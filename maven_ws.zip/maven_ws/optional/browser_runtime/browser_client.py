"""
Browser Client Bridge
=====================

Provides an `is_available()` function for the capabilities probe to check
whether the browser runtime server is running and reachable.

This module bridges the capability probe in brains/system_capabilities.py
with the actual browser runtime server.
"""

from __future__ import annotations

import socket
from typing import Optional

from optional.browser_runtime.config import get_config


def is_available(timeout: float = 1.0) -> bool:
    """
    Check if the browser runtime server is available.

    This does a simple TCP connection test to the server's host:port.
    A full HTTP healthcheck would require additional dependencies.

    Args:
        timeout: Connection timeout in seconds.

    Returns:
        True if the server is reachable, False otherwise.
    """
    config = get_config()
    host = config.host
    port = config.port

    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except (socket.error, socket.timeout, OSError):
        return False


def get_server_url() -> str:
    """
    Get the URL of the browser runtime server.

    Returns:
        The base URL for the browser runtime server (e.g., "http://127.0.0.1:8765")
    """
    config = get_config()
    return f"http://{config.host}:{config.port}"


def health_check() -> Optional[dict]:
    """
    Perform an HTTP healthcheck against the browser runtime server.

    Returns:
        The health response dict if server is healthy, None otherwise.
    """
    try:
        import urllib.request
        import json

        url = f"{get_server_url()}/health"
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=2.0) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)
    except Exception:
        return None


def open_url(target_url: str, wait_until: str = "domcontentloaded") -> dict:
    """
    Open a URL in the browser runtime server.

    This sends a POST request to the /open endpoint to navigate
    to a URL and return a page snapshot.

    Args:
        target_url: The URL to open.
        wait_until: When to consider navigation done ('domcontentloaded', 'load', 'networkidle').

    Returns:
        A dict with the result including page_id, snapshot, etc.
        On error, returns dict with 'error' key.
    """
    try:
        import urllib.request
        import json

        api_url = f"{get_server_url()}/open"
        payload = json.dumps({
            "url": target_url,
            "wait_until": wait_until,
        }).encode("utf-8")

        req = urllib.request.Request(
            api_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=30.0) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        return {"error": str(e), "success": False}


def click_element(
    selector: Optional[str] = None,
    text: Optional[str] = None,
    page_id: Optional[str] = None,
) -> dict:
    """
    Click an element on the current page.

    Args:
        selector: CSS selector of element to click (e.g., "button.submit", "#search-btn")
        text: Text content to find and click (e.g., "Search", "Submit")
        page_id: Optional page ID to target (uses current page if not specified)

    Returns:
        A dict with the result including snapshot.
        On error, returns dict with 'error' key.

    Examples:
        click_element(selector="input[type='submit']")
        click_element(text="Search")
    """
    if not selector and not text:
        return {"error": "Must specify either selector or text", "success": False}

    try:
        import urllib.request
        import json

        api_url = f"{get_server_url()}/click"
        payload_data = {}
        if selector:
            payload_data["selector"] = selector
        if text:
            payload_data["text"] = text
        if page_id:
            payload_data["page_id"] = page_id

        payload = json.dumps(payload_data).encode("utf-8")

        req = urllib.request.Request(
            api_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=30.0) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        return {"error": str(e), "success": False}


def type_text(
    selector: str,
    text: str,
    clear_first: bool = True,
    page_id: Optional[str] = None,
) -> dict:
    """
    Type text into an input element.

    Args:
        selector: CSS selector of input element (e.g., "input[name='q']", "#search-box")
        text: Text to type into the element
        clear_first: Whether to clear the input before typing (default True)
        page_id: Optional page ID to target (uses current page if not specified)

    Returns:
        A dict with the result including snapshot.
        On error, returns dict with 'error' key.

    Examples:
        type_text("input[name='search_query']", "funny videos")
        type_text("#searchbox", "python tutorials", clear_first=True)
    """
    try:
        import urllib.request
        import json

        api_url = f"{get_server_url()}/type"
        payload_data = {
            "selector": selector,
            "text": text,
            "clear_first": clear_first,
        }
        if page_id:
            payload_data["page_id"] = page_id

        payload = json.dumps(payload_data).encode("utf-8")

        req = urllib.request.Request(
            api_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=30.0) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        return {"error": str(e), "success": False}


def search_on_page(
    query: str,
    search_selector: str = "input[name='search_query'], input[name='q'], input[type='search'], #search-box, .search-input",
    submit_selector: Optional[str] = None,
    page_id: Optional[str] = None,
) -> dict:
    """
    Perform a search on the current page by typing into search box and submitting.

    This function types the query into the search input and presses Enter.
    It does NOT navigate to a search engine - it searches on the CURRENT page.

    Args:
        query: The search query to enter
        search_selector: CSS selector for the search input (default tries common patterns)
        submit_selector: Optional selector for submit button (if None, presses Enter)
        page_id: Optional page ID to target

    Returns:
        A dict with the result including snapshot.
        On error, returns dict with 'error' key.

    Examples:
        search_on_page("funny videos")  # Uses default search input detection
        search_on_page("python", search_selector="#search-input")
    """
    try:
        # Step 1: Type the query into the search box
        type_result = type_text(
            selector=search_selector,
            text=query,
            clear_first=True,
            page_id=page_id,
        )

        if type_result.get("error"):
            return {
                "error": f"Failed to type search query: {type_result['error']}",
                "success": False,
            }

        # Step 2: Submit the search (click button or press Enter)
        if submit_selector:
            submit_result = click_element(selector=submit_selector, page_id=page_id)
            if submit_result.get("error"):
                return {
                    "error": f"Failed to click submit: {submit_result['error']}",
                    "success": False,
                }
            return submit_result
        else:
            # Press Enter to submit
            enter_result = press_key("Enter", page_id=page_id)
            if enter_result.get("error"):
                return {
                    "error": f"Failed to press Enter: {enter_result['error']}",
                    "success": False,
                }
            return enter_result

    except Exception as e:
        return {"error": str(e), "success": False}


def press_key(key: str, page_id: Optional[str] = None) -> dict:
    """
    Press a keyboard key on the current page.

    Args:
        key: Key to press (e.g., "Enter", "Tab", "Escape", "ArrowDown")
        page_id: Optional page ID to target

    Returns:
        A dict with the result.
        On error, returns dict with 'error' key.

    Examples:
        press_key("Enter")
        press_key("Tab")
    """
    try:
        import urllib.request
        import json

        api_url = f"{get_server_url()}/key"
        payload_data = {"key": key}
        if page_id:
            payload_data["page_id"] = page_id

        payload = json.dumps(payload_data).encode("utf-8")

        req = urllib.request.Request(
            api_url,
            data=payload,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        with urllib.request.urlopen(req, timeout=30.0) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)
    except Exception as e:
        return {"error": str(e), "success": False}
