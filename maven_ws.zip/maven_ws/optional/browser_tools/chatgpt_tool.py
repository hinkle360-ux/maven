# optional/browser_tools/chatgpt_tool.py — ChatGPT Browser Tool
"""
ChatGPT browser tool with persistent session.

Features:
- chatgpt(message) - Send message to ChatGPT, get reply
- chatgpt_open_session() - Open session, return page_id
- chatgpt_send(page_id, message) - Send to existing session
- chatgpt_login_once() - One-time login handler

Usage:
    from optional.browser_tools.chatgpt_tool import chatgpt, chatgpt_open_session, chatgpt_send

    # One-off message:
    reply = chatgpt("What is 2+2?")

    # Multi-turn session:
    page_id = chatgpt_open_session()
    reply1 = chatgpt_send(page_id, "Hello!")
    reply2 = chatgpt_send(page_id, "Tell me more")
"""

import json
import time
import urllib.request
from pathlib import Path

BROWSER_URL = "http://127.0.0.1:8765"
CHATGPT_URL = "https://chatgpt.com/"
SESSION_FILE = Path("chatgpt_session.json")

DEBUG = True


def _post(endpoint: str, data: dict) -> dict:
    """Make POST request to browser server."""
    if DEBUG:
        print(f"[CHATGPT] POST {endpoint}: {json.dumps(data)[:80]}...")

    req = urllib.request.Request(
        f"{BROWSER_URL}{endpoint}",
        data=json.dumps(data).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            result = json.loads(r.read().decode())
            if DEBUG:
                status = result.get("status", result.get("error", "unknown"))
                print(f"[CHATGPT] Response: {status}")
            return result
    except Exception as e:
        if DEBUG:
            print(f"[CHATGPT] Error: {e}")
        return {"error": str(e), "status": "error"}


def _wait_for(page_id: str, selector: str, timeout_ms: int = 10000) -> bool:
    """Wait for an element to appear on the page."""
    result = _post("/wait_for", {
        "page_id": page_id,
        "selector": selector,
        "timeout_ms": timeout_ms
    })
    return result.get("status") == "success"


def _is_page_valid(page_id: str) -> bool:
    """Check if a page_id is still valid."""
    if not page_id:
        return False
    result = _post("/get_page", {"page_id": page_id, "include_text": False})
    return result.get("status") != "error" and "error" not in result


# ChatGPT-specific selectors (contenteditable first - that's what works)
CHATGPT_INPUT_SELECTORS = [
    "div[contenteditable='true']",
    "div[role='textbox']",
    "div[data-placeholder]",
    "textarea#prompt-textarea",
    "textarea[placeholder]",
    "textarea",
]

# Navigation junk to filter out
CHATGPT_JUNK = [
    "ChatGPT", "New chat", "Upgrade", "User", "Settings",
    "Help", "Log out", "GPT-4", "GPT-3.5", "Today", "Yesterday",
    "Previous 7 Days", "Previous 30 Days", "Regenerate", "Stop generating",
]


def _extract_chatgpt_reply(text: str, user_message: str) -> str:
    """Extract ChatGPT's reply from page text."""
    # Method 1: Split on user message
    if user_message and user_message[:50] in text:
        msg_start = user_message[:50]
        parts = text.split(msg_start)
        if len(parts) > 1:
            reply = parts[-1].strip()
            # Clean junk
            for junk in CHATGPT_JUNK:
                if junk in reply:
                    reply = reply.split(junk)[0]
            reply = reply.strip()
            if len(reply) > 20:
                return reply

    # Method 2: Look for assistant markers
    # ChatGPT often has "ChatGPT" before its responses
    if "ChatGPT" in text:
        parts = text.split("ChatGPT")
        if len(parts) > 1:
            # Get last ChatGPT response
            reply = parts[-1].strip()
            for junk in CHATGPT_JUNK:
                if junk in reply:
                    reply = reply.split(junk)[0]
            reply = reply.strip()
            if len(reply) > 20:
                return reply

    return "ChatGPT is thinking..."


# ============================================================================
# Main Functions
# ============================================================================

def chatgpt(message: str) -> str:
    """
    Send a message to ChatGPT and get a reply.
    Opens a new page each time.
    """
    # 1. Open ChatGPT
    result = _post("/open", {"url": CHATGPT_URL})
    page_id = result.get("page_id")
    if not page_id:
        return f"Failed to open ChatGPT: {result}"

    # 2. Wait for chat input
    found_selector = None
    for selector in CHATGPT_INPUT_SELECTORS:
        if _wait_for(page_id, selector, timeout_ms=8000):
            found_selector = selector
            print(f"[CHATGPT] Found input: {selector}")
            break

    if not found_selector:
        page = _post("/get_page", {"page_id": page_id, "include_text": True})
        return f"Could not find chat input. Page: {page.get('text', '')[:200]}"

    # 3. Click to focus
    _post("/click", {"page_id": page_id, "selector": found_selector})
    time.sleep(0.5)

    # 4. Type with submit
    _post("/type", {
        "page_id": page_id,
        "selector": found_selector,
        "text": message,
        "submit": True
    })

    # 5. Wait for response
    print("[CHATGPT] Waiting for response...")
    time.sleep(15)

    # 6. Extract reply with polling
    for attempt in range(3):
        page = _post("/get_page", {"page_id": page_id, "include_text": True})
        text = page.get("text", "")

        reply = _extract_chatgpt_reply(text, message)
        if reply != "ChatGPT is thinking...":
            return reply

        if attempt < 2:
            time.sleep(5)

    return "ChatGPT is thinking..."


# ============================================================================
# Session-aware Functions (reuse same window)
# ============================================================================

_chatgpt_page_id = None


def chatgpt_open_session() -> str:
    """Open ChatGPT once, return page_id for chatgpt_send(). Reuses existing window if valid."""
    global _chatgpt_page_id

    # Try to reuse existing page
    if _chatgpt_page_id and _is_page_valid(_chatgpt_page_id):
        print(f"[CHATGPT] Reusing existing window: {_chatgpt_page_id}")
        _post("/open", {"url": CHATGPT_URL, "page_id": _chatgpt_page_id})
        time.sleep(1)
        return _chatgpt_page_id

    # Open new page
    print("[CHATGPT] Opening new window...")
    result = _post("/open", {"url": CHATGPT_URL})
    page_id = result.get("page_id")
    if not page_id:
        return None

    # Wait for input to be ready
    for selector in CHATGPT_INPUT_SELECTORS:
        if _wait_for(page_id, selector, timeout_ms=8000):
            print(f"[CHATGPT] Session ready, found: {selector}")
            break

    _chatgpt_page_id = page_id
    return page_id


def chatgpt_send(page_id: str, message: str) -> str:
    """Send message to existing ChatGPT session."""
    # Find input
    found_selector = None
    for selector in CHATGPT_INPUT_SELECTORS:
        if _wait_for(page_id, selector, timeout_ms=5000):
            found_selector = selector
            break

    if not found_selector:
        return "Could not find chat input"

    # Click to focus
    _post("/click", {"page_id": page_id, "selector": found_selector})
    time.sleep(0.5)

    # Type with submit
    _post("/type", {
        "page_id": page_id,
        "selector": found_selector,
        "text": message,
        "submit": True
    })

    # Wait for response
    print("[CHATGPT] Waiting for response...")
    time.sleep(15)

    # Extract reply with polling
    for attempt in range(3):
        page = _post("/get_page", {"page_id": page_id, "include_text": True})
        text = page.get("text", "")

        reply = _extract_chatgpt_reply(text, message)
        if reply != "ChatGPT is thinking...":
            return reply

        if attempt < 2:
            time.sleep(5)

    return "ChatGPT is thinking..."


# ============================================================================
# Login Helper
# ============================================================================

def chatgpt_login_once():
    """
    One-time login handler.
    Opens ChatGPT, waits for you to log in, then saves the session.
    """
    result = _post("/open", {"url": CHATGPT_URL})
    page_id = result.get("page_id")
    if not page_id:
        print(f"[CHATGPT] Failed to open: {result}")
        return

    page = _post("/get_page", {"page_id": page_id, "include_text": True})

    if any(word in page.get("text", "").lower() for word in ["log in", "sign up", "welcome"]):
        print("[CHATGPT] Please log in via the browser, then press ENTER here")
        input("Done? > ")
        cookies = _post("/cookies", {"page_id": page_id})
        SESSION_FILE.write_text(json.dumps(cookies), encoding="utf-8")
        print("[CHATGPT] Session saved!")
    else:
        print("[CHATGPT] Already logged in!")


# ============================================================================
# CLI Testing
# ============================================================================

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python chatgpt_tool.py login")
        print("  python chatgpt_tool.py chat <message>")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "login":
        chatgpt_login_once()
    elif cmd == "chat":
        msg = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "Hello ChatGPT!"
        print(f"Sending: {msg}")
        print(f"Reply: {chatgpt(msg)}")
    else:
        print(f"Unknown command: {cmd}")
