# optional/browser_tools/claude_tool.py — Claude Browser Tool
"""
Claude browser tool with persistent session.

Features:
- claude(message) - Send message to Claude, get reply
- claude_open_session() - Open session, return page_id
- claude_send(page_id, message) - Send to existing session
- claude_login_once() - One-time login handler

Usage:
    from optional.browser_tools.claude_tool import claude, claude_open_session, claude_send

    # One-off message:
    reply = claude("What is 2+2?")

    # Multi-turn session:
    page_id = claude_open_session()
    reply1 = claude_send(page_id, "Hello!")
    reply2 = claude_send(page_id, "Tell me more")
"""

import json
import time
import urllib.request
from pathlib import Path

BROWSER_URL = "http://127.0.0.1:8765"
CLAUDE_URL = "https://claude.ai/new"
SESSION_FILE = Path("claude_session.json")

DEBUG = True


def _post(endpoint: str, data: dict) -> dict:
    """Make POST request to browser server."""
    if DEBUG:
        print(f"[CLAUDE] POST {endpoint}: {json.dumps(data)[:80]}...")

    req = urllib.request.Request(
        f"{BROWSER_URL}{endpoint}",
        data=json.dumps(data).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            result = json.loads(r.read().decode())
            if DEBUG:
                status = result.get("status", result.get("error", "unknown"))
                print(f"[CLAUDE] Response: {status}")
            return result
    except Exception as e:
        if DEBUG:
            print(f"[CLAUDE] Error: {e}")
        return {"error": str(e), "status": "error"}


def _wait_for(page_id: str, selector: str, timeout_ms: int = 10000) -> bool:
    """Wait for an element to appear on the page."""
    result = _post("/wait_for", {
        "page_id": page_id,
        "selector": selector,
        "timeout_ms": timeout_ms
    })
    return result.get("status") == "success"


def _is_page_valid(page_id: str) -> bool:
    """Check if a page_id is still valid."""
    if not page_id:
        return False
    result = _post("/get_page", {"page_id": page_id, "include_text": False})
    return result.get("status") != "error" and "error" not in result


# Claude-specific selectors
CLAUDE_INPUT_SELECTORS = [
    "div[contenteditable='true']",
    "div[data-placeholder]",
    "div[role='textbox']",
    "textarea",
    "div.ProseMirror",
]

# Navigation junk to filter out
CLAUDE_JUNK = [
    "Claude", "New chat", "Starred", "Recents", "Settings",
    "Help", "Log out", "Pro", "Today", "Yesterday",
    "Previous 7 Days", "Previous 30 Days", "Stop", "Copy",
    "Retry", "Edit", "Anthropic", "Home",
]


def _extract_claude_reply(text: str, user_message: str) -> str:
    """Extract Claude's reply from page text."""
    # Method 1: Split on user message
    if user_message and user_message[:50] in text:
        msg_start = user_message[:50]
        parts = text.split(msg_start)
        if len(parts) > 1:
            reply = parts[-1].strip()
            # Clean junk
            for junk in CLAUDE_JUNK:
                if junk in reply:
                    reply = reply.split(junk)[0]
            reply = reply.strip()
            if len(reply) > 20:
                return reply

    # Method 2: Look for assistant markers
    # Claude often has specific patterns in its responses
    lines = text.splitlines()
    # Find content after what looks like user input
    reply_lines = []
    found_response = False
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # Skip navigation junk
        if any(junk in line for junk in CLAUDE_JUNK):
            if found_response and reply_lines:
                break
            continue
        if found_response:
            reply_lines.append(line)
        # Look for the end of user message area
        if user_message and user_message[:30] in line:
            found_response = True

    if reply_lines:
        reply = "\n".join(reply_lines).strip()
        if len(reply) > 20:
            return reply

    return "Claude is thinking..."


# ============================================================================
# Main Functions
# ============================================================================

def claude(message: str) -> str:
    """
    Send a message to Claude and get a reply.
    Opens a new page each time.
    """
    # 1. Open Claude
    result = _post("/open", {"url": CLAUDE_URL})
    page_id = result.get("page_id")
    if not page_id:
        return f"Failed to open Claude: {result}"

    # 2. Wait for chat input
    found_selector = None
    for selector in CLAUDE_INPUT_SELECTORS:
        if _wait_for(page_id, selector, timeout_ms=8000):
            found_selector = selector
            print(f"[CLAUDE] Found input: {selector}")
            break

    if not found_selector:
        page = _post("/get_page", {"page_id": page_id, "include_text": True})
        return f"Could not find chat input. Page: {page.get('text', '')[:200]}"

    # 3. Click to focus
    _post("/click", {"page_id": page_id, "selector": found_selector})
    time.sleep(0.5)

    # 4. Type with submit
    _post("/type", {
        "page_id": page_id,
        "selector": found_selector,
        "text": message,
        "submit": True
    })

    # 5. Wait for response
    print("[CLAUDE] Waiting for response...")
    time.sleep(15)

    # 6. Extract reply with polling
    for attempt in range(3):
        page = _post("/get_page", {"page_id": page_id, "include_text": True})
        text = page.get("text", "")

        reply = _extract_claude_reply(text, message)
        if reply != "Claude is thinking...":
            return reply

        if attempt < 2:
            time.sleep(5)

    return "Claude is thinking..."


# ============================================================================
# Session-aware Functions (reuse same window)
# ============================================================================

_claude_page_id = None


def claude_open_session() -> str:
    """Open Claude once, return page_id for claude_send(). Reuses existing window if valid."""
    global _claude_page_id

    # Try to reuse existing page
    if _claude_page_id and _is_page_valid(_claude_page_id):
        print(f"[CLAUDE] Reusing existing window: {_claude_page_id}")
        _post("/open", {"url": CLAUDE_URL, "page_id": _claude_page_id})
        time.sleep(1)
        return _claude_page_id

    # Open new page
    print("[CLAUDE] Opening new window...")
    result = _post("/open", {"url": CLAUDE_URL})
    page_id = result.get("page_id")
    if not page_id:
        return None

    # Wait for input to be ready
    for selector in CLAUDE_INPUT_SELECTORS:
        if _wait_for(page_id, selector, timeout_ms=8000):
            print(f"[CLAUDE] Session ready, found: {selector}")
            break

    _claude_page_id = page_id
    return page_id


def claude_send(page_id: str, message: str) -> str:
    """Send message to existing Claude session."""
    # Find input
    found_selector = None
    for selector in CLAUDE_INPUT_SELECTORS:
        if _wait_for(page_id, selector, timeout_ms=5000):
            found_selector = selector
            break

    if not found_selector:
        return "Could not find chat input"

    # Click to focus
    _post("/click", {"page_id": page_id, "selector": found_selector})
    time.sleep(0.5)

    # Type with submit
    _post("/type", {
        "page_id": page_id,
        "selector": found_selector,
        "text": message,
        "submit": True
    })

    # Wait for response
    print("[CLAUDE] Waiting for response...")
    time.sleep(15)

    # Extract reply with polling
    for attempt in range(3):
        page = _post("/get_page", {"page_id": page_id, "include_text": True})
        text = page.get("text", "")

        reply = _extract_claude_reply(text, message)
        if reply != "Claude is thinking...":
            return reply

        if attempt < 2:
            time.sleep(5)

    return "Claude is thinking..."


# ============================================================================
# Login Helper
# ============================================================================

def claude_login_once():
    """
    One-time login handler.
    Opens Claude, waits for you to log in, then saves the session.
    """
    result = _post("/open", {"url": CLAUDE_URL})
    page_id = result.get("page_id")
    if not page_id:
        print(f"[CLAUDE] Failed to open: {result}")
        return

    page = _post("/get_page", {"page_id": page_id, "include_text": True})

    if any(word in page.get("text", "").lower() for word in ["log in", "sign in", "sign up", "continue with"]):
        print("[CLAUDE] Please log in via the browser, then press ENTER here")
        input("Done? > ")
        cookies = _post("/cookies", {"page_id": page_id})
        SESSION_FILE.write_text(json.dumps(cookies), encoding="utf-8")
        print("[CLAUDE] Session saved!")
    else:
        print("[CLAUDE] Already logged in!")


# ============================================================================
# CLI Testing
# ============================================================================

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python claude_tool.py login")
        print("  python claude_tool.py chat <message>")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "login":
        claude_login_once()
    elif cmd == "chat":
        msg = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "Hello Claude!"
        print(f"Sending: {msg}")
        print(f"Reply: {claude(msg)}")
    else:
        print(f"Unknown command: {cmd}")
