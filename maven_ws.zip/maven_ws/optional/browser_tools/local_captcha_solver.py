"""
Local CAPTCHA Solver
====================

Minimal viable implementation for CAPTCHA handling.
Does NOT actually solve CAPTCHAs - returns a result indicating
human intervention is required.

This module provides safe fallback behavior when CAPTCHAs are encountered.
"""

import base64
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any
import re


@dataclass
class CaptchaResult:
    """Result of CAPTCHA detection/solving attempt."""
    status: str  # "solved", "requires_human", "unsupported", "error"
    solution: Optional[str] = None
    captcha_type: str = "unknown"
    confidence: float = 0.0
    message: str = ""


# Known CAPTCHA element patterns
CAPTCHA_PATTERNS = [
    r'recaptcha',
    r'hcaptcha',
    r'captcha',
    r'g-recaptcha',
    r'cf-turnstile',
    r'challenge-form',
    r'security-check',
]


def detect_captcha(html_content: str) -> Dict[str, Any]:
    """
    Detect if a page contains a CAPTCHA.

    Args:
        html_content: HTML content of the page

    Returns:
        Dict containing:
        - detected: bool
        - captcha_type: str
        - confidence: float
    """
    html_lower = html_content.lower()
    detected = False
    captcha_type = "unknown"
    confidence = 0.0

    for pattern in CAPTCHA_PATTERNS:
        if re.search(pattern, html_lower):
            detected = True
            confidence = 0.8

            if 'recaptcha' in pattern or 'g-recaptcha' in pattern:
                captcha_type = "recaptcha"
            elif 'hcaptcha' in pattern:
                captcha_type = "hcaptcha"
            elif 'turnstile' in pattern:
                captcha_type = "cloudflare_turnstile"
            else:
                captcha_type = "generic"
            break

    # Check for iframe-based CAPTCHAs
    if not detected and 'iframe' in html_lower:
        if 'recaptcha' in html_lower or 'captcha' in html_lower:
            detected = True
            captcha_type = "iframe_captcha"
            confidence = 0.6

    return {
        "detected": detected,
        "captcha_type": captcha_type,
        "confidence": confidence,
    }


async def solve_captcha(
    image_base64: str,
    captcha_type: str = "text"
) -> CaptchaResult:
    """
    Attempt to solve a CAPTCHA locally.

    This implementation does NOT actually solve CAPTCHAs.
    It returns a result indicating human intervention is required.

    Args:
        image_base64: Base64-encoded image of the CAPTCHA
        captcha_type: Type of CAPTCHA ("text", "image", "recaptcha", "hcaptcha")

    Returns:
        CaptchaResult indicating human intervention required
    """
    # Validate input
    if not image_base64:
        return CaptchaResult(
            status="error",
            captcha_type=captcha_type,
            message="No image data provided"
        )

    # Check if this is a type we might handle in future
    supported_types = ["text", "simple_text"]
    if captcha_type in supported_types:
        # Even for "supported" types, we return requires_human
        # since we don't have actual OCR implemented
        return CaptchaResult(
            status="requires_human",
            captcha_type=captcha_type,
            confidence=0.0,
            message="Text CAPTCHA detected. Human solving required."
        )

    # Modern CAPTCHAs are not locally solvable
    modern_types = ["recaptcha", "hcaptcha", "cloudflare_turnstile"]
    if captcha_type in modern_types:
        return CaptchaResult(
            status="unsupported",
            captcha_type=captcha_type,
            confidence=0.0,
            message=f"{captcha_type} cannot be solved locally. Human intervention required."
        )

    # Default fallback
    return CaptchaResult(
        status="requires_human",
        captcha_type=captcha_type,
        confidence=0.0,
        message="CAPTCHA requires human solving"
    )


def solve_text_captcha_ocr(image_path: Path) -> CaptchaResult:
    """
    Attempt to solve a simple text CAPTCHA using OCR.

    Currently returns requires_human as OCR is not implemented.

    Args:
        image_path: Path to the CAPTCHA image

    Returns:
        CaptchaResult
    """
    if not image_path.exists():
        return CaptchaResult(
            status="error",
            captcha_type="text",
            message=f"Image not found: {image_path}"
        )

    # OCR would go here if pytesseract was available
    # For now, return requires_human
    return CaptchaResult(
        status="requires_human",
        captcha_type="text",
        confidence=0.0,
        message="OCR not available. Human solving required."
    )


def get_captcha_handling_strategy(captcha_type: str) -> Dict[str, Any]:
    """
    Get recommended handling strategy for a CAPTCHA type.

    Args:
        captcha_type: Detected CAPTCHA type

    Returns:
        Dict with handling recommendations
    """
    strategies = {
        "recaptcha": {
            "action": "pause",
            "message": "reCAPTCHA detected. Automation paused for human solving.",
            "can_retry": True,
            "retry_delay": 60,
        },
        "hcaptcha": {
            "action": "pause",
            "message": "hCaptcha detected. Automation paused for human solving.",
            "can_retry": True,
            "retry_delay": 60,
        },
        "cloudflare_turnstile": {
            "action": "wait",
            "message": "Cloudflare challenge. Waiting for automatic completion.",
            "can_retry": True,
            "retry_delay": 10,
        },
        "text": {
            "action": "pause",
            "message": "Text CAPTCHA detected. Human solving may be required.",
            "can_retry": True,
            "retry_delay": 30,
        },
        "unknown": {
            "action": "skip",
            "message": "Unknown CAPTCHA type. Skipping page.",
            "can_retry": False,
            "retry_delay": 0,
        },
    }

    return strategies.get(captcha_type, strategies["unknown"])
