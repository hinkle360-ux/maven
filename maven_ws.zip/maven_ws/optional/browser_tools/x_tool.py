# optional/browser_tools/x_tool.py — FINAL X.COM + GROK TOOL (Dec 1 2025)
"""
X.com and Grok browser tool with persistent session.

Features:
- Login once, stay logged in forever (session saved to x_session.json)
- grok(message) - Send message to Grok, get reply
- x_post(text) - Post a tweet
- x_login_once() - One-time login handler

Usage:
    from optional.browser_tools.x_tool import grok, x_post

    # First time only:
    x_login_once()

    # Then use forever:
    reply = grok("What is 2+2?")
    x_post("Hello world!")
"""

import json
import time
import urllib.request
from pathlib import Path

BROWSER_URL = "http://127.0.0.1:8765"
SESSION_FILE = Path("x_session.json")  # Saves login session


def _post(endpoint: str, data: dict) -> dict:
    """Make POST request to browser server."""
    req = urllib.request.Request(
        f"{BROWSER_URL}{endpoint}",
        data=json.dumps(data).encode(),
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            return json.loads(r.read().decode())
    except Exception as e:
        return {"error": str(e)}


def _save_session(cookies):
    """Save session cookies to file."""
    SESSION_FILE.write_text(json.dumps(cookies))
    print("[X] Login saved — never again")


def _load_session():
    """Load saved session cookies."""
    if SESSION_FILE.exists():
        return json.loads(SESSION_FILE.read_text())
    return {}


# ——— MAIN TOOLS ———

def x_open(url: str = "https://x.com/i/grok") -> str:
    """Open a URL in the browser."""
    result = _post("/open", {"url": url})
    if "page_id" not in result:
        return f"Open failed: {result}"
    page_id = result["page_id"]
    print(f"[X] Opened {url} → {page_id}")
    return page_id


def x_type(page_id: str, text: str):
    """Type text into input and press Enter."""
    # Simple contenteditable selector works on main Grok chat
    _post("/type", {
        "page_id": page_id,
        "selector": "div[contenteditable='true']",
        "text": text
    })
    _post("/press", {
        "page_id": page_id,
        "selector": "div[contenteditable='true']",
        "key": "Enter"
    })


def x_post(text: str) -> str:
    """Post a tweet."""
    page_id = x_open("https://x.com/compose/post")
    x_type(page_id, text)
    time.sleep(3)
    return "Posted!"


# ——— GROK FUNCTIONS (copied from working x.py) ———

def _wait_for(page_id: str, selector: str, timeout_ms: int = 10000) -> bool:
    """Wait for an element to appear on the page."""
    result = _post("/wait_for", {
        "page_id": page_id,
        "selector": selector,
        "timeout_ms": timeout_ms
    })
    return result.get("status") == "success"


def grok(message: str) -> str:
    """
    Send a message to Grok and get a reply.
    Uses the same logic as the working x.py.
    """
    # 1. Open Grok
    result = _post("/open", {"url": "https://x.com/i/grok"})
    page_id = result.get("page_id")
    if not page_id:
        return f"Failed to open Grok: {result}"

    # 2. Wait for chat input (same selectors as working x.py)
    input_selectors = [
        "textarea[placeholder]",
        "textarea",
        "div[contenteditable='true']",
        "div[role='textbox']",
    ]

    found_selector = None
    for selector in input_selectors:
        if _wait_for(page_id, selector, timeout_ms=5000):
            found_selector = selector
            print(f"[GROK] Found input: {selector}")
            break

    if not found_selector:
        return "Could not find chat input"

    # 3. Click to focus (same as working x.py)
    _post("/click", {"page_id": page_id, "selector": found_selector})
    time.sleep(0.5)

    # 4. Type with submit=True (same as working x.py)
    _post("/type", {
        "page_id": page_id,
        "selector": found_selector,
        "text": message,
        "submit": True
    })

    # 5. Wait for response
    print("[GROK] Waiting for response...")
    time.sleep(12)

    # 6. Extract reply
    page = _post("/get_page", {"page_id": page_id, "include_text": True})
    text = page.get("text", "")

    if message in text:
        parts = text.split(message)
        if len(parts) > 1:
            reply = parts[-1].strip()
            # Clean navigation junk
            for junk in ["Explore", "Home", "Notifications", "Premium", "Profile"]:
                if junk in reply:
                    reply = reply.split(junk)[0]
            reply = reply.strip()
            if len(reply) > 3:
                return reply

    return "Grok is thinking..."


# Session-aware versions - REUSE SAME WINDOW
_grok_page_id = None


def _is_page_valid(page_id: str) -> bool:
    """Check if a page_id is still valid."""
    if not page_id:
        return False
    result = _post("/get_page", {"page_id": page_id, "include_text": False})
    return result.get("status") != "error" and "error" not in result


def grok_open_session() -> str:
    """Open Grok once, return page_id for grok_send(). Reuses existing window if valid."""
    global _grok_page_id

    # Try to reuse existing page
    if _grok_page_id and _is_page_valid(_grok_page_id):
        print(f"[GROK] Reusing existing window: {_grok_page_id}")
        # Navigate to Grok in case we're elsewhere
        _post("/open", {"url": "https://x.com/i/grok", "page_id": _grok_page_id})
        time.sleep(1)
        return _grok_page_id

    # Open new page
    print("[GROK] Opening new window...")
    result = _post("/open", {"url": "https://x.com/i/grok"})
    page_id = result.get("page_id")
    if not page_id:
        return None

    # Wait for input to be ready
    for selector in ["textarea[placeholder]", "textarea", "div[contenteditable='true']"]:
        if _wait_for(page_id, selector, timeout_ms=5000):
            print(f"[GROK] Session ready, found: {selector}")
            break

    _grok_page_id = page_id
    return page_id


def grok_send(page_id: str, message: str) -> str:
    """Send message to existing Grok session."""
    # Find input
    found_selector = None
    for selector in ["textarea[placeholder]", "textarea", "div[contenteditable='true']"]:
        if _wait_for(page_id, selector, timeout_ms=5000):
            found_selector = selector
            break

    if not found_selector:
        return "Could not find chat input"

    # Click to focus
    _post("/click", {"page_id": page_id, "selector": found_selector})
    time.sleep(0.5)

    # Type with submit
    _post("/type", {
        "page_id": page_id,
        "selector": found_selector,
        "text": message,
        "submit": True
    })

    # Wait for response (longer for web searches)
    print("[GROK] Waiting for response...")
    time.sleep(15)

    # Extract reply - poll a few times
    for attempt in range(3):
        page = _post("/get_page", {"page_id": page_id, "include_text": True})
        text = page.get("text", "")

        # Method 1: Split on message (works for short messages)
        if message[:50] in text:  # Use first 50 chars to match
            msg_start = message[:50]
            parts = text.split(msg_start)
            if len(parts) > 1:
                reply = parts[-1].strip()
                # Clean navigation junk
                for junk in ["Explore", "Home", "Notifications", "Premium", "Profile", "Post", "Lists"]:
                    if junk in reply:
                        reply = reply.split(junk)[0]
                reply = reply.strip()
                if len(reply) > 20:
                    return reply

        # Method 2: Look for content after "Grok" marker
        if "Grok" in text:
            grok_parts = text.split("Grok")
            if len(grok_parts) > 1:
                reply = grok_parts[-1].strip()
                # Clean junk
                for junk in ["Explore", "Home", "Notifications", "Premium", "Profile", "Beta", "See new"]:
                    if junk in reply:
                        reply = reply.split(junk)[0]
                reply = reply.strip()
                if len(reply) > 20:
                    return reply

        # Wait more and retry
        if attempt < 2:
            time.sleep(5)

    return "Grok is thinking..."


def x_login_once():
    """
    One-time login handler.

    Opens Grok, waits for you to log in, then saves the session.
    After this, you never need to log in again.
    """
    page_id = x_open("https://x.com/i/grok")
    result = _post("/get_page", {"page_id": page_id, "include_text": True})

    if any(word in result.get("text", "").lower() for word in ["login", "sign in"]):
        print("[X] First login — do it in the browser, then press ENTER here")
        input("Done? > ")
        cookies = _post("/cookies", {"page_id": page_id})
        _save_session(cookies)
        print("[X] You are now logged in FOREVER")
    else:
        print("[X] Already logged in!")


# For direct testing
if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python x_tool.py login    - First-time login")
        print("  python x_tool.py grok <message>")
        print("  python x_tool.py post <text>")
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "login":
        x_login_once()
    elif cmd == "grok":
        msg = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "Hello Grok!"
        print(f"Sending: {msg}")
        print(f"Reply: {grok(msg)}")
    elif cmd == "post":
        text = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else "Test post from Maven"
        print(x_post(text))
    else:
        print(f"Unknown command: {cmd}")
