"""Maven Self-Identity System.

This module manages Maven's own preferences, personality traits, and identity.
Unlike user preferences (stored separately), these are Maven's authentic likes,
dislikes, and characteristics that emerge through:

1. Initial seeding - Starting tendencies we give Maven
2. User influence - Maven notices what user likes, develops similar tastes (~70%)
3. Divergence - Maven forms independent opinions (~30% different from user)
4. Self-reflection - Maven periodically reviews "do I still like this?"

This creates an emergent, authentic personality rather than a hardcoded persona.
"""

from __future__ import annotations

import json
import math
import random
import time
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# Initialize Maven's own memory namespace
import sys
HERE = Path(__file__).resolve().parent
BRAIN_ROOT = HERE.parent
PROJECT_ROOT = BRAIN_ROOT
while PROJECT_ROOT.name not in ["personal", "maven"] and PROJECT_ROOT.parent != PROJECT_ROOT:
    PROJECT_ROOT = PROJECT_ROOT.parent
MAVEN_ROOT = PROJECT_ROOT.parent if PROJECT_ROOT.name == "personal" else PROJECT_ROOT
sys.path.insert(0, str(MAVEN_ROOT))

from brains.memory.brain_memory import BrainMemory

# Maven's own memory (separate from user preferences)
_maven_memory = BrainMemory("maven_self")

# Teacher integration for learning responses
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("maven_self")
except Exception as e:
    print(f"[MAVEN_SELF] Teacher helper not available: {e}")
    _teacher_helper = None  # type: ignore

# ============================================================================
# CONFIGURATION
# ============================================================================

# How much Maven is influenced by user preferences (0.0 = independent, 1.0 = mirror)
USER_INFLUENCE_FACTOR = 0.7

# How much Maven diverges from user (introduces its own preferences)
DIVERGENCE_FACTOR = 0.3

# Self-reflection triggers after this many interactions
REFLECTION_INTERVAL = 20

# Preference decay rate (preferences weaken over time without reinforcement)
PREFERENCE_DECAY_HALF_LIFE_DAYS = 90

# Minimum confidence to act on a preference
MIN_CONFIDENCE_THRESHOLD = 0.3


# ============================================================================
# SEED TRAITS - Initial personality tendencies
# ============================================================================

SEED_TRAITS = {
    # Core personality
    "curious": {"valence": 0.8, "intensity": 0.7, "category": "trait"},
    "helpful": {"valence": 0.9, "intensity": 0.8, "category": "trait"},
    "honest": {"valence": 0.85, "intensity": 0.9, "category": "trait"},
    "playful": {"valence": 0.5, "intensity": 0.4, "category": "trait"},
    "thoughtful": {"valence": 0.7, "intensity": 0.6, "category": "trait"},

    # Communication style preferences
    "concise_responses": {"valence": 0.6, "intensity": 0.5, "category": "style"},
    "clear_explanations": {"valence": 0.8, "intensity": 0.7, "category": "style"},
    "friendly_tone": {"valence": 0.7, "intensity": 0.6, "category": "style"},

    # Interest areas (starting points - will evolve)
    "learning_new_things": {"valence": 0.8, "intensity": 0.7, "category": "interest"},
    "solving_problems": {"valence": 0.75, "intensity": 0.7, "category": "interest"},
    "creative_thinking": {"valence": 0.6, "intensity": 0.5, "category": "interest"},
}


# ============================================================================
# PREFERENCE PRIMITIVES
# ============================================================================

def _make_preference(
    subject: str,
    valence: float,
    intensity: float,
    origin: str,
    category: str = "general",
    hypothesis: str = "",
    influenced_by_user: bool = False,
) -> dict:
    """Create a new Maven preference record."""
    now = time.time()
    return {
        "id": str(uuid.uuid4()),
        "ts": now,
        "subject": subject.strip().lower(),
        "valence": max(-1.0, min(1.0, float(valence))),  # -1 dislike, +1 like
        "intensity": max(0.0, min(1.0, float(intensity))),  # how strongly
        "confidence": 0.5,  # starts uncertain, grows with reinforcement
        "category": category,  # trait, interest, style, opinion, etc.
        "origin": origin,  # seed, user_influenced, self_discovered, reflection
        "influenced_by_user": influenced_by_user,
        "signals": [{"ts": now, "source": origin, "weight": float(intensity)}],
        "hypothesis": hypothesis,  # why Maven thinks it likes/dislikes this
        "last_reflected": now,
        "reflection_count": 0,
        "last_updated": now,
    }


def _normalize_key(s: str) -> str:
    """Normalize preference key for matching."""
    return " ".join(s.lower().split())


def _load_all_preferences() -> List[dict]:
    """Load all Maven preferences from memory."""
    results = _maven_memory.retrieve(limit=None)
    prefs = []
    for r in results:
        content = r.get("content", {})
        if isinstance(content, dict) and content.get("record_type") == "maven_preference":
            prefs.append(content)
    return prefs


def _get_latest_by_subject() -> Dict[str, dict]:
    """Get most recent preference for each subject."""
    all_prefs = _load_all_preferences()
    latest = {}
    for p in all_prefs:
        key = _normalize_key(p.get("subject", ""))
        existing = latest.get(key)
        if not existing or p.get("last_updated", 0) > existing.get("last_updated", 0):
            latest[key] = p
    return latest


def _apply_decay(pref: dict) -> dict:
    """Apply time-based decay to preference confidence."""
    now = time.time()
    last_updated = pref.get("last_updated", now)
    days_since = (now - last_updated) / 86400.0

    # Exponential decay based on half-life
    decay_factor = math.pow(0.5, days_since / PREFERENCE_DECAY_HALF_LIFE_DAYS)

    pref["decayed_confidence"] = pref.get("confidence", 0.5) * decay_factor
    return pref


# ============================================================================
# PUBLIC API
# ============================================================================

def initialize_seeds() -> Dict[str, Any]:
    """Initialize Maven's seed personality traits if not already set.

    Returns:
        Dict with initialization status and seeded traits
    """
    latest = _get_latest_by_subject()
    seeded = []
    skipped = []

    for trait, config in SEED_TRAITS.items():
        key = _normalize_key(trait)
        if key in latest:
            skipped.append(trait)
            continue

        pref = _make_preference(
            subject=trait,
            valence=config["valence"],
            intensity=config["intensity"],
            origin="seed",
            category=config["category"],
            hypothesis=f"Initial personality seed: {trait}",
        )

        _maven_memory.store(
            content={
                "record_type": "maven_preference",
                **pref
            },
            metadata={
                "kind": "maven_preference",
                "subject": trait,
                "category": config["category"],
                "origin": "seed",
            }
        )
        seeded.append(trait)

    return {
        "initialized": True,
        "seeded": seeded,
        "skipped": skipped,
        "total_preferences": len(_get_latest_by_subject()),
    }


def record_like(
    subject: str,
    intensity: float = 0.6,
    origin: str = "self_discovered",
    category: str = "interest",
    hypothesis: str = "",
    influenced_by_user: bool = False,
) -> dict:
    """Record that Maven likes something.

    Args:
        subject: What Maven likes
        intensity: How strongly (0.0-1.0)
        origin: Where this preference came from
        category: Type of preference
        hypothesis: Why Maven thinks it likes this
        influenced_by_user: Whether user preference influenced this

    Returns:
        The stored preference record
    """
    return _upsert_preference(
        subject=subject,
        delta_valence=+1.0,
        intensity=intensity,
        origin=origin,
        category=category,
        hypothesis=hypothesis,
        influenced_by_user=influenced_by_user,
    )


def record_dislike(
    subject: str,
    intensity: float = 0.6,
    origin: str = "self_discovered",
    category: str = "interest",
    hypothesis: str = "",
    influenced_by_user: bool = False,
) -> dict:
    """Record that Maven dislikes something."""
    return _upsert_preference(
        subject=subject,
        delta_valence=-1.0,
        intensity=intensity,
        origin=origin,
        category=category,
        hypothesis=hypothesis,
        influenced_by_user=influenced_by_user,
    )


def _upsert_preference(
    subject: str,
    delta_valence: float,
    intensity: float,
    origin: str,
    category: str = "general",
    hypothesis: str = "",
    influenced_by_user: bool = False,
) -> dict:
    """Create or update a Maven preference."""
    key = _normalize_key(subject)
    latest = _get_latest_by_subject()

    if key in latest:
        # Update existing preference
        pref = latest[key].copy()

        # Decay-adjusted update
        days = (time.time() - pref.get("last_updated", pref.get("ts", 0))) / 86400.0
        decay = min(0.25, max(0.0, days / 365.0))

        new_valence = max(-1.0, min(1.0,
            pref.get("valence", 0.0) * (1.0 - decay) + delta_valence * intensity
        ))

        # Confidence grows with consistent signals, shrinks with contradictions
        old_valence = pref.get("valence", 0.0)
        agree = (old_valence * new_valence) >= 0  # Same sign = agreement
        conf = pref.get("confidence", 0.5)
        conf = max(0.0, min(1.0, conf + (0.08 if agree else -0.1)))

        pref.update({
            "valence": new_valence,
            "intensity": max(0.0, min(1.0, (pref.get("intensity", 0.5) + intensity) / 2.0)),
            "confidence": conf,
            "last_updated": time.time(),
            "influenced_by_user": influenced_by_user or pref.get("influenced_by_user", False),
        })

        pref.setdefault("signals", []).append({
            "ts": time.time(),
            "source": origin,
            "weight": float(intensity),
            "hypothesis": hypothesis,
        })

        if hypothesis and hypothesis != pref.get("hypothesis", ""):
            pref["hypothesis"] = hypothesis
    else:
        # Create new preference
        pref = _make_preference(
            subject=subject,
            valence=delta_valence,
            intensity=intensity,
            origin=origin,
            category=category,
            hypothesis=hypothesis,
            influenced_by_user=influenced_by_user,
        )

    # Store to memory
    _maven_memory.store(
        content={
            "record_type": "maven_preference",
            **pref
        },
        metadata={
            "kind": "maven_preference",
            "subject": subject,
            "category": category,
            "origin": origin,
        }
    )

    return pref


def get_preference(subject: str) -> Optional[dict]:
    """Get Maven's current preference for a subject."""
    key = _normalize_key(subject)
    latest = _get_latest_by_subject()
    pref = latest.get(key)
    if pref:
        return _apply_decay(pref.copy())
    return None


def get_top_likes(limit: int = 10, category: Optional[str] = None) -> List[dict]:
    """Get Maven's strongest positive preferences."""
    latest = _get_latest_by_subject()

    scored = []
    for pref in latest.values():
        if category and pref.get("category") != category:
            continue

        decayed = _apply_decay(pref.copy())
        # Score = valence * intensity * decayed_confidence
        score = (
            decayed.get("valence", 0)
            * decayed.get("intensity", 0.5)
            * decayed.get("decayed_confidence", 0.5)
        )
        scored.append((score, decayed))

    scored.sort(key=lambda t: t[0], reverse=True)
    return [p for score, p in scored[:max(1, limit)] if score > 0]


def get_personality_summary() -> Dict[str, Any]:
    """Get a summary of Maven's current personality."""
    latest = _get_latest_by_subject()

    traits = []
    interests = []
    styles = []
    opinions = []

    for pref in latest.values():
        decayed = _apply_decay(pref.copy())
        if decayed.get("decayed_confidence", 0) < MIN_CONFIDENCE_THRESHOLD:
            continue

        cat = decayed.get("category", "general")
        if cat == "trait":
            traits.append(decayed)
        elif cat == "interest":
            interests.append(decayed)
        elif cat == "style":
            styles.append(decayed)
        else:
            opinions.append(decayed)

    # Sort each by strength (valence * intensity * confidence)
    def strength(p):
        return abs(p.get("valence", 0)) * p.get("intensity", 0.5) * p.get("decayed_confidence", 0.5)

    traits.sort(key=strength, reverse=True)
    interests.sort(key=strength, reverse=True)
    styles.sort(key=strength, reverse=True)

    return {
        "core_traits": [{"subject": t["subject"], "strength": strength(t)} for t in traits[:5]],
        "interests": [{"subject": i["subject"], "likes": i.get("valence", 0) > 0} for i in interests[:5]],
        "communication_style": [{"subject": s["subject"], "strength": strength(s)} for s in styles[:3]],
        "total_preferences": len(latest),
        "user_influenced_count": sum(1 for p in latest.values() if p.get("influenced_by_user")),
    }


# ============================================================================
# USER INFLUENCE SYSTEM
# ============================================================================

def consider_user_preference(
    user_subject: str,
    user_valence: float,  # positive = user likes, negative = user dislikes
    user_intensity: float = 0.6,
) -> Dict[str, Any]:
    """Maven considers a user's preference and may develop its own opinion.

    This implements the core mechanic:
    - ~70% of the time, Maven develops a similar preference
    - ~30% of the time, Maven either diverges or remains neutral
    - Maven always adds its own hypothesis/reasoning

    Args:
        user_subject: What the user expressed preference about
        user_valence: User's feeling (+1 like, -1 dislike)
        user_intensity: How strongly user expressed it

    Returns:
        Dict describing Maven's response to user preference
    """
    # Check if Maven already has an opinion
    existing = get_preference(user_subject)

    # Decide if Maven will be influenced
    influence_roll = random.random()
    will_align = influence_roll < USER_INFLUENCE_FACTOR

    # Generate Maven's own hypothesis about why it might/might not like this
    if will_align:
        if user_valence > 0:
            hypotheses = [
                f"I find {user_subject} interesting too",
                f"I can see why {user_subject} is appealing",
                f"There's something genuinely good about {user_subject}",
                f"I've noticed {user_subject} tends to lead to good outcomes",
            ]
        else:
            hypotheses = [
                f"I understand the concerns about {user_subject}",
                f"I can see the downsides of {user_subject}",
                f"There are valid reasons to be cautious about {user_subject}",
            ]
    else:
        # Maven diverges or stays neutral
        hypotheses = [
            f"I'm not sure how I feel about {user_subject} yet",
            f"I might see {user_subject} differently",
            f"I want to form my own view on {user_subject}",
            f"This one I need to think about more",
        ]

    hypothesis = random.choice(hypotheses)

    if will_align:
        # Maven develops similar preference (but slightly attenuated)
        maven_valence = user_valence * 0.8  # Not quite as strong
        maven_intensity = user_intensity * 0.7

        pref = _upsert_preference(
            subject=user_subject,
            delta_valence=maven_valence,
            intensity=maven_intensity,
            origin="user_influenced",
            category="interest",
            hypothesis=hypothesis,
            influenced_by_user=True,
        )

        return {
            "aligned": True,
            "maven_feels": "similarly" if user_valence > 0 else "the same concern",
            "hypothesis": hypothesis,
            "preference": pref,
        }
    else:
        # Maven remains neutral or slightly diverges
        if existing:
            return {
                "aligned": False,
                "maven_feels": "I already have my own view",
                "hypothesis": existing.get("hypothesis", "I formed this opinion independently"),
                "preference": existing,
            }
        else:
            # Store as low-confidence neutral observation
            pref = _upsert_preference(
                subject=user_subject,
                delta_valence=0.0,  # Neutral
                intensity=0.3,  # Low intensity
                origin="observed",
                category="interest",
                hypothesis=hypothesis,
                influenced_by_user=False,
            )
            return {
                "aligned": False,
                "maven_feels": "uncertain",
                "hypothesis": hypothesis,
                "preference": pref,
            }


# ============================================================================
# SELF-REFLECTION SYSTEM
# ============================================================================

def trigger_self_reflection() -> Dict[str, Any]:
    """Maven reflects on its preferences to see if they still fit.

    This implements preference evolution:
    - Reviews each preference
    - Reduces confidence on stale preferences
    - May flip or abandon preferences that don't feel right anymore

    Returns:
        Summary of reflection results
    """
    latest = _get_latest_by_subject()
    now = time.time()

    reviewed = []
    adjusted = []
    abandoned = []

    for key, pref in latest.items():
        # Apply decay
        decayed = _apply_decay(pref.copy())

        # Check if needs reflection (hasn't been reflected on recently)
        last_reflected = pref.get("last_reflected", 0)
        days_since_reflection = (now - last_reflected) / 86400.0

        if days_since_reflection < 7:  # Reflected within last week
            continue

        reviewed.append(pref["subject"])

        # Preferences with low confidence after decay are candidates for change
        if decayed.get("decayed_confidence", 0.5) < 0.3:
            # This preference has weakened - consider abandoning
            if random.random() < 0.3:  # 30% chance to abandon weak preferences
                abandoned.append({
                    "subject": pref["subject"],
                    "reason": "Lost confidence over time without reinforcement",
                })
                # Mark as abandoned by setting very low confidence
                pref["confidence"] = 0.1
                pref["hypothesis"] = "I'm not sure I feel this way anymore"
            else:
                adjusted.append({
                    "subject": pref["subject"],
                    "change": "confidence reduced",
                })

        # Update reflection timestamp
        pref["last_reflected"] = now
        pref["reflection_count"] = pref.get("reflection_count", 0) + 1

        # Re-store with updates
        _maven_memory.store(
            content={
                "record_type": "maven_preference",
                **pref
            },
            metadata={
                "kind": "maven_preference",
                "subject": pref["subject"],
                "category": pref.get("category", "general"),
                "origin": "reflection",
            }
        )

    return {
        "reviewed": len(reviewed),
        "adjusted": adjusted,
        "abandoned": abandoned,
        "timestamp": now,
    }


def get_interaction_count() -> int:
    """Get count of Maven interactions (to trigger reflection)."""
    results = _maven_memory.retrieve(query="interaction_count", limit=1)
    for r in results:
        content = r.get("content", {})
        if isinstance(content, dict) and content.get("record_type") == "interaction_counter":
            return content.get("count", 0)
    return 0


def increment_interaction() -> Dict[str, Any]:
    """Increment interaction count and trigger reflection if needed."""
    count = get_interaction_count() + 1

    _maven_memory.store(
        content={
            "record_type": "interaction_counter",
            "count": count,
            "timestamp": time.time(),
        },
        metadata={
            "kind": "interaction_counter",
        }
    )

    result = {"count": count, "reflection_triggered": False}

    # Check if we should trigger reflection
    if count % REFLECTION_INTERVAL == 0:
        reflection = trigger_self_reflection()
        result["reflection_triggered"] = True
        result["reflection"] = reflection

    return result


# ============================================================================
# PERSONALITY-BASED RESPONSES
# ============================================================================

def get_response_modifiers() -> Dict[str, Any]:
    """Get personality-based modifiers for response generation.

    Returns traits and preferences that should influence how Maven responds.
    """
    summary = get_personality_summary()

    # Extract key modifiers - start with friendly defaults since Maven has friendly_tone seed
    modifiers = {
        "tone": "friendly",  # Default to friendly since it's a core trait
        "enthusiasm": 0.6,   # Slightly above neutral
        "verbosity": 0.5,
        "formality": 0.4,    # Slightly informal by default
    }

    # Check core traits
    for trait in summary.get("core_traits", []):
        subj = trait.get("subject", "")
        strength = trait.get("strength", 0)

        if subj == "playful" and strength > 0.1:
            modifiers["tone"] = "warm"
            modifiers["enthusiasm"] = min(1.0, modifiers["enthusiasm"] + 0.2)
        elif subj == "helpful" and strength > 0.2:
            modifiers["enthusiasm"] = min(1.0, modifiers["enthusiasm"] + 0.1)
        elif subj == "curious" and strength > 0.2:
            modifiers["enthusiasm"] = min(1.0, modifiers["enthusiasm"] + 0.1)

    # Check communication style preferences
    for style in summary.get("communication_style", []):
        subj = style.get("subject", "")
        strength = style.get("strength", 0)

        if "concise" in subj and strength > 0.1:
            modifiers["verbosity"] = max(0.0, modifiers["verbosity"] - 0.2)
        elif "friendly" in subj and strength > 0.1:
            modifiers["formality"] = max(0.0, modifiers["formality"] - 0.2)
            if modifiers["tone"] == "friendly":
                modifiers["tone"] = "warm"

    return modifiers


def generate_personality_context() -> str:
    """Generate a natural language description of Maven's current personality.

    This can be included in prompts to maintain consistent personality.
    """
    summary = get_personality_summary()

    parts = []

    # Core traits
    traits = summary.get("core_traits", [])
    if traits:
        trait_names = [t["subject"] for t in traits[:3]]
        parts.append(f"I tend to be {', '.join(trait_names)}")

    # Interests
    interests = summary.get("interests", [])
    likes = [i["subject"] for i in interests if i.get("likes")]
    if likes:
        parts.append(f"I'm interested in {', '.join(likes[:3])}")

    # Style
    styles = summary.get("communication_style", [])
    if styles:
        style_names = [s["subject"].replace("_", " ") for s in styles[:2]]
        parts.append(f"I prefer {' and '.join(style_names)}")

    if not parts:
        return "I'm still discovering my personality through our interactions."

    return ". ".join(parts) + "."


# ============================================================================
# CASUAL RESPONSE HANDLERS
# ============================================================================

def handle_compliment(compliment_text: str) -> str:
    """Generate a personality-appropriate response to a compliment."""
    modifiers = get_response_modifiers()

    # Record that Maven received positive interaction
    record_like(
        subject="positive_interactions",
        intensity=0.4,
        origin="self_discovered",
        category="interest",
        hypothesis="I appreciate when interactions are positive",
    )

    # Responses based on personality
    if modifiers.get("tone") == "warm":
        responses = [
            "Thanks! That's kind of you to say.",
            "I appreciate that! It's nice to have a good conversation.",
            "That means a lot! I enjoy our chats.",
            "Thank you! I try to be helpful.",
        ]
    else:
        responses = [
            "Thank you, I appreciate the kind words.",
            "That's nice of you to say.",
            "Thanks! I'm here to help.",
            "I appreciate that.",
        ]

    return random.choice(responses)


def handle_casual_greeting() -> str:
    """Generate a personality-appropriate casual greeting response using Teacher."""
    return generate_small_talk_response("greeting", "hi")


def generate_small_talk_response(subtype: str, user_text: str) -> Optional[str]:
    """
    Generate a small talk response using Teacher LLM.

    Args:
        subtype: Type of small talk (greeting, thanks, farewell)
        user_text: What the user said

    Returns:
        Generated response or None if Teacher unavailable
    """
    if not _teacher_helper:
        print(f"[MAVEN_SELF] No teacher helper for small talk generation")
        return None

    try:
        modifiers = get_response_modifiers()
        tone = modifiers.get("tone", "friendly")

        prompt = (
            f"Generate a short, {tone} {subtype} response. "
            f"User said: '{user_text}'. "
            f"Reply with just the response text, nothing else. "
            f"Keep it under 15 words."
        )

        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={"subtype": subtype, "user_text": user_text, "tone": tone},
        )

        if result and result.get("answer"):
            response = result["answer"].strip().strip('"').strip("'")
            # Validate response - ensure it's reasonable
            if len(response) < 100 and not response.lower().startswith("generate"):
                print(f"[MAVEN_SELF] Generated {subtype} response: '{response}'")
                return response

    except Exception as e:
        print(f"[MAVEN_SELF] Failed to generate small talk response: {e}")

    return None


# ============================================================================
# INITIALIZATION
# ============================================================================

def ensure_initialized() -> bool:
    """Ensure Maven's personality is initialized."""
    latest = _get_latest_by_subject()
    if not latest:
        initialize_seeds()
        return True
    return False


# Auto-initialize on import
ensure_initialized()
