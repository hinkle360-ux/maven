"""
Memory Persistence Logger
=========================

This module provides logging instrumentation for Maven's memory persistence layer.
It helps diagnose issues where facts are extracted correctly but not persisted to disk.

USAGE:
    from brains.memory.persistence_logger import log_memory_write, log_memory_read
    
    # Log when storing a fact
    log_memory_write("user_occupation", "data scientist", "/path/to/file.json")
    
    # Log when retrieving a fact  
    log_memory_read("user_occupation", found=True, value="data scientist")
"""

import json
import os
from datetime import datetime
from typing import Any, Optional

# Log file location
LOG_DIR = "reports/memory_debug"
LOG_FILE = os.path.join(LOG_DIR, "persistence_log.jsonl")

def ensure_log_dir():
    """Ensure the log directory exists."""
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
    except Exception:
        pass

def log_memory_write(key: str, value: Any, destination: str, success: bool = True):
    """
    Log a memory write operation.
    
    Args:
        key: The memory key being written (e.g., "user_name", "user_occupation")
        value: The value being stored
        destination: Where it's being stored (file path, DB table, etc.)
        success: Whether the write succeeded
    """
    try:
        ensure_log_dir()
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "operation": "WRITE",
            "key": key,
            "value": str(value)[:200],  # Truncate long values
            "destination": destination,
            "success": success
        }
        
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry) + "\n")
            
        # Also print to console for immediate visibility
        status = "✓" if success else "✗"
        print(f"[MEMORY_WRITE {status}] {key} -> {destination}")
        
    except Exception as e:
        # Never let logging break the system
        print(f"[MEMORY_WRITE_LOG_ERROR] {e}")

def log_memory_read(key: str, found: bool, value: Optional[Any] = None, source: Optional[str] = None):
    """
    Log a memory read operation.
    
    Args:
        key: The memory key being read
        found: Whether the key was found
        value: The value retrieved (if found)
        source: Where it was retrieved from
    """
    try:
        ensure_log_dir()
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "operation": "READ",
            "key": key,
            "found": found,
            "value": str(value)[:200] if value else None,
            "source": source
        }
        
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry) + "\n")
            
        # Also print to console
        status = "✓" if found else "✗"
        print(f"[MEMORY_READ {status}] {key} from {source or 'unknown'}")
        
    except Exception as e:
        print(f"[MEMORY_READ_LOG_ERROR] {e}")

def log_memory_commit(store_name: str, num_records: int, success: bool = True):
    """
    Log a memory commit/flush operation.
    
    Args:
        store_name: Name of the memory store being committed
        num_records: Number of records being committed
        success: Whether the commit succeeded
    """
    try:
        ensure_log_dir()
        
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "operation": "COMMIT",
            "store": store_name,
            "num_records": num_records,
            "success": success
        }
        
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry) + "\n")
            
        status = "✓" if success else "✗"
        print(f"[MEMORY_COMMIT {status}] {store_name}: {num_records} records")
        
    except Exception as e:
        print(f"[MEMORY_COMMIT_LOG_ERROR] {e}")

def get_recent_logs(n: int = 50) -> list:
    """
    Retrieve the N most recent log entries.
    
    Args:
        n: Number of recent entries to retrieve
        
    Returns:
        List of log entry dicts
    """
    try:
        if not os.path.exists(LOG_FILE):
            return []
            
        logs = []
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    logs.append(json.loads(line.strip()))
                except Exception:
                    continue
        
        return logs[-n:]
    except Exception:
        return []
