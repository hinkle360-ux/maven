"""
task_scheduler.py
=================

This module implements a very lightweight task scheduler for Maven.
It allows tasks (functions with arguments) to be registered and
executed at a later time.  The scheduler maintains a simple in-memory
queue of pending tasks.  It is intended as a placeholder for a more
sophisticated background execution engine.  Future enhancements could
include persistent storage, cron-like scheduling, concurrency and
retry policies.

Usage example:

    from brains.autonomy.task_scheduler import schedule_task, run_pending_tasks

    def greet(name):
        print(f"Hello {name}!")

    # Schedule a greeting for later
    schedule_task(greet, args=("Maven",))

    # At some point in the main loop, run all pending tasks
    run_pending_tasks()

The scheduler does not currently integrate with the Maven pipeline.
Integration points could include invoking `run_pending_tasks()` at the
beginning or end of each pipeline execution, or having an external
timer trigger task execution.
"""

from __future__ import annotations

from typing import Callable, Any, List, Tuple, Dict

# Internal queue of scheduled tasks.  Each item is a tuple of
# (callable, args, kwargs).  In the future this could be replaced
# with a persistent task store on disk.
_task_queue: List[Tuple[Callable[..., Any], Tuple[Any, ...], Dict[str, Any]]] = []

def schedule_task(func: Callable[..., Any], args: Tuple[Any, ...] = (), kwargs: Dict[str, Any] | None = None) -> None:
    """Schedule a callable to be executed later.

    Args:
        func: The function or callable to execute.
        args: Positional arguments to pass to the function.
        kwargs: Keyword arguments to pass to the function.

    Returns:
        None.  The task is appended to the internal queue.
    """
    global _task_queue
    if kwargs is None:
        kwargs = {}
    _task_queue.append((func, args, kwargs))


def run_pending_tasks() -> None:
    """Run all pending tasks in the queue.

    Tasks are executed in FIFO order.  Exceptions are caught and
    printed to prevent a single failing task from stopping the
    scheduler.  After all tasks have been run, the queue is cleared.
    """
    global _task_queue
    while _task_queue:
        func, args, kwargs = _task_queue.pop(0)
        try:
            func(*args, **kwargs)
        except Exception as e:
            print(f"[TASK_SCHEDULER] Error executing task {func.__name__}: {e}")
