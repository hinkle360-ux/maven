"""Routing optimization utilities."""
