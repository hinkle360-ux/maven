# brains/routing/router_introspection.py
"""
Router Introspection - Scan-First System Awareness
===================================================

Provides the Router Brain with introspection capabilities to scan
and understand the current system state before making routing decisions.

Key Functions:
- introspect_system(): Pull current brain/tool lists from registries
- update_self_model(): Maintain a structured self-model on the blackboard
- check_freshness(): Determine if the cached self-model is stale

This ensures Maven's self-knowledge comes from live introspection,
not hardcoded values.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, Optional, List, Set
from dataclasses import dataclass, field
from datetime import datetime
import hashlib


# =============================================================================
# Self-Model Data Structure
# =============================================================================

@dataclass
class SystemSnapshot:
    """
    A snapshot of Maven's current system state.

    This is what the Router uses for routing decisions and what
    Memory/EVA use for self-description.
    """
    # Counts
    total_brains: int = 0
    total_tools: int = 0
    total_helpers: int = 0
    total_teachers: int = 0

    # Categories
    brain_categories: Dict[str, List[str]] = field(default_factory=dict)
    tool_categories: Dict[str, List[str]] = field(default_factory=dict)

    # Core subsystems
    has_blackboard: bool = True
    has_teacher_student: bool = True
    has_persistent_memory: bool = True

    # Enabled components
    enabled_brains: List[str] = field(default_factory=list)
    enabled_tools: List[str] = field(default_factory=list)

    # Capabilities
    all_capabilities: Set[str] = field(default_factory=set)
    web_enabled: bool = False
    browser_enabled: bool = False

    # Metadata
    timestamp: datetime = field(default_factory=datetime.now)
    hash: str = ""

    def compute_hash(self) -> str:
        """Compute a hash of the snapshot for staleness detection."""
        content = (
            f"{self.total_brains}:{self.total_tools}:"
            f"{sorted(self.enabled_brains)}:{sorted(self.enabled_tools)}"
        )
        return hashlib.md5(content.encode()).hexdigest()[:8]

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return {
            "total_brains": self.total_brains,
            "total_tools": self.total_tools,
            "total_helpers": self.total_helpers,
            "total_teachers": self.total_teachers,
            "brain_categories": self.brain_categories,
            "tool_categories": self.tool_categories,
            "has_blackboard": self.has_blackboard,
            "has_teacher_student": self.has_teacher_student,
            "has_persistent_memory": self.has_persistent_memory,
            "enabled_brains": self.enabled_brains,
            "enabled_tools": self.enabled_tools,
            "all_capabilities": list(self.all_capabilities),
            "web_enabled": self.web_enabled,
            "browser_enabled": self.browser_enabled,
            "timestamp": self.timestamp.isoformat(),
            "hash": self.hash,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SystemSnapshot":
        """Create from dictionary."""
        snapshot = cls(
            total_brains=data.get("total_brains", 0),
            total_tools=data.get("total_tools", 0),
            total_helpers=data.get("total_helpers", 0),
            total_teachers=data.get("total_teachers", 0),
            brain_categories=data.get("brain_categories", {}),
            tool_categories=data.get("tool_categories", {}),
            has_blackboard=data.get("has_blackboard", True),
            has_teacher_student=data.get("has_teacher_student", True),
            has_persistent_memory=data.get("has_persistent_memory", True),
            enabled_brains=data.get("enabled_brains", []),
            enabled_tools=data.get("enabled_tools", []),
            all_capabilities=set(data.get("all_capabilities", [])),
            web_enabled=data.get("web_enabled", False),
            browser_enabled=data.get("browser_enabled", False),
            hash=data.get("hash", ""),
        )
        if data.get("timestamp"):
            try:
                snapshot.timestamp = datetime.fromisoformat(data["timestamp"])
            except (ValueError, TypeError):
                pass
        return snapshot


@dataclass
class SelfModel:
    """
    Maven's structured self-knowledge derived from live introspection.

    This is maintained on the blackboard and used by:
    - Router for routing decisions
    - Memory for self-knowledge queries
    - EVA for self-description formatting
    """
    # Current snapshot
    snapshot: SystemSnapshot

    # Routing policies (can be updated by learning)
    router_policies: Dict[str, Any] = field(default_factory=dict)

    # Length policies (can be updated by learning)
    length_policies: Dict[str, Any] = field(default_factory=dict)

    # Metadata
    last_updated: datetime = field(default_factory=datetime.now)
    update_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return {
            "snapshot": self.snapshot.to_dict(),
            "router_policies": self.router_policies,
            "length_policies": self.length_policies,
            "last_updated": self.last_updated.isoformat(),
            "update_count": self.update_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SelfModel":
        """Create from dictionary."""
        snapshot = SystemSnapshot.from_dict(data.get("snapshot", {}))
        model = cls(
            snapshot=snapshot,
            router_policies=data.get("router_policies", {}),
            length_policies=data.get("length_policies", {}),
            update_count=data.get("update_count", 0),
        )
        if data.get("last_updated"):
            try:
                model.last_updated = datetime.fromisoformat(data["last_updated"])
            except (ValueError, TypeError):
                pass
        return model

    def is_stale(self, max_age_seconds: float = 60.0) -> bool:
        """Check if the self-model is stale and needs refresh."""
        age = (datetime.now() - self.last_updated).total_seconds()
        return age > max_age_seconds


# =============================================================================
# Introspection Functions
# =============================================================================

def introspect_system() -> SystemSnapshot:
    """
    Pull current brain/tool lists from registries.

    This is the main scan-first function that the Router calls
    at the start of each request (if needed).

    Returns:
        SystemSnapshot with current system state
    """
    snapshot = SystemSnapshot()

    # Try to get data from SystemRegistry
    try:
        from brains.utils.system_registry import get_system_registry, ComponentKind
        registry = get_system_registry()

        brains = registry.get_enabled(ComponentKind.BRAIN)
        tools = registry.get_enabled(ComponentKind.TOOL)
        helpers = registry.get_enabled(ComponentKind.HELPER)
        teachers = registry.get_enabled(ComponentKind.TEACHER)

        snapshot.total_brains = len(brains)
        snapshot.total_tools = len(tools)
        snapshot.total_helpers = len(helpers)
        snapshot.total_teachers = len(teachers)

        snapshot.enabled_brains = [b.id for b in brains]
        snapshot.enabled_tools = [t.id for t in tools]

        # Collect capabilities
        for component in brains + tools + helpers + teachers:
            snapshot.all_capabilities.update(component.capabilities)

        # Categorize brains
        snapshot.brain_categories = _categorize_brains(brains)

        # Categorize tools
        snapshot.tool_categories = _categorize_tools(tools)

        # Check for web/browser capabilities
        snapshot.web_enabled = any(
            "web" in cap.lower()
            for cap in snapshot.all_capabilities
        )
        snapshot.browser_enabled = any(
            "browser" in cap.lower() or "chatgpt" in cap.lower() or "grok" in cap.lower()
            for cap in snapshot.all_capabilities
        )

    except ImportError:
        # Registry not available, try scanner
        pass

    # Fallback: try system scanner
    if snapshot.total_brains == 0:
        try:
            from brains.utils.system_scanner import get_system_scanner, ComponentType
            scanner = get_system_scanner()
            scanner.scan_all()
            summary = scanner.get_system_summary()

            by_type = summary.get("by_type", {})
            snapshot.total_brains = (
                by_type.get("cognitive_brain", {}).get("count", 0) +
                by_type.get("routing_brain", {}).get("count", 0)
            )
            snapshot.total_tools = by_type.get("tool", {}).get("count", 0)

            # Get brain names
            for comp_type in ["cognitive_brain", "routing_brain"]:
                if comp_type in by_type:
                    for comp in by_type[comp_type].get("components", []):
                        snapshot.enabled_brains.append(comp.get("name", ""))

            # Get tool names
            if "tool" in by_type:
                for comp in by_type["tool"].get("components", []):
                    snapshot.enabled_tools.append(comp.get("name", ""))

        except ImportError:
            pass

    # Compute hash for staleness detection
    snapshot.hash = snapshot.compute_hash()
    snapshot.timestamp = datetime.now()

    return snapshot


def _categorize_brains(brains) -> Dict[str, List[str]]:
    """Categorize brains by their primary role."""
    categories = {
        "routing": [],
        "memory": [],
        "learning": [],
        "reasoning": [],
        "synthesis": [],
        "planning": [],
        "self": [],
        "other": [],
    }

    for brain in brains:
        name = brain.id.lower()
        caps = {c.lower() for c in brain.capabilities}

        if "routing" in name or "routing" in caps:
            categories["routing"].append(brain.id)
        elif "memory" in name or "memory" in caps:
            categories["memory"].append(brain.id)
        elif "learn" in name or "learning" in caps or "teacher" in name:
            categories["learning"].append(brain.id)
        elif "reason" in name or "reasoning" in caps:
            categories["reasoning"].append(brain.id)
        elif "synth" in name or "respond" in name or "voice" in name:
            categories["synthesis"].append(brain.id)
        elif "plan" in name or "planning" in caps:
            categories["planning"].append(brain.id)
        elif "self" in name or "introsp" in name:
            categories["self"].append(brain.id)
        else:
            categories["other"].append(brain.id)

    return {k: v for k, v in categories.items() if v}


def _categorize_tools(tools) -> Dict[str, List[str]]:
    """Categorize tools by their primary function."""
    categories = {
        "browser": [],
        "web_search": [],
        "file": [],
        "system": [],
        "git": [],
        "other": [],
    }

    for tool in tools:
        name = tool.id.lower()
        caps = {c.lower() for c in tool.capabilities}

        if any(x in name for x in ["browser", "chatgpt", "claude", "grok", "x_"]):
            categories["browser"].append(tool.id)
        elif "web" in name or "search" in name:
            categories["web_search"].append(tool.id)
        elif "file" in name or "filesystem" in name:
            categories["file"].append(tool.id)
        elif "shell" in name or "system" in name or "pc" in name:
            categories["system"].append(tool.id)
        elif "git" in name:
            categories["git"].append(tool.id)
        else:
            categories["other"].append(tool.id)

    return {k: v for k, v in categories.items() if v}


# =============================================================================
# Self-Model Management
# =============================================================================

# Module-level cache
_cached_self_model: Optional[SelfModel] = None


def get_self_model(force_refresh: bool = False) -> SelfModel:
    """
    Get the current self-model, refreshing if stale.

    Args:
        force_refresh: Force a refresh even if not stale

    Returns:
        Current SelfModel
    """
    global _cached_self_model

    if _cached_self_model is None or force_refresh or _cached_self_model.is_stale():
        snapshot = introspect_system()
        if _cached_self_model is None:
            _cached_self_model = SelfModel(snapshot=snapshot)
        else:
            _cached_self_model.snapshot = snapshot
            _cached_self_model.last_updated = datetime.now()
            _cached_self_model.update_count += 1

    return _cached_self_model


def update_self_model(snapshot: SystemSnapshot) -> SelfModel:
    """
    Update the cached self-model with a new snapshot.

    Args:
        snapshot: New system snapshot

    Returns:
        Updated SelfModel
    """
    global _cached_self_model

    if _cached_self_model is None:
        _cached_self_model = SelfModel(snapshot=snapshot)
    else:
        _cached_self_model.snapshot = snapshot
        _cached_self_model.last_updated = datetime.now()
        _cached_self_model.update_count += 1

    return _cached_self_model


def check_freshness(max_age_seconds: float = 60.0) -> bool:
    """
    Check if the cached self-model is fresh.

    Args:
        max_age_seconds: Maximum age in seconds

    Returns:
        True if fresh, False if stale or missing
    """
    global _cached_self_model

    if _cached_self_model is None:
        return False

    return not _cached_self_model.is_stale(max_age_seconds)


def reset_cache() -> None:
    """Reset the cached self-model (for testing)."""
    global _cached_self_model
    _cached_self_model = None


# =============================================================================
# Blackboard Integration
# =============================================================================

def store_self_model_on_blackboard(blackboard, self_model: SelfModel) -> None:
    """
    Store the self-model on the blackboard's planning lane.

    Args:
        blackboard: Blackboard instance
        self_model: The self-model to store
    """
    blackboard.add_planning_decision(
        owner="router_introspection",
        decision_type="self_model",
        decision=self_model.to_dict(),
        reason="System introspection scan",
    )


def get_self_model_from_blackboard(blackboard) -> Optional[SelfModel]:
    """
    Retrieve the self-model from the blackboard.

    Args:
        blackboard: Blackboard instance

    Returns:
        SelfModel if found, None otherwise
    """
    entries = blackboard.get_entries(
        lane="planning",
        owner="router_introspection",
    )

    for entry in reversed(entries):  # Most recent first
        if isinstance(entry.payload, dict):
            decision = entry.payload.get("decision")
            if decision and "snapshot" in decision:
                return SelfModel.from_dict(decision)

    return None


# =============================================================================
# Convenience Functions for Router
# =============================================================================

def scan_first_if_needed(blackboard, max_age_seconds: float = 60.0) -> SelfModel:
    """
    The main scan-first entry point for the Router.

    Checks if the self-model is fresh, and if not, performs introspection.

    Args:
        blackboard: Blackboard instance
        max_age_seconds: Maximum age before refresh

    Returns:
        Fresh SelfModel
    """
    # Check blackboard first
    bb_model = get_self_model_from_blackboard(blackboard)
    if bb_model and not bb_model.is_stale(max_age_seconds):
        return bb_model

    # Check cache
    if check_freshness(max_age_seconds):
        return get_self_model()

    # Need to refresh
    self_model = get_self_model(force_refresh=True)

    # Store on blackboard
    store_self_model_on_blackboard(blackboard, self_model)

    return self_model


def get_brain_count() -> int:
    """Quick helper to get current brain count."""
    model = get_self_model()
    return model.snapshot.total_brains


def get_tool_count() -> int:
    """Quick helper to get current tool count."""
    model = get_self_model()
    return model.snapshot.total_tools


def get_summary_text() -> str:
    """
    Get a brief text summary of the current system state.

    Suitable for self-description responses.
    """
    model = get_self_model()
    s = model.snapshot

    return (
        f"I currently have {s.total_brains} cognitive brains and {s.total_tools} tools. "
        f"My brains handle routing, memory, learning, and response synthesis. "
        f"My tools include browser automation, web search, file operations, and system control."
    )


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "SystemSnapshot",
    "SelfModel",
    "introspect_system",
    "get_self_model",
    "update_self_model",
    "check_freshness",
    "reset_cache",
    "store_self_model_on_blackboard",
    "get_self_model_from_blackboard",
    "scan_first_if_needed",
    "get_brain_count",
    "get_tool_count",
    "get_summary_text",
]
