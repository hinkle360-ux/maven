# brains/routing/length_depth_planner.py
"""
Length & Depth Planner - Response Depth Decisions
==================================================

A utility function (not a new brain) that decides how deep each answer
should go based on:
- Question count (more questions = shorter per answer)
- Complexity of each question
- User style (casual vs technical)
- Context (deep architecture discussion = allow more depth)

Outputs per-question guidance for EVA to use during synthesis.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
import re
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from enum import Enum

from brains.routing.question_parser import QuestionBatch, ParsedQuestion, QuestionTopic


class DepthLevel(str, Enum):
    """How deep the answer should go."""
    SHORT = "short"      # 1-2 sentences, direct answer
    MEDIUM = "medium"    # 3-5 sentences, some explanation
    DEEP = "deep"        # Full explanation with examples


class DetailPreference(str, Enum):
    """What kind of detail to include."""
    HIGH_LEVEL = "high_level"        # Overview, concepts only
    ARCHITECTURAL = "architectural"   # System structure details
    STEPWISE = "stepwise"            # Step-by-step explanation


class ExamplePolicy(str, Enum):
    """Whether to include examples."""
    NONE = "none"             # No examples
    BRIEF = "brief"           # One-liner example
    DETAILED = "detailed"     # Full worked example


@dataclass
class DepthGuidance:
    """
    Guidance for how to answer a specific question.

    This is what EVA uses when synthesizing each answer.
    """
    question_id: str
    depth: DepthLevel
    detail_preference: DetailPreference
    example_policy: ExamplePolicy
    max_sentences: int
    max_bullets: int
    allow_subheadings: bool
    emphasis_words: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return {
            "question_id": self.question_id,
            "depth": self.depth.value,
            "detail_preference": self.detail_preference.value,
            "example_policy": self.example_policy.value,
            "max_sentences": self.max_sentences,
            "max_bullets": self.max_bullets,
            "allow_subheadings": self.allow_subheadings,
            "emphasis_words": self.emphasis_words,
        }


@dataclass
class BatchDepthPlan:
    """
    Complete depth plan for a question batch.

    Contains guidance for each question plus overall constraints.
    """
    per_question: Dict[str, DepthGuidance]
    total_max_length: int  # Total characters across all answers
    overall_style: str  # "conversational", "technical", "formal"
    add_closing: bool  # Whether to add Maven's closing reflection

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return {
            "per_question": {
                qid: g.to_dict() for qid, g in self.per_question.items()
            },
            "total_max_length": self.total_max_length,
            "overall_style": self.overall_style,
            "add_closing": self.add_closing,
        }

    def get_guidance(self, question_id: str) -> Optional[DepthGuidance]:
        """Get guidance for a specific question."""
        return self.per_question.get(question_id)


# =============================================================================
# Complexity Analysis
# =============================================================================

# Words that indicate complex/deep questions
COMPLEXITY_MARKERS = {
    "how": 1,
    "why": 2,
    "compare": 2,
    "contrast": 2,
    "architecture": 2,
    "internally": 1,
    "coordination": 2,
    "communicate": 1,
    "interact": 1,
    "learning": 1,
    "pattern": 1,
    "flow": 1,
    "sync": 1,
    "async": 1,
    "parallel": 1,
    "sequential": 1,
    "mechanism": 2,
    "explain": 1,
    "describe": 1,
    "detailed": 2,
    "comprehensive": 2,
}

# Words that indicate simple/direct questions
SIMPLICITY_MARKERS = {
    "what": 0,
    "can": 0,
    "do": 0,
    "is": 0,
    "are": 0,
    "list": 0,
    "name": 0,
    "count": 0,
    "number": 0,
}


def compute_complexity_score(text: str) -> int:
    """
    Compute a complexity score for a question.

    Higher scores indicate more complex questions that need deeper answers.

    Args:
        text: Question text

    Returns:
        Complexity score (0-10)
    """
    score = 0
    text_lower = text.lower()

    # Count complexity markers
    for word, weight in COMPLEXITY_MARKERS.items():
        if word in text_lower:
            score += weight

    # Reduce for simplicity markers (but don't go negative)
    for word, weight in SIMPLICITY_MARKERS.items():
        if word in text_lower:
            score = max(0, score - 1)

    # Long questions tend to be more complex
    word_count = len(text.split())
    if word_count > 20:
        score += 1
    if word_count > 40:
        score += 1

    # Cap at 10
    return min(10, score)


def detect_user_style(text: str) -> str:
    """
    Detect the user's communication style.

    Args:
        text: Full user message

    Returns:
        Style: "casual", "technical", or "formal"
    """
    text_lower = text.lower()

    # Technical indicators
    technical_words = [
        "architecture", "implementation", "coordinate", "synchronize",
        "async", "sync", "parallel", "sequential", "mechanism",
        "blackboard", "routing", "pipeline", "module", "component",
    ]
    technical_count = sum(1 for w in technical_words if w in text_lower)

    # Casual indicators
    casual_patterns = [
        r"\bhey\b", r"\bhi\b", r"\byo\b", r"\bthanks\b", r"\bplease\b",
        r"\bcan you\b", r"\bjust\b", r"\bquick\b",
    ]
    casual_count = sum(1 for p in casual_patterns if re.search(p, text_lower))

    # Formal indicators
    formal_patterns = [
        r"\bplease\b.*\bexplain\b", r"\bkindly\b", r"\bwould you\b",
        r"\bcould you\b.*\bdescribe\b",
    ]
    formal_count = sum(1 for p in formal_patterns if re.search(p, text_lower))

    if technical_count >= 2:
        return "technical"
    elif casual_count >= 2:
        return "casual"
    elif formal_count >= 1:
        return "formal"
    else:
        return "casual"  # Default to casual


def is_architecture_context(batch: QuestionBatch) -> bool:
    """
    Check if this is a deep architecture discussion.

    These get more depth allowance.
    """
    architecture_topics = {
        QuestionTopic.SELF_ARCHITECTURE,
        QuestionTopic.COORDINATION,
        QuestionTopic.ROUTING_CONTROL,
    }

    architecture_count = sum(
        1 for q in batch.items
        if q.inferred_topic in architecture_topics
    )

    return architecture_count >= 2 or (
        batch.count == 1 and
        batch.items[0].inferred_topic in architecture_topics
    )


def is_identity_context(batch: QuestionBatch) -> bool:
    """
    Check if this is an identity/self question.

    Identity questions should ALWAYS get deep responses with:
    - Full cognitive inventory
    - Tool listing
    - Architecture overview
    - Dynamic self-model data
    """
    identity_topics = {
        QuestionTopic.SELF_DESCRIPTION,
        QuestionTopic.SELF_CAPABILITIES,
        QuestionTopic.SELF_ARCHITECTURE,
        QuestionTopic.MEMORY_PERSISTENCE,
        QuestionTopic.TOOLS_ACTIONS,
        QuestionTopic.COMPARISON,  # "how are you different from ChatGPT"
    }

    identity_count = sum(
        1 for q in batch.items
        if q.inferred_topic in identity_topics
    )

    return identity_count >= 1  # ANY identity question gets deep treatment


# =============================================================================
# Depth Planning Logic (HYBRID MAVEN SPEC)
# =============================================================================

# HYBRID MAVEN SPEC - Dynamic Length Rules:
#
# Short mode (num_questions == 1 AND complexity == low):
#   - "What are the most important things to understand about you?"
#   - 2-4 short bullets or 1-2 concise paragraphs
#
# Medium mode (num_questions > 1 OR complexity == medium/high):
#   - "How do your brains coordinate? Do they work in parallel?"
#   - One section per question, mirroring structure
#
# Long mode (RARE - only when explicitly requested OR system-design-level):
#   - "Go deep", "in detail", "technical spec"
#   - "Give a full internal pipeline spec for Maven"
#
# For self_model responses:
#   - Simple self-question ("What did you just learn?") -> SHORT
#   - Multi-part architecture deep dive -> MEDIUM, not huge


def _is_explicit_long_request(text: str) -> bool:
    """Check if user explicitly requested detailed/long response."""
    text_lower = text.lower()
    long_markers = [
        "go deep", "in detail", "detailed", "comprehensive",
        "full spec", "technical spec", "explain in depth",
        "step by step", "walk me through", "thoroughly",
    ]
    return any(marker in text_lower for marker in long_markers)


def _is_system_design_question(text: str) -> bool:
    """Check if question is system-design-level complexity."""
    text_lower = text.lower()
    design_markers = [
        "internal pipeline", "full architecture", "system design",
        "implementation detail", "data flow", "control flow spec",
        "complete specification", "full internal",
    ]
    return any(marker in text_lower for marker in design_markers)


def _plan_single_question(
    question: ParsedQuestion,
    batch_count: int,
    user_style: str,
    is_architecture: bool,
    is_identity: bool = False,
) -> DepthGuidance:
    """
    HYBRID MAVEN SPEC: Plan depth for a single question.

    Dynamic length rules:
    - SHORT: num_questions == 1 AND complexity == low
    - MEDIUM: num_questions > 1 OR complexity >= medium
    - DEEP: Explicitly requested OR system-design-level

    For self_model responses, override teacher's "always medium":
    - Simple self-question -> SHORT
    - Multi-part architecture -> MEDIUM, not huge
    """
    complexity = compute_complexity_score(question.text)
    text_lower = question.text.lower()

    # Extract emphasis words first (used for all paths)
    emphasis_words = []
    for word in ["brains", "tools", "coordinate", "memory", "learning", "routing",
                 "capabilities", "architecture", "identity", "cognitive"]:
        if word in text_lower:
            emphasis_words.append(word)

    # =========================================================================
    # HYBRID MAVEN SPEC: Determine depth level
    # =========================================================================

    # Rule 1: DEEP only when explicitly requested OR system-design-level
    explicit_long = _is_explicit_long_request(question.text)
    system_design = _is_system_design_question(question.text)

    if explicit_long or system_design:
        # RARE: Long mode only when explicitly requested
        depth = DepthLevel.DEEP
        max_sentences = 10
        max_bullets = 6
        detail_preference = DetailPreference.ARCHITECTURAL
        example_policy = ExamplePolicy.DETAILED
        allow_subheadings = True

        return DepthGuidance(
            question_id=question.id,
            depth=depth,
            detail_preference=detail_preference,
            example_policy=example_policy,
            max_sentences=max_sentences,
            max_bullets=max_bullets,
            allow_subheadings=allow_subheadings,
            emphasis_words=emphasis_words,
        )

    # Rule 2: MEDIUM for multi-question batches OR medium/high complexity
    if batch_count > 1 or complexity >= 2:
        depth = DepthLevel.MEDIUM

        # Scale sentences/bullets based on batch size
        if batch_count >= 4:
            max_sentences = 3  # Many questions = shorter per answer
            max_bullets = 3
        elif batch_count >= 2:
            max_sentences = 4
            max_bullets = 4
        else:
            max_sentences = 5
            max_bullets = 5

        # Determine detail preference
        if question.inferred_topic in {
            QuestionTopic.SELF_ARCHITECTURE,
            QuestionTopic.COORDINATION,
            QuestionTopic.ROUTING_CONTROL,
        }:
            detail_preference = DetailPreference.ARCHITECTURAL
        elif "how" in text_lower or "step" in text_lower:
            detail_preference = DetailPreference.STEPWISE
        else:
            detail_preference = DetailPreference.HIGH_LEVEL

        example_policy = ExamplePolicy.BRIEF
        allow_subheadings = False

        return DepthGuidance(
            question_id=question.id,
            depth=depth,
            detail_preference=detail_preference,
            example_policy=example_policy,
            max_sentences=max_sentences,
            max_bullets=max_bullets,
            allow_subheadings=allow_subheadings,
            emphasis_words=emphasis_words,
        )

    # Rule 3: SHORT for single simple questions
    # This includes simple self-questions like "What did you just learn?"
    depth = DepthLevel.SHORT
    max_sentences = 3
    max_bullets = 4
    detail_preference = DetailPreference.HIGH_LEVEL
    example_policy = ExamplePolicy.NONE
    allow_subheadings = False

    # Special case: Simple identity question still gets brief but informative response
    identity_topics = {
        QuestionTopic.SELF_DESCRIPTION,
        QuestionTopic.SELF_CAPABILITIES,
        QuestionTopic.RECENT_LEARNING,
    }
    if question.inferred_topic in identity_topics:
        max_sentences = 4  # Slightly longer for identity
        max_bullets = 5

    return DepthGuidance(
        question_id=question.id,
        depth=depth,
        detail_preference=detail_preference,
        example_policy=example_policy,
        max_sentences=max_sentences,
        max_bullets=max_bullets,
        allow_subheadings=allow_subheadings,
        emphasis_words=emphasis_words,
    )


def plan_depth(batch: QuestionBatch) -> BatchDepthPlan:
    """
    Create a depth plan for an entire question batch.

    This is the main entry point for the Length & Depth Planner.

    Args:
        batch: The parsed question batch

    Returns:
        BatchDepthPlan with guidance for each question
    """
    if batch.count == 0:
        return BatchDepthPlan(
            per_question={},
            total_max_length=500,
            overall_style="casual",
            add_closing=False,
        )

    # Analyze overall context
    user_style = detect_user_style(batch.original_text)
    is_architecture = is_architecture_context(batch)
    is_identity = is_identity_context(batch)

    # Plan each question
    per_question = {}
    for question in batch.items:
        guidance = _plan_single_question(
            question=question,
            batch_count=batch.count,
            user_style=user_style,
            is_architecture=is_architecture,
            is_identity=is_identity,
        )
        per_question[question.id] = guidance

    # Calculate total max length
    if batch.count == 1:
        total_max_length = 2000  # Single question can be longer
    elif batch.count <= 3:
        total_max_length = 1500
    else:
        total_max_length = 1200  # Many questions = more concise

    # Add closing for architecture discussions or single deep questions
    add_closing = (
        is_architecture or
        (batch.count == 1 and per_question["q1"].depth == DepthLevel.DEEP)
    )

    return BatchDepthPlan(
        per_question=per_question,
        total_max_length=total_max_length,
        overall_style=user_style,
        add_closing=add_closing,
    )


# =============================================================================
# Convenience Functions
# =============================================================================

def get_depth_for_question(
    question_text: str,
    total_questions: int = 1,
) -> DepthGuidance:
    """
    Quick helper to get depth guidance for a single question.

    Args:
        question_text: The question text
        total_questions: How many questions in the batch

    Returns:
        DepthGuidance for this question
    """
    from brains.routing.question_parser import (
        ParsedQuestion, QuestionTopic, classify_question_topic
    )

    topic = classify_question_topic(question_text)
    question = ParsedQuestion(
        id="q1",
        text=question_text,
        position=0,
        inferred_topic=topic,
    )

    # Identity topics that should get deep treatment
    identity_topics = {
        QuestionTopic.SELF_DESCRIPTION,
        QuestionTopic.SELF_CAPABILITIES,
        QuestionTopic.SELF_ARCHITECTURE,
        QuestionTopic.MEMORY_PERSISTENCE,
        QuestionTopic.TOOLS_ACTIONS,
        QuestionTopic.COMPARISON,
    }

    return _plan_single_question(
        question=question,
        batch_count=total_questions,
        user_style="casual",
        is_architecture=(topic == QuestionTopic.SELF_ARCHITECTURE),
        is_identity=(topic in identity_topics),
    )


def should_include_example(guidance: DepthGuidance) -> bool:
    """Check if an example should be included."""
    return guidance.example_policy != ExamplePolicy.NONE


def get_sentence_limit(guidance: DepthGuidance) -> int:
    """Get the sentence limit for an answer."""
    return guidance.max_sentences


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "DepthLevel",
    "DetailPreference",
    "ExamplePolicy",
    "DepthGuidance",
    "BatchDepthPlan",
    "compute_complexity_score",
    "detect_user_style",
    "is_architecture_context",
    "is_identity_context",
    "plan_depth",
    "get_depth_for_question",
    "should_include_example",
    "get_sentence_limit",
]
