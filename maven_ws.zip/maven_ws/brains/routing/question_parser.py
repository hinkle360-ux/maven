# brains/routing/question_parser.py
"""
Question Parser - Multi-Question Detection and Structuring
===========================================================

Parses user messages to detect and enumerate all questions.
Builds a structured question_batch with:
- Question count
- Structure type (numbered, bulleted, prose)
- Individual question items with position and inferred topic

This module is used by the Router Brain to ensure every question
gets routed and answered.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
import re
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum


class QuestionStructure(str, Enum):
    """The structural format of the incoming questions."""
    NUMBERED = "numbered"      # 1. Question one 2. Question two
    BULLETED = "bulleted"      # - Question one • Question two
    PROSE = "prose"            # Question one? And question two?
    HEADINGS = "headings"      # ## Topic\nQuestion
    SINGLE = "single"          # Just one question


class QuestionTopic(str, Enum):
    """Topic classification for routing purposes."""
    SELF_ARCHITECTURE = "self_architecture"
    SELF_DESCRIPTION = "self_description"
    SELF_CAPABILITIES = "self_capabilities"
    MEMORY_PERSISTENCE = "memory_persistence"
    TOOLS_ACTIONS = "tools_actions"
    ROUTING_CONTROL = "routing_control"
    LEARNING_TEACHER = "learning_teacher"
    GENERAL_REASONING = "general_reasoning"
    COMPARISON = "comparison"
    COORDINATION = "coordination"
    RECENT_LEARNING = "recent_learning"  # "what did you just learn" type questions
    SESSION_HISTORY = "session_history"   # "what did we discuss" type questions
    # Technical expertise topics (Computer & Python Expert Mode)
    TECHNICAL_COMPUTER = "technical_computer"    # OS, filesystem, networking, system admin
    TECHNICAL_PYTHON = "technical_python"        # Python syntax, patterns, best practices
    TECHNICAL_DEBUGGING = "technical_debugging"  # Errors, tracebacks, debugging
    UNKNOWN = "unknown"


@dataclass
class ParsedQuestion:
    """A single parsed question with metadata."""
    id: str
    text: str
    position: int
    inferred_topic: QuestionTopic
    original_marker: str = ""  # "1.", "-", "•", etc.
    assigned_brains: List[str] = field(default_factory=list)
    answered: bool = False
    answer_content: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return {
            "id": self.id,
            "text": self.text,
            "position": self.position,
            "topic": self.inferred_topic.value,
            "marker": self.original_marker,
            "assigned_brains": self.assigned_brains,
            "answered": self.answered,
        }


@dataclass
class QuestionBatch:
    """
    A batch of parsed questions with structure metadata.

    This is written to the blackboard by the Router for EVA to consume.
    """
    count: int
    structure: QuestionStructure
    items: List[ParsedQuestion]
    original_text: str

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return {
            "count": self.count,
            "structure": self.structure.value,
            "items": [q.to_dict() for q in self.items],
            "original_text": self.original_text,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "QuestionBatch":
        """Create from dictionary."""
        items = []
        for item_data in data.get("items", []):
            items.append(ParsedQuestion(
                id=item_data["id"],
                text=item_data["text"],
                position=item_data["position"],
                inferred_topic=QuestionTopic(item_data.get("topic", "unknown")),
                original_marker=item_data.get("marker", ""),
                assigned_brains=item_data.get("assigned_brains", []),
                answered=item_data.get("answered", False),
            ))
        return cls(
            count=data["count"],
            structure=QuestionStructure(data["structure"]),
            items=items,
            original_text=data.get("original_text", ""),
        )

    def mark_answered(self, question_id: str, content: str) -> None:
        """Mark a question as answered."""
        for item in self.items:
            if item.id == question_id:
                item.answered = True
                item.answer_content = content
                break

    def all_answered(self) -> bool:
        """Check if all questions have been answered."""
        return all(q.answered for q in self.items)

    def get_unanswered(self) -> List[ParsedQuestion]:
        """Get list of unanswered questions."""
        return [q for q in self.items if not q.answered]


# =============================================================================
# Topic Classification Patterns
# =============================================================================

TOPIC_PATTERNS: Dict[QuestionTopic, List[str]] = {
    # RECENT_LEARNING must come FIRST - it's more specific than general learning
    QuestionTopic.RECENT_LEARNING: [
        r"\bwhat\s+did\s+you\s+(?:just\s+)?learn\b",
        r"\bwhat\s+have\s+you\s+learned\b",
        r"\bwhat\s+(?:did\s+)?you\s+learn\s+from\b",
        r"\bwhat\s+lessons?\b",
        r"\brecent\s+(?:learning|lessons?)\b",
        r"\blast\s+(?:session|conversation|chat)\b.*\blearn\b",
        r"\bsummarize\s+(?:what\s+)?(?:you\s+)?learned\b",
        r"\bwhat\s+facts?\s+did\s+you\b",
        r"\bwhat\s+did\s+(?:chatgpt|grok|claude)\s+(?:say|tell|teach)\b",
        r"\bfrom\s+(?:that|the)\s+(?:session|conversation|chat)\b",
    ],
    # SESSION_HISTORY for "what did we discuss" type questions
    QuestionTopic.SESSION_HISTORY: [
        r"\bwhat\s+did\s+we\s+(?:talk|discuss|say)\b",
        r"\bwhat\s+have\s+we\s+(?:talked|discussed)\b",
        r"\bour\s+(?:conversation|discussion|chat)\b",
        r"\bwhat\s+(?:was|were)\s+we\s+(?:talking|discussing)\b",
        r"\bearlier\s+(?:in\s+)?(?:this\s+)?(?:conversation|chat|session)\b",
        r"\bdo\s+you\s+remember\s+(?:what|when|our)\b",
        r"\bconversation\s+history\b",
    ],
    QuestionTopic.SELF_ARCHITECTURE: [
        r"\bhow\s+do.*brains?\b",
        r"\bcoordinate\b",
        r"\barchitecture\b",
        r"\bstructure\b",
        r"\bcontrol\s+flow\b",
        r"\bsync\s+vs\s+async\b",
        r"\bblackboard\b",
        r"\brouting\b",
        r"\bhow\s+do.*communicate\b",
        r"\binteract\b.*\binternal\b",
        r"\bspecialized\b",
        r"\bfunction\s+or\b.*\bmodality\b",
        r"\bby\s+function\b",
        r"\bby\s+modality\b",
    ],
    QuestionTopic.SELF_DESCRIPTION: [
        r"\bwho\s+are\s+you\b",
        r"\bwhat\s+are\s+you\b",
        r"\bintroduce\s+yourself\b",
        r"\bexplain\s+yourself\b",
        r"\byour\s+name\b",
        r"\btell\s+me\s+about\s+you\b",
    ],
    QuestionTopic.SELF_CAPABILITIES: [
        r"\bcan\s+you\b",
        r"\bare\s+you\s+able\b",
        r"\bwhat\s+can\s+you\b",
        r"\bcapabilities\b",
        r"\bwhat\s+do\s+you\s+do\b",
    ],
    QuestionTopic.MEMORY_PERSISTENCE: [
        r"\bmemory\b",
        r"\bremember\b",
        r"\bpersist\b",
        r"\bstore\b",
        r"\bforget\b",
        r"\blong-term\b",
        r"\bshort-term\b",
    ],
    QuestionTopic.TOOLS_ACTIONS: [
        r"\btool\b",
        r"\btools\b",
        r"\bexternal\s+tool\b",
        r"\baction\b",
        r"\bbrowser\b",
        r"\bweb\s+search\b",
        r"\btool-usage\b",
        r"\bexternal\s+system\b",
    ],
    QuestionTopic.ROUTING_CONTROL: [
        r"\brouting\b",
        r"\brouter\b",
        r"\bdispatch\b",
        r"\bselect.*brain\b",
        r"\bchoose.*module\b",
    ],
    QuestionTopic.LEARNING_TEACHER: [
        r"\blearn\b",
        r"\blearning\b",
        r"\bteacher\b",
        r"\bstudent\b",
        r"\bimprove\b",
        r"\bevolve\b",
        r"\bself-modify\b",
        r"\bpattern\b",
    ],
    QuestionTopic.COMPARISON: [
        r"\bchatgpt\b",
        r"\bclaude\b",
        r"\bgrok\b",
        r"\bcompare\b",
        r"\bdifferent\s+from\b",
        r"\bvs\b",
        r"\bversus\b",
    ],
    QuestionTopic.COORDINATION: [
        r"\bcoordinate\b",
        r"\bsynchronize\b",
        r"\bparallel\b",
        r"\bsequential\b",
        r"\bconcurrent\b",
    ],
    # ============ TECHNICAL EXPERTISE PATTERNS ============
    # These must come BEFORE general patterns to catch technical questions
    QuestionTopic.TECHNICAL_PYTHON: [
        # Python-specific keywords
        r"\bpython\b",
        r"\bpython\s*3\.\d+\b",
        r"\bpython\s*3\.11\b",
        r"\bpython\s*3\.10\b",
        r"\bpip\s+install\b",
        r"\bpip\b.*\bpackage\b",
        r"\bvenv\b",
        r"\bvirtualenv\b",
        r"\bconda\b",
        r"\bpypi\b",
        # Python features
        r"\basync\s*def\b",
        r"\bawait\b",
        r"\basyncio\b",
        r"\bdecorator\b",
        r"\b@\w+\b",
        r"\bdataclass\b",
        r"\btype\s*hint\b",
        r"\btyping\b",
        r"\b__init__\b",
        r"\b__name__\b",
        r"\bdunder\b",
        # Python patterns
        r"\blist\s*comprehension\b",
        r"\bdict\s*comprehension\b",
        r"\bgenerator\b",
        r"\byield\b",
        r"\bcontext\s*manager\b",
        r"\bwith\s+open\b",
        r"\bexcept\s+\w+Error\b",
        r"\braise\s+\w+Error\b",
        # Python 3.11+ specific
        r"\bexception\s*group\b",
        r"\bexcept\*\b",
        r"\btomllib\b",
        r"\bTaskGroup\b",
        r"\bmatch\s+case\b",
        r"\bpattern\s*matching\b",
    ],
    QuestionTopic.TECHNICAL_DEBUGGING: [
        # Error types
        r"\bTraceback\b",
        r"\b\w+Error\b",
        r"\b\w+Exception\b",
        r"\bNameError\b",
        r"\bTypeError\b",
        r"\bValueError\b",
        r"\bAttributeError\b",
        r"\bKeyError\b",
        r"\bIndexError\b",
        r"\bImportError\b",
        r"\bModuleNotFoundError\b",
        r"\bSyntaxError\b",
        # Debugging keywords
        r"\bdebug\b",
        r"\bdebugging\b",
        r"\berror\b.*\bfix\b",
        r"\bfix\b.*\berror\b",
        r"\bwhy\b.*\berror\b",
        r"\bstack\s*trace\b",
        r"\bbreakpoint\b",
        r"\bpdb\b",
        r"\bwhat\s+(?:does|is)\s+this\s+error\b",
        r"\bwhy\s+(?:am\s+)?(?:i|we)\s+getting\b",
        r"\bhow\s+(?:do\s+)?(?:i|we)\s+fix\b",
        r"\bwhat\s+went\s+wrong\b",
    ],
    QuestionTopic.TECHNICAL_COMPUTER: [
        # OS and system
        r"\boperating\s*system\b",
        r"\blinux\b",
        r"\bwindows\b",
        r"\bmacos\b",
        r"\bunix\b",
        r"\bubuntu\b",
        r"\bdebian\b",
        r"\bfedora\b",
        r"\bcentos\b",
        # Filesystem
        r"\bfilesystem\b",
        r"\bfile\s*system\b",
        r"\bdirectory\b",
        r"\bfolder\b",
        r"\bpath\b",
        r"\bpermission\b",
        r"\bchmod\b",
        r"\bchown\b",
        r"\brwx\b",
        # Networking
        r"\bnetworking\b",
        r"\btcp\b",
        r"\budp\b",
        r"\bip\s*address\b",
        r"\bport\b",
        r"\bdns\b",
        r"\bhttp\b",
        r"\bhttps\b",
        r"\bsocket\b",
        r"\bfirewall\b",
        # Shell and commands
        r"\bbash\b",
        r"\bshell\b",
        r"\bterminal\b",
        r"\bcommand\s*line\b",
        r"\bcli\b",
        r"\bsudo\b",
        r"\bapt\b",
        r"\byum\b",
        r"\bpacman\b",
        r"\bbrew\b",
        # Processes and system
        r"\bprocess\b",
        r"\bkill\b.*\bprocess\b",
        r"\bps\s+aux\b",
        r"\bsystemctl\b",
        r"\bservice\b",
        r"\bdaemon\b",
        r"\bcron\b",
        # Git and version control
        r"\bgit\b",
        r"\bgit\s+(?:clone|pull|push|commit|branch|merge|rebase)\b",
        r"\brepository\b",
        r"\bversion\s*control\b",
        # Environment
        r"\benvironment\s*variable\b",
        r"\benv\s*var\b",
        r"\bPATH\b",
        r"\bexport\b",
    ],
}

# Compile patterns for efficiency
_COMPILED_TOPIC_PATTERNS: Dict[QuestionTopic, List[re.Pattern]] = {
    topic: [re.compile(p, re.IGNORECASE) for p in patterns]
    for topic, patterns in TOPIC_PATTERNS.items()
}


def classify_question_topic(text: str) -> QuestionTopic:
    """
    Classify a question into a topic for routing purposes.

    Args:
        text: The question text

    Returns:
        The inferred topic
    """
    for topic, patterns in _COMPILED_TOPIC_PATTERNS.items():
        for pattern in patterns:
            if pattern.search(text):
                return topic
    return QuestionTopic.UNKNOWN


# =============================================================================
# Structure Detection
# =============================================================================

# Patterns for detecting structure
NUMBERED_PATTERN = re.compile(r"^\s*(\d+)[.)]\s+", re.MULTILINE)
BULLETED_PATTERN = re.compile(r"^\s*[-•*]\s+", re.MULTILINE)
HEADING_PATTERN = re.compile(r"^#+\s+.+$", re.MULTILINE)


def detect_structure(text: str) -> QuestionStructure:
    """
    Detect the structural format of the input.

    Args:
        text: The user message

    Returns:
        The detected structure type
    """
    # Count different markers
    numbered_matches = len(NUMBERED_PATTERN.findall(text))
    bulleted_matches = len(BULLETED_PATTERN.findall(text))
    heading_matches = len(HEADING_PATTERN.findall(text))

    # Detect inline question marks (prose style)
    question_marks = text.count("?")

    if numbered_matches >= 2:
        return QuestionStructure.NUMBERED
    elif bulleted_matches >= 2:
        return QuestionStructure.BULLETED
    elif heading_matches >= 1:
        return QuestionStructure.HEADINGS
    elif question_marks >= 2:
        return QuestionStructure.PROSE
    else:
        return QuestionStructure.SINGLE


# =============================================================================
# Question Extraction
# =============================================================================

def _extract_numbered_questions(text: str) -> List[Tuple[str, str, int]]:
    """
    Extract questions from numbered list format.

    Returns list of (marker, question_text, position)
    """
    results = []

    # Split on numbered markers
    parts = re.split(r"(\d+[.)]\s+)", text)

    position = 0
    current_marker = ""
    for part in parts:
        if re.match(r"\d+[.)]\s+", part):
            current_marker = part.strip()
        elif part.strip() and current_marker:
            results.append((current_marker, part.strip(), position))
            position += 1
            current_marker = ""

    return results


def _extract_bulleted_questions(text: str) -> List[Tuple[str, str, int]]:
    """
    Extract questions from bulleted list format.

    Returns list of (marker, question_text, position)
    """
    results = []
    lines = text.split("\n")
    position = 0

    for line in lines:
        match = re.match(r"^\s*([-•*])\s+(.+)$", line)
        if match:
            marker = match.group(1)
            question_text = match.group(2).strip()
            results.append((marker, question_text, position))
            position += 1

    return results


def _extract_prose_questions(text: str) -> List[Tuple[str, str, int]]:
    """
    Extract questions from prose format (inline ? marks).

    Returns list of (marker, question_text, position)
    """
    results = []

    # Split on sentence boundaries that end with ?
    sentences = re.split(r"(?<=[.!?])\s+", text)

    position = 0
    for sentence in sentences:
        sentence = sentence.strip()
        if "?" in sentence:
            results.append(("", sentence, position))
            position += 1

    # If no explicit questions found, treat entire text as one
    if not results and text.strip():
        results.append(("", text.strip(), 0))

    return results


def _extract_heading_questions(text: str) -> List[Tuple[str, str, int]]:
    """
    Extract questions from heading + content format.

    Returns list of (marker, question_text, position)
    """
    results = []
    lines = text.split("\n")

    current_heading = ""
    current_content = []
    position = 0

    for line in lines:
        if re.match(r"^#+\s+", line):
            # New heading - save previous if exists
            if current_heading and current_content:
                content = " ".join(current_content).strip()
                results.append((current_heading, content, position))
                position += 1

            current_heading = line.strip()
            current_content = []
        else:
            current_content.append(line)

    # Don't forget the last section
    if current_heading and current_content:
        content = " ".join(current_content).strip()
        results.append((current_heading, content, position))

    return results


# =============================================================================
# Main Parser Function
# =============================================================================

def parse_questions(text: str) -> QuestionBatch:
    """
    Parse user message to detect and enumerate all questions.

    This is the main entry point for question parsing.

    Args:
        text: The user message

    Returns:
        QuestionBatch with all detected questions and structure metadata
    """
    if not text or not text.strip():
        return QuestionBatch(
            count=0,
            structure=QuestionStructure.SINGLE,
            items=[],
            original_text=text or "",
        )

    # Detect structure
    structure = detect_structure(text)

    # Extract questions based on structure
    if structure == QuestionStructure.NUMBERED:
        raw_questions = _extract_numbered_questions(text)
    elif structure == QuestionStructure.BULLETED:
        raw_questions = _extract_bulleted_questions(text)
    elif structure == QuestionStructure.HEADINGS:
        raw_questions = _extract_heading_questions(text)
    else:  # PROSE or SINGLE
        raw_questions = _extract_prose_questions(text)

    # Build ParsedQuestion objects
    items = []
    for i, (marker, question_text, position) in enumerate(raw_questions):
        topic = classify_question_topic(question_text)
        items.append(ParsedQuestion(
            id=f"q{i+1}",
            text=question_text,
            position=position,
            inferred_topic=topic,
            original_marker=marker,
        ))

    # If no questions detected, treat entire text as one question
    if not items:
        topic = classify_question_topic(text)
        items.append(ParsedQuestion(
            id="q1",
            text=text.strip(),
            position=0,
            inferred_topic=topic,
        ))

    return QuestionBatch(
        count=len(items),
        structure=structure,
        items=items,
        original_text=text,
    )


# =============================================================================
# Brain Assignment
# =============================================================================

# Topic -> Brain mapping
TOPIC_TO_BRAINS: Dict[QuestionTopic, List[str]] = {
    # RECENT_LEARNING needs memory_librarian to retrieve recent facts
    QuestionTopic.RECENT_LEARNING: [
        "memory_librarian", "learning", "language",
    ],
    # SESSION_HISTORY needs system_history for conversation context
    QuestionTopic.SESSION_HISTORY: [
        "system_history", "memory_librarian", "language",
    ],
    # SELF topics need BOTH self_model (for dynamic data) and self_introspection (for registry)
    QuestionTopic.SELF_ARCHITECTURE: [
        "self_model", "self_introspection", "memory_librarian", "language",
    ],
    QuestionTopic.SELF_DESCRIPTION: [
        "self_model", "self_introspection", "language",
    ],
    QuestionTopic.SELF_CAPABILITIES: [
        "self_model", "self_introspection", "language",
    ],
    QuestionTopic.MEMORY_PERSISTENCE: [
        "self_model", "self_introspection", "memory_librarian", "language",
    ],
    QuestionTopic.TOOLS_ACTIONS: [
        "self_model", "self_introspection", "language",
    ],
    QuestionTopic.ROUTING_CONTROL: [
        "self_model", "self_introspection", "language",
    ],
    QuestionTopic.LEARNING_TEACHER: [
        "self_model", "self_introspection", "learning", "language",
    ],
    QuestionTopic.COMPARISON: [
        "self_model", "self_introspection", "language",
    ],
    QuestionTopic.COORDINATION: [
        "self_model", "self_introspection", "language",
    ],
    QuestionTopic.GENERAL_REASONING: [
        "reasoning", "language",
    ],
    # ============ TECHNICAL EXPERTISE BRAIN ASSIGNMENTS ============
    # These activate the technical expert brains for precise answers
    QuestionTopic.TECHNICAL_PYTHON: [
        "python_expert", "coder", "reasoning", "language",
    ],
    QuestionTopic.TECHNICAL_DEBUGGING: [
        "debugger", "coder", "reasoning", "language",
    ],
    QuestionTopic.TECHNICAL_COMPUTER: [
        "technical_expert", "sysadmin_expert", "reasoning", "language",
    ],
    QuestionTopic.UNKNOWN: [
        "language",
    ],
}


def assign_brains_to_questions(batch: QuestionBatch) -> QuestionBatch:
    """
    Assign appropriate brains to each question based on topic.

    Modifies the batch in place and returns it.

    Args:
        batch: The question batch to process

    Returns:
        The same batch with brains assigned
    """
    for question in batch.items:
        brains = TOPIC_TO_BRAINS.get(
            question.inferred_topic,
            TOPIC_TO_BRAINS[QuestionTopic.UNKNOWN]
        )
        question.assigned_brains = list(brains)

    return batch


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "QuestionStructure",
    "QuestionTopic",
    "ParsedQuestion",
    "QuestionBatch",
    "classify_question_topic",
    "detect_structure",
    "parse_questions",
    "assign_brains_to_questions",
    "TOPIC_TO_BRAINS",
]
