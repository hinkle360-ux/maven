"""
Routing Engine - Unified Entry Point for All Routing Decisions
==============================================================

This module is the single entry point for routing user messages to brains/tools.
It orchestrates the layered routing system with strict precedence:

SCAN-FIRST RULE:
- Before routing, always check self_model freshness
- If stale, run introspection to update system snapshot
- Never assume brain/tool counts - derive dynamically from registries

ROUTING PRECEDENCE (in order):
1. GRAMMAR (Priority -1) - Deterministic regex patterns for explicit commands
   - "x grok hello" → x tool with grok subcommand
   - "research: AI" → research_manager brain
   - ALWAYS respected, cannot be overridden

2. SELF-INTENT GATE (Priority 0) - Self/capability questions
   - "who are you" → self_model brain
   - "can you browse" → self_model brain
   - Prevents Teacher from hallucinating capabilities

3. ROUTER LLM (Priority 0.5) - JSON-only routing LLM
   - Called when grammar doesn't match
   - Returns confidence score
   - Only used if confidence >= threshold

4. LEARNED PATTERNS (Priority 1) - Pattern store / routing_learning
   - Historical patterns from routing_examples
   - Lowest priority, easily overridden

5. SAFE DEFAULT (Fallback) - language brain
   - Used when all else fails
   - Never crashes the system

MULTI-QUESTION HANDLING:
- Parse all questions from input using question_parser
- Build a question_batch with count, structure, and items
- Route each question to appropriate brains
- Store question_batch on blackboard for EVA to consume

Usage:
    from brains.routing.routing_engine import build_routing_plan

    decision = build_routing_plan(
        query="x grok hello from maven",
        capability_snapshot=snapshot,
    )

    # decision.brains = ["language"]
    # decision.tools = ["x"]
    # decision.subcommand = "grok"
    # decision.confidence = 1.0
    # decision.source = "grammar:x_grok"

    # For multi-question routing:
    from brains.routing.routing_engine import build_multi_question_plan

    plan = build_multi_question_plan(
        query="How do brains coordinate? Are they specialized?",
        blackboard=blackboard,
    )
    # plan.question_batch has parsed questions
    # plan.decisions has routing per question
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field

from brains.routing.router_schema import (
    RoutingDecision,
    ParsedCommand,
    LLMRouterResult,
    RoutingContext,
    RoutingExample,
    VALID_BRAINS,
)

# Import question parser for multi-question handling
try:
    from brains.routing.question_parser import (
        QuestionBatch,
        ParsedQuestion,
        QuestionStructure,
        QuestionTopic,
        parse_questions,
        assign_brains_to_questions,
        TOPIC_TO_BRAINS,
    )
    _question_parser_available = True
except ImportError:
    _question_parser_available = False

# Import router introspection for scan-first behavior
try:
    from brains.routing.router_introspection import (
        SelfModel,
        SystemSnapshot,
        scan_first_if_needed,
        get_self_model,
        introspect_system,
    )
    _introspection_available = True
except ImportError:
    _introspection_available = False

# Import length/depth planner
try:
    from brains.routing.length_depth_planner import (
        BatchDepthPlan,
        DepthGuidance,
        plan_depth,
    )
    _depth_planner_available = True
except ImportError:
    _depth_planner_available = False

# Import self-intent detection from self_blocks
try:
    from brains.cognitive.self_model.service.self_blocks import (
        SelfIntent,
        detect_self_intent,
        extract_focus_words,
    )
    _self_blocks_available = True
except ImportError:
    _self_blocks_available = False
    SelfIntent = None  # type: ignore

# Text normalizer for handling typos
try:
    from brains.routing.normalizer import normalize, NormalizationResult
    _normalizer_available = True
except ImportError:
    _normalizer_available = False
    normalize = None  # type: ignore

# Intelligent LLM-based intent classifier (learns from outcomes)
try:
    from brains.cognitive.integrator.llm_intent_classifier import (
        get_llm_intent_classifier,
        IntentClassification,
    )
    _intelligent_classifier_available = True
except ImportError:
    _intelligent_classifier_available = False
    get_llm_intent_classifier = None  # type: ignore
    IntentClassification = None  # type: ignore


# =============================================================================
# GRAMMAR PATTERNS (Priority -1)
# =============================================================================

# Pattern: x grok <message> or x: grok <message>
PATTERN_X_GROK = re.compile(
    r"^x\s*[:\s]+grok\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: grok <message> (standalone grok command)
PATTERN_GROK_STANDALONE = re.compile(
    r"^grok\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: x post <message> or post to x: <message>
PATTERN_X_POST = re.compile(
    r"^(?:x\s+post|post\s+(?:to\s+)?x)\s*[:\s]*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: research: <topic> or research: "<topic>" web:N
PATTERN_RESEARCH = re.compile(
    r'^research\s*:\s*(?:"([^"]+)"|(.+?))(?:\s+web\s*:\s*(\d+))?$',
    re.IGNORECASE | re.DOTALL
)

# Pattern: browser_open: <url> or open <url>
PATTERN_BROWSER_OPEN = re.compile(
    r"^(?:browser_open|open)\s*:\s*(https?://\S+)$",
    re.IGNORECASE
)

# Pattern: search: <query> or web search: <query>
PATTERN_WEB_SEARCH = re.compile(
    r"^(?:web\s+)?search\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: use <tool> tool: <args>
PATTERN_EXPLICIT_TOOL = re.compile(
    r"^use\s+(\w+)\s+tool\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: use grok: <message> or use grok <message> (direct grok command)
# This is a shorthand for "x grok: <message>"
PATTERN_USE_GROK = re.compile(
    r"^use\s+grok\s*[:\s]+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: use chatgpt: <message> or use chatgpt <message>
PATTERN_USE_CHATGPT = re.compile(
    r"^use\s+chatgpt\s*[:\s]+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: chatgpt <message> (standalone chatgpt command)
PATTERN_CHATGPT = re.compile(
    r"^chatgpt\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: x <subcommand> <args> (generic x command)
PATTERN_X_GENERIC = re.compile(
    r"^x\s*[:\s]+(\w+)\s*(.*)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: shell: <command> or run: <command>
PATTERN_SHELL = re.compile(
    r"^(?:shell|run)\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: python: <code>
PATTERN_PYTHON = re.compile(
    r"^python\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: code: <request>
PATTERN_CODE = re.compile(
    r"^code\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: maven <action> (direct maven commands)
PATTERN_MAVEN_COMMAND = re.compile(
    r"^maven\s+(explain|introduce|whoami|scan|status)\s*(.*)$",
    re.IGNORECASE
)


# =============================================================================
# SELF-INTENT PATTERNS (Priority 0)
# =============================================================================

# HYBRID MAVEN SPEC: Two-tier self-intent detection
#
# Tier 1: STRONG self-introspection patterns -> Route to self_model
#         These are EXPLICIT questions about Maven's internal architecture
#
# Tier 2: WEAK self-patterns -> Route to conversation mode (reasoning + language)
#         These are general questions that happen to touch on Maven
#
# The goal is to reduce self_model routing, which causes:
# - Repeated identity lines
# - Meta answers instead of direct answers

# STRONG patterns - explicit Maven architecture introspection
# Only these go to self_model brain
STRONG_SELF_PATTERNS = [
    # Explicit architecture introspection
    r"\byour\s+architecture\b",
    r"\byour\s+brains?\b",
    r"\byour\s+tools?\b",
    r"\byour\s+modules?\b",
    r"\byour\s+components?\b",
    r"\bhow\s+do\s+your\s+brains\b",
    r"\bhow\s+many\s+brains?\b",
    r"\bhow\s+many\s+tools?\b",
    r"\bhow\s+many\s+modules?\b",
    r"\bhow\s+many\s+components?\b",
    r"\bnumber\s+of\s+brains?\b",
    r"\bnumber\s+of\s+tools?\b",
    r"\btotal\s+brains?\b",
    r"\btotal\s+tools?\b",
    r"\bwhat\s+are\s+your\s+brains\b",
    r"\bwhat\s+are\s+your\s+capabilities\b",
    r"\blist\s+your\s+brains?\b",
    r"\blist\s+your\s+tools?\b",
    r"\bblackboard\b",

    # Explicit self-introduction requests
    r"\bintroduce\s+yourself\b",
    r"\bdescribe\s+yourself\b",
    r"\btell\s+me\s+about\s+yourself\b",
    r"\bexplain\s+yourself\b",
    r"\bwhoami\b",
    r"\bwho\s+are\s+you\b",
    r"\bwhat\s+are\s+you\b",

    # Recent learning/store questions
    r"\bwhat\s+did\s+you\s+(?:just\s+)?learn\b",
    r"\bwhat\s+did\s+you\s+store\b",
    r"\bwhat\s+have\s+you\s+learned\b",
    r"\bwhat\s+lessons?\b",

    # Maven-specific introspection
    r"\bhow\s+do\s+you\s+work\b",
    r"\bhow\s+are\s+you\s+(?:built|designed|structured)\b",
    r"\byourself\s+as\s+a\s+system\b",
    r"\babout\s+yourself\b",
]

# WEAK patterns - touch on self but should use normal reasoning
# These should NOT trigger full self_model, just add context
WEAK_SELF_PATTERNS = [
    # Generic capability questions
    r"\bcan\s+you\b",
    r"\bare\s+you\s+able\b",
    r"\bdo\s+you\s+have\b.*\b(access|ability)\b",
    r"\bwhat\s+can\s+you\s+do\b",

    # Identity comparisons
    r"\bare\s+you\s+(maven|an\s+llm|chatgpt|claude|gpt)\b",
    r"\bwho\s+(made|created|built)\s+you\b",

    # Internal state (philosophical)
    r"\bhow\s+do\s+you\s+feel\b",
    r"\bdo\s+you\s+have\s+(feelings|emotions)\b",
    r"\bare\s+you\s+(happy|sad|conscious|sentient)\b",
    r"\bdo\s+you\s+(like|enjoy|prefer)\b",

    # History questions
    r"\bwhat\s+did\s+(we|i)\s+(discuss|talk|ask)\b",
    r"\bdo\s+you\s+remember\b",

    # Comparison questions - use reasoning to explain differences
    r"\bdifferent\s+from\s+(chatgpt|claude|grok)\b",
    r"\bcompare.*to\s+(chatgpt|claude|grok)\b",
    r"\bvs\s+(chatgpt|claude|grok)\b",
    r"\bversus\s+(chatgpt|claude|grok)\b",

    # Health/diagnostics
    r"\b(system|your)\s+(health|status)\b",
    r"\bdiagnose\b",
    r"\bare\s+you\s+(working|broken|ok)\b",
]

# Legacy combined patterns for backward compatibility
SELF_INTENT_PATTERNS = STRONG_SELF_PATTERNS + WEAK_SELF_PATTERNS

_COMPILED_STRONG_SELF_PATTERNS = [re.compile(p, re.IGNORECASE) for p in STRONG_SELF_PATTERNS]
_COMPILED_WEAK_SELF_PATTERNS = [re.compile(p, re.IGNORECASE) for p in WEAK_SELF_PATTERNS]
_COMPILED_SELF_PATTERNS = [re.compile(p, re.IGNORECASE) for p in SELF_INTENT_PATTERNS]


# =============================================================================
# GRAMMAR LAYER (Priority -1)
# =============================================================================

def _parse_grammar(query: str) -> Optional[ParsedCommand]:
    """
    Parse user input against the hard grammar.

    This is Priority -1 - matches here ALWAYS take precedence.

    Args:
        query: Raw user input text

    Returns:
        ParsedCommand if matched, None otherwise
    """
    if not query:
        return None

    # Normalize: strip, collapse whitespace
    text = query.strip()
    text_normalized = re.sub(r'\s+', ' ', text)

    # Try patterns in order (most specific first)

    # 1. x grok <message>
    match = PATTERN_X_GROK.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand="grok",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="x_grok",
            metadata={"platform": "x", "action": "grok_chat"}
        )

    # 2. grok <message> (standalone)
    match = PATTERN_GROK_STANDALONE.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand="grok",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="grok_standalone",
            metadata={"platform": "x", "action": "grok_chat"}
        )

    # 2.5. use grok: <message> (shorthand for x grok)
    match = PATTERN_USE_GROK.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand="grok",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="use_grok",
            metadata={"platform": "x", "action": "grok_chat"}
        )

    # 2.6. use chatgpt: <message>
    match = PATTERN_USE_CHATGPT.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["chatgpt"],
            brains=["language"],
            subcommand="chat",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="use_chatgpt",
            metadata={"platform": "chatgpt", "action": "chat"}
        )

    # 3. x post / post to x
    match = PATTERN_X_POST.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand="post",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="x_post",
            metadata={"platform": "x", "action": "post"}
        )

    # 4. research: <topic>
    match = PATTERN_RESEARCH.match(text_normalized)
    if match:
        topic = match.group(1) or match.group(2)
        web_limit = int(match.group(3)) if match.group(3) else 10
        return ParsedCommand(
            intent="research",
            tools=["web_search", "web_fetch"],
            brains=["research_manager", "reasoning"],
            args=topic.strip() if topic else "",
            raw_input=text,
            matched_pattern="research",
            metadata={"web_limit": web_limit, "mode": "deep_research"}
        )

    # 5. browser_open: <url>
    match = PATTERN_BROWSER_OPEN.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_open",
            tools=["browser_open"],
            brains=["language"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="browser_open",
            metadata={"url": match.group(1).strip()}
        )

    # 6. search: <query>
    match = PATTERN_WEB_SEARCH.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="web_search",
            tools=["web_search"],
            brains=["research_manager"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="web_search",
            metadata={"query": match.group(1).strip()}
        )

    # 7. use <tool> tool: <args>
    match = PATTERN_EXPLICIT_TOOL.match(text_normalized)
    if match:
        tool_name = match.group(1).lower()
        return ParsedCommand(
            intent="explicit_tool",
            tools=[tool_name],
            brains=["language"],
            args=match.group(2).strip(),
            raw_input=text,
            matched_pattern="explicit_tool",
            metadata={"explicit_tool": tool_name}
        )

    # 8. chatgpt <message>
    match = PATTERN_CHATGPT.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["chatgpt"],
            brains=["language"],
            subcommand="chat",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="chatgpt",
            metadata={"platform": "chatgpt", "action": "chat"}
        )

    # 9. x <subcommand> <args> (generic)
    match = PATTERN_X_GENERIC.match(text_normalized)
    if match:
        subcommand = match.group(1).lower()
        args = match.group(2).strip() if match.group(2) else ""
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand=subcommand,
            args=args,
            raw_input=text,
            matched_pattern="x_generic",
            metadata={"platform": "x", "action": subcommand}
        )

    # 10. shell: <command>
    match = PATTERN_SHELL.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="shell_execution",
            tools=["shell"],
            brains=["coder"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="shell",
            metadata={"command": match.group(1).strip()}
        )

    # 11. python: <code>
    match = PATTERN_PYTHON.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="python_execution",
            tools=["python_sandbox"],
            brains=["coder"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="python",
            metadata={"code": match.group(1).strip()}
        )

    # 12. code: <request>
    match = PATTERN_CODE.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="coding",
            tools=[],
            brains=["coder", "reasoning"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="code",
            metadata={"request": match.group(1).strip()}
        )

    # 13. maven <action>
    match = PATTERN_MAVEN_COMMAND.match(text_normalized)
    if match:
        action = match.group(1).lower()
        extra = match.group(2).strip() if match.group(2) else ""

        if action in ("explain", "introduce", "whoami"):
            return ParsedCommand(
                intent="self_introduction",
                tools=[],
                brains=["self_model"],
                subcommand="introduction",
                args=extra,
                raw_input=text,
                matched_pattern="maven_command",
                metadata={"action": action}
            )
        elif action == "scan":
            return ParsedCommand(
                intent="self_scan",
                tools=[],
                brains=["self_model"],
                subcommand="scan",
                args=extra or "self",
                raw_input=text,
                matched_pattern="maven_command",
                metadata={"action": "scan", "target": extra or "self"}
            )
        elif action == "status":
            return ParsedCommand(
                intent="status",
                tools=[],
                brains=["self_model"],
                subcommand="status",
                args="",
                raw_input=text,
                matched_pattern="maven_command",
                metadata={"action": "status"}
            )

    # No grammar match
    return None


# =============================================================================
# SELF-INTENT GATE (Priority 0)
# =============================================================================

def _is_self_intent(query: str) -> bool:
    """Check if query is a self-intent question (any tier)."""
    if not query:
        return False
    for pattern in _COMPILED_SELF_PATTERNS:
        if pattern.search(query):
            return True
    return False


def _is_strong_self_intent(query: str) -> bool:
    """
    HYBRID MAVEN SPEC: Check if query requires explicit self_model routing.

    Strong patterns trigger full self_model brain:
    - "What are your brains?"
    - "How do you work?"
    - "Describe your architecture"
    - "How many brains do you have?"
    - "What did you just learn?"

    Weak patterns use conversation mode (reasoning + language).
    """
    if not query:
        return False
    for pattern in _COMPILED_STRONG_SELF_PATTERNS:
        if pattern.search(query):
            return True
    return False


def _is_weak_self_intent(query: str) -> bool:
    """Check if query is a weak self-intent (use conversation mode)."""
    if not query:
        return False
    # Weak = matches any self pattern but NOT strong patterns
    if _is_strong_self_intent(query):
        return False
    for pattern in _COMPILED_WEAK_SELF_PATTERNS:
        if pattern.search(query):
            return True
    return False


def _get_self_intent_type(query: str) -> Optional[str]:
    """Get the type of self-intent using the self_blocks module."""
    if not query:
        return None

    # Use new self_blocks detection if available
    if _self_blocks_available:
        intent = detect_self_intent(query)
        if intent:
            return intent.value  # e.g., "self_identity", "self_capabilities"

    # Fallback to original logic
    query_lower = query.lower()

    # Introduction patterns (most specific, with typo tolerance)
    intro_markers = [
        "explain your self", "explain yourself", "introduce yourself",
        "explaine your self", "explaine yourself",  # common typos
        "your self",  # standalone "your self" is usually about self
        "whoami", "tell grok", "tell chatgpt",
    ]
    # Also check regex for typo variants
    intro_regex = r"\bexpl[ai]+n[e]?\s*(your\s*self|yourself)\b"
    if any(m in query_lower for m in intro_markers) or re.search(intro_regex, query_lower):
        return "self_identity"  # Updated to new format

    # Capability patterns
    cap_markers = ["can you", "are you able", "what can you do", "what tools"]
    if any(m in query_lower for m in cap_markers):
        return "self_capabilities"

    # Identity patterns
    id_markers = [
        "who are you", "what are you", "yourself", "your name",
        "who made", "who created", "how do you feel",
    ]
    if any(m in query_lower for m in id_markers):
        return "self_identity"

    # Architecture patterns
    arch_markers = ["how do you work", "architecture", "how are you built", "brains communicate"]
    if any(m in query_lower for m in arch_markers):
        return "self_architecture_highlevel"

    # Comparison patterns
    comp_markers = ["chatgpt", "claude", "grok", "compare", "different from"]
    if any(m in query_lower for m in comp_markers):
        return "self_comparison"

    # History patterns
    hist_markers = ["what did we", "what did i", "do you remember"]
    if any(m in query_lower for m in hist_markers):
        return "self_history"

    # Health/diagnostics patterns
    health_markers = ["health", "status", "diagnose", "working", "broken"]
    if any(m in query_lower for m in health_markers):
        return "self_health"

    return None


def _get_introduction_target(query: str) -> Optional[str]:
    """Extract target platform for self-introduction (grok, chatgpt, etc.)."""
    if not query:
        return None

    query_lower = query.lower()

    target_patterns = [
        r"(?:explain|introduce)\s+(?:your\s*self|yourself)\s+to\s+(\w+)",
        r"tell\s+(\w+)\s+(?:about\s+yourself|who\s+you\s+are)",
    ]

    for pattern in target_patterns:
        match = re.search(pattern, query_lower)
        if match:
            target = match.group(1)
            if target in ("grok", "x", "twitter"):
                return "grok"
            elif target in ("chatgpt", "openai", "gpt"):
                return "chatgpt"
            return target

    return None


def _handle_self_intent(ctx: RoutingContext) -> RoutingDecision:
    """Handle self-intent queries by routing to self_introspection brain."""
    intent_type = _get_self_intent_type(ctx.query)
    target = _get_introduction_target(ctx.query)

    # Extract focus words for targeted answers
    focus_words = []
    if _self_blocks_available:
        focus_words = extract_focus_words(ctx.query)

    # Route to self_introspection brain (not self_model) for architecture queries
    # self_introspection uses the SystemRegistry and self_blocks for accurate info
    decision = RoutingDecision(
        brains=["self_introspection"],
        tools=[],
        intent=intent_type if intent_type else "self_query",
        confidence=1.0,
        source="self_intent_gate",
        bypass_teacher=True,  # Don't let Teacher hallucinate capabilities
    )

    # Store intent metadata for EVA/response synthesis
    decision.metadata["self_intent_type"] = intent_type
    decision.metadata["focus_words"] = focus_words

    decision.add_audit(f"SELF_INTENT_GATE: Detected {intent_type} query")
    if focus_words:
        decision.add_audit(f"Focus words: {', '.join(focus_words)}")

    # History needs system_history brain too
    if intent_type == "self_history":
        decision.brains = ["self_introspection", "system_history"]

    # Introduction to external AI = generate intro AND send to target platform
    elif intent_type == "self_identity" and target:
        decision.metadata["introduction_target"] = target
        decision.metadata["requires_tool_send"] = True
        decision.add_audit(f"Introduction target: {target}")

        # Add browser tool for sending to target
        if target in ("grok", "x"):
            decision.tools = ["x"]
            decision.subcommand = "grok"
            decision.metadata["platform"] = "x"
            decision.metadata["action"] = "grok_chat"
        elif target in ("chatgpt", "gpt", "openai"):
            decision.tools = ["chatgpt"]
            decision.subcommand = "chat"
            decision.metadata["platform"] = "chatgpt"
            decision.metadata["action"] = "chat"

    return decision


# =============================================================================
# CAPABILITY VALIDATION
# =============================================================================

def _validate_against_capabilities(
    decision: RoutingDecision,
    capability_snapshot: Dict[str, Any],
) -> RoutingDecision:
    """Validate and filter decision against system capabilities."""
    exec_mode = capability_snapshot.get("execution_mode", "UNKNOWN")
    web_enabled = capability_snapshot.get("web_research_enabled", False)
    tools_available = set(capability_snapshot.get("tools_available", []))

    valid_tools = []
    for tool in decision.tools:
        tool_base = tool.split(".")[0] if "." in tool else tool

        # Check availability
        if tool not in tools_available and tool_base not in tools_available:
            decision.add_violation(f"Tool not available: {tool}")
            continue

        # Check web tools
        if "web" in tool.lower() and not web_enabled:
            decision.add_violation(f"Web disabled: {tool}")
            continue

        # Check execution tools
        if tool_base in ("shell", "python_sandbox") and exec_mode in ("DISABLED", "SAFE_CHAT"):
            decision.add_violation(f"Execution disabled: {tool}")
            continue

        valid_tools.append(tool)

    decision.tools = valid_tools

    # Validate brains
    valid_brains = [b for b in decision.brains if b in VALID_BRAINS]
    if not valid_brains:
        valid_brains = ["language"]
        decision.add_audit("CRASH_PREVENTION: Defaulted to language brain")
    decision.brains = valid_brains

    return decision


# =============================================================================
# MAIN ROUTING FUNCTION
# =============================================================================

def build_routing_plan(
    query: str,
    capability_snapshot: Optional[Dict[str, Any]] = None,
    last_tool_name: Optional[str] = None,
    last_intent: Optional[str] = None,
    llm_router_enabled: bool = True,
    llm_confidence_threshold: float = 0.75,
) -> RoutingDecision:
    """
    Build a routing plan for a user query.

    This is the main entry point for all routing decisions.
    It follows strict precedence:
        Normalize > Grammar > Self-Intent > LLM Router > Learned > Default

    Args:
        query: The user's input text
        capability_snapshot: Current system capabilities
        last_tool_name: Last tool used (for continuation)
        last_intent: Last intent detected (for continuation)
        llm_router_enabled: Whether to use LLM router
        llm_confidence_threshold: Minimum confidence for LLM router

    Returns:
        RoutingDecision with brains, tools, and metadata
    """
    if capability_snapshot is None:
        capability_snapshot = {}

    # =========================================================================
    # STEP 0: NORMALIZE INPUT (Typo correction BEFORE routing)
    # =========================================================================
    # This fixes common typos so grammar and self-intent patterns work correctly.
    # e.g., "explaine your self" → "explain yourself"
    # e.g., "x gork helo" → "x grok hello"
    original_query = query
    normalized_query = query

    if _normalizer_available and query:
        try:
            norm_result = normalize(query)
            if norm_result.was_modified:
                normalized_query = norm_result.normalized
                print(f"[ROUTING] Normalized: '{query}' → '{normalized_query}'")
        except Exception as e:
            print(f"[ROUTING] Normalization failed: {e}, using original")

    # Build routing context with NORMALIZED query
    ctx = RoutingContext(
        query=normalized_query,  # Use normalized for routing
        capability_snapshot=capability_snapshot,
        last_tool_name=last_tool_name,
        last_intent=last_intent,
    )
    # Store original for logging/display
    ctx.metadata = {"original_query": original_query}

    # =========================================================================
    # PRIORITY -1: GRAMMAR LAYER (HARD FLOOR)
    # =========================================================================
    # Grammar runs on NORMALIZED text
    parsed = _parse_grammar(normalized_query)
    if parsed:
        ctx.grammar_matched = True
        ctx.grammar_result = parsed
        decision = parsed.to_routing_decision()
        decision.metadata["original_query"] = original_query
        decision.metadata["normalized_query"] = normalized_query
        decision = _validate_against_capabilities(decision, capability_snapshot)
        ctx.final_decision = decision
        return decision

    # =========================================================================
    # PRIORITY 0: SELF-INTENT GATE (HYBRID MAVEN SPEC)
    # =========================================================================
    # Two-tier self-intent handling:
    # - STRONG patterns -> self_introspection brain (full architecture introspection)
    # - WEAK patterns -> reasoning + language brains (conversation mode)
    #
    # This prevents over-routing to self_model, which causes:
    # - Repeated identity lines
    # - Meta answers instead of direct answers

    # Check for STRONG self-intent first (explicit architecture questions)
    if _is_strong_self_intent(normalized_query):
        ctx.self_intent_detected = True
        ctx.self_intent_type = _get_self_intent_type(normalized_query)
        ctx.introduction_target = _get_introduction_target(normalized_query)
        decision = _handle_self_intent(ctx)
        decision.metadata["original_query"] = original_query
        decision.metadata["normalized_query"] = normalized_query
        decision.metadata["self_intent_tier"] = "strong"
        decision = _validate_against_capabilities(decision, capability_snapshot)
        ctx.final_decision = decision
        return decision

    # Check for WEAK self-intent (use conversation mode instead)
    if _is_weak_self_intent(normalized_query):
        ctx.self_intent_detected = True
        ctx.self_intent_type = _get_self_intent_type(normalized_query)
        # HYBRID MAVEN: Route to reasoning + language for conversation mode
        decision = RoutingDecision(
            brains=["reasoning", "language"],
            tools=[],
            intent=ctx.self_intent_type if ctx.self_intent_type else "conversation",
            confidence=0.85,
            source="weak_self_intent:conversation_mode",
            bypass_teacher=False,  # Allow Teacher for natural conversation
        )
        decision.metadata["original_query"] = original_query
        decision.metadata["normalized_query"] = normalized_query
        decision.metadata["self_intent_tier"] = "weak"
        decision.add_audit("HYBRID_MAVEN: Weak self-intent detected, using conversation mode")
        decision = _validate_against_capabilities(decision, capability_snapshot)
        ctx.final_decision = decision
        return decision

    # =========================================================================
    # PRIORITY 0.5: LLM ROUTER (Optional - Now uses Intelligent Classifier)
    # =========================================================================
    # The intelligent classifier provides:
    # - LLM-based semantic understanding (not just keywords)
    # - Learning from user corrections
    # - Pattern caching for speed
    # - Upgrade proposal generation for persistent failures
    if llm_router_enabled:
        # Try intelligent classifier first (preferred)
        if _intelligent_classifier_available and get_llm_intent_classifier:
            try:
                classifier = get_llm_intent_classifier()
                classification = classifier.classify_intent(query, {"query": query})

                if classification and classification.confidence >= llm_confidence_threshold:
                    ctx.llm_result = LLMRouterResult(
                        brains=classification.recommended_brains,
                        tools=classification.recommended_tools,
                        confidence=classification.confidence,
                        reason=classification.reasoning,
                        raw_response=classification.to_dict(),
                    )
                    decision = ctx.llm_result.to_routing_decision()
                    decision.add_audit(f"INTELLIGENT_CLASSIFIER: {classification.primary_intent} "
                                      f"(source={classification.source})")
                    decision = _validate_against_capabilities(decision, capability_snapshot)
                    ctx.final_decision = decision
                    return decision

            except Exception as e:
                print(f"[ROUTING] Intelligent classifier failed: {e}, trying legacy router")

        # Fall back to legacy LLM router
        try:
            from brains.cognitive.router_llm import route_with_llm
            llm_result = route_with_llm(query, capability_snapshot)

            if llm_result.confidence >= llm_confidence_threshold:
                ctx.llm_result = LLMRouterResult(
                    brains=llm_result.brains,
                    tools=llm_result.tools,
                    confidence=llm_result.confidence,
                    reason=llm_result.reason,
                    raw_response=llm_result.raw_response,
                )
                decision = ctx.llm_result.to_routing_decision()
                decision = _validate_against_capabilities(decision, capability_snapshot)
                ctx.final_decision = decision
                return decision

        except ImportError:
            pass  # LLM router not available
        except Exception:
            pass  # LLM router failed, continue to next layer

    # =========================================================================
    # PRIORITY 1: LEARNED PATTERNS (routing_learning / pattern_store)
    # =========================================================================
    try:
        from brains.cognitive.pattern_store import get_best_match
        learned = get_best_match(query)
        if learned and learned.get("confidence", 0) >= 0.7:
            ctx.learned_result = learned
            decision = RoutingDecision(
                brains=learned.get("brains", ["language"]),
                tools=learned.get("tools", []),
                confidence=learned.get("confidence", 0.7),
                source="learned_pattern",
                audit_notes=[f"Learned pattern match: {learned.get('pattern', 'unknown')}"],
            )
            decision = _validate_against_capabilities(decision, capability_snapshot)
            ctx.final_decision = decision
            return decision
    except ImportError:
        pass  # Pattern store not available
    except Exception:
        pass  # Pattern lookup failed

    # =========================================================================
    # FALLBACK: SAFE DEFAULT
    # =========================================================================
    decision = RoutingDecision(
        brains=["language"],
        tools=[],
        confidence=0.3,
        source="safe_default",
        audit_notes=["FALLBACK: No patterns matched, using language brain"],
    )
    decision = _validate_against_capabilities(decision, capability_snapshot)
    ctx.final_decision = decision
    return decision


def is_explicit_command(query: str) -> bool:
    """Quick check if query is an explicit grammar command."""
    return _parse_grammar(query) is not None


# =============================================================================
# MULTI-QUESTION ROUTING (SCAN-FIRST REDESIGN)
# =============================================================================

@dataclass
class MultiQuestionPlan:
    """
    Complete routing plan for a multi-question message.

    Contains:
    - The parsed question batch
    - Routing decisions per question
    - Depth guidance per question
    - Overall metadata
    """
    question_batch: Optional[Any]  # QuestionBatch if available
    decisions: Dict[str, RoutingDecision]  # question_id -> RoutingDecision
    depth_plan: Optional[Any] = None  # BatchDepthPlan if available
    self_model: Optional[Any] = None  # SelfModel snapshot
    combined_brains: List[str] = field(default_factory=list)
    combined_tools: List[str] = field(default_factory=list)
    is_multi_question: bool = False

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return {
            "question_batch": self.question_batch.to_dict() if self.question_batch else None,
            "decisions": {
                qid: {
                    "brains": d.brains,
                    "tools": d.tools,
                    "source": d.source,
                    "confidence": d.confidence,
                }
                for qid, d in self.decisions.items()
            },
            "depth_plan": self.depth_plan.to_dict() if self.depth_plan else None,
            "combined_brains": self.combined_brains,
            "combined_tools": self.combined_tools,
            "is_multi_question": self.is_multi_question,
        }


def build_multi_question_plan(
    query: str,
    blackboard: Optional[Any] = None,
    capability_snapshot: Optional[Dict[str, Any]] = None,
) -> MultiQuestionPlan:
    """
    Build a complete routing plan for a potentially multi-question message.

    This is the main entry point for the scan-first, multi-question redesign.

    Steps:
    1. Scan first - refresh self_model if stale
    2. Parse questions - build question_batch with structure
    3. Route each question - assign brains per question
    4. Plan depth - decide how deep each answer should go
    5. Return complete plan for EVA to execute

    Args:
        query: The user message
        blackboard: Blackboard instance (optional, for storing plan)
        capability_snapshot: Current system capabilities

    Returns:
        MultiQuestionPlan with all routing information
    """
    if capability_snapshot is None:
        capability_snapshot = {}

    # Initialize plan
    plan = MultiQuestionPlan(
        question_batch=None,
        decisions={},
        combined_brains=[],
        combined_tools=[],
    )

    # =========================================================================
    # STEP 0: SCAN FIRST - Refresh self_model if needed
    # =========================================================================
    if _introspection_available and blackboard:
        try:
            plan.self_model = scan_first_if_needed(blackboard)
        except Exception as e:
            print(f"[ROUTING] Introspection failed: {e}")
    elif _introspection_available:
        try:
            plan.self_model = get_self_model()
        except Exception:
            pass

    # =========================================================================
    # STEP 1: PARSE QUESTIONS
    # =========================================================================
    if _question_parser_available:
        try:
            plan.question_batch = parse_questions(query)
            plan.question_batch = assign_brains_to_questions(plan.question_batch)
            plan.is_multi_question = plan.question_batch.count > 1
        except Exception as e:
            print(f"[ROUTING] Question parsing failed: {e}")

    # =========================================================================
    # STEP 2: ROUTE EACH QUESTION
    # =========================================================================
    if plan.question_batch:
        for question in plan.question_batch.items:
            # Build a routing decision for this specific question
            decision = _route_single_question(
                question=question,
                capability_snapshot=capability_snapshot,
            )
            plan.decisions[question.id] = decision

            # Collect combined brains/tools
            for brain in decision.brains:
                if brain not in plan.combined_brains:
                    plan.combined_brains.append(brain)
            for tool in decision.tools:
                if tool not in plan.combined_tools:
                    plan.combined_tools.append(tool)
    else:
        # Fallback: treat entire query as single question
        decision = build_routing_plan(
            query=query,
            capability_snapshot=capability_snapshot,
        )
        plan.decisions["q1"] = decision
        plan.combined_brains = decision.brains
        plan.combined_tools = decision.tools

    # =========================================================================
    # STEP 3: PLAN DEPTH
    # =========================================================================
    if _depth_planner_available and plan.question_batch:
        try:
            plan.depth_plan = plan_depth(plan.question_batch)
        except Exception as e:
            print(f"[ROUTING] Depth planning failed: {e}")

    # =========================================================================
    # STEP 4: STORE ON BLACKBOARD
    # =========================================================================
    if blackboard:
        try:
            blackboard.add_planning_decision(
                owner="routing_engine",
                decision_type="multi_question_plan",
                decision=plan.to_dict(),
                reason=f"Parsed {plan.question_batch.count if plan.question_batch else 1} questions",
            )
        except Exception as e:
            print(f"[ROUTING] Blackboard write failed: {e}")

    return plan


def _route_single_question(
    question: Any,  # ParsedQuestion
    capability_snapshot: Dict[str, Any],
) -> RoutingDecision:
    """
    Route a single parsed question to appropriate brains.

    Uses the question's topic and assigned_brains to build a RoutingDecision.
    Also includes operation hints for self-model brain based on topic.
    """
    # Get brains assigned by question parser
    brains = list(question.assigned_brains) if question.assigned_brains else ["language"]

    # Validate brains
    valid_brains = [b for b in brains if b in VALID_BRAINS]
    if not valid_brains:
        valid_brains = ["language"]

    # Build decision
    decision = RoutingDecision(
        brains=valid_brains,
        tools=[],
        confidence=0.8,
        source=f"question_parser:{question.inferred_topic.value}",
        bypass_teacher=True,  # Self questions bypass teacher
    )

    decision.metadata["question_id"] = question.id
    decision.metadata["question_topic"] = question.inferred_topic.value

    # =========================================================================
    # SELF-MODEL OPERATION HINTS
    # When self_model brain is assigned, specify which operation to use
    # based on the question topic. This ensures the right dynamic data is used.
    # =========================================================================
    topic = question.inferred_topic.value

    if "self_model" in valid_brains:
        # Map topics to self_model operations for dynamic responses
        topic_to_operation = {
            "self_description": "SELF_INTRODUCTION",     # Full dynamic intro
            "self_capabilities": "DESCRIBE_CAPABILITIES", # Real capability check
            "self_architecture": "SELF_INTRODUCTION",    # Architecture from scan
            "memory_persistence": "QUERY_SELF",          # Memory stats
            "tools_actions": "DESCRIBE_CAPABILITIES",    # Tools list
            "comparison": "SELF_INTRODUCTION",           # Comparative intro
            "routing_control": "QUERY_SELF",             # Routing info
            "learning_teacher": "QUERY_SELF",            # Learning status
            "coordination": "QUERY_SELF",                # Coordination info
        }

        operation = topic_to_operation.get(topic, "QUERY_SELF")
        decision.metadata["self_model_operation"] = operation
        decision.metadata["use_dynamic_introspection"] = True
        decision.add_audit(f"Self-model operation: {operation}")

    decision.add_audit(f"Routed question '{question.id}' to {valid_brains}")

    return decision


def get_question_batch_from_blackboard(blackboard) -> Optional[Any]:
    """
    Retrieve the question batch from the blackboard.

    Args:
        blackboard: Blackboard instance

    Returns:
        QuestionBatch if found, None otherwise
    """
    if not _question_parser_available:
        return None

    try:
        entries = blackboard.get_entries(
            lane="planning",
            owner="routing_engine",
        )

        for entry in reversed(entries):  # Most recent first
            if isinstance(entry.payload, dict):
                decision = entry.payload.get("decision")
                if decision and "question_batch" in decision:
                    batch_data = decision["question_batch"]
                    if batch_data:
                        return QuestionBatch.from_dict(batch_data)
    except Exception:
        pass

    return None


def get_depth_plan_from_blackboard(blackboard) -> Optional[Any]:
    """
    Retrieve the depth plan from the blackboard.

    Args:
        blackboard: Blackboard instance

    Returns:
        BatchDepthPlan data if found, None otherwise
    """
    try:
        entries = blackboard.get_entries(
            lane="planning",
            owner="routing_engine",
        )

        for entry in reversed(entries):
            if isinstance(entry.payload, dict):
                decision = entry.payload.get("decision")
                if decision and "depth_plan" in decision:
                    return decision["depth_plan"]
    except Exception:
        pass

    return None


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "build_routing_plan",
    "build_multi_question_plan",
    "MultiQuestionPlan",
    "is_explicit_command",
    "get_question_batch_from_blackboard",
    "get_depth_plan_from_blackboard",
    "RoutingDecision",
    "ParsedCommand",
    "RoutingContext",
]
