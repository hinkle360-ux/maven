"""
Self-Configuring Tool Discovery
===============================

Dynamic tool discovery and capability probing system that:
1. Scans for available tools at startup and on demand
2. Probes each tool to verify it actually works (not just exists)
3. Auto-registers discovered tools in a capability registry
4. Monitors tool availability and adapts when tools appear/disappear
5. Provides a unified interface for brains to query "what can I do now?"

This integrates with the existing capabilities.py but adds:
- Dynamic discovery (not just config file reading)
- Live probing (actually test if tools work)
- Hot-reload capability detection
- Tool metadata extraction

Usage:
    from brains.agent.tool_discovery import (
        discover_tools,
        probe_tool,
        get_available_tools,
        get_tool_capabilities,
        watch_for_tool_changes,
    )

    # Discover all tools
    tools = discover_tools()

    # Check if a specific tool works
    result = probe_tool("llm")

    # Get capabilities for a tool
    caps = get_tool_capabilities("filesystem")
"""

from __future__ import annotations

import importlib
import json
import time
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from brains.maven_paths import get_reports_path


# Discovery cache path
TOOL_DISCOVERY_CACHE = get_reports_path("tool_discovery_cache.json")


@dataclass
class ToolCapability:
    """A specific capability provided by a tool."""
    name: str
    description: str
    can_read: bool = False
    can_write: bool = False
    can_execute: bool = False
    can_network: bool = False
    risk_level: str = "low"  # low, medium, high
    requires_approval: bool = False


@dataclass
class DiscoveredTool:
    """A discovered tool with its metadata and capabilities."""
    tool_id: str
    name: str
    description: str = ""
    module_path: str = ""

    # Discovery status
    discovered_at: float = field(default_factory=time.time)
    last_probe_at: Optional[float] = None
    probe_success: bool = False
    probe_latency_ms: Optional[int] = None
    probe_error: Optional[str] = None

    # Capabilities
    capabilities: List[ToolCapability] = field(default_factory=list)

    # Availability
    available: bool = False
    availability_reason: str = ""

    # Metadata
    version: Optional[str] = None
    author: Optional[str] = None
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result["capabilities"] = [asdict(c) for c in self.capabilities]
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DiscoveredTool":
        caps_data = data.pop("capabilities", [])
        caps = [ToolCapability(**c) for c in caps_data]
        return cls(**data, capabilities=caps)


# Tool discovery registry
@dataclass
class ToolProbeSpec:
    """Specification for how to probe a tool."""
    module_path: str
    probe_func: Optional[str] = None  # Function to call for probing
    probe_args: Dict[str, Any] = field(default_factory=dict)
    timeout_ms: int = 5000
    capabilities: List[str] = field(default_factory=list)
    risk_level: str = "low"


# Known tools to probe
TOOL_PROBE_SPECS: Dict[str, ToolProbeSpec] = {
    "llm": ToolProbeSpec(
        module_path="brains.tools.llm_service",
        probe_func="llm_service.enabled",
        capabilities=["generate_text", "complete_prompt"],
        risk_level="low",
    ),
    "filesystem": ToolProbeSpec(
        module_path="brains.agent.tools.fs_tool",
        probe_func="is_available",
        capabilities=["read_file", "write_file", "list_directory"],
        risk_level="medium",
    ),
    "shell": ToolProbeSpec(
        module_path="brains.agent.tools.shell_tool",
        probe_func="is_available",
        capabilities=["execute_command"],
        risk_level="high",
    ),
    "python": ToolProbeSpec(
        module_path="brains.agent.tools.python_exec",
        probe_func="is_available",
        capabilities=["execute_python"],
        risk_level="high",
    ),
    "web_search": ToolProbeSpec(
        module_path="host_tools.web_client.web_client",
        probe_func="is_available",
        capabilities=["search_web", "fetch_url"],
        risk_level="medium",
    ),
    "git": ToolProbeSpec(
        module_path="brains.tools.git_tool",
        probe_func="is_available",
        capabilities=["git_status", "git_commit", "git_push"],
        risk_level="medium",
    ),
    "math": ToolProbeSpec(
        module_path="brains.agent.tools.math_tool",
        probe_func="is_available",
        capabilities=["evaluate_expression", "solve_equation"],
        risk_level="low",
    ),
    "time": ToolProbeSpec(
        module_path="brains.agent.tools.time_now",
        probe_func="is_available",
        capabilities=["get_current_time", "get_timezone"],
        risk_level="low",
    ),
    "browser": ToolProbeSpec(
        module_path="optional.browser_runtime.browser_client",
        probe_func="is_available",
        capabilities=["browse_page", "click_element", "screenshot"],
        risk_level="high",
    ),
    "vector_index": ToolProbeSpec(
        module_path="brains.memory.vector_index",
        probe_func="is_vector_index_enabled",
        capabilities=["semantic_search", "index_content"],
        risk_level="low",
    ),
    "task_scheduler": ToolProbeSpec(
        module_path="brains.agent.autonomous.task_scheduler",
        probe_func=None,  # Just check if importable
        capabilities=["schedule_task", "list_tasks", "cancel_task"],
        risk_level="low",
    ),
}


class ToolDiscovery:
    """
    Self-configuring tool discovery system.

    Discovers, probes, and monitors available tools.
    """

    def __init__(self, auto_discover: bool = True, cache_results: bool = True):
        """Initialize the discovery system."""
        self._tools: Dict[str, DiscoveredTool] = {}
        self._probe_specs = TOOL_PROBE_SPECS.copy()
        self._cache_enabled = cache_results
        self._last_discovery: float = 0
        self._discovery_interval_seconds: float = 300  # 5 minutes
        self._watchers: List[Callable[[str, bool], None]] = []

        if auto_discover:
            self._load_cache()
            self.discover_all()

    def _load_cache(self) -> None:
        """Load cached discovery results."""
        if not self._cache_enabled or not TOOL_DISCOVERY_CACHE.exists():
            return

        try:
            data = json.loads(TOOL_DISCOVERY_CACHE.read_text())
            for tool_id, tool_data in data.get("tools", {}).items():
                self._tools[tool_id] = DiscoveredTool.from_dict(tool_data)
            print(f"[TOOL_DISCOVERY] Loaded {len(self._tools)} tools from cache")
        except Exception as e:
            print(f"[TOOL_DISCOVERY] Cache load failed: {e}")

    def _save_cache(self) -> None:
        """Save discovery results to cache."""
        if not self._cache_enabled:
            return

        try:
            TOOL_DISCOVERY_CACHE.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "discovered_at": time.time(),
                "tools": {tid: t.to_dict() for tid, t in self._tools.items()}
            }
            TOOL_DISCOVERY_CACHE.write_text(json.dumps(data, indent=2))
        except Exception as e:
            print(f"[TOOL_DISCOVERY] Cache save failed: {e}")

    def register_tool_spec(self, tool_id: str, spec: ToolProbeSpec) -> None:
        """Register a new tool specification for discovery."""
        self._probe_specs[tool_id] = spec

    def discover_all(self, force: bool = False) -> Dict[str, DiscoveredTool]:
        """
        Discover and probe all known tools.

        Args:
            force: Force rediscovery even if recently done

        Returns:
            Dictionary of discovered tools
        """
        now = time.time()
        if not force and (now - self._last_discovery) < self._discovery_interval_seconds:
            return self._tools.copy()

        self._last_discovery = now
        discovered = {}

        for tool_id, spec in self._probe_specs.items():
            tool = self._discover_tool(tool_id, spec)
            if tool:
                discovered[tool_id] = tool
                # Notify watchers if availability changed
                old_tool = self._tools.get(tool_id)
                if old_tool and old_tool.available != tool.available:
                    self._notify_watchers(tool_id, tool.available)

        self._tools = discovered
        self._save_cache()

        available_count = sum(1 for t in discovered.values() if t.available)
        print(f"[TOOL_DISCOVERY] Discovered {len(discovered)} tools, {available_count} available")

        return discovered

    def _discover_tool(self, tool_id: str, spec: ToolProbeSpec) -> Optional[DiscoveredTool]:
        """Discover and probe a single tool."""
        tool = DiscoveredTool(
            tool_id=tool_id,
            name=tool_id.replace("_", " ").title(),
            module_path=spec.module_path,
            tags=spec.capabilities,
        )

        # Try to import the module
        try:
            parts = spec.module_path.rsplit(".", 1)
            if len(parts) == 2:
                module = importlib.import_module(parts[0])
                obj = getattr(module, parts[1], None)
            else:
                module = importlib.import_module(spec.module_path)
                obj = module

            # Extract metadata if available
            if hasattr(module, "__doc__") and module.__doc__:
                tool.description = module.__doc__.split("\n")[0]
            if hasattr(module, "__version__"):
                tool.version = getattr(module, "__version__")
            if hasattr(module, "__author__"):
                tool.author = getattr(module, "__author__")

            # Probe the tool
            probe_result = self._probe_tool(tool_id, spec, obj)
            tool.available = probe_result["available"]
            tool.probe_success = probe_result["success"]
            tool.probe_latency_ms = probe_result.get("latency_ms")
            tool.probe_error = probe_result.get("error")
            tool.last_probe_at = time.time()
            tool.availability_reason = probe_result.get("reason", "")

            # Build capabilities list
            for cap_name in spec.capabilities:
                tool.capabilities.append(ToolCapability(
                    name=cap_name,
                    description=f"{tool.name} {cap_name}",
                    risk_level=spec.risk_level,
                ))

        except ImportError as e:
            tool.available = False
            tool.probe_success = False
            tool.probe_error = f"Import failed: {e}"
            tool.availability_reason = "module not found"
        except Exception as e:
            tool.available = False
            tool.probe_success = False
            tool.probe_error = f"Discovery failed: {e}"
            tool.availability_reason = "discovery error"

        return tool

    def _probe_tool(self, tool_id: str, spec: ToolProbeSpec, module: Any) -> Dict[str, Any]:
        """Probe a tool to verify it actually works."""
        start = time.time()

        try:
            if spec.probe_func:
                # Navigate to the probe function
                parts = spec.probe_func.split(".")
                obj = module
                for part in parts:
                    obj = getattr(obj, part)

                # Call or evaluate the probe
                if callable(obj):
                    result = obj(**spec.probe_args)
                else:
                    result = obj  # Property or attribute

                available = bool(result)
            else:
                # No probe function - module import success means available
                available = True

            latency = int((time.time() - start) * 1000)

            return {
                "available": available,
                "success": True,
                "latency_ms": latency,
                "reason": "" if available else "probe returned false",
            }

        except Exception as e:
            return {
                "available": False,
                "success": False,
                "error": str(e),
                "reason": f"probe failed: {str(e)[:50]}",
            }

    def probe_tool(self, tool_id: str) -> Dict[str, Any]:
        """
        Probe a specific tool to check if it works.

        Args:
            tool_id: Tool identifier

        Returns:
            Probe result dictionary
        """
        spec = self._probe_specs.get(tool_id)
        if not spec:
            return {"available": False, "success": False, "error": "Unknown tool"}

        try:
            parts = spec.module_path.rsplit(".", 1)
            if len(parts) == 2:
                module = importlib.import_module(parts[0])
                obj = getattr(module, parts[1], None)
            else:
                module = importlib.import_module(spec.module_path)
                obj = module

            return self._probe_tool(tool_id, spec, obj)

        except ImportError as e:
            return {"available": False, "success": False, "error": f"Import failed: {e}"}
        except Exception as e:
            return {"available": False, "success": False, "error": str(e)}

    def get_tool(self, tool_id: str) -> Optional[DiscoveredTool]:
        """Get a discovered tool by ID."""
        return self._tools.get(tool_id)

    def get_available_tools(self) -> List[DiscoveredTool]:
        """Get all available (working) tools."""
        return [t for t in self._tools.values() if t.available]

    def get_unavailable_tools(self) -> List[DiscoveredTool]:
        """Get all unavailable tools."""
        return [t for t in self._tools.values() if not t.available]

    def get_tools_by_capability(self, capability: str) -> List[DiscoveredTool]:
        """Get tools that have a specific capability."""
        result = []
        for tool in self._tools.values():
            if any(c.name == capability for c in tool.capabilities):
                result.append(tool)
        return result

    def get_tool_capabilities(self, tool_id: str) -> List[ToolCapability]:
        """Get capabilities for a specific tool."""
        tool = self._tools.get(tool_id)
        return tool.capabilities if tool else []

    def get_all_capabilities(self) -> Dict[str, List[str]]:
        """Get all capabilities grouped by tool."""
        return {
            t.tool_id: [c.name for c in t.capabilities]
            for t in self._tools.values()
            if t.available
        }

    def can_perform(self, capability: str) -> bool:
        """Check if any available tool can perform a capability."""
        for tool in self._tools.values():
            if tool.available and any(c.name == capability for c in tool.capabilities):
                return True
        return False

    def watch_for_changes(self, callback: Callable[[str, bool], None]) -> None:
        """Register a callback for tool availability changes."""
        self._watchers.append(callback)

    def _notify_watchers(self, tool_id: str, available: bool) -> None:
        """Notify watchers of tool availability change."""
        for watcher in self._watchers:
            try:
                watcher(tool_id, available)
            except Exception:
                pass

    def get_discovery_summary(self) -> Dict[str, Any]:
        """Get a summary of discovered tools."""
        available = [t for t in self._tools.values() if t.available]
        unavailable = [t for t in self._tools.values() if not t.available]

        return {
            "total_tools": len(self._tools),
            "available_count": len(available),
            "unavailable_count": len(unavailable),
            "available_tools": [t.tool_id for t in available],
            "unavailable_tools": [
                {"id": t.tool_id, "reason": t.availability_reason}
                for t in unavailable
            ],
            "all_capabilities": list(set(
                c.name for t in available for c in t.capabilities
            )),
            "last_discovery": self._last_discovery,
        }

    def refresh(self) -> Dict[str, Any]:
        """Force a full rediscovery of all tools."""
        return self.discover_all(force=True)


# Module-level singleton
_discovery: Optional[ToolDiscovery] = None


def get_discovery() -> ToolDiscovery:
    """Get the singleton tool discovery instance."""
    global _discovery
    if _discovery is None:
        _discovery = ToolDiscovery()
    return _discovery


def discover_tools(force: bool = False) -> Dict[str, DiscoveredTool]:
    """Convenience function to discover all tools."""
    return get_discovery().discover_all(force=force)


def probe_tool(tool_id: str) -> Dict[str, Any]:
    """Convenience function to probe a specific tool."""
    return get_discovery().probe_tool(tool_id)


def get_available_tools() -> List[DiscoveredTool]:
    """Convenience function to get available tools."""
    return get_discovery().get_available_tools()


def get_tool_capabilities(tool_id: str) -> List[ToolCapability]:
    """Convenience function to get tool capabilities."""
    return get_discovery().get_tool_capabilities(tool_id)


def can_perform(capability: str) -> bool:
    """Convenience function to check if a capability is available."""
    return get_discovery().can_perform(capability)


def get_discovery_summary() -> Dict[str, Any]:
    """Convenience function to get discovery summary."""
    return get_discovery().get_discovery_summary()


def watch_for_tool_changes(callback: Callable[[str, bool], None]) -> None:
    """Convenience function to watch for tool changes."""
    get_discovery().watch_for_changes(callback)


__all__ = [
    "ToolDiscovery",
    "DiscoveredTool",
    "ToolCapability",
    "ToolProbeSpec",
    "get_discovery",
    "discover_tools",
    "probe_tool",
    "get_available_tools",
    "get_tool_capabilities",
    "can_perform",
    "get_discovery_summary",
    "watch_for_tool_changes",
]
