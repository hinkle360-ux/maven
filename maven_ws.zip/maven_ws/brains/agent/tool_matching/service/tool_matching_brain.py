"""
Tool Matching Brain
===================

Brain service for semantic tool matching in Maven's cognitive pipeline.

This brain provides natural language tool selection capabilities, enabling
the system to understand task descriptions and match them to appropriate
tools using semantic similarity matching.

Operations:
- MATCH_TASK: Match a natural language task to available tools
- GET_BEST_TOOL: Get the single best tool for a task
- SUGGEST_FOR_INTENT: Suggest tools based on intent and entities
- CAN_HANDLE: Check if any tool can handle a task
- INDEX_TOOLS: (Re)index available tool capabilities
- GET_STATS: Get matcher statistics

This is a critical component for AGI-level adaptive tool use.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from brains.memory.brain_memory import BrainMemory


# Brain memory instance
_memory = BrainMemory("tool_matching")


def handle(context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Canonical entry point for the tool matching brain.

    Args:
        context: Message context with 'op' and 'payload'

    Returns:
        Response dict with 'status' and 'payload'
    """
    op = context.get("op", "")
    payload = context.get("payload", {})

    try:
        if op == "MATCH_TASK":
            return _handle_match_task(payload)
        elif op == "GET_BEST_TOOL":
            return _handle_get_best_tool(payload)
        elif op == "SUGGEST_FOR_INTENT":
            return _handle_suggest_for_intent(payload)
        elif op == "CAN_HANDLE":
            return _handle_can_handle(payload)
        elif op == "INDEX_TOOLS":
            return _handle_index_tools(payload)
        elif op == "GET_STATS":
            return _handle_get_stats()
        else:
            return {
                "status": "error",
                "error": f"Unknown operation: {op}",
                "available_ops": [
                    "MATCH_TASK",
                    "GET_BEST_TOOL",
                    "SUGGEST_FOR_INTENT",
                    "CAN_HANDLE",
                    "INDEX_TOOLS",
                    "GET_STATS",
                ],
            }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


def _handle_match_task(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Match a natural language task description to available tools.

    Payload:
        task_description: str - Natural language task description
        top_k: int (optional) - Maximum matches to return (default: 5)
        min_score: float (optional) - Minimum score threshold (default: 0.1)

    Returns:
        matches: List of tool matches with scores and explanations
    """
    task_description = payload.get("task_description", "")
    if not task_description:
        return {
            "status": "error",
            "error": "task_description is required",
        }

    top_k = payload.get("top_k", 5)
    min_score = payload.get("min_score", 0.1)

    try:
        from brains.agent.semantic_tool_matcher import match_task_to_tools

        matches = match_task_to_tools(
            task_description=task_description,
            top_k=top_k,
            min_score=min_score,
        )

        # Store successful match in memory for learning
        if matches:
            _memory.store({
                "type": "tool_match_query",
                "task": task_description,
                "top_match": matches[0].tool_id,
                "score": matches[0].combined_score,
            })

        return {
            "status": "ok",
            "payload": {
                "matches": [m.to_dict() for m in matches],
                "match_count": len(matches),
                "best_match": matches[0].to_dict() if matches else None,
            },
        }

    except Exception as e:
        return {
            "status": "error",
            "error": f"Match failed: {str(e)}",
        }


def _handle_get_best_tool(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Get the single best tool for a task.

    Payload:
        task_description: str - Natural language task description
        min_confidence: str (optional) - "low", "medium", "high" (default: "low")

    Returns:
        tool: Best matching tool or null
    """
    task_description = payload.get("task_description", "")
    if not task_description:
        return {
            "status": "error",
            "error": "task_description is required",
        }

    min_confidence = payload.get("min_confidence", "low")

    try:
        from brains.agent.semantic_tool_matcher import get_best_tool_for_task

        best = get_best_tool_for_task(
            task_description=task_description,
            min_confidence=min_confidence,
        )

        return {
            "status": "ok",
            "payload": {
                "tool": best.to_dict() if best else None,
                "found": best is not None,
            },
        }

    except Exception as e:
        return {
            "status": "error",
            "error": f"Get best tool failed: {str(e)}",
        }


def _handle_suggest_for_intent(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Suggest tools based on a parsed intent and entities.

    Payload:
        intent: str - Detected intent
        entities: dict (optional) - Extracted entities

    Returns:
        suggestions: List of suggested tools
    """
    intent = payload.get("intent", "")
    if not intent:
        return {
            "status": "error",
            "error": "intent is required",
        }

    entities = payload.get("entities", {})

    try:
        from brains.agent.semantic_tool_matcher import suggest_tools_for_intent

        suggestions = suggest_tools_for_intent(intent=intent, entities=entities)

        return {
            "status": "ok",
            "payload": {
                "suggestions": [s.to_dict() for s in suggestions],
                "suggestion_count": len(suggestions),
            },
        }

    except Exception as e:
        return {
            "status": "error",
            "error": f"Suggest failed: {str(e)}",
        }


def _handle_can_handle(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Check if any tool can handle a task.

    Payload:
        task_description: str - Natural language task description
        confidence: str (optional) - "low", "medium", "high" (default: "medium")

    Returns:
        can_handle: bool - True if a tool can handle the task
    """
    task_description = payload.get("task_description", "")
    if not task_description:
        return {
            "status": "error",
            "error": "task_description is required",
        }

    confidence = payload.get("confidence", "medium")

    try:
        from brains.agent.semantic_tool_matcher import can_handle_task

        can_handle = can_handle_task(
            task_description=task_description,
            confidence=confidence,
        )

        return {
            "status": "ok",
            "payload": {
                "can_handle": can_handle,
            },
        }

    except Exception as e:
        return {
            "status": "error",
            "error": f"Check failed: {str(e)}",
        }


def _handle_index_tools(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Index or reindex tool capabilities.

    Payload:
        force: bool (optional) - Force reindexing (default: False)

    Returns:
        indexed_count: Number of capabilities indexed
    """
    force = payload.get("force", False)

    try:
        from brains.agent.semantic_tool_matcher import index_tool_capabilities

        count = index_tool_capabilities(force=force)

        return {
            "status": "ok",
            "payload": {
                "indexed_count": count,
            },
        }

    except Exception as e:
        return {
            "status": "error",
            "error": f"Index failed: {str(e)}",
        }


def _handle_get_stats() -> Dict[str, Any]:
    """
    Get matcher statistics.

    Returns:
        stats: Matcher statistics
    """
    try:
        from brains.agent.semantic_tool_matcher import get_matcher_stats

        stats = get_matcher_stats()

        return {
            "status": "ok",
            "payload": {
                "stats": stats,
            },
        }

    except Exception as e:
        return {
            "status": "error",
            "error": f"Get stats failed: {str(e)}",
        }


# Canonical alias
service_api = handle


# Convenience functions for direct use by other brains
def match_task(task_description: str, top_k: int = 5) -> List[Dict[str, Any]]:
    """Quick helper to match a task to tools."""
    result = handle({
        "op": "MATCH_TASK",
        "payload": {
            "task_description": task_description,
            "top_k": top_k,
        },
    })
    if result.get("status") == "ok":
        return result.get("payload", {}).get("matches", [])
    return []


def get_best_tool(task_description: str) -> Optional[Dict[str, Any]]:
    """Quick helper to get the best tool for a task."""
    result = handle({
        "op": "GET_BEST_TOOL",
        "payload": {
            "task_description": task_description,
        },
    })
    if result.get("status") == "ok":
        return result.get("payload", {}).get("tool")
    return None


def can_handle(task_description: str) -> bool:
    """Quick helper to check if a task can be handled."""
    result = handle({
        "op": "CAN_HANDLE",
        "payload": {
            "task_description": task_description,
        },
    })
    if result.get("status") == "ok":
        return result.get("payload", {}).get("can_handle", False)
    return False
