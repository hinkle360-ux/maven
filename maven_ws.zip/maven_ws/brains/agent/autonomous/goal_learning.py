"""
Cross-Session Goal Learning
============================

Persistent goal learning system that enables Maven to:
1. Track goal success/failure rates across sessions
2. Learn retry strategies from failures
3. Store and reuse goal templates
4. Persist long-term objectives in LTM

This is a critical AGI competency for autonomous goal management - the
ability to learn from past goal executions and adapt strategies accordingly.

Usage:
    from brains.agent.autonomous.goal_learning import (
        track_goal_outcome,
        get_goal_success_rate,
        learn_retry_strategy,
        store_goal_template,
        suggest_goals_for_context,
        GoalLearner,
    )

    # Track a goal outcome
    track_goal_outcome(
        goal_id="goal_123",
        goal_type="implementation",
        success=True,
        execution_time_ms=5000,
    )

    # Get success rate for goal type
    rate = get_goal_success_rate("implementation")  # Returns 0.85

    # Learn what retry strategy works
    strategy = learn_retry_strategy("file_operation")

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import json
import time
import hashlib
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from brains.memory.brain_memory import BrainMemory


# Goal learning memory - uses LTM for cross-session persistence
_memory = BrainMemory("goal_learning")


class GoalOutcome(Enum):
    """Possible goal outcomes."""
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    TIMEOUT = "timeout"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"


class RetryStrategy(Enum):
    """Retry strategies learned from failures."""
    IMMEDIATE = "immediate"      # Retry immediately
    EXPONENTIAL_BACKOFF = "exponential_backoff"  # Wait longer each time
    DIFFERENT_APPROACH = "different_approach"    # Try different method
    SIMPLIFY = "simplify"        # Break into smaller tasks
    ESCALATE = "escalate"        # Ask for help/input
    ABORT = "abort"              # Don't retry this type
    WAIT_FOR_CONDITION = "wait_for_condition"    # Wait for external change


@dataclass
class GoalOutcomeRecord:
    """Record of a goal execution outcome."""
    goal_id: str
    goal_type: str
    goal_title: str
    outcome: GoalOutcome
    execution_time_ms: int
    error_message: Optional[str] = None
    retry_count: int = 0
    context: Dict[str, Any] = field(default_factory=dict)
    timestamp: float = field(default_factory=time.time)
    session_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "goal_id": self.goal_id,
            "goal_type": self.goal_type,
            "goal_title": self.goal_title,
            "outcome": self.outcome.value,
            "execution_time_ms": self.execution_time_ms,
            "error_message": self.error_message,
            "retry_count": self.retry_count,
            "context": self.context,
            "timestamp": self.timestamp,
            "session_id": self.session_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GoalOutcomeRecord":
        record = cls(
            goal_id=data["goal_id"],
            goal_type=data["goal_type"],
            goal_title=data.get("goal_title", ""),
            outcome=GoalOutcome(data.get("outcome", "success")),
            execution_time_ms=data.get("execution_time_ms", 0),
            error_message=data.get("error_message"),
            retry_count=data.get("retry_count", 0),
            context=data.get("context", {}),
            session_id=data.get("session_id"),
        )
        record.timestamp = data.get("timestamp", time.time())
        return record


@dataclass
class GoalTemplate:
    """A reusable goal template."""
    template_id: str
    name: str
    description: str
    goal_type: str
    pattern: str  # Regex pattern to match user requests
    default_params: Dict[str, Any] = field(default_factory=dict)
    success_rate: float = 0.0
    avg_execution_time_ms: int = 0
    usage_count: int = 0
    last_used: Optional[float] = None
    created_at: float = field(default_factory=time.time)
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "template_id": self.template_id,
            "name": self.name,
            "description": self.description,
            "goal_type": self.goal_type,
            "pattern": self.pattern,
            "default_params": self.default_params,
            "success_rate": self.success_rate,
            "avg_execution_time_ms": self.avg_execution_time_ms,
            "usage_count": self.usage_count,
            "last_used": self.last_used,
            "created_at": self.created_at,
            "tags": self.tags,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GoalTemplate":
        return cls(
            template_id=data["template_id"],
            name=data["name"],
            description=data.get("description", ""),
            goal_type=data.get("goal_type", "generic"),
            pattern=data.get("pattern", ""),
            default_params=data.get("default_params", {}),
            success_rate=data.get("success_rate", 0.0),
            avg_execution_time_ms=data.get("avg_execution_time_ms", 0),
            usage_count=data.get("usage_count", 0),
            last_used=data.get("last_used"),
            created_at=data.get("created_at", time.time()),
            tags=data.get("tags", []),
        )


@dataclass
class RetryStrategyLearning:
    """Learned retry strategy for a goal type."""
    goal_type: str
    best_strategy: RetryStrategy
    success_by_strategy: Dict[str, int] = field(default_factory=dict)
    failure_by_strategy: Dict[str, int] = field(default_factory=dict)
    avg_retries_to_success: float = 0.0
    max_retries_observed: int = 0
    last_updated: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "goal_type": self.goal_type,
            "best_strategy": self.best_strategy.value,
            "success_by_strategy": self.success_by_strategy,
            "failure_by_strategy": self.failure_by_strategy,
            "avg_retries_to_success": self.avg_retries_to_success,
            "max_retries_observed": self.max_retries_observed,
            "last_updated": self.last_updated,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RetryStrategyLearning":
        learning = cls(
            goal_type=data["goal_type"],
            best_strategy=RetryStrategy(data.get("best_strategy", "immediate")),
        )
        learning.success_by_strategy = data.get("success_by_strategy", {})
        learning.failure_by_strategy = data.get("failure_by_strategy", {})
        learning.avg_retries_to_success = data.get("avg_retries_to_success", 0.0)
        learning.max_retries_observed = data.get("max_retries_observed", 0)
        learning.last_updated = data.get("last_updated", time.time())
        return learning


class GoalLearner:
    """
    Cross-session goal learning system.

    Tracks goal outcomes, learns retry strategies, and manages goal templates
    for improved autonomous goal management.
    """

    # Default goal type patterns for classification
    GOAL_TYPE_PATTERNS: Dict[str, List[str]] = {
        "implementation": ["implement", "build", "create", "develop", "code", "write"],
        "debugging": ["debug", "fix", "troubleshoot", "diagnose", "resolve"],
        "research": ["research", "investigate", "study", "analyze", "understand"],
        "configuration": ["configure", "setup", "install", "deploy"],
        "documentation": ["document", "write docs", "readme"],
        "testing": ["test", "verify", "validate", "check"],
        "data_processing": ["process", "transform", "convert", "parse", "extract"],
        "file_operation": ["read file", "write file", "copy", "move", "delete"],
        "web_operation": ["fetch", "scrape", "download", "api call"],
        "git_operation": ["commit", "push", "pull", "merge", "branch"],
    }

    def __init__(self, session_id: Optional[str] = None):
        """Initialize the goal learner."""
        self.session_id = session_id or self._generate_session_id()
        self._outcome_cache: Dict[str, List[GoalOutcomeRecord]] = {}
        self._template_cache: Dict[str, GoalTemplate] = {}
        self._strategy_cache: Dict[str, RetryStrategyLearning] = {}
        self._load_from_memory()

    def _generate_session_id(self) -> str:
        """Generate a unique session ID."""
        return hashlib.md5(f"{time.time()}".encode()).hexdigest()[:8]

    def _load_from_memory(self) -> None:
        """Load cached data from memory."""
        try:
            # Load outcome records (limited to recent)
            results = _memory.retrieve(
                query="kind:goal_outcome",
                limit=100,
                tiers=["stm", "mtm", "ltm"]
            )
            for result in results:
                metadata = result.get("metadata", {})
                if metadata.get("kind") == "goal_outcome":
                    record = GoalOutcomeRecord.from_dict(result.get("content", {}))
                    goal_type = record.goal_type
                    if goal_type not in self._outcome_cache:
                        self._outcome_cache[goal_type] = []
                    self._outcome_cache[goal_type].append(record)

            # Load templates
            results = _memory.retrieve(
                query="kind:goal_template",
                limit=50,
                tiers=["mtm", "ltm"]
            )
            for result in results:
                metadata = result.get("metadata", {})
                if metadata.get("kind") == "goal_template":
                    template = GoalTemplate.from_dict(result.get("content", {}))
                    self._template_cache[template.template_id] = template

            # Load retry strategies
            results = _memory.retrieve(
                query="kind:retry_strategy",
                limit=20,
                tiers=["mtm", "ltm"]
            )
            for result in results:
                metadata = result.get("metadata", {})
                if metadata.get("kind") == "retry_strategy":
                    learning = RetryStrategyLearning.from_dict(result.get("content", {}))
                    self._strategy_cache[learning.goal_type] = learning

            print(f"[GOAL_LEARNER] Loaded {sum(len(v) for v in self._outcome_cache.values())} outcomes, "
                  f"{len(self._template_cache)} templates, {len(self._strategy_cache)} strategies")

        except Exception as e:
            print(f"[GOAL_LEARNER] Failed to load from memory: {e}")

    def classify_goal_type(self, goal_title: str) -> str:
        """
        Classify a goal into a type based on its title.

        Args:
            goal_title: The goal's title/description

        Returns:
            Goal type string
        """
        title_lower = goal_title.lower()

        for goal_type, patterns in self.GOAL_TYPE_PATTERNS.items():
            for pattern in patterns:
                if pattern in title_lower:
                    return goal_type

        return "generic"

    def track_outcome(
        self,
        goal_id: str,
        goal_title: str,
        outcome: GoalOutcome,
        execution_time_ms: int = 0,
        error_message: Optional[str] = None,
        retry_count: int = 0,
        context: Optional[Dict[str, Any]] = None,
        goal_type: Optional[str] = None,
    ) -> GoalOutcomeRecord:
        """
        Track the outcome of a goal execution.

        Args:
            goal_id: Unique goal identifier
            goal_title: Goal description
            outcome: Execution outcome
            execution_time_ms: Execution duration
            error_message: Error if failed
            retry_count: Number of retries attempted
            context: Additional context
            goal_type: Goal type (auto-classified if not provided)

        Returns:
            The created outcome record
        """
        if goal_type is None:
            goal_type = self.classify_goal_type(goal_title)

        record = GoalOutcomeRecord(
            goal_id=goal_id,
            goal_type=goal_type,
            goal_title=goal_title,
            outcome=outcome,
            execution_time_ms=execution_time_ms,
            error_message=error_message,
            retry_count=retry_count,
            context=context or {},
            session_id=self.session_id,
        )

        # Cache locally
        if goal_type not in self._outcome_cache:
            self._outcome_cache[goal_type] = []
        self._outcome_cache[goal_type].append(record)

        # Store in memory (LTM for cross-session persistence)
        try:
            _memory.store(
                content=record.to_dict(),
                metadata={
                    "kind": "goal_outcome",
                    "goal_type": goal_type,
                    "outcome": outcome.value,
                    "session_id": self.session_id,
                }
            )
        except Exception:
            pass

        # Update retry strategy learning if applicable
        if outcome in (GoalOutcome.SUCCESS, GoalOutcome.FAILURE):
            self._update_retry_learning(goal_type, outcome, retry_count)

        print(f"[GOAL_LEARNER] Tracked {outcome.value} for {goal_type}: {goal_title[:50]}...")

        return record

    def _update_retry_learning(
        self,
        goal_type: str,
        outcome: GoalOutcome,
        retry_count: int,
    ) -> None:
        """Update retry strategy learning based on outcome."""
        if goal_type not in self._strategy_cache:
            self._strategy_cache[goal_type] = RetryStrategyLearning(
                goal_type=goal_type,
                best_strategy=RetryStrategy.IMMEDIATE,
            )

        learning = self._strategy_cache[goal_type]
        learning.max_retries_observed = max(learning.max_retries_observed, retry_count)
        learning.last_updated = time.time()

        # Infer which strategy was used based on retry count
        if retry_count == 0:
            strategy_used = "immediate"
        elif retry_count <= 2:
            strategy_used = "immediate"
        elif retry_count <= 5:
            strategy_used = "exponential_backoff"
        else:
            strategy_used = "different_approach"

        if outcome == GoalOutcome.SUCCESS:
            learning.success_by_strategy[strategy_used] = (
                learning.success_by_strategy.get(strategy_used, 0) + 1
            )

            # Update average retries to success
            total_successes = sum(learning.success_by_strategy.values())
            if total_successes > 0:
                # Simple average (could be weighted)
                learning.avg_retries_to_success = (
                    (learning.avg_retries_to_success * (total_successes - 1) + retry_count)
                    / total_successes
                )

        else:
            learning.failure_by_strategy[strategy_used] = (
                learning.failure_by_strategy.get(strategy_used, 0) + 1
            )

        # Determine best strategy based on success rates
        best_rate = 0.0
        for strategy in learning.success_by_strategy:
            successes = learning.success_by_strategy.get(strategy, 0)
            failures = learning.failure_by_strategy.get(strategy, 0)
            total = successes + failures
            if total > 0:
                rate = successes / total
                if rate > best_rate:
                    best_rate = rate
                    try:
                        learning.best_strategy = RetryStrategy(strategy)
                    except ValueError:
                        pass

        # Store updated learning
        try:
            _memory.store(
                content=learning.to_dict(),
                metadata={
                    "kind": "retry_strategy",
                    "goal_type": goal_type,
                    "best_strategy": learning.best_strategy.value,
                }
            )
        except Exception:
            pass

    def get_success_rate(self, goal_type: str, time_window_days: int = 30) -> float:
        """
        Get the success rate for a goal type.

        Args:
            goal_type: Type of goal
            time_window_days: Consider only outcomes within this window

        Returns:
            Success rate (0.0 to 1.0)
        """
        outcomes = self._outcome_cache.get(goal_type, [])
        if not outcomes:
            return 0.0

        cutoff = time.time() - (time_window_days * 86400)
        recent = [o for o in outcomes if o.timestamp >= cutoff]

        if not recent:
            return 0.0

        successes = sum(1 for o in recent if o.outcome == GoalOutcome.SUCCESS)
        return successes / len(recent)

    def get_retry_strategy(self, goal_type: str) -> RetryStrategy:
        """
        Get the best retry strategy for a goal type.

        Args:
            goal_type: Type of goal

        Returns:
            Recommended retry strategy
        """
        learning = self._strategy_cache.get(goal_type)
        if learning:
            return learning.best_strategy

        # Default strategies based on goal type
        defaults = {
            "file_operation": RetryStrategy.IMMEDIATE,
            "web_operation": RetryStrategy.EXPONENTIAL_BACKOFF,
            "git_operation": RetryStrategy.WAIT_FOR_CONDITION,
            "implementation": RetryStrategy.DIFFERENT_APPROACH,
            "debugging": RetryStrategy.DIFFERENT_APPROACH,
        }
        return defaults.get(goal_type, RetryStrategy.IMMEDIATE)

    def store_template(
        self,
        name: str,
        description: str,
        pattern: str,
        goal_type: Optional[str] = None,
        default_params: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> GoalTemplate:
        """
        Store a reusable goal template.

        Args:
            name: Template name
            description: What this template does
            pattern: Regex pattern to match user requests
            goal_type: Goal type classification
            default_params: Default parameters
            tags: Categorization tags

        Returns:
            The created template
        """
        template_id = hashlib.md5(f"{name}:{pattern}".encode()).hexdigest()[:10]

        template = GoalTemplate(
            template_id=template_id,
            name=name,
            description=description,
            goal_type=goal_type or self.classify_goal_type(description),
            pattern=pattern,
            default_params=default_params or {},
            tags=tags or [],
        )

        self._template_cache[template_id] = template

        # Store in LTM
        try:
            _memory.store(
                content=template.to_dict(),
                metadata={
                    "kind": "goal_template",
                    "template_id": template_id,
                    "name": name,
                    "goal_type": template.goal_type,
                }
            )
        except Exception:
            pass

        print(f"[GOAL_LEARNER] Stored template: {name}")
        return template

    def suggest_goals(self, context: str, limit: int = 5) -> List[GoalTemplate]:
        """
        Suggest goals based on context.

        Args:
            context: Current context/user input
            limit: Maximum suggestions

        Returns:
            List of matching templates sorted by success rate
        """
        import re

        matches: List[Tuple[GoalTemplate, float]] = []
        context_lower = context.lower()

        for template in self._template_cache.values():
            # Check pattern match
            try:
                if re.search(template.pattern, context_lower, re.IGNORECASE):
                    # Score by success rate and recency
                    score = template.success_rate
                    if template.last_used:
                        age_days = (time.time() - template.last_used) / 86400
                        recency_bonus = max(0, 0.2 - (age_days * 0.01))
                        score += recency_bonus
                    matches.append((template, score))
            except re.error:
                continue

        # Sort by score
        matches.sort(key=lambda x: x[1], reverse=True)
        return [m[0] for m in matches[:limit]]

    def get_statistics(self) -> Dict[str, Any]:
        """Get learning statistics."""
        total_outcomes = sum(len(v) for v in self._outcome_cache.values())
        success_count = sum(
            sum(1 for o in outcomes if o.outcome == GoalOutcome.SUCCESS)
            for outcomes in self._outcome_cache.values()
        )

        return {
            "total_outcomes_tracked": total_outcomes,
            "total_templates": len(self._template_cache),
            "total_strategies_learned": len(self._strategy_cache),
            "overall_success_rate": success_count / total_outcomes if total_outcomes > 0 else 0.0,
            "goal_types_tracked": list(self._outcome_cache.keys()),
            "session_id": self.session_id,
        }


# Module-level singleton
_learner: Optional[GoalLearner] = None


def get_learner(session_id: Optional[str] = None) -> GoalLearner:
    """Get the singleton goal learner."""
    global _learner
    if _learner is None:
        _learner = GoalLearner(session_id)
    return _learner


def track_goal_outcome(
    goal_id: str,
    goal_title: str,
    success: bool,
    execution_time_ms: int = 0,
    error_message: Optional[str] = None,
    retry_count: int = 0,
    context: Optional[Dict[str, Any]] = None,
    goal_type: Optional[str] = None,
) -> GoalOutcomeRecord:
    """Convenience function to track a goal outcome."""
    outcome = GoalOutcome.SUCCESS if success else GoalOutcome.FAILURE
    return get_learner().track_outcome(
        goal_id=goal_id,
        goal_title=goal_title,
        outcome=outcome,
        execution_time_ms=execution_time_ms,
        error_message=error_message,
        retry_count=retry_count,
        context=context,
        goal_type=goal_type,
    )


def get_goal_success_rate(goal_type: str, time_window_days: int = 30) -> float:
    """Convenience function to get success rate."""
    return get_learner().get_success_rate(goal_type, time_window_days)


def learn_retry_strategy(goal_type: str) -> RetryStrategy:
    """Convenience function to get retry strategy."""
    return get_learner().get_retry_strategy(goal_type)


def store_goal_template(
    name: str,
    description: str,
    pattern: str,
    goal_type: Optional[str] = None,
    default_params: Optional[Dict[str, Any]] = None,
    tags: Optional[List[str]] = None,
) -> GoalTemplate:
    """Convenience function to store a template."""
    return get_learner().store_template(
        name=name,
        description=description,
        pattern=pattern,
        goal_type=goal_type,
        default_params=default_params,
        tags=tags,
    )


def suggest_goals_for_context(context: str, limit: int = 5) -> List[GoalTemplate]:
    """Convenience function to suggest goals."""
    return get_learner().suggest_goals(context, limit)


def get_learning_statistics() -> Dict[str, Any]:
    """Convenience function to get statistics."""
    return get_learner().get_statistics()


# Public API
__all__ = [
    "GoalOutcome",
    "RetryStrategy",
    "GoalOutcomeRecord",
    "GoalTemplate",
    "RetryStrategyLearning",
    "GoalLearner",
    "get_learner",
    "track_goal_outcome",
    "get_goal_success_rate",
    "learn_retry_strategy",
    "store_goal_template",
    "suggest_goals_for_context",
    "get_learning_statistics",
]
