"""
Omniscient Observer - Maven's Perpetual Learning System

Maven as a hungry-for-knowledge system that continuously:
1. Monitors web sources (Twitter, Reddit, HN, ArXiv, etc.)
2. Learns patterns from everything it observes
3. Builds world models and user models
4. Only interrupts when something truly important is found

This is Maven's "always watching, always learning" mode.

Architecture:
- OmniscientObserver: Main controller for continuous observation
- ObservationSource: Abstraction for different data sources
- WorldModel: Tracks external world knowledge
- UserModel: Tracks user patterns and preferences
"""

from __future__ import annotations

import threading
import time
import json
import hashlib
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Dict, List, Any, Optional, Callable, Set
from queue import Queue, Empty

# Import Maven components
try:
    from brains.memory.brain_memory import BrainMemory
except ImportError:
    BrainMemory = None  # type: ignore

try:
    from brains.maven_paths import get_reports_path, get_data_path
except ImportError:
    def get_reports_path():
        return Path("./reports")
    def get_data_path():
        return Path("./data")


# ============================================================================
# Enums and Data Classes
# ============================================================================

class ObservationPriority(Enum):
    """Priority levels for observations."""
    BACKGROUND = "background"      # Low priority, batch process
    NORMAL = "normal"              # Standard observation
    ELEVATED = "elevated"          # Worth noting
    IMPORTANT = "important"        # Should remember
    CRITICAL = "critical"          # Might warrant interruption


class SourceType(Enum):
    """Types of observation sources."""
    WEB_FEED = "web_feed"          # RSS, Twitter, etc.
    API = "api"                    # External APIs
    LOCAL_FILE = "local_file"     # File system changes
    USER_ACTIVITY = "user_activity"  # User behavior
    SYSTEM_EVENT = "system_event"   # Internal events
    SYNTHESIZED = "synthesized"    # Derived insights


@dataclass
class Observation:
    """A single observation from any source."""
    id: str
    source: str
    source_type: SourceType
    content: str
    timestamp: float
    priority: ObservationPriority
    metadata: Dict[str, Any] = field(default_factory=dict)
    patterns_detected: List[str] = field(default_factory=list)
    entities: List[str] = field(default_factory=list)
    relevance_score: float = 0.5
    processed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["source_type"] = self.source_type.value
        d["priority"] = self.priority.value
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Observation":
        data["source_type"] = SourceType(data.get("source_type", "web_feed"))
        data["priority"] = ObservationPriority(data.get("priority", "normal"))
        return cls(**data)


@dataclass
class WorldFact:
    """A fact about the external world."""
    id: str
    content: str
    domain: str
    confidence: float
    source_observations: List[str]  # Observation IDs that support this
    first_seen: float
    last_confirmed: float
    contradiction_count: int = 0
    confirmation_count: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class UserPattern:
    """A learned pattern about the user."""
    id: str
    pattern_type: str  # "interest", "schedule", "preference", "behavior"
    description: str
    confidence: float
    evidence: List[str]  # Observation IDs supporting this
    first_observed: float
    last_observed: float
    occurrence_count: int = 1

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# ============================================================================
# World Model - Tracks external knowledge
# ============================================================================

class WorldModel:
    """
    Maven's model of the external world.

    Tracks facts, trends, events, and entities observed from various sources.
    Facts are versioned and can be confirmed or contradicted over time.
    """

    def __init__(self, persistence_path: Optional[Path] = None):
        self.facts: Dict[str, WorldFact] = {}
        self.domains: Dict[str, Set[str]] = {}  # domain -> fact IDs
        self.entities: Dict[str, Set[str]] = {}  # entity -> fact IDs
        self.trends: Dict[str, List[Dict[str, Any]]] = {}  # trend tracking

        self.persistence_path = persistence_path or (get_data_path() / "world_model.json")
        self._lock = threading.Lock()
        self._load()

    def _generate_id(self, content: str) -> str:
        """Generate deterministic ID from content."""
        return f"wf_{hashlib.md5(content.encode()).hexdigest()[:12]}"

    def _load(self) -> None:
        """Load world model from disk."""
        if self.persistence_path.exists():
            try:
                with open(self.persistence_path, 'r') as f:
                    data = json.load(f)
                self.facts = {k: WorldFact(**v) for k, v in data.get("facts", {}).items()}
                self.domains = {k: set(v) for k, v in data.get("domains", {}).items()}
                self.entities = {k: set(v) for k, v in data.get("entities", {}).items()}
                self.trends = data.get("trends", {})
            except Exception:
                pass

    def _save(self) -> None:
        """Persist world model to disk."""
        try:
            self.persistence_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "facts": {k: v.to_dict() for k, v in self.facts.items()},
                "domains": {k: list(v) for k, v in self.domains.items()},
                "entities": {k: list(v) for k, v in self.entities.items()},
                "trends": self.trends,
            }
            with open(self.persistence_path, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def add_fact(
        self,
        content: str,
        domain: str,
        confidence: float,
        observation_id: str,
        entities: Optional[List[str]] = None
    ) -> WorldFact:
        """
        Add or update a fact in the world model.

        If the fact exists, confirm it. If contradicted, track that too.
        """
        with self._lock:
            fact_id = self._generate_id(content)
            now = time.time()

            if fact_id in self.facts:
                # Existing fact - confirm it
                existing = self.facts[fact_id]
                existing.confirmation_count += 1
                existing.last_confirmed = now
                existing.confidence = min(1.0, existing.confidence + 0.05)
                if observation_id not in existing.source_observations:
                    existing.source_observations.append(observation_id)
                return existing
            else:
                # New fact
                fact = WorldFact(
                    id=fact_id,
                    content=content,
                    domain=domain,
                    confidence=confidence,
                    source_observations=[observation_id],
                    first_seen=now,
                    last_confirmed=now,
                )
                self.facts[fact_id] = fact

                # Index by domain
                if domain not in self.domains:
                    self.domains[domain] = set()
                self.domains[domain].add(fact_id)

                # Index by entities
                for entity in (entities or []):
                    if entity not in self.entities:
                        self.entities[entity] = set()
                    self.entities[entity].add(fact_id)

                self._save()
                return fact

    def contradict_fact(self, fact_id: str, observation_id: str) -> None:
        """Record that an observation contradicts a fact."""
        with self._lock:
            if fact_id in self.facts:
                fact = self.facts[fact_id]
                fact.contradiction_count += 1
                fact.confidence = max(0.1, fact.confidence - 0.1)
                self._save()

    def get_facts_by_domain(self, domain: str, min_confidence: float = 0.5) -> List[WorldFact]:
        """Get all facts in a domain above confidence threshold."""
        fact_ids = self.domains.get(domain, set())
        return [
            self.facts[fid] for fid in fact_ids
            if fid in self.facts and self.facts[fid].confidence >= min_confidence
        ]

    def get_facts_about_entity(self, entity: str, min_confidence: float = 0.5) -> List[WorldFact]:
        """Get all facts about a specific entity."""
        fact_ids = self.entities.get(entity, set())
        return [
            self.facts[fid] for fid in fact_ids
            if fid in self.facts and self.facts[fid].confidence >= min_confidence
        ]

    def track_trend(self, topic: str, sentiment: float, observation_id: str) -> None:
        """Track a trend over time."""
        with self._lock:
            if topic not in self.trends:
                self.trends[topic] = []
            self.trends[topic].append({
                "timestamp": time.time(),
                "sentiment": sentiment,
                "observation": observation_id,
            })
            # Keep last 100 data points per trend
            self.trends[topic] = self.trends[topic][-100:]
            self._save()

    def get_trend_momentum(self, topic: str) -> Optional[Dict[str, Any]]:
        """Analyze trend momentum for a topic."""
        if topic not in self.trends or len(self.trends[topic]) < 3:
            return None

        points = self.trends[topic]
        recent = points[-10:]
        older = points[-20:-10] if len(points) >= 20 else points[:len(points)//2]

        recent_avg = sum(p["sentiment"] for p in recent) / len(recent)
        older_avg = sum(p["sentiment"] for p in older) / len(older) if older else 0.5

        return {
            "topic": topic,
            "current_sentiment": recent_avg,
            "momentum": recent_avg - older_avg,
            "data_points": len(points),
            "trend_direction": "rising" if recent_avg > older_avg else "falling" if recent_avg < older_avg else "stable"
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get world model statistics."""
        return {
            "total_facts": len(self.facts),
            "domains": list(self.domains.keys()),
            "entities_tracked": len(self.entities),
            "trends_tracked": len(self.trends),
            "high_confidence_facts": sum(1 for f in self.facts.values() if f.confidence > 0.8),
        }


# ============================================================================
# User Model - Tracks user patterns
# ============================================================================

class UserModel:
    """
    Maven's model of the user.

    Tracks interests, preferences, schedules, and behavioral patterns.
    Used to personalize responses and anticipate needs.
    """

    def __init__(self, persistence_path: Optional[Path] = None):
        self.patterns: Dict[str, UserPattern] = {}
        self.interests: Dict[str, float] = {}  # topic -> interest level
        self.activity_log: List[Dict[str, Any]] = []  # Recent activity
        self.preferences: Dict[str, Any] = {}  # Explicit preferences

        self.persistence_path = persistence_path or (get_data_path() / "user_model.json")
        self._lock = threading.Lock()
        self._load()

    def _generate_id(self, content: str) -> str:
        """Generate deterministic ID."""
        return f"up_{hashlib.md5(content.encode()).hexdigest()[:12]}"

    def _load(self) -> None:
        """Load user model from disk."""
        if self.persistence_path.exists():
            try:
                with open(self.persistence_path, 'r') as f:
                    data = json.load(f)
                self.patterns = {k: UserPattern(**v) for k, v in data.get("patterns", {}).items()}
                self.interests = data.get("interests", {})
                self.activity_log = data.get("activity_log", [])[-1000:]  # Keep last 1000
                self.preferences = data.get("preferences", {})
            except Exception:
                pass

    def _save(self) -> None:
        """Persist user model to disk."""
        try:
            self.persistence_path.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "patterns": {k: v.to_dict() for k, v in self.patterns.items()},
                "interests": self.interests,
                "activity_log": self.activity_log[-1000:],
                "preferences": self.preferences,
            }
            with open(self.persistence_path, 'w') as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass

    def record_activity(self, activity_type: str, details: Dict[str, Any]) -> None:
        """Record a user activity for pattern detection."""
        with self._lock:
            self.activity_log.append({
                "type": activity_type,
                "details": details,
                "timestamp": time.time(),
            })
            self.activity_log = self.activity_log[-1000:]  # Trim
            self._save()

    def update_interest(self, topic: str, delta: float, observation_id: str = "") -> None:
        """Update interest level in a topic."""
        with self._lock:
            current = self.interests.get(topic, 0.5)
            self.interests[topic] = max(0.0, min(1.0, current + delta))

            # Create or update interest pattern
            pattern_id = self._generate_id(f"interest:{topic}")
            now = time.time()

            if pattern_id in self.patterns:
                pattern = self.patterns[pattern_id]
                pattern.confidence = self.interests[topic]
                pattern.last_observed = now
                pattern.occurrence_count += 1
                if observation_id and observation_id not in pattern.evidence:
                    pattern.evidence.append(observation_id)
            else:
                self.patterns[pattern_id] = UserPattern(
                    id=pattern_id,
                    pattern_type="interest",
                    description=f"User is interested in {topic}",
                    confidence=self.interests[topic],
                    evidence=[observation_id] if observation_id else [],
                    first_observed=now,
                    last_observed=now,
                )

            self._save()

    def add_pattern(
        self,
        pattern_type: str,
        description: str,
        confidence: float,
        observation_id: str
    ) -> UserPattern:
        """Add or reinforce a user pattern."""
        with self._lock:
            pattern_id = self._generate_id(f"{pattern_type}:{description}")
            now = time.time()

            if pattern_id in self.patterns:
                pattern = self.patterns[pattern_id]
                pattern.confidence = min(1.0, pattern.confidence + 0.05)
                pattern.last_observed = now
                pattern.occurrence_count += 1
                if observation_id not in pattern.evidence:
                    pattern.evidence.append(observation_id)
            else:
                pattern = UserPattern(
                    id=pattern_id,
                    pattern_type=pattern_type,
                    description=description,
                    confidence=confidence,
                    evidence=[observation_id],
                    first_observed=now,
                    last_observed=now,
                )
                self.patterns[pattern_id] = pattern

            self._save()
            return self.patterns[pattern_id]

    def set_preference(self, key: str, value: Any) -> None:
        """Set an explicit user preference."""
        with self._lock:
            self.preferences[key] = value
            self._save()

    def get_preference(self, key: str, default: Any = None) -> Any:
        """Get a user preference."""
        return self.preferences.get(key, default)

    def get_top_interests(self, n: int = 10) -> List[tuple]:
        """Get the user's top interests."""
        sorted_interests = sorted(self.interests.items(), key=lambda x: x[1], reverse=True)
        return sorted_interests[:n]

    def get_patterns_by_type(self, pattern_type: str) -> List[UserPattern]:
        """Get all patterns of a specific type."""
        return [p for p in self.patterns.values() if p.pattern_type == pattern_type]

    def get_stats(self) -> Dict[str, Any]:
        """Get user model statistics."""
        return {
            "total_patterns": len(self.patterns),
            "interests_tracked": len(self.interests),
            "activity_log_size": len(self.activity_log),
            "preferences_set": len(self.preferences),
            "pattern_types": list(set(p.pattern_type for p in self.patterns.values())),
        }


# ============================================================================
# Observation Source - Abstract base for data sources
# ============================================================================

class ObservationSource(ABC):
    """
    Abstract base class for observation sources.

    Each source knows how to:
    1. Check if it should poll now (rate limiting)
    2. Fetch new observations
    3. Parse results into Observation objects
    """

    def __init__(
        self,
        name: str,
        source_type: SourceType,
        poll_interval_seconds: int = 300,
        enabled: bool = True
    ):
        self.name = name
        self.source_type = source_type
        self.poll_interval = poll_interval_seconds
        self.enabled = enabled
        self.last_poll: float = 0
        self.total_observations: int = 0
        self.errors: int = 0

    def should_poll(self) -> bool:
        """Check if enough time has passed since last poll."""
        if not self.enabled:
            return False
        return time.time() - self.last_poll >= self.poll_interval

    @abstractmethod
    def fetch(self) -> List[Observation]:
        """Fetch new observations from this source."""
        pass

    def poll(self) -> List[Observation]:
        """Poll for observations if it's time."""
        if not self.should_poll():
            return []

        try:
            observations = self.fetch()
            self.last_poll = time.time()
            self.total_observations += len(observations)
            return observations
        except Exception as e:
            self.errors += 1
            print(f"[OmniscientObserver] Error polling {self.name}: {e}")
            return []

    def get_stats(self) -> Dict[str, Any]:
        """Get source statistics."""
        return {
            "name": self.name,
            "type": self.source_type.value,
            "enabled": self.enabled,
            "poll_interval": self.poll_interval,
            "last_poll": self.last_poll,
            "total_observations": self.total_observations,
            "errors": self.errors,
        }


# ============================================================================
# Built-in Observation Sources
# ============================================================================

class UserActivitySource(ObservationSource):
    """
    Observes user activity within Maven.

    Tracks queries, commands, preferences expressed in conversation.
    """

    def __init__(self):
        super().__init__(
            name="user_activity",
            source_type=SourceType.USER_ACTIVITY,
            poll_interval_seconds=10,  # Very frequent for user activity
        )
        self._pending_activities: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def record(self, activity_type: str, content: str, metadata: Optional[Dict] = None) -> None:
        """Record a user activity for later observation."""
        with self._lock:
            self._pending_activities.append({
                "type": activity_type,
                "content": content,
                "metadata": metadata or {},
                "timestamp": time.time(),
            })

    def fetch(self) -> List[Observation]:
        """Fetch pending user activities as observations."""
        with self._lock:
            activities = self._pending_activities.copy()
            self._pending_activities.clear()

        observations = []
        for activity in activities:
            key = f"{activity['content']}{activity['timestamp']}"
            obs_id = f"ua_{hashlib.md5(key.encode()).hexdigest()[:8]}"
            observations.append(Observation(
                id=obs_id,
                source=self.name,
                source_type=self.source_type,
                content=activity["content"],
                timestamp=activity["timestamp"],
                priority=ObservationPriority.NORMAL,
                metadata={
                    "activity_type": activity["type"],
                    **activity["metadata"],
                },
            ))
        return observations


class SystemEventSource(ObservationSource):
    """
    Observes system events within Maven.

    Tracks brain activations, memory operations, errors, etc.
    """

    def __init__(self):
        super().__init__(
            name="system_events",
            source_type=SourceType.SYSTEM_EVENT,
            poll_interval_seconds=30,
        )
        self._pending_events: List[Dict[str, Any]] = []
        self._lock = threading.Lock()

    def record(self, event_type: str, details: str, severity: str = "info") -> None:
        """Record a system event."""
        with self._lock:
            self._pending_events.append({
                "type": event_type,
                "details": details,
                "severity": severity,
                "timestamp": time.time(),
            })

    def fetch(self) -> List[Observation]:
        """Fetch pending system events as observations."""
        with self._lock:
            events = self._pending_events.copy()
            self._pending_events.clear()

        observations = []
        for event in events:
            priority = {
                "debug": ObservationPriority.BACKGROUND,
                "info": ObservationPriority.NORMAL,
                "warning": ObservationPriority.ELEVATED,
                "error": ObservationPriority.IMPORTANT,
                "critical": ObservationPriority.CRITICAL,
            }.get(event["severity"], ObservationPriority.NORMAL)

            key = f"{event['details']}{event['timestamp']}"
            obs_id = f"se_{hashlib.md5(key.encode()).hexdigest()[:8]}"
            observations.append(Observation(
                id=obs_id,
                source=self.name,
                source_type=self.source_type,
                content=event["details"],
                timestamp=event["timestamp"],
                priority=priority,
                metadata={
                    "event_type": event["type"],
                    "severity": event["severity"],
                },
            ))
        return observations


class WebFeedSource(ObservationSource):
    """
    Base class for web feed sources (RSS, APIs, etc).

    Subclass this to implement specific web sources.
    """

    def __init__(self, name: str, url: str, poll_interval_seconds: int = 300):
        super().__init__(
            name=name,
            source_type=SourceType.WEB_FEED,
            poll_interval_seconds=poll_interval_seconds,
        )
        self.url = url
        self._seen_ids: Set[str] = set()

    def fetch(self) -> List[Observation]:
        """Fetch from web source - override in subclass."""
        # Placeholder - subclasses should implement actual fetching
        return []


# ============================================================================
# Omniscient Observer - Main Controller
# ============================================================================

class OmniscientObserver:
    """
    Maven's perpetual learning system.

    Continuously observes, learns, and builds models of the world and user.
    Only interrupts when something truly important is found.

    Usage:
        observer = OmniscientObserver()
        observer.start()

        # Later...
        observer.stop()
    """

    def __init__(
        self,
        world_model: Optional[WorldModel] = None,
        user_model: Optional[UserModel] = None,
        interrupt_callback: Optional[Callable[[Observation], None]] = None,
        interrupt_threshold: float = 0.9
    ):
        # Models
        self.world_model = world_model or WorldModel()
        self.user_model = user_model or UserModel()

        # Sources
        self.sources: Dict[str, ObservationSource] = {}
        self._user_activity_source = UserActivitySource()
        self._system_event_source = SystemEventSource()
        self.add_source(self._user_activity_source)
        self.add_source(self._system_event_source)

        # Processing
        self.observation_queue: Queue = Queue()
        self.interrupt_callback = interrupt_callback
        self.interrupt_threshold = interrupt_threshold

        # State
        self._running = False
        self._observation_thread: Optional[threading.Thread] = None
        self._processing_thread: Optional[threading.Thread] = None
        self._synthesis_thread: Optional[threading.Thread] = None

        # Statistics
        self.stats = {
            "observations_total": 0,
            "observations_processed": 0,
            "interrupts_triggered": 0,
            "facts_learned": 0,
            "patterns_detected": 0,
            "start_time": None,
            "last_activity": None,
        }

        # Memory for observations (if BrainMemory available)
        self._memory = BrainMemory("omniscient_observations") if BrainMemory else None

    # =========================================================================
    # Source Management
    # =========================================================================

    def add_source(self, source: ObservationSource) -> None:
        """Add an observation source."""
        self.sources[source.name] = source

    def remove_source(self, name: str) -> None:
        """Remove an observation source."""
        self.sources.pop(name, None)

    def enable_source(self, name: str) -> None:
        """Enable a source."""
        if name in self.sources:
            self.sources[name].enabled = True

    def disable_source(self, name: str) -> None:
        """Disable a source."""
        if name in self.sources:
            self.sources[name].enabled = False

    # =========================================================================
    # Activity Recording (for external use)
    # =========================================================================

    def record_user_activity(self, activity_type: str, content: str, metadata: Optional[Dict] = None) -> None:
        """Record a user activity for observation."""
        self._user_activity_source.record(activity_type, content, metadata)

    def record_system_event(self, event_type: str, details: str, severity: str = "info") -> None:
        """Record a system event for observation."""
        self._system_event_source.record(event_type, details, severity)

    # =========================================================================
    # Observation Threads
    # =========================================================================

    def _observation_loop(self) -> None:
        """Main observation loop - polls all sources."""
        print("[OmniscientObserver] Observation thread started")

        while self._running:
            try:
                for source in self.sources.values():
                    observations = source.poll()
                    for obs in observations:
                        self.observation_queue.put(obs)
                        self.stats["observations_total"] += 1

                # Sleep a bit before next round
                time.sleep(1)

            except Exception as e:
                print(f"[OmniscientObserver] Observation loop error: {e}")
                time.sleep(5)

        print("[OmniscientObserver] Observation thread stopped")

    def _processing_loop(self) -> None:
        """Processing loop - processes observations and updates models."""
        print("[OmniscientObserver] Processing thread started")

        while self._running:
            try:
                # Get observation with timeout to allow checking _running
                try:
                    obs = self.observation_queue.get(timeout=1.0)
                except Empty:
                    continue

                # Process the observation
                self._process_observation(obs)
                self.stats["observations_processed"] += 1
                self.stats["last_activity"] = time.time()

                # Check if this warrants an interrupt
                if obs.relevance_score >= self.interrupt_threshold:
                    self._trigger_interrupt(obs)

            except Exception as e:
                print(f"[OmniscientObserver] Processing loop error: {e}")
                time.sleep(1)

        print("[OmniscientObserver] Processing thread stopped")

    def _synthesis_loop(self) -> None:
        """Synthesis loop - periodically synthesizes patterns."""
        print("[OmniscientObserver] Synthesis thread started")

        synthesis_interval = 300  # 5 minutes
        last_synthesis = time.time()

        while self._running:
            try:
                if time.time() - last_synthesis >= synthesis_interval:
                    self._synthesize_patterns()
                    last_synthesis = time.time()

                time.sleep(10)

            except Exception as e:
                print(f"[OmniscientObserver] Synthesis loop error: {e}")
                time.sleep(30)

        print("[OmniscientObserver] Synthesis thread stopped")

    # =========================================================================
    # Observation Processing
    # =========================================================================

    def _process_observation(self, obs: Observation) -> None:
        """
        Process a single observation.

        1. Extract entities and patterns
        2. Update world model if external
        3. Update user model if user-related
        4. Store in memory
        """
        # Mark as processed
        obs.processed = True

        # Extract entities (simple extraction - could use NLP)
        obs.entities = self._extract_entities(obs.content)

        # Extract patterns
        obs.patterns_detected = self._detect_patterns(obs)

        # Calculate relevance
        obs.relevance_score = self._calculate_relevance(obs)

        # Update appropriate model
        if obs.source_type == SourceType.USER_ACTIVITY:
            self._update_user_model(obs)
        elif obs.source_type in [SourceType.WEB_FEED, SourceType.API]:
            self._update_world_model(obs)
        elif obs.source_type == SourceType.SYSTEM_EVENT:
            # System events might affect both models
            if obs.metadata.get("severity") in ["error", "critical"]:
                self.record_system_event("error_pattern", obs.content, "warning")

        # Store in memory
        if self._memory:
            self._memory.store(
                content=obs.to_dict(),
                metadata={
                    "kind": "observation",
                    "source": obs.source,
                    "priority": obs.priority.value,
                    "relevance": obs.relevance_score,
                }
            )

    def _extract_entities(self, content: str) -> List[str]:
        """Extract entities from content (simple implementation)."""
        entities = []
        # Look for capitalized words (proper nouns)
        words = content.split()
        for word in words:
            clean = word.strip(".,!?\"'()[]{}:;")
            if clean and clean[0].isupper() and len(clean) > 2:
                entities.append(clean)
        return list(set(entities))[:10]  # Dedupe and limit

    def _detect_patterns(self, obs: Observation) -> List[str]:
        """Detect patterns in an observation."""
        patterns = []
        content_lower = obs.content.lower()

        # Question patterns
        if "?" in obs.content or any(q in content_lower for q in ["what", "how", "why", "when", "where", "who"]):
            patterns.append("question")

        # Interest indicators
        if any(word in content_lower for word in ["interesting", "cool", "amazing", "love", "hate", "like", "dislike"]):
            patterns.append("sentiment")

        # Technical terms
        if any(word in content_lower for word in ["code", "function", "class", "api", "database", "server"]):
            patterns.append("technical")

        # Time references
        if any(word in content_lower for word in ["today", "tomorrow", "yesterday", "morning", "evening", "night"]):
            patterns.append("temporal")

        return patterns

    def _calculate_relevance(self, obs: Observation) -> float:
        """Calculate relevance score for an observation."""
        score = 0.5  # Base score

        # Priority boost
        priority_boost = {
            ObservationPriority.BACKGROUND: -0.2,
            ObservationPriority.NORMAL: 0,
            ObservationPriority.ELEVATED: 0.15,
            ObservationPriority.IMPORTANT: 0.3,
            ObservationPriority.CRITICAL: 0.5,
        }
        score += priority_boost.get(obs.priority, 0)

        # Entity boost (more entities = more relevant)
        score += min(0.2, len(obs.entities) * 0.05)

        # Pattern boost
        if "question" in obs.patterns_detected:
            score += 0.1
        if "technical" in obs.patterns_detected:
            score += 0.05

        # User interest boost
        for entity in obs.entities:
            interest = self.user_model.interests.get(entity, 0)
            score += interest * 0.1

        return min(1.0, max(0.0, score))

    def _update_world_model(self, obs: Observation) -> None:
        """Update world model based on observation."""
        # Add as fact if confident enough
        if obs.relevance_score > 0.4:
            domain = obs.metadata.get("domain", "general")
            self.world_model.add_fact(
                content=obs.content[:500],  # Truncate long content
                domain=domain,
                confidence=obs.relevance_score,
                observation_id=obs.id,
                entities=obs.entities,
            )
            self.stats["facts_learned"] += 1

        # Track trends for entities
        sentiment = 0.5  # Neutral default
        if "sentiment" in obs.patterns_detected:
            sentiment = 0.7 if any(w in obs.content.lower() for w in ["good", "great", "love", "amazing"]) else 0.3

        for entity in obs.entities[:3]:  # Top 3 entities
            self.world_model.track_trend(entity, sentiment, obs.id)

    def _update_user_model(self, obs: Observation) -> None:
        """Update user model based on observation."""
        activity_type = obs.metadata.get("activity_type", "unknown")

        # Record the activity
        self.user_model.record_activity(activity_type, {
            "content": obs.content[:200],
            "entities": obs.entities,
        })

        # Update interests based on entities
        for entity in obs.entities:
            self.user_model.update_interest(entity, 0.02, obs.id)

        # Detect behavioral patterns
        if "question" in obs.patterns_detected:
            self.user_model.add_pattern(
                pattern_type="behavior",
                description="User asks questions frequently",
                confidence=0.6,
                observation_id=obs.id,
            )
            self.stats["patterns_detected"] += 1

        if activity_type == "query":
            # Track query patterns
            self.user_model.add_pattern(
                pattern_type="behavior",
                description=f"User queries about {obs.entities[0] if obs.entities else 'general topics'}",
                confidence=0.5,
                observation_id=obs.id,
            )

    def _synthesize_patterns(self) -> None:
        """Periodically synthesize higher-level patterns."""
        # Get top interests and look for correlations
        top_interests = self.user_model.get_top_interests(5)

        if len(top_interests) >= 2:
            # Create synthetic observation about user interests
            interests_str = ", ".join(t[0] for t in top_interests)
            self.user_model.add_pattern(
                pattern_type="interest_cluster",
                description=f"User shows consistent interest in: {interests_str}",
                confidence=0.7,
                observation_id=f"synth_{int(time.time())}",
            )

        # Check world model for emerging trends
        for topic in list(self.world_model.trends.keys())[:5]:
            momentum = self.world_model.get_trend_momentum(topic)
            if momentum and abs(momentum["momentum"]) > 0.2:
                direction = "rising" if momentum["momentum"] > 0 else "falling"
                self.world_model.add_fact(
                    content=f"Trend detected: {topic} is {direction} in sentiment",
                    domain="trends",
                    confidence=0.6,
                    observation_id=f"synth_{int(time.time())}",
                    entities=[topic],
                )

    # =========================================================================
    # Interrupt System
    # =========================================================================

    def _trigger_interrupt(self, obs: Observation) -> None:
        """Trigger an interrupt for an important observation."""
        self.stats["interrupts_triggered"] += 1

        if self.interrupt_callback:
            try:
                self.interrupt_callback(obs)
            except Exception as e:
                print(f"[OmniscientObserver] Interrupt callback error: {e}")
        else:
            print(f"[OmniscientObserver] IMPORTANT: {obs.content[:100]}...")

    # =========================================================================
    # Lifecycle Management
    # =========================================================================

    def start(self) -> None:
        """Start the omniscient observer."""
        if self._running:
            print("[OmniscientObserver] Already running")
            return

        self._running = True
        self.stats["start_time"] = time.time()

        # Start threads
        self._observation_thread = threading.Thread(
            target=self._observation_loop,
            name="OmniscientObserver-Observation",
            daemon=True,
        )
        self._processing_thread = threading.Thread(
            target=self._processing_loop,
            name="OmniscientObserver-Processing",
            daemon=True,
        )
        self._synthesis_thread = threading.Thread(
            target=self._synthesis_loop,
            name="OmniscientObserver-Synthesis",
            daemon=True,
        )

        self._observation_thread.start()
        self._processing_thread.start()
        self._synthesis_thread.start()

        print("[OmniscientObserver] Started - Maven is now always watching, always learning")

    def stop(self) -> None:
        """Stop the omniscient observer."""
        if not self._running:
            return

        self._running = False

        # Wait for threads to finish
        if self._observation_thread:
            self._observation_thread.join(timeout=5)
        if self._processing_thread:
            self._processing_thread.join(timeout=5)
        if self._synthesis_thread:
            self._synthesis_thread.join(timeout=5)

        print("[OmniscientObserver] Stopped")

    def is_running(self) -> bool:
        """Check if observer is running."""
        return self._running

    def get_stats(self) -> Dict[str, Any]:
        """Get observer statistics."""
        uptime = None
        if self.stats["start_time"]:
            uptime = time.time() - self.stats["start_time"]

        return {
            **self.stats,
            "uptime_seconds": uptime,
            "sources": {name: src.get_stats() for name, src in self.sources.items()},
            "world_model": self.world_model.get_stats(),
            "user_model": self.user_model.get_stats(),
            "queue_size": self.observation_queue.qsize(),
        }


# ============================================================================
# Singleton Instance & Convenience Functions
# ============================================================================

_observer_instance: Optional[OmniscientObserver] = None


def get_observer() -> OmniscientObserver:
    """Get or create the singleton observer instance."""
    global _observer_instance
    if _observer_instance is None:
        _observer_instance = OmniscientObserver()
    return _observer_instance


def start_omniscient_mode(interrupt_callback: Optional[Callable] = None) -> OmniscientObserver:
    """
    Start Maven's omniscient observation mode.

    Args:
        interrupt_callback: Optional callback for important observations

    Returns:
        The OmniscientObserver instance
    """
    observer = get_observer()
    if interrupt_callback:
        observer.interrupt_callback = interrupt_callback
    observer.start()
    return observer


def stop_omniscient_mode() -> None:
    """Stop Maven's omniscient observation mode."""
    observer = get_observer()
    observer.stop()


def record_activity(activity_type: str, content: str, metadata: Optional[Dict] = None) -> None:
    """Record a user activity (convenience function)."""
    observer = get_observer()
    observer.record_user_activity(activity_type, content, metadata)


def record_event(event_type: str, details: str, severity: str = "info") -> None:
    """Record a system event (convenience function)."""
    observer = get_observer()
    observer.record_system_event(event_type, details, severity)


def get_world_facts(domain: str, limit: int = 10) -> List[Dict[str, Any]]:
    """Get facts from the world model (convenience function)."""
    observer = get_observer()
    facts = observer.world_model.get_facts_by_domain(domain)[:limit]
    return [f.to_dict() for f in facts]


def get_user_interests(top_n: int = 10) -> List[tuple]:
    """Get user's top interests (convenience function)."""
    observer = get_observer()
    return observer.user_model.get_top_interests(top_n)


def get_observation_stats() -> Dict[str, Any]:
    """Get observation statistics (convenience function)."""
    observer = get_observer()
    return observer.get_stats()


# ============================================================================
# Testing / Direct Execution
# ============================================================================

if __name__ == "__main__":
    print("Testing OmniscientObserver...")

    # Create and start observer
    observer = OmniscientObserver()

    # Add some test activities
    observer.record_user_activity("query", "What is the weather like?", {"domain": "weather"})
    observer.record_user_activity("query", "Tell me about Python programming", {"domain": "tech"})
    observer.record_system_event("brain_activation", "Reasoning brain activated", "info")

    # Start observing
    observer.start()

    # Let it run briefly
    time.sleep(5)

    # Check stats
    stats = observer.get_stats()
    print(f"\nStats after 5 seconds:")
    print(f"  Observations total: {stats['observations_total']}")
    print(f"  Observations processed: {stats['observations_processed']}")
    print(f"  World model facts: {stats['world_model']['total_facts']}")
    print(f"  User model patterns: {stats['user_model']['total_patterns']}")

    # Stop
    observer.stop()
    print("\nTest complete.")
