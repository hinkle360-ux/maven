"""
goal_generation.py
~~~~~~~~~~~~~~~~~~

Autonomous Goal Generation System

This module provides capabilities for generating goals autonomously based on:
1. **Context Analysis**: Current conversation and task state
2. **User Preferences**: Learned patterns from user interactions
3. **System State**: Current capabilities and constraints
4. **Proactive Detection**: Identifying opportunities without prompting

Architecture:
- GoalGenerator: Main generator with multiple strategies
- GoalTemplate: Reusable goal patterns
- GoalCandidate: Generated goal with metadata
- GoalPrioritizer: Ranks and filters goals

Key Features:
- Multi-strategy goal generation
- Priority scoring with configurable weights
- User preference alignment
- Feasibility assessment
- Goal conflict detection

Usage:
    from brains.agent.autonomous.goal_generation import (
        GoalGenerator,
        generate_goals,
        get_proactive_suggestions,
    )

    generator = GoalGenerator()

    # Generate goals from context
    goals = generator.generate_from_context({
        "recent_queries": [...],
        "current_task": "...",
        "user_preferences": {...},
    })

    # Get proactive suggestions
    suggestions = get_proactive_suggestions(session_state)

Author: Maven Self-Upgrade
Created: December 2025
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from brains.memory.brain_memory import BrainMemory


# =============================================================================
# ENUMS AND TYPES
# =============================================================================

class GoalCategory(Enum):
    """Categories of autonomous goals."""
    TASK_COMPLETION = "task_completion"      # Complete pending tasks
    INFORMATION_RETRIEVAL = "info_retrieval" # Find and present info
    LEARNING = "learning"                     # Learn from interactions
    OPTIMIZATION = "optimization"             # Improve processes
    MAINTENANCE = "maintenance"               # System maintenance
    PROACTIVE_HELP = "proactive_help"        # Anticipate user needs
    ERROR_RECOVERY = "error_recovery"         # Recover from failures
    SELF_IMPROVEMENT = "self_improvement"     # Improve own capabilities


class GoalPriority(Enum):
    """Goal priority levels."""
    CRITICAL = 5    # Must do immediately
    HIGH = 4        # Should do soon
    MEDIUM = 3      # Normal priority
    LOW = 2         # Can defer
    OPTIONAL = 1    # Nice to have


class GoalStatus(Enum):
    """Goal status tracking."""
    PROPOSED = "proposed"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    DEFERRED = "deferred"


class GenerationStrategy(Enum):
    """Goal generation strategies."""
    CONTEXT_DRIVEN = "context_driven"     # Based on current context
    PATTERN_BASED = "pattern_based"       # Based on learned patterns
    PROACTIVE = "proactive"               # Anticipating needs
    REACTIVE = "reactive"                 # Responding to events
    SCHEDULED = "scheduled"               # Time-based triggers
    EXPLORATORY = "exploratory"           # Discovery and learning


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class GoalTemplate:
    """
    Reusable goal pattern template.

    Templates define common goal patterns that can be instantiated
    with specific parameters based on context.
    """
    template_id: str
    name: str
    category: GoalCategory
    description_pattern: str  # Pattern with {placeholders}
    required_context: List[str]  # Required context keys
    priority_base: GoalPriority
    typical_steps: List[str]
    success_criteria: List[str]
    applicability_score: float = 0.5  # How often this applies

    def instantiate(self, context: Dict[str, Any]) -> Optional["GoalCandidate"]:
        """
        Create a goal candidate from this template.

        Args:
            context: Context dictionary for filling placeholders

        Returns:
            GoalCandidate if context has required keys, None otherwise
        """
        # Check required context
        for key in self.required_context:
            if key not in context:
                return None

        # Fill in description
        try:
            description = self.description_pattern.format(**context)
        except KeyError:
            return None

        return GoalCandidate(
            goal_id=self._generate_id(context),
            template_id=self.template_id,
            category=self.category,
            description=description,
            priority=self.priority_base,
            context=context,
            steps=self._expand_steps(context),
            success_criteria=self.success_criteria,
        )

    def _generate_id(self, context: Dict[str, Any]) -> str:
        """Generate unique goal ID."""
        content = json.dumps({
            "template": self.template_id,
            "ts": time.time(),
            "ctx_keys": sorted(context.keys()),
        }, sort_keys=True)
        return f"goal_{hashlib.sha256(content.encode()).hexdigest()[:12]}"

    def _expand_steps(self, context: Dict[str, Any]) -> List[str]:
        """Expand step templates with context."""
        expanded = []
        for step in self.typical_steps:
            try:
                expanded.append(step.format(**context))
            except KeyError:
                expanded.append(step)
        return expanded


@dataclass
class GoalCandidate:
    """
    A candidate goal generated by the system.

    Represents a potential goal that could be pursued, with
    scoring and metadata for prioritization.
    """
    goal_id: str
    template_id: Optional[str]
    category: GoalCategory
    description: str
    priority: GoalPriority
    context: Dict[str, Any]
    steps: List[str]
    success_criteria: List[str]

    # Scoring
    relevance_score: float = 0.5
    feasibility_score: float = 0.5
    user_alignment_score: float = 0.5

    # Metadata
    created_at: float = field(default_factory=time.time)
    status: GoalStatus = GoalStatus.PROPOSED
    source_strategy: Optional[GenerationStrategy] = None

    def get_composite_score(
        self,
        weights: Optional[Dict[str, float]] = None,
    ) -> float:
        """
        Calculate composite priority score.

        Args:
            weights: Custom weights for scoring components

        Returns:
            Composite score (0-1)
        """
        default_weights = {
            "priority": 0.3,
            "relevance": 0.25,
            "feasibility": 0.25,
            "user_alignment": 0.2,
        }
        w = weights or default_weights

        priority_normalized = self.priority.value / 5.0

        score = (
            w.get("priority", 0.3) * priority_normalized +
            w.get("relevance", 0.25) * self.relevance_score +
            w.get("feasibility", 0.25) * self.feasibility_score +
            w.get("user_alignment", 0.2) * self.user_alignment_score
        )

        return min(1.0, max(0.0, score))

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "goal_id": self.goal_id,
            "category": self.category.value,
            "description": self.description,
            "priority": self.priority.value,
            "steps": self.steps,
            "success_criteria": self.success_criteria,
            "scores": {
                "relevance": self.relevance_score,
                "feasibility": self.feasibility_score,
                "user_alignment": self.user_alignment_score,
                "composite": self.get_composite_score(),
            },
            "status": self.status.value,
            "source_strategy": self.source_strategy.value if self.source_strategy else None,
        }

    def __lt__(self, other: "GoalCandidate") -> bool:
        """Compare by composite score for sorting."""
        return self.get_composite_score() < other.get_composite_score()


@dataclass
class GenerationResult:
    """Result of goal generation."""
    goals: List[GoalCandidate]
    strategy_used: GenerationStrategy
    context_analyzed: Dict[str, Any]
    generation_time: float
    warnings: List[str] = field(default_factory=list)

    def get_top_goals(self, n: int = 5) -> List[GoalCandidate]:
        """Get top N goals by score."""
        sorted_goals = sorted(self.goals, reverse=True)
        return sorted_goals[:n]


# =============================================================================
# DEFAULT TEMPLATES
# =============================================================================

DEFAULT_TEMPLATES: List[GoalTemplate] = [
    # Task completion templates
    GoalTemplate(
        template_id="complete_pending_task",
        name="Complete Pending Task",
        category=GoalCategory.TASK_COMPLETION,
        description_pattern="Complete the pending task: {task_description}",
        required_context=["task_description"],
        priority_base=GoalPriority.HIGH,
        typical_steps=[
            "Review task requirements",
            "Gather necessary resources",
            "Execute task steps",
            "Verify completion",
        ],
        success_criteria=["Task is fully completed", "User is satisfied"],
        applicability_score=0.8,
    ),
    GoalTemplate(
        template_id="follow_up_question",
        name="Follow Up on User Question",
        category=GoalCategory.PROACTIVE_HELP,
        description_pattern="Follow up on: {original_question}",
        required_context=["original_question"],
        priority_base=GoalPriority.MEDIUM,
        typical_steps=[
            "Recall original question context",
            "Check if answer was satisfactory",
            "Offer additional assistance",
        ],
        success_criteria=["User confirms understanding"],
        applicability_score=0.6,
    ),

    # Information retrieval templates
    GoalTemplate(
        template_id="research_topic",
        name="Research Topic",
        category=GoalCategory.INFORMATION_RETRIEVAL,
        description_pattern="Research information about: {topic}",
        required_context=["topic"],
        priority_base=GoalPriority.MEDIUM,
        typical_steps=[
            "Search memory for existing knowledge",
            "Identify knowledge gaps",
            "Query external sources if needed",
            "Synthesize findings",
        ],
        success_criteria=["Comprehensive information gathered"],
        applicability_score=0.7,
    ),

    # Learning templates
    GoalTemplate(
        template_id="learn_user_preference",
        name="Learn User Preference",
        category=GoalCategory.LEARNING,
        description_pattern="Learn and remember user preference: {preference_type}",
        required_context=["preference_type", "preference_value"],
        priority_base=GoalPriority.LOW,
        typical_steps=[
            "Extract preference from context",
            "Store in user preferences memory",
            "Apply to future interactions",
        ],
        success_criteria=["Preference stored", "Future behavior updated"],
        applicability_score=0.5,
    ),
    GoalTemplate(
        template_id="learn_from_correction",
        name="Learn from User Correction",
        category=GoalCategory.LEARNING,
        description_pattern="Learn from correction: {correction_content}",
        required_context=["correction_content", "original_response"],
        priority_base=GoalPriority.HIGH,
        typical_steps=[
            "Analyze what was wrong",
            "Understand correct approach",
            "Update knowledge base",
            "Confirm learning",
        ],
        success_criteria=["Mistake understood", "Knowledge updated"],
        applicability_score=0.9,
    ),

    # Optimization templates
    GoalTemplate(
        template_id="optimize_response",
        name="Optimize Response Quality",
        category=GoalCategory.OPTIMIZATION,
        description_pattern="Improve response quality for: {response_type}",
        required_context=["response_type"],
        priority_base=GoalPriority.LOW,
        typical_steps=[
            "Analyze recent responses",
            "Identify improvement areas",
            "Apply optimizations",
        ],
        success_criteria=["Response quality improved"],
        applicability_score=0.4,
    ),

    # Maintenance templates
    GoalTemplate(
        template_id="cleanup_memory",
        name="Memory Cleanup",
        category=GoalCategory.MAINTENANCE,
        description_pattern="Clean up memory: {memory_area}",
        required_context=["memory_area"],
        priority_base=GoalPriority.LOW,
        typical_steps=[
            "Identify stale entries",
            "Archive or remove old data",
            "Optimize memory structure",
        ],
        success_criteria=["Memory optimized"],
        applicability_score=0.3,
    ),

    # Error recovery templates
    GoalTemplate(
        template_id="recover_from_error",
        name="Recover from Error",
        category=GoalCategory.ERROR_RECOVERY,
        description_pattern="Recover from: {error_description}",
        required_context=["error_description", "error_type"],
        priority_base=GoalPriority.CRITICAL,
        typical_steps=[
            "Diagnose error cause",
            "Attempt recovery",
            "Verify system stability",
            "Prevent recurrence",
        ],
        success_criteria=["Error resolved", "System stable"],
        applicability_score=0.9,
    ),

    # Proactive help templates
    GoalTemplate(
        template_id="suggest_improvement",
        name="Suggest Improvement",
        category=GoalCategory.PROACTIVE_HELP,
        description_pattern="Suggest improvement for: {improvement_area}",
        required_context=["improvement_area"],
        priority_base=GoalPriority.OPTIONAL,
        typical_steps=[
            "Identify improvement opportunity",
            "Formulate suggestion",
            "Present to user appropriately",
        ],
        success_criteria=["User considers suggestion"],
        applicability_score=0.4,
    ),
    GoalTemplate(
        template_id="anticipate_need",
        name="Anticipate User Need",
        category=GoalCategory.PROACTIVE_HELP,
        description_pattern="Prepare for anticipated need: {anticipated_need}",
        required_context=["anticipated_need"],
        priority_base=GoalPriority.MEDIUM,
        typical_steps=[
            "Predict user's next request",
            "Gather relevant information",
            "Prepare response",
        ],
        success_criteria=["User need addressed proactively"],
        applicability_score=0.5,
    ),
]


# =============================================================================
# GOAL GENERATOR
# =============================================================================

class GoalGenerator:
    """
    Autonomous goal generation system.

    Generates goals based on multiple strategies:
    - Context analysis
    - Pattern matching
    - Proactive detection
    - Scheduled triggers
    """

    def __init__(
        self,
        templates: Optional[List[GoalTemplate]] = None,
        user_preferences: Optional[Dict[str, Any]] = None,
    ):
        """
        Initialize goal generator.

        Args:
            templates: Custom goal templates
            user_preferences: User preference data
        """
        self._memory = BrainMemory("goal_generation")
        self._templates = templates or DEFAULT_TEMPLATES.copy()
        self._user_prefs = user_preferences or {}
        self._generation_history: List[GenerationResult] = []

        # Strategy handlers
        self._strategies: Dict[GenerationStrategy, Callable] = {
            GenerationStrategy.CONTEXT_DRIVEN: self._generate_context_driven,
            GenerationStrategy.PATTERN_BASED: self._generate_pattern_based,
            GenerationStrategy.PROACTIVE: self._generate_proactive,
            GenerationStrategy.REACTIVE: self._generate_reactive,
            GenerationStrategy.EXPLORATORY: self._generate_exploratory,
        }

    def generate(
        self,
        context: Dict[str, Any],
        strategies: Optional[List[GenerationStrategy]] = None,
        max_goals: int = 10,
    ) -> GenerationResult:
        """
        Generate goals using specified strategies.

        Args:
            context: Current context dictionary
            strategies: Strategies to use (all if None)
            max_goals: Maximum goals to generate

        Returns:
            GenerationResult with candidate goals
        """
        start_time = time.time()
        all_goals: List[GoalCandidate] = []
        warnings: List[str] = []

        # Use all strategies if none specified
        use_strategies = strategies or list(self._strategies.keys())

        for strategy in use_strategies:
            handler = self._strategies.get(strategy)
            if handler:
                try:
                    goals = handler(context)
                    for goal in goals:
                        goal.source_strategy = strategy
                    all_goals.extend(goals)
                except Exception as e:
                    warnings.append(f"Strategy {strategy.value} failed: {e}")

        # Score and filter goals
        scored_goals = self._score_goals(all_goals, context)
        filtered_goals = self._filter_conflicts(scored_goals)

        # Limit to max_goals
        final_goals = sorted(filtered_goals, reverse=True)[:max_goals]

        result = GenerationResult(
            goals=final_goals,
            strategy_used=use_strategies[0] if use_strategies else GenerationStrategy.CONTEXT_DRIVEN,
            context_analyzed=context,
            generation_time=time.time() - start_time,
            warnings=warnings,
        )

        self._generation_history.append(result)
        self._store_generation(result)

        return result

    def generate_from_context(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """
        Generate goals primarily from context analysis.

        Args:
            context: Context dictionary

        Returns:
            List of goal candidates
        """
        result = self.generate(
            context,
            strategies=[
                GenerationStrategy.CONTEXT_DRIVEN,
                GenerationStrategy.PROACTIVE,
            ],
        )
        return result.goals

    def get_proactive_suggestions(
        self,
        session_state: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """
        Generate proactive goal suggestions.

        Args:
            session_state: Current session state

        Returns:
            List of proactive goal suggestions
        """
        result = self.generate(
            session_state,
            strategies=[GenerationStrategy.PROACTIVE],
            max_goals=5,
        )
        return result.goals

    def add_template(self, template: GoalTemplate):
        """Add a custom goal template."""
        self._templates.append(template)

    def update_user_preferences(self, preferences: Dict[str, Any]):
        """Update user preferences for goal alignment."""
        self._user_prefs.update(preferences)

    # =========================================================================
    # STRATEGY IMPLEMENTATIONS
    # =========================================================================

    def _generate_context_driven(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Generate goals based on current context."""
        goals = []

        # Try to instantiate templates with context
        for template in self._templates:
            goal = template.instantiate(context)
            if goal:
                goals.append(goal)

        # Analyze conversation for implicit goals
        recent_queries = context.get("recent_queries", [])
        for query in recent_queries[-5:]:
            if isinstance(query, str):
                implicit = self._extract_implicit_goals(query, context)
                goals.extend(implicit)

        return goals

    def _generate_pattern_based(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Generate goals based on learned patterns."""
        goals = []

        # Check for recurring patterns
        history = self._memory.search(
            "goal_pattern",
            limit=10,
        )

        for record in history:
            try:
                pattern = json.loads(record.get("content", "{}"))
                if self._pattern_matches(pattern, context):
                    goal = self._goal_from_pattern(pattern, context)
                    if goal:
                        goals.append(goal)
            except (json.JSONDecodeError, KeyError):
                continue

        return goals

    def _generate_proactive(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Generate proactive goals anticipating user needs."""
        goals = []

        # Analyze for proactive opportunities
        proactive_checks = [
            self._check_incomplete_tasks,
            self._check_error_patterns,
            self._check_learning_opportunities,
            self._check_optimization_opportunities,
        ]

        for check_func in proactive_checks:
            try:
                check_goals = check_func(context)
                goals.extend(check_goals)
            except Exception:
                continue

        return goals

    def _generate_reactive(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Generate goals reacting to events."""
        goals = []

        # Check for error events
        if context.get("last_error"):
            error_template = self._get_template("recover_from_error")
            if error_template:
                error_context = {
                    "error_description": str(context["last_error"]),
                    "error_type": context.get("error_type", "unknown"),
                    **context,
                }
                goal = error_template.instantiate(error_context)
                if goal:
                    goal.priority = GoalPriority.CRITICAL
                    goals.append(goal)

        # Check for user corrections
        if context.get("user_correction"):
            learn_template = self._get_template("learn_from_correction")
            if learn_template:
                learn_context = {
                    "correction_content": str(context["user_correction"]),
                    "original_response": context.get("original_response", ""),
                    **context,
                }
                goal = learn_template.instantiate(learn_context)
                if goal:
                    goals.append(goal)

        return goals

    def _generate_exploratory(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Generate exploratory/discovery goals."""
        goals = []

        # Look for unexplored areas
        explored_topics = set(context.get("explored_topics", []))
        available_topics = set(context.get("available_topics", []))

        unexplored = available_topics - explored_topics
        for topic in list(unexplored)[:3]:
            goals.append(GoalCandidate(
                goal_id=f"explore_{topic}_{int(time.time())}",
                template_id=None,
                category=GoalCategory.LEARNING,
                description=f"Explore topic: {topic}",
                priority=GoalPriority.OPTIONAL,
                context={"topic": topic},
                steps=[
                    f"Research {topic}",
                    "Identify key concepts",
                    "Store findings",
                ],
                success_criteria=["New knowledge acquired"],
                source_strategy=GenerationStrategy.EXPLORATORY,
            ))

        return goals

    # =========================================================================
    # HELPER METHODS
    # =========================================================================

    def _extract_implicit_goals(
        self,
        query: str,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Extract implicit goals from a query."""
        goals = []
        query_lower = query.lower()

        # Patterns that indicate implicit goals
        patterns = [
            (r"remind me to (.+)", "follow_up_question", {"original_question": None}),
            (r"i want to (.+)", "complete_pending_task", {"task_description": None}),
            (r"help me (.+)", "complete_pending_task", {"task_description": None}),
            (r"find (.+)", "research_topic", {"topic": None}),
            (r"what is (.+)", "research_topic", {"topic": None}),
            (r"how do i (.+)", "research_topic", {"topic": None}),
        ]

        for pattern, template_id, defaults in patterns:
            match = re.search(pattern, query_lower)
            if match:
                template = self._get_template(template_id)
                if template:
                    extracted = match.group(1)
                    goal_context = {**context}

                    # Fill in extracted value
                    for key in defaults:
                        if defaults[key] is None:
                            goal_context[key] = extracted

                    goal = template.instantiate(goal_context)
                    if goal:
                        goals.append(goal)

        return goals

    def _check_incomplete_tasks(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Check for incomplete tasks."""
        goals = []

        pending_tasks = context.get("pending_tasks", [])
        for task in pending_tasks[:3]:
            task_desc = task if isinstance(task, str) else task.get("description", "")
            if task_desc:
                template = self._get_template("complete_pending_task")
                if template:
                    goal = template.instantiate({
                        "task_description": task_desc,
                        **context,
                    })
                    if goal:
                        goals.append(goal)

        return goals

    def _check_error_patterns(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Check for recurring error patterns."""
        goals = []

        recent_errors = context.get("recent_errors", [])
        if len(recent_errors) >= 2:
            # Multiple errors might indicate systemic issue
            goals.append(GoalCandidate(
                goal_id=f"diagnose_errors_{int(time.time())}",
                template_id=None,
                category=GoalCategory.ERROR_RECOVERY,
                description="Diagnose recurring errors",
                priority=GoalPriority.HIGH,
                context={"error_count": len(recent_errors)},
                steps=[
                    "Analyze error patterns",
                    "Identify root cause",
                    "Implement fix",
                ],
                success_criteria=["Error pattern resolved"],
            ))

        return goals

    def _check_learning_opportunities(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Check for learning opportunities."""
        goals = []

        # Check for repeated questions (opportunity to learn)
        question_freq = context.get("question_frequency", {})
        for question, count in question_freq.items():
            if count >= 3:
                goals.append(GoalCandidate(
                    goal_id=f"learn_q_{hash(question) % 10000}_{int(time.time())}",
                    template_id=None,
                    category=GoalCategory.LEARNING,
                    description=f"Improve answer quality for: {question[:50]}",
                    priority=GoalPriority.LOW,
                    context={"question": question, "frequency": count},
                    steps=[
                        "Analyze previous answers",
                        "Research better response",
                        "Store improved answer",
                    ],
                    success_criteria=["Answer quality improved"],
                ))

        return goals

    def _check_optimization_opportunities(
        self,
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Check for optimization opportunities."""
        goals = []

        # Check response time
        avg_response_time = context.get("avg_response_time", 0)
        if avg_response_time > 5.0:  # > 5 seconds
            goals.append(GoalCandidate(
                goal_id=f"optimize_speed_{int(time.time())}",
                template_id=None,
                category=GoalCategory.OPTIMIZATION,
                description="Optimize response time",
                priority=GoalPriority.LOW,
                context={"current_avg": avg_response_time},
                steps=[
                    "Profile slow operations",
                    "Identify bottlenecks",
                    "Apply optimizations",
                ],
                success_criteria=["Response time reduced"],
            ))

        return goals

    def _get_template(self, template_id: str) -> Optional[GoalTemplate]:
        """Get template by ID."""
        for template in self._templates:
            if template.template_id == template_id:
                return template
        return None

    def _pattern_matches(
        self,
        pattern: Dict[str, Any],
        context: Dict[str, Any],
    ) -> bool:
        """Check if a pattern matches current context."""
        required_keys = pattern.get("required_context_keys", [])
        for key in required_keys:
            if key not in context:
                return False

        # Check value patterns
        value_patterns = pattern.get("value_patterns", {})
        for key, pattern_regex in value_patterns.items():
            value = context.get(key, "")
            if not re.search(pattern_regex, str(value)):
                return False

        return True

    def _goal_from_pattern(
        self,
        pattern: Dict[str, Any],
        context: Dict[str, Any],
    ) -> Optional[GoalCandidate]:
        """Create goal from learned pattern."""
        try:
            return GoalCandidate(
                goal_id=f"pattern_{pattern.get('pattern_id', 'unknown')}_{int(time.time())}",
                template_id=None,
                category=GoalCategory(pattern.get("category", "task_completion")),
                description=pattern.get("description", "Pattern-based goal"),
                priority=GoalPriority(pattern.get("priority", 3)),
                context=context,
                steps=pattern.get("steps", []),
                success_criteria=pattern.get("success_criteria", []),
            )
        except (ValueError, KeyError):
            return None

    def _score_goals(
        self,
        goals: List[GoalCandidate],
        context: Dict[str, Any],
    ) -> List[GoalCandidate]:
        """Score goals based on context and preferences."""
        for goal in goals:
            # Relevance scoring
            goal.relevance_score = self._calculate_relevance(goal, context)

            # Feasibility scoring
            goal.feasibility_score = self._calculate_feasibility(goal, context)

            # User alignment scoring
            goal.user_alignment_score = self._calculate_user_alignment(goal)

        return goals

    def _calculate_relevance(
        self,
        goal: GoalCandidate,
        context: Dict[str, Any],
    ) -> float:
        """Calculate goal relevance to current context."""
        score = 0.5

        # Check if goal addresses current task
        current_task = context.get("current_task", "")
        if current_task and current_task.lower() in goal.description.lower():
            score += 0.3

        # Check if goal addresses recent query
        recent_queries = context.get("recent_queries", [])
        for query in recent_queries[-3:]:
            if isinstance(query, str) and query.lower() in goal.description.lower():
                score += 0.1

        # Check category relevance
        category_weights = {
            GoalCategory.ERROR_RECOVERY: 0.1,  # Always somewhat relevant
            GoalCategory.TASK_COMPLETION: 0.1,
        }
        score += category_weights.get(goal.category, 0.0)

        return min(1.0, score)

    def _calculate_feasibility(
        self,
        goal: GoalCandidate,
        context: Dict[str, Any],
    ) -> float:
        """Calculate goal feasibility."""
        score = 0.7  # Base feasibility

        # Check step count
        step_count = len(goal.steps)
        if step_count > 10:
            score -= 0.2
        elif step_count <= 3:
            score += 0.1

        # Check resource availability
        available_tools = context.get("available_tools", [])
        if available_tools:
            score += 0.1

        return min(1.0, max(0.0, score))

    def _calculate_user_alignment(
        self,
        goal: GoalCandidate,
    ) -> float:
        """Calculate alignment with user preferences."""
        score = 0.5

        # Check category preferences
        preferred_categories = self._user_prefs.get("preferred_goal_categories", [])
        if goal.category.value in preferred_categories:
            score += 0.3

        # Check priority preferences
        min_priority = self._user_prefs.get("min_goal_priority", 1)
        if goal.priority.value >= min_priority:
            score += 0.1

        # Check against blocked patterns
        blocked_patterns = self._user_prefs.get("blocked_goal_patterns", [])
        for pattern in blocked_patterns:
            if re.search(pattern, goal.description, re.IGNORECASE):
                score -= 0.4

        return min(1.0, max(0.0, score))

    def _filter_conflicts(
        self,
        goals: List[GoalCandidate],
    ) -> List[GoalCandidate]:
        """Filter out conflicting goals."""
        filtered = []
        seen_descriptions: Set[str] = set()

        for goal in goals:
            # Check for duplicates
            desc_key = goal.description.lower()[:50]
            if desc_key in seen_descriptions:
                continue

            seen_descriptions.add(desc_key)
            filtered.append(goal)

        return filtered

    def _store_generation(self, result: GenerationResult):
        """Store generation result for learning."""
        summary = {
            "goal_count": len(result.goals),
            "strategies": [g.source_strategy.value for g in result.goals if g.source_strategy],
            "categories": [g.category.value for g in result.goals],
            "avg_score": sum(g.get_composite_score() for g in result.goals) / max(1, len(result.goals)),
        }
        self._memory.store(
            json.dumps(summary),
            metadata={
                "type": "generation_result",
                "goal_count": len(result.goals),
            },
        )

    def get_statistics(self) -> Dict[str, Any]:
        """Get generator statistics."""
        total_goals = sum(len(r.goals) for r in self._generation_history)
        return {
            "template_count": len(self._templates),
            "generation_count": len(self._generation_history),
            "total_goals_generated": total_goals,
            "user_prefs_set": len(self._user_prefs),
        }


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def generate_goals(
    context: Dict[str, Any],
    max_goals: int = 10,
) -> List[GoalCandidate]:
    """
    Generate goals from context.

    Args:
        context: Context dictionary
        max_goals: Maximum goals to return

    Returns:
        List of goal candidates
    """
    generator = GoalGenerator()
    result = generator.generate(context, max_goals=max_goals)
    return result.goals


def get_proactive_suggestions(
    session_state: Dict[str, Any],
) -> List[GoalCandidate]:
    """
    Get proactive goal suggestions.

    Args:
        session_state: Current session state

    Returns:
        List of proactive suggestions
    """
    generator = GoalGenerator()
    return generator.get_proactive_suggestions(session_state)


def create_goal(
    description: str,
    category: GoalCategory = GoalCategory.TASK_COMPLETION,
    priority: GoalPriority = GoalPriority.MEDIUM,
    steps: Optional[List[str]] = None,
) -> GoalCandidate:
    """
    Create a goal manually.

    Args:
        description: Goal description
        category: Goal category
        priority: Goal priority
        steps: Goal steps

    Returns:
        GoalCandidate
    """
    return GoalCandidate(
        goal_id=f"manual_{int(time.time())}_{hash(description) % 10000}",
        template_id=None,
        category=category,
        description=description,
        priority=priority,
        context={},
        steps=steps or ["Execute goal"],
        success_criteria=["Goal completed"],
    )


# =============================================================================
# MODULE EXPORTS
# =============================================================================

__all__ = [
    # Enums
    "GoalCategory",
    "GoalPriority",
    "GoalStatus",
    "GenerationStrategy",
    # Data classes
    "GoalTemplate",
    "GoalCandidate",
    "GenerationResult",
    # Classes
    "GoalGenerator",
    # Functions
    "generate_goals",
    "get_proactive_suggestions",
    "create_goal",
    # Constants
    "DEFAULT_TEMPLATES",
]
