"""
world_state_simulation.py
~~~~~~~~~~~~~~~~~~~~~~~~~

World State Simulation for Counterfactual Reasoning

This module provides a simulation environment for predicting the effects
of actions before they are executed. It enables:

1. **Counterfactual Analysis**: "What would happen if I did X?"
2. **Risk Assessment**: Evaluate potential consequences of actions
3. **Rollback Simulation**: Simulate state changes and revert them
4. **Multi-Step Planning**: Chain simulated actions to predict outcomes

Architecture:
- WorldState: Immutable snapshot of system state
- StateChange: Represents a single state transition
- Simulator: Executes hypothetical actions on simulated state
- SimulationResult: Predicted outcomes with confidence scores

Usage:
    from brains.agent.autonomous.world_state_simulation import (
        WorldStateSimulator,
        SimulationResult,
        simulate_action_sequence,
    )

    simulator = WorldStateSimulator()

    # Simulate a single action
    result = simulator.simulate(
        action="create_file",
        params={"path": "/tmp/test.txt", "content": "hello"},
    )

    # Check predicted outcome
    if result.success_probability > 0.8:
        # Safe to execute
        pass

    # Simulate action sequence
    results = simulate_action_sequence([
        {"action": "read_file", "params": {"path": "config.json"}},
        {"action": "modify", "params": {"key": "setting", "value": True}},
        {"action": "write_file", "params": {"path": "config.json"}},
    ])

Author: Maven Self-Upgrade
Created: December 2025
"""

from __future__ import annotations

import copy
import hashlib
import json
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple, Union

from brains.memory.brain_memory import BrainMemory


# =============================================================================
# ENUMS AND TYPES
# =============================================================================

class ActionCategory(Enum):
    """Categories of actions for simulation."""
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
    FILE_DELETE = "file_delete"
    SHELL_COMMAND = "shell_command"
    NETWORK_REQUEST = "network_request"
    MEMORY_OPERATION = "memory_operation"
    STATE_QUERY = "state_query"
    COMPUTATION = "computation"
    EXTERNAL_API = "external_api"
    UNKNOWN = "unknown"


class RiskLevel(Enum):
    """Risk levels for actions."""
    SAFE = "safe"              # No side effects
    LOW = "low"                # Reversible side effects
    MEDIUM = "medium"          # Significant but recoverable
    HIGH = "high"              # Potentially destructive
    CRITICAL = "critical"      # Irreversible changes


class SimulationStatus(Enum):
    """Status of a simulation."""
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    BLOCKED = "blocked"
    UNKNOWN = "unknown"


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class WorldState:
    """
    Immutable snapshot of the world state.

    Represents the current state of the system including:
    - File system state (files, directories)
    - Memory state (working memory, brain memories)
    - Environment state (environment variables, settings)
    - Session state (context, history)
    """
    timestamp: float
    state_id: str

    # Core state components
    files: Dict[str, Dict[str, Any]] = field(default_factory=dict)
    directories: Set[str] = field(default_factory=set)
    memory_state: Dict[str, Any] = field(default_factory=dict)
    environment: Dict[str, str] = field(default_factory=dict)
    session_context: Dict[str, Any] = field(default_factory=dict)

    # Metadata
    parent_state_id: Optional[str] = None
    action_that_created: Optional[str] = None

    def __post_init__(self):
        """Convert mutable defaults."""
        if isinstance(self.directories, list):
            self.directories = set(self.directories)

    def clone(self) -> "WorldState":
        """Create a deep copy of this state."""
        return WorldState(
            timestamp=time.time(),
            state_id=self._generate_id(),
            files=copy.deepcopy(self.files),
            directories=copy.deepcopy(self.directories),
            memory_state=copy.deepcopy(self.memory_state),
            environment=copy.deepcopy(self.environment),
            session_context=copy.deepcopy(self.session_context),
            parent_state_id=self.state_id,
            action_that_created=None,
        )

    def _generate_id(self) -> str:
        """Generate unique state ID."""
        content = json.dumps({
            "ts": time.time(),
            "files": list(self.files.keys())[:10],
            "parent": self.parent_state_id,
        }, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def get_hash(self) -> str:
        """Get content hash for comparison."""
        content = json.dumps({
            "files": sorted(self.files.keys()),
            "dirs": sorted(self.directories),
            "env": sorted(self.environment.keys()),
        }, sort_keys=True)
        return hashlib.sha256(content.encode()).hexdigest()[:12]

    def diff(self, other: "WorldState") -> Dict[str, Any]:
        """Compare this state with another."""
        diff = {
            "files_added": [],
            "files_removed": [],
            "files_modified": [],
            "dirs_added": [],
            "dirs_removed": [],
            "env_changed": [],
        }

        # File changes
        our_files = set(self.files.keys())
        their_files = set(other.files.keys())

        diff["files_added"] = list(their_files - our_files)
        diff["files_removed"] = list(our_files - their_files)

        for f in our_files & their_files:
            if self.files[f] != other.files[f]:
                diff["files_modified"].append(f)

        # Directory changes
        diff["dirs_added"] = list(other.directories - self.directories)
        diff["dirs_removed"] = list(self.directories - other.directories)

        # Environment changes
        for k in set(self.environment.keys()) | set(other.environment.keys()):
            if self.environment.get(k) != other.environment.get(k):
                diff["env_changed"].append(k)

        return diff

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "timestamp": self.timestamp,
            "state_id": self.state_id,
            "files": list(self.files.keys()),
            "directories": list(self.directories),
            "memory_keys": list(self.memory_state.keys()),
            "environment_keys": list(self.environment.keys()),
            "parent_state_id": self.parent_state_id,
            "hash": self.get_hash(),
        }


@dataclass
class StateChange:
    """Represents a single state transition."""
    change_type: str
    target: str
    old_value: Any = None
    new_value: Any = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def is_reversible(self) -> bool:
        """Check if this change can be reversed."""
        reversible_types = {
            "file_create", "file_modify", "file_delete",
            "dir_create", "dir_delete",
            "memory_store", "memory_delete",
            "env_set", "env_unset",
        }
        return self.change_type in reversible_types

    def get_reverse(self) -> Optional["StateChange"]:
        """Get the reverse of this change."""
        if not self.is_reversible():
            return None

        reverse_map = {
            "file_create": "file_delete",
            "file_delete": "file_create",
            "file_modify": "file_modify",
            "dir_create": "dir_delete",
            "dir_delete": "dir_create",
            "memory_store": "memory_delete",
            "memory_delete": "memory_store",
            "env_set": "env_unset" if self.old_value is None else "env_set",
            "env_unset": "env_set",
        }

        return StateChange(
            change_type=reverse_map.get(self.change_type, self.change_type),
            target=self.target,
            old_value=self.new_value,
            new_value=self.old_value,
            metadata={"reversed_from": self.change_type},
        )


@dataclass
class ActionEffect:
    """Predicted effect of an action."""
    category: ActionCategory
    risk_level: RiskLevel
    changes: List[StateChange]
    side_effects: List[str]
    preconditions: List[str]
    postconditions: List[str]

    def total_risk_score(self) -> float:
        """Calculate overall risk score (0-1)."""
        risk_weights = {
            RiskLevel.SAFE: 0.0,
            RiskLevel.LOW: 0.2,
            RiskLevel.MEDIUM: 0.5,
            RiskLevel.HIGH: 0.8,
            RiskLevel.CRITICAL: 1.0,
        }
        base_risk = risk_weights.get(self.risk_level, 0.5)

        # Adjust for number of changes
        change_factor = min(len(self.changes) * 0.05, 0.3)

        # Adjust for side effects
        side_effect_factor = min(len(self.side_effects) * 0.1, 0.3)

        return min(base_risk + change_factor + side_effect_factor, 1.0)


@dataclass
class SimulationResult:
    """Result of a simulation."""
    action: str
    params: Dict[str, Any]
    status: SimulationStatus
    success_probability: float
    final_state: Optional[WorldState]
    effects: List[ActionEffect]
    warnings: List[str]
    errors: List[str]
    execution_time_estimate: float
    rollback_possible: bool

    def is_safe(self, threshold: float = 0.7) -> bool:
        """Check if action is considered safe."""
        if self.status == SimulationStatus.BLOCKED:
            return False
        if self.success_probability < threshold:
            return False

        max_risk = max(
            (e.total_risk_score() for e in self.effects),
            default=0.0
        )
        return max_risk < 0.5

    def get_risk_summary(self) -> Dict[str, Any]:
        """Get summary of risks."""
        return {
            "success_probability": self.success_probability,
            "rollback_possible": self.rollback_possible,
            "warning_count": len(self.warnings),
            "error_count": len(self.errors),
            "total_changes": sum(len(e.changes) for e in self.effects),
            "max_risk_level": max(
                (e.risk_level.value for e in self.effects),
                default="unknown"
            ),
        }

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "action": self.action,
            "params": self.params,
            "status": self.status.value,
            "success_probability": self.success_probability,
            "warnings": self.warnings,
            "errors": self.errors,
            "execution_time_estimate": self.execution_time_estimate,
            "rollback_possible": self.rollback_possible,
            "risk_summary": self.get_risk_summary(),
        }


# =============================================================================
# ACTION EFFECT PREDICTORS
# =============================================================================

class ActionEffectPredictor:
    """Predicts effects of actions based on patterns."""

    def __init__(self):
        """Initialize with default prediction rules."""
        self._rules: Dict[str, Callable] = {}
        self._register_default_rules()

    def _register_default_rules(self):
        """Register default prediction rules."""
        # File operations
        self._rules["create_file"] = self._predict_file_create
        self._rules["write_file"] = self._predict_file_write
        self._rules["read_file"] = self._predict_file_read
        self._rules["delete_file"] = self._predict_file_delete
        self._rules["move_file"] = self._predict_file_move

        # Shell operations
        self._rules["shell_command"] = self._predict_shell_command
        self._rules["execute"] = self._predict_shell_command

        # Memory operations
        self._rules["memory_store"] = self._predict_memory_store
        self._rules["memory_retrieve"] = self._predict_memory_retrieve
        self._rules["memory_delete"] = self._predict_memory_delete

        # Network operations
        self._rules["http_request"] = self._predict_network_request
        self._rules["api_call"] = self._predict_api_call

    def predict(
        self,
        action: str,
        params: Dict[str, Any],
        current_state: WorldState,
    ) -> ActionEffect:
        """Predict the effect of an action."""
        predictor = self._rules.get(action, self._predict_unknown)
        return predictor(action, params, current_state)

    def _predict_file_create(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict file creation effect."""
        path = params.get("path", "")
        content = params.get("content", "")

        changes = [
            StateChange(
                change_type="file_create",
                target=path,
                old_value=None,
                new_value={"content": content[:100], "size": len(content)},
            )
        ]

        preconditions = []
        side_effects = []

        # Check if file already exists
        if path in state.files:
            preconditions.append(f"File {path} already exists - will overwrite")
            changes[0].change_type = "file_modify"
            changes[0].old_value = state.files.get(path)

        # Check parent directory
        parent = str(Path(path).parent)
        if parent and parent != "." and parent not in state.directories:
            side_effects.append(f"Will create parent directory: {parent}")
            changes.append(StateChange(
                change_type="dir_create",
                target=parent,
            ))

        return ActionEffect(
            category=ActionCategory.FILE_WRITE,
            risk_level=RiskLevel.LOW,
            changes=changes,
            side_effects=side_effects,
            preconditions=preconditions,
            postconditions=[f"File {path} will exist"],
        )

    def _predict_file_write(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict file write effect."""
        path = params.get("path", "")
        content = params.get("content", "")

        old_content = state.files.get(path, {}).get("content")

        changes = [
            StateChange(
                change_type="file_modify",
                target=path,
                old_value=old_content,
                new_value=content[:100] if content else None,
            )
        ]

        risk = RiskLevel.LOW
        preconditions = []

        if path not in state.files:
            preconditions.append(f"File {path} does not exist - will create")
            risk = RiskLevel.LOW
        elif path.endswith((".py", ".json", ".yaml", ".yml", ".toml")):
            # Config/code files are higher risk
            risk = RiskLevel.MEDIUM

        return ActionEffect(
            category=ActionCategory.FILE_WRITE,
            risk_level=risk,
            changes=changes,
            side_effects=[],
            preconditions=preconditions,
            postconditions=[f"File {path} will contain new content"],
        )

    def _predict_file_read(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict file read effect (no changes)."""
        path = params.get("path", "")

        preconditions = []
        if path not in state.files:
            preconditions.append(f"File {path} may not exist")

        return ActionEffect(
            category=ActionCategory.FILE_READ,
            risk_level=RiskLevel.SAFE,
            changes=[],
            side_effects=[],
            preconditions=preconditions,
            postconditions=[],
        )

    def _predict_file_delete(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict file deletion effect."""
        path = params.get("path", "")

        old_content = state.files.get(path)

        changes = [
            StateChange(
                change_type="file_delete",
                target=path,
                old_value=old_content,
                new_value=None,
            )
        ]

        preconditions = []
        if path not in state.files:
            preconditions.append(f"File {path} does not exist")

        return ActionEffect(
            category=ActionCategory.FILE_DELETE,
            risk_level=RiskLevel.MEDIUM,
            changes=changes,
            side_effects=[],
            preconditions=preconditions,
            postconditions=[f"File {path} will not exist"],
        )

    def _predict_file_move(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict file move effect."""
        source = params.get("source", params.get("from", ""))
        dest = params.get("dest", params.get("to", ""))

        changes = [
            StateChange(
                change_type="file_delete",
                target=source,
                old_value=state.files.get(source),
            ),
            StateChange(
                change_type="file_create",
                target=dest,
                new_value=state.files.get(source),
            ),
        ]

        preconditions = []
        if source not in state.files:
            preconditions.append(f"Source file {source} does not exist")
        if dest in state.files:
            preconditions.append(f"Destination {dest} exists - will overwrite")

        return ActionEffect(
            category=ActionCategory.FILE_WRITE,
            risk_level=RiskLevel.MEDIUM,
            changes=changes,
            side_effects=[],
            preconditions=preconditions,
            postconditions=[
                f"File {source} will not exist",
                f"File {dest} will exist",
            ],
        )

    def _predict_shell_command(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict shell command effect."""
        command = params.get("command", "")

        # Analyze command for risk
        risk = RiskLevel.LOW
        side_effects = []
        preconditions = []

        dangerous_patterns = [
            ("rm -rf", RiskLevel.CRITICAL),
            ("rm -r", RiskLevel.HIGH),
            ("rm ", RiskLevel.MEDIUM),
            ("sudo", RiskLevel.HIGH),
            ("> /dev", RiskLevel.CRITICAL),
            ("dd if=", RiskLevel.CRITICAL),
            ("mkfs", RiskLevel.CRITICAL),
            ("chmod 777", RiskLevel.MEDIUM),
            ("curl | sh", RiskLevel.CRITICAL),
            ("wget | sh", RiskLevel.CRITICAL),
        ]

        for pattern, pattern_risk in dangerous_patterns:
            if pattern in command.lower():
                risk = max(risk, pattern_risk, key=lambda r: r.value)
                side_effects.append(f"Command contains '{pattern}'")

        # Check for file modifications
        if ">" in command or ">>" in command:
            side_effects.append("Command writes to file")
            risk = max(risk, RiskLevel.LOW)

        return ActionEffect(
            category=ActionCategory.SHELL_COMMAND,
            risk_level=risk,
            changes=[],  # Shell effects are unpredictable
            side_effects=side_effects,
            preconditions=preconditions,
            postconditions=[],
        )

    def _predict_memory_store(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict memory store effect."""
        key = params.get("key", params.get("content", "")[:20])

        return ActionEffect(
            category=ActionCategory.MEMORY_OPERATION,
            risk_level=RiskLevel.SAFE,
            changes=[
                StateChange(
                    change_type="memory_store",
                    target=key,
                    new_value=True,
                )
            ],
            side_effects=[],
            preconditions=[],
            postconditions=[f"Memory will contain: {key}"],
        )

    def _predict_memory_retrieve(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict memory retrieval effect."""
        return ActionEffect(
            category=ActionCategory.MEMORY_OPERATION,
            risk_level=RiskLevel.SAFE,
            changes=[],
            side_effects=[],
            preconditions=[],
            postconditions=[],
        )

    def _predict_memory_delete(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict memory deletion effect."""
        key = params.get("key", "")

        return ActionEffect(
            category=ActionCategory.MEMORY_OPERATION,
            risk_level=RiskLevel.LOW,
            changes=[
                StateChange(
                    change_type="memory_delete",
                    target=key,
                    old_value=state.memory_state.get(key),
                )
            ],
            side_effects=[],
            preconditions=[],
            postconditions=[f"Memory will not contain: {key}"],
        )

    def _predict_network_request(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict network request effect."""
        method = params.get("method", "GET").upper()
        url = params.get("url", "")

        risk = RiskLevel.LOW if method == "GET" else RiskLevel.MEDIUM

        return ActionEffect(
            category=ActionCategory.NETWORK_REQUEST,
            risk_level=risk,
            changes=[],
            side_effects=[f"Will make {method} request to {url}"],
            preconditions=["Network connectivity required"],
            postconditions=[],
        )

    def _predict_api_call(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict API call effect."""
        return ActionEffect(
            category=ActionCategory.EXTERNAL_API,
            risk_level=RiskLevel.MEDIUM,
            changes=[],
            side_effects=["External API state may change"],
            preconditions=["API availability required"],
            postconditions=[],
        )

    def _predict_unknown(
        self,
        action: str,
        params: Dict[str, Any],
        state: WorldState,
    ) -> ActionEffect:
        """Predict unknown action effect."""
        return ActionEffect(
            category=ActionCategory.UNKNOWN,
            risk_level=RiskLevel.MEDIUM,
            changes=[],
            side_effects=[f"Unknown action: {action}"],
            preconditions=[],
            postconditions=[],
        )


# =============================================================================
# WORLD STATE SIMULATOR
# =============================================================================

class WorldStateSimulator:
    """
    Simulates world state changes for counterfactual reasoning.

    This class maintains a simulation environment that can:
    - Track current world state
    - Predict effects of actions
    - Apply simulated changes
    - Compare states before/after
    - Assess risk and reversibility
    """

    def __init__(self, initial_state: Optional[WorldState] = None):
        """
        Initialize simulator.

        Args:
            initial_state: Starting world state (creates empty if None)
        """
        self._memory = BrainMemory("world_simulation")
        self._predictor = ActionEffectPredictor()
        self._current_state = initial_state or self._create_initial_state()
        self._state_history: List[WorldState] = [self._current_state]
        self._simulation_count = 0

    def _create_initial_state(self) -> WorldState:
        """Create initial world state."""
        return WorldState(
            timestamp=time.time(),
            state_id="initial_" + hashlib.sha256(
                str(time.time()).encode()
            ).hexdigest()[:12],
        )

    @property
    def current_state(self) -> WorldState:
        """Get current world state."""
        return self._current_state

    def update_state(
        self,
        files: Optional[Dict[str, Any]] = None,
        directories: Optional[Set[str]] = None,
        memory_state: Optional[Dict[str, Any]] = None,
        environment: Optional[Dict[str, str]] = None,
    ) -> WorldState:
        """
        Update the current world state.

        Args:
            files: File state updates
            directories: Directory updates
            memory_state: Memory state updates
            environment: Environment updates

        Returns:
            Updated world state
        """
        new_state = self._current_state.clone()

        if files:
            new_state.files.update(files)
        if directories:
            new_state.directories.update(directories)
        if memory_state:
            new_state.memory_state.update(memory_state)
        if environment:
            new_state.environment.update(environment)

        self._current_state = new_state
        self._state_history.append(new_state)

        return new_state

    def simulate(
        self,
        action: str,
        params: Dict[str, Any],
        apply_changes: bool = False,
    ) -> SimulationResult:
        """
        Simulate an action and predict its effects.

        Args:
            action: Action to simulate
            params: Action parameters
            apply_changes: Whether to apply changes to state

        Returns:
            SimulationResult with predictions
        """
        self._simulation_count += 1
        start_time = time.time()

        # Predict effects
        effect = self._predictor.predict(action, params, self._current_state)

        # Calculate success probability
        success_prob = self._calculate_success_probability(action, params, effect)

        # Determine status
        if effect.risk_level == RiskLevel.CRITICAL:
            status = SimulationStatus.BLOCKED
        elif success_prob > 0.8:
            status = SimulationStatus.SUCCESS
        elif success_prob > 0.5:
            status = SimulationStatus.PARTIAL
        else:
            status = SimulationStatus.FAILURE

        # Generate warnings
        warnings = []
        for precond in effect.preconditions:
            warnings.append(f"Precondition: {precond}")
        for side_effect in effect.side_effects:
            warnings.append(f"Side effect: {side_effect}")

        # Generate errors
        errors = []
        if effect.risk_level in (RiskLevel.HIGH, RiskLevel.CRITICAL):
            errors.append(f"High risk action: {effect.risk_level.value}")

        # Calculate final state if applying changes
        final_state = None
        if apply_changes and status != SimulationStatus.BLOCKED:
            final_state = self._apply_effects(effect)

        # Check reversibility
        rollback_possible = all(c.is_reversible() for c in effect.changes)

        result = SimulationResult(
            action=action,
            params=params,
            status=status,
            success_probability=success_prob,
            final_state=final_state,
            effects=[effect],
            warnings=warnings,
            errors=errors,
            execution_time_estimate=time.time() - start_time,
            rollback_possible=rollback_possible,
        )

        # Store simulation for learning
        self._store_simulation(result)

        return result

    def simulate_sequence(
        self,
        actions: List[Dict[str, Any]],
        stop_on_failure: bool = True,
    ) -> List[SimulationResult]:
        """
        Simulate a sequence of actions.

        Args:
            actions: List of {"action": str, "params": dict}
            stop_on_failure: Stop if any action fails

        Returns:
            List of simulation results
        """
        results = []

        # Clone state for simulation
        sim_state = self._current_state.clone()
        original_state = self._current_state

        try:
            for action_def in actions:
                action = action_def.get("action", "")
                params = action_def.get("params", {})

                # Temporarily use simulated state
                self._current_state = sim_state

                result = self.simulate(action, params, apply_changes=True)
                results.append(result)

                if stop_on_failure and result.status in (
                    SimulationStatus.FAILURE,
                    SimulationStatus.BLOCKED,
                ):
                    break

                # Update simulation state
                if result.final_state:
                    sim_state = result.final_state
        finally:
            # Restore original state
            self._current_state = original_state

        return results

    def compare_states(
        self,
        before: WorldState,
        after: WorldState,
    ) -> Dict[str, Any]:
        """
        Compare two world states.

        Args:
            before: State before changes
            after: State after changes

        Returns:
            Diff dictionary
        """
        return before.diff(after)

    def get_rollback_actions(
        self,
        result: SimulationResult,
    ) -> List[Dict[str, Any]]:
        """
        Get actions to rollback a simulation result.

        Args:
            result: Simulation result to rollback

        Returns:
            List of rollback actions
        """
        rollback_actions = []

        for effect in result.effects:
            for change in reversed(effect.changes):
                reverse = change.get_reverse()
                if reverse:
                    rollback_actions.append({
                        "action": reverse.change_type,
                        "params": {
                            "target": reverse.target,
                            "value": reverse.new_value,
                        },
                    })

        return rollback_actions

    def _calculate_success_probability(
        self,
        action: str,
        params: Dict[str, Any],
        effect: ActionEffect,
    ) -> float:
        """Calculate probability of action success."""
        # Base probability by category
        base_probs = {
            ActionCategory.FILE_READ: 0.95,
            ActionCategory.FILE_WRITE: 0.90,
            ActionCategory.FILE_DELETE: 0.85,
            ActionCategory.SHELL_COMMAND: 0.75,
            ActionCategory.NETWORK_REQUEST: 0.80,
            ActionCategory.MEMORY_OPERATION: 0.99,
            ActionCategory.STATE_QUERY: 0.99,
            ActionCategory.COMPUTATION: 0.95,
            ActionCategory.EXTERNAL_API: 0.70,
            ActionCategory.UNKNOWN: 0.50,
        }

        prob = base_probs.get(effect.category, 0.50)

        # Adjust for preconditions
        prob -= len(effect.preconditions) * 0.05

        # Adjust for risk
        risk_penalties = {
            RiskLevel.SAFE: 0.0,
            RiskLevel.LOW: 0.02,
            RiskLevel.MEDIUM: 0.05,
            RiskLevel.HIGH: 0.15,
            RiskLevel.CRITICAL: 0.30,
        }
        prob -= risk_penalties.get(effect.risk_level, 0.1)

        return max(0.0, min(1.0, prob))

    def _apply_effects(self, effect: ActionEffect) -> WorldState:
        """Apply predicted effects to create new state."""
        new_state = self._current_state.clone()
        new_state.action_that_created = f"{effect.category.value}"

        for change in effect.changes:
            if change.change_type == "file_create":
                new_state.files[change.target] = change.new_value or {}
            elif change.change_type == "file_modify":
                if change.target in new_state.files:
                    new_state.files[change.target] = change.new_value or {}
                else:
                    new_state.files[change.target] = change.new_value or {}
            elif change.change_type == "file_delete":
                new_state.files.pop(change.target, None)
            elif change.change_type == "dir_create":
                new_state.directories.add(change.target)
            elif change.change_type == "dir_delete":
                new_state.directories.discard(change.target)
            elif change.change_type == "memory_store":
                new_state.memory_state[change.target] = change.new_value
            elif change.change_type == "memory_delete":
                new_state.memory_state.pop(change.target, None)
            elif change.change_type in ("env_set", "env_unset"):
                if change.new_value is not None:
                    new_state.environment[change.target] = str(change.new_value)
                else:
                    new_state.environment.pop(change.target, None)

        self._current_state = new_state
        self._state_history.append(new_state)

        return new_state

    def _store_simulation(self, result: SimulationResult):
        """Store simulation result for learning."""
        self._memory.store(
            json.dumps({
                "action": result.action,
                "status": result.status.value,
                "success_prob": result.success_probability,
                "risk_summary": result.get_risk_summary(),
            }),
            metadata={
                "type": "simulation_result",
                "action": result.action,
                "status": result.status.value,
            },
        )

    def get_statistics(self) -> Dict[str, Any]:
        """Get simulation statistics."""
        return {
            "simulation_count": self._simulation_count,
            "state_history_length": len(self._state_history),
            "current_state_hash": self._current_state.get_hash(),
            "current_file_count": len(self._current_state.files),
            "current_dir_count": len(self._current_state.directories),
        }


# =============================================================================
# CONVENIENCE FUNCTIONS
# =============================================================================

def create_simulator(
    files: Optional[Dict[str, Any]] = None,
    directories: Optional[Set[str]] = None,
) -> WorldStateSimulator:
    """
    Create a simulator with initial state.

    Args:
        files: Initial file state
        directories: Initial directories

    Returns:
        Configured simulator
    """
    initial_state = WorldState(
        timestamp=time.time(),
        state_id="init_" + hashlib.sha256(str(time.time()).encode()).hexdigest()[:12],
        files=files or {},
        directories=directories or set(),
    )
    return WorldStateSimulator(initial_state)


def simulate_action(
    action: str,
    params: Dict[str, Any],
    current_files: Optional[Dict[str, Any]] = None,
) -> SimulationResult:
    """
    Quick simulation of a single action.

    Args:
        action: Action to simulate
        params: Action parameters
        current_files: Current file state

    Returns:
        Simulation result
    """
    simulator = create_simulator(files=current_files)
    return simulator.simulate(action, params)


def simulate_action_sequence(
    actions: List[Dict[str, Any]],
    current_files: Optional[Dict[str, Any]] = None,
) -> List[SimulationResult]:
    """
    Simulate a sequence of actions.

    Args:
        actions: List of action definitions
        current_files: Current file state

    Returns:
        List of simulation results
    """
    simulator = create_simulator(files=current_files)
    return simulator.simulate_sequence(actions)


def assess_action_risk(
    action: str,
    params: Dict[str, Any],
) -> Dict[str, Any]:
    """
    Quick risk assessment for an action.

    Args:
        action: Action to assess
        params: Action parameters

    Returns:
        Risk assessment dictionary
    """
    result = simulate_action(action, params)
    return {
        "action": action,
        "is_safe": result.is_safe(),
        "risk_summary": result.get_risk_summary(),
        "warnings": result.warnings,
        "rollback_possible": result.rollback_possible,
    }


# =============================================================================
# MODULE EXPORTS
# =============================================================================

__all__ = [
    # Enums
    "ActionCategory",
    "RiskLevel",
    "SimulationStatus",
    # Data classes
    "WorldState",
    "StateChange",
    "ActionEffect",
    "SimulationResult",
    # Classes
    "ActionEffectPredictor",
    "WorldStateSimulator",
    # Functions
    "create_simulator",
    "simulate_action",
    "simulate_action_sequence",
    "assess_action_risk",
]
