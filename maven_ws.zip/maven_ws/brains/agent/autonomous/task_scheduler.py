"""
Background Task Scheduler
=========================

A persistent task scheduler for scheduling and managing background tasks.
Tasks are stored in a JSONL file and can be scheduled for:
- Immediate execution
- Future execution (scheduled_at timestamp)
- Recurring execution (cron-like patterns)

This integrates with the existing GoalQueue but adds scheduling capabilities.

Features:
- Persistent task queue (survives restarts)
- Task scheduling with timestamps
- Priority ordering
- Dependency tracking
- Automatic retry with backoff
- Task status tracking
"""

from __future__ import annotations

import json
import time
import uuid
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set

from brains.maven_paths import get_reports_path


# Storage path
SCHEDULER_DB_PATH = get_reports_path("task_scheduler.jsonl")
SCHEDULER_STATE_PATH = get_reports_path("scheduler_state.json")


class TaskStatus(Enum):
    """Task status values."""
    PENDING = "pending"          # Waiting to be scheduled
    SCHEDULED = "scheduled"      # Scheduled for future execution
    READY = "ready"              # Ready to execute now
    RUNNING = "running"          # Currently executing
    COMPLETED = "completed"      # Successfully completed
    FAILED = "failed"            # Failed execution
    CANCELLED = "cancelled"      # Cancelled by user/system
    DEFERRED = "deferred"        # Deferred for later


class TaskPriority(Enum):
    """Task priority levels."""
    CRITICAL = 0    # Execute immediately
    HIGH = 1        # High priority
    NORMAL = 2      # Normal priority
    LOW = 3         # Low priority
    BACKGROUND = 4  # Background task


@dataclass
class ScheduledTask:
    """A scheduled task in the queue."""
    task_id: str
    title: str
    description: str = ""
    status: str = "pending"
    priority: int = 2  # NORMAL

    # Scheduling
    created_at: float = field(default_factory=time.time)
    scheduled_at: Optional[float] = None  # When to execute (None = ASAP)
    started_at: Optional[float] = None
    completed_at: Optional[float] = None

    # Execution
    handler: str = ""  # Handler function/brain to execute
    params: Dict[str, Any] = field(default_factory=dict)
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    # Retry config
    max_retries: int = 3
    retry_count: int = 0
    retry_backoff_seconds: int = 60

    # Dependencies
    depends_on: List[str] = field(default_factory=list)
    blocks: List[str] = field(default_factory=list)

    # Metadata
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Recurrence (cron-like)
    recurring: bool = False
    recurrence_pattern: Optional[str] = None  # e.g., "daily", "hourly", "weekly"
    next_occurrence: Optional[float] = None

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ScheduledTask":
        """Create from dictionary."""
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})

    def is_ready(self, completed_tasks: Set[str]) -> bool:
        """Check if this task is ready to execute."""
        if self.status not in ["pending", "scheduled", "ready"]:
            return False

        # Check scheduled time
        if self.scheduled_at and time.time() < self.scheduled_at:
            return False

        # Check dependencies
        if self.depends_on:
            for dep_id in self.depends_on:
                if dep_id not in completed_tasks:
                    return False

        return True

    def can_retry(self) -> bool:
        """Check if this task can be retried."""
        return self.retry_count < self.max_retries


class TaskScheduler:
    """
    Persistent background task scheduler.

    Manages a queue of tasks that can be scheduled for immediate or
    future execution. Tasks are persisted to disk and survive restarts.
    """

    def __init__(self, auto_load: bool = True):
        """Initialize the scheduler."""
        self._tasks: Dict[str, ScheduledTask] = {}
        self._handlers: Dict[str, Callable] = {}
        self._running_task: Optional[str] = None
        self._last_check: float = 0
        self._check_interval_seconds: float = 5.0

        # Ensure storage directory exists
        SCHEDULER_DB_PATH.parent.mkdir(parents=True, exist_ok=True)

        if auto_load:
            self._load_tasks()

        print(f"[TASK_SCHEDULER] Initialized with {len(self._tasks)} tasks")

    def _load_tasks(self) -> None:
        """Load tasks from persistent storage."""
        if not SCHEDULER_DB_PATH.exists():
            return

        try:
            for line in SCHEDULER_DB_PATH.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                    task = ScheduledTask.from_dict(data)
                    self._tasks[task.task_id] = task
                except (json.JSONDecodeError, TypeError):
                    continue
            print(f"[TASK_SCHEDULER] Loaded {len(self._tasks)} tasks from disk")
        except Exception as e:
            print(f"[TASK_SCHEDULER] Error loading tasks: {e}")

    def _save_tasks(self) -> None:
        """Save all tasks to persistent storage."""
        try:
            lines = [json.dumps(task.to_dict()) for task in self._tasks.values()]
            content = "\n".join(lines)
            if content:
                content += "\n"
            SCHEDULER_DB_PATH.write_text(content)
        except Exception as e:
            print(f"[TASK_SCHEDULER] Error saving tasks: {e}")

    def _save_task(self, task: ScheduledTask) -> None:
        """Save a single task (append to JSONL)."""
        self._tasks[task.task_id] = task
        self._save_tasks()  # Full rewrite for simplicity

    # =========================================================================
    # Task Management
    # =========================================================================

    def schedule(
        self,
        title: str,
        description: str = "",
        handler: str = "",
        params: Optional[Dict[str, Any]] = None,
        scheduled_at: Optional[float] = None,
        priority: TaskPriority = TaskPriority.NORMAL,
        depends_on: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        max_retries: int = 3,
        recurring: bool = False,
        recurrence_pattern: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ScheduledTask:
        """
        Schedule a new task.

        Args:
            title: Short description of the task
            description: Detailed description
            handler: Handler function/brain name
            params: Parameters for the handler
            scheduled_at: Unix timestamp for execution (None = immediate)
            priority: Task priority level
            depends_on: List of task IDs this depends on
            tags: List of tags for filtering
            max_retries: Maximum retry attempts
            recurring: Whether this task recurs
            recurrence_pattern: Recurrence pattern ("hourly", "daily", "weekly")
            metadata: Additional metadata

        Returns:
            The created ScheduledTask
        """
        task_id = str(uuid.uuid4())[:8]

        task = ScheduledTask(
            task_id=task_id,
            title=title,
            description=description,
            status=TaskStatus.SCHEDULED.value if scheduled_at else TaskStatus.PENDING.value,
            priority=priority.value,
            scheduled_at=scheduled_at,
            handler=handler,
            params=params or {},
            depends_on=depends_on or [],
            tags=tags or [],
            max_retries=max_retries,
            recurring=recurring,
            recurrence_pattern=recurrence_pattern,
            metadata=metadata or {},
        )

        # Calculate next occurrence for recurring tasks
        if recurring and recurrence_pattern:
            task.next_occurrence = self._calculate_next_occurrence(recurrence_pattern)

        self._save_task(task)
        print(f"[TASK_SCHEDULER] Scheduled task '{title}' ({task_id})")

        return task

    def schedule_in(
        self,
        title: str,
        delay_seconds: float,
        **kwargs
    ) -> ScheduledTask:
        """Schedule a task to run after a delay."""
        scheduled_at = time.time() + delay_seconds
        return self.schedule(title, scheduled_at=scheduled_at, **kwargs)

    def schedule_at(
        self,
        title: str,
        dt: datetime,
        **kwargs
    ) -> ScheduledTask:
        """Schedule a task to run at a specific datetime."""
        scheduled_at = dt.timestamp()
        return self.schedule(title, scheduled_at=scheduled_at, **kwargs)

    def defer(self, task_id: str, delay_seconds: float = 3600) -> bool:
        """
        Defer a task to run later.

        Args:
            task_id: Task to defer
            delay_seconds: How long to defer (default: 1 hour)

        Returns:
            True if task was deferred
        """
        task = self._tasks.get(task_id)
        if not task:
            return False

        task.status = TaskStatus.DEFERRED.value
        task.scheduled_at = time.time() + delay_seconds
        self._save_task(task)

        print(f"[TASK_SCHEDULER] Deferred task '{task.title}' by {delay_seconds}s")
        return True

    def cancel(self, task_id: str) -> bool:
        """Cancel a task."""
        task = self._tasks.get(task_id)
        if not task:
            return False

        task.status = TaskStatus.CANCELLED.value
        self._save_task(task)

        print(f"[TASK_SCHEDULER] Cancelled task '{task.title}'")
        return True

    def reschedule(self, task_id: str, scheduled_at: float) -> bool:
        """Reschedule a task to a new time."""
        task = self._tasks.get(task_id)
        if not task:
            return False

        task.scheduled_at = scheduled_at
        task.status = TaskStatus.SCHEDULED.value
        self._save_task(task)

        return True

    def get_task(self, task_id: str) -> Optional[ScheduledTask]:
        """Get a task by ID."""
        return self._tasks.get(task_id)

    def list_tasks(
        self,
        status: Optional[TaskStatus] = None,
        tags: Optional[List[str]] = None,
        handler: Optional[str] = None,
        limit: int = 50,
    ) -> List[ScheduledTask]:
        """
        List tasks matching criteria.

        Args:
            status: Filter by status
            tags: Filter by tags (any match)
            handler: Filter by handler
            limit: Maximum tasks to return

        Returns:
            List of matching tasks
        """
        tasks = list(self._tasks.values())

        if status:
            tasks = [t for t in tasks if t.status == status.value]

        if tags:
            tasks = [t for t in tasks if any(tag in t.tags for tag in tags)]

        if handler:
            tasks = [t for t in tasks if t.handler == handler]

        # Sort by priority then by scheduled_at
        tasks.sort(key=lambda t: (t.priority, t.scheduled_at or 0))

        return tasks[:limit]

    def get_pending_tasks(self) -> List[ScheduledTask]:
        """Get all pending/ready tasks."""
        pending_statuses = {
            TaskStatus.PENDING.value,
            TaskStatus.SCHEDULED.value,
            TaskStatus.READY.value,
        }
        return [t for t in self._tasks.values() if t.status in pending_statuses]

    def get_ready_tasks(self) -> List[ScheduledTask]:
        """Get tasks that are ready to execute now."""
        completed_ids = {
            t.task_id for t in self._tasks.values()
            if t.status == TaskStatus.COMPLETED.value
        }

        ready = []
        for task in self._tasks.values():
            if task.is_ready(completed_ids):
                ready.append(task)

        # Sort by priority
        ready.sort(key=lambda t: t.priority)
        return ready

    # =========================================================================
    # Execution
    # =========================================================================

    def register_handler(self, name: str, handler: Callable) -> None:
        """Register a handler function for a task type."""
        self._handlers[name] = handler
        print(f"[TASK_SCHEDULER] Registered handler: {name}")

    def execute_task(self, task_id: str) -> Dict[str, Any]:
        """
        Execute a task by ID.

        Args:
            task_id: Task to execute

        Returns:
            Execution result
        """
        task = self._tasks.get(task_id)
        if not task:
            return {"status": "error", "error": f"Task not found: {task_id}"}

        # Mark as running
        task.status = TaskStatus.RUNNING.value
        task.started_at = time.time()
        self._running_task = task_id
        self._save_task(task)

        try:
            # Get handler
            handler = self._handlers.get(task.handler)
            if not handler:
                raise ValueError(f"No handler registered for: {task.handler}")

            # Execute
            result = handler(task.params)

            # Mark completed
            task.status = TaskStatus.COMPLETED.value
            task.completed_at = time.time()
            task.result = result

            # Handle recurring tasks
            if task.recurring and task.recurrence_pattern:
                self._schedule_next_occurrence(task)

            self._save_task(task)
            self._running_task = None

            print(f"[TASK_SCHEDULER] Completed task '{task.title}'")
            return {"status": "ok", "result": result}

        except Exception as e:
            task.retry_count += 1
            task.error = str(e)

            if task.can_retry():
                # Schedule retry with backoff
                backoff = task.retry_backoff_seconds * (2 ** (task.retry_count - 1))
                task.scheduled_at = time.time() + backoff
                task.status = TaskStatus.SCHEDULED.value
                print(f"[TASK_SCHEDULER] Task '{task.title}' failed, retrying in {backoff}s")
            else:
                task.status = TaskStatus.FAILED.value
                task.completed_at = time.time()
                print(f"[TASK_SCHEDULER] Task '{task.title}' failed permanently: {e}")

            self._save_task(task)
            self._running_task = None

            return {"status": "error", "error": str(e)}

    def process_ready_tasks(self, max_tasks: int = 5) -> List[Dict[str, Any]]:
        """
        Process ready tasks.

        Args:
            max_tasks: Maximum tasks to process

        Returns:
            List of execution results
        """
        ready = self.get_ready_tasks()[:max_tasks]
        results = []

        for task in ready:
            result = self.execute_task(task.task_id)
            results.append({
                "task_id": task.task_id,
                "title": task.title,
                **result,
            })

        return results

    def check_and_process(self) -> List[Dict[str, Any]]:
        """
        Check for ready tasks and process them.

        This is the main entry point for periodic task processing.
        """
        now = time.time()
        if now - self._last_check < self._check_interval_seconds:
            return []

        self._last_check = now
        return self.process_ready_tasks()

    # =========================================================================
    # Recurrence
    # =========================================================================

    def _calculate_next_occurrence(self, pattern: str, from_time: Optional[float] = None) -> float:
        """Calculate next occurrence based on recurrence pattern."""
        base_time = from_time or time.time()

        patterns = {
            "minutely": 60,
            "hourly": 3600,
            "daily": 86400,
            "weekly": 604800,
            "monthly": 2592000,  # ~30 days
        }

        interval = patterns.get(pattern.lower(), 86400)  # Default: daily
        return base_time + interval

    def _schedule_next_occurrence(self, task: ScheduledTask) -> None:
        """Schedule the next occurrence of a recurring task."""
        if not task.recurring or not task.recurrence_pattern:
            return

        # Create a new task for the next occurrence
        next_time = self._calculate_next_occurrence(
            task.recurrence_pattern,
            task.completed_at or time.time()
        )

        self.schedule(
            title=task.title,
            description=task.description,
            handler=task.handler,
            params=task.params,
            scheduled_at=next_time,
            priority=TaskPriority(task.priority),
            tags=task.tags,
            max_retries=task.max_retries,
            recurring=True,
            recurrence_pattern=task.recurrence_pattern,
            metadata={"parent_task": task.task_id, **task.metadata},
        )

    # =========================================================================
    # Stats and Cleanup
    # =========================================================================

    def get_stats(self) -> Dict[str, Any]:
        """Get scheduler statistics."""
        status_counts: Dict[str, int] = {}
        for task in self._tasks.values():
            status_counts[task.status] = status_counts.get(task.status, 0) + 1

        return {
            "total_tasks": len(self._tasks),
            "by_status": status_counts,
            "pending_count": len(self.get_pending_tasks()),
            "ready_count": len(self.get_ready_tasks()),
            "running_task": self._running_task,
        }

    def cleanup_completed(self, max_age_days: int = 7) -> int:
        """Remove old completed/cancelled/failed tasks."""
        cutoff = time.time() - (max_age_days * 86400)
        terminal_statuses = {
            TaskStatus.COMPLETED.value,
            TaskStatus.CANCELLED.value,
            TaskStatus.FAILED.value,
        }

        to_remove = []
        for task_id, task in self._tasks.items():
            if task.status in terminal_statuses:
                completed_at = task.completed_at or task.created_at
                if completed_at < cutoff:
                    to_remove.append(task_id)

        for task_id in to_remove:
            del self._tasks[task_id]

        if to_remove:
            self._save_tasks()
            print(f"[TASK_SCHEDULER] Cleaned up {len(to_remove)} old tasks")

        return len(to_remove)

    def get_session_summary(self) -> Dict[str, Any]:
        """
        Get a summary suitable for session start.

        This should be called at session start to inform the user
        of pending tasks.
        """
        pending = self.get_pending_tasks()
        ready = self.get_ready_tasks()

        summary = {
            "pending_count": len(pending),
            "ready_count": len(ready),
            "has_pending": len(pending) > 0,
            "pending_titles": [t.title for t in pending[:5]],
            "ready_titles": [t.title for t in ready[:5]],
        }

        if ready:
            summary["next_task"] = {
                "task_id": ready[0].task_id,
                "title": ready[0].title,
                "priority": ready[0].priority,
            }

        return summary


# Module-level singleton
_scheduler: Optional[TaskScheduler] = None


def get_scheduler() -> TaskScheduler:
    """Get the singleton scheduler instance."""
    global _scheduler
    if _scheduler is None:
        _scheduler = TaskScheduler()
    return _scheduler


def schedule_task(
    title: str,
    handler: str = "",
    params: Optional[Dict[str, Any]] = None,
    delay_seconds: Optional[float] = None,
    **kwargs
) -> ScheduledTask:
    """Convenience function to schedule a task."""
    scheduler = get_scheduler()
    if delay_seconds:
        return scheduler.schedule_in(title, delay_seconds, handler=handler, params=params, **kwargs)
    return scheduler.schedule(title, handler=handler, params=params, **kwargs)


def get_pending_tasks() -> List[ScheduledTask]:
    """Convenience function to get pending tasks."""
    return get_scheduler().get_pending_tasks()


def get_session_tasks_summary() -> Dict[str, Any]:
    """Get task summary for session start."""
    return get_scheduler().get_session_summary()


def process_background_tasks(max_tasks: int = 5) -> List[Dict[str, Any]]:
    """Process background tasks."""
    return get_scheduler().process_ready_tasks(max_tasks)


__all__ = [
    "TaskScheduler",
    "ScheduledTask",
    "TaskStatus",
    "TaskPriority",
    "get_scheduler",
    "schedule_task",
    "get_pending_tasks",
    "get_session_tasks_summary",
    "process_background_tasks",
]
