"""
Autonomous Loop Watchdog
========================

This module provides safety bounds and monitoring for autonomous execution loops.
It prevents infinite loops, detects cycles, enforces timeouts, and integrates
with self_dmn for feedback-based loop termination.

Key Features:
1. Loop Iteration Bounds: Configurable max iterations per loop
2. Timeout Detection: Wall-clock timeout for long-running operations
3. Cycle Detection: Detect circular dependencies in goals/tasks
4. Self-DMN Integration: Use reflection feedback to decide loop continuation
5. Resource Monitoring: Track and limit resource consumption

Usage:
    from brains.agent.autonomous.watchdog import (
        LoopWatchdog,
        create_watchdog,
        check_loop_safety,
    )

    watchdog = create_watchdog(max_iterations=100, timeout_seconds=300)

    for i in range(1000):
        if not watchdog.check_iteration():
            print(f"Watchdog stopped loop: {watchdog.stop_reason}")
            break
        # ... do work ...

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import time
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from brains.memory.brain_memory import BrainMemory


class StopReason(str, Enum):
    """Reasons for watchdog stopping a loop."""
    NONE = "none"
    MAX_ITERATIONS = "max_iterations"
    TIMEOUT = "timeout"
    CYCLE_DETECTED = "cycle_detected"
    RESOURCE_LIMIT = "resource_limit"
    DMN_FEEDBACK = "dmn_feedback"
    USER_CANCEL = "user_cancel"
    ERROR_THRESHOLD = "error_threshold"
    NO_PROGRESS = "no_progress"


@dataclass
class WatchdogConfig:
    """Configuration for the loop watchdog."""
    max_iterations: int = 100
    timeout_seconds: float = 300.0  # 5 minutes default
    max_consecutive_errors: int = 5
    max_no_progress_iterations: int = 10
    check_dmn_interval: int = 10  # Check DMN every N iterations
    min_progress_delta: float = 0.01  # Minimum progress per iteration
    enable_cycle_detection: bool = True
    enable_resource_monitoring: bool = True
    resource_check_interval: int = 5


@dataclass
class LoopState:
    """State tracking for a loop execution."""
    iteration: int = 0
    start_time: float = field(default_factory=time.time)
    last_progress: float = 0.0
    consecutive_errors: int = 0
    no_progress_count: int = 0
    visited_states: Set[str] = field(default_factory=set)
    error_history: List[str] = field(default_factory=list)
    progress_history: List[Tuple[int, float]] = field(default_factory=list)


class LoopWatchdog:
    """
    Monitors and controls autonomous execution loops.

    Provides safety bounds, timeout detection, cycle detection,
    and integration with self_dmn for intelligent loop termination.
    """

    def __init__(self, config: Optional[WatchdogConfig] = None):
        """
        Initialize the watchdog.

        Args:
            config: Watchdog configuration (uses defaults if not provided)
        """
        self.config = config or WatchdogConfig()
        self.state = LoopState()
        self._stop_requested = False
        self._stop_reason = StopReason.NONE
        self._memory = BrainMemory("watchdog")
        self._lock = threading.Lock()
        self._dmn_handler: Optional[Callable] = None

        # Try to load DMN handler for feedback
        self._load_dmn_handler()

    def _load_dmn_handler(self) -> None:
        """Load the self_dmn brain handler for feedback."""
        try:
            from brains.cognitive.self_dmn.service.self_dmn_brain import handle
            self._dmn_handler = handle
        except ImportError:
            self._dmn_handler = None

    @property
    def stop_reason(self) -> StopReason:
        """Get the reason the watchdog stopped the loop."""
        return self._stop_reason

    @property
    def is_stopped(self) -> bool:
        """Check if the watchdog has stopped the loop."""
        return self._stop_requested

    @property
    def elapsed_time(self) -> float:
        """Get elapsed time since loop start."""
        return time.time() - self.state.start_time

    @property
    def iterations(self) -> int:
        """Get current iteration count."""
        return self.state.iteration

    def reset(self) -> None:
        """Reset the watchdog for a new loop."""
        with self._lock:
            self.state = LoopState()
            self._stop_requested = False
            self._stop_reason = StopReason.NONE

    def request_stop(self, reason: StopReason = StopReason.USER_CANCEL) -> None:
        """Request the watchdog to stop the loop."""
        with self._lock:
            self._stop_requested = True
            self._stop_reason = reason

    def check_iteration(self, progress: float = 0.0, state_key: str = "") -> bool:
        """
        Check if the loop should continue.

        This should be called at the start of each iteration.

        Args:
            progress: Current progress (0.0 to 1.0)
            state_key: Optional unique key for cycle detection

        Returns:
            True if loop should continue, False if it should stop
        """
        with self._lock:
            self.state.iteration += 1

            # Check if stop was requested
            if self._stop_requested:
                return False

            # Check max iterations
            if self.state.iteration >= self.config.max_iterations:
                self._stop_requested = True
                self._stop_reason = StopReason.MAX_ITERATIONS
                self._log_stop("Max iterations reached", self.state.iteration)
                return False

            # Check timeout
            elapsed = time.time() - self.state.start_time
            if elapsed >= self.config.timeout_seconds:
                self._stop_requested = True
                self._stop_reason = StopReason.TIMEOUT
                self._log_stop("Timeout reached", elapsed)
                return False

            # Check progress
            if progress > 0:
                progress_delta = progress - self.state.last_progress
                self.state.progress_history.append((self.state.iteration, progress))

                if progress_delta < self.config.min_progress_delta:
                    self.state.no_progress_count += 1
                else:
                    self.state.no_progress_count = 0

                self.state.last_progress = progress

                if self.state.no_progress_count >= self.config.max_no_progress_iterations:
                    self._stop_requested = True
                    self._stop_reason = StopReason.NO_PROGRESS
                    self._log_stop("No progress detected", self.state.no_progress_count)
                    return False

            # Cycle detection
            if self.config.enable_cycle_detection and state_key:
                if state_key in self.state.visited_states:
                    self._stop_requested = True
                    self._stop_reason = StopReason.CYCLE_DETECTED
                    self._log_stop("Cycle detected", state_key)
                    return False
                self.state.visited_states.add(state_key)

            # DMN feedback check (every N iterations)
            if (self._dmn_handler and
                self.state.iteration % self.config.check_dmn_interval == 0):
                if not self._check_dmn_feedback():
                    self._stop_requested = True
                    self._stop_reason = StopReason.DMN_FEEDBACK
                    self._log_stop("DMN recommended stopping", self.state.iteration)
                    return False

            return True

    def report_error(self, error: str) -> bool:
        """
        Report an error during loop execution.

        Args:
            error: Error message

        Returns:
            True if loop should continue, False if error threshold exceeded
        """
        with self._lock:
            self.state.consecutive_errors += 1
            self.state.error_history.append(error)

            if self.state.consecutive_errors >= self.config.max_consecutive_errors:
                self._stop_requested = True
                self._stop_reason = StopReason.ERROR_THRESHOLD
                self._log_stop("Error threshold exceeded", self.state.consecutive_errors)
                return False

            return True

    def report_success(self) -> None:
        """Report a successful operation (resets error count)."""
        with self._lock:
            self.state.consecutive_errors = 0

    def _check_dmn_feedback(self) -> bool:
        """
        Check with self_dmn if loop should continue.

        Returns:
            True if should continue, False if DMN recommends stopping
        """
        if not self._dmn_handler:
            return True

        try:
            result = self._dmn_handler({
                "op": "EVALUATE_CONTINUATION",
                "payload": {
                    "loop_type": "autonomous",
                    "iteration": self.state.iteration,
                    "elapsed_seconds": time.time() - self.state.start_time,
                    "progress": self.state.last_progress,
                    "consecutive_errors": self.state.consecutive_errors,
                }
            })

            if result.get("ok"):
                payload = result.get("payload", {})
                should_continue = payload.get("should_continue", True)
                if not should_continue:
                    reason = payload.get("reason", "DMN recommended stopping")
                    print(f"[WATCHDOG] DMN feedback: {reason}")
                return should_continue

            return True  # Continue if DMN call fails

        except Exception as e:
            print(f"[WATCHDOG] DMN check failed: {e}")
            return True  # Continue if DMN unavailable

    def _log_stop(self, message: str, value: Any) -> None:
        """Log a stop event."""
        print(f"[WATCHDOG] Loop stopped: {message} (value={value})")

        # Store in memory for learning
        try:
            self._memory.store(
                content={
                    "stop_reason": self._stop_reason.value,
                    "message": message,
                    "value": str(value),
                    "iteration": self.state.iteration,
                    "elapsed_seconds": time.time() - self.state.start_time,
                    "progress": self.state.last_progress,
                },
                metadata={
                    "kind": "watchdog_stop",
                    "reason": self._stop_reason.value,
                    "confidence": 0.9,
                }
            )
        except Exception:
            pass

    def get_stats(self) -> Dict[str, Any]:
        """Get statistics about the current loop execution."""
        with self._lock:
            return {
                "iteration": self.state.iteration,
                "elapsed_seconds": time.time() - self.state.start_time,
                "progress": self.state.last_progress,
                "consecutive_errors": self.state.consecutive_errors,
                "no_progress_count": self.state.no_progress_count,
                "visited_states_count": len(self.state.visited_states),
                "error_count": len(self.state.error_history),
                "is_stopped": self._stop_requested,
                "stop_reason": self._stop_reason.value,
            }


class CycleDetector:
    """
    Detects cycles in goal/task dependencies.

    Uses depth-first search to detect circular dependencies that would
    cause infinite loops.
    """

    def __init__(self):
        """Initialize the cycle detector."""
        self._graph: Dict[str, Set[str]] = {}

    def add_dependency(self, node: str, depends_on: str) -> None:
        """Add a dependency edge."""
        if node not in self._graph:
            self._graph[node] = set()
        self._graph[node].add(depends_on)

    def build_from_goals(self, goals: List[Dict[str, Any]]) -> None:
        """Build dependency graph from goal list."""
        self._graph.clear()

        for goal in goals:
            goal_id = goal.get("goal_id", "")
            depends_on = goal.get("depends_on", [])

            if goal_id:
                if goal_id not in self._graph:
                    self._graph[goal_id] = set()

                for dep in depends_on:
                    self._graph[goal_id].add(dep)

    def detect_cycles(self) -> List[List[str]]:
        """
        Detect all cycles in the dependency graph.

        Returns:
            List of cycles (each cycle is a list of node IDs)
        """
        cycles = []
        visited = set()
        rec_stack = set()
        path = []

        def dfs(node: str) -> bool:
            visited.add(node)
            rec_stack.add(node)
            path.append(node)

            for neighbor in self._graph.get(node, set()):
                if neighbor not in visited:
                    if dfs(neighbor):
                        return True
                elif neighbor in rec_stack:
                    # Found a cycle
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:] + [neighbor])

            path.pop()
            rec_stack.remove(node)
            return False

        for node in self._graph:
            if node not in visited:
                dfs(node)

        return cycles

    def has_cycle(self) -> bool:
        """Check if there are any cycles."""
        return len(self.detect_cycles()) > 0

    def get_safe_execution_order(self) -> Tuple[List[str], List[str]]:
        """
        Get a safe execution order (topological sort).

        Returns:
            Tuple of (ordered_nodes, nodes_in_cycles)
        """
        cycles = self.detect_cycles()
        nodes_in_cycles = set()
        for cycle in cycles:
            nodes_in_cycles.update(cycle)

        # Filter out nodes in cycles
        safe_graph = {
            node: deps - nodes_in_cycles
            for node, deps in self._graph.items()
            if node not in nodes_in_cycles
        }

        # Topological sort
        ordered = []
        visited = set()

        def visit(node: str) -> None:
            if node in visited or node in nodes_in_cycles:
                return
            visited.add(node)
            for dep in safe_graph.get(node, set()):
                visit(dep)
            ordered.append(node)

        for node in safe_graph:
            visit(node)

        ordered.reverse()
        return ordered, list(nodes_in_cycles)


def create_watchdog(
    max_iterations: int = 100,
    timeout_seconds: float = 300.0,
    max_errors: int = 5,
) -> LoopWatchdog:
    """
    Create a watchdog with common settings.

    Args:
        max_iterations: Maximum loop iterations
        timeout_seconds: Maximum wall-clock time
        max_errors: Maximum consecutive errors

    Returns:
        Configured LoopWatchdog
    """
    config = WatchdogConfig(
        max_iterations=max_iterations,
        timeout_seconds=timeout_seconds,
        max_consecutive_errors=max_errors,
    )
    return LoopWatchdog(config)


def check_loop_safety(
    goals: List[Dict[str, Any]],
) -> Tuple[bool, List[List[str]]]:
    """
    Check if a set of goals can be safely executed (no cycles).

    Args:
        goals: List of goal dictionaries with "goal_id" and "depends_on"

    Returns:
        Tuple of (is_safe, list_of_cycles)
    """
    detector = CycleDetector()
    detector.build_from_goals(goals)
    cycles = detector.detect_cycles()
    return len(cycles) == 0, cycles


def get_safe_goal_order(
    goals: List[Dict[str, Any]],
) -> Tuple[List[str], List[str]]:
    """
    Get safe execution order for goals.

    Args:
        goals: List of goal dictionaries

    Returns:
        Tuple of (ordered_goal_ids, goal_ids_in_cycles)
    """
    detector = CycleDetector()
    detector.build_from_goals(goals)
    return detector.get_safe_execution_order()


# Singleton watchdog for global access
_global_watchdog: Optional[LoopWatchdog] = None


def get_global_watchdog() -> LoopWatchdog:
    """Get or create the global watchdog."""
    global _global_watchdog
    if _global_watchdog is None:
        _global_watchdog = create_watchdog()
    return _global_watchdog


def reset_global_watchdog() -> None:
    """Reset the global watchdog."""
    global _global_watchdog
    if _global_watchdog:
        _global_watchdog.reset()


__all__ = [
    "LoopWatchdog",
    "WatchdogConfig",
    "LoopState",
    "StopReason",
    "CycleDetector",
    "create_watchdog",
    "check_loop_safety",
    "get_safe_goal_order",
    "get_global_watchdog",
    "reset_global_watchdog",
]
