"""
Semantic Tool Matching
======================

Embedding-based task-to-tool capability matching for AGI-level adaptive tool use.

This module enables Maven to understand natural language task descriptions and
semantically match them to available tools, supporting:

1. Natural language task understanding ("I need to search the web for...")
2. Semantic similarity matching (not just keyword matching)
3. Multi-tool ranking and selection
4. Capability-aware action selection
5. Hybrid matching (keyword + semantic for robustness)

This is a critical AGI competency for adaptive tool use - the ability to
dynamically select appropriate tools based on task semantics rather than
rigid keyword rules.

Usage:
    from brains.agent.semantic_tool_matcher import (
        match_task_to_tools,
        get_best_tool_for_task,
        index_tool_capabilities,
        ToolMatch,
    )

    # Index available tools (done automatically on first use)
    index_tool_capabilities()

    # Match a natural language task to tools
    matches = match_task_to_tools("I need to look something up online")
    # Returns: [ToolMatch(tool_id="web_search", score=0.87, ...), ...]

    # Get the best tool for a task
    best = get_best_tool_for_task("execute some Python code")
    # Returns: ToolMatch(tool_id="python", ...)

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import json
import math
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from brains.maven_paths import get_reports_path


# Index persistence path
TOOL_INDEX_PATH = get_reports_path("semantic_tool_index.json")


@dataclass
class ToolMatch:
    """Result of matching a task to a tool."""
    tool_id: str
    tool_name: str
    score: float  # 0.0 to 1.0, semantic similarity score
    keyword_score: float = 0.0  # Keyword-based match score
    combined_score: float = 0.0  # Weighted combination of both
    matched_capabilities: List[str] = field(default_factory=list)
    confidence: str = "low"  # low, medium, high
    explanation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_id": self.tool_id,
            "tool_name": self.tool_name,
            "score": self.score,
            "keyword_score": self.keyword_score,
            "combined_score": self.combined_score,
            "matched_capabilities": self.matched_capabilities,
            "confidence": self.confidence,
            "explanation": self.explanation,
        }


@dataclass
class ToolCapabilityEntry:
    """A tool capability entry in the semantic index."""
    tool_id: str
    tool_name: str
    capability_name: str
    description: str
    keywords: List[str] = field(default_factory=list)
    embedding: List[float] = field(default_factory=list)
    risk_level: str = "low"


class SemanticToolMatcher:
    """
    Semantic matcher for task-to-tool capability matching.

    Uses embeddings to semantically match natural language task descriptions
    to available tool capabilities, enabling AGI-level adaptive tool selection.
    """

    # Semantic expansion patterns - map task intents to capability keywords
    SEMANTIC_EXPANSIONS: Dict[str, List[str]] = {
        # Web/Internet related
        "search": ["search_web", "web_search", "fetch_url", "lookup", "find"],
        "browse": ["browse_page", "web_search", "fetch_url", "internet"],
        "lookup": ["search_web", "fetch_url", "find", "query"],
        "find online": ["search_web", "fetch_url", "browse"],
        "google": ["search_web", "web_search"],

        # File system
        "read": ["read_file", "get_file", "open_file"],
        "write": ["write_file", "save_file", "create_file"],
        "save": ["write_file", "save_file"],
        "open": ["read_file", "open_file"],
        "list files": ["list_directory", "read_file"],
        "create file": ["write_file", "create_file"],

        # Execution
        "run": ["execute_command", "execute_python", "run_script"],
        "execute": ["execute_command", "execute_python"],
        "code": ["execute_python", "execute_command"],
        "python": ["execute_python"],
        "script": ["execute_python", "execute_command"],
        "shell": ["execute_command"],
        "command": ["execute_command"],
        "terminal": ["execute_command"],

        # Git
        "commit": ["git_commit", "git_status"],
        "push": ["git_push", "git_commit"],
        "pull": ["git_status", "git_push"],
        "version control": ["git_status", "git_commit", "git_push"],
        "git": ["git_status", "git_commit", "git_push"],

        # Math/Calculation
        "calculate": ["evaluate_expression", "solve_equation"],
        "compute": ["evaluate_expression", "solve_equation"],
        "math": ["evaluate_expression", "solve_equation"],
        "solve": ["solve_equation", "evaluate_expression"],
        "equation": ["solve_equation"],

        # Time
        "time": ["get_current_time", "get_timezone"],
        "date": ["get_current_time"],
        "now": ["get_current_time"],
        "clock": ["get_current_time"],

        # Browser automation
        "click": ["click_element", "browse_page"],
        "screenshot": ["screenshot", "browse_page"],
        "automate": ["browse_page", "click_element"],
        "scrape": ["browse_page", "fetch_url"],

        # Memory/Search
        "remember": ["semantic_search", "index_content"],
        "recall": ["semantic_search"],
        "semantic": ["semantic_search"],
        "similar": ["semantic_search"],

        # Task scheduling
        "schedule": ["schedule_task", "list_tasks"],
        "later": ["schedule_task"],
        "remind": ["schedule_task"],
        "task": ["schedule_task", "list_tasks"],
    }

    # Capability to tool mapping for quick lookup
    CAPABILITY_TO_TOOL: Dict[str, str] = {}

    def __init__(self, auto_index: bool = True):
        """Initialize the semantic tool matcher."""
        self._entries: List[ToolCapabilityEntry] = []
        self._embeddings_ready = False
        self._last_index_time: float = 0
        self._dimension = 384

        if auto_index:
            self._load_index()
            if not self._entries:
                self.index_tools()

    def _load_index(self) -> None:
        """Load the semantic index from disk."""
        try:
            if TOOL_INDEX_PATH.exists():
                data = json.loads(TOOL_INDEX_PATH.read_text())
                self._entries = []
                for entry_data in data.get("entries", []):
                    self._entries.append(ToolCapabilityEntry(
                        tool_id=entry_data["tool_id"],
                        tool_name=entry_data["tool_name"],
                        capability_name=entry_data["capability_name"],
                        description=entry_data["description"],
                        keywords=entry_data.get("keywords", []),
                        embedding=entry_data.get("embedding", []),
                        risk_level=entry_data.get("risk_level", "low"),
                    ))
                self._embeddings_ready = any(e.embedding for e in self._entries)
                self._last_index_time = data.get("indexed_at", 0)
                print(f"[SEMANTIC_TOOL_MATCHER] Loaded {len(self._entries)} capability entries")
        except Exception as e:
            print(f"[SEMANTIC_TOOL_MATCHER] Failed to load index: {e}")

    def _save_index(self) -> None:
        """Save the semantic index to disk."""
        try:
            TOOL_INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "indexed_at": time.time(),
                "entries": [
                    {
                        "tool_id": e.tool_id,
                        "tool_name": e.tool_name,
                        "capability_name": e.capability_name,
                        "description": e.description,
                        "keywords": e.keywords,
                        "embedding": e.embedding,
                        "risk_level": e.risk_level,
                    }
                    for e in self._entries
                ]
            }
            TOOL_INDEX_PATH.write_text(json.dumps(data, indent=2))
        except Exception as e:
            print(f"[SEMANTIC_TOOL_MATCHER] Failed to save index: {e}")

    def _tokenize(self, text: str) -> List[str]:
        """Tokenize text into words."""
        text = text.lower()
        tokens = re.findall(r'\w+', text)
        return [t for t in tokens if len(t) > 2]

    def _hash_token(self, token: str, dimension: int) -> int:
        """Hash a token to a dimension index."""
        import hashlib
        h = hashlib.md5(token.encode()).hexdigest()
        return int(h, 16) % dimension

    def _embed_text(self, text: str) -> List[float]:
        """Create a simple embedding for text using TF-IDF-like hashing."""
        vector = [0.0] * self._dimension
        tokens = self._tokenize(text)

        if not tokens:
            return vector

        # Count token frequencies
        freq: Dict[str, int] = {}
        for token in tokens:
            freq[token] = freq.get(token, 0) + 1

        # Create embedding with TF weighting
        for token, count in freq.items():
            idx = self._hash_token(token, self._dimension)
            tf = math.log(1 + count)
            vector[idx] += tf

        # Normalize
        norm = math.sqrt(sum(v * v for v in vector))
        if norm > 0:
            vector = [v / norm for v in vector]

        return vector

    def _cosine_similarity(self, v1: List[float], v2: List[float]) -> float:
        """Compute cosine similarity between two vectors."""
        if len(v1) != len(v2) or not v1:
            return 0.0

        dot = sum(a * b for a, b in zip(v1, v2))
        norm1 = math.sqrt(sum(a * a for a in v1))
        norm2 = math.sqrt(sum(b * b for b in v2))

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return dot / (norm1 * norm2)

    def index_tools(self, force: bool = False) -> int:
        """
        Index all available tool capabilities for semantic matching.

        Args:
            force: Force reindexing even if recently done

        Returns:
            Number of capabilities indexed
        """
        # Check if recently indexed
        if not force and self._entries and (time.time() - self._last_index_time) < 300:
            return len(self._entries)

        self._entries = []

        try:
            # Get tools from discovery
            from brains.agent.tool_discovery import discover_tools
            tools = discover_tools()

            for tool_id, tool in tools.items():
                if not tool.available:
                    continue

                for capability in tool.capabilities:
                    # Build description text for embedding
                    description = f"{tool.name} {capability.name} {capability.description}"

                    # Extract keywords from capability name
                    keywords = [capability.name]
                    keywords.extend(self._tokenize(capability.name))
                    keywords.extend(self._tokenize(capability.description))

                    # Create embedding
                    embedding = self._embed_text(description)

                    entry = ToolCapabilityEntry(
                        tool_id=tool_id,
                        tool_name=tool.name,
                        capability_name=capability.name,
                        description=description,
                        keywords=list(set(keywords)),
                        embedding=embedding,
                        risk_level=capability.risk_level,
                    )
                    self._entries.append(entry)

                    # Update capability-to-tool mapping
                    SemanticToolMatcher.CAPABILITY_TO_TOOL[capability.name] = tool_id

            self._embeddings_ready = True
            self._last_index_time = time.time()
            self._save_index()

            print(f"[SEMANTIC_TOOL_MATCHER] Indexed {len(self._entries)} capabilities from {len(tools)} tools")
            return len(self._entries)

        except ImportError:
            # Fall back to static capability definitions
            return self._index_static_capabilities()

    def _index_static_capabilities(self) -> int:
        """Index static capability definitions when tool discovery is unavailable."""
        static_caps = [
            ("llm", "LLM", "generate_text", "Generate text using language model"),
            ("filesystem", "File System", "read_file", "Read file contents from disk"),
            ("filesystem", "File System", "write_file", "Write content to a file"),
            ("filesystem", "File System", "list_directory", "List files in a directory"),
            ("shell", "Shell", "execute_command", "Execute shell commands"),
            ("python", "Python", "execute_python", "Execute Python code"),
            ("web_search", "Web Search", "search_web", "Search the web for information"),
            ("web_search", "Web Search", "fetch_url", "Fetch content from a URL"),
            ("git", "Git", "git_status", "Check git repository status"),
            ("git", "Git", "git_commit", "Commit changes to git"),
            ("git", "Git", "git_push", "Push commits to remote"),
            ("math", "Math", "evaluate_expression", "Evaluate mathematical expressions"),
            ("math", "Math", "solve_equation", "Solve mathematical equations"),
            ("time", "Time", "get_current_time", "Get the current time"),
            ("browser", "Browser", "browse_page", "Browse and interact with web pages"),
            ("browser", "Browser", "screenshot", "Take screenshots of pages"),
            ("vector_index", "Vector Index", "semantic_search", "Search by semantic similarity"),
            ("task_scheduler", "Task Scheduler", "schedule_task", "Schedule tasks for later"),
        ]

        for tool_id, tool_name, cap_name, description in static_caps:
            entry = ToolCapabilityEntry(
                tool_id=tool_id,
                tool_name=tool_name,
                capability_name=cap_name,
                description=f"{tool_name} {cap_name} {description}",
                keywords=[cap_name] + self._tokenize(description),
                embedding=self._embed_text(f"{tool_name} {cap_name} {description}"),
            )
            self._entries.append(entry)
            SemanticToolMatcher.CAPABILITY_TO_TOOL[cap_name] = tool_id

        self._embeddings_ready = True
        self._last_index_time = time.time()
        self._save_index()

        print(f"[SEMANTIC_TOOL_MATCHER] Indexed {len(self._entries)} static capabilities")
        return len(self._entries)

    def _expand_query(self, query: str) -> List[str]:
        """Expand query with semantic synonyms and related terms."""
        expanded = [query]
        query_lower = query.lower()

        for pattern, expansions in self.SEMANTIC_EXPANSIONS.items():
            if pattern in query_lower:
                expanded.extend(expansions)

        return list(set(expanded))

    def _keyword_score(self, query: str, entry: ToolCapabilityEntry) -> float:
        """Calculate keyword-based match score."""
        query_tokens = set(self._tokenize(query.lower()))
        expanded_tokens = set()

        # Add expanded terms
        for token in query_tokens:
            if token in self.SEMANTIC_EXPANSIONS:
                expanded_tokens.update(self.SEMANTIC_EXPANSIONS[token])

        query_tokens.update(expanded_tokens)

        if not query_tokens:
            return 0.0

        # Check for matches in capability keywords
        cap_keywords = set(kw.lower() for kw in entry.keywords)
        cap_keywords.add(entry.capability_name.lower())
        cap_keywords.update(self._tokenize(entry.description.lower()))

        # Calculate overlap
        matches = query_tokens & cap_keywords
        if not matches:
            return 0.0

        # Score based on match quality
        score = len(matches) / max(len(query_tokens), 1)

        # Boost for direct capability name match
        if entry.capability_name.lower() in query_tokens:
            score = min(1.0, score + 0.3)

        return min(1.0, score)

    def match_task(
        self,
        task_description: str,
        top_k: int = 5,
        min_score: float = 0.1,
        keyword_weight: float = 0.4,
    ) -> List[ToolMatch]:
        """
        Match a natural language task description to available tools.

        Args:
            task_description: Natural language description of what needs to be done
            top_k: Maximum number of matches to return
            min_score: Minimum combined score threshold
            keyword_weight: Weight for keyword matching (0-1), rest goes to semantic

        Returns:
            List of ToolMatch objects sorted by combined score
        """
        if not self._entries:
            self.index_tools()

        if not self._entries:
            return []

        # Create query embedding
        query_embedding = self._embed_text(task_description)

        # Score each capability
        scored: Dict[str, Tuple[float, float, List[str]]] = {}  # tool_id -> (semantic, keyword, caps)

        for entry in self._entries:
            # Semantic score
            semantic_score = 0.0
            if entry.embedding and query_embedding:
                semantic_score = self._cosine_similarity(query_embedding, entry.embedding)

            # Keyword score
            kw_score = self._keyword_score(task_description, entry)

            # Combine scores
            combined = (1 - keyword_weight) * semantic_score + keyword_weight * kw_score

            if combined >= min_score:
                if entry.tool_id not in scored:
                    scored[entry.tool_id] = (0.0, 0.0, [])

                old_semantic, old_kw, caps = scored[entry.tool_id]
                # Take max scores across capabilities
                scored[entry.tool_id] = (
                    max(old_semantic, semantic_score),
                    max(old_kw, kw_score),
                    caps + [entry.capability_name],
                )

        # Build results
        matches: List[ToolMatch] = []
        for tool_id, (semantic_score, kw_score, caps) in scored.items():
            combined = (1 - keyword_weight) * semantic_score + keyword_weight * kw_score

            # Determine confidence
            if combined >= 0.7:
                confidence = "high"
            elif combined >= 0.4:
                confidence = "medium"
            else:
                confidence = "low"

            # Get tool name
            tool_name = tool_id.replace("_", " ").title()
            for entry in self._entries:
                if entry.tool_id == tool_id:
                    tool_name = entry.tool_name
                    break

            match = ToolMatch(
                tool_id=tool_id,
                tool_name=tool_name,
                score=semantic_score,
                keyword_score=kw_score,
                combined_score=combined,
                matched_capabilities=list(set(caps)),
                confidence=confidence,
                explanation=self._build_explanation(task_description, tool_id, caps),
            )
            matches.append(match)

        # Sort by combined score
        matches.sort(key=lambda m: m.combined_score, reverse=True)

        return matches[:top_k]

    def _build_explanation(
        self,
        task: str,
        tool_id: str,
        capabilities: List[str],
    ) -> str:
        """Build a human-readable explanation for the match."""
        cap_str = ", ".join(capabilities[:3])
        return f"Tool '{tool_id}' can handle this task using: {cap_str}"

    def get_best_match(
        self,
        task_description: str,
        min_confidence: str = "low",
    ) -> Optional[ToolMatch]:
        """
        Get the single best tool match for a task.

        Args:
            task_description: Natural language task description
            min_confidence: Minimum confidence level ("low", "medium", "high")

        Returns:
            Best matching tool or None if no good match
        """
        matches = self.match_task(task_description, top_k=1)
        if not matches:
            return None

        best = matches[0]

        # Check confidence threshold
        confidence_order = ["low", "medium", "high"]
        min_idx = confidence_order.index(min_confidence)
        best_idx = confidence_order.index(best.confidence)

        if best_idx >= min_idx:
            return best

        return None

    def suggest_tools_for_intent(
        self,
        intent: str,
        entities: Optional[Dict[str, Any]] = None,
    ) -> List[ToolMatch]:
        """
        Suggest tools based on a parsed intent and entities.

        This is useful when integrating with the NLU pipeline that has
        already extracted intents and entities.

        Args:
            intent: Detected intent (e.g., "search", "execute", "save")
            entities: Extracted entities (e.g., {"query": "python tutorial"})

        Returns:
            List of suggested tools
        """
        # Build task description from intent and entities
        task_parts = [intent]

        if entities:
            for key, value in entities.items():
                if isinstance(value, str):
                    task_parts.append(value)
                elif isinstance(value, list):
                    task_parts.extend(str(v) for v in value)

        task_description = " ".join(task_parts)
        return self.match_task(task_description)

    def can_handle(self, task_description: str, confidence_threshold: str = "medium") -> bool:
        """
        Check if any available tool can handle the given task.

        Args:
            task_description: Natural language task description
            confidence_threshold: Minimum confidence level

        Returns:
            True if a tool is available with sufficient confidence
        """
        best = self.get_best_match(task_description, min_confidence=confidence_threshold)
        return best is not None

    def get_stats(self) -> Dict[str, Any]:
        """Get matcher statistics."""
        tool_counts: Dict[str, int] = {}
        for entry in self._entries:
            tool_counts[entry.tool_id] = tool_counts.get(entry.tool_id, 0) + 1

        return {
            "total_capabilities": len(self._entries),
            "unique_tools": len(tool_counts),
            "tools_by_capability_count": tool_counts,
            "embeddings_ready": self._embeddings_ready,
            "last_indexed": self._last_index_time,
            "index_age_seconds": time.time() - self._last_index_time if self._last_index_time else None,
        }


# Module-level singleton
_matcher: Optional[SemanticToolMatcher] = None


def get_matcher() -> SemanticToolMatcher:
    """Get the singleton semantic tool matcher."""
    global _matcher
    if _matcher is None:
        _matcher = SemanticToolMatcher()
    return _matcher


def match_task_to_tools(
    task_description: str,
    top_k: int = 5,
    min_score: float = 0.1,
) -> List[ToolMatch]:
    """
    Convenience function to match a task to tools.

    Args:
        task_description: Natural language description of what needs to be done
        top_k: Maximum number of matches
        min_score: Minimum score threshold

    Returns:
        List of ToolMatch objects
    """
    return get_matcher().match_task(task_description, top_k=top_k, min_score=min_score)


def get_best_tool_for_task(
    task_description: str,
    min_confidence: str = "low",
) -> Optional[ToolMatch]:
    """
    Convenience function to get the best tool for a task.

    Args:
        task_description: Natural language task description
        min_confidence: Minimum confidence level

    Returns:
        Best matching tool or None
    """
    return get_matcher().get_best_match(task_description, min_confidence=min_confidence)


def index_tool_capabilities(force: bool = False) -> int:
    """
    Convenience function to index tool capabilities.

    Args:
        force: Force reindexing

    Returns:
        Number of capabilities indexed
    """
    return get_matcher().index_tools(force=force)


def can_handle_task(task_description: str, confidence: str = "medium") -> bool:
    """
    Convenience function to check if a task can be handled.

    Args:
        task_description: Natural language task description
        confidence: Minimum confidence level

    Returns:
        True if a tool is available
    """
    return get_matcher().can_handle(task_description, confidence_threshold=confidence)


def suggest_tools_for_intent(
    intent: str,
    entities: Optional[Dict[str, Any]] = None,
) -> List[ToolMatch]:
    """
    Convenience function to suggest tools for an intent.

    Args:
        intent: Detected intent
        entities: Extracted entities

    Returns:
        List of suggested tools
    """
    return get_matcher().suggest_tools_for_intent(intent, entities)


def get_matcher_stats() -> Dict[str, Any]:
    """Convenience function to get matcher statistics."""
    return get_matcher().get_stats()


# Public API
__all__ = [
    "SemanticToolMatcher",
    "ToolMatch",
    "ToolCapabilityEntry",
    "get_matcher",
    "match_task_to_tools",
    "get_best_tool_for_task",
    "index_tool_capabilities",
    "can_handle_task",
    "suggest_tools_for_intent",
    "get_matcher_stats",
]
