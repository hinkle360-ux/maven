"""
Agent Inter-Process Communication (IPC) Module

Provides file-based IPC for collaborative agent network.
Messages are JSON-based and stored in inbox/outbox directories.

FULLY IMPLEMENTED: Message sending, receiving, inbox/outbox management.
"""

from typing import Dict, List, Any, Optional
from pathlib import Path
import json
import time
import hashlib

from brains.maven_paths import get_reports_path


def _get_ipc_root() -> Path:
    """Get the root directory for IPC messages."""
    ipc_root = get_reports_path() / "agents"
    ipc_root.mkdir(parents=True, exist_ok=True)
    return ipc_root


def _get_inbox(agent_id: str) -> Path:
    """Get inbox directory for an agent."""
    inbox = _get_ipc_root() / agent_id / "inbox"
    inbox.mkdir(parents=True, exist_ok=True)
    return inbox


def _get_outbox(agent_id: str) -> Path:
    """Get outbox directory for an agent."""
    outbox = _get_ipc_root() / agent_id / "outbox"
    outbox.mkdir(parents=True, exist_ok=True)
    return outbox


def _generate_message_id() -> str:
    """Generate unique message ID."""
    timestamp = str(time.time())
    return hashlib.md5(timestamp.encode()).hexdigest()[:12]


def send_message(
    from_agent: str,
    to_agent: str,
    topic: str,
    payload: Dict[str, Any],
    priority: str = "normal"
) -> Dict[str, Any]:
    """
    Send a message to another agent.

    Args:
        from_agent: Sender agent ID
        to_agent: Recipient agent ID
        topic: Message topic/type
        payload: Message content
        priority: Message priority (low, normal, high)

    Returns:
        Dict with message_id and status
    """
    message_id = _generate_message_id()
    timestamp = time.time()

    message = {
        "id": message_id,
        "from": from_agent,
        "to": to_agent,
        "topic": topic,
        "payload": payload,
        "timestamp": timestamp,
        "priority": priority,
        "read": False,
    }

    # Write to recipient's inbox
    recipient_inbox = _get_inbox(to_agent)
    message_file = recipient_inbox / f"{message_id}.json"

    try:
        with open(message_file, 'w') as f:
            json.dump(message, f, indent=2)

        # Also store in sender's outbox for tracking
        sender_outbox = _get_outbox(from_agent)
        outbox_file = sender_outbox / f"{message_id}.json"
        with open(outbox_file, 'w') as f:
            json.dump(message, f, indent=2)

        return {
            "status": "sent",
            "message_id": message_id,
            "timestamp": timestamp,
        }

    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
        }


def receive_messages(
    agent_id: str,
    topic_filter: Optional[str] = None,
    limit: int = 10,
    mark_read: bool = True
) -> List[Dict[str, Any]]:
    """
    Receive messages from an agent's inbox.

    Args:
        agent_id: Agent ID to receive messages for
        topic_filter: Optional topic to filter by
        limit: Maximum messages to return
        mark_read: Whether to mark messages as read

    Returns:
        List of message dictionaries
    """
    inbox = _get_inbox(agent_id)
    messages = []

    try:
        # Get all message files, sorted by modification time (newest first)
        message_files = sorted(
            inbox.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True
        )

        for msg_file in message_files:
            if len(messages) >= limit:
                break

            try:
                with open(msg_file, 'r') as f:
                    message = json.load(f)

                # Apply topic filter
                if topic_filter and message.get("topic") != topic_filter:
                    continue

                # Skip already read messages if only unread wanted
                if message.get("read") and not mark_read:
                    continue

                messages.append(message)

                # Mark as read
                if mark_read and not message.get("read"):
                    message["read"] = True
                    message["read_at"] = time.time()
                    with open(msg_file, 'w') as f:
                        json.dump(message, f, indent=2)

            except Exception:
                continue

    except Exception:
        pass

    return messages


def get_unread_count(agent_id: str) -> int:
    """
    Get count of unread messages for an agent.

    Args:
        agent_id: Agent ID

    Returns:
        Number of unread messages
    """
    inbox = _get_inbox(agent_id)
    count = 0

    try:
        for msg_file in inbox.glob("*.json"):
            try:
                with open(msg_file, 'r') as f:
                    message = json.load(f)
                if not message.get("read"):
                    count += 1
            except Exception:
                continue
    except Exception:
        pass

    return count


def delete_message(agent_id: str, message_id: str) -> bool:
    """
    Delete a message from an agent's inbox.

    Args:
        agent_id: Agent ID
        message_id: Message ID to delete

    Returns:
        True if deleted, False otherwise
    """
    inbox = _get_inbox(agent_id)
    message_file = inbox / f"{message_id}.json"

    try:
        if message_file.exists():
            message_file.unlink()
            return True
    except Exception:
        pass

    return False


def cleanup_old_messages(agent_id: str, max_age_hours: int = 24) -> int:
    """
    Clean up old messages from inbox and outbox.

    Args:
        agent_id: Agent ID
        max_age_hours: Maximum age in hours

    Returns:
        Number of messages deleted
    """
    deleted = 0
    max_age_seconds = max_age_hours * 3600
    current_time = time.time()

    for directory in [_get_inbox(agent_id), _get_outbox(agent_id)]:
        try:
            for msg_file in directory.glob("*.json"):
                try:
                    with open(msg_file, 'r') as f:
                        message = json.load(f)
                    msg_time = message.get("timestamp", 0)
                    if current_time - msg_time > max_age_seconds:
                        msg_file.unlink()
                        deleted += 1
                except Exception:
                    continue
        except Exception:
            continue

    return deleted


def broadcast_message(
    from_agent: str,
    topic: str,
    payload: Dict[str, Any],
    exclude: Optional[List[str]] = None
) -> Dict[str, Any]:
    """
    Broadcast a message to all known agents.

    Args:
        from_agent: Sender agent ID
        topic: Message topic
        payload: Message content
        exclude: List of agent IDs to exclude

    Returns:
        Dict with sent count and any errors
    """
    ipc_root = _get_ipc_root()
    exclude = exclude or []
    sent_count = 0
    errors = []

    try:
        # Find all agent directories
        for agent_dir in ipc_root.iterdir():
            if agent_dir.is_dir():
                agent_id = agent_dir.name
                if agent_id != from_agent and agent_id not in exclude:
                    result = send_message(from_agent, agent_id, topic, payload)
                    if result.get("status") == "sent":
                        sent_count += 1
                    else:
                        errors.append(f"{agent_id}: {result.get('error')}")

    except Exception as e:
        errors.append(f"Broadcast error: {e}")

    return {
        "sent_count": sent_count,
        "errors": errors,
    }
