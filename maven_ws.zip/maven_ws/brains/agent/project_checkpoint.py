"""
Proactive Checkpoint/Resume System
==================================

This module provides automatic checkpointing and resumption for long-running
projects. It enables Maven to:

1. Automatically save project state at key milestones
2. Detect and offer to resume interrupted work
3. Track project progress across sessions
4. Provide context restoration for resumed work

Features:
- Automatic checkpoint creation after significant changes
- Project state serialization (files changed, goals completed, etc.)
- Session continuity tracking
- Resume prompts at session start
- Context restoration from checkpoints

Usage:
    from brains.agent.project_checkpoint import (
        create_checkpoint,
        resume_from_checkpoint,
        get_active_projects,
        ProjectCheckpoint,
    )

    # Create a checkpoint
    checkpoint = create_checkpoint(
        project_id="my-project",
        description="Implemented feature X",
        context={"files_modified": ["file1.py"], "goals": ["goal1"]}
    )

    # Resume from checkpoint
    context = resume_from_checkpoint(project_id="my-project")

    # Get active projects with pending work
    projects = get_active_projects()
"""

from __future__ import annotations

import json
import hashlib
import time
import os
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

from brains.maven_paths import get_reports_path


# Storage paths
CHECKPOINT_DIR = get_reports_path("checkpoints")
PROJECT_INDEX_PATH = get_reports_path("project_index.json")


@dataclass
class FileState:
    """State of a file at checkpoint time."""
    path: str
    exists: bool
    modified_at: Optional[float] = None
    size_bytes: Optional[int] = None
    content_hash: Optional[str] = None  # MD5 of first 10KB

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FileState":
        return cls(**data)

    @classmethod
    def from_path(cls, path: str) -> "FileState":
        """Create FileState from a file path."""
        p = Path(path)
        if not p.exists():
            return cls(path=path, exists=False)

        try:
            stat = p.stat()
            # Hash first 10KB for quick comparison
            content_hash = None
            if p.is_file():
                data = p.read_bytes()[:10240]
                content_hash = hashlib.md5(data).hexdigest()

            return cls(
                path=path,
                exists=True,
                modified_at=stat.st_mtime,
                size_bytes=stat.st_size,
                content_hash=content_hash,
            )
        except Exception:
            return cls(path=path, exists=True)


@dataclass
class GoalProgress:
    """Progress on a project goal."""
    goal_id: str
    title: str
    status: str = "pending"  # pending, in_progress, completed, blocked
    progress_pct: float = 0.0
    notes: str = ""
    subtasks_completed: int = 0
    subtasks_total: int = 0


@dataclass
class ProjectCheckpoint:
    """A checkpoint capturing project state at a point in time."""
    checkpoint_id: str
    project_id: str
    created_at: float = field(default_factory=time.time)
    description: str = ""

    # Session info
    session_id: Optional[str] = None
    user_id: Optional[str] = None

    # File state
    files_tracked: List[FileState] = field(default_factory=list)
    files_modified: List[str] = field(default_factory=list)
    files_created: List[str] = field(default_factory=list)
    files_deleted: List[str] = field(default_factory=list)

    # Goal state
    goals: List[GoalProgress] = field(default_factory=list)
    active_goal: Optional[str] = None

    # Context
    context: Dict[str, Any] = field(default_factory=dict)
    conversation_summary: str = ""
    last_user_request: str = ""
    pending_actions: List[str] = field(default_factory=list)

    # Metadata
    checkpoint_type: str = "manual"  # manual, auto, milestone
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result["files_tracked"] = [f.to_dict() if hasattr(f, "to_dict") else f for f in self.files_tracked]
        result["goals"] = [g if isinstance(g, dict) else asdict(g) for g in self.goals]
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectCheckpoint":
        files = [FileState.from_dict(f) if isinstance(f, dict) else f for f in data.pop("files_tracked", [])]
        goals = [GoalProgress(**g) if isinstance(g, dict) else g for g in data.pop("goals", [])]
        return cls(**data, files_tracked=files, goals=goals)


@dataclass
class ProjectState:
    """Overall state of a tracked project."""
    project_id: str
    name: str
    created_at: float = field(default_factory=time.time)
    updated_at: float = field(default_factory=time.time)

    # Status
    status: str = "active"  # active, paused, completed, abandoned
    progress_pct: float = 0.0

    # Paths
    root_path: Optional[str] = None
    tracked_paths: List[str] = field(default_factory=list)

    # Checkpoints
    checkpoint_count: int = 0
    latest_checkpoint_id: Optional[str] = None
    latest_checkpoint_at: Optional[float] = None

    # Resume info
    has_pending_work: bool = False
    resume_prompt: str = ""
    last_session_id: Optional[str] = None

    # Metadata
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProjectState":
        return cls(**data)


class CheckpointManager:
    """
    Manager for project checkpoints and resumption.

    Handles:
    - Creating and loading checkpoints
    - Tracking project state
    - Detecting interrupted work
    - Generating resume prompts
    """

    def __init__(self, auto_checkpoint_interval: int = 300):
        """
        Initialize the checkpoint manager.

        Args:
            auto_checkpoint_interval: Seconds between auto-checkpoints (0 = disabled)
        """
        self._projects: Dict[str, ProjectState] = {}
        self._auto_interval = auto_checkpoint_interval
        self._last_auto_checkpoint: Dict[str, float] = {}

        # Ensure storage directory exists
        CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)

        # Load project index
        self._load_project_index()

    def _load_project_index(self) -> None:
        """Load the project index from disk."""
        if not PROJECT_INDEX_PATH.exists():
            return

        try:
            data = json.loads(PROJECT_INDEX_PATH.read_text())
            for pid, pdata in data.get("projects", {}).items():
                self._projects[pid] = ProjectState.from_dict(pdata)
            print(f"[CHECKPOINT] Loaded {len(self._projects)} projects from index")
        except Exception as e:
            print(f"[CHECKPOINT] Failed to load project index: {e}")

    def _save_project_index(self) -> None:
        """Save the project index to disk."""
        try:
            PROJECT_INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
            data = {
                "updated_at": time.time(),
                "projects": {pid: p.to_dict() for pid, p in self._projects.items()}
            }
            PROJECT_INDEX_PATH.write_text(json.dumps(data, indent=2))
        except Exception as e:
            print(f"[CHECKPOINT] Failed to save project index: {e}")

    def _checkpoint_path(self, project_id: str, checkpoint_id: str) -> Path:
        """Get path for a checkpoint file."""
        return CHECKPOINT_DIR / project_id / f"{checkpoint_id}.json"

    # =========================================================================
    # Project Management
    # =========================================================================

    def create_project(
        self,
        project_id: str,
        name: str,
        root_path: Optional[str] = None,
        tracked_paths: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> ProjectState:
        """Create a new tracked project."""
        project = ProjectState(
            project_id=project_id,
            name=name,
            root_path=root_path,
            tracked_paths=tracked_paths or [],
            tags=tags or [],
        )
        self._projects[project_id] = project
        self._save_project_index()

        # Create project checkpoint directory
        (CHECKPOINT_DIR / project_id).mkdir(parents=True, exist_ok=True)

        print(f"[CHECKPOINT] Created project: {name} ({project_id})")
        return project

    def get_project(self, project_id: str) -> Optional[ProjectState]:
        """Get a project by ID."""
        return self._projects.get(project_id)

    def list_projects(self, status: Optional[str] = None) -> List[ProjectState]:
        """List all tracked projects."""
        projects = list(self._projects.values())
        if status:
            projects = [p for p in projects if p.status == status]
        return sorted(projects, key=lambda p: p.updated_at, reverse=True)

    def update_project_status(
        self,
        project_id: str,
        status: str,
        progress_pct: Optional[float] = None,
    ) -> bool:
        """Update project status."""
        project = self._projects.get(project_id)
        if not project:
            return False

        project.status = status
        project.updated_at = time.time()
        if progress_pct is not None:
            project.progress_pct = progress_pct

        self._save_project_index()
        return True

    # =========================================================================
    # Checkpoint Operations
    # =========================================================================

    def create_checkpoint(
        self,
        project_id: str,
        description: str = "",
        files_modified: Optional[List[str]] = None,
        files_created: Optional[List[str]] = None,
        goals: Optional[List[Dict[str, Any]]] = None,
        context: Optional[Dict[str, Any]] = None,
        conversation_summary: str = "",
        last_user_request: str = "",
        pending_actions: Optional[List[str]] = None,
        checkpoint_type: str = "manual",
        tags: Optional[List[str]] = None,
        session_id: Optional[str] = None,
    ) -> ProjectCheckpoint:
        """
        Create a checkpoint for a project.

        Args:
            project_id: Project identifier
            description: Human-readable description
            files_modified: List of modified file paths
            files_created: List of created file paths
            goals: List of goal progress dicts
            context: Additional context to save
            conversation_summary: Summary of recent conversation
            last_user_request: The last request from user
            pending_actions: Actions that still need to be done
            checkpoint_type: "manual", "auto", or "milestone"
            tags: Tags for categorization
            session_id: Current session ID

        Returns:
            The created checkpoint
        """
        # Ensure project exists
        if project_id not in self._projects:
            self.create_project(project_id, project_id)

        # Generate checkpoint ID
        timestamp = int(time.time())
        checkpoint_id = f"cp_{timestamp}"

        # Track file states
        files_tracked = []
        all_files = set(files_modified or []) | set(files_created or [])
        for path in all_files:
            files_tracked.append(FileState.from_path(path))

        # Parse goals
        goal_objects = []
        for g in (goals or []):
            if isinstance(g, GoalProgress):
                goal_objects.append(g)
            elif isinstance(g, dict):
                goal_objects.append(GoalProgress(**g))

        checkpoint = ProjectCheckpoint(
            checkpoint_id=checkpoint_id,
            project_id=project_id,
            description=description,
            session_id=session_id,
            files_tracked=files_tracked,
            files_modified=files_modified or [],
            files_created=files_created or [],
            goals=goal_objects,
            context=context or {},
            conversation_summary=conversation_summary,
            last_user_request=last_user_request,
            pending_actions=pending_actions or [],
            checkpoint_type=checkpoint_type,
            tags=tags or [],
        )

        # Save checkpoint to disk
        path = self._checkpoint_path(project_id, checkpoint_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(checkpoint.to_dict(), indent=2))

        # Update project state
        project = self._projects[project_id]
        project.checkpoint_count += 1
        project.latest_checkpoint_id = checkpoint_id
        project.latest_checkpoint_at = time.time()
        project.updated_at = time.time()
        project.has_pending_work = bool(pending_actions)
        project.last_session_id = session_id

        # Generate resume prompt
        if pending_actions:
            project.resume_prompt = self._generate_resume_prompt(checkpoint)
        else:
            project.resume_prompt = ""

        self._save_project_index()
        self._last_auto_checkpoint[project_id] = time.time()

        print(f"[CHECKPOINT] Created checkpoint {checkpoint_id} for {project_id}")
        return checkpoint

    def load_checkpoint(
        self,
        project_id: str,
        checkpoint_id: Optional[str] = None,
    ) -> Optional[ProjectCheckpoint]:
        """
        Load a checkpoint.

        Args:
            project_id: Project identifier
            checkpoint_id: Specific checkpoint ID (None = latest)

        Returns:
            The checkpoint or None if not found
        """
        project = self._projects.get(project_id)
        if not project:
            return None

        if checkpoint_id is None:
            checkpoint_id = project.latest_checkpoint_id

        if not checkpoint_id:
            return None

        path = self._checkpoint_path(project_id, checkpoint_id)
        if not path.exists():
            return None

        try:
            data = json.loads(path.read_text())
            return ProjectCheckpoint.from_dict(data)
        except Exception as e:
            print(f"[CHECKPOINT] Failed to load checkpoint: {e}")
            return None

    def list_checkpoints(
        self,
        project_id: str,
        limit: int = 10,
    ) -> List[ProjectCheckpoint]:
        """List checkpoints for a project."""
        project_dir = CHECKPOINT_DIR / project_id
        if not project_dir.exists():
            return []

        checkpoints = []
        for path in sorted(project_dir.glob("*.json"), reverse=True)[:limit]:
            try:
                data = json.loads(path.read_text())
                checkpoints.append(ProjectCheckpoint.from_dict(data))
            except Exception:
                continue

        return checkpoints

    def should_auto_checkpoint(self, project_id: str) -> bool:
        """Check if an auto-checkpoint should be created."""
        if self._auto_interval <= 0:
            return False

        last = self._last_auto_checkpoint.get(project_id, 0)
        return (time.time() - last) >= self._auto_interval

    def auto_checkpoint(
        self,
        project_id: str,
        context: Optional[Dict[str, Any]] = None,
        **kwargs
    ) -> Optional[ProjectCheckpoint]:
        """Create an auto-checkpoint if enough time has passed."""
        if not self.should_auto_checkpoint(project_id):
            return None

        return self.create_checkpoint(
            project_id=project_id,
            description="Auto-checkpoint",
            checkpoint_type="auto",
            context=context,
            **kwargs,
        )

    # =========================================================================
    # Resume Operations
    # =========================================================================

    def get_projects_with_pending_work(self) -> List[ProjectState]:
        """Get all projects that have pending work to resume."""
        return [
            p for p in self._projects.values()
            if p.status == "active" and p.has_pending_work
        ]

    def get_resume_context(self, project_id: str) -> Optional[Dict[str, Any]]:
        """
        Get context for resuming work on a project.

        Returns a dict with everything needed to resume:
        - checkpoint: The latest checkpoint data
        - summary: What was happening
        - pending_actions: What still needs to be done
        - files_changed: What files were involved
        """
        checkpoint = self.load_checkpoint(project_id)
        if not checkpoint:
            return None

        project = self._projects.get(project_id)

        return {
            "project_id": project_id,
            "project_name": project.name if project else project_id,
            "checkpoint_id": checkpoint.checkpoint_id,
            "checkpoint_created_at": checkpoint.created_at,
            "checkpoint_age_hours": (time.time() - checkpoint.created_at) / 3600,
            "description": checkpoint.description,
            "conversation_summary": checkpoint.conversation_summary,
            "last_user_request": checkpoint.last_user_request,
            "pending_actions": checkpoint.pending_actions,
            "files_modified": checkpoint.files_modified,
            "files_created": checkpoint.files_created,
            "goals": [asdict(g) if hasattr(g, '__dataclass_fields__') else g for g in checkpoint.goals],
            "context": checkpoint.context,
            "resume_prompt": project.resume_prompt if project else "",
        }

    def mark_resumed(self, project_id: str, session_id: Optional[str] = None) -> bool:
        """Mark a project as resumed (clears pending work flag temporarily)."""
        project = self._projects.get(project_id)
        if not project:
            return False

        project.last_session_id = session_id
        project.updated_at = time.time()
        self._save_project_index()

        print(f"[CHECKPOINT] Resumed project: {project_id}")
        return True

    def mark_completed(self, project_id: str) -> bool:
        """Mark a project as completed."""
        return self.update_project_status(project_id, "completed", progress_pct=100.0)

    def _generate_resume_prompt(self, checkpoint: ProjectCheckpoint) -> str:
        """Generate a prompt for resuming work."""
        parts = []

        if checkpoint.description:
            parts.append(f"Last checkpoint: {checkpoint.description}")

        if checkpoint.conversation_summary:
            parts.append(f"Context: {checkpoint.conversation_summary}")

        if checkpoint.last_user_request:
            parts.append(f"Last request: '{checkpoint.last_user_request}'")

        if checkpoint.pending_actions:
            actions = ", ".join(checkpoint.pending_actions[:3])
            if len(checkpoint.pending_actions) > 3:
                actions += f" (+{len(checkpoint.pending_actions) - 3} more)"
            parts.append(f"Pending: {actions}")

        return " | ".join(parts) if parts else "Work in progress"

    # =========================================================================
    # File Change Detection
    # =========================================================================

    def detect_file_changes(
        self,
        project_id: str,
        checkpoint_id: Optional[str] = None,
    ) -> Dict[str, List[str]]:
        """
        Detect files that changed since a checkpoint.

        Returns:
            Dict with "modified", "created", "deleted" lists
        """
        checkpoint = self.load_checkpoint(project_id, checkpoint_id)
        if not checkpoint:
            return {"modified": [], "created": [], "deleted": []}

        modified = []
        deleted = []

        for file_state in checkpoint.files_tracked:
            current = FileState.from_path(file_state.path)

            if not file_state.exists and current.exists:
                continue  # Was created, still exists

            if file_state.exists and not current.exists:
                deleted.append(file_state.path)
            elif file_state.exists and current.exists:
                # Check if modified
                if (file_state.content_hash != current.content_hash or
                    file_state.size_bytes != current.size_bytes):
                    modified.append(file_state.path)

        return {
            "modified": modified,
            "deleted": deleted,
            "created": [],  # Would need to scan directory to detect new files
        }

    # =========================================================================
    # Session Start Check
    # =========================================================================

    def get_session_start_summary(self) -> Dict[str, Any]:
        """
        Get a summary for session start.

        Returns info about any projects with pending work that might
        want to be resumed.
        """
        pending = self.get_projects_with_pending_work()

        if not pending:
            return {
                "has_pending_work": False,
                "projects": [],
                "message": "",
            }

        projects_info = []
        for project in pending[:5]:  # Limit to 5
            checkpoint = self.load_checkpoint(project.project_id)
            age_hours = 0
            if checkpoint:
                age_hours = (time.time() - checkpoint.created_at) / 3600

            projects_info.append({
                "project_id": project.project_id,
                "name": project.name,
                "resume_prompt": project.resume_prompt,
                "checkpoint_age_hours": round(age_hours, 1),
                "progress_pct": project.progress_pct,
            })

        message = f"You have {len(pending)} project(s) with pending work."
        if len(pending) == 1:
            message = f"Would you like to continue working on '{pending[0].name}'?"

        return {
            "has_pending_work": True,
            "projects": projects_info,
            "message": message,
        }


# Module-level singleton
_checkpoint_manager: Optional[CheckpointManager] = None


def get_checkpoint_manager() -> CheckpointManager:
    """Get the singleton checkpoint manager."""
    global _checkpoint_manager
    if _checkpoint_manager is None:
        _checkpoint_manager = CheckpointManager()
    return _checkpoint_manager


# Convenience functions
def create_checkpoint(
    project_id: str,
    description: str = "",
    **kwargs
) -> ProjectCheckpoint:
    """Create a checkpoint for a project."""
    return get_checkpoint_manager().create_checkpoint(project_id, description, **kwargs)


def resume_from_checkpoint(project_id: str) -> Optional[Dict[str, Any]]:
    """Get context for resuming a project."""
    return get_checkpoint_manager().get_resume_context(project_id)


def get_active_projects() -> List[ProjectState]:
    """Get all active projects."""
    return get_checkpoint_manager().list_projects(status="active")


def get_pending_projects() -> List[ProjectState]:
    """Get projects with pending work."""
    return get_checkpoint_manager().get_projects_with_pending_work()


def check_session_start() -> Dict[str, Any]:
    """Check for pending work at session start."""
    return get_checkpoint_manager().get_session_start_summary()


__all__ = [
    "CheckpointManager",
    "ProjectCheckpoint",
    "ProjectState",
    "FileState",
    "GoalProgress",
    "get_checkpoint_manager",
    "create_checkpoint",
    "resume_from_checkpoint",
    "get_active_projects",
    "get_pending_projects",
    "check_session_start",
]
