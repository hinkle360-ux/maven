"""
Autonomy Reinforcement Loop

Implements self-assigned goal management for Maven's autonomous operation.
Attaches to LearningBrain for knowledge-driven goal generation.

Components:
- goal_proposer: Proposes new goals based on gaps in knowledge
- goal_evaluator: Evaluates goal achievability and priority
- goal_memory: Stores and tracks goal progress

FULLY IMPLEMENTED: Goal lifecycle management without new brains.
"""

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field, asdict
from enum import Enum
import time
import json
from pathlib import Path

from brains.memory.brain_memory import BrainMemory
from brains.maven_paths import get_reports_path


class GoalStatus(Enum):
    """Goal lifecycle states."""
    PROPOSED = "proposed"
    ACTIVE = "active"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    DEFERRED = "deferred"


class GoalPriority(Enum):
    """Goal priority levels."""
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Goal:
    """Represents an autonomous goal."""
    id: str
    description: str
    category: str
    priority: GoalPriority
    status: GoalStatus
    created_at: float
    updated_at: float
    source: str  # What triggered this goal
    success_criteria: List[str] = field(default_factory=list)
    progress: float = 0.0  # 0.0 to 1.0
    attempts: int = 0
    max_attempts: int = 3
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        d = asdict(self)
        d["priority"] = self.priority.value
        d["status"] = self.status.value
        return d

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Goal":
        """Create from dictionary."""
        data["priority"] = GoalPriority(data.get("priority", "medium"))
        data["status"] = GoalStatus(data.get("status", "proposed"))
        return cls(**data)


# Goal memory instance
_goal_memory = BrainMemory("autonomy_goals")


def _generate_goal_id() -> str:
    """Generate unique goal ID."""
    import hashlib
    timestamp = str(time.time())
    return f"goal_{hashlib.md5(timestamp.encode()).hexdigest()[:8]}"


def _save_goals(goals: List[Goal]) -> None:
    """Save goals to persistent storage."""
    goals_path = get_reports_path() / "autonomy" / "goals.json"
    goals_path.parent.mkdir(parents=True, exist_ok=True)

    try:
        goals_data = [g.to_dict() for g in goals]
        with open(goals_path, 'w') as f:
            json.dump(goals_data, f, indent=2)
    except Exception:
        pass


def _load_goals() -> List[Goal]:
    """Load goals from persistent storage."""
    goals_path = get_reports_path() / "autonomy" / "goals.json"

    if not goals_path.exists():
        return []

    try:
        with open(goals_path, 'r') as f:
            goals_data = json.load(f)
        return [Goal.from_dict(g) for g in goals_data]
    except Exception:
        return []


# ============================================================================
# Goal Proposer
# ============================================================================

def propose_goal(
    description: str,
    category: str,
    source: str,
    priority: str = "medium",
    success_criteria: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Goal:
    """
    Propose a new autonomous goal.

    Args:
        description: What the goal aims to achieve
        category: Goal category (learning, exploration, optimization, etc.)
        source: What triggered this goal (knowledge_gap, user_feedback, etc.)
        priority: Goal priority (low, medium, high, critical)
        success_criteria: List of criteria for goal completion
        metadata: Additional metadata

    Returns:
        Created Goal object
    """
    goal = Goal(
        id=_generate_goal_id(),
        description=description,
        category=category,
        priority=GoalPriority(priority),
        status=GoalStatus.PROPOSED,
        created_at=time.time(),
        updated_at=time.time(),
        source=source,
        success_criteria=success_criteria or [],
        metadata=metadata or {},
    )

    # Store in memory
    _goal_memory.store(
        content=goal.to_dict(),
        metadata={
            "kind": "goal",
            "category": category,
            "status": "proposed",
        }
    )

    # Save to persistent storage
    goals = _load_goals()
    goals.append(goal)
    _save_goals(goals)

    return goal


def propose_learning_goal(knowledge_gap: str, domain: str) -> Goal:
    """
    Propose a goal to fill a knowledge gap.

    Args:
        knowledge_gap: Description of what's missing
        domain: Domain of the knowledge

    Returns:
        Created learning goal
    """
    return propose_goal(
        description=f"Learn about: {knowledge_gap}",
        category="learning",
        source="knowledge_gap",
        priority="medium",
        success_criteria=[
            f"Can answer questions about {knowledge_gap}",
            f"Has stored facts about {knowledge_gap}",
        ],
        metadata={
            "domain": domain,
            "gap": knowledge_gap,
        }
    )


def propose_exploration_goal(topic: str, depth: str = "moderate") -> Goal:
    """
    Propose a goal to explore a topic.

    Args:
        topic: Topic to explore
        depth: Exploration depth (shallow, moderate, deep)

    Returns:
        Created exploration goal
    """
    return propose_goal(
        description=f"Explore topic: {topic}",
        category="exploration",
        source="curiosity",
        priority="low",
        success_criteria=[
            f"Has explored {topic} to {depth} depth",
            f"Can discuss multiple aspects of {topic}",
        ],
        metadata={
            "topic": topic,
            "depth": depth,
        }
    )


# ============================================================================
# Goal Evaluator
# ============================================================================

def evaluate_goal(goal: Goal) -> Dict[str, Any]:
    """
    Evaluate a goal's achievability and priority.

    Args:
        goal: Goal to evaluate

    Returns:
        Evaluation result with score and recommendations
    """
    evaluation = {
        "goal_id": goal.id,
        "achievable": True,
        "achievability_score": 0.5,
        "priority_score": 0.5,
        "recommendations": [],
    }

    # Check attempts
    if goal.attempts >= goal.max_attempts:
        evaluation["achievable"] = False
        evaluation["recommendations"].append("Max attempts reached, consider deferring")

    # Score based on priority
    priority_scores = {
        GoalPriority.LOW: 0.25,
        GoalPriority.MEDIUM: 0.5,
        GoalPriority.HIGH: 0.75,
        GoalPriority.CRITICAL: 1.0,
    }
    evaluation["priority_score"] = priority_scores.get(goal.priority, 0.5)

    # Score based on category
    category_scores = {
        "learning": 0.8,  # High achievability for learning goals
        "exploration": 0.7,
        "optimization": 0.5,
        "repair": 0.6,
    }
    evaluation["achievability_score"] = category_scores.get(goal.category, 0.5)

    # Adjust based on progress
    evaluation["achievability_score"] = min(1.0, evaluation["achievability_score"] + goal.progress * 0.2)

    # Generate recommendations
    if goal.progress > 0 and goal.progress < 0.5:
        evaluation["recommendations"].append("Goal in early progress, continue working")
    elif goal.progress >= 0.5:
        evaluation["recommendations"].append("Goal more than half complete, prioritize completion")

    return evaluation


def prioritize_goals(goals: List[Goal]) -> List[Goal]:
    """
    Sort goals by priority and achievability.

    Args:
        goals: List of goals to prioritize

    Returns:
        Sorted list (highest priority first)
    """
    def goal_score(g: Goal) -> float:
        evaluation = evaluate_goal(g)
        return (
            evaluation["priority_score"] * 0.6 +
            evaluation["achievability_score"] * 0.4
        )

    return sorted(goals, key=goal_score, reverse=True)


# ============================================================================
# Goal Memory
# ============================================================================

def get_active_goals(limit: int = 10) -> List[Goal]:
    """
    Get currently active goals.

    Args:
        limit: Maximum goals to return

    Returns:
        List of active goals
    """
    goals = _load_goals()
    active = [g for g in goals if g.status in [GoalStatus.ACTIVE, GoalStatus.IN_PROGRESS]]
    return prioritize_goals(active)[:limit]


def get_goals_by_status(status: str) -> List[Goal]:
    """
    Get goals by status.

    Args:
        status: Status to filter by

    Returns:
        List of goals with that status
    """
    goals = _load_goals()
    target_status = GoalStatus(status)
    return [g for g in goals if g.status == target_status]


def update_goal_progress(goal_id: str, progress: float, notes: str = "") -> bool:
    """
    Update progress on a goal.

    Args:
        goal_id: Goal ID
        progress: New progress value (0.0 to 1.0)
        notes: Optional progress notes

    Returns:
        True if updated, False otherwise
    """
    goals = _load_goals()

    for goal in goals:
        if goal.id == goal_id:
            goal.progress = min(1.0, max(0.0, progress))
            goal.updated_at = time.time()

            if progress >= 1.0:
                goal.status = GoalStatus.COMPLETED
            elif progress > 0:
                goal.status = GoalStatus.IN_PROGRESS

            if notes:
                goal.metadata["progress_notes"] = goal.metadata.get("progress_notes", [])
                goal.metadata["progress_notes"].append({
                    "time": time.time(),
                    "progress": progress,
                    "note": notes,
                })

            _save_goals(goals)
            return True

    return False


def activate_goal(goal_id: str) -> bool:
    """
    Activate a proposed goal.

    Args:
        goal_id: Goal ID

    Returns:
        True if activated, False otherwise
    """
    goals = _load_goals()

    for goal in goals:
        if goal.id == goal_id and goal.status == GoalStatus.PROPOSED:
            goal.status = GoalStatus.ACTIVE
            goal.updated_at = time.time()
            _save_goals(goals)
            return True

    return False


def fail_goal(goal_id: str, reason: str) -> bool:
    """
    Mark a goal as failed.

    Args:
        goal_id: Goal ID
        reason: Failure reason

    Returns:
        True if updated, False otherwise
    """
    goals = _load_goals()

    for goal in goals:
        if goal.id == goal_id:
            goal.status = GoalStatus.FAILED
            goal.updated_at = time.time()
            goal.metadata["failure_reason"] = reason
            goal.attempts += 1
            _save_goals(goals)
            return True

    return False


def defer_goal(goal_id: str, until: Optional[float] = None) -> bool:
    """
    Defer a goal for later.

    Args:
        goal_id: Goal ID
        until: Optional timestamp to defer until

    Returns:
        True if deferred, False otherwise
    """
    goals = _load_goals()

    for goal in goals:
        if goal.id == goal_id:
            goal.status = GoalStatus.DEFERRED
            goal.updated_at = time.time()
            if until:
                goal.metadata["deferred_until"] = until
            _save_goals(goals)
            return True

    return False


def get_goal_stats() -> Dict[str, Any]:
    """
    Get statistics about goals.

    Returns:
        Dict with goal statistics
    """
    goals = _load_goals()

    stats = {
        "total": len(goals),
        "by_status": {},
        "by_category": {},
        "completion_rate": 0.0,
    }

    for goal in goals:
        status_name = goal.status.value
        stats["by_status"][status_name] = stats["by_status"].get(status_name, 0) + 1

        stats["by_category"][goal.category] = stats["by_category"].get(goal.category, 0) + 1

    completed = stats["by_status"].get("completed", 0)
    total_finished = completed + stats["by_status"].get("failed", 0)
    if total_finished > 0:
        stats["completion_rate"] = completed / total_finished

    return stats
