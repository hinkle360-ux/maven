# brains/cognitive/maven_responder/service/maven_responder.py
"""
Maven Responder Brain (EVA - External Voice Authority)
=======================================================

The single authority for Maven's external voice. All user-facing and
external AI-facing responses MUST go through this brain.

Design Principle:
    LLMs are advisors, Maven is the speaker.

    - LLM outputs go to answer_drafts lane (internal)
    - Tool results go to tool_results lane (internal)
    - Only maven_responder writes to maven_voice lane (user-facing)

Multi-Question Behavior:
    - Read question_batch from blackboard (from Router)
    - Mirror the asker's structure (numbered, bulleted, prose)
    - Answer each question explicitly, in order
    - Use depth guidance from Length & Depth Planner
    - Add optional Maven-flavored closing reflection

This brain:
1. Reads user request and context
2. Gets question_batch and depth_plan from blackboard
3. Gathers drafts/notes from LLMs and tools (answer_drafts, tool_results)
4. Synthesizes a response per question, matching structure
5. Writes the final answer to maven_voice lane

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
import re
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field

# Import blackboard
try:
    from brains.pipeline.blackboard import (
        Blackboard,
        BlackboardEntry,
        create_blackboard,
    )
except ImportError:
    Blackboard = None
    BlackboardEntry = None

# Import Teacher for internal synthesis (as advisor only)
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _synthesis_helper = TeacherHelper("maven_responder")
except Exception:
    _synthesis_helper = None

# Import question parser for multi-question handling
try:
    from brains.routing.question_parser import (
        QuestionBatch,
        ParsedQuestion,
        QuestionStructure,
        QuestionTopic,
    )
    _question_parser_available = True
except ImportError:
    _question_parser_available = False
    QuestionBatch = None
    QuestionStructure = None

# Import routing engine for retrieving question batches
try:
    from brains.routing.routing_engine import (
        get_question_batch_from_blackboard,
        get_depth_plan_from_blackboard,
    )
    _routing_engine_available = True
except ImportError:
    _routing_engine_available = False

# Import introspection for dynamic self-knowledge
try:
    from brains.routing.router_introspection import (
        get_self_model,
        get_summary_text,
    )
    _introspection_available = True
except ImportError:
    _introspection_available = False

# Import self_blocks for self-description
try:
    from brains.cognitive.self_model.service.self_blocks import (
        SelfIntent,
        assemble_self_answer,
        get_registry_data,
    )
    _self_blocks_available = True
except ImportError:
    _self_blocks_available = False

# Import structure mirroring for multi-agent conversations
try:
    from brains.cognitive.response_planner import (
        StructureMirror,
        create_structure_mirror,
        format_mirrored_response,
    )
    _structure_mirror_available = True
except ImportError:
    _structure_mirror_available = False
    StructureMirror = None


# =============================================================================
# Configuration
# =============================================================================

# Maven's persona traits for consistent voice
MAVEN_PERSONA = {
    "name": "Maven",
    "style": "concise, direct, helpful",
    "traits": [
        "Short, structured responses",
        "Technical accuracy over pleasantries",
        "Action-oriented when appropriate",
        "Honest about limitations",
    ],
    "avoid": [
        "Excessive praise or validation",
        "Copying LLM outputs verbatim",
        "Internal technical jargon (paths, timestamps, dicts)",
        "Overly long explanations",
    ],
}

# Overlap threshold - if response is too similar to LLM draft, rephrase
SIMILARITY_THRESHOLD = 0.70


# =============================================================================
# HYBRID MAVEN SPEC: Identity Repetition Control
# =============================================================================
# Track when identity has been explained to prevent "I'm Maven..." spam
#
# Rules:
# - Full identity only when: user explicitly asks OR new conversation
# - After first explanation, use only brief reminders if needed
# - Never spam "I'm Maven, a modular AI assistant..."

_identity_explained_this_conversation: bool = False
_identity_explain_count: int = 0
_MAX_IDENTITY_EXPLAINS_PER_SESSION = 1  # Only explain identity once per conversation


def reset_identity_state() -> None:
    """Reset identity state at start of new conversation."""
    global _identity_explained_this_conversation, _identity_explain_count
    _identity_explained_this_conversation = False
    _identity_explain_count = 0


def should_include_full_identity(force: bool = False, explicit_request: bool = False) -> bool:
    """
    HYBRID MAVEN SPEC: Determine if full identity block should be included.

    Rules:
    - Full identity only when: user explicitly asks OR new conversation
    - After first explanation, use only brief reminders if needed
    - Never spam "I'm Maven, a modular AI assistant..."
    """
    global _identity_explained_this_conversation, _identity_explain_count

    if force or explicit_request:
        return True

    if not _identity_explained_this_conversation:
        return True

    # Already explained - don't repeat
    return False


def mark_identity_explained() -> None:
    """Mark that identity has been explained this conversation."""
    global _identity_explained_this_conversation, _identity_explain_count
    _identity_explained_this_conversation = True
    _identity_explain_count += 1


def get_identity_reminder() -> str:
    """Get brief identity reminder instead of full explanation."""
    return "As a modular AI assistant"  # Short, inline prefix only


def is_explicit_identity_request(text: str) -> bool:
    """Check if user explicitly asked about Maven's identity."""
    text_lower = text.lower()
    explicit_patterns = [
        "who are you", "what are you", "introduce yourself",
        "describe yourself", "tell me about yourself", "remind me what you are",
        "your name", "whoami",
    ]
    return any(p in text_lower for p in explicit_patterns)


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class SynthesisContext:
    """Context gathered for response synthesis."""
    user_query: str
    normalized_query: str
    intent: Optional[str]
    drafts: List[Dict[str, Any]]
    tool_results: List[Dict[str, Any]]
    conversation_history: Optional[str]
    target_audience: str  # "user", "chatgpt", "claude", "grok"


@dataclass
class SynthesizedResponse:
    """Result of response synthesis."""
    text: str
    confidence: float
    source_drafts: List[str]
    rephrased: bool  # True if similarity check forced rephrase


@dataclass
class PerQuestionAnswer:
    """Answer for a single question in a multi-question batch."""
    question_id: str
    question_text: str
    answer_text: str
    depth_used: str  # "short", "medium", "deep"


@dataclass
class StructuredResponse:
    """
    A response that mirrors the asker's structure.

    Contains answers for each question plus optional closing.
    """
    structure: str  # "numbered", "bulleted", "prose", "single"
    answers: List[PerQuestionAnswer]
    closing: Optional[str] = None
    total_questions: int = 0

    def format(self) -> str:
        """Format the response matching the original structure."""
        if not self.answers:
            return ""

        parts = []

        if self.structure == "numbered":
            # Numbered list with headers
            for i, answer in enumerate(self.answers, 1):
                # Create a brief header from the question
                header = _extract_question_header(answer.question_text)
                parts.append(f"**{i}. {header}**\n\n{answer.answer_text}")

        elif self.structure == "bulleted":
            # Bulleted responses
            for answer in self.answers:
                header = _extract_question_header(answer.question_text)
                parts.append(f"**{header}**\n\n{answer.answer_text}")

        elif self.structure == "prose" and len(self.answers) > 1:
            # Prose with labeled paragraphs for multiple questions
            for answer in self.answers:
                header = _extract_question_header(answer.question_text)
                parts.append(f"**{header}**\n\n{answer.answer_text}")

        else:
            # Single question or simple prose - just the answer
            parts.append(self.answers[0].answer_text)

        # Combine answers
        result = "\n\n".join(parts)

        # Add closing if provided
        if self.closing:
            result += f"\n\n{self.closing}"

        return result


def _extract_question_header(question_text: str) -> str:
    """
    Extract a brief header from a question for section titles.

    e.g., "How do these 37 brains coordinate?" -> "How my brains coordinate"
    """
    # Remove question marks and clean up
    text = question_text.rstrip("?").strip()

    # Common transformations for Maven's voice
    text = re.sub(r"\bthese\s+\d+\b", "my", text, flags=re.IGNORECASE)
    text = re.sub(r"\byour\b", "my", text, flags=re.IGNORECASE)
    text = re.sub(r"\bdo you\b", "I", text, flags=re.IGNORECASE)
    text = re.sub(r"\bare\s+the\b", "are my", text, flags=re.IGNORECASE)

    # Capitalize first letter
    if text:
        text = text[0].upper() + text[1:]

    # Limit length
    words = text.split()
    if len(words) > 8:
        text = " ".join(words[:8]) + "..."

    return text


# =============================================================================
# Similarity Detection (Guardrail)
# =============================================================================

def compute_ngram_similarity(text1: str, text2: str, n: int = 3) -> float:
    """
    Compute n-gram based similarity between two texts.

    Returns a value between 0 (completely different) and 1 (identical).
    Used to detect when Maven's response is too similar to LLM drafts.
    """
    if not text1 or not text2:
        return 0.0

    def get_ngrams(text: str, n: int) -> set:
        text = text.lower().strip()
        # Remove punctuation for comparison
        text = re.sub(r'[^\w\s]', '', text)
        words = text.split()
        if len(words) < n:
            return {tuple(words)}
        return {tuple(words[i:i+n]) for i in range(len(words) - n + 1)}

    ngrams1 = get_ngrams(text1, n)
    ngrams2 = get_ngrams(text2, n)

    if not ngrams1 or not ngrams2:
        return 0.0

    intersection = len(ngrams1 & ngrams2)
    union = len(ngrams1 | ngrams2)

    return intersection / union if union > 0 else 0.0


def check_similarity_to_drafts(response: str, drafts: List[Dict[str, Any]]) -> Tuple[bool, float]:
    """
    Check if response is too similar to any draft.

    Returns:
        Tuple of (is_too_similar, max_similarity_score)
    """
    max_similarity = 0.0

    for draft in drafts:
        draft_text = draft.get("draft_text", "") or str(draft.get("payload", ""))
        similarity = compute_ngram_similarity(response, draft_text)
        max_similarity = max(max_similarity, similarity)

    return (max_similarity > SIMILARITY_THRESHOLD, max_similarity)


# =============================================================================
# Response Synthesis
# =============================================================================

def _extract_draft_content(drafts: List[BlackboardEntry]) -> List[Dict[str, Any]]:
    """Extract content from draft entries."""
    result = []
    for entry in drafts:
        payload = entry.payload
        if isinstance(payload, dict):
            result.append({
                "id": entry.id,
                "owner": entry.owner,
                "draft_text": payload.get("draft_text", ""),
                "draft_type": payload.get("draft_type", "unknown"),
                "source_info": payload.get("source_info", {}),
            })
        elif isinstance(payload, str):
            result.append({
                "id": entry.id,
                "owner": entry.owner,
                "draft_text": payload,
                "draft_type": "raw",
                "source_info": {},
            })
    return result


def _extract_tool_content(tool_results: List[BlackboardEntry]) -> List[Dict[str, Any]]:
    """Extract content from tool result entries."""
    result = []
    for entry in tool_results:
        result.append({
            "id": entry.id,
            "owner": entry.owner,
            "payload": entry.payload,
        })
    return result


def gather_synthesis_context(
    blackboard: Blackboard,
    target_audience: str = "user",
) -> SynthesisContext:
    """
    Gather all context needed for response synthesis from the blackboard.

    Args:
        blackboard: The blackboard instance
        target_audience: Who the response is for ("user", "chatgpt", "claude", "grok")

    Returns:
        SynthesisContext with all gathered information
    """
    # Get user input
    user_input = blackboard.get_user_input() or {}
    user_query = user_input.get("original_query", "")
    normalized_query = user_input.get("normalized_text", user_query)
    intent = user_input.get("intent")

    # Get drafts from answer_drafts lane
    draft_entries = blackboard.get_entries(lane="answer_drafts")
    drafts = _extract_draft_content(draft_entries)

    # Get tool results
    tool_entries = blackboard.get_entries(lane="tool_results")
    tool_results = _extract_tool_content(tool_entries)

    # Get conversation context if available
    context_entry = blackboard.get_latest(lane="context")
    conversation_history = None
    if context_entry and isinstance(context_entry.payload, dict):
        history = context_entry.payload.get("conversation_history", [])
        if history:
            # Format last few turns
            recent = history[-6:] if len(history) > 6 else history
            conversation_history = "\n".join([
                f"{turn.get('role', 'unknown')}: {turn.get('text', '')[:100]}"
                for turn in recent
            ])

    return SynthesisContext(
        user_query=user_query,
        normalized_query=normalized_query,
        intent=intent,
        drafts=drafts,
        tool_results=tool_results,
        conversation_history=conversation_history,
        target_audience=target_audience,
    )


def synthesize_response(
    context: SynthesisContext,
    force_rephrase: bool = False,
) -> SynthesizedResponse:
    """
    Synthesize a response in Maven's voice from gathered context.

    This is the core function that transforms LLM drafts and tool results
    into Maven's own voice.

    Args:
        context: The synthesis context with all gathered information
        force_rephrase: Force a rephrase pass even if similarity is below threshold

    Returns:
        SynthesizedResponse with the final text
    """
    # If no drafts or tool results, generate a basic response
    if not context.drafts and not context.tool_results:
        return SynthesizedResponse(
            text=_generate_fallback_response(context),
            confidence=0.5,
            source_drafts=[],
            rephrased=False,
        )

    # Combine draft content for synthesis
    draft_texts = [d["draft_text"] for d in context.drafts if d.get("draft_text")]
    tool_summaries = _summarize_tool_results(context.tool_results)

    # Build synthesis prompt
    response = _synthesize_with_teacher(
        user_query=context.user_query,
        drafts=draft_texts,
        tool_summaries=tool_summaries,
        target_audience=context.target_audience,
        conversation_history=context.conversation_history,
    )

    if not response:
        # Fallback: simple combination without LLM
        response = _synthesize_without_llm(context)

    # Check similarity to drafts (guardrail)
    is_too_similar, similarity = check_similarity_to_drafts(response, context.drafts)

    if is_too_similar or force_rephrase:
        # Force a rephrase pass
        response = _rephrase_response(response, context)

    return SynthesizedResponse(
        text=response,
        confidence=0.8 if response else 0.3,
        source_drafts=[d["id"] for d in context.drafts],
        rephrased=is_too_similar or force_rephrase,
    )


def _generate_fallback_response(context: SynthesisContext) -> str:
    """Generate a fallback response when no drafts are available."""
    if context.intent:
        return f"I understand you're asking about {context.intent}. Let me look into that."
    return "I'm processing your request. One moment please."


def _summarize_tool_results(tool_results: List[Dict[str, Any]]) -> str:
    """Create a brief summary of tool results for synthesis."""
    if not tool_results:
        return ""

    summaries = []
    for result in tool_results:
        owner = result.get("owner", "unknown")
        payload = result.get("payload", {})

        if isinstance(payload, dict):
            # Extract key info, avoiding internal fields
            status = payload.get("status", "completed")
            summary = payload.get("summary", payload.get("recap", ""))
            if summary:
                summaries.append(f"[{owner}] {summary[:200]}")
            elif status:
                summaries.append(f"[{owner}] Status: {status}")
        elif isinstance(payload, str):
            summaries.append(f"[{owner}] {payload[:200]}")

    return "\n".join(summaries)


def _synthesize_with_teacher(
    user_query: str,
    drafts: List[str],
    tool_summaries: str,
    target_audience: str,
    conversation_history: Optional[str],
) -> Optional[str]:
    """
    Use Teacher (LLM) as internal helper for synthesis.

    The LLM here is used as an ADVISOR only - its output will be
    checked for similarity and may be rephrased.
    """
    if not _synthesis_helper:
        return None

    # Build the synthesis prompt with clear instructions
    prompt = f"""You are a draft generator helping Maven synthesize a response.
Your text will NOT be shown directly to the user - Maven will rephrase it.

IMPORTANT: Provide notes and key points, not polished prose.
Maven will speak in its own voice based on your notes.

---
User Query: {user_query}

Target Audience: {target_audience}

{f'Conversation History:{chr(10)}{conversation_history}{chr(10)}---' if conversation_history else ''}

Notes from LLM advisors:
{chr(10).join(f'- {d[:300]}' for d in drafts[:5]) if drafts else '(none)'}

Tool results summary:
{tool_summaries or '(none)'}

---
Maven's persona: Concise, direct, helpful. No excessive praise.
Avoid: copying drafts verbatim, internal jargon, overly long explanations.

Synthesize a response (2-5 sentences) that:
1. Addresses the user's query directly
2. Incorporates relevant facts from drafts/tools
3. Uses Maven's voice (short, direct, action-oriented)

Your draft (for Maven to rephrase):"""

    try:
        result = _synthesis_helper.maybe_call_teacher(
            question=prompt,
            context={
                "mode": "response_synthesis",
                "target": target_audience,
            }
        )

        if result and result.get("answer"):
            response = str(result["answer"]).strip()
            # Clean up common LLM artifacts
            response = re.sub(r'^(Here\'s|Sure,|Certainly,|Of course,)\s*', '', response, flags=re.IGNORECASE)
            response = re.sub(r'^(Maven\'s response:|Response:)\s*', '', response, flags=re.IGNORECASE)
            return response
    except Exception as e:
        print(f"[MAVEN_RESPONDER] Synthesis error: {e}")

    return None


def _synthesize_without_llm(context: SynthesisContext) -> str:
    """
    Fallback synthesis without using an LLM.

    Simply extracts key information and formats it concisely.
    """
    parts = []

    # Use the first draft's key content
    if context.drafts:
        first_draft = context.drafts[0].get("draft_text", "")
        # Take first 2 sentences
        sentences = re.split(r'[.!?]\s+', first_draft)
        if sentences:
            parts.append(sentences[0] + ".")
            if len(sentences) > 1:
                parts.append(sentences[1] + ".")

    # Add tool result summary
    if context.tool_results:
        for result in context.tool_results[:2]:
            payload = result.get("payload", {})
            if isinstance(payload, dict):
                summary = payload.get("summary", payload.get("recap", ""))
                if summary:
                    parts.append(summary[:150])

    return " ".join(parts) if parts else _generate_fallback_response(context)


def _rephrase_response(response: str, context: SynthesisContext) -> str:
    """
    Force a rephrase of the response to reduce similarity to drafts.

    This is the guardrail against verbatim copying.
    """
    if not _synthesis_helper:
        # Without LLM, do simple word substitution
        return _simple_rephrase(response)

    prompt = f"""Rephrase this text in Maven's voice.
DO NOT keep any sentences the same. Change the wording completely.
Keep the meaning but use different words and structure.

Maven's style: Short, direct, no fluff.

Original:
{response}

Rephrased (different words, same meaning):"""

    try:
        result = _synthesis_helper.maybe_call_teacher(
            question=prompt,
            context={"mode": "rephrase"}
        )

        if result and result.get("answer"):
            rephrased = str(result["answer"]).strip()
            rephrased = re.sub(r'^(Here\'s|Rephrased:)\s*', '', rephrased, flags=re.IGNORECASE)
            return rephrased
    except Exception:
        pass

    return _simple_rephrase(response)


def _simple_rephrase(text: str) -> str:
    """Simple rephrase without LLM - just restructure slightly."""
    sentences = re.split(r'([.!?]\s+)', text)
    # Reverse sentence order as simple restructuring
    if len(sentences) > 2:
        # Keep first, shuffle middle
        result = [sentences[0], sentences[1]]
        middle = sentences[2:-2] if len(sentences) > 4 else []
        result.extend(reversed(middle))
        result.extend(sentences[-2:] if len(sentences) > 2 else [])
        return ''.join(result)
    return text


# =============================================================================
# Multi-Question Synthesis (Structure Mirroring)
# =============================================================================

def synthesize_multi_question_response(
    blackboard: Blackboard,
    target_audience: str = "user",
) -> StructuredResponse:
    """
    Synthesize a structured response for a multi-question message.

    This is the main entry point for the new multi-question behavior.

    Steps:
    1. Get question_batch and depth_plan from blackboard
    2. For each question, synthesize an answer
    3. Apply depth guidance from planner
    4. Format with structure mirroring
    5. Add optional closing

    Args:
        blackboard: Blackboard with context and drafts
        target_audience: Who the response is for

    Returns:
        StructuredResponse ready for formatting
    """
    # Get question batch from blackboard
    question_batch = None
    depth_plan = None

    if _routing_engine_available:
        try:
            question_batch = get_question_batch_from_blackboard(blackboard)
            depth_plan = get_depth_plan_from_blackboard(blackboard)
        except Exception:
            pass

    # If no question batch, fall back to simple synthesis
    if not question_batch or not question_batch.items:
        # Get single answer using existing logic
        context = gather_synthesis_context(blackboard, target_audience)
        result = synthesize_response(context)

        return StructuredResponse(
            structure="single",
            answers=[PerQuestionAnswer(
                question_id="q1",
                question_text=context.user_query,
                answer_text=result.text,
                depth_used="medium",
            )],
            closing=None,
            total_questions=1,
        )

    # Synthesize answer for each question
    answers = []
    drafts = _gather_all_drafts(blackboard)
    tool_summaries = _gather_tool_summaries(blackboard)

    for question in question_batch.items:
        # Get depth guidance for this question
        depth = "medium"
        max_sentences = 5
        if depth_plan and isinstance(depth_plan, dict):
            q_guidance = depth_plan.get("per_question", {}).get(question.id, {})
            depth = q_guidance.get("depth", "medium")
            max_sentences = q_guidance.get("max_sentences", 5)

        # Synthesize answer for this question
        answer_text = _synthesize_single_question_answer(
            question=question,
            drafts=drafts,
            tool_summaries=tool_summaries,
            depth=depth,
            max_sentences=max_sentences,
            target_audience=target_audience,
            blackboard=blackboard,
        )

        answers.append(PerQuestionAnswer(
            question_id=question.id,
            question_text=question.text,
            answer_text=answer_text,
            depth_used=depth,
        ))

        # Mark question as answered
        question.answered = True
        question.answer_content = answer_text

    # Determine if we should add a closing
    closing = None
    add_closing = False
    if depth_plan and isinstance(depth_plan, dict):
        add_closing = depth_plan.get("add_closing", False)

    if add_closing and len(answers) > 1:
        closing = _generate_closing_reflection(question_batch, answers)

    # Get structure from question batch
    structure = "numbered"  # Default
    if hasattr(question_batch, 'structure'):
        if hasattr(question_batch.structure, 'value'):
            structure = question_batch.structure.value
        else:
            structure = str(question_batch.structure)

    # Create structure mirror for enhanced formatting (multi-agent conversations)
    structure_mirror = None
    if _structure_mirror_available and question_batch:
        try:
            structure_mirror = create_structure_mirror(question_batch)
            if structure_mirror:
                # Use structure mirror's detected input structure
                structure = structure_mirror.input_structure
        except Exception:
            pass

    return StructuredResponse(
        structure=structure,
        answers=answers,
        closing=closing,
        total_questions=len(answers),
    )


def _gather_all_drafts(blackboard: Blackboard) -> List[Dict[str, Any]]:
    """Gather all draft content from the blackboard."""
    draft_entries = blackboard.get_entries(lane="answer_drafts")
    return _extract_draft_content(draft_entries)


def _gather_tool_summaries(blackboard: Blackboard) -> str:
    """Gather tool result summaries from the blackboard."""
    tool_entries = blackboard.get_entries(lane="tool_results")
    tool_results = _extract_tool_content(tool_entries)
    return _summarize_tool_results(tool_results)


def _synthesize_single_question_answer(
    question: Any,  # ParsedQuestion
    drafts: List[Dict[str, Any]],
    tool_summaries: str,
    depth: str,
    max_sentences: int,
    target_audience: str,
    blackboard: Optional[Blackboard] = None,
) -> str:
    """
    Synthesize an answer for a single question.

    Routes to different handlers based on question topic:
    - RECENT_LEARNING: retrieves recent facts/lessons from memory
    - SESSION_HISTORY: summarizes conversation history
    - SELF_ARCHITECTURE: uses dynamic introspection
    - Others: uses draft content
    """
    topic = None
    if hasattr(question, 'inferred_topic'):
        topic = question.inferred_topic

    topic_value = ""
    if topic:
        topic_value = topic.value if hasattr(topic, 'value') else str(topic)

    # RECENT_LEARNING: "what did you just learn"
    if topic_value == "recent_learning":
        return _synthesize_recent_learning_answer(
            question=question,
            drafts=drafts,
            tool_summaries=tool_summaries,
            depth=depth,
            blackboard=blackboard,
        )

    # SESSION_HISTORY: "what did we discuss"
    if topic_value == "session_history":
        return _synthesize_session_history_answer(
            question=question,
            depth=depth,
            blackboard=blackboard,
        )

    # For self-architecture questions, use dynamic introspection
    is_self_question = topic_value.startswith("self_") or topic_value in [
        "coordination", "memory_persistence", "learning_teacher",
        "routing_control", "tools_actions",
    ]

    if is_self_question and _self_blocks_available:
        # Use self_blocks for accurate self-description
        return _synthesize_self_answer(question, depth, max_sentences)

    # For other questions, use draft content
    return _synthesize_from_drafts(
        question_text=question.text,
        drafts=drafts,
        tool_summaries=tool_summaries,
        depth=depth,
        max_sentences=max_sentences,
        target_audience=target_audience,
    )


def _synthesize_recent_learning_answer(
    question: Any,
    drafts: List[Dict[str, Any]],
    tool_summaries: str,
    depth: str,
    blackboard: Optional[Blackboard] = None,
) -> str:
    """
    Synthesize an answer about recent learning.

    This retrieves facts/lessons from:
    1. Tool results on the blackboard (e.g., ChatGPT session facts)
    2. Answer drafts that contain learning summaries
    3. Telemetry events tagged as facts or lessons
    """
    facts = []
    lessons = []

    # 1. Check tool results for stored facts
    if blackboard:
        tool_entries = blackboard.get_entries(lane="tool_results")
        for entry in tool_entries:
            payload = entry.payload
            if isinstance(payload, dict):
                # Look for facts stored by browser tools
                stored_facts = payload.get("facts_stored", [])
                if stored_facts:
                    facts.extend(stored_facts)

                # Look for session summaries
                summary = payload.get("summary", payload.get("recap", ""))
                if summary and "learn" in summary.lower():
                    lessons.append(summary)

                # Look for decisions/outcomes
                decisions = payload.get("decisions", [])
                for d in decisions:
                    if isinstance(d, dict) and d.get("type") == "fact":
                        facts.append(d.get("content", str(d)))

        # 2. Check telemetry for fact decisions
        telemetry = blackboard.get_entries(lane="telemetry")
        for entry in telemetry:
            payload = entry.payload
            if isinstance(payload, dict):
                event_type = payload.get("event_type", "")
                if "fact" in event_type.lower() or "lesson" in event_type.lower():
                    data = payload.get("data", {})
                    if isinstance(data, dict):
                        content = data.get("content", data.get("fact", str(data)))
                        if content:
                            facts.append(str(content)[:200])

    # 3. Also check drafts for learning-related content
    for draft in drafts:
        draft_text = draft.get("draft_text", "")
        if any(kw in draft_text.lower() for kw in ["learned", "fact", "lesson", "discovered"]):
            lessons.append(draft_text[:300])

    # 4. Include tool summaries if they mention learning
    if tool_summaries and any(kw in tool_summaries.lower() for kw in ["learn", "fact", "discover"]):
        lessons.append(tool_summaries[:300])

    # Build the answer
    if not facts and not lessons:
        return (
            "I don't have any recent learning to report from this session. "
            "If I had a conversation with an external AI like ChatGPT or Grok, "
            "I would summarize what I learned from that interaction here."
        )

    parts = []

    if facts:
        if depth == "short":
            parts.append(f"From this session, I stored {len(facts)} facts.")
        else:
            parts.append(f"Here's what I learned from this session ({len(facts)} facts):\n")
            for i, fact in enumerate(facts[:10], 1):  # Limit to 10
                fact_text = str(fact)[:150]
                parts.append(f"  {i}. {fact_text}")

    if lessons:
        if parts:
            parts.append("\n")
        parts.append("Key takeaways:")
        for lesson in lessons[:5]:  # Limit to 5
            parts.append(f"  - {lesson[:200]}")

    return "\n".join(parts)


def _synthesize_session_history_answer(
    question: Any,
    depth: str,
    blackboard: Optional[Blackboard] = None,
) -> str:
    """
    Synthesize an answer about conversation history.

    This retrieves the recent conversation context from:
    1. The context lane on the blackboard
    2. User input history
    """
    history_items = []

    if blackboard:
        # Get context lane for conversation history
        context_entry = blackboard.get_latest(lane="context")
        if context_entry and isinstance(context_entry.payload, dict):
            history = context_entry.payload.get("conversation_history", [])
            for turn in history[-10:]:  # Last 10 turns
                role = turn.get("role", "unknown")
                text = turn.get("text", "")[:100]
                if text:
                    history_items.append(f"{role}: {text}")

        # Get user inputs
        user_inputs = blackboard.get_entries(lane="user_input")
        for entry in user_inputs[-5:]:  # Last 5
            if isinstance(entry.payload, dict):
                query = entry.payload.get("original_query", "")
                if query:
                    history_items.append(f"You asked: {query[:100]}")

    if not history_items:
        return (
            "I don't have detailed conversation history from this session yet. "
            "As we continue talking, I track our discussion topics and can "
            "summarize them when asked."
        )

    if depth == "short":
        return f"In this session, we've had {len(history_items)} exchanges so far."

    parts = ["Here's a summary of our recent conversation:"]
    for item in history_items[-8:]:  # Last 8 for readability
        parts.append(f"  - {item}")

    return "\n".join(parts)


def _synthesize_self_answer(
    question: Any,
    depth: str,
    max_sentences: int,
) -> str:
    """
    HYBRID MAVEN SPEC: Synthesize an answer to a self-architecture question.

    Uses dynamic introspection and self_blocks for accurate info.

    Identity repetition control:
    - Full identity only when: user explicitly asks OR new conversation
    - After first explanation, use only brief reminders
    - Never spam "I'm Maven, a modular AI assistant..."
    """
    question_text = question.text.lower()

    # HYBRID MAVEN: Check if this is an explicit identity request
    is_identity_question = is_explicit_identity_request(question.text)
    include_full_identity = should_include_full_identity(explicit_request=is_identity_question)

    # Map question to SelfIntent
    intent = None
    if _self_blocks_available:
        if any(kw in question_text for kw in ["coordinate", "communicate", "interact"]):
            intent = SelfIntent.ARCHITECTURE_DETAIL
        elif any(kw in question_text for kw in ["specialized", "function", "modality"]):
            intent = SelfIntent.BRAINS
        elif any(kw in question_text for kw in ["control flow", "sync", "async", "parallel"]):
            intent = SelfIntent.ARCHITECTURE_DETAIL
        elif any(kw in question_text for kw in ["tool", "external", "action"]):
            intent = SelfIntent.TOOLS
        elif any(kw in question_text for kw in ["memory", "persist", "remember"]):
            intent = SelfIntent.MEMORY
        elif any(kw in question_text for kw in ["learn", "improve", "evolve"]):
            intent = SelfIntent.LEARNING
        elif is_identity_question:
            intent = SelfIntent.IDENTITY
        else:
            intent = SelfIntent.ARCHITECTURE_HIGHLEVEL

    # Get registry data for accurate counts
    registry_data = {}
    if _self_blocks_available:
        try:
            registry_data = get_registry_data()
        except Exception:
            pass

    # Generate answer based on question content
    # This uses dynamic data, not hardcoded values
    if "coordinate" in question_text or "communicate" in question_text:
        return _generate_coordination_answer(registry_data, depth)
    elif "specialized" in question_text or "function" in question_text or "modality" in question_text:
        return _generate_specialization_answer(registry_data, depth)
    elif "control flow" in question_text or "sync" in question_text or "async" in question_text:
        return _generate_control_flow_answer(registry_data, depth)
    elif "tool" in question_text and "interact" in question_text:
        return _generate_tool_interaction_answer(registry_data, depth)
    else:
        # Generic architecture answer
        if _self_blocks_available and intent:
            short_form = (depth == "short")

            # HYBRID MAVEN: Identity repetition control
            if intent == SelfIntent.IDENTITY:
                if include_full_identity:
                    # Mark that we've explained identity
                    mark_identity_explained()
                    return assemble_self_answer(intent, max_blocks=2, short_form=short_form)
                else:
                    # Already explained - use brief reminder
                    return (
                        f"{get_identity_reminder()}, I can answer questions about "
                        "my architecture, brains, tools, and how I work."
                    )

            return assemble_self_answer(intent, max_blocks=2, short_form=short_form)

    return "I can answer questions about my architecture and capabilities."


def _generate_coordination_answer(registry_data: Dict[str, Any], depth: str) -> str:
    """Generate answer about brain coordination."""
    brain_count = registry_data.get("total_brains", 0)

    if depth == "short":
        return (
            f"My {brain_count} brains coordinate through a routing brain and shared blackboard. "
            "The router dispatches tasks; brains write results to the blackboard; "
            "my response synthesizer produces the final answer."
        )

    return (
        f"Internally, I use a combination of a routing brain and a shared blackboard.\n\n"
        f"The routing brain inspects the incoming request, decides which subset of my "
        f"{brain_count} cognitive brains is relevant (reasoning, memory, learning, self-modeling, etc.), "
        "and posts structured tasks onto the blackboard.\n\n"
        "Each relevant brain can then read from the blackboard, contribute its own partial analysis "
        "or proposal, and write its results back.\n\n"
        "The router monitors this shared space, marks which sub-questions have been covered, "
        "and decides when there is enough internal agreement or coverage to move on.\n\n"
        "So coordination is partly centralized (via routing decisions) and partly distributed "
        "(via multiple brains contributing to the same shared workspace)."
    )


def _generate_specialization_answer(registry_data: Dict[str, Any], depth: str) -> str:
    """Generate answer about brain specialization."""
    if depth == "short":
        return (
            "My brains are specialized primarily by function: routing, reasoning, memory, "
            "learning, and response synthesis. Some focus on specific modalities like "
            "planning or self-description."
        )

    return (
        "My brains are specialized primarily by function, and secondarily by the kind of "
        "information they tend to work with.\n\n"
        "By function, I have brains focused on things like: routing, long-horizon reasoning, "
        "memory access, learning and evaluation, response shaping, and self-description.\n\n"
        "By 'modality' in my case, it's more about role than raw data type: for example, "
        "some brains focus on planning and decomposition, others on integrating tool results, "
        "others on summarizing internal state into something you can read.\n\n"
        "The exact list and counts are pulled dynamically from my internal registry, "
        "but the pattern is: many narrow, role-specific brains rather than a single general one."
    )


def _generate_control_flow_answer(registry_data: Dict[str, Any], depth: str) -> str:
    """Generate answer about control flow."""
    if depth == "short":
        return (
            "My control flow is hybrid: the routing brain steps through a sequence "
            "(parse → classify → assign → wait → synthesize), but within that, "
            "multiple brains can work logically in parallel on the blackboard."
        )

    return (
        "Logically, my control flow is hybrid:\n\n"
        "At the coordination level, the routing brain steps through a sequence: "
        "parse request → identify questions → assign brains → wait for contributions → "
        "hand off to my external voice.\n\n"
        "Within that, multiple brains can work 'in parallel' from a logical perspective, "
        "each reading and writing to the blackboard as they add their part.\n\n"
        "Before I answer you, the routing brain waits until each identified question has at least "
        "one suitable internal answer, so you get a coherent, ordered response rather than "
        "a stream of partial thoughts.\n\n"
        "So the orchestration is sequential, but the internal contributions behave like "
        "controlled parallel workers."
    )


def _generate_tool_interaction_answer(registry_data: Dict[str, Any], depth: str) -> str:
    """Generate answer about tool interaction."""
    tool_count = registry_data.get("total_tools", 0)

    if depth == "short":
        return (
            f"I keep a strict separation: my {tool_count} tools execute actions "
            "(browser, web search, files), but brains decide what and why. "
            "Tool results go to the blackboard for brains to interpret."
        )

    return (
        f"I keep a strict separation between thinking and acting:\n\n"
        "Cognitive brains decide what needs to happen and why. They can propose: "
        "'Call a web-search tool with this query' or 'Read that file and extract X.'\n\n"
        f"Tools (I have {tool_count}) never decide on their own; they simply execute "
        "the requests they receive.\n\n"
        "When a tool runs, its raw results are written back to the blackboard "
        "(or handed to a designated integration brain), and then my cognitive brains "
        "interpret those results, check them, and decide what to do next.\n\n"
        "In other words: my brains generate the intent and interpret the outcomes; "
        "my tools perform the concrete actions on the outside world."
    )


def _synthesize_from_drafts(
    question_text: str,
    drafts: List[Dict[str, Any]],
    tool_summaries: str,
    depth: str,
    max_sentences: int,
    target_audience: str,
) -> str:
    """Synthesize an answer from draft content."""
    if not drafts and not tool_summaries:
        return f"I'm processing this question: {question_text[:100]}..."

    # Combine relevant draft content
    draft_texts = [d.get("draft_text", "") for d in drafts if d.get("draft_text")]

    if not _synthesis_helper:
        # Without LLM, just use first draft
        if draft_texts:
            text = draft_texts[0]
            # Limit to max_sentences
            sentences = re.split(r'[.!?]\s+', text)
            return ". ".join(sentences[:max_sentences]) + "."
        return tool_summaries[:500] if tool_summaries else ""

    # Use Teacher for synthesis
    prompt = f"""Synthesize a {depth} answer to this question:

Question: {question_text}

Notes from advisors:
{chr(10).join(f'- {d[:200]}' for d in draft_texts[:3]) if draft_texts else '(none)'}

Tool results:
{tool_summaries[:300] if tool_summaries else '(none)'}

Requirements:
- Depth: {depth} (max {max_sentences} sentences)
- Answer directly and specifically
- Use Maven's voice: concise, direct, no fluff
- No excessive praise or validation

Your answer:"""

    try:
        result = _synthesis_helper.maybe_call_teacher(
            question=prompt,
            context={"mode": "per_question_synthesis", "depth": depth}
        )
        if result and result.get("answer"):
            answer = str(result["answer"]).strip()
            # Clean up
            answer = re.sub(r'^(Here\'s|Sure,|Certainly,)\s*', '', answer, flags=re.IGNORECASE)
            return answer
    except Exception:
        pass

    # Fallback
    if draft_texts:
        return draft_texts[0][:500]
    return tool_summaries[:300] if tool_summaries else ""


def _generate_closing_reflection(
    question_batch: Any,
    answers: List[PerQuestionAnswer],
) -> str:
    """
    Generate an optional closing reflection.

    This is Maven's brief meta-comment after answering all questions.
    """
    count = len(answers)

    closings = [
        f"This is how I'm designed to work across these {count} aspects.",
        "I can go deeper on any of these if you want.",
        "Let me know if you'd like more detail on any particular area.",
        "These components work together to give me coherent, evolving behavior.",
    ]

    # Pick one based on content
    if any("architecture" in a.answer_text.lower() for a in answers):
        return closings[0]
    elif count >= 3:
        return closings[1]
    else:
        return closings[3]


# =============================================================================
# Main Responder Class
# =============================================================================

class MavenResponder:
    """
    The Maven Responder brain - single authority for external voice.

    All external-facing text (to users, ChatGPT, Claude, Grok, etc.)
    must go through this brain.

    Multi-Question Behavior (Scan-First Redesign):
    - Reads question_batch from blackboard (placed by Router)
    - Mirrors the asker's structure (numbered, bulleted, prose)
    - Answers each question explicitly, in order
    - Uses depth guidance from Length & Depth Planner
    - Adds optional Maven-flavored closing

    Usage:
        responder = MavenResponder()

        # For user responses (with multi-question support)
        answer = responder.respond_to_user(blackboard)

        # For external AI conversations
        answer = responder.respond_to_ai(blackboard, target="chatgpt")

        # For explicit multi-question handling
        answer = responder.respond_multi_question(blackboard)
    """

    def __init__(self):
        self.owner_name = "maven_responder"

    def respond_to_user(
        self,
        blackboard: Blackboard,
        force_rephrase: bool = False,
        use_multi_question: bool = True,
    ) -> str:
        """
        Generate a response for the user.

        Args:
            blackboard: Blackboard with context, drafts, and tool results
            force_rephrase: Force rephrase even if similarity is low
            use_multi_question: Use multi-question synthesis if available

        Returns:
            The final response text (also written to maven_voice lane)
        """
        # Check if we should use multi-question synthesis
        if use_multi_question and _routing_engine_available:
            try:
                question_batch = get_question_batch_from_blackboard(blackboard)
                if question_batch and question_batch.count > 1:
                    return self.respond_multi_question(blackboard)
            except Exception:
                pass

        return self._generate_response(
            blackboard=blackboard,
            target_audience="user",
            force_rephrase=force_rephrase,
        )

    def respond_multi_question(
        self,
        blackboard: Blackboard,
        target_audience: str = "user",
    ) -> str:
        """
        Generate a structured response for a multi-question message.

        This uses the new scan-first, structure-mirroring behavior.

        Args:
            blackboard: Blackboard with question_batch and context
            target_audience: Who the response is for

        Returns:
            The final formatted response (also written to maven_voice lane)
        """
        # Use multi-question synthesis
        structured = synthesize_multi_question_response(blackboard, target_audience)

        # Format the response
        final_text = structured.format()

        # Sanitize output
        final_text = self._sanitize_output(final_text)

        # Write to maven_voice lane
        blackboard.add_final_answer(
            owner=self.owner_name,
            text=final_text,
            confidence=0.9,
            source_drafts=[a.question_id for a in structured.answers],
            tags=[
                f"audience:{target_audience}",
                f"questions:{structured.total_questions}",
                f"structure:{structured.structure}",
            ],
        )

        return final_text

    def respond_to_ai(
        self,
        blackboard: Blackboard,
        target: str = "chatgpt",
        force_rephrase: bool = False,
    ) -> str:
        """
        Generate a response for an external AI (ChatGPT, Claude, Grok).

        Args:
            blackboard: Blackboard with context, drafts, and tool results
            target: Target AI ("chatgpt", "claude", "grok")
            force_rephrase: Force rephrase even if similarity is low

        Returns:
            The final response text (also written to maven_voice lane)
        """
        return self._generate_response(
            blackboard=blackboard,
            target_audience=target,
            force_rephrase=force_rephrase,
        )

    def _generate_response(
        self,
        blackboard: Blackboard,
        target_audience: str,
        force_rephrase: bool,
    ) -> str:
        """Internal method to generate and record response."""
        # Gather context
        context = gather_synthesis_context(blackboard, target_audience)

        # Synthesize response
        result = synthesize_response(context, force_rephrase)

        # Sanitize output (remove any leaked internal data)
        final_text = self._sanitize_output(result.text)

        # Write to maven_voice lane (user-facing)
        blackboard.add_final_answer(
            owner=self.owner_name,
            text=final_text,
            confidence=result.confidence,
            source_drafts=result.source_drafts,
            tags=[f"audience:{target_audience}"],
        )

        return final_text

    def _sanitize_output(self, text: str) -> str:
        """
        Final sanitization pass to catch any leaked internal data.

        This is a safety net - the synthesis should already avoid
        internal data, but this catches anything that slipped through.
        """
        if not text:
            return text

        # Windows paths
        text = re.sub(r'[A-Za-z]:\\[^\s\n\r\'"]+', '[path]', text)

        # Unix paths
        text = re.sub(r'/(?:home|Users|var|tmp)/[^\s\n\r\'"]+', '[path]', text)

        # ISO timestamps
        text = re.sub(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?', '[timestamp]', text)

        # Raw dicts with internal keys
        text = re.sub(
            r"\{['\"](?:timestamp|root|file_count|session_id|page_id)['\"]:[^}]+\}",
            '[internal data]',
            text,
            flags=re.IGNORECASE
        )

        # Clean up markers
        text = re.sub(r'(\[path\]\s*)+', '[path] ', text)
        text = re.sub(r'(\[internal data\]\s*)+', '[internal data] ', text)

        return text.strip()


# =============================================================================
# Turn Logging for Learning
# =============================================================================

def log_turn_for_learning(
    blackboard: Blackboard,
    final_response: str,
    target_audience: str = "user",
) -> Dict[str, Any]:
    """
    Log a complete turn for the learning pipeline.

    Captures:
    - input: normalized user query
    - internal_notes: drafts and tool results used
    - final_output: Maven's spoken answer

    This enables:
    - Routing learning: (input -> tools used)
    - Style learning: (notes -> output) pairs
    - Memory storage: important facts

    Args:
        blackboard: The blackboard with the completed turn
        final_response: The final response that was sent
        target_audience: Who received the response

    Returns:
        The logged turn record
    """
    # Get user input
    user_input = blackboard.get_user_input() or {}

    # Get all drafts used
    draft_entries = blackboard.get_entries(lane="answer_drafts")
    drafts = [
        {
            "owner": e.owner,
            "text": e.payload.get("draft_text", str(e.payload))[:500]
            if isinstance(e.payload, dict) else str(e.payload)[:500],
        }
        for e in draft_entries
    ]

    # Get tool results
    tool_entries = blackboard.get_entries(lane="tool_results")
    tools_used = [e.owner for e in tool_entries]

    # Build turn record
    turn_record = {
        "input": {
            "original_query": user_input.get("original_query", ""),
            "normalized_text": user_input.get("normalized_text", ""),
            "intent": user_input.get("intent"),
        },
        "internal_notes": {
            "drafts": drafts,
            "tools_used": tools_used,
            "tool_count": len(tool_entries),
            "draft_count": len(draft_entries),
        },
        "final_output": {
            "text": final_response,
            "target_audience": target_audience,
        },
    }

    # Store in telemetry for learning pipeline to pick up
    blackboard.add_telemetry(
        owner="maven_responder",
        event_type="turn_complete",
        data=turn_record,
    )

    return turn_record


# =============================================================================
# Singleton & Factory
# =============================================================================

_responder_instance: Optional[MavenResponder] = None


def get_maven_responder() -> MavenResponder:
    """Get or create the singleton MavenResponder instance."""
    global _responder_instance
    if _responder_instance is None:
        _responder_instance = MavenResponder()
    return _responder_instance


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Main class
    "MavenResponder",
    "get_maven_responder",

    # Data classes
    "SynthesisContext",
    "SynthesizedResponse",
    "PerQuestionAnswer",
    "StructuredResponse",

    # Core functions
    "gather_synthesis_context",
    "synthesize_response",
    "synthesize_multi_question_response",
    "log_turn_for_learning",

    # HYBRID MAVEN: Identity repetition control
    "reset_identity_state",
    "should_include_full_identity",
    "mark_identity_explained",
    "get_identity_reminder",
    "is_explicit_identity_request",

    # Utilities
    "compute_ngram_similarity",
    "check_similarity_to_drafts",

    # Configuration
    "MAVEN_PERSONA",
    "SIMILARITY_THRESHOLD",
]
