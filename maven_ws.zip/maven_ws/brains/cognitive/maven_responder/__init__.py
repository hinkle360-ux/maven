# brains/cognitive/maven_responder/__init__.py
"""
Maven Responder Brain
=====================

The single authority for Maven's external voice.
All user-facing and external AI-facing responses must go through this brain.

Design: LLMs are advisors, Maven is the speaker.
"""

from brains.cognitive.maven_responder.service.maven_responder import (
    MavenResponder,
    get_maven_responder,
    synthesize_response,
    gather_synthesis_context,
    log_turn_for_learning,
    MAVEN_PERSONA,
)

__all__ = [
    "MavenResponder",
    "get_maven_responder",
    "synthesize_response",
    "gather_synthesis_context",
    "log_turn_for_learning",
    "MAVEN_PERSONA",
]
