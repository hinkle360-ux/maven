# brains/cognitive/self_introspection/__init__.py
"""
Self Introspection Brain
========================

Maven's brain for answering questions about itself using the SystemRegistry.
This replaces ad-hoc file scanning with structured knowledge.
"""
