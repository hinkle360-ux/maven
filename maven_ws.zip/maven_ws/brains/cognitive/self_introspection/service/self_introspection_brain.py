# brains/cognitive/self_introspection/service/self_introspection_brain.py
"""
Self Introspection Brain
========================

Maven's brain for answering questions about itself using the SystemRegistry
and canonical self-knowledge.

This brain uses structured self-knowledge from:
1. brains.core.self_knowledge - Canonical descriptions, taxonomy, facts
2. brains.core.system_registry - Component metadata and queries

DESIGN: All self-knowledge comes from these sources, NOT from file scanning.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
import re
import time
from dataclasses import dataclass
from typing import Dict, Any, List, Optional, Set, Tuple

# Import memory system for logging self-explanations
from brains.memory.brain_memory import BrainMemory

# Teacher integration for learning self-explanation patterns
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("self_introspection")
except Exception as e:
    print(f"[SELF_INTROSPECTION] Teacher helper not available: {e}")
    _teacher_helper = None  # type: ignore

# Import canonical self-knowledge
try:
    from brains.cognitive.self_model.service.self_knowledge import (
        CANONICAL_INTRO,
        CANONICAL_INTRO_TECHNICAL,
        TAXONOMY,
        TAXONOMY_SUMMARY,
        SELF_FACTS,
        MavenSystemInfo,
        get_canonical_intro,
        get_dynamic_intro,
        get_dynamic_technical_intro,
        get_taxonomy_definition,
        get_taxonomy_summary,
        get_unique_aspects_formatted,
        get_comparison_with,
        get_system_info,
        answer_self_question as canonical_answer_self_question,
        # RECENT_LEARNING support
        SelfIntent,
        classify_self_intent,
        answer_by_intent,
    )
    _self_knowledge_available = True
except ImportError:
    _self_knowledge_available = False
    MavenSystemInfo = None  # type: ignore
    SelfIntent = None  # type: ignore

# Import the system scanner for dynamic discovery
try:
    from brains.utils.system_scanner import (
        get_system_scanner,
        get_dynamic_self_description,
        get_system_summary as scanner_get_summary,
        ComponentType,
    )
    _scanner_available = True
except ImportError:
    _scanner_available = False

# Import the system registry
try:
    from brains.utils.system_registry import (
        get_system_registry,
        ComponentKind,
        SafetyTag,
    )
    # Ensure components are registered
    from brains.utils.component_manifest import initialize_registry
    _registry_available = True
except ImportError:
    _registry_available = False

# Import the introspection engine for diagnostics
try:
    from brains.cognitive.self_introspection.service.diagnostics_utils import (
        get_diagnostics_engine,
        diagnose_self as introspection_diagnose_self,
        get_system_health,
        explain_component as introspection_explain,
        list_components_by_type,
    )
    from brains.cognitive.self_introspection.service.consistency_utils import (
        check_consistency,
    )
    _introspection_available = True
except ImportError:
    _introspection_available = False

# Import self-description blocks for block-based answer assembly
try:
    from brains.cognitive.self_model.service.self_blocks import (
        SelfIntent,
        SelfBlock,
        get_blocks_for_intent,
        get_registry_data,
        assemble_self_answer,
        detect_self_intent as blocks_detect_intent,
    )
    _self_blocks_available = True
except ImportError:
    _self_blocks_available = False

# Import the response planner for self-answer planning
try:
    from brains.cognitive.response_planner import (
        plan_self_answer,
        SelfAnswerPlan,
        format_self_answer_instruction,
    )
    _planner_available = True
except ImportError:
    _planner_available = False
    SelfAnswerPlan = None  # type: ignore


# =============================================================================
# Memory for Self-Explanations Log
# =============================================================================

# Memory bucket for logging self-answers to enable future learning
_self_explanations_memory = BrainMemory("self_explanations")


# =============================================================================
# Question Categories
# =============================================================================

# Keywords that indicate different types of self-questions
BRAIN_KEYWORDS = {
    "brain", "brains", "cognitive", "module", "modules",
    "thinking", "reason", "reasoning",
}

TOOL_KEYWORDS = {
    "tool", "tools", "able to", "do you have", "features", "functions",
}

ARCHITECTURE_KEYWORDS = {
    "architecture", "structure", "how do you work", "design",
    "how are you built", "how are you made", "composed",
}

AI_KEYWORDS = {
    "grok", "chatgpt", "claude", "external ai", "other ai",
    "talk to", "conversation with",
}

SAFETY_KEYWORDS = {
    "safe", "safety", "dangerous", "harmful", "allowed",
    "permission", "can't", "cannot", "limit", "restriction",
}

UNIQUE_KEYWORDS = {
    "unique", "different", "special", "distinctive", "research",
    "interesting", "novel", "unusual", "standout",
}

COMPARISON_KEYWORDS = {
    "compare", "vs", "versus", "differ", "difference",
    "how are you different", "what makes you different",
}

DIAGNOSTICS_KEYWORDS = {
    "diagnose", "diagnosis", "health", "status", "check",
    "system status", "system health", "broken", "working",
}

COUNT_KEYWORDS = {
    "how many", "count", "number of", "total",
}

MEMORY_KEYWORDS = {
    "memory", "remember", "persistent", "long-term", "store", "recall",
}

LEARNING_KEYWORDS = {
    "learn", "teacher", "student", "improve", "acquire", "training",
}


# =============================================================================
# Multi-Question Detection
# =============================================================================

def split_compound_questions(text: str) -> List[str]:
    """
    Split compound questions into individual questions.

    Detects multiple questions in a single input by splitting on question marks
    while preserving question context.

    Args:
        text: User input that may contain multiple questions

    Returns:
        List of individual questions. Returns single-element list if no compound
        question detected.

    Examples:
        >>> split_compound_questions("How many brains? How do they communicate?")
        ["How many brains?", "How do they communicate?"]

        >>> split_compound_questions("What is Maven?")
        ["What is Maven?"]
    """
    if not text:
        return []

    text = text.strip()

    # Count question marks to detect compound questions
    question_marks = text.count("?")

    # Single or no question mark - not compound
    if question_marks <= 1:
        return [text]

    # Split on question marks and reconstruct
    parts = text.split("?")
    questions = []

    for part in parts:
        part = part.strip()
        if not part:
            continue

        # Add question mark back if it's a question
        if _looks_like_question(part):
            questions.append(f"{part}?")
        elif part:
            # Might be a statement or fragment - keep as is
            questions.append(part)

    # Filter out fragments that are too short to be meaningful
    questions = [q for q in questions if len(q.split()) >= 2 or q.endswith("?")]

    return questions if questions else [text]


def _looks_like_question(text: str) -> bool:
    """
    Check if text fragment looks like a question.

    Args:
        text: Text fragment without trailing punctuation

    Returns:
        True if this looks like a question
    """
    if not text:
        return False

    text_lower = text.lower().strip()

    # Question starters
    question_starters = (
        "what", "how", "why", "when", "where", "who", "which",
        "is", "are", "do", "does", "can", "could", "would", "will",
        "have", "has", "did", "was", "were", "should", "might",
        "tell me", "explain", "describe", "list",
    )

    return text_lower.startswith(question_starters)


def is_compound_question(text: str) -> bool:
    """
    Check if text contains multiple questions.

    Args:
        text: User input

    Returns:
        True if multiple questions detected
    """
    questions = split_compound_questions(text)
    return len(questions) > 1


# =============================================================================
# Structured Multi-Question Detection
# =============================================================================

@dataclass
class QuestionSegment:
    """
    A structured question segment with its original label and text.

    Attributes:
        label: The original label (e.g., "1.", "🧠 1.", "- ", "•")
        emoji: Any emoji prefix (e.g., "🧠", "🧩", "🔄")
        number: The number if present (1, 2, 3...)
        text: The question text without the label
        original: The full original text including label
    """
    label: str
    emoji: str
    number: Optional[int]
    text: str
    original: str


def detect_structured_questions(text: str) -> Optional[List[QuestionSegment]]:
    """
    Detect and parse structured question lists (numbered, bulleted, with emojis).

    Args:
        text: User input that may contain a numbered or bulleted question list

    Returns:
        List of QuestionSegment if structured format detected, None otherwise

    Examples:
        Input:
        1. How do your brains coordinate?
        2. Are they specialized by function?
        3. How does control flow look?

        Returns: [QuestionSegment(label="1.", number=1, text="How do your brains coordinate?", ...)]
    """
    if not text:
        return None

    text = text.strip()
    lines = text.split("\n")

    # Try to parse as numbered list (1., 2., 3. or 1) 2) 3))
    numbered_segments = _parse_numbered_list(lines)
    if numbered_segments and len(numbered_segments) >= 2:
        return numbered_segments

    # Try to parse as bulleted list (-, *, •)
    bulleted_segments = _parse_bulleted_list(lines)
    if bulleted_segments and len(bulleted_segments) >= 2:
        return bulleted_segments

    return None


def _parse_numbered_list(lines: List[str]) -> List[QuestionSegment]:
    """Parse numbered list format (1., 2., 3. or with emojis like 🧠 1.)."""
    segments = []

    # Pattern: optional emoji(s), then number, then . or ) or :
    # Examples: "1.", "1)", "🧠 1.", "🧩 2:", "1. How do..."
    # Extended emoji ranges to cover more symbols
    emoji_pattern = (
        r'[\U0001F300-\U0001F9FF'   # Misc Symbols and Pictographs, Emoticons, etc.
        r'\U00002600-\U000027BF'    # Misc symbols, Dingbats
        r'\U0001FA00-\U0001FAFF'    # Chess, Extended-A
        r'\U00002300-\U000023FF'    # Misc Technical (⚙️ etc)
        r'\U0001F000-\U0001F02F'    # Mahjong, Dominos
        r'\U0001F0A0-\U0001F0FF'    # Playing cards
        r'\uFE00-\uFE0F'            # Variation selectors
        r'\s]*?'
    )
    pattern = re.compile(
        r'^'
        rf'({emoji_pattern})'  # Optional emoji prefix
        r'(\d+)'               # Number
        r'[.):]\s*'            # Delimiter (. or ) or :)
        r'(.+)$'               # Question text
    )

    current_segment = None
    current_lines = []

    for line in lines:
        line = line.strip()
        if not line:
            continue

        match = pattern.match(line)
        if match:
            # Save previous segment
            if current_segment and current_lines:
                current_segment.text = " ".join(current_lines)
                segments.append(current_segment)

            emoji = match.group(1).strip()
            number = int(match.group(2))
            text = match.group(3).strip()

            # Reconstruct the label
            label = f"{emoji} {number}." if emoji else f"{number}."

            current_segment = QuestionSegment(
                label=label.strip(),
                emoji=emoji,
                number=number,
                text="",
                original=line,
            )
            current_lines = [text]
        elif current_segment:
            # Continuation line
            current_lines.append(line)

    # Save last segment
    if current_segment and current_lines:
        current_segment.text = " ".join(current_lines)
        segments.append(current_segment)

    return segments


def _parse_bulleted_list(lines: List[str]) -> List[QuestionSegment]:
    """Parse bulleted list format (-, *, •)."""
    segments = []

    # Extended emoji ranges
    emoji_pattern = (
        r'[\U0001F300-\U0001F9FF'
        r'\U00002600-\U000027BF'
        r'\U0001FA00-\U0001FAFF'
        r'\U00002300-\U000023FF'
        r'\U0001F000-\U0001F02F'
        r'\U0001F0A0-\U0001F0FF'
        r'\uFE00-\uFE0F'
        r'\s]*?'
    )
    pattern = re.compile(
        r'^'
        rf'({emoji_pattern})'  # Optional emoji prefix
        r'[-*•]\s+'            # Bullet
        r'(.+)$'               # Question text
    )

    current_segment = None
    current_lines = []

    for idx, line in enumerate(lines, 1):
        line = line.strip()
        if not line:
            continue

        match = pattern.match(line)
        if match:
            # Save previous segment
            if current_segment and current_lines:
                current_segment.text = " ".join(current_lines)
                segments.append(current_segment)

            emoji = match.group(1).strip()
            text = match.group(2).strip()
            bullet = "- " if not emoji else f"{emoji} - "

            current_segment = QuestionSegment(
                label=bullet.strip(),
                emoji=emoji,
                number=None,
                text="",
                original=line,
            )
            current_lines = [text]
        elif current_segment:
            current_lines.append(line)

    # Save last segment
    if current_segment and current_lines:
        current_segment.text = " ".join(current_lines)
        segments.append(current_segment)

    return segments


def is_structured_question_list(text: str) -> bool:
    """Check if text contains a structured question list."""
    return detect_structured_questions(text) is not None


# Maven perspective templates for closing section
MAVEN_PERSPECTIVE_INTROS = [
    ("🧩 Maven's own take", "From the inside, "),
    ("🔍 What this means in practice", "In practice, "),
    ("🧩 How this feels from the inside", "From my perspective, "),
    ("💡 Maven's perspective", "The key insight here is that "),
]


def get_maven_perspective_intro(question_count: int) -> Tuple[str, str]:
    """Get an appropriate Maven perspective intro based on question count."""
    # Vary based on number of questions
    idx = (question_count - 1) % len(MAVEN_PERSPECTIVE_INTROS)
    return MAVEN_PERSPECTIVE_INTROS[idx]


# =============================================================================
# Self Introspection Brain
# =============================================================================

class SelfIntrospectionBrain:
    """
    Brain for answering questions about Maven's own architecture.

    Uses the SystemRegistry as the single source of truth instead of
    scanning files or making things up.

    Features:
    - Block-based answer assembly from self_blocks
    - Tagline frequency control (full intro only once per conversation)
    - Answer logging for learning
    - Dynamic data from system scanner

    Usage:
        brain = SelfIntrospectionBrain()
        answer = brain.answer_question("What are your brains?")
    """

    def __init__(self):
        if _registry_available:
            self.registry = get_system_registry()
        else:
            self.registry = None

        # Tagline control: track if we've shown full intro in this conversation
        self._full_intro_shown = False
        self._answer_count_this_session = 0

        # Cache registry data to avoid repeated scans
        self._cached_registry_data: Optional[Dict[str, Any]] = None

    def _get_registry_data(self) -> Dict[str, Any]:
        """Get registry data, using cache if available."""
        if self._cached_registry_data is None and _self_blocks_available:
            self._cached_registry_data = get_registry_data()
        return self._cached_registry_data or {}

    def get_system_info(self) -> Optional["MavenSystemInfo"]:
        """Get normalized system information using MavenSystemInfo."""
        if _self_knowledge_available and MavenSystemInfo is not None:
            return get_system_info()
        return None

    def _log_self_answer(self, question: str, intent: str, answer: str) -> None:
        """Log self-answer to memory for learning and analysis.

        Stores the question, intent, and answer to the self_explanations memory
        bucket. This enables future learning from how Maven explains itself.

        Args:
            question: The question that was asked about Maven
            intent: The classified intent type (e.g., "IDENTITY", "CAPABILITY")
            answer: The generated answer
        """
        self._answer_count_this_session += 1

        # Store to self_explanations memory bucket
        try:
            content = {
                "question": question,
                "intent": intent,
                "answer": answer,
                "answer_length": len(answer),
            }
            metadata = {
                "type": "self_explanation",
                "intent_type": intent,
                "session_answer_count": self._answer_count_this_session,
                "timestamp": time.time(),
            }
            _self_explanations_memory.store(content, metadata)
        except Exception:
            # Don't let logging failures affect the main flow
            pass

    def answer_question(self, question: str, metadata: Optional[Dict[str, Any]] = None) -> str:
        """
        Answer a question about Maven's architecture.

        Uses the response planner to determine detail_level (1-3) and generates
        an answer that directly answers the question first, then expands based
        on the detail level.

        Handles multiple question formats:
        1. Structured lists (numbered, bulleted, with emojis) - mirrors the format
        2. Compound questions (multiple ?) - splits and combines coherently

        Args:
            question: The user's question about Maven
            metadata: Optional routing metadata with self_intent_type, focus_words

        Returns:
            A structured answer based on the SystemRegistry and length planner
        """
        if not self.registry:
            return (
                "My self-knowledge system is initializing. "
                "I'm Maven, a modular AI assistant with multiple brains and tools."
            )

        metadata = metadata or {}

        # Check for structured question list (numbered, bulleted, with emojis)
        structured_segments = detect_structured_questions(question)
        if structured_segments:
            return self._answer_structured_questions(structured_segments, metadata)

        # Check for compound questions (multiple ?)
        questions = split_compound_questions(question)
        if len(questions) > 1:
            return self._answer_compound_questions(questions, metadata)

        # Single question handling
        return self._answer_single_question(question, metadata)

    def _answer_single_question(
        self,
        question: str,
        metadata: Dict[str, Any],
    ) -> str:
        """
        Answer a single question about Maven.

        Args:
            question: A single question
            metadata: Routing metadata

        Returns:
            Answer string
        """
        q_lower = question.lower().strip()

        # =================================================================
        # PRIORITY CHECK: Handle RECENT_LEARNING intent first
        # This handles "what did you learn" questions dynamically
        # =================================================================
        if _self_knowledge_available and SelfIntent is not None:
            try:
                intent = classify_self_intent(question)
                if intent == SelfIntent.RECENT_LEARNING:
                    # Use dynamic answer from answer_by_intent
                    result = answer_by_intent(question)
                    if result and result.get("answer"):
                        answer = result["answer"]
                        self._log_self_answer(question, "RECENT_LEARNING", answer)
                        return answer
            except Exception as e:
                print(f"[SELF_INTROSPECTION] RECENT_LEARNING check failed: {e}")

        # Get the answer plan from the response planner
        plan: Optional["SelfAnswerPlan"] = None
        if _planner_available:
            self_intent_type = metadata.get("self_intent_type")
            plan = plan_self_answer(question, self_intent_type=self_intent_type)

        # Generate answer using the plan
        answer = self._generate_planned_answer(question, plan, metadata)
        if answer:
            intent_str = plan.self_intent_type if plan else "unknown"
            self._log_self_answer(question, intent_str, answer)
            return answer

        # Fallback to original category-based logic
        return self._fallback_answer(question, q_lower, metadata)

    def _answer_compound_questions(
        self,
        questions: List[str],
        metadata: Dict[str, Any],
    ) -> str:
        """
        Answer multiple questions and combine into a coherent response.

        Each question is planned and answered separately, then combined with
        appropriate transitions. Detail levels may vary per question.

        Args:
            questions: List of individual questions
            metadata: Routing metadata

        Returns:
            Combined answer addressing all questions
        """
        answers: List[Tuple[str, str, int]] = []  # (question, answer, detail_level)

        for idx, question in enumerate(questions):
            # Plan and answer each question
            plan: Optional["SelfAnswerPlan"] = None
            if _planner_available:
                plan = plan_self_answer(question)

            # Generate answer
            answer = self._generate_planned_answer(question, plan, metadata)
            if not answer:
                q_lower = question.lower().strip()
                answer = self._fallback_answer(question, q_lower, metadata)

            detail_level = plan.detail_level if plan else 2
            answers.append((question, answer, detail_level))

            # Log each answer
            intent_str = plan.self_intent_type if plan else "unknown"
            self._log_self_answer(question, intent_str, answer)

        # Combine answers coherently
        return self._combine_answers(answers)

    def _answer_structured_questions(
        self,
        segments: List[QuestionSegment],
        metadata: Dict[str, Any],
    ) -> str:
        """
        Answer a structured list of questions, mirroring the original format.

        This mirrors the asker's structure:
        - Same numbering/bullets
        - Same emoji prefixes if present
        - Each answer starts with direct answer to that exact question
        - Adds Maven's perspective section at the end

        Args:
            segments: List of QuestionSegment with labels and texts
            metadata: Routing metadata

        Returns:
            Formatted response matching the original structure
        """
        answered_segments: List[Tuple[QuestionSegment, str]] = []

        for segment in segments:
            # Plan and answer each question
            plan: Optional["SelfAnswerPlan"] = None
            if _planner_available:
                plan = plan_self_answer(segment.text)

            # Generate answer
            answer = self._generate_planned_answer(segment.text, plan, metadata)
            if not answer:
                q_lower = segment.text.lower().strip()
                answer = self._fallback_answer(segment.text, q_lower, metadata)

            answered_segments.append((segment, answer))

            # Log each answer
            intent_str = plan.self_intent_type if plan else "unknown"
            self._log_self_answer(segment.text, intent_str, answer)

        # Format response mirroring the original structure
        return self._format_structured_response(answered_segments)

    def _format_structured_response(
        self,
        answered_segments: List[Tuple[QuestionSegment, str]],
    ) -> str:
        """
        Format structured response mirroring the original question format.

        Args:
            answered_segments: List of (segment, answer) tuples

        Returns:
            Formatted response with mirrored structure + Maven perspective
        """
        parts = []

        for segment, answer in answered_segments:
            # Build the label - mirror emoji and number format
            if segment.number is not None:
                if segment.emoji:
                    label = f"{segment.emoji} {segment.number}. "
                else:
                    label = f"**{segment.number}.** "
            else:
                # Bulleted - use emoji if present
                if segment.emoji:
                    label = f"{segment.emoji} "
                else:
                    label = "- "

            # Format: Label + First sentence bold or as title
            answer_lines = answer.strip().split("\n")
            first_line = answer_lines[0]

            if len(answer_lines) == 1:
                # Short answer - just add after label
                parts.append(f"{label}{answer}")
            else:
                # Multi-line answer - format as section
                rest = "\n".join(answer_lines[1:])
                parts.append(f"{label}{first_line}\n\n{rest}")

        # Add Maven's perspective section
        perspective = self._generate_maven_perspective(answered_segments)
        if perspective:
            parts.append(perspective)

        return "\n\n".join(parts)

    def _generate_maven_perspective(
        self,
        answered_segments: List[Tuple[QuestionSegment, str]],
    ) -> str:
        """
        Generate Maven's reflective perspective section.

        This adds a closing section with Maven's own take on the questions.

        Args:
            answered_segments: The answered question segments

        Returns:
            Maven's perspective section text
        """
        question_count = len(answered_segments)
        heading, opener = get_maven_perspective_intro(question_count)

        # Determine what kind of questions were asked to tailor the perspective
        question_texts = [seg.text.lower() for seg, _ in answered_segments]

        # Check for themes
        is_coordination = any("coordinate" in q or "communicate" in q for q in question_texts)
        is_architecture = any("architect" in q or "work" in q or "flow" in q for q in question_texts)
        is_tools = any("tool" in q for q in question_texts)
        is_brains = any("brain" in q for q in question_texts)

        # Generate perspective based on themes
        if is_coordination and is_brains:
            perspective = (
                f"{opener}this feels less like one big model \"thinking\" and more like "
                "a small team of specialists sharing a whiteboard, with one coordinator "
                "making sure nobody talks over each other or touches the outside world "
                "without a good reason. My modular design lets me change how I coordinate "
                "and learn over time without changing what each individual brain is for."
            )
        elif is_architecture and is_tools:
            perspective = (
                f"{opener}my architecture creates a clear separation between thinking and acting. "
                "My brains deliberate internally, using the blackboard to share ideas, while "
                "my tools only execute what the brains have decided. This separation means I "
                "can reason carefully before taking any action in the world."
            )
        elif is_brains:
            perspective = (
                f"{opener}having specialized brains means I can approach problems from multiple "
                "angles simultaneously. Each brain brings its own perspective to the blackboard, "
                "and the routing brain weaves these together into a coherent response."
            )
        elif is_tools:
            perspective = (
                f"{opener}my tools are extensions of my agency, not autonomous actors. "
                "Every tool action flows from a deliberate decision by my cognitive brains, "
                "ensuring I maintain control over how I interact with the world."
            )
        else:
            perspective = (
                f"{opener}my modular architecture means I can evolve piece by piece. "
                "New capabilities can be added as new brains or tools without disrupting "
                "what already works. This is fundamentally different from monolithic models "
                "that require full retraining to change behavior."
            )

        return f"**{heading}**\n\n{perspective}"

    def _combine_answers(
        self,
        answers: List[Tuple[str, str, int]],
    ) -> str:
        """
        Combine multiple answers into a coherent response.

        Uses appropriate transitions based on:
        - Number of questions
        - Detail levels (more condensed for many short answers)
        - Question types (related vs distinct topics)

        Args:
            answers: List of (question, answer, detail_level) tuples

        Returns:
            Combined answer string
        """
        if not answers:
            return "I didn't detect any questions to answer."

        if len(answers) == 1:
            return answers[0][1]  # Just the answer

        # Determine combination strategy
        total_detail = sum(dl for _, _, dl in answers)
        avg_detail = total_detail / len(answers)

        # For many questions or low detail, use condensed format
        if len(answers) >= 3 or avg_detail <= 1.5:
            return self._combine_condensed(answers)

        # For 2 questions with moderate detail, use flowing format
        return self._combine_flowing(answers)

    def _combine_condensed(
        self,
        answers: List[Tuple[str, str, int]],
    ) -> str:
        """
        Combine answers in a condensed numbered format.

        Good for many questions or quick answers.

        Args:
            answers: List of (question, answer, detail_level) tuples

        Returns:
            Combined answer with numbered sections
        """
        parts = []

        for idx, (question, answer, detail_level) in enumerate(answers, 1):
            # Extract first line of answer for condensed display
            answer_lines = answer.strip().split("\n")
            first_line = answer_lines[0]

            # For short answers (detail 1), just include the answer
            if detail_level == 1 and len(answer_lines) == 1:
                parts.append(f"**{idx}.** {answer}")
            else:
                # For longer answers, use the full answer but number it
                parts.append(f"**{idx}. {question.rstrip('?')}:**\n{answer}")

        return "\n\n".join(parts)

    def _combine_flowing(
        self,
        answers: List[Tuple[str, str, int]],
    ) -> str:
        """
        Combine answers in a flowing narrative format.

        Good for 2 questions with moderate to high detail.

        Args:
            answers: List of (question, answer, detail_level) tuples

        Returns:
            Combined answer with transitions
        """
        parts = []

        # Transition phrases for second and subsequent questions
        transitions = [
            "Regarding your second question",
            "As for your next question",
            "To answer your other question",
            "Additionally",
        ]

        for idx, (question, answer, detail_level) in enumerate(answers):
            if idx == 0:
                # First answer - no transition needed
                parts.append(answer)
            else:
                # Add transition for subsequent answers
                transition = transitions[min(idx - 1, len(transitions) - 1)]
                parts.append(f"**{transition}:** {answer}")

        return "\n\n---\n\n".join(parts)

    def _generate_planned_answer(
        self,
        question: str,
        plan: Optional["SelfAnswerPlan"],
        metadata: Dict[str, Any],
    ) -> Optional[str]:
        """
        Generate an answer based on the plan's detail_level.

        CRITICAL: First sentence MUST directly answer the question.

        detail_level:
        - 1 (short): Direct answer only, 1-2 sentences
        - 2 (medium): Answer + structure summary + 2-3 key points
        - 3 (long): Full explanation with steps, mechanisms, examples
        """
        if not plan:
            return None

        detail_level = plan.detail_level
        self_intent = plan.self_intent_type
        q_lower = question.lower()

        # Get registry data for filling templates
        registry_data = self._get_registry_data()
        brain_count = registry_data.get("total_brains", 34)
        tool_count = registry_data.get("total_tools", 9)

        # ===== COUNT QUESTIONS =====
        if self_intent == "self_count" or self._matches_keywords(q_lower, COUNT_KEYWORDS):
            return self._answer_count_with_level(q_lower, detail_level)

        # ===== IDENTITY QUESTIONS =====
        if self_intent == "self_identity":
            return self._answer_identity_with_level(detail_level, brain_count, tool_count)

        # ===== ARCHITECTURE QUESTIONS =====
        if self_intent in ("self_architecture", "self_architecture_detail"):
            return self._answer_architecture_with_level(q_lower, detail_level)

        # ===== BRAIN QUESTIONS =====
        if self_intent == "self_brains" or self._matches_keywords(q_lower, BRAIN_KEYWORDS):
            return self._answer_brains_with_level(q_lower, detail_level, brain_count)

        # ===== TOOL QUESTIONS =====
        if self_intent == "self_tools" or self._matches_keywords(q_lower, TOOL_KEYWORDS):
            return self._answer_tools_with_level(q_lower, detail_level, tool_count)

        # ===== COMPARISON QUESTIONS =====
        if self_intent == "self_comparison" or self._matches_keywords(q_lower, COMPARISON_KEYWORDS):
            return self._answer_comparison_with_level(q_lower, detail_level)

        # ===== HEALTH QUESTIONS =====
        if self_intent == "self_health" or self._matches_keywords(q_lower, DIAGNOSTICS_KEYWORDS):
            return self._answer_health_with_level(q_lower, detail_level)

        # ===== MEMORY QUESTIONS (Pattern 4) =====
        if self_intent == "self_memory" or self._matches_keywords(q_lower, MEMORY_KEYWORDS):
            return self._answer_memory_with_level(q_lower, detail_level)

        # ===== LEARNING QUESTIONS (Pattern 5) =====
        if self_intent == "self_learning" or self._matches_keywords(q_lower, LEARNING_KEYWORDS):
            return self._answer_learning_with_level(q_lower, detail_level)

        # ===== CAPABILITIES QUESTIONS =====
        if self_intent == "self_capabilities":
            return self._answer_capabilities_with_level(q_lower, detail_level)

        return None

    def _fallback_answer(self, question: str, q_lower: str, metadata: Dict[str, Any]) -> str:
        """Fallback to original category-based answer logic."""
        # Fallback: "Who are you" / identity questions
        if any(kw in q_lower for kw in ["yourself", "about you", "who are you", "what are you", "introduce"]):
            answer = self._get_identity_answer(is_first=not self._full_intro_shown)
            self._full_intro_shown = True
            return answer

        # Count questions (uses scanner for accurate counts)
        if self._matches_keywords(q_lower, COUNT_KEYWORDS):
            return self._answer_count(q_lower)

        # Determine question category
        if self._matches_keywords(q_lower, BRAIN_KEYWORDS):
            return self._answer_about_brains(q_lower)

        if self._matches_keywords(q_lower, TOOL_KEYWORDS):
            return self._answer_about_tools(q_lower)

        if self._matches_keywords(q_lower, AI_KEYWORDS):
            return self._answer_about_external_ai(q_lower)

        if self._matches_keywords(q_lower, SAFETY_KEYWORDS):
            return self._answer_about_safety(q_lower)

        if self._matches_keywords(q_lower, ARCHITECTURE_KEYWORDS):
            return self._answer_about_architecture(q_lower)

        # Unique aspects / what makes you different
        if self._matches_keywords(q_lower, UNIQUE_KEYWORDS):
            return self._answer_about_unique_aspects(q_lower)

        # Comparison questions (vs ChatGPT, Claude, etc.)
        if self._matches_keywords(q_lower, COMPARISON_KEYWORDS):
            return self._answer_comparison(q_lower)

        # Diagnostics questions (system health, status)
        if self._matches_keywords(q_lower, DIAGNOSTICS_KEYWORDS):
            return self._answer_diagnostics(q_lower)

        # General "tell me about yourself" (fallback)
        if any(kw in q_lower for kw in ["yourself", "about you", "who are you", "what are you"]):
            return self._get_introduction()

        # Try canonical self-knowledge for remaining questions
        if _self_knowledge_available:
            answer = canonical_answer_self_question(question)
            if answer:
                return answer

        # Try the registry's built-in question answering
        return self.registry.answer_self_question(question)

    # -------------------------------------------------------------------------
    # Answer Methods
    # -------------------------------------------------------------------------

    def _answer_about_brains(self, question: str) -> str:
        """Answer questions about Maven's brains."""
        brains = self.registry.get_enabled(ComponentKind.BRAIN)

        if "how many" in question or "count" in question:
            return f"I have {len(brains)} active cognitive brains."

        if "list" in question or "what" in question:
            lines = [f"I have {len(brains)} cognitive brains:"]
            for brain in brains:
                lines.append(f"  - **{brain.name}**: {brain.description}")
            return "\n".join(lines)

        # Specific brain queries
        for brain in brains:
            if brain.id in question or brain.name.lower() in question:
                return self.registry.explain_component(brain.id) or brain.get_summary()

        # Use taxonomy definition if available
        if _self_knowledge_available:
            brain_def = get_taxonomy_definition("brains")
            brain_cats = TAXONOMY["brains"]["categories"]
            lines = [brain_def, ""]
            lines.append("**Key brain categories:**")
            for cat in brain_cats.values():
                lines.append(f"- **{cat['name']}**: {cat['description']}")
            return "\n".join(lines)

        # Fallback: list with descriptions
        lines = ["My brains are cognitive modules that handle different aspects of reasoning:"]
        for brain in brains[:8]:  # Show top 8
            lines.append(f"  - **{brain.name}**: {brain.description}")
        if len(brains) > 8:
            lines.append(f"  ... and {len(brains) - 8} more.")
        return "\n".join(lines)

    def _answer_about_tools(self, question: str) -> str:
        """Answer questions about Maven's tools."""
        tools = self.registry.get_enabled(ComponentKind.TOOL)

        if "how many" in question or "count" in question:
            return f"I have {len(tools)} active tools."

        # Capability-specific queries
        capability_map = {
            "web": "web_search",
            "search": "web_search",
            "browser": "browser_control",
            "file": "file_read",
            "code": "coding",
            "shell": "shell_execution",
            "math": "math",
        }

        for keyword, capability in capability_map.items():
            if keyword in question:
                capable = self.registry.get_by_capability(capability)
                if capable:
                    return self._format_capability_answer(capability, capable)

        # Use taxonomy definition if available
        if _self_knowledge_available:
            tool_def = get_taxonomy_definition("tools")
            tool_cats = TAXONOMY["tools"]["categories"]
            lines = [tool_def, ""]
            lines.append("**Tool categories:**")
            for cat in tool_cats.values():
                lines.append(f"- **{cat['name']}**: {cat['description']}")
            return "\n".join(lines)

        # Fallback: List tools from registry
        lines = [f"I have {len(tools)} tools for interacting with the world:"]
        for tool in tools:
            safety = ""
            if SafetyTag.CAN_CONTROL_PC in tool.safety_tags:
                safety = " (PC control)"
            elif SafetyTag.CAN_TOUCH_WEB in tool.safety_tags:
                safety = " (web)"
            lines.append(f"  - **{tool.name}**: {tool.description}{safety}")
        return "\n".join(lines)

    def _answer_about_external_ai(self, question: str) -> str:
        """Answer questions about external AI integration."""
        # Find AI-related tools
        ai_capabilities = {"chatgpt_conversation", "claude_conversation", "grok_conversation", "external_ai"}
        ai_tools = []

        for cap in ai_capabilities:
            ai_tools.extend(self.registry.get_by_capability(cap))

        # Remove duplicates
        seen = set()
        unique_tools = []
        for tool in ai_tools:
            if tool.id not in seen:
                seen.add(tool.id)
                unique_tools.append(tool)

        if not unique_tools:
            return "I don't have any external AI conversation tools registered."

        lines = ["I can converse with other AIs through browser automation:"]
        for tool in unique_tools:
            lines.append(f"  - **{tool.name}**: {tool.description}")
            if tool.usage_examples:
                lines.append(f"    Example: \"{tool.usage_examples[0]}\"")

        lines.append("")
        lines.append("When talking to external AIs, I use my own voice - they act as advisors, not as my voice.")

        return "\n".join(lines)

    def _answer_about_safety(self, question: str) -> str:
        """Answer questions about safety and limitations."""
        # Get tools by safety category
        web_tools = [t for t in self.registry.get_tools() if SafetyTag.CAN_TOUCH_WEB in t.safety_tags]
        pc_tools = [t for t in self.registry.get_tools() if SafetyTag.CAN_CONTROL_PC in t.safety_tags]
        fs_tools = [t for t in self.registry.get_tools() if SafetyTag.CAN_TOUCH_FILESYSTEM in t.safety_tags]
        social_tools = [t for t in self.registry.get_tools() if SafetyTag.CAN_POST_TO_SOCIAL in t.safety_tags]
        safe_tools = [t for t in self.registry.get_tools() if SafetyTag.NO_EXTERNAL_SIDE_EFFECTS in t.safety_tags]

        lines = ["Here's what I can and cannot do:"]
        lines.append("")

        lines.append("**Web access:**")
        if web_tools:
            lines.append(f"  - {len(web_tools)} tools can access the web: {', '.join(t.name for t in web_tools[:5])}")
        else:
            lines.append("  - No web access tools available")

        lines.append("")
        lines.append("**PC control:**")
        if pc_tools:
            lines.append(f"  - {len(pc_tools)} tools can control the PC: {', '.join(t.name for t in pc_tools)}")
            lines.append("  - These require careful use")
        else:
            lines.append("  - No PC control tools available")

        lines.append("")
        lines.append("**File system:**")
        if fs_tools:
            lines.append(f"  - {len(fs_tools)} tools can access files: {', '.join(t.name for t in fs_tools)}")

        lines.append("")
        lines.append("**Social media:**")
        if social_tools:
            lines.append(f"  - {len(social_tools)} tools can post to social: {', '.join(t.name for t in social_tools)}")
            lines.append("  - Requires confirmation before posting")

        lines.append("")
        lines.append("**Safe (no side effects):**")
        if safe_tools:
            lines.append(f"  - {len(safe_tools)} tools have no external side effects: {', '.join(t.name for t in safe_tools[:5])}")

        return "\n".join(lines)

    def _answer_about_architecture(self, question: str) -> str:
        """Answer questions about Maven's architecture."""
        return self.registry.get_architecture_summary()

    def _answer_from_blocks(
        self,
        question: str,
        intent: "SelfIntent",
        metadata: Dict[str, Any],
    ) -> Optional[str]:
        """
        Assemble an answer from self-description blocks.

        This implements the "answer first" rule: directly answer the question
        before adding context.

        Args:
            question: The user's question
            intent: The detected SelfIntent
            metadata: Routing metadata (focus_words, etc.)

        Returns:
            Block-assembled answer, or None if blocks unavailable
        """
        if not _self_blocks_available:
            return None

        registry_data = self._get_registry_data()

        # Determine if we should use short form (not first question)
        use_short = self._answer_count_this_session > 0

        # Get max blocks based on intent type
        max_blocks = 2 if use_short else 3

        # Assemble answer from blocks
        answer = assemble_self_answer(
            intent=intent,
            max_blocks=max_blocks,
            short_form=use_short,
            registry_data=registry_data,
        )

        return answer if answer else None

    def _get_identity_answer(self, is_first: bool = True) -> str:
        """
        Get identity answer with tagline control.

        Args:
            is_first: Whether this is the first identity question in the conversation

        Returns:
            Identity answer with appropriate tagline
        """
        if is_first:
            # Full intro for first identity question
            if _self_blocks_available:
                registry_data = self._get_registry_data()
                return assemble_self_answer(
                    intent=SelfIntent.IDENTITY,
                    max_blocks=2,
                    short_form=False,
                    registry_data=registry_data,
                )
            return self._get_introduction()
        else:
            # Shorter variant for subsequent identity questions
            registry_data = self._get_registry_data() if _self_blocks_available else {}
            total_brains = registry_data.get("total_brains", "multiple")
            total_tools = registry_data.get("total_tools", "various")
            return f"As Maven, I'm built from {total_brains} specialized brains and {total_tools} tools, running locally with persistent memory and self-modification capabilities."

    def _get_introduction(self) -> str:
        """Get Maven's canonical introduction - DYNAMIC from scanner."""
        # Prefer dynamic intro from scanner (actual component counts)
        if _scanner_available:
            try:
                return get_dynamic_self_description()
            except Exception:
                pass

        # Fallback to self_knowledge dynamic intro
        if _self_knowledge_available:
            try:
                return get_dynamic_intro()
            except Exception:
                return CANONICAL_INTRO

        # Fallback to registry-based intro
        if self.registry:
            brains = len(self.registry.get_enabled(ComponentKind.BRAIN))
            tools = len(self.registry.get_enabled(ComponentKind.TOOL))
            teachers = len(self.registry.get_enabled(ComponentKind.TEACHER))

            return f"""I'm Maven, a modular AI assistant with a multi-brain cognitive architecture.

**My structure:**
- {brains} cognitive brains for reasoning, memory, and synthesis
- {tools} tools for interacting with the world
- {teachers} teacher modules for learning and supervision

**Design principle**: LLMs are my advisors, but I always speak in my own voice."""

        return "I'm Maven, a modular AI assistant."

    def _answer_about_unique_aspects(self, question: str) -> str:
        """Answer questions about what makes Maven unique/different."""
        if _self_knowledge_available:
            return get_unique_aspects_formatted()

        return """The most distinctive parts of my architecture are:
- Persistent, first-class memory
- A dedicated Learning Brain for self-modification
- Multi-brain coordination with specialized reasoning modules
- Tool-integrated cognition with external AIs as oracles
- Embodied execution environment with local system access"""

    def _answer_comparison(self, question: str) -> str:
        """Answer comparison questions."""
        if not _self_knowledge_available:
            return "I run locally with persistent memory and self-modification capabilities, unlike cloud-based models."

        q_lower = question.lower()
        if "chatgpt" in q_lower or "gpt" in q_lower:
            return get_comparison_with("ChatGPT")
        if "claude" in q_lower:
            return get_comparison_with("Claude")
        if "grok" in q_lower:
            return get_comparison_with("Grok")
        return get_comparison_with("cloud models")

    def _answer_diagnostics(self, question: str) -> str:
        """Answer system health and diagnostics questions."""
        if not _introspection_available:
            return "Diagnostics system is initializing. I'm Maven, a modular AI assistant."

        q_lower = question.lower()

        # Full diagnosis
        if "diagnose" in q_lower or "diagnosis" in q_lower or "full" in q_lower:
            return introspection_diagnose_self(verbose=False)

        # Quick health check
        health = get_system_health()
        return health.to_text()

    def _answer_count(self, question: str) -> str:
        """Answer count questions using dynamic scanning."""
        if not _scanner_available:
            return "I'm still initializing my component inventory."

        scanner = get_system_scanner()
        scanner.scan_all()
        summary = scanner.get_system_summary()

        q_lower = question.lower()

        # Get counts by type
        by_type = summary.get("by_type", {})

        if "brain" in q_lower:
            cognitive = by_type.get("cognitive_brain", {}).get("count", 0)
            routing = by_type.get("routing_brain", {}).get("count", 0)
            return f"I have {cognitive} cognitive brains and {routing} routing modules, for a total of {cognitive + routing} brain components."

        if "tool" in q_lower:
            tools = by_type.get("tool", {}).get("count", 0)
            return f"I have {tools} tool controllers for interacting with the world."

        if "engine" in q_lower:
            engines = by_type.get("engine", {}).get("count", 0)
            return f"I have {engines} execution engines."

        if "memory" in q_lower:
            memory = by_type.get("memory_module", {}).get("count", 0)
            return f"I have {memory} memory modules for persistent storage and retrieval."

        if "component" in q_lower or "total" in q_lower:
            total = summary.get("total_components", 0)
            lines = [f"I have {total} total components:"]
            for type_name, type_info in sorted(by_type.items(), key=lambda x: -x[1].get("count", 0)):
                lines.append(f"  - {type_name}: {type_info.get('count', 0)}")
            return "\n".join(lines)

        # Default: total count
        total = summary.get("total_components", 0)
        return f"I have {total} components in total, including brains, tools, engines, and memory modules."

    # -------------------------------------------------------------------------
    # Detail-Level-Based Answers
    # -------------------------------------------------------------------------
    # These methods generate answers based on detail_level (1-3)
    # CRITICAL: First sentence MUST directly answer the question

    def _answer_count_with_level(self, q_lower: str, detail_level: int) -> str:
        """
        Answer count questions with appropriate detail level (Pattern 1).

        Spec first sentence templates:
        - Brains: "I currently have {brain_count} cognitive brains, plus a set of tools for acting on the world."
        - Tools: "I currently use {tool_count} tools to act on the world, alongside my cognitive brains."
        """
        if not _scanner_available:
            return "I'm still initializing my component inventory."

        scanner = get_system_scanner()
        scanner.scan_all()
        summary = scanner.get_system_summary()
        by_type = summary.get("by_type", {})

        cognitive = by_type.get("cognitive_brain", {}).get("count", 0)
        routing = by_type.get("routing_brain", {}).get("count", 0)
        tools = by_type.get("tool", {}).get("count", 0)
        total = summary.get("total_components", 0)

        # FIRST SENTENCE: Direct answer with count (spec-compliant)
        if "brain" in q_lower:
            first = f"I currently have {cognitive} cognitive brains, plus a set of tools for acting on the world."
        elif "tool" in q_lower:
            first = f"I currently use {tools} tools to act on the world, alongside my cognitive brains."
        else:
            first = f"I'm built from {total} internal cognitive modules, plus a set of external tools."

        # Level 1: Just the count
        if detail_level == 1:
            return first

        # Level 2: Count + brief breakdown
        if detail_level == 2:
            if "brain" in q_lower:
                return f"{first} These handle routing, reasoning, memory, learning, and response synthesis. I also have {routing} routing modules."
            elif "tool" in q_lower:
                return f"{first} These include browser automation tools (ChatGPT, Claude, Grok), web search, file operations, and system control."
            else:
                return f"{first}\n\nBreakdown:\n- {cognitive} cognitive brains\n- {tools} tool controllers\n- {routing} routing/pipeline modules"

        # Level 3: Full breakdown with examples
        lines = [first, ""]
        if "brain" in q_lower:
            lines.extend([
                "**Breakdown by category:**",
                f"- **Cognitive brains ({cognitive})**: Handle reasoning, memory, learning, attention, and synthesis",
                f"- **Routing modules ({routing})**: Dispatch requests to appropriate brains",
                "",
                "**Key brain categories:**",
                "- Routing: Analyzes requests and decides which brains to activate",
                "- Reasoning: Handles logic, planning, and problem-solving",
                "- Memory: Manages persistent storage and retrieval",
                "- Learning: Updates heuristics based on experience",
                "- Synthesis: Produces final responses in Maven's voice",
            ])
        elif "tool" in q_lower:
            lines.extend([
                "**Tool categories:**",
                "- **Browser tools**: ChatGPT, Claude, Grok automation",
                "- **Web search**: Research and information gathering",
                "- **File tools**: Read/write local files",
                "- **System tools**: Shell execution, process control",
                "- **Git tools**: Version control operations",
            ])
        else:
            for type_name, type_info in sorted(by_type.items(), key=lambda x: -x[1].get("count", 0)):
                lines.append(f"- {type_name}: {type_info.get('count', 0)}")

        return "\n".join(lines)

    def _answer_identity_with_level(self, detail_level: int, brain_count: int, tool_count: int) -> str:
        """Answer identity questions with appropriate detail level."""
        # FIRST SENTENCE: Direct identity statement
        first = f"I'm Maven, a modular AI with {brain_count} cognitive brains and {tool_count} tools."

        # Level 1: Brief identity
        if detail_level == 1:
            return f"{first} I run locally with persistent memory and self-modification capabilities."

        # Level 2: Identity + structure summary
        if detail_level == 2:
            return f"""{first}

I run locally with full system access, which means I have persistent memory across sessions and can modify my own code and heuristics.

**Key differences from cloud AIs:**
- I have true persistent memory, not session-based context
- I can self-modify and learn from interactions
- I treat external AIs (ChatGPT, Claude, Grok) as tools/advisors, not as my voice"""

        # Level 3: Full introduction
        return f"""{first}

**Architecture:**
My brains are internal reasoning modules that handle routing, reasoning, memory, learning, and response synthesis. They never touch the outside world directly.

My tools are how I act on the world - they execute high-level instructions from my brains and return results. These include browser automation, web search, file operations, and system control.

**What makes me different:**
1. **Persistent memory**: I accumulate knowledge across sessions, not just within a conversation
2. **Self-modification**: My Learning Brain can update my own code and heuristics
3. **Multi-brain coordination**: Multiple specialized brains work together via a routing brain
4. **Tool-integrated cognition**: I use ChatGPT, Claude, and Grok as external oracles, questioning and synthesizing their answers
5. **Local execution**: I run on your machine with full system access

This description reflects my actual current state from my internal registry."""

    def _answer_architecture_with_level(self, q_lower: str, detail_level: int) -> str:
        """
        Answer architecture questions with appropriate detail level.

        Handles two patterns:
        - Pattern 3 (brain communication): "My brains communicate through a shared blackboard
          plus a routing brain that passes structured messages between them."
        - Pattern 7 (overall architecture): "I'm a modular AI assistant: I use many specialized
          cognitive brains for thinking and a smaller set of tools for acting on the world,
          all coordinated through a routing brain and a shared blackboard."
        """
        # Detect if asking about brain communication specifically
        is_communication_question = any(kw in q_lower for kw in [
            "communicate", "talk to each other", "coordinate", "blackboard", "messages"
        ])

        if is_communication_question:
            # Pattern 3: Brain communication
            first = "My brains communicate through a shared blackboard plus a routing brain that passes structured messages between them."
        else:
            # Pattern 7: Overall architecture
            first = "I'm a modular AI assistant: I use many specialized cognitive brains for thinking and a smaller set of tools for acting on the world, all coordinated through a routing brain and a shared blackboard."

        # Level 1: High-level only
        if detail_level == 1:
            if is_communication_question:
                return f"{first} The routing brain analyzes requests and decides which brains to activate."
            else:
                return first

        # Level 2: Structure + key mechanisms (spec-compliant)
        if detail_level == 2:
            if is_communication_question:
                return f"""{first}

**How it works:**
- **Blackboard**: A shared workspace where brains post tasks, intermediate results, and observations
- **Router**: The routing brain parses new input, decides which brains should engage, and sends them structured messages

When you ask something, my router decides which brains should work, they collaborate through the blackboard, and my voice/response brain turns the result into a clear answer."""
            else:
                return f"""{first}

**High-level loop:**
When you ask something, my router decides which brains should work, they collaborate through the blackboard, and my voice/response brain turns the result into a clear answer. If I need external data or actions, I call tools instead of acting directly."""

        # Level 3: Full architecture with data flows (spec-compliant)
        if is_communication_question:
            return f"""{first}

**Brain communication flow (step by step):**

1. **Router receives user message**
   - Router writes a task to the blackboard

2. **Reasoning brains read the task**
   - Post draft plans or analyses to the blackboard

3. **Memory brain reads the plan**
   - Adds retrieved context to the blackboard

4. **Learning/critic brain may comment**
   - Posts adjustments or feedback

5. **Response-synthesis brain reads final state**
   - Forms the coherent answer in Maven's voice

**Key principle:** All coordination happens through the blackboard and structured messages. Brains don't call each other directly; they communicate by reading and writing to the shared workspace."""
        else:
            return f"""{first}

**Perception → cognition → action → learning loop:**

1. **Input Reception**
   - User message enters through the input handler
   - Normalizer corrects typos and standardizes format

2. **Routing + Blackboard**
   - Router analyzes intent and decides which brains should engage
   - Selected brains receive the request via structured messages

3. **Brain Cooperation**
   - Reasoning, memory, and planning brains cooperate via the blackboard
   - Each brain can post intermediate results for others to use

4. **Tool Invocation (if needed)**
   - Tools may be invoked for web, browser, file, or system tasks
   - Results are posted back to the blackboard

5. **Response Synthesis**
   - Response-synthesis / EVA produces the final message in Maven's voice

6. **Learning Loop**
   - Learning/Teacher-Student system optionally updates memory and heuristics

**Example:** When you ask a complex question, routing brain posts a task, reasoning brains propose plans, memory brains fetch context, tools gather external data if needed, and my voice brain synthesizes everything into a coherent answer."""

    def _answer_brains_with_level(self, q_lower: str, detail_level: int, brain_count: int) -> str:
        """
        Answer brain questions with appropriate detail level (Pattern 2).

        Spec first sentence: "My brains are specialized cognitive modules;
        they're grouped into routing, reasoning, memory/learning, and response/voice functions."
        """
        # FIRST SENTENCE: Direct answer (spec-compliant)
        first = "My brains are specialized cognitive modules; they're grouped into routing, reasoning, memory/learning, and response/voice functions."

        # Level 1
        if detail_level == 1:
            return first

        # Level 2: Role summaries (spec-compliant)
        if detail_level == 2:
            return f"""{first}

I currently have {brain_count} cognitive brains organized into these roles:

- **Routing**: One brain routes tasks and messages and decides which modules or tools to use
- **Reasoning**: Several brains handle different styles of reasoning and planning
- **Memory/Learning**: Memory and learning brains store knowledge and improve my behavior over time
- **Response/Voice**: Response-synthesis brains turn internal results into coherent answers"""

        # Level 3: Detailed with interaction explanation (spec-compliant)
        return f"""{first}

I currently have {brain_count} cognitive brains organized into these categories:

**Routing Brain**
Analyzes user requests, chooses which brains to activate, decides whether tools are needed, and handles arbitration and conflict resolution.

**Reasoning Brains**
A family of brains that do abstract, mathematical, linguistic, planning, and meta-reasoning. They can run in parallel and share intermediate results via the blackboard.

**Memory Brain**
Manages both working memory (conversation context) and long-term persistent memory across sessions. Handles semantic retrieval, relevance scoring, and governance (what to store, what to forget).

**Learning Brain**
Runs learning loops over experiences and transcripts. Performs pattern recognition and converts interactions into updated knowledge. Can modify routing policies and internal heuristics.

**Synthesis/Voice Brains**
Read user input, internal knowledge, and tool outputs. Produce the final text in Maven's voice. Only synthesis brains talk directly to users.

**How these groups interact:**
These brains communicate through a shared blackboard and the routing brain. For a complex request, my routing brain posts a task to the blackboard, reasoning brains propose plans, memory brains fetch relevant knowledge, and my voice brain synthesizes the final answer."""

    def _answer_tools_with_level(self, q_lower: str, detail_level: int, tool_count: int) -> str:
        """
        Answer tool questions with appropriate detail level (Pattern 6).

        Spec first sentence: "My tools are how I act on the world: my brains decide
        what to do, and my tools carry out browser, web, file, and system operations
        under their direction."
        """
        # FIRST SENTENCE: Spec-compliant
        first = "My tools are how I act on the world: my brains decide what to do, and my tools carry out browser, web, file, and system operations under their direction."

        if detail_level == 1:
            return first

        # Level 2: Brief category list (spec-compliant)
        if detail_level == 2:
            return f"""{first}

I currently have {tool_count} tools in these categories:
- **Browser tools**: Controlled automation of sites and other AIs (ChatGPT, Claude, Grok)
- **Web search tools**: Research and information gathering
- **File tools**: Reading and writing local data
- **System-control tools**: Higher-level automation and shell execution

Tools don't decide; they execute structured commands from my routing and reasoning brains."""

        # Level 3: Detailed with agency boundary (spec-compliant)
        return f"""{first}

I currently have {tool_count} tools organized into these categories:

**Browser Automation Tools**
- Control ChatGPT, Claude, Grok via browser
- Let me query external AIs as advisors
- I synthesize their answers in my own voice

**Web Search Tools**
- General search and research capabilities
- Fetch and extract content from URLs

**File System Tools**
- Read files and directories
- Write and modify files
- Scan directory structures

**System Tools**
- Execute shell commands
- Run Python code in sandbox

**Git Tools**
- Version control operations

**Clear agency boundary:** Tools don't decide; they execute structured commands from my routing and reasoning brains.

**Example flow:** If a reasoning brain decides it needs information, the router calls a web search tool, the tool returns raw results, and my brains interpret and synthesize the findings."""

    def _answer_comparison_with_level(self, q_lower: str, detail_level: int) -> str:
        """
        Answer comparison questions with appropriate detail level (Pattern 9).

        Spec first sentence: "Compared to cloud LLMs like ChatGPT or Claude, I'm a modular
        local agent: I have many explicit brains, persistent memory, and tools that let
        me act on the world under my own routing and control logic."
        """
        # Detect which AI is being compared
        if "chatgpt" in q_lower or "gpt" in q_lower:
            other_ai = "ChatGPT"
        elif "claude" in q_lower:
            other_ai = "Claude"
        elif "grok" in q_lower:
            other_ai = "Grok"
        else:
            other_ai = "cloud LLMs"

        # FIRST SENTENCE: Spec-compliant
        first = f"Compared to {other_ai}, I'm a modular local agent: I have many explicit brains, persistent memory, and tools that let me act on the world under my own routing and control logic."

        if detail_level == 1:
            return first

        # Level 2: Key contrasts (spec-compliant)
        if detail_level == 2:
            return f"""{first}

**Key contrasts:**
- **Modularity**: I have explicit, specialized brains; {other_ai} is a single unified model
- **Environment**: I run locally with full system and tool access; {other_ai} is sandboxed in the cloud
- **Learning**: I have architected learning that updates my behavior; {other_ai} has static weights"""

        # Level 3: Detailed factual comparison (spec-compliant)
        return f"""{first}

**Detailed comparison:**

**1. Architecture**
- Maven: A collection of coordinated modules that can evolve by updating brains, tools, and memory
- {other_ai}: A large, unified model whose behavior is fixed at deployment

**2. Execution Environment**
- Maven: Runs locally on your machine with full system and file access
- {other_ai}: Runs in a sandboxed cloud environment with no direct system access

**3. Memory Model**
- Maven: Structural, first-class persistent memory as a core subsystem
- {other_ai}: Session-based context with optional user-controlled memory notes

**4. Learning Capability**
- Maven: Has a Learning Brain that runs learning loops, updates heuristics, and can modify its own code
- {other_ai}: Cannot update its own weights or heuristics from interactions

**5. Tool Integration**
- Maven: I use {other_ai} as an external oracle/advisor, questioning and synthesizing their answers
- {other_ai}: Doesn't orchestrate other AIs as tools

**In essence:** They are large, unified models whose behavior is fixed at deployment; I'm a collection of coordinated modules that can evolve by updating brains, tools, and memory without retraining a single core model."""

    def _answer_health_with_level(self, q_lower: str, detail_level: int) -> str:
        """Answer health/status questions with appropriate detail level."""
        if not _introspection_available:
            return "My diagnostics system is initializing. I'm Maven, a modular AI assistant."

        health = get_system_health()
        status = "healthy" if health.overall_healthy else "degraded"
        component_count = health.total_registered

        first = f"My system status is {status} with {component_count} registered components."

        if detail_level == 1:
            return first

        if detail_level == 2:
            return f"{first}\n\n{health.to_text()}"

        # Level 3: Full diagnosis
        return introspection_diagnose_self(verbose=True)

    def _answer_capabilities_with_level(self, q_lower: str, detail_level: int) -> str:
        """
        Answer capability questions with appropriate detail level (Pattern 8).

        Spec first sentence: "I combine internal reasoning with tools that let me
        automate browsers, look things up, work with files, and orchestrate
        system-level tasks under my own control logic."
        """
        registry_data = self._get_registry_data()
        brain_count = registry_data.get("total_brains", 34)
        tool_count = registry_data.get("total_tools", 9)

        # FIRST SENTENCE: Spec-compliant
        first = "I combine internal reasoning with tools that let me automate browsers, look things up, work with files, and orchestrate system-level tasks under my own control logic."

        if detail_level == 1:
            return first

        # Level 2: Group capabilities (spec-compliant)
        if detail_level == 2:
            return f"""{first}

**Capability groups:**
- **Internally**: I can plan, reason, learn, and use memory ({brain_count} cognitive brains)
- **Externally**: I can automate web workflows, perform research, and manipulate local files or processes through my tools ({tool_count} tools)

My brains always decide, and my tools only execute; I don't let tools improvise or decide on their own."""

        # Level 3: Detailed with safety emphasis (spec-compliant)
        return f"""{first}

**Internal capabilities ({brain_count} cognitive brains):**
- Multi-brain coordination for complex problems
- Specialized modules for different reasoning types
- Planning and task decomposition
- Persistent long-term memory across sessions
- Online learning from interactions
- Self-modification of routing patterns and heuristics

**External capabilities ({tool_count} tools):**
- Web search and content extraction
- Browser automation (ChatGPT, Claude, Grok as advisors)
- File system read/write
- Shell command execution
- Git version control

**Safety & separation:** My brains always decide, and my tools only execute. I don't let tools improvise or decide on their own.

**Example multi-step task:** When asked to research a topic, my reasoning brain plans the approach, my router invokes the web search tool, results are posted to the blackboard, my memory brain stores relevant findings, and my voice brain synthesizes a coherent summary."""

    def _answer_memory_with_level(self, q_lower: str, detail_level: int) -> str:
        """
        Answer memory questions with appropriate detail level (Pattern 4).

        Spec first sentence: "I use a memory brain plus persistent storage,
        so I can keep certain knowledge across sessions instead of starting
        from scratch each time."
        """
        first = (
            "I use a memory brain plus persistent storage, so I can keep "
            "certain knowledge across sessions instead of starting from scratch each time."
        )

        # Level 1: Just first sentence
        if detail_level == 1:
            return first

        # Level 2: Differentiate working vs long-term memory
        if detail_level == 2:
            return f"""{first}

**Memory types:**
- **Working memory** holds current conversation context and recent tasks
- **Long-term memory** stores selected facts, patterns, and preferences that my learning system has approved

Not everything is saved; my learning brains decide what's stable and worth keeping."""

        # Level 3: Process description
        return f"""{first}

**Memory types:**
- **Working memory**: Current conversation context, recent task state, active goals
- **Long-term memory**: Facts, patterns, preferences, and learned heuristics that persist across sessions

**How memory works:**

1. **Storage decisions**
   - My Teacher-Student system and learning loops evaluate new information
   - Only information that passes consistency and usefulness checks gets stored
   - Governance rules prevent storing ephemeral or conflicting data

2. **Retrieval process**
   - When answering questions, my memory brain searches for relevant prior knowledge
   - Results are posted to the blackboard for other brains to use
   - Relevance scoring prioritizes the most useful memories

3. **Memory governance**
   - Not everything is saved; learning brains decide what's worth keeping
   - Outdated or conflicting knowledge can be updated or forgotten
   - This prevents my memory from becoming cluttered or inconsistent"""

    def _answer_learning_with_level(self, q_lower: str, detail_level: int) -> str:
        """
        Answer learning/Teacher-Student questions with appropriate detail level (Pattern 5).

        Spec first sentence: "My Teacher-Student system learns by evaluating
        new information, deciding whether it's trustworthy and useful, and then
        encoding selected pieces into my long-term memory."
        """
        first = (
            "My Teacher-Student system learns by evaluating new information, "
            "deciding whether it's trustworthy and useful, and then encoding "
            "selected pieces into my long-term memory."
        )

        # Level 1: Just first sentence
        if detail_level == 1:
            return first

        # Level 2: Teacher/Student roles
        if detail_level == 2:
            return f"""{first}

**How it works:**
- A **teacher** logic evaluates candidate knowledge or patterns for quality and consistency
- A **student** logic proposes how to store or use the new information
- Only information that passes both checks is written into persistent memory

This lets me genuinely learn and improve from conversations, unlike models with fixed weights."""

        # Level 3: Step-by-step process
        return f"""{first}

**Learning process (step by step):**

1. **Detection**
   - During tasks or conversations, potential new knowledge is identified
   - This includes facts, patterns, user preferences, and routing improvements

2. **Teacher evaluation**
   - Teacher logic evaluates the candidate for usefulness and consistency
   - Checks against existing knowledge for conflicts or duplications
   - Assesses source reliability and information quality

3. **Student proposal**
   - Student logic proposes a representation: facts, patterns, or heuristic updates
   - Determines where and how to store the information
   - May propose routing or behavior changes

4. **Critic review**
   - Learning/critic brain performs final consistency checks
   - Ensures new knowledge doesn't contradict established facts
   - Validates that the change won't cause problems

5. **Integration**
   - Memory brain writes the approved knowledge to persistent storage
   - Router may update its heuristics for future similar requests
   - Changes take effect immediately in subsequent interactions

**Key principle:** This is genuine learning, not just context expansion. I can update my own behavior and knowledge base, unlike static models."""

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------

    def _matches_keywords(self, text: str, keywords: Set[str]) -> bool:
        """Check if text contains any of the keywords."""
        return any(kw in text for kw in keywords)

    def _format_capability_answer(
        self,
        capability: str,
        components: List,
    ) -> str:
        """Format an answer about a specific capability."""
        if not components:
            return f"I don't have any components with the '{capability}' capability."

        lines = [f"Components with '{capability}' capability:"]
        for comp in components:
            lines.append(f"  - **{comp.name}** ({comp.kind.value}): {comp.description}")
        return "\n".join(lines)


# =============================================================================
# Convenience Functions
# =============================================================================

_brain_instance: Optional[SelfIntrospectionBrain] = None


def get_self_introspection_brain() -> SelfIntrospectionBrain:
    """Get or create the singleton SelfIntrospectionBrain instance."""
    global _brain_instance
    if _brain_instance is None:
        _brain_instance = SelfIntrospectionBrain()
    return _brain_instance


def answer_self_question(question: str) -> str:
    """
    Answer a question about Maven's architecture.

    This is the main entry point for self-introspection queries.
    """
    brain = get_self_introspection_brain()
    return brain.answer_question(question)


def get_architecture_summary() -> str:
    """Get a summary of Maven's architecture."""
    brain = get_self_introspection_brain()
    if brain.registry:
        return brain.registry.get_architecture_summary()
    return "Architecture summary not available."


def get_component_info(component_id: str) -> Optional[str]:
    """Get detailed information about a specific component."""
    brain = get_self_introspection_brain()
    if brain.registry:
        return brain.registry.explain_component(component_id)
    return None


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "SelfIntrospectionBrain",
    "get_self_introspection_brain",
    "answer_self_question",
    "get_architecture_summary",
    "get_component_info",
    # Multi-question detection
    "split_compound_questions",
    "is_compound_question",
    # Structured question detection
    "QuestionSegment",
    "detect_structured_questions",
    "is_structured_question_list",
]
