# brains/core/introspection/consistency.py
"""
Consistency Checker
===================

Cross-checks the static registry, dynamic scanner, and runtime availability
to detect:
- Components in filesystem but not registered
- Components registered but missing from filesystem
- Components that exist but can't be imported (broken)
- Capability gaps and coverage analysis

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
import importlib
from pathlib import Path
from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional, Any, Tuple
from enum import Enum


class ComponentStatus(str, Enum):
    """Status of a component."""
    REGISTERED_AND_FOUND = "registered_and_found"
    REGISTERED_NOT_FOUND = "registered_not_found"
    FOUND_NOT_REGISTERED = "found_not_registered"
    IMPORT_ERROR = "import_error"
    HEALTHY = "healthy"


@dataclass
class ComponentHealth:
    """Health status of a single component."""
    id: str
    name: str
    status: ComponentStatus
    registry_entry: bool = False
    filesystem_found: bool = False
    importable: bool = False
    import_error: Optional[str] = None
    module_path: str = ""
    filesystem_path: str = ""

    def is_healthy(self) -> bool:
        return self.status == ComponentStatus.HEALTHY or (
            self.registry_entry and self.filesystem_found and self.importable
        )


@dataclass
class ConsistencyReport:
    """Full consistency report across registry, scanner, and runtime."""
    # Component health
    components: Dict[str, ComponentHealth] = field(default_factory=dict)

    # Summary counts
    total_registered: int = 0
    total_discovered: int = 0
    total_healthy: int = 0
    total_broken: int = 0

    # Issues
    unregistered: List[str] = field(default_factory=list)  # In filesystem, not registered
    missing: List[str] = field(default_factory=list)  # Registered, not in filesystem
    broken: List[str] = field(default_factory=list)  # Can't be imported

    # Capability analysis
    capabilities_covered: Set[str] = field(default_factory=set)
    capabilities_gap: Set[str] = field(default_factory=set)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "summary": {
                "total_registered": self.total_registered,
                "total_discovered": self.total_discovered,
                "total_healthy": self.total_healthy,
                "total_broken": self.total_broken,
            },
            "issues": {
                "unregistered_count": len(self.unregistered),
                "unregistered": self.unregistered[:20],  # First 20
                "missing_count": len(self.missing),
                "missing": self.missing,
                "broken_count": len(self.broken),
                "broken": self.broken,
            },
            "capabilities": {
                "covered": list(self.capabilities_covered),
                "gaps": list(self.capabilities_gap),
            },
        }

    def get_summary_text(self) -> str:
        """Get human-readable summary."""
        lines = [
            "**Consistency Report**",
            "",
            f"Registered components: {self.total_registered}",
            f"Discovered components: {self.total_discovered}",
            f"Healthy: {self.total_healthy}",
            f"Broken: {self.total_broken}",
            "",
        ]

        if self.unregistered:
            lines.append(f"**Unregistered ({len(self.unregistered)})**: Components in filesystem but not in registry")
            for comp_id in self.unregistered[:10]:
                lines.append(f"  - {comp_id}")
            if len(self.unregistered) > 10:
                lines.append(f"  ... and {len(self.unregistered) - 10} more")
            lines.append("")

        if self.missing:
            lines.append(f"**Missing ({len(self.missing)})**: Registered but not found in filesystem")
            for comp_id in self.missing:
                lines.append(f"  - {comp_id}")
            lines.append("")

        if self.broken:
            lines.append(f"**Broken ({len(self.broken)})**: Cannot be imported")
            for comp_id in self.broken:
                health = self.components.get(comp_id)
                if health and health.import_error:
                    lines.append(f"  - {comp_id}: {health.import_error[:50]}")
                else:
                    lines.append(f"  - {comp_id}")
            lines.append("")

        if self.capabilities_gap:
            lines.append(f"**Capability Gaps**: {', '.join(sorted(self.capabilities_gap))}")

        return "\n".join(lines)


class ConsistencyChecker:
    """
    Checks consistency between registry, filesystem scanner, and runtime.

    Usage:
        checker = ConsistencyChecker()
        report = checker.check()
        print(report.get_summary_text())
    """

    def __init__(self):
        self._registry = None
        self._scanner = None
        self._report: Optional[ConsistencyReport] = None

    def _get_registry(self):
        """Get the system registry."""
        if self._registry is None:
            try:
                from brains.utils.system_registry import get_system_registry
                from brains.utils.component_manifest import initialize_registry
                initialize_registry()
                self._registry = get_system_registry()
            except ImportError:
                self._registry = None
        return self._registry

    def _get_scanner(self):
        """Get the system scanner."""
        if self._scanner is None:
            try:
                from brains.utils.system_scanner import get_system_scanner
                self._scanner = get_system_scanner()
            except ImportError:
                self._scanner = None
        return self._scanner

    def check(self, verify_imports: bool = True) -> ConsistencyReport:
        """
        Run full consistency check.

        Args:
            verify_imports: If True, attempt to import each module to verify it works

        Returns:
            ConsistencyReport with all findings
        """
        report = ConsistencyReport()

        registry = self._get_registry()
        scanner = self._get_scanner()

        if registry is None or scanner is None:
            return report

        # Get registered components
        registered_ids = set()
        registered_modules = {}
        for comp in registry.get_all():
            registered_ids.add(comp.id)
            registered_modules[comp.id] = comp.owner_module

        # Get discovered components
        scanner.scan_all()
        discovered_ids = set(scanner.components.keys())
        discovered_modules = {cid: c.module_path for cid, c in scanner.components.items()}

        report.total_registered = len(registered_ids)
        report.total_discovered = len(discovered_ids)

        # Find unregistered (in filesystem, not in registry)
        # Normalize IDs for comparison (scanner adds prefixes like "tool_", "memory_")
        scanner_to_registry_map = self._build_id_map(registered_ids, discovered_ids)

        for disc_id in discovered_ids:
            mapped_id = scanner_to_registry_map.get(disc_id)
            if mapped_id is None:
                report.unregistered.append(disc_id)

        # Find missing (in registry, not in filesystem)
        registry_to_scanner_map = {v: k for k, v in scanner_to_registry_map.items() if v}
        for reg_id in registered_ids:
            if reg_id not in registry_to_scanner_map:
                # Check if the module path exists
                module_path = registered_modules.get(reg_id, "")
                if module_path and not self._module_exists(module_path):
                    report.missing.append(reg_id)

        # Check import health if requested
        all_ids = registered_ids | discovered_ids
        for comp_id in all_ids:
            health = ComponentHealth(
                id=comp_id,
                name=comp_id,
                status=ComponentStatus.HEALTHY,
                registry_entry=comp_id in registered_ids,
                filesystem_found=comp_id in discovered_ids or scanner_to_registry_map.get(comp_id) in registered_ids,
            )

            # Get module path
            if comp_id in registered_modules:
                health.module_path = registered_modules[comp_id]
            elif comp_id in discovered_modules:
                health.module_path = discovered_modules[comp_id]

            if verify_imports and health.module_path:
                health.importable, health.import_error = self._try_import(health.module_path)

            # Determine status
            if not health.registry_entry and health.filesystem_found:
                health.status = ComponentStatus.FOUND_NOT_REGISTERED
            elif health.registry_entry and not health.filesystem_found:
                health.status = ComponentStatus.REGISTERED_NOT_FOUND
            elif health.import_error:
                health.status = ComponentStatus.IMPORT_ERROR
                report.broken.append(comp_id)
            else:
                health.status = ComponentStatus.HEALTHY if health.is_healthy() else ComponentStatus.IMPORT_ERROR

            report.components[comp_id] = health

        # Count healthy
        report.total_healthy = sum(1 for h in report.components.values() if h.is_healthy())
        report.total_broken = len(report.broken)

        # Capability analysis
        report.capabilities_covered = self._get_all_capabilities(registry)
        report.capabilities_gap = self._get_capability_gaps(report.capabilities_covered)

        self._report = report
        return report

    def _build_id_map(self, registered_ids: Set[str], discovered_ids: Set[str]) -> Dict[str, Optional[str]]:
        """Build a map from discovered IDs to registered IDs."""
        result = {}

        for disc_id in discovered_ids:
            # Direct match
            if disc_id in registered_ids:
                result[disc_id] = disc_id
                continue

            # Try removing prefixes (scanner adds "tool_", "memory_", etc.)
            for prefix in ["tool_", "memory_", "agent_", "routing_", "pipeline_", "learning_", "gov_"]:
                if disc_id.startswith(prefix):
                    base_id = disc_id[len(prefix):]
                    if base_id in registered_ids:
                        result[disc_id] = base_id
                        break
            else:
                # No match found
                result[disc_id] = None

        return result

    def _module_exists(self, module_path: str) -> bool:
        """Check if a module path corresponds to an existing file."""
        # Convert module path to file path
        parts = module_path.split(".")
        # Try to find the file
        try:
            from brains.utils.system_scanner import get_system_scanner
            scanner = get_system_scanner()
            base = scanner.base_path

            # Check as directory with __init__.py
            dir_path = base / "/".join(parts)
            if dir_path.is_dir() and (dir_path / "__init__.py").exists():
                return True

            # Check as file
            file_path = base / "/".join(parts[:-1]) / f"{parts[-1]}.py"
            if file_path.exists():
                return True

            # Check as service file
            service_path = base / "/".join(parts) / "service" / f"{parts[-1]}_brain.py"
            if service_path.exists():
                return True

            return False
        except Exception:
            return False

    def _try_import(self, module_path: str) -> Tuple[bool, Optional[str]]:
        """Try to import a module and return (success, error_message)."""
        try:
            importlib.import_module(module_path)
            return True, None
        except ImportError as e:
            return False, str(e)
        except Exception as e:
            return False, f"{type(e).__name__}: {str(e)}"

    def _get_all_capabilities(self, registry) -> Set[str]:
        """Get all capabilities from registered components."""
        caps = set()
        for comp in registry.get_all():
            caps.update(comp.capabilities)
        return caps

    def _get_capability_gaps(self, covered: Set[str]) -> Set[str]:
        """Identify expected capabilities that aren't covered."""
        expected = {
            "routing", "memory_storage", "memory_retrieval", "learning",
            "reasoning", "planning", "web_search", "browser_control",
            "file_read", "file_write", "shell_execution", "external_ai",
            "response_synthesis", "introspection", "self_explanation",
        }
        return expected - covered

    def get_unregistered(self) -> List[str]:
        """Get list of components in filesystem but not registered."""
        if self._report is None:
            self.check(verify_imports=False)
        return self._report.unregistered if self._report else []

    def get_missing(self) -> List[str]:
        """Get list of components registered but missing from filesystem."""
        if self._report is None:
            self.check(verify_imports=False)
        return self._report.missing if self._report else []

    def get_broken(self) -> List[str]:
        """Get list of components that can't be imported."""
        if self._report is None:
            self.check(verify_imports=True)
        return self._report.broken if self._report else []


# =============================================================================
# Singleton and Convenience Functions
# =============================================================================

_checker_instance: Optional[ConsistencyChecker] = None


def get_consistency_checker() -> ConsistencyChecker:
    """Get or create the singleton ConsistencyChecker instance."""
    global _checker_instance
    if _checker_instance is None:
        _checker_instance = ConsistencyChecker()
    return _checker_instance


def check_consistency(verify_imports: bool = True) -> ConsistencyReport:
    """Run a full consistency check."""
    return get_consistency_checker().check(verify_imports=verify_imports)


def get_unregistered_components() -> List[str]:
    """Get components in filesystem but not registered."""
    return get_consistency_checker().get_unregistered()


def get_missing_from_filesystem() -> List[str]:
    """Get components registered but missing from filesystem."""
    return get_consistency_checker().get_missing()


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "ComponentStatus",
    "ComponentHealth",
    "ConsistencyReport",
    "ConsistencyChecker",
    "get_consistency_checker",
    "check_consistency",
    "get_unregistered_components",
    "get_missing_from_filesystem",
]
