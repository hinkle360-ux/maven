# brains/core/introspection/diagnostics.py
"""
Diagnostics Engine
==================

Provides diagnostic commands for understanding Maven's internal state.
Can be called from CLI or chat interface.

Commands:
- diagnose_self: Full system health check
- get_system_health: Quick health summary
- explain_component: Detailed info about a specific component
- list_components_by_type: List all components of a type
- find_capability: Find components with a capability
- what_am_i: Dynamic self-description

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass
from enum import Enum


class HealthLevel(str, Enum):
    """System health levels."""
    HEALTHY = "healthy"
    WARNING = "warning"
    CRITICAL = "critical"
    UNKNOWN = "unknown"


@dataclass
class SystemHealth:
    """Overall system health summary."""
    level: HealthLevel
    message: str
    components_healthy: int
    components_total: int
    issues: List[str]
    warnings: List[str]

    def to_text(self) -> str:
        icon = {"healthy": "[OK]", "warning": "[WARN]", "critical": "[CRIT]", "unknown": "[?]"}
        lines = [
            f"{icon.get(self.level.value, '[?]')} System Health: {self.level.value.upper()}",
            "",
            f"Components: {self.components_healthy}/{self.components_total} healthy",
            "",
        ]

        if self.issues:
            lines.append("**Issues:**")
            for issue in self.issues[:5]:
                lines.append(f"  - {issue}")
            if len(self.issues) > 5:
                lines.append(f"  ... and {len(self.issues) - 5} more")
            lines.append("")

        if self.warnings:
            lines.append("**Warnings:**")
            for warn in self.warnings[:5]:
                lines.append(f"  - {warn}")
            if len(self.warnings) > 5:
                lines.append(f"  ... and {len(self.warnings) - 5} more")

        return "\n".join(lines)


class DiagnosticsEngine:
    """
    Diagnostics engine for Maven self-inspection.

    Usage:
        engine = DiagnosticsEngine()
        health = engine.get_system_health()
        print(health.to_text())

        info = engine.explain_component("integrator")
        print(info)
    """

    def __init__(self):
        self._registry = None
        self._scanner = None
        self._consistency = None

    def _get_registry(self):
        if self._registry is None:
            try:
                from brains.utils.system_registry import get_system_registry
                from brains.utils.component_manifest import initialize_registry
                initialize_registry()
                self._registry = get_system_registry()
            except ImportError:
                pass
        return self._registry

    def _get_scanner(self):
        if self._scanner is None:
            try:
                from brains.utils.system_scanner import get_system_scanner
                self._scanner = get_system_scanner()
            except ImportError:
                pass
        return self._scanner

    def _get_consistency(self):
        if self._consistency is None:
            try:
                from brains.cognitive.self_introspection.service.consistency_utils import get_consistency_checker
                self._consistency = get_consistency_checker()
            except ImportError:
                pass
        return self._consistency

    # =========================================================================
    # Health Commands
    # =========================================================================

    def get_system_health(self) -> SystemHealth:
        """Get quick system health summary."""
        consistency = self._get_consistency()
        if consistency is None:
            return SystemHealth(
                level=HealthLevel.UNKNOWN,
                message="Consistency checker not available",
                components_healthy=0,
                components_total=0,
                issues=["Cannot load introspection modules"],
                warnings=[],
            )

        # Run consistency check without import verification for speed
        report = consistency.check(verify_imports=False)

        issues = []
        warnings = []

        # Check for critical issues
        if report.broken:
            issues.extend([f"Broken: {bid}" for bid in report.broken[:3]])

        if report.missing:
            warnings.extend([f"Missing: {mid}" for mid in report.missing[:3]])

        if len(report.unregistered) > 50:
            warnings.append(f"{len(report.unregistered)} components not in registry")

        # Determine health level
        if issues:
            level = HealthLevel.CRITICAL
            message = f"System has {len(issues)} critical issues"
        elif warnings:
            level = HealthLevel.WARNING
            message = f"System functional with {len(warnings)} warnings"
        else:
            level = HealthLevel.HEALTHY
            message = "All systems operational"

        return SystemHealth(
            level=level,
            message=message,
            components_healthy=report.total_healthy,
            components_total=report.total_discovered,
            issues=issues,
            warnings=warnings,
        )

    def diagnose_self(self, verbose: bool = False) -> str:
        """
        Run full self-diagnosis.

        Args:
            verbose: If True, include detailed component list

        Returns:
            Human-readable diagnostic report
        """
        lines = ["# Maven Self-Diagnosis Report", ""]

        # System health
        health = self.get_system_health()
        lines.append(health.to_text())
        lines.append("")

        # Registry vs Scanner comparison
        registry = self._get_registry()
        scanner = self._get_scanner()

        if registry and scanner:
            scanner.scan_all()

            lines.append("## Component Inventory")
            lines.append("")

            # Count by type from scanner
            from brains.utils.system_scanner import ComponentType
            type_counts = {}
            for comp in scanner.components.values():
                t = comp.component_type.value
                type_counts[t] = type_counts.get(t, 0) + 1

            for ctype, count in sorted(type_counts.items(), key=lambda x: -x[1]):
                lines.append(f"- {ctype}: {count}")

            lines.append("")
            lines.append(f"**Total discovered**: {len(scanner.components)}")
            lines.append(f"**Registered in manifest**: {len(registry.get_all())}")
            lines.append("")

        # Consistency details
        consistency = self._get_consistency()
        if consistency:
            report = consistency.check(verify_imports=False)

            if report.unregistered:
                lines.append("## Unregistered Components")
                lines.append(f"*{len(report.unregistered)} components found in filesystem but not in registry*")
                lines.append("")
                if verbose:
                    for uid in sorted(report.unregistered)[:30]:
                        lines.append(f"- {uid}")
                    if len(report.unregistered) > 30:
                        lines.append(f"... and {len(report.unregistered) - 30} more")
                else:
                    lines.append("(use verbose=True to see full list)")
                lines.append("")

            if report.capabilities_gap:
                lines.append("## Capability Gaps")
                lines.append(f"Expected capabilities not explicitly covered: {', '.join(sorted(report.capabilities_gap))}")
                lines.append("")

        # Self-knowledge status
        lines.append("## Self-Knowledge Status")
        try:
            from brains.cognitive.self_model.service.self_knowledge import CANONICAL_INTRO, get_dynamic_intro
            lines.append("- Canonical intro: Available")
            lines.append("- Dynamic intro: " + ("Available" if get_dynamic_intro() else "Not available"))
        except ImportError:
            lines.append("- Self-knowledge module: NOT AVAILABLE")
        lines.append("")

        return "\n".join(lines)

    # =========================================================================
    # Component Queries
    # =========================================================================

    def explain_component(self, component_id: str) -> str:
        """
        Get detailed explanation of a component.

        Args:
            component_id: The component ID to explain

        Returns:
            Human-readable component description
        """
        registry = self._get_registry()
        scanner = self._get_scanner()

        lines = [f"# Component: {component_id}", ""]

        # Check registry
        registry_comp = None
        if registry:
            try:
                registry_comp = registry.get_component(component_id)
            except Exception:
                pass

        if registry_comp:
            lines.append("## Registry Entry")
            lines.append(f"**Name**: {registry_comp.name}")
            lines.append(f"**Kind**: {registry_comp.kind.value}")
            lines.append(f"**Description**: {registry_comp.description}")
            lines.append(f"**Module**: {registry_comp.owner_module}")
            if registry_comp.capabilities:
                lines.append(f"**Capabilities**: {', '.join(registry_comp.capabilities)}")
            if registry_comp.safety_tags:
                lines.append(f"**Safety Tags**: {', '.join(t.value for t in registry_comp.safety_tags)}")
            if registry_comp.usage_examples:
                lines.append("**Usage Examples**:")
                for ex in registry_comp.usage_examples:
                    lines.append(f"  - {ex}")
            lines.append("")
        else:
            lines.append("*Not found in registry*")
            lines.append("")

        # Check scanner
        scanner_comp = None
        if scanner:
            scanner.scan_all()
            scanner_comp = scanner.components.get(component_id)

            # Try with prefixes
            if not scanner_comp:
                for prefix in ["tool_", "memory_", "agent_", "routing_", "pipeline_"]:
                    scanner_comp = scanner.components.get(f"{prefix}{component_id}")
                    if scanner_comp:
                        break

        if scanner_comp:
            lines.append("## Discovered from Filesystem")
            lines.append(f"**Name**: {scanner_comp.name}")
            lines.append(f"**Type**: {scanner_comp.component_type.value}")
            lines.append(f"**Path**: {scanner_comp.path}")
            lines.append(f"**Module**: {scanner_comp.module_path}")
            if scanner_comp.description:
                lines.append(f"**Description**: {scanner_comp.description}")
            if scanner_comp.classes:
                lines.append(f"**Classes**: {', '.join(scanner_comp.classes[:5])}")
            if scanner_comp.functions:
                lines.append(f"**Functions**: {', '.join(scanner_comp.functions[:5])}")
            lines.append("")

        if not registry_comp and not scanner_comp:
            return f"Component '{component_id}' not found in registry or filesystem."

        return "\n".join(lines)

    def list_components_by_type(self, component_type: str) -> str:
        """
        List all components of a given type.

        Args:
            component_type: Type like "brain", "tool", "engine", etc.

        Returns:
            Human-readable list
        """
        scanner = self._get_scanner()
        if not scanner:
            return "Scanner not available"

        scanner.scan_all()

        # Map user-friendly types to ComponentType
        type_map = {
            "brain": ["cognitive_brain", "routing_brain"],
            "brains": ["cognitive_brain", "routing_brain"],
            "tool": ["tool"],
            "tools": ["tool"],
            "engine": ["engine"],
            "engines": ["engine"],
            "memory": ["memory_module"],
            "agent": ["agent"],
            "pipeline": ["pipeline_component"],
            "governance": ["governance"],
            "learning": ["learning"],
            "helper": ["helper"],
        }

        target_types = type_map.get(component_type.lower(), [component_type.lower()])

        matches = []
        for comp in scanner.components.values():
            if comp.component_type.value in target_types:
                matches.append(comp)

        if not matches:
            return f"No components found of type '{component_type}'"

        lines = [f"# {component_type.title()} Components ({len(matches)})", ""]

        for comp in sorted(matches, key=lambda x: x.name):
            desc = comp.description[:60] + "..." if len(comp.description) > 60 else comp.description
            lines.append(f"- **{comp.name}** ({comp.id}): {desc}")

        return "\n".join(lines)

    def find_capability(self, capability: str) -> str:
        """
        Find components with a specific capability.

        Args:
            capability: The capability to search for

        Returns:
            Human-readable list of matching components
        """
        registry = self._get_registry()
        scanner = self._get_scanner()

        matches = []

        # Check registry
        if registry:
            for comp in registry.get_all():
                if capability.lower() in {c.lower() for c in comp.capabilities}:
                    matches.append((comp.id, comp.name, "registry"))

        # Check scanner
        if scanner:
            scanner.scan_all()
            for comp in scanner.components.values():
                if capability.lower() in {c.lower() for c in comp.capabilities}:
                    if comp.id not in {m[0] for m in matches}:
                        matches.append((comp.id, comp.name, "discovered"))

        if not matches:
            return f"No components found with capability '{capability}'"

        lines = [f"# Components with '{capability}' capability ({len(matches)})", ""]
        for comp_id, name, source in sorted(matches, key=lambda x: x[1]):
            lines.append(f"- **{name}** ({comp_id}) [{source}]")

        return "\n".join(lines)

    def what_am_i(self) -> str:
        """
        Generate a dynamic self-description based on discovered components.

        Returns:
            Human-readable self-description
        """
        scanner = self._get_scanner()
        if not scanner:
            return "I am Maven, a modular AI assistant. (Scanner not available for detailed info)"

        scanner.scan_all()
        return scanner.get_dynamic_self_description()

    # =========================================================================
    # CLI Command Handler
    # =========================================================================

    def handle_command(self, command: str) -> str:
        """
        Handle a diagnostic command from CLI or chat.

        Commands:
            system:diagnose-self
            system:health
            system:list <type>
            system:explain <component_id>
            system:find <capability>
            system:what-am-i

        Args:
            command: The command string

        Returns:
            Command output
        """
        parts = command.strip().split()
        if not parts:
            return self._get_help()

        cmd = parts[0].lower()
        args = parts[1:]

        if cmd in ("diagnose-self", "diagnose", "full"):
            verbose = "--verbose" in args or "-v" in args
            return self.diagnose_self(verbose=verbose)

        elif cmd in ("health", "status"):
            return self.get_system_health().to_text()

        elif cmd in ("list", "ls"):
            if not args:
                return "Usage: list <type>  (types: brain, tool, engine, memory, agent, pipeline)"
            return self.list_components_by_type(args[0])

        elif cmd in ("explain", "info", "show"):
            if not args:
                return "Usage: explain <component_id>"
            return self.explain_component(args[0])

        elif cmd in ("find", "search", "capability"):
            if not args:
                return "Usage: find <capability>"
            return self.find_capability(args[0])

        elif cmd in ("what-am-i", "intro", "self"):
            return self.what_am_i()

        else:
            return self._get_help()

    def _get_help(self) -> str:
        return """**Maven Diagnostics Commands**

- `diagnose-self [-v]`: Full system diagnosis
- `health`: Quick health check
- `list <type>`: List components (brain, tool, engine, memory, agent, pipeline, governance)
- `explain <id>`: Detailed component info
- `find <capability>`: Find components by capability
- `what-am-i`: Dynamic self-description

Example: `system:list brain` or `system:explain integrator`
"""


# =============================================================================
# Singleton and Convenience Functions
# =============================================================================

_engine_instance: Optional[DiagnosticsEngine] = None


def get_diagnostics_engine() -> DiagnosticsEngine:
    """Get or create the singleton DiagnosticsEngine instance."""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = DiagnosticsEngine()
    return _engine_instance


def diagnose_self(verbose: bool = False) -> str:
    """Run full self-diagnosis."""
    return get_diagnostics_engine().diagnose_self(verbose=verbose)


def get_system_health() -> SystemHealth:
    """Get system health summary."""
    return get_diagnostics_engine().get_system_health()


def explain_component(component_id: str) -> str:
    """Get detailed explanation of a component."""
    return get_diagnostics_engine().explain_component(component_id)


def list_components_by_type(component_type: str) -> str:
    """List all components of a type."""
    return get_diagnostics_engine().list_components_by_type(component_type)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "HealthLevel",
    "SystemHealth",
    "DiagnosticsEngine",
    "get_diagnostics_engine",
    "diagnose_self",
    "get_system_health",
    "explain_component",
    "list_components_by_type",
]
