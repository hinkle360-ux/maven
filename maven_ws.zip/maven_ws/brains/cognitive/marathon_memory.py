"""
Marathon Conversation Summary - Rolling context for long conversations
=====================================================================
FIX CCS-11: Prevents context decay over 25+ turn conversations by
maintaining a rolling summary of key facts mentioned throughout.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

import re
import logging

logger = logging.getLogger(__name__)

# Rolling conversation summary
_conversation_summary = {}


def update_conversation_summary(session_history, user_attributes_cache=None):
    """
    Scan session history and compile key facts into rolling summary.
    Called every 5 turns in conversations with 10+ turns.
    
    Args:
        session_history: List of {"role": str, "content": str} dicts
        user_attributes_cache: Optional dict of stored user attributes
    
    Returns:
        Dict of key facts extracted
    """
    global _conversation_summary
    
    if not session_history:
        return _conversation_summary
    
    s = {}
    
    for turn in session_history:
        if turn.get("role") != "user":
            continue
        msg = turn.get("content", "").lower()
        
        # Name: "my name is X", "I'm X and..."
        nm = re.search(r"(?:my name is|i'm|i am)\s+([a-z][a-z'\-]+)(?:\s+and\b|\.|,|!|$)", msg)
        if nm and not nm.group(1).isdigit() and len(nm.group(1)) > 1:
            s["name"] = nm.group(1).capitalize()
        
        # Travel companion
        tc = re.search(r"(?:traveling|travelling)\s+with\s+(?:my\s+)?(sister|brother|friend|wife|husband)?\s*(\w+)", msg)
        if tc:
            rel = tc.group(1) or ""
            s["companion"] = f"{rel} {tc.group(2).capitalize()}".strip()
        
        # Travel month
        mo = re.search(
            r"(?:going|travel|visit|plan)\w*\s+(?:in|for|during)\s+"
            r"(january|february|march|april|may|june|july|august|september|october|november|december)",
            msg
        )
        if mo:
            s["month"] = mo.group(1).capitalize()
        
        # Travel destination
        dest = re.search(r"(?:trip|travel|going|visiting)\w*\s+to\s+([A-Za-z]+(?:\s+[A-Za-z]+)?)", msg, re.IGNORECASE)
        if dest:
            s["destination"] = dest.group(1).strip().title()
        
        # Dietary
        for d in ["vegetarian", "vegan", "pescatarian", "gluten-free", "kosher", "halal"]:
            if d in msg:
                s["dietary"] = d
        
        # Budget
        bg = re.search(r"budget\s+(?:is\s+)?(?:around\s+)?\$?([\d,]+)", msg)
        if bg:
            s["budget"] = bg.group(1)
        
        # Math results - capture actual calculation
        mm = re.search(r"what.{0,5}(\d+)\s*([*x\u00d7+\-])\s*(\d+)", msg)
        if mm:
            a, op, b = mm.group(1), mm.group(2), mm.group(3)
            try:
                ops = {"*": "*", "x": "*", "\u00d7": "*", "+": "+", "-": "-"}
                result = eval(f"{a}{ops.get(op, '*')}{b}")
                s["math_result"] = f"{a}{op}{b}={result}"
            except Exception:
                s["had_math"] = True
    
    # Also pull from user attributes cache if available
    if user_attributes_cache:
        attr_map = {
            "name": "name",
            "location": "location", 
            "job": "job",
            "dietary_preference": "dietary",
            "travel_companion": "companion",
            "travel_companion_relation": "companion_relation",
            "pet_name": "pet",
        }
        for attr_key, summary_key in attr_map.items():
            if attr_key in user_attributes_cache and summary_key not in s:
                s[summary_key] = user_attributes_cache[attr_key]
    
    _conversation_summary = s
    logger.debug(f"[MARATHON_SUMMARY] Updated: {s}")
    return s


def get_summary_context():
    """
    Get a brief summary string of key conversation facts.
    Returns empty string if no significant facts tracked.
    """
    global _conversation_summary
    if not _conversation_summary:
        return ""
    
    parts = []
    field_labels = {
        "name": "User",
        "destination": "Trip to",
        "month": "Travel month",
        "companion": "Traveling with",
        "companion_relation": "Companion is",
        "dietary": "Dietary",
        "budget": "Budget $",
        "location": "Lives in",
        "job": "Works as",
        "pet": "Pet",
    }
    
    for key, label in field_labels.items():
        val = _conversation_summary.get(key)
        if val:
            parts.append(f"{label}: {val}")
    
    # Add math results if tracked
    math_r = _conversation_summary.get("math_result")
    if math_r:
        parts.append(f"Math solved: {math_r}")
    
    if not parts:
        return ""
    
    return "[Context: " + "; ".join(parts) + "]"


def reset_summary():
    """Reset the conversation summary."""
    global _conversation_summary
    _conversation_summary = {}


# Quick knowledge answers for rapid-fire questions (CCS-13)
QUICK_ANSWERS = {
    "romeo and juliet": "William Shakespeare wrote Romeo and Juliet.",
    "wrote hamlet": "William Shakespeare wrote Hamlet.",
    "wrote romeo": "William Shakespeare wrote Romeo and Juliet.",
    "color is the sky": "The sky is blue.",
    "colour is the sky": "The sky is blue.",
    "color of the sky": "The sky is blue.",
    "days in a week": "There are 7 days in a week.",
    "capital of italy": "The capital of Italy is Rome.",
    "capital of france": "The capital of France is Paris.",
    "capital of japan": "The capital of Japan is Tokyo.",
    "capital of germany": "The capital of Germany is Berlin.",
    "capital of spain": "The capital of Spain is Madrid.",
    "capital of england": "The capital of England is London.",
    "capital of china": "The capital of China is Beijing.",
    "largest ocean": "The largest ocean is the Pacific Ocean.",
    "tallest mountain": "The tallest mountain is Mount Everest.",
    "chemical symbol for water": "The chemical symbol for water is H2O.",
    "boiling point of water": "Water boils at 100\u00b0C (212\u00b0F) at standard pressure.",
    "speed of light": "The speed of light is approximately 299,792,458 meters per second.",
}


def try_quick_answer(question):
    """
    Try instant answer for common knowledge questions.
    Returns answer string or None.
    """
    q = question.lower().strip().rstrip("?").strip()
    
    for key, ans in QUICK_ANSWERS.items():
        if key in q:
            return ans
    
    # Quick math
    m = re.search(r"(\d+)\s*[+]\s*(\d+)", q)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        return f"The answer is {a+b}. ({a} + {b} = {a+b})"
    
    m = re.search(r"(\d+)\s*[*x\u00d7]\s*(\d+)", q)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        return f"The answer is {a*b}. ({a} \u00d7 {b} = {a*b})"
    
    return None
