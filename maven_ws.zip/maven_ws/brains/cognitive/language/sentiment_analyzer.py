"""
Sentiment and Negation Analyzer
================================

Handles complex negation patterns like:
- "I'm not unhappy" (NOT the same as "I'm happy" - it's neutral/mixed)
- "I don't dislike it" (NOT the same as "I like it")
- Double negatives that cancel out

This prevents Maven from over-simplifying nuanced statements.
"""

import re
from typing import Optional, Tuple

def analyze_negation(statement: str) -> Tuple[str, str]:
    """
    Analyze a statement for negation patterns.
    
    Args:
        statement: User's statement (e.g., "I'm not unhappy with my job")
        
    Returns:
        Tuple of (sentiment, confidence):
        - sentiment: "positive", "negative", "neutral", or "mixed"
        - confidence: "high", "medium", "low"
    
    Examples:
        "I'm happy" → ("positive", "high")
        "I'm unhappy" → ("negative", "high")
        "I'm not unhappy" → ("neutral", "medium")  # Double negative = neutral
        "I'm not happy" → ("negative", "medium")   # Simple negation
    """
    lower = statement.lower().strip()
    
    # -----------------------------------------------------------------
    # 1. DOUBLE NEGATION (not + negative_word)
    # -----------------------------------------------------------------
    # Pattern: "not" + negative adjective = neutral/mixed
    double_neg_patterns = [
        (r"\bnot\s+unhappy\b", "neutral"),
        (r"\bnot\s+dissatisfied\b", "neutral"),
        (r"\bnot\s+displeased\b", "neutral"),
        (r"\bnot\s+uncomfortable\b", "neutral"),
        (r"\bnot\s+upset\b", "neutral"),
        (r"\bdon't\s+dislike\b", "neutral"),
        (r"\bdon't\s+hate\b", "neutral"),
    ]
    
    for pattern, sentiment in double_neg_patterns:
        if re.search(pattern, lower):
            return (sentiment, "medium")
    
    # -----------------------------------------------------------------
    # 2. SIMPLE NEGATION (not + positive_word)
    # -----------------------------------------------------------------
    # Pattern: "not" + positive adjective = negative
    simple_neg_patterns = [
        (r"\bnot\s+happy\b", "negative"),
        (r"\bnot\s+satisfied\b", "negative"),
        (r"\bnot\s+pleased\b", "negative"),
        (r"\bnot\s+comfortable\b", "negative"),
        (r"\bdon't\s+like\b", "negative"),
        (r"\bdon't\s+love\b", "negative"),
        (r"\bdon't\s+enjoy\b", "negative"),
    ]
    
    for pattern, sentiment in simple_neg_patterns:
        if re.search(pattern, lower):
            return (sentiment, "medium")
    
    # -----------------------------------------------------------------
    # 3. POSITIVE STATEMENTS
    # -----------------------------------------------------------------
    positive_words = ["happy", "satisfied", "pleased", "love", "like", "enjoy", "great", "good"]
    for word in positive_words:
        if re.search(rf"\b{word}\b", lower):
            # Make sure it's not negated
            if not re.search(rf"\b(?:not|don't|doesn't)\s+{word}\b", lower):
                return ("positive", "high")
    
    # -----------------------------------------------------------------
    # 4. NEGATIVE STATEMENTS
    # -----------------------------------------------------------------
    negative_words = ["unhappy", "dissatisfied", "hate", "dislike", "terrible", "bad", "awful"]
    for word in negative_words:
        if re.search(rf"\b{word}\b", lower):
            # Make sure it's not double-negated
            if not re.search(rf"\b(?:not|don't|doesn't)\s+{word}\b", lower):
                return ("negative", "high")
    
    # -----------------------------------------------------------------
    # 5. DEFAULT - UNKNOWN/NEUTRAL
    # -----------------------------------------------------------------
    return ("neutral", "low")

def extract_sentiment_statement(statement: str) -> Optional[str]:
    """
    Extract a clean sentiment statement, handling negations properly.
    
    Args:
        statement: User's statement
        
    Returns:
        Cleaned statement or None
        
    Examples:
        "I'm not unhappy with my job" → "I have mixed feelings about my job"
        "I'm happy with my job" → "I'm happy with my job"
        "I don't like pizza" → "I dislike pizza"
    """
    sentiment, confidence = analyze_negation(statement)
    
    # Extract the subject (what they're talking about)
    subject_match = re.search(r"(?:with|about)\s+(.+?)(?:\.|$)", statement, re.IGNORECASE)
    subject = subject_match.group(1) if subject_match else "it"
    
    if sentiment == "neutral" and "not" in statement.lower():
        # Double negative - express as neutral/mixed
        return f"I have mixed feelings about {subject}"
    elif sentiment == "negative" and "not" in statement.lower():
        # Simple negation - convert "not happy" → "unhappy" or "dissatisfied"
        return statement  # Keep original for now
    else:
        # Positive or clear negative - keep as is
        return statement

def should_store_as_belief(statement: str) -> bool:
    """
    Determine if a nuanced statement should be stored as a belief/opinion
    rather than a hard fact.
    
    Double negations and mixed sentiments should be stored as beliefs
    since they're subjective and context-dependent.
    
    Args:
        statement: User's statement
        
    Returns:
        True if it should be stored as a belief, False for hard fact
    """
    sentiment, confidence = analyze_negation(statement)
    
    # Store as belief if:
    # - It's a double negative (neutral sentiment from negation)
    # - Confidence is not high
    # - It contains hedging words
    
    if sentiment == "neutral" and "not" in statement.lower():
        return True  # Double negative
    
    if confidence in ["low", "medium"]:
        return True  # Not confident
    
    # Check for hedging words
    hedging_words = ["maybe", "perhaps", "somewhat", "kind of", "sort of", "a bit"]
    lower = statement.lower()
    if any(word in lower for word in hedging_words):
        return True
    
    return False
