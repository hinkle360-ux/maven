"""
Prose Converter - Convert Content to Natural Prose
==================================================

FIX 4: This module ensures text_realizer outputs natural prose:
1. Strips markdown formatting (headers, bullets, bold, etc.)
2. Converts structured content to flowing paragraphs
3. Maintains readability without sacrificing content

Integration Point:
    text_realizer.realize() should call convert_to_prose() before
    returning any user-facing response.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import re
from typing import Dict, List, Any, Optional, Tuple


# =============================================================================
# MARKDOWN STRIPPING
# =============================================================================

def strip_markdown(text: str, preserve_code: bool = False) -> str:
    """
    Strip markdown formatting from text.

    Args:
        text: Text that may contain markdown
        preserve_code: If True, preserve code blocks

    Returns:
        Plain text without markdown
    """
    if not text:
        return text

    # Preserve code blocks if requested
    code_blocks = []
    if preserve_code:
        def save_code(match):
            code_blocks.append(match.group(0))
            return f"[CODE_BLOCK_{len(code_blocks)-1}]"
        text = re.sub(r'```[\s\S]*?```', save_code, text)

    # Remove headers (## Header -> Header)
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)

    # Remove bold (**text** or __text__)
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    text = re.sub(r'__(.+?)__', r'\1', text)

    # Remove italic (*text* or _text_)
    text = re.sub(r'\*(.+?)\*', r'\1', text)
    text = re.sub(r'(?<!\w)_(.+?)_(?!\w)', r'\1', text)

    # Remove strikethrough (~~text~~)
    text = re.sub(r'~~(.+?)~~', r'\1', text)

    # Remove inline code (`code`)
    text = re.sub(r'`([^`]+)`', r'\1', text)

    # Remove links ([text](url) -> text)
    text = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', text)

    # Remove images (![alt](url) -> alt)
    text = re.sub(r'!\[([^\]]*)\]\([^)]+\)', r'\1', text)

    # Remove horizontal rules
    text = re.sub(r'^[-*_]{3,}\s*$', '', text, flags=re.MULTILINE)

    # Remove blockquotes (> text -> text)
    text = re.sub(r'^>\s*', '', text, flags=re.MULTILINE)

    # Restore code blocks
    if preserve_code:
        for i, code in enumerate(code_blocks):
            text = text.replace(f"[CODE_BLOCK_{i}]", code)

    return text


def convert_bullets_to_prose(text: str) -> str:
    """
    Convert bullet points and numbered lists to flowing prose.

    Args:
        text: Text with bullet points or numbered lists

    Returns:
        Prose version of the text
    """
    if not text:
        return text

    lines = text.split('\n')
    result_lines = []
    bullet_items = []

    def flush_bullets():
        """Convert accumulated bullets to prose."""
        nonlocal bullet_items
        if not bullet_items:
            return

        # Join bullets into prose
        if len(bullet_items) == 1:
            result_lines.append(bullet_items[0])
        else:
            # Join with commas and 'and'
            prose = join_list_naturally(bullet_items)
            result_lines.append(prose)

        bullet_items = []

    for line in lines:
        line = line.strip()

        # Check for bullet
        bullet_match = re.match(r'^[-*+]\s+(.+)$', line)
        number_match = re.match(r'^\d+[.)]\s+(.+)$', line)

        if bullet_match:
            bullet_items.append(bullet_match.group(1).strip())
        elif number_match:
            bullet_items.append(number_match.group(1).strip())
        else:
            # Flush any accumulated bullets
            flush_bullets()
            if line:
                result_lines.append(line)

    # Flush remaining bullets
    flush_bullets()

    return '\n'.join(result_lines)


def join_list_naturally(items: List[str]) -> str:
    """
    Join a list of items into natural prose.

    Examples:
        ["A"] -> "A"
        ["A", "B"] -> "A and B"
        ["A", "B", "C"] -> "A, B, and C"
    """
    if not items:
        return ""

    if len(items) == 1:
        item = items[0]
        # Ensure ends with period
        if not item.endswith(('.', '!', '?')):
            item += '.'
        return item

    if len(items) == 2:
        result = f"{items[0]} and {items[1]}"
        if not result.endswith(('.', '!', '?')):
            result += '.'
        return result

    # Three or more items
    result = ", ".join(items[:-1]) + f", and {items[-1]}"
    if not result.endswith(('.', '!', '?')):
        result += '.'
    return result


# =============================================================================
# PROSE CONVERSION
# =============================================================================

def convert_to_prose(
    content: str,
    preserve_code: bool = False,
    style: str = "natural",
) -> str:
    """
    Convert any content to natural prose.

    This is the main function for ensuring user-facing responses
    are in clean, natural prose without markdown formatting.

    Args:
        content: Content that may contain markdown or structured text
        preserve_code: If True, preserve code blocks
        style: "natural" (default), "formal", or "concise"

    Returns:
        Natural prose suitable for user display
    """
    if not content:
        return content

    # Step 1: Strip markdown (except code if preserving)
    text = strip_markdown(content, preserve_code=preserve_code)

    # Step 2: Convert bullets to prose
    text = convert_bullets_to_prose(text)

    # Step 3: Clean up whitespace
    text = clean_whitespace(text)

    # Step 4: Ensure proper sentence structure
    text = ensure_sentences(text)

    # Step 5: Apply style
    if style == "formal":
        text = formalize(text)
    elif style == "concise":
        text = concisify(text)

    return text


def clean_whitespace(text: str) -> str:
    """Clean up extra whitespace."""
    if not text:
        return text

    # Replace multiple newlines with double newline
    text = re.sub(r'\n{3,}', '\n\n', text)

    # Replace multiple spaces with single space
    text = re.sub(r'[ \t]+', ' ', text)

    # Remove leading/trailing whitespace from lines
    lines = [line.strip() for line in text.split('\n')]
    text = '\n'.join(lines)

    return text.strip()


def ensure_sentences(text: str) -> str:
    """Ensure text has proper sentence structure."""
    if not text:
        return text

    lines = text.split('\n')
    result = []

    for line in lines:
        line = line.strip()
        if not line:
            result.append('')
            continue

        # Skip code blocks
        if line.startswith('```') or line.startswith('    '):
            result.append(line)
            continue

        # Ensure ends with punctuation
        if line and not line[-1] in '.!?:':
            line = line.rstrip(',;') + '.'

        # Capitalize first letter if it's a new sentence
        if line and line[0].islower():
            # Check if previous line ends with sentence terminator
            if not result or (result[-1] and result[-1][-1] in '.!?\n'):
                line = line[0].upper() + line[1:]

        result.append(line)

    return '\n'.join(result)


def formalize(text: str) -> str:
    """Make text more formal."""
    if not text:
        return text

    # Replace contractions
    replacements = {
        "don't": "do not",
        "doesn't": "does not",
        "didn't": "did not",
        "won't": "will not",
        "wouldn't": "would not",
        "can't": "cannot",
        "couldn't": "could not",
        "shouldn't": "should not",
        "isn't": "is not",
        "aren't": "are not",
        "wasn't": "was not",
        "weren't": "were not",
        "haven't": "have not",
        "hasn't": "has not",
        "hadn't": "had not",
        "I'm": "I am",
        "you're": "you are",
        "we're": "we are",
        "they're": "they are",
        "it's": "it is",
        "that's": "that is",
        "there's": "there is",
        "here's": "here is",
        "what's": "what is",
        "who's": "who is",
        "let's": "let us",
    }

    for contraction, expansion in replacements.items():
        text = re.sub(re.escape(contraction), expansion, text, flags=re.IGNORECASE)

    return text


def concisify(text: str) -> str:
    """Make text more concise."""
    if not text:
        return text

    # Remove filler phrases
    filler_patterns = [
        r'\bbasically\b,?\s*',
        r'\bactually\b,?\s*',
        r'\bsimply\b,?\s*',
        r'\bjust\b\s+',
        r'\breally\b\s+',
        r'\bvery\b\s+',
        r'\bquite\b\s+',
        r'\bin order to\b',
        r'\bdue to the fact that\b',
        r'\bfor the purpose of\b',
        r'\bat the present time\b',
        r'\bin the event that\b',
        r'\bin spite of the fact that\b',
    ]

    for pattern in filler_patterns:
        text = re.sub(pattern, '', text, flags=re.IGNORECASE)

    # Replace wordy phrases
    wordy_replacements = {
        "in order to": "to",
        "due to the fact that": "because",
        "for the purpose of": "for",
        "at the present time": "now",
        "in the event that": "if",
        "in spite of the fact that": "although",
        "on a regular basis": "regularly",
        "at this point in time": "now",
        "in the near future": "soon",
    }

    for wordy, concise in wordy_replacements.items():
        text = re.sub(re.escape(wordy), concise, text, flags=re.IGNORECASE)

    return text


# =============================================================================
# TEXT REALIZER INTEGRATION
# =============================================================================

def realize_as_prose(
    answer_spec: Dict[str, Any],
    source_content: Optional[str] = None,
) -> str:
    """
    Realize an answer spec as natural prose.

    This integrates with text_realizer to ensure all output
    is in clean, natural prose.

    Args:
        answer_spec: The answer specification dict
        source_content: Optional raw source content

    Returns:
        Natural prose response
    """
    content = source_content or answer_spec.get("source_content", "")

    if not content:
        # Build from must_include facts
        must_include = answer_spec.get("must_include", [])
        if must_include:
            content = " ".join(must_include)

    if not content:
        return "I don't have information about that."

    # Convert to prose
    preserve_code = answer_spec.get("preserve_code", False)
    style = answer_spec.get("style", "natural")

    prose = convert_to_prose(content, preserve_code=preserve_code, style=style)

    # Apply length constraint if specified
    length_hint = answer_spec.get("length_hint", "medium")
    if length_hint == "short" and len(prose) > 200:
        # Truncate to first 1-2 sentences
        sentences = re.split(r'(?<=[.!?])\s+', prose)
        prose = " ".join(sentences[:2])
        if not prose.endswith(('.', '!', '?')):
            prose += '.'

    return prose


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Main functions
    "convert_to_prose",
    "realize_as_prose",
    # Helper functions
    "strip_markdown",
    "convert_bullets_to_prose",
    "join_list_naturally",
    "clean_whitespace",
    "ensure_sentences",
    "formalize",
    "concisify",
]
