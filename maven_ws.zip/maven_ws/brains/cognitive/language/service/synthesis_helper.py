"""
Synthesis Helper - Improved Fact-to-Prose Composition
=====================================================

FIX 2: This module provides improved synthesis that:
1. Composes coherent prose from facts (not just concatenation)
2. Preserves code blocks and examples when requested
3. Doesn't over-compress responses
4. Uses LLM for composition when needed (not for content generation)

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import re
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field


# =============================================================================
# SYNTHESIS CONFIGURATION
# =============================================================================

@dataclass
class SynthesisConfig:
    """Configuration for synthesis behavior."""
    preserve_code_blocks: bool = True
    preserve_examples: bool = True
    max_facts: int = 10  # Increased from 5
    min_prose_length: int = 20
    composition_mode: str = "flowing"  # "flowing", "bullet", "minimal"
    strip_markdown: bool = False  # Only strip if needed


# =============================================================================
# CODE AND EXAMPLE DETECTION
# =============================================================================

def extract_code_blocks(text: str) -> Tuple[str, List[str]]:
    """
    Extract code blocks from text.

    Returns:
        Tuple of (text_without_code, list_of_code_blocks)
    """
    code_blocks = []

    # Pattern for fenced code blocks
    fenced_pattern = r'```[\w]*\n?([\s\S]*?)```'
    matches = re.findall(fenced_pattern, text)
    code_blocks.extend(matches)

    # Pattern for indented code blocks (4+ spaces)
    indented_pattern = r'(?:^|\n)((?:    |\t).+(?:\n(?:    |\t).+)*)'
    indented_matches = re.findall(indented_pattern, text)
    code_blocks.extend(indented_matches)

    # Remove code blocks from text
    text_without_code = re.sub(fenced_pattern, '[CODE_BLOCK]', text)

    return text_without_code, code_blocks


def contains_examples(text: str) -> bool:
    """Check if text contains examples."""
    example_patterns = [
        r'\bexample\b',
        r'\bfor instance\b',
        r'\bsuch as\b',
        r'\be\.g\.\b',
        r'\bhere is\b',
        r'\blike this\b',
        r'```',  # Code block
        r'^    ',  # Indented code
    ]
    text_lower = text.lower()
    return any(re.search(p, text_lower) for p in example_patterns)


def query_wants_examples(query: str) -> bool:
    """Check if query is asking for examples or code."""
    example_keywords = [
        "example", "show me", "demonstrate", "sample",
        "code", "snippet", "script", "program",
        "how to", "how do i", "how can i",
        "step by step", "steps", "instructions",
        "illustrate", "give me an example",
    ]
    query_lower = query.lower()
    return any(kw in query_lower for kw in example_keywords)


# =============================================================================
# IMPROVED SYNTHESIS
# =============================================================================

def synthesize_coherent_response(
    facts: List[str],
    query: str = "",
    response_plan: Optional[Dict[str, Any]] = None,
    config: Optional[SynthesisConfig] = None,
) -> str:
    """
    Compose a coherent response from facts.

    This is the IMPROVED synthesis function that:
    - Composes flowing prose (not just concatenation)
    - Preserves code blocks and examples when appropriate
    - Respects the response plan's length_mode
    - Doesn't over-compress

    Args:
        facts: List of fact strings
        query: The original user query
        response_plan: Optional response plan with length_mode, etc.
        config: Optional synthesis configuration

    Returns:
        Coherent prose response
    """
    config = config or SynthesisConfig()
    response_plan = response_plan or {}

    if not facts:
        return "I don't have information about that."

    # Determine if we should preserve examples/code
    preserve_examples = config.preserve_examples and query_wants_examples(query)
    length_mode = response_plan.get("length_mode", "medium")

    # Extract and preserve code blocks if needed
    code_blocks = []
    processed_facts = []

    for fact in facts[:config.max_facts]:
        fact_str = str(fact).strip()
        if not fact_str:
            continue

        if preserve_examples and contains_examples(fact_str):
            # Preserve the entire fact including examples
            text_part, codes = extract_code_blocks(fact_str)
            processed_facts.append(text_part.replace('[CODE_BLOCK]', '').strip())
            code_blocks.extend(codes)
        else:
            # Check for code blocks even if not explicitly preserving
            if '```' in fact_str or fact_str.startswith('    '):
                text_part, codes = extract_code_blocks(fact_str)
                processed_facts.append(text_part.replace('[CODE_BLOCK]', '').strip())
                code_blocks.extend(codes)
            else:
                processed_facts.append(fact_str)

    # Remove empty and duplicate facts
    processed_facts = [f for f in processed_facts if f and len(f) > 3]
    seen = set()
    unique_facts = []
    for f in processed_facts:
        f_normalized = f.lower().strip()
        if f_normalized not in seen:
            seen.add(f_normalized)
            unique_facts.append(f)

    if not unique_facts:
        return "I don't have information about that."

    # Compose based on length mode
    if length_mode in ("short", "brief"):
        composed = _compose_short(unique_facts, query)
    elif length_mode in ("long", "detailed", "step_by_step"):
        composed = _compose_detailed(unique_facts, query, code_blocks)
    else:  # medium
        composed = _compose_medium(unique_facts, query)

    # Append preserved code blocks
    if code_blocks and preserve_examples:
        composed = _append_code_blocks(composed, code_blocks)

    # Strip markdown if configured
    if config.strip_markdown:
        composed = strip_markdown_formatting(composed)

    return composed


def _compose_short(facts: List[str], query: str) -> str:
    """Compose a short response (1-2 sentences)."""
    if len(facts) == 1:
        return _ensure_prose(facts[0], query)

    # Combine top 2 facts
    parts = [_ensure_prose(f, query) for f in facts[:2]]
    return " ".join(parts)


def _compose_medium(facts: List[str], query: str) -> str:
    """Compose a medium-length response (1-2 paragraphs)."""
    if len(facts) == 1:
        return _ensure_prose(facts[0], query)

    # Group related facts and compose paragraphs
    prose_parts = []
    for fact in facts[:5]:
        prose = _ensure_prose(fact, query)
        if prose:
            prose_parts.append(prose)

    if not prose_parts:
        return facts[0] if facts else "I don't have that information."

    # Join with proper punctuation
    result = " ".join(prose_parts)

    # Ensure it ends properly
    if result and not result.endswith(('.', '!', '?')):
        result += "."

    return result


def _compose_detailed(facts: List[str], query: str, code_blocks: List[str]) -> str:
    """Compose a detailed response with full content preserved."""
    if not facts:
        return "I don't have detailed information about that."

    # For detailed responses, preserve more structure
    prose_parts = []
    for fact in facts[:10]:  # Allow more facts for detailed
        prose = _ensure_prose(fact, query)
        if prose:
            prose_parts.append(prose)

    result = "\n\n".join(prose_parts) if len(prose_parts) > 2 else " ".join(prose_parts)

    return result


def _ensure_prose(fact: str, query: str) -> str:
    """
    Ensure a fact is in prose form.

    Converts key:value patterns to natural sentences.
    """
    if not fact:
        return ""

    # Already looks like prose
    if len(fact) > 30 and not re.match(r'^[\w_]+:\s', fact):
        # Check if it ends properly
        if not fact.endswith(('.', '!', '?', ':')):
            fact = fact.rstrip(',;') + "."
        return fact

    # Key:value pattern
    kv_match = re.match(r'^([\w_]+):\s*(.+)$', fact, re.IGNORECASE)
    if kv_match:
        key = kv_match.group(1).lower().replace('_', ' ')
        value = kv_match.group(2).strip()

        # Personal fact patterns
        query_lower = query.lower()
        if key == "name":
            return f"Your name is {value}." if "my" in query_lower else f"The name is {value}."
        if key == "location":
            return f"Your location is {value}." if "my" in query_lower else f"The location is {value}."
        if key in ("answer", "result"):
            return value  # Just the value for answers
        if key == "status":
            return f"The status is {value}."

        # Generic
        return f"The {key} is {value}."

    # Already looks like a sentence
    if not fact.endswith(('.', '!', '?')):
        fact = fact.rstrip(',;') + "."

    return fact


def _append_code_blocks(prose: str, code_blocks: List[str]) -> str:
    """Append preserved code blocks to prose."""
    if not code_blocks:
        return prose

    # Add code blocks with proper formatting
    parts = [prose.rstrip()]

    for i, code in enumerate(code_blocks[:3]):  # Limit to 3 code blocks
        code = code.strip()
        if code:
            parts.append(f"\n\n```\n{code}\n```")

    return "".join(parts)


def strip_markdown_formatting(text: str) -> str:
    """
    Strip markdown formatting from text.

    Removes headers, bold, italic, bullets while preserving content.
    Preserves code blocks.
    """
    if not text:
        return text

    # Preserve code blocks first
    code_blocks = []
    def save_code(match):
        code_blocks.append(match.group(0))
        return f"[CODE_PLACEHOLDER_{len(code_blocks)-1}]"

    text = re.sub(r'```[\s\S]*?```', save_code, text)

    # Remove headers
    text = re.sub(r'^#+\s*', '', text, flags=re.MULTILINE)

    # Remove bold/italic
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    text = re.sub(r'\*(.+?)\*', r'\1', text)
    text = re.sub(r'__(.+?)__', r'\1', text)
    text = re.sub(r'_(.+?)_', r'\1', text)

    # Convert bullets to prose
    text = re.sub(r'^\s*[-*]\s+', '', text, flags=re.MULTILINE)
    text = re.sub(r'^\s*\d+\.\s+', '', text, flags=re.MULTILINE)

    # Restore code blocks
    for i, code in enumerate(code_blocks):
        text = text.replace(f"[CODE_PLACEHOLDER_{i}]", code)

    # Clean up extra whitespace
    text = re.sub(r'\n{3,}', '\n\n', text)
    text = text.strip()

    return text


# =============================================================================
# INTEGRATION WITH EXISTING SYNTHESIS
# =============================================================================

def improved_synthesize_from_facts(
    facts: str | list,
    context: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Improved version of synthesize_from_facts.

    Drop-in replacement that:
    - Preserves code blocks and examples
    - Composes flowing prose
    - Respects length mode from response_plan

    Args:
        facts: Raw fact string or list of fact strings
        context: Optional context with query, task_type, response_plan, etc.

    Returns:
        Synthesized natural language response
    """
    context = context or {}

    # Normalize to list
    if isinstance(facts, str):
        if "\n" in facts:
            fact_list = [f.strip() for f in facts.split("\n") if f.strip()]
        else:
            fact_list = [facts.strip()]
    else:
        fact_list = [str(f).strip() for f in facts if f]

    if not fact_list:
        return "I don't have that information."

    # Get configuration from context
    query = context.get("query", "")
    response_plan = context.get("response_plan", {})

    # Build config
    config = SynthesisConfig(
        preserve_code_blocks=context.get("preserve_code", True),
        preserve_examples=context.get("preserve_examples", True),
        strip_markdown=context.get("strip_markdown", False),
    )

    return synthesize_coherent_response(
        facts=fact_list,
        query=query,
        response_plan=response_plan,
        config=config,
    )


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Config
    "SynthesisConfig",
    # Functions
    "synthesize_coherent_response",
    "improved_synthesize_from_facts",
    "extract_code_blocks",
    "contains_examples",
    "query_wants_examples",
    "strip_markdown_formatting",
]
