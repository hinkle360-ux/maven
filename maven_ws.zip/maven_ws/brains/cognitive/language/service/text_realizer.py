# brains/cognitive/language/service/text_realizer.py
"""
Text Realizer - Central Linguistic Output Layer
================================================

HYBRID MAVEN SPEC: This module makes language_brain the SINGLE place that
produces surface text. All other brains produce semantic specs, not prose.

Key principles:
1. Reasoning brains produce AnswerSpecs (structured content, not text)
2. text_realizer turns specs into Maven-voice prose
3. External LLM (Teacher) is only used for TRAINING, never for live output
4. Learning loop allows language_brain to improve without Teacher over time

This ensures Maven speaks in its own voice, not copied from external LLMs.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from enum import Enum, auto
import time
import random
import re

# FIX 2: Import prose converter for markdown stripping
try:
    from brains.cognitive.language.service.prose_converter import (
        convert_to_prose,
        strip_markdown,
    )
    _prose_converter_available = True
except ImportError:
    _prose_converter_available = False
    print("[TEXT_REALIZER] prose_converter not available, markdown stripping disabled")

# FIX 2: Import improved synthesis helper
try:
    from brains.cognitive.language.service.synthesis_helper import (
        improved_synthesize_from_facts,
        synthesize_coherent_response,
    )
    _synthesis_helper_available = True
except ImportError:
    _synthesis_helper_available = False
    print("[TEXT_REALIZER] synthesis_helper not available, using basic synthesis")

# =============================================================================
# AnswerSpec - Semantic specification for answers
# =============================================================================

class ToneStyle(Enum):
    """Tone styles for text realization."""
    CONCISE_TECHNICAL = auto()   # Short, technical, peer conversation
    EXPLANATORY = auto()          # More detailed, educational
    CASUAL = auto()               # Informal, conversational
    FORMAL = auto()               # Professional, structured


class LengthHint(Enum):
    """Length hints for text realization."""
    SINGLE_SENTENCE = auto()      # One sentence
    SHORT_PARAGRAPH = auto()      # 2-4 sentences
    MEDIUM = auto()               # 2-3 paragraphs
    DETAILED = auto()             # Full explanation


@dataclass
class AnswerSpec:
    """
    Semantic specification for an answer.

    Reasoning brains produce this instead of text. The text_realizer
    turns it into surface prose in Maven's voice.
    """
    intent: str                              # e.g., "SELF_IDENTITY", "MEMORY_MODEL"
    topic: str                               # e.g., "overview", "tier_structure"
    must_include: List[str] = field(default_factory=list)   # Key points that MUST appear
    optional_details: List[str] = field(default_factory=list)  # Extra details if space
    tone: ToneStyle = ToneStyle.CONCISE_TECHNICAL
    length_hint: LengthHint = LengthHint.SHORT_PARAGRAPH
    avoid_phrases: List[str] = field(default_factory=list)  # Phrases to avoid
    context: Dict[str, Any] = field(default_factory=dict)   # Additional context

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging/storage."""
        return {
            "intent": self.intent,
            "topic": self.topic,
            "must_include": self.must_include,
            "optional_details": self.optional_details,
            "tone": self.tone.name,
            "length_hint": self.length_hint.name,
            "avoid_phrases": self.avoid_phrases,
            "context": self.context,
        }


# =============================================================================
# Intent Maturity Tracking - For Teacher Phase-out
# =============================================================================

@dataclass
class IntentMaturity:
    """Track maturity of language_brain for each intent type."""
    successful_answers: int = 0      # Answers that didn't need correction
    teacher_fallbacks: int = 0       # Times we had to call Teacher
    heavy_paraphrases: int = 0       # Times output needed major rewriting
    last_teacher_call: float = 0.0   # Timestamp of last Teacher use
    maturity_score: float = 0.0      # Computed maturity (0.0 - 1.0)

    def update_maturity(self) -> None:
        """Recalculate maturity score based on stats."""
        total = self.successful_answers + self.teacher_fallbacks + self.heavy_paraphrases
        if total < 10:
            # Not enough data yet
            self.maturity_score = 0.0
            return

        # Maturity = success rate with penalty for recent Teacher use
        success_rate = self.successful_answers / total
        recency_penalty = 0.0
        if self.last_teacher_call > 0:
            hours_since_teacher = (time.time() - self.last_teacher_call) / 3600
            if hours_since_teacher < 24:
                recency_penalty = 0.2 * (1 - hours_since_teacher / 24)

        self.maturity_score = max(0.0, min(1.0, success_rate - recency_penalty))


# Global maturity tracking per intent
_intent_maturity: Dict[str, IntentMaturity] = {}

# Maturity threshold - above this, don't call Teacher for this intent
MATURITY_THRESHOLD = 0.7


def get_intent_maturity(intent: str) -> IntentMaturity:
    """Get or create maturity tracker for an intent."""
    if intent not in _intent_maturity:
        _intent_maturity[intent] = IntentMaturity()
    return _intent_maturity[intent]


def should_use_teacher(intent: str) -> bool:
    """Check if we should call Teacher for this intent (training mode)."""
    maturity = get_intent_maturity(intent)
    maturity.update_maturity()
    return maturity.maturity_score < MATURITY_THRESHOLD


def record_successful_answer(intent: str) -> None:
    """Record a successful answer (no corrections needed)."""
    maturity = get_intent_maturity(intent)
    maturity.successful_answers += 1
    maturity.update_maturity()


def record_teacher_fallback(intent: str) -> None:
    """Record that we had to use Teacher for this intent."""
    maturity = get_intent_maturity(intent)
    maturity.teacher_fallbacks += 1
    maturity.last_teacher_call = time.time()
    maturity.update_maturity()


# =============================================================================
# Text Realization - Turn specs into prose
# =============================================================================

# Sentence connectors for natural flow
CONNECTORS = [
    "",  # No connector (direct)
    "This means ",
    "In practice, ",
    "Specifically, ",
    "For example, ",
]

# Avoid these formulaic openers
FORMULAIC_OPENERS = [
    "let me tell you",
    "here's something interesting",
    "in other words",
    "to put it another way",
    "moving on to",
    "essentially",
    "simply put",
]


def realize_answer(spec: AnswerSpec, previous_outputs: List[str] = None) -> str:
    """
    Turn an AnswerSpec into surface text in Maven's voice.

    This is the ONLY function that should produce user-facing prose.
    All other brains produce specs, not text.

    Args:
        spec: The semantic specification for the answer
        previous_outputs: Recent outputs to avoid repetition

    Returns:
        Realized text in Maven's voice
    """
    previous_outputs = previous_outputs or []

    # Build the core content from must_include points
    sentences = []

    for i, point in enumerate(spec.must_include):
        # Clean up the point
        point = point.strip()
        if not point:
            continue

        # Ensure proper capitalization
        if point and point[0].islower():
            point = point[0].upper() + point[1:]

        # Ensure proper ending
        if not point.endswith(('.', '!', '?')):
            point = point + '.'

        # Add connector for flow (except first sentence)
        if i > 0 and spec.length_hint != LengthHint.SINGLE_SENTENCE:
            connector = random.choice(CONNECTORS[:3])  # Limit to subtle connectors
            if connector and not point.startswith(connector):
                point = connector + point[0].lower() + point[1:]

        sentences.append(point)

    # Add optional details if we have room
    if spec.length_hint in (LengthHint.MEDIUM, LengthHint.DETAILED):
        for detail in spec.optional_details[:2]:  # Limit to 2 optional details
            detail = detail.strip()
            if detail:
                if not detail.endswith(('.', '!', '?')):
                    detail = detail + '.'
                sentences.append(detail)

    # Join based on length hint
    if spec.length_hint == LengthHint.SINGLE_SENTENCE:
        # Combine into one sentence
        text = sentences[0] if sentences else ""
    elif spec.length_hint == LengthHint.SHORT_PARAGRAPH:
        # Single paragraph
        text = ' '.join(sentences)
    else:
        # Multiple paragraphs - group sentences
        if len(sentences) <= 3:
            text = ' '.join(sentences)
        else:
            mid = len(sentences) // 2
            para1 = ' '.join(sentences[:mid])
            para2 = ' '.join(sentences[mid:])
            text = f"{para1}\n\n{para2}"

    # Clean up any formulaic openers that might have slipped in
    text = _strip_formulaic_openers(text)

    # Check for repetition with previous outputs
    if previous_outputs:
        text = _ensure_unique(text, previous_outputs)

    # FIX 2: Strip markdown formatting for natural prose output
    # This ensures Maven outputs clean prose, not markdown artifacts
    if _prose_converter_available:
        text = convert_to_prose(text, preserve_code=False, style="natural")

    return text.strip()


def _strip_formulaic_openers(text: str) -> str:
    """Remove formulaic opening phrases."""
    text_lower = text.lower()
    for opener in FORMULAIC_OPENERS:
        if text_lower.startswith(opener):
            # Remove the opener and capitalize
            text = text[len(opener):].strip()
            if text:
                text = text[0].upper() + text[1:]
            break
        # Also check for "opener," or "opener:"
        for punct in [',', ':']:
            if text_lower.startswith(opener + punct):
                text = text[len(opener) + 1:].strip()
                if text:
                    text = text[0].upper() + text[1:]
                break
    return text


def _ensure_unique(text: str, previous_outputs: List[str]) -> str:
    """Ensure text is sufficiently different from previous outputs."""
    text_words = set(text.lower().split())

    for prev in previous_outputs[-5:]:
        prev_words = set(prev.lower().split())
        if text_words and prev_words:
            overlap = len(text_words & prev_words) / max(len(text_words), len(prev_words))
            if overlap > 0.8:
                # Too similar - try to vary
                sentences = text.split('. ')
                if len(sentences) > 1:
                    # Shuffle middle sentences
                    random.shuffle(sentences[1:-1] if len(sentences) > 2 else sentences)
                    text = '. '.join(sentences)
                break

    return text


def paraphrase(text: str, constraints: Dict[str, Any] = None) -> str:
    """
    Paraphrase text with given constraints.

    Args:
        text: Text to paraphrase
        constraints: Dict with:
            - avoid_phrases: List of phrases to avoid
            - similarity_cap: Max similarity to original (0.0-1.0)
            - tone: Target tone

    Returns:
        Paraphrased text
    """
    constraints = constraints or {}
    avoid_phrases = constraints.get("avoid_phrases", [])

    result = text

    # Remove any phrases we need to avoid
    for phrase in avoid_phrases:
        if phrase.lower() in result.lower():
            # Try to remove or replace the phrase
            pattern = re.compile(re.escape(phrase), re.IGNORECASE)
            result = pattern.sub("", result)

    # Clean up any double spaces or orphaned punctuation
    result = re.sub(r'\s+', ' ', result)
    result = re.sub(r'\s+([.,!?])', r'\1', result)

    return result.strip()


def compress(text: str, target_len: int) -> str:
    """
    Compress text to approximately target length.

    Args:
        text: Text to compress
        target_len: Target character length

    Returns:
        Compressed text
    """
    if len(text) <= target_len:
        return text

    # Split into sentences
    sentences = re.split(r'(?<=[.!?])\s+', text)

    # Take sentences until we hit target
    result = []
    current_len = 0

    for sentence in sentences:
        if current_len + len(sentence) + 1 <= target_len:
            result.append(sentence)
            current_len += len(sentence) + 1
        else:
            break

    if not result:
        # Target too short - return truncated first sentence
        return text[:target_len-3] + "..."

    return ' '.join(result)


# =============================================================================
# Spec Builders - Helpers for creating AnswerSpecs from intent blocks
# =============================================================================

def spec_from_intent_block(
    intent: str,
    block_text: str,
    tone: ToneStyle = ToneStyle.CONCISE_TECHNICAL,
    length_hint: LengthHint = LengthHint.SHORT_PARAGRAPH,
) -> AnswerSpec:
    """
    Create an AnswerSpec from an existing intent block text.

    This is a bridge function for transitioning from static blocks
    to spec-based realization.

    Args:
        intent: The intent name (e.g., "SELF_IDENTITY")
        block_text: The static block text to convert
        tone: Desired tone
        length_hint: Desired length

    Returns:
        AnswerSpec with must_include points extracted from block
    """
    # Split block into sentences/points
    sentences = re.split(r'(?<=[.!?])\s+', block_text)
    sentences = [s.strip() for s in sentences if s.strip()]

    # First 2-3 sentences are must_include, rest are optional
    must_include = sentences[:3]
    optional_details = sentences[3:]

    return AnswerSpec(
        intent=intent,
        topic="general",
        must_include=must_include,
        optional_details=optional_details,
        tone=tone,
        length_hint=length_hint,
    )


# =============================================================================
# Identity + Provenance Realization - Data-driven, no hardcoded prose
# =============================================================================

def realize_identity_answer(snapshot: Dict[str, Any], style: Optional[Dict[str, Any]] = None) -> str:
    """
    Convert structured SelfModelSnapshot into a natural-language identity answer.

    NO HARDCODED SELF-FACTS, only framing/ordering. All content comes from snapshot.

    Args:
        snapshot: Dict from SelfModelSnapshot.to_dict() containing:
            - name: str (e.g., "Maven")
            - system_type: str (e.g., "modular cognitive AI")
            - brains_count: int
            - tools_count: int
            - execution_mode: str
            - capabilities: List[str]
            - etc.
        style: Optional style hints (length, verbosity, etc.)

    Returns:
        Natural-language identity answer derived from structured data
    """
    style = style or {}
    length = style.get("length", "medium")

    name = snapshot.get("name", "Maven")
    system_type = snapshot.get("system_type", "AI system")
    brains_count = snapshot.get("brains_count", 0)
    tools_count = snapshot.get("tools_count", 0)
    execution_mode = snapshot.get("execution_mode", "UNKNOWN")
    capabilities = snapshot.get("capabilities", [])
    brain_names = snapshot.get("brain_names", [])

    # Build base factual utterance skeleton (minimal framing, all content from data)
    parts = []

    # Core identity (always included)
    parts.append(f"I am {name}, a {system_type}.")

    # Architecture summary (if we have counts)
    if brains_count > 0 or tools_count > 0:
        arch_part = "My current architecture includes"
        if brains_count > 0:
            arch_part += f" {brains_count} specialized brains"
        if tools_count > 0:
            if brains_count > 0:
                arch_part += f" and {tools_count} tools"
            else:
                arch_part += f" {tools_count} tools"
        arch_part += "."
        parts.append(arch_part)

    # Execution mode (if known)
    if execution_mode and execution_mode != "UNKNOWN":
        parts.append(f"I'm running in {execution_mode} mode.")

    # Short version stops here
    if length == "short":
        return " ".join(parts)

    # Medium version adds capabilities
    if capabilities and length in ("medium", "detailed"):
        cap_str = ", ".join(capabilities[:5])  # Limit to 5
        parts.append(f"I can help with: {cap_str}.")

    # Detailed version adds brain list
    if brain_names and length == "detailed":
        brain_str = ", ".join(brain_names[:10])  # Limit to 10
        parts.append(f"My brains include: {brain_str}.")

    return " ".join(parts)


def realize_provenance_answer(prov: Dict[str, Any], last_text: Optional[str] = None, style: Optional[Dict[str, Any]] = None) -> str:
    """
    Convert structured AnswerProvenance into a natural-language provenance explanation.

    NO HARDCODED PROSE, only mapping from structured metadata to clear explanation.

    Args:
        prov: Dict from AnswerProvenance.to_dict() containing:
            - source: str ("teacher", "local", "mixed")
            - self_origin: bool
            - brains_involved: List[str]
            - tools_used: List[str]
            - teacher_calls: int
            - confidence: float
            - reasoning_kind: Optional[str]
        last_text: Optional snippet of the last answer (for context)
        style: Optional style hints

    Returns:
        Natural-language provenance explanation derived from structured data
    """
    style = style or {}
    source = prov.get("source", "unknown")
    self_origin = prov.get("self_origin", False)
    brains = prov.get("brains_involved", [])
    tools = prov.get("tools_used", [])
    teacher_calls = prov.get("teacher_calls", 0)
    confidence = prov.get("confidence", 0.0)
    reasoning_kind = prov.get("reasoning_kind")

    parts = []

    # Core source explanation (always included)
    if self_origin:
        parts.append("That answer was composed directly by my internal reasoning and language systems.")
    elif source == "teacher":
        parts.append("That answer was generated with help from my external language model teacher.")
    elif source == "local":
        parts.append("That answer came from my internal knowledge and reasoning, without external LLM assistance.")
    elif source == "mixed":
        parts.append("That answer combined my internal reasoning with an external language model teacher.")
    else:
        parts.append(f"That answer came from source: {source}.")

    # Brains involved (if available)
    if brains:
        brain_list = ", ".join(brains[:5])  # Limit to 5
        parts.append(f"It flowed through these brains: {brain_list}.")

    # Tools used (if available)
    if tools:
        tool_list = ", ".join(tools[:3])  # Limit to 3
        parts.append(f"It used these tools: {tool_list}.")

    # Reasoning kind (if available)
    if reasoning_kind:
        parts.append(f"Reasoning type: {reasoning_kind}.")

    # Teacher calls (if relevant)
    if teacher_calls > 0:
        parts.append(f"I consulted the teacher {teacher_calls} time(s) during generation.")

    # Confidence (if available and meaningful)
    if confidence > 0.0:
        conf_pct = int(confidence * 100)
        parts.append(f"Confidence: {conf_pct}%.")

    return " ".join(parts)


def realize_fallback_provenance() -> str:
    """
    Return a fallback provenance explanation when no data is available.

    Returns a minimal, honest response indicating no provenance was tracked
    for the last answer. This avoids hardcoded explanations of the system.
    """
    # Return minimal response - the caller should handle generating
    # a more detailed explanation through Teacher if needed
    return "Provenance data was not recorded for that answer."


# =============================================================================
# Fact Synthesis - Convert raw facts into natural prose
# =============================================================================

def synthesize_from_facts(
    facts: str | list,
    context: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Synthesize raw facts into natural language prose.

    This is the convenience function for turning raw database-like output
    into Maven-voice responses. Used by the compositor as a fallback
    when raw facts slip through to the output layer.

    Args:
        facts: Raw fact string or list of fact strings
        context: Optional context with query, task_type, etc.

    Returns:
        Synthesized natural language response

    Examples:
        >>> synthesize_from_facts("name: Alice")
        "Your name is Alice."

        >>> synthesize_from_facts(["name: Alice", "location: Seattle"])
        "Your name is Alice. Your location is Seattle."
    """
    if not facts:
        return "I don't have that information."

    # FIX 2: Use improved synthesis helper when available
    # This preserves code examples and composes coherent prose
    if _synthesis_helper_available:
        try:
            return improved_synthesize_from_facts(facts, context)
        except Exception as e:
            print(f"[TEXT_REALIZER] improved synthesis failed: {e}, using fallback")

    context = context or {}
    query = context.get("query", "")
    task_type = context.get("task_type", "")

    # Normalize to list
    if isinstance(facts, str):
        # Check if it's multi-line
        if "\n" in facts:
            fact_list = [f.strip() for f in facts.split("\n") if f.strip()]
        else:
            fact_list = [facts.strip()]
    else:
        fact_list = [str(f).strip() for f in facts if f]

    if not fact_list:
        return "I don't have that information."

    # Build AnswerSpec for sophisticated synthesis
    must_include = []
    for fact in fact_list[:5]:  # Limit to 5 facts
        # Parse key:value patterns
        kv_match = re.match(r'^(\w+):\s*(.+)$', fact, re.IGNORECASE)
        if kv_match:
            key = kv_match.group(1).lower()
            value = kv_match.group(2).strip()
            must_include.append(_synthesize_single_fact(key, value, query))
        else:
            # Not a key:value pattern - use directly if it looks like prose
            if len(fact) > 10 and not fact.startswith("{") and not fact.startswith("["):
                must_include.append(fact)

    if not must_include:
        # Fallback: just use the first fact as-is
        return fact_list[0] if fact_list else "I don't have that information."

    # Determine tone and length from task_type
    if task_type in ("small_talk", "greeting"):
        tone = ToneStyle.CASUAL
        length = LengthHint.SINGLE_SENTENCE
    elif task_type in ("personal_query", "fact_lookup"):
        tone = ToneStyle.CONCISE_TECHNICAL
        length = LengthHint.SINGLE_SENTENCE
    else:
        tone = ToneStyle.CONCISE_TECHNICAL
        length = LengthHint.SHORT_PARAGRAPH

    # Create and realize the spec
    spec = AnswerSpec(
        intent=task_type.upper() if task_type else "FACTUAL",
        topic=query[:50] if query else "response",
        must_include=must_include,
        tone=tone,
        length_hint=length,
    )

    return realize_answer(spec)


def _synthesize_single_fact(key: str, value: str, query: str = "") -> str:
    """
    Synthesize a single key:value fact into natural prose.

    Args:
        key: The fact key (e.g., "name", "location")
        value: The fact value
        query: Optional query for context

    Returns:
        Natural language sentence
    """
    key_lower = key.lower()
    query_lower = query.lower()

    # Personal fact patterns
    if key_lower == "name":
        if "my" in query_lower or "i" in query_lower:
            return f"Your name is {value}."
        return f"The name is {value}."

    if key_lower == "location":
        if "my" in query_lower:
            return f"Your location is {value}."
        return f"The location is {value}."

    if key_lower == "email":
        return f"Your email is {value}."

    if key_lower == "phone":
        return f"Your phone number is {value}."

    if key_lower in ("preference", "pref"):
        return f"You prefer {value}."

    if key_lower in ("favorite", "favourite"):
        return f"Your favorite is {value}."

    # Answer/result patterns
    if key_lower in ("answer", "result", "output"):
        return value  # Just the value for answers

    if key_lower == "status":
        return f"The status is {value}."

    # Math patterns
    if key_lower in ("sum", "total", "product", "difference"):
        return f"The {key_lower} is {value}."

    # Generic pattern
    readable_key = key.replace("_", " ")
    return f"The {readable_key} is {value}."


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Data classes
    "AnswerSpec",
    "ToneStyle",
    "LengthHint",
    "IntentMaturity",
    # Maturity tracking
    "get_intent_maturity",
    "should_use_teacher",
    "record_successful_answer",
    "record_teacher_fallback",
    "MATURITY_THRESHOLD",
    # Text realization
    "realize_answer",
    "paraphrase",
    "compress",
    # Fact synthesis (for compositor fallback)
    "synthesize_from_facts",
    # Identity + Provenance (new)
    "realize_identity_answer",
    "realize_provenance_answer",
    "realize_fallback_provenance",
    # Helpers
    "spec_from_intent_block",
]
