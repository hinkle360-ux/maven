"""
Fact-Locking Rewrite Pipeline
=============================

A constrained content-transformer that guarantees fact preservation
during tone/style rewrites. Compensates for LLM sloppiness on
fact-preserving rewrites.

Architecture:
    FactExtractor -> ConstrainedRewriter -> RewriteValidator -> RewriteOrchestrator

Usage:
    from brains.cognitive.language.service.fact_lock_rewriter import rewrite_with_fact_lock

    result = rewrite_with_fact_lock(
        original_text="A man walks into a bar...",
        target_tone="sarcastic",
        llm_caller=my_llm_function
    )
"""

from __future__ import annotations

import re
import json
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional, Callable, Tuple
from enum import Enum


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class ExtractedFacts:
    """Structured fact list extracted from text."""
    entities: List[str] = field(default_factory=list)  # people, places, orgs
    objects: List[str] = field(default_factory=list)   # key objects with attributes
    numbers: List[Dict[str, Any]] = field(default_factory=list)  # label + value
    relations: List[Dict[str, str]] = field(default_factory=list)  # subject-relation-object
    conditions: List[str] = field(default_factory=list)  # status/conditions
    critical_phrases: List[str] = field(default_factory=list)  # must-not-change phrases

    def to_prompt_format(self) -> str:
        """Format facts for inclusion in LLM prompt."""
        lines = []

        if self.entities:
            # Ensure all entities are strings
            entity_strs = [str(e) for e in self.entities if e]
            lines.append(f"Entities: {', '.join(entity_strs)}")

        if self.objects:
            # Ensure all objects are strings
            obj_strs = [str(o) for o in self.objects if o]
            lines.append(f"Key objects: {', '.join(obj_strs)}")

        if self.numbers:
            # Handle both dict and non-dict items safely
            num_strs = []
            for n in self.numbers:
                if isinstance(n, dict):
                    num_strs.append(f"{n.get('label', 'value')}: {n.get('value', '')}")
                else:
                    num_strs.append(str(n))
            lines.append(f"Numbers: {', '.join(num_strs)}")

        if self.relations:
            # Handle both dict and non-dict items safely
            rel_strs = []
            for r in self.relations:
                if isinstance(r, dict):
                    rel_strs.append(f"{r.get('subject', '')} {r.get('relation', '')} {r.get('object', '')}")
                else:
                    rel_strs.append(str(r))
            lines.append(f"Relations: {'; '.join(rel_strs)}")

        if self.conditions:
            # Ensure all conditions are strings
            cond_strs = [str(c) for c in self.conditions if c]
            lines.append(f"Conditions/Status: {'; '.join(cond_strs)}")

        if self.critical_phrases:
            # Ensure all phrases are strings
            phrase_strs = [str(p) for p in self.critical_phrases if p]
            lines.append(f"Critical phrases (must preserve meaning): {'; '.join(phrase_strs)}")

        return "\n".join(lines)

    def get_all_keywords(self) -> List[str]:
        """Get all keywords that should appear in rewrite."""
        keywords = []
        keywords.extend(self.entities)
        keywords.extend(self.objects)
        keywords.extend(self.critical_phrases)
        for n in self.numbers:
            if 'value' in n:
                keywords.append(str(n['value']))
        return keywords


class ViolationType(Enum):
    """Types of fact violations in rewrites."""
    MISSING_ENTITY = "missing_entity"
    MISSING_OBJECT = "missing_object"
    CHANGED_ATTRIBUTE = "changed_attribute"
    MISSING_NUMBER = "missing_number"
    MISSING_CONDITION = "missing_condition"
    ADDED_UNSUPPORTED_FACT = "added_unsupported_fact"
    FORMAT_VIOLATION = "format_violation"
    LENGTH_VIOLATION = "length_violation"


@dataclass
class ValidationResult:
    """Result of rewrite validation."""
    valid: bool
    violations: List[Dict[str, Any]] = field(default_factory=list)
    score: float = 0.0  # 0.0 to 1.0

    def add_violation(self, vtype: ViolationType, detail: str, severity: float = 1.0):
        """Add a violation to the result."""
        self.violations.append({
            "type": vtype.value,
            "detail": detail,
            "severity": severity
        })
        self.valid = False


@dataclass
class RewriteResult:
    """Final result of the rewrite pipeline."""
    success: bool
    rewritten_text: str
    original_text: str
    facts: Optional[ExtractedFacts] = None
    validation: Optional[ValidationResult] = None
    attempts: int = 0
    all_candidates: List[str] = field(default_factory=list)
    error: Optional[str] = None


# =============================================================================
# FACT EXTRACTOR
# =============================================================================

class FactExtractor:
    """
    Extracts structured facts from text.

    Uses LLM in extraction mode with strict schema, plus rule-based fallbacks.
    """

    # Common color words to detect
    COLORS = {"red", "blue", "green", "yellow", "black", "white", "orange",
              "purple", "pink", "brown", "gray", "grey", "crimson", "scarlet",
              "azure", "golden", "silver"}

    # Common relation patterns
    RELATION_PATTERNS = [
        (r"(\w+)\s+(?:doesn't|does not|don't|do not)\s+(\w+)\s+(\w+)", "negative"),
        (r"(\w+)\s+(?:can't|cannot)\s+(\w+)\s+(\w+)", "inability"),
        (r"(\w+)\s+(?:forgot|forgets|doesn't remember)\s+(\w+)", "memory_gap"),
    ]

    def __init__(self, llm_caller: Optional[Callable] = None):
        self.llm_caller = llm_caller

    def extract(self, text: str, task_hint: str = "") -> ExtractedFacts:
        """
        Extract facts from text.

        Args:
            text: Original text to extract facts from
            task_hint: Optional hint about the task (e.g., "tone change, facts must be preserved")

        Returns:
            ExtractedFacts structure
        """
        facts = ExtractedFacts()

        # Layer 1: Rule-based extraction (fast, reliable)
        facts = self._rule_based_extraction(text, facts)

        # Layer 2: LLM-based extraction (if available)
        if self.llm_caller:
            facts = self._llm_extraction(text, facts, task_hint)

        # Normalize and deduplicate
        facts = self._normalize_facts(facts)

        return facts

    def _rule_based_extraction(self, text: str, facts: ExtractedFacts) -> ExtractedFacts:
        """Fast rule-based fact extraction."""
        text_lower = text.lower()
        words = text.split()

        # Extract colors + adjacent nouns (e.g., "red notebook")
        for i, word in enumerate(words):
            word_clean = word.lower().strip('.,!?;:')
            if word_clean in self.COLORS:
                # Get the next word as the object
                if i + 1 < len(words):
                    obj = words[i + 1].strip('.,!?;:')
                    facts.objects.append(f"{word_clean} {obj}")
                    facts.critical_phrases.append(f"{word_clean} {obj}")

        # Extract common entities
        entity_patterns = [
            r'\b(man|woman|person|guy|bartender|waiter|customer)\b',
            r'\b(bar|restaurant|pub|tavern|cafe)\b',
        ]
        for pattern in entity_patterns:
            matches = re.findall(pattern, text_lower)
            facts.entities.extend(matches)

        # Extract numbers
        number_matches = re.findall(r'\b(\d+)\b', text)
        for num in number_matches:
            facts.numbers.append({"label": "number", "value": num})

        # Extract word numbers
        word_nums = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
                     "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10}
        for word, val in word_nums.items():
            if word in text_lower:
                facts.numbers.append({"label": word, "value": val})

        # Extract memory/recognition conditions
        memory_patterns = [
            r"(doesn't|does not|don't|do not)\s+remember",
            r"(can't|cannot)\s+recall",
            r"(forgot|forgotten)",
            r"no\s+(memory|recognition|recollection)",
        ]
        for pattern in memory_patterns:
            if re.search(pattern, text_lower):
                # Find what's being forgotten
                context = re.search(r'(\w+)\s+' + pattern, text_lower)
                if context:
                    facts.conditions.append(f"{context.group(1)} has memory gap")
                else:
                    facts.conditions.append("memory/recognition issue present")

        # Extract "drops/dropped" actions with objects
        drop_match = re.search(r'drops?\s+(?:a\s+)?(\w+\s+\w+|\w+)', text_lower)
        if drop_match:
            facts.relations.append({
                "subject": "someone",
                "relation": "drops",
                "object": drop_match.group(1)
            })
            facts.critical_phrases.append(f"drops {drop_match.group(1)}")

        return facts

    def _llm_extraction(self, text: str, facts: ExtractedFacts, task_hint: str) -> ExtractedFacts:
        """LLM-based fact extraction for deeper understanding."""
        prompt = f"""Extract all concrete facts from this text. Output as JSON.

Text: {text}

Task context: {task_hint if task_hint else "General fact extraction for preservation"}

Extract:
1. entities: list of people, places, organizations mentioned
2. objects: list of physical objects with their attributes (color, size, etc.)
3. numbers: list of {{label, value}} for any numbers/quantities
4. relations: list of {{subject, relation, object}} for causal/action relationships
5. conditions: list of states or conditions (e.g., "X doesn't remember Y")

Output ONLY valid JSON, no explanation:
{{"entities": [], "objects": [], "numbers": [], "relations": [], "conditions": []}}"""

        try:
            response = self.llm_caller(prompt)
            if response and not response.startswith("[LLM ERROR"):
                # Try to parse JSON from response
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    data = json.loads(json_match.group())

                    # Ensure data is a dict
                    if not isinstance(data, dict):
                        data = {}

                    # Merge with existing facts - with type safety
                    if 'entities' in data and isinstance(data['entities'], list):
                        for e in data['entities']:
                            if isinstance(e, str):
                                facts.entities.append(e)
                            elif isinstance(e, dict):
                                # Extract name/value from dict
                                facts.entities.append(str(e.get('name', e.get('value', str(e)))))

                    if 'objects' in data and isinstance(data['objects'], list):
                        for o in data['objects']:
                            if isinstance(o, str):
                                facts.objects.append(o)
                            elif isinstance(o, dict):
                                facts.objects.append(str(o.get('name', o.get('description', str(o)))))

                    if 'numbers' in data and isinstance(data['numbers'], list):
                        for n in data['numbers']:
                            if isinstance(n, dict):
                                facts.numbers.append(n)
                            elif isinstance(n, (int, float, str)):
                                facts.numbers.append({"label": "value", "value": n})

                    if 'relations' in data and isinstance(data['relations'], list):
                        for r in data['relations']:
                            if isinstance(r, dict):
                                facts.relations.append(r)
                            elif isinstance(r, str):
                                facts.relations.append({"subject": "", "relation": r, "object": ""})

                    if 'conditions' in data and isinstance(data['conditions'], list):
                        for c in data['conditions']:
                            if isinstance(c, str):
                                facts.conditions.append(c)
                            elif isinstance(c, dict):
                                facts.conditions.append(str(c.get('description', c.get('condition', str(c)))))
        except Exception:
            pass  # Fall back to rule-based only

        return facts

    def _normalize_facts(self, facts: ExtractedFacts) -> ExtractedFacts:
        """Normalize and deduplicate facts."""
        # Lowercase and deduplicate entities
        facts.entities = list(set(e.lower().strip() for e in facts.entities if e))

        # Deduplicate objects
        facts.objects = list(set(o.lower().strip() for o in facts.objects if o))

        # Deduplicate conditions
        facts.conditions = list(set(c.lower().strip() for c in facts.conditions if c))

        # Deduplicate critical phrases
        facts.critical_phrases = list(set(p.lower().strip() for p in facts.critical_phrases if p))

        return facts


# =============================================================================
# CONSTRAINED REWRITER
# =============================================================================

class ConstrainedRewriter:
    """
    Rewrites text with explicit fact constraints.

    Uses a hardened prompt that shoves facts in the LLM's face and
    explicitly defines allowed vs forbidden changes.
    """

    SYSTEM_PROMPT = """You are a precise rewriter.
Task: change the tone of the text while keeping all facts unchanged.
Facts include entities, relationships, numbers, and concrete events.
Do not change what happened, who did it, where it happened, or any numbers, colors, or specific attributes.
Only change: tone, wording, sentence structure, and style.
Do not add new events or new factual details.
Do not remove any events or factual details.
Output only the rewritten text, no explanations."""

    def __init__(self, llm_caller: Callable):
        self.llm_caller = llm_caller

    def rewrite(
        self,
        original_text: str,
        facts: ExtractedFacts,
        target_tone: str,
        format_requirements: str = "single paragraph",
        length_requirements: str = "",
        additional_rules: List[str] = None
    ) -> str:
        """
        Generate a constrained rewrite.

        Args:
            original_text: Text to rewrite
            facts: Extracted facts that must be preserved
            target_tone: Target tone (e.g., "sarcastic", "noir", "formal")
            format_requirements: Format constraints
            length_requirements: Length constraints
            additional_rules: Extra rules to enforce

        Returns:
            Candidate rewritten text
        """
        # Build the hardened prompt
        prompt = self._build_prompt(
            original_text, facts, target_tone,
            format_requirements, length_requirements, additional_rules
        )

        # Call LLM
        response = self.llm_caller(prompt)

        # Clean up response
        response = self._clean_response(response)

        return response

    def _build_prompt(
        self,
        original_text: str,
        facts: ExtractedFacts,
        target_tone: str,
        format_requirements: str,
        length_requirements: str,
        additional_rules: List[str] = None
    ) -> str:
        """Build the constrained rewriter prompt."""

        # Format facts for prompt
        fact_list = facts.to_prompt_format()

        # Build rules section
        rules = [
            "Do not contradict any fact in the fact list.",
            "Do not introduce any new concrete facts that are not implied.",
            "Do not remove any important factual detail.",
        ]

        # Add specific rules for critical phrases
        if facts.critical_phrases:
            rules.append(f"Must preserve the meaning of: {', '.join(facts.critical_phrases)}")

        # Add specific rules for conditions (like memory gaps)
        if facts.conditions:
            rules.append(f"Must clearly convey these conditions: {'; '.join(facts.conditions)}")

        # Add specific rules for objects
        if facts.objects:
            rules.append(f"Must mention these objects: {', '.join(facts.objects)}")

        if additional_rules:
            rules.extend(additional_rules)

        rules_text = "\n".join(f"- {r}" for r in rules)

        prompt = f"""{self.SYSTEM_PROMPT}

---

Original text:
{original_text}

---

Extracted facts (must remain true and complete in your rewrite):
{fact_list}

---

Transformation instructions:
- Target tone: {target_tone}
- Format: {format_requirements}
{f'- Length: {length_requirements}' if length_requirements else ''}

Rules (follow strictly):
{rules_text}

You may:
- change wording
- change sentence boundaries
- change tone and style
- compress or expand slightly, as long as all facts remain

---

Output:
A single rewritten version in the requested tone.
No bullet points, no numbering, no commentary.
Just the rewritten text:"""

        return prompt

    def _clean_response(self, response: str) -> str:
        """Clean up LLM response."""
        # Remove common prefixes
        prefixes_to_remove = [
            "Here's the rewritten text:",
            "Here is the rewritten text:",
            "Rewritten:",
            "Output:",
        ]

        response = response.strip()
        for prefix in prefixes_to_remove:
            if response.lower().startswith(prefix.lower()):
                response = response[len(prefix):].strip()

        # Remove quotes if wrapped
        if response.startswith('"') and response.endswith('"'):
            response = response[1:-1]

        return response.strip()


# =============================================================================
# REWRITE VALIDATOR
# =============================================================================

class RewriteValidator:
    """
    Multi-layer validator for fact-preserving rewrites.

    Layer 1: Cheap lexical/entity check
    Layer 2: LLM-based factual consistency check
    Layer 3: Format/length constraint check
    """

    # Synonym groups for flexible matching
    SYNONYMS = {
        "red": {"red", "crimson", "scarlet", "ruby", "vermilion"},
        "blue": {"blue", "azure", "cobalt", "navy", "sapphire"},
        "notebook": {"notebook", "journal", "book", "notepad", "pad"},
        "bartender": {"bartender", "barkeeper", "barkeep", "barman", "server"},
        "bar": {"bar", "pub", "tavern", "saloon"},
        "man": {"man", "guy", "fellow", "gentleman", "person", "he", "him"},
        "remember": {"remember", "recall", "recognize", "recollect"},
    }

    def __init__(self, llm_caller: Optional[Callable] = None):
        self.llm_caller = llm_caller

    def validate(
        self,
        original_text: str,
        facts: ExtractedFacts,
        candidate: str,
        format_requirements: str = "",
        max_length: int = 0,
        min_length: int = 0
    ) -> ValidationResult:
        """
        Validate a candidate rewrite against facts and constraints.

        Args:
            original_text: Original text
            facts: Extracted facts
            candidate: Candidate rewrite to validate
            format_requirements: Format constraints (e.g., "no lists")
            max_length: Maximum word count (0 = no limit)
            min_length: Minimum word count (0 = no limit)

        Returns:
            ValidationResult with valid flag and violations
        """
        result = ValidationResult(valid=True, score=1.0)

        # Layer 1: Lexical/entity check (fast)
        result = self._lexical_check(facts, candidate, result)

        # Layer 2: LLM-based consistency check (if available and layer 1 passed)
        if result.valid and self.llm_caller:
            result = self._llm_consistency_check(facts, candidate, result)

        # Layer 3: Format/constraint check
        result = self._format_check(candidate, format_requirements, max_length, min_length, result)

        # Calculate final score
        if result.violations:
            total_severity = sum(v.get("severity", 1.0) for v in result.violations)
            result.score = max(0.0, 1.0 - (total_severity * 0.2))

        return result

    def _lexical_check(self, facts: ExtractedFacts, candidate: str, result: ValidationResult) -> ValidationResult:
        """Layer 1: Fast lexical/entity check."""
        candidate_lower = candidate.lower()

        # Check entities
        for entity in facts.entities:
            if not self._flexible_match(entity, candidate_lower):
                result.add_violation(
                    ViolationType.MISSING_ENTITY,
                    f"Missing entity: {entity}",
                    severity=0.8
                )

        # Check objects (with color attributes)
        for obj in facts.objects:
            if not self._flexible_match(obj, candidate_lower):
                result.add_violation(
                    ViolationType.MISSING_OBJECT,
                    f"Missing object: {obj}",
                    severity=1.0  # High severity for missing objects
                )

        # Check conditions (memory gaps, etc.)
        for condition in facts.conditions:
            # More flexible check for conditions
            condition_words = condition.lower().split()
            key_words = [w for w in condition_words if len(w) > 3]
            matches = sum(1 for w in key_words if w in candidate_lower or
                         any(syn in candidate_lower for syn in self.SYNONYMS.get(w, set())))
            if matches < len(key_words) * 0.5:
                result.add_violation(
                    ViolationType.MISSING_CONDITION,
                    f"Missing condition: {condition}",
                    severity=0.9
                )

        # Check critical phrases
        for phrase in facts.critical_phrases:
            if not self._flexible_match(phrase, candidate_lower):
                result.add_violation(
                    ViolationType.MISSING_OBJECT,
                    f"Missing critical phrase: {phrase}",
                    severity=1.0
                )

        return result

    def _flexible_match(self, target: str, text: str) -> bool:
        """Check if target (or synonyms) appears in text."""
        target_lower = target.lower()

        # Direct match
        if target_lower in text:
            return True

        # Check each word with synonyms
        target_words = target_lower.split()
        matches = 0
        for word in target_words:
            if word in text:
                matches += 1
            else:
                # Check synonyms
                for syn_group in self.SYNONYMS.values():
                    if word in syn_group:
                        if any(syn in text for syn in syn_group):
                            matches += 1
                            break

        # Require most words to match
        return matches >= len(target_words) * 0.7

    def _llm_consistency_check(self, facts: ExtractedFacts, candidate: str, result: ValidationResult) -> ValidationResult:
        """Layer 2: LLM-based factual consistency check."""
        prompt = f"""Compare these facts against the rewritten text.

FACTS:
{facts.to_prompt_format()}

REWRITTEN TEXT:
{candidate}

List any problems:
1. Facts from the list that are missing or contradicted in the text
2. New factual claims in the text that weren't in the original facts

Output as JSON:
{{"missing_facts": [], "contradictions": [], "new_claims": []}}

If no problems, output: {{"missing_facts": [], "contradictions": [], "new_claims": []}}"""

        try:
            response = self.llm_caller(prompt)
            if response and not response.startswith("[LLM ERROR"):
                json_match = re.search(r'\{.*\}', response, re.DOTALL)
                if json_match:
                    data = json.loads(json_match.group())

                    for missing in data.get("missing_facts", []):
                        if missing:
                            result.add_violation(
                                ViolationType.MISSING_ENTITY,
                                f"LLM detected missing: {missing}",
                                severity=0.7
                            )

                    for contradiction in data.get("contradictions", []):
                        if contradiction:
                            result.add_violation(
                                ViolationType.CHANGED_ATTRIBUTE,
                                f"LLM detected contradiction: {contradiction}",
                                severity=1.0
                            )

                    for new_claim in data.get("new_claims", []):
                        if new_claim:
                            result.add_violation(
                                ViolationType.ADDED_UNSUPPORTED_FACT,
                                f"LLM detected new claim: {new_claim}",
                                severity=0.5
                            )
        except Exception:
            pass  # Continue with other checks

        return result

    def _format_check(
        self,
        candidate: str,
        format_requirements: str,
        max_length: int,
        min_length: int,
        result: ValidationResult
    ) -> ValidationResult:
        """Layer 3: Format and length constraint check."""

        # Check for lists/bullets if forbidden
        if "no list" in format_requirements.lower() or "no bullet" in format_requirements.lower():
            if re.search(r'^\s*[-*•]\s', candidate, re.MULTILINE):
                result.add_violation(
                    ViolationType.FORMAT_VIOLATION,
                    "Contains bullet points",
                    severity=0.8
                )
            if re.search(r'^\s*\d+[.):]\s', candidate, re.MULTILINE):
                result.add_violation(
                    ViolationType.FORMAT_VIOLATION,
                    "Contains numbered list",
                    severity=0.8
                )

        # Check for single paragraph if required
        if "single paragraph" in format_requirements.lower():
            paragraphs = [p.strip() for p in candidate.split('\n\n') if p.strip()]
            if len(paragraphs) > 1:
                result.add_violation(
                    ViolationType.FORMAT_VIOLATION,
                    f"Multiple paragraphs ({len(paragraphs)})",
                    severity=0.6
                )

        # Length checks
        word_count = len(candidate.split())
        if max_length > 0 and word_count > max_length:
            result.add_violation(
                ViolationType.LENGTH_VIOLATION,
                f"Too long: {word_count} words (max: {max_length})",
                severity=0.5
            )
        if min_length > 0 and word_count < min_length:
            result.add_violation(
                ViolationType.LENGTH_VIOLATION,
                f"Too short: {word_count} words (min: {min_length})",
                severity=0.5
            )

        # Check for meta-talk
        meta_patterns = [
            r"as an ai",
            r"language model",
            r"i cannot",
            r"i'm sorry",
            r"here's the rewritten",
            r"here is the rewritten",
        ]
        for pattern in meta_patterns:
            if re.search(pattern, candidate.lower()):
                result.add_violation(
                    ViolationType.FORMAT_VIOLATION,
                    f"Contains meta-talk: {pattern}",
                    severity=0.9
                )

        return result


# =============================================================================
# REWRITE ORCHESTRATOR
# =============================================================================

class RewriteOrchestrator:
    """
    Main orchestration layer for fact-locked rewrites.

    Loop: extract -> rewrite -> validate -> retry or return
    """

    def __init__(
        self,
        llm_caller: Callable,
        max_retries: int = 3,
        use_repair_mode: bool = True
    ):
        self.llm_caller = llm_caller
        self.max_retries = max_retries
        self.use_repair_mode = use_repair_mode

        self.extractor = FactExtractor(llm_caller)
        self.rewriter = ConstrainedRewriter(llm_caller)
        self.validator = RewriteValidator(llm_caller)

    def rewrite(
        self,
        original_text: str,
        target_tone: str,
        format_requirements: str = "single paragraph, no lists",
        length_requirements: str = "",
        max_length: int = 0,
        min_length: int = 0,
        additional_rules: List[str] = None
    ) -> RewriteResult:
        """
        Execute the full rewrite pipeline with validation and retry.

        Args:
            original_text: Text to rewrite
            target_tone: Target tone
            format_requirements: Format constraints
            length_requirements: Length description
            max_length: Max word count
            min_length: Min word count
            additional_rules: Extra rules

        Returns:
            RewriteResult with success status and rewritten text
        """
        result = RewriteResult(
            success=False,
            rewritten_text="",
            original_text=original_text
        )

        try:
            # Step 1: Extract facts
            facts = self.extractor.extract(
                original_text,
                task_hint=f"Tone change to {target_tone}, facts must be preserved"
            )
            result.facts = facts

            # Step 2-4: Generate, validate, retry loop
            best_candidate = ""
            best_validation = ValidationResult(valid=False, score=0.0)

            for attempt in range(self.max_retries):
                result.attempts = attempt + 1

                try:
                    # Generate candidate
                    if attempt == 0 or not self.use_repair_mode:
                        # Fresh generation
                        candidate = self.rewriter.rewrite(
                            original_text,
                            facts,
                            target_tone,
                            format_requirements,
                            length_requirements,
                            additional_rules
                        )
                    else:
                        # Repair mode: tell LLM what was wrong
                        candidate = self._repair_rewrite(
                            original_text,
                            facts,
                            best_candidate,
                            best_validation,
                            target_tone,
                            format_requirements
                        )

                    if not candidate:
                        continue

                    result.all_candidates.append(candidate)

                    # Validate
                    validation = self.validator.validate(
                        original_text,
                        facts,
                        candidate,
                        format_requirements,
                        max_length,
                        min_length
                    )

                    # Track best candidate
                    if validation.score > best_validation.score:
                        best_candidate = candidate
                        best_validation = validation

                    # Check if valid
                    if validation.valid:
                        result.success = True
                        result.rewritten_text = candidate
                        result.validation = validation
                        return result

                except Exception as inner_e:
                    # Log but continue trying
                    result.error = f"Attempt {attempt + 1} failed: {inner_e}"
                    continue

            # Return best candidate even if not perfect
            result.rewritten_text = best_candidate
            result.validation = best_validation
            result.success = best_validation.score >= 0.7  # Partial success threshold

            if not result.success and not result.error:
                result.error = f"Failed after {self.max_retries} attempts. Violations: {best_validation.violations}"

        except Exception as e:
            # Fallback: do a plain rewrite without fact-lock
            result.error = f"Fact-lock pipeline error: {e}. Falling back to plain rewrite."
            try:
                fallback_prompt = f"Rewrite this text in a {target_tone} tone: {original_text}"
                result.rewritten_text = self.llm_caller(fallback_prompt)
                result.success = bool(result.rewritten_text and not result.rewritten_text.startswith("["))
            except Exception:
                pass

        return result

    def _repair_rewrite(
        self,
        original_text: str,
        facts: ExtractedFacts,
        previous_candidate: str,
        validation: ValidationResult,
        target_tone: str,
        format_requirements: str
    ) -> str:
        """Generate a repair prompt based on previous validation failures."""

        violations_text = "\n".join(
            f"- {v['type']}: {v['detail']}"
            for v in validation.violations
        )

        prompt = f"""Your previous rewrite had problems. Fix them.

ORIGINAL TEXT:
{original_text}

FACTS TO PRESERVE:
{facts.to_prompt_format()}

YOUR PREVIOUS REWRITE:
{previous_candidate}

PROBLEMS WITH YOUR REWRITE:
{violations_text}

INSTRUCTIONS:
1. Keep the {target_tone} tone
2. Fix all the problems listed above
3. Make sure all facts are preserved
4. Format: {format_requirements}

Output ONLY the fixed rewrite, no explanation:"""

        response = self.llm_caller(prompt)
        return self.rewriter._clean_response(response)


# =============================================================================
# CONVENIENCE FUNCTION
# =============================================================================

def rewrite_with_fact_lock(
    original_text: str,
    target_tone: str,
    llm_caller: Callable,
    format_requirements: str = "single paragraph, no lists",
    max_retries: int = 3
) -> RewriteResult:
    """
    Convenience function for fact-locked rewrites.

    Args:
        original_text: Text to rewrite
        target_tone: Target tone (e.g., "sarcastic", "formal", "noir")
        llm_caller: Function that takes prompt and returns response string
        format_requirements: Format constraints
        max_retries: Maximum retry attempts

    Returns:
        RewriteResult with success status and rewritten text

    Example:
        result = rewrite_with_fact_lock(
            "A man walks into a bar...",
            "sarcastic",
            lambda p: ollama_call(p)
        )
        if result.success:
            print(result.rewritten_text)
    """
    orchestrator = RewriteOrchestrator(
        llm_caller=llm_caller,
        max_retries=max_retries
    )

    return orchestrator.rewrite(
        original_text=original_text,
        target_tone=target_tone,
        format_requirements=format_requirements
    )


# =============================================================================
# INTENT DETECTION FOR ROUTING
# =============================================================================

def is_rewrite_with_constraints_task(query: str) -> bool:
    """
    Detect if a query is a rewrite-with-constraints task.

    Used by router to decide when to use the heavy fact-lock pipeline.
    """
    query_lower = query.lower()

    # Rewrite patterns
    rewrite_patterns = [
        r"rewrite.*(tone|style|formal|casual|sarcastic)",
        r"change.*(tone|style).*(?:keep|preserve|same).*fact",
        r"(?:keep|preserve).*fact.*(?:rewrite|change)",
        r"paraphrase.*(?:without|keep).*meaning",
        r"(?:formalize|simplify).*(?:keep|preserve)",
        r"same.*(?:fact|detail|information).*different.*(tone|style)",
    ]

    for pattern in rewrite_patterns:
        if re.search(pattern, query_lower):
            return True

    return False
