"""
Reflexion Agent
===============

Full reflexion agent implementation with trajectory management and rollback
capabilities for AGI-level self-correction.

The reflexion agent enables Maven to:
1. Track execution trajectories (sequences of actions and results)
2. Detect failures and suboptimal outcomes
3. Generate reflections on what went wrong
4. Rollback to previous states
5. Retry with learned improvements
6. Store successful patterns for future use

This implements the Reflexion architecture from Shinn et al. (2023) adapted
for Maven's multi-brain cognitive system.

Usage:
    from brains.cognitive.reflexion.service.reflexion_agent import (
        start_trajectory,
        record_action,
        evaluate_trajectory,
        generate_reflection,
        rollback_to_checkpoint,
        ReflexionAgent,
    )

    # Start tracking a task
    trajectory_id = start_trajectory("Implement user authentication")

    # Record actions as they happen
    record_action(trajectory_id, "analyze_requirements", {"result": "success"})
    record_action(trajectory_id, "write_code", {"result": "failure", "error": "syntax error"})

    # Evaluate and reflect
    evaluation = evaluate_trajectory(trajectory_id)
    if not evaluation["success"]:
        reflection = generate_reflection(trajectory_id)
        rollback_to_checkpoint(trajectory_id, checkpoint_index=0)
        # Retry with reflection context

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import json
import time
import hashlib
import copy
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

from brains.memory.brain_memory import BrainMemory

# Teacher integration for learning reflection patterns
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("reflexion")
except Exception as e:
    print(f"[REFLEXION] Teacher helper not available: {e}")
    _teacher_helper = None  # type: ignore

# Reflexion memory for trajectory storage
_memory = BrainMemory("reflexion")


class ActionStatus(Enum):
    """Status of an action in a trajectory."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"
    SKIPPED = "skipped"
    ROLLED_BACK = "rolled_back"


class TrajectoryStatus(Enum):
    """Overall status of a trajectory."""
    ACTIVE = "active"
    COMPLETED = "completed"
    FAILED = "failed"
    ROLLED_BACK = "rolled_back"
    ABANDONED = "abandoned"


class ReflectionType(Enum):
    """Types of reflections that can be generated."""
    FAILURE_ANALYSIS = "failure_analysis"
    STRATEGY_IMPROVEMENT = "strategy_improvement"
    ERROR_PATTERN = "error_pattern"
    SUCCESS_PATTERN = "success_pattern"
    APPROACH_CHANGE = "approach_change"


@dataclass
class ActionRecord:
    """Record of a single action in a trajectory."""
    action_id: str
    action_type: str
    description: str
    input_state: Dict[str, Any]
    output_state: Dict[str, Any]
    status: ActionStatus
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    duration_ms: int = 0
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "action_id": self.action_id,
            "action_type": self.action_type,
            "description": self.description,
            "input_state": self.input_state,
            "output_state": self.output_state,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "duration_ms": self.duration_ms,
            "timestamp": self.timestamp,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActionRecord":
        return cls(
            action_id=data["action_id"],
            action_type=data["action_type"],
            description=data.get("description", ""),
            input_state=data.get("input_state", {}),
            output_state=data.get("output_state", {}),
            status=ActionStatus(data.get("status", "pending")),
            result=data.get("result"),
            error=data.get("error"),
            duration_ms=data.get("duration_ms", 0),
            timestamp=data.get("timestamp", time.time()),
            metadata=data.get("metadata", {}),
        )


@dataclass
class Checkpoint:
    """A checkpoint in a trajectory for rollback."""
    checkpoint_id: str
    action_index: int
    state_snapshot: Dict[str, Any]
    description: str
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "checkpoint_id": self.checkpoint_id,
            "action_index": self.action_index,
            "state_snapshot": self.state_snapshot,
            "description": self.description,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Checkpoint":
        return cls(
            checkpoint_id=data["checkpoint_id"],
            action_index=data.get("action_index", 0),
            state_snapshot=data.get("state_snapshot", {}),
            description=data.get("description", ""),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class Reflection:
    """A reflection generated from trajectory analysis."""
    reflection_id: str
    trajectory_id: str
    reflection_type: ReflectionType
    content: str
    lessons_learned: List[str]
    suggested_changes: List[str]
    confidence: float
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "reflection_id": self.reflection_id,
            "trajectory_id": self.trajectory_id,
            "reflection_type": self.reflection_type.value,
            "content": self.content,
            "lessons_learned": self.lessons_learned,
            "suggested_changes": self.suggested_changes,
            "confidence": self.confidence,
            "timestamp": self.timestamp,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Reflection":
        return cls(
            reflection_id=data["reflection_id"],
            trajectory_id=data["trajectory_id"],
            reflection_type=ReflectionType(data.get("reflection_type", "failure_analysis")),
            content=data.get("content", ""),
            lessons_learned=data.get("lessons_learned", []),
            suggested_changes=data.get("suggested_changes", []),
            confidence=data.get("confidence", 0.5),
            timestamp=data.get("timestamp", time.time()),
        )


@dataclass
class Trajectory:
    """A complete execution trajectory with actions, checkpoints, and reflections."""
    trajectory_id: str
    task_description: str
    actions: List[ActionRecord] = field(default_factory=list)
    checkpoints: List[Checkpoint] = field(default_factory=list)
    reflections: List[Reflection] = field(default_factory=list)
    status: TrajectoryStatus = TrajectoryStatus.ACTIVE
    initial_state: Dict[str, Any] = field(default_factory=dict)
    current_state: Dict[str, Any] = field(default_factory=dict)
    retry_count: int = 0
    max_retries: int = 3
    created_at: float = field(default_factory=time.time)
    completed_at: Optional[float] = None
    parent_trajectory_id: Optional[str] = None  # For retry lineage

    def to_dict(self) -> Dict[str, Any]:
        return {
            "trajectory_id": self.trajectory_id,
            "task_description": self.task_description,
            "actions": [a.to_dict() for a in self.actions],
            "checkpoints": [c.to_dict() for c in self.checkpoints],
            "reflections": [r.to_dict() for r in self.reflections],
            "status": self.status.value,
            "initial_state": self.initial_state,
            "current_state": self.current_state,
            "retry_count": self.retry_count,
            "max_retries": self.max_retries,
            "created_at": self.created_at,
            "completed_at": self.completed_at,
            "parent_trajectory_id": self.parent_trajectory_id,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "Trajectory":
        trajectory = cls(
            trajectory_id=data["trajectory_id"],
            task_description=data.get("task_description", ""),
            status=TrajectoryStatus(data.get("status", "active")),
            initial_state=data.get("initial_state", {}),
            current_state=data.get("current_state", {}),
            retry_count=data.get("retry_count", 0),
            max_retries=data.get("max_retries", 3),
            created_at=data.get("created_at", time.time()),
            completed_at=data.get("completed_at"),
            parent_trajectory_id=data.get("parent_trajectory_id"),
        )
        trajectory.actions = [ActionRecord.from_dict(a) for a in data.get("actions", [])]
        trajectory.checkpoints = [Checkpoint.from_dict(c) for c in data.get("checkpoints", [])]
        trajectory.reflections = [Reflection.from_dict(r) for r in data.get("reflections", [])]
        return trajectory

    def add_action(self, action: ActionRecord) -> None:
        """Add an action to the trajectory."""
        self.actions.append(action)
        if action.output_state:
            self.current_state.update(action.output_state)

    def create_checkpoint(self, description: str = "") -> Checkpoint:
        """Create a checkpoint at the current position."""
        checkpoint_id = hashlib.md5(
            f"{self.trajectory_id}:{len(self.checkpoints)}:{time.time()}".encode()
        ).hexdigest()[:10]

        checkpoint = Checkpoint(
            checkpoint_id=checkpoint_id,
            action_index=len(self.actions),
            state_snapshot=copy.deepcopy(self.current_state),
            description=description or f"Checkpoint after action {len(self.actions)}",
        )
        self.checkpoints.append(checkpoint)
        return checkpoint

    def rollback_to_checkpoint(self, checkpoint_index: int) -> bool:
        """Rollback to a specific checkpoint."""
        if checkpoint_index < 0 or checkpoint_index >= len(self.checkpoints):
            return False

        checkpoint = self.checkpoints[checkpoint_index]

        # Mark actions after checkpoint as rolled back
        for i in range(checkpoint.action_index, len(self.actions)):
            self.actions[i].status = ActionStatus.ROLLED_BACK

        # Restore state
        self.current_state = copy.deepcopy(checkpoint.state_snapshot)
        self.status = TrajectoryStatus.ROLLED_BACK

        return True

    def get_failed_actions(self) -> List[ActionRecord]:
        """Get all failed actions in the trajectory."""
        return [a for a in self.actions if a.status == ActionStatus.FAILURE]

    def get_success_rate(self) -> float:
        """Calculate the success rate of actions."""
        if not self.actions:
            return 0.0
        successful = sum(1 for a in self.actions if a.status == ActionStatus.SUCCESS)
        return successful / len(self.actions)


class ReflexionAgent:
    """
    Full reflexion agent with trajectory management and self-correction.

    Implements the Reflexion loop:
    1. Execute actions and record trajectory
    2. Evaluate outcome
    3. If failed, generate reflection
    4. Rollback to checkpoint
    5. Retry with reflection context
    """

    # Error pattern database for reflection generation
    ERROR_PATTERNS: Dict[str, Dict[str, Any]] = {
        "syntax_error": {
            "indicators": ["syntax", "parse", "unexpected token", "invalid"],
            "lessons": ["Check code syntax before execution", "Validate input format"],
            "suggestions": ["Use linter", "Add input validation"],
        },
        "type_error": {
            "indicators": ["type", "cannot convert", "expected", "incompatible"],
            "lessons": ["Verify data types", "Add type checking"],
            "suggestions": ["Use type hints", "Add assertions"],
        },
        "not_found": {
            "indicators": ["not found", "does not exist", "missing", "no such"],
            "lessons": ["Check resource existence before use", "Handle missing resources"],
            "suggestions": ["Add existence checks", "Provide defaults"],
        },
        "permission": {
            "indicators": ["permission", "denied", "access", "unauthorized"],
            "lessons": ["Check permissions before action", "Request appropriate access"],
            "suggestions": ["Verify credentials", "Use proper authentication"],
        },
        "timeout": {
            "indicators": ["timeout", "timed out", "too long", "exceeded"],
            "lessons": ["Set appropriate timeouts", "Add progress monitoring"],
            "suggestions": ["Increase timeout", "Add retry with backoff"],
        },
        "resource": {
            "indicators": ["memory", "disk", "quota", "limit", "exhausted"],
            "lessons": ["Monitor resource usage", "Clean up resources"],
            "suggestions": ["Free resources", "Use pagination"],
        },
    }

    def __init__(self, max_retries: int = 3):
        """Initialize the reflexion agent."""
        self.max_retries = max_retries
        self._trajectories: Dict[str, Trajectory] = {}
        self._active_trajectory_id: Optional[str] = None
        self._load_from_memory()

    def _load_from_memory(self) -> None:
        """Load recent trajectories from memory."""
        try:
            results = _memory.retrieve(
                query="kind:trajectory",
                limit=50,
                tiers=["stm", "mtm"]
            )
            for result in results:
                metadata = result.get("metadata", {})
                if metadata.get("kind") == "trajectory":
                    trajectory = Trajectory.from_dict(result.get("content", {}))
                    self._trajectories[trajectory.trajectory_id] = trajectory
            print(f"[REFLEXION] Loaded {len(self._trajectories)} trajectories")
        except Exception as e:
            print(f"[REFLEXION] Failed to load trajectories: {e}")

    def _save_trajectory(self, trajectory: Trajectory) -> None:
        """Save a trajectory to memory."""
        try:
            _memory.store(
                content=trajectory.to_dict(),
                metadata={
                    "kind": "trajectory",
                    "trajectory_id": trajectory.trajectory_id,
                    "status": trajectory.status.value,
                    "task": trajectory.task_description[:100],
                }
            )
        except Exception:
            pass

    def start_trajectory(
        self,
        task_description: str,
        initial_state: Optional[Dict[str, Any]] = None,
        parent_trajectory_id: Optional[str] = None,
    ) -> str:
        """
        Start a new execution trajectory.

        Args:
            task_description: What task is being executed
            initial_state: Initial state before execution
            parent_trajectory_id: If this is a retry, the parent trajectory

        Returns:
            Trajectory ID
        """
        trajectory_id = hashlib.md5(
            f"{task_description}:{time.time()}".encode()
        ).hexdigest()[:12]

        trajectory = Trajectory(
            trajectory_id=trajectory_id,
            task_description=task_description,
            initial_state=initial_state or {},
            current_state=copy.deepcopy(initial_state or {}),
            max_retries=self.max_retries,
            parent_trajectory_id=parent_trajectory_id,
        )

        # If this is a retry, increment retry count
        if parent_trajectory_id and parent_trajectory_id in self._trajectories:
            parent = self._trajectories[parent_trajectory_id]
            trajectory.retry_count = parent.retry_count + 1

        # Create initial checkpoint
        trajectory.create_checkpoint("Initial state")

        self._trajectories[trajectory_id] = trajectory
        self._active_trajectory_id = trajectory_id

        print(f"[REFLEXION] Started trajectory {trajectory_id}: {task_description[:50]}...")
        return trajectory_id

    def record_action(
        self,
        trajectory_id: str,
        action_type: str,
        description: str = "",
        input_state: Optional[Dict[str, Any]] = None,
        output_state: Optional[Dict[str, Any]] = None,
        result: Optional[Dict[str, Any]] = None,
        status: ActionStatus = ActionStatus.SUCCESS,
        error: Optional[str] = None,
        duration_ms: int = 0,
        create_checkpoint: bool = False,
    ) -> str:
        """
        Record an action in a trajectory.

        Returns:
            Action ID
        """
        trajectory = self._trajectories.get(trajectory_id)
        if not trajectory:
            raise ValueError(f"Trajectory {trajectory_id} not found")

        action_id = hashlib.md5(
            f"{trajectory_id}:{len(trajectory.actions)}:{time.time()}".encode()
        ).hexdigest()[:10]

        action = ActionRecord(
            action_id=action_id,
            action_type=action_type,
            description=description or action_type,
            input_state=input_state or copy.deepcopy(trajectory.current_state),
            output_state=output_state or {},
            status=status,
            result=result,
            error=error,
            duration_ms=duration_ms,
        )

        trajectory.add_action(action)

        # Optionally create checkpoint after action
        if create_checkpoint and status == ActionStatus.SUCCESS:
            trajectory.create_checkpoint(f"After {action_type}")

        # Save trajectory
        self._save_trajectory(trajectory)

        return action_id

    def evaluate_trajectory(self, trajectory_id: str) -> Dict[str, Any]:
        """
        Evaluate the outcome of a trajectory.

        Returns:
            Evaluation dictionary with success status, metrics, and issues
        """
        trajectory = self._trajectories.get(trajectory_id)
        if not trajectory:
            return {"success": False, "error": "Trajectory not found"}

        failed_actions = trajectory.get_failed_actions()
        success_rate = trajectory.get_success_rate()

        evaluation = {
            "trajectory_id": trajectory_id,
            "success": len(failed_actions) == 0 and trajectory.status != TrajectoryStatus.FAILED,
            "success_rate": success_rate,
            "total_actions": len(trajectory.actions),
            "failed_actions": len(failed_actions),
            "retry_count": trajectory.retry_count,
            "can_retry": trajectory.retry_count < trajectory.max_retries,
            "issues": [],
        }

        # Analyze failed actions
        for action in failed_actions:
            issue = {
                "action_id": action.action_id,
                "action_type": action.action_type,
                "error": action.error,
                "error_pattern": self._identify_error_pattern(action.error or ""),
            }
            evaluation["issues"].append(issue)

        return evaluation

    def _identify_error_pattern(self, error: str) -> str:
        """Identify the error pattern from an error message."""
        error_lower = error.lower()
        for pattern_name, pattern_info in self.ERROR_PATTERNS.items():
            for indicator in pattern_info["indicators"]:
                if indicator in error_lower:
                    return pattern_name
        return "unknown"

    def generate_reflection(
        self,
        trajectory_id: str,
        reflection_type: ReflectionType = ReflectionType.FAILURE_ANALYSIS,
    ) -> Reflection:
        """
        Generate a reflection based on trajectory analysis.

        Returns:
            Reflection object with lessons learned and suggestions
        """
        trajectory = self._trajectories.get(trajectory_id)
        if not trajectory:
            raise ValueError(f"Trajectory {trajectory_id} not found")

        reflection_id = hashlib.md5(
            f"{trajectory_id}:{len(trajectory.reflections)}:{time.time()}".encode()
        ).hexdigest()[:10]

        failed_actions = trajectory.get_failed_actions()
        lessons = []
        suggestions = []
        content_parts = []

        # Analyze each failed action
        for action in failed_actions:
            error = action.error or "Unknown error"
            pattern = self._identify_error_pattern(error)

            content_parts.append(f"Action '{action.action_type}' failed: {error}")

            if pattern in self.ERROR_PATTERNS:
                pattern_info = self.ERROR_PATTERNS[pattern]
                lessons.extend(pattern_info["lessons"])
                suggestions.extend(pattern_info["suggestions"])
            else:
                lessons.append(f"Investigate why {action.action_type} failed")
                suggestions.append("Add error handling for this case")

        # Build reflection content
        content = f"Task: {trajectory.task_description}\n\n"
        content += "Issues encountered:\n"
        content += "\n".join(f"- {p}" for p in content_parts)
        content += "\n\nAnalysis:\n"
        content += f"- Success rate: {trajectory.get_success_rate():.1%}\n"
        content += f"- Retry count: {trajectory.retry_count}/{trajectory.max_retries}\n"

        if trajectory.reflections:
            content += f"\nPrevious reflections: {len(trajectory.reflections)}\n"

        # Deduplicate lessons and suggestions
        lessons = list(dict.fromkeys(lessons))
        suggestions = list(dict.fromkeys(suggestions))

        # Calculate confidence based on pattern matches
        known_patterns = sum(
            1 for a in failed_actions
            if self._identify_error_pattern(a.error or "") != "unknown"
        )
        confidence = known_patterns / max(len(failed_actions), 1)

        reflection = Reflection(
            reflection_id=reflection_id,
            trajectory_id=trajectory_id,
            reflection_type=reflection_type,
            content=content,
            lessons_learned=lessons[:5],  # Top 5 lessons
            suggested_changes=suggestions[:5],  # Top 5 suggestions
            confidence=confidence,
        )

        trajectory.reflections.append(reflection)
        self._save_trajectory(trajectory)

        # Store reflection in memory for future learning
        try:
            _memory.store(
                content=reflection.to_dict(),
                metadata={
                    "kind": "reflection",
                    "reflection_id": reflection_id,
                    "trajectory_id": trajectory_id,
                    "type": reflection_type.value,
                }
            )
        except Exception:
            pass

        print(f"[REFLEXION] Generated reflection with {len(lessons)} lessons")
        return reflection

    def rollback_to_checkpoint(
        self,
        trajectory_id: str,
        checkpoint_index: int = -1,
    ) -> bool:
        """
        Rollback a trajectory to a checkpoint.

        Args:
            trajectory_id: Trajectory to rollback
            checkpoint_index: Which checkpoint (-1 for most recent)

        Returns:
            True if rollback succeeded
        """
        trajectory = self._trajectories.get(trajectory_id)
        if not trajectory:
            return False

        if checkpoint_index < 0:
            checkpoint_index = len(trajectory.checkpoints) + checkpoint_index

        success = trajectory.rollback_to_checkpoint(checkpoint_index)
        if success:
            self._save_trajectory(trajectory)
            print(f"[REFLEXION] Rolled back to checkpoint {checkpoint_index}")

        return success

    def retry_trajectory(
        self,
        trajectory_id: str,
        with_reflection: bool = True,
    ) -> Optional[str]:
        """
        Create a retry trajectory with reflection context.

        Returns:
            New trajectory ID or None if max retries exceeded
        """
        original = self._trajectories.get(trajectory_id)
        if not original:
            return None

        if original.retry_count >= original.max_retries:
            print(f"[REFLEXION] Max retries ({original.max_retries}) exceeded")
            return None

        # Generate reflection if requested
        if with_reflection and original.get_failed_actions():
            self.generate_reflection(trajectory_id)

        # Create new trajectory as retry
        new_id = self.start_trajectory(
            task_description=original.task_description,
            initial_state=original.initial_state,
            parent_trajectory_id=trajectory_id,
        )

        # Copy reflections to new trajectory for context
        new_trajectory = self._trajectories[new_id]
        new_trajectory.reflections = copy.deepcopy(original.reflections)

        print(f"[REFLEXION] Created retry trajectory {new_id} (attempt {new_trajectory.retry_count + 1})")
        return new_id

    def complete_trajectory(
        self,
        trajectory_id: str,
        success: bool = True,
    ) -> None:
        """Mark a trajectory as completed."""
        trajectory = self._trajectories.get(trajectory_id)
        if not trajectory:
            return

        trajectory.status = TrajectoryStatus.COMPLETED if success else TrajectoryStatus.FAILED
        trajectory.completed_at = time.time()
        self._save_trajectory(trajectory)

        # If successful, store as success pattern
        if success:
            self._store_success_pattern(trajectory)

        print(f"[REFLEXION] Trajectory {trajectory_id} {'completed' if success else 'failed'}")

    def _store_success_pattern(self, trajectory: Trajectory) -> None:
        """Store successful trajectory as a pattern for future reference."""
        try:
            pattern = {
                "task_type": self._classify_task(trajectory.task_description),
                "task_description": trajectory.task_description,
                "action_sequence": [
                    {"type": a.action_type, "description": a.description}
                    for a in trajectory.actions
                    if a.status == ActionStatus.SUCCESS
                ],
                "total_actions": len(trajectory.actions),
                "duration_ms": sum(a.duration_ms for a in trajectory.actions),
                "retries_needed": trajectory.retry_count,
            }

            _memory.store(
                content=pattern,
                metadata={
                    "kind": "success_pattern",
                    "task_type": pattern["task_type"],
                    "trajectory_id": trajectory.trajectory_id,
                }
            )
        except Exception:
            pass

    def _classify_task(self, task_description: str) -> str:
        """Classify a task for pattern matching."""
        task_lower = task_description.lower()

        classifications = {
            "implementation": ["implement", "build", "create", "develop", "code"],
            "debugging": ["debug", "fix", "troubleshoot", "resolve", "diagnose"],
            "testing": ["test", "verify", "validate", "check"],
            "research": ["research", "investigate", "analyze", "study"],
            "configuration": ["configure", "setup", "install", "deploy"],
        }

        for task_type, keywords in classifications.items():
            if any(kw in task_lower for kw in keywords):
                return task_type

        return "general"

    def get_trajectory(self, trajectory_id: str) -> Optional[Trajectory]:
        """Get a trajectory by ID."""
        return self._trajectories.get(trajectory_id)

    def get_active_trajectory(self) -> Optional[Trajectory]:
        """Get the currently active trajectory."""
        if self._active_trajectory_id:
            return self._trajectories.get(self._active_trajectory_id)
        return None

    def get_reflections_for_task(self, task_description: str, limit: int = 5) -> List[Reflection]:
        """Get relevant reflections for a similar task."""
        task_type = self._classify_task(task_description)
        reflections = []

        for trajectory in self._trajectories.values():
            if self._classify_task(trajectory.task_description) == task_type:
                reflections.extend(trajectory.reflections)

        # Sort by timestamp and return most recent
        reflections.sort(key=lambda r: r.timestamp, reverse=True)
        return reflections[:limit]

    def get_statistics(self) -> Dict[str, Any]:
        """Get reflexion agent statistics."""
        total = len(self._trajectories)
        completed = sum(1 for t in self._trajectories.values() if t.status == TrajectoryStatus.COMPLETED)
        failed = sum(1 for t in self._trajectories.values() if t.status == TrajectoryStatus.FAILED)
        total_reflections = sum(len(t.reflections) for t in self._trajectories.values())

        return {
            "total_trajectories": total,
            "completed": completed,
            "failed": failed,
            "success_rate": completed / total if total > 0 else 0.0,
            "total_reflections": total_reflections,
            "active_trajectory": self._active_trajectory_id,
        }


# Module-level singleton
_agent: Optional[ReflexionAgent] = None


def get_agent(max_retries: int = 3) -> ReflexionAgent:
    """Get the singleton reflexion agent."""
    global _agent
    if _agent is None:
        _agent = ReflexionAgent(max_retries)
    return _agent


def start_trajectory(
    task_description: str,
    initial_state: Optional[Dict[str, Any]] = None,
) -> str:
    """Convenience function to start a trajectory."""
    return get_agent().start_trajectory(task_description, initial_state)


def record_action(
    trajectory_id: str,
    action_type: str,
    result: Optional[Dict[str, Any]] = None,
    status: ActionStatus = ActionStatus.SUCCESS,
    error: Optional[str] = None,
    create_checkpoint: bool = False,
) -> str:
    """Convenience function to record an action."""
    return get_agent().record_action(
        trajectory_id=trajectory_id,
        action_type=action_type,
        result=result,
        status=status,
        error=error,
        create_checkpoint=create_checkpoint,
    )


def evaluate_trajectory(trajectory_id: str) -> Dict[str, Any]:
    """Convenience function to evaluate a trajectory."""
    return get_agent().evaluate_trajectory(trajectory_id)


def generate_reflection(trajectory_id: str) -> Reflection:
    """Convenience function to generate a reflection."""
    return get_agent().generate_reflection(trajectory_id)


def rollback_to_checkpoint(trajectory_id: str, checkpoint_index: int = -1) -> bool:
    """Convenience function to rollback to a checkpoint."""
    return get_agent().rollback_to_checkpoint(trajectory_id, checkpoint_index)


def retry_trajectory(trajectory_id: str) -> Optional[str]:
    """Convenience function to retry a trajectory."""
    return get_agent().retry_trajectory(trajectory_id)


def complete_trajectory(trajectory_id: str, success: bool = True) -> None:
    """Convenience function to complete a trajectory."""
    get_agent().complete_trajectory(trajectory_id, success)


def get_reflexion_statistics() -> Dict[str, Any]:
    """Convenience function to get statistics."""
    return get_agent().get_statistics()


# Brain service contract
def handle(context: Dict[str, Any]) -> Dict[str, Any]:
    """Brain service entry point."""
    op = context.get("op", "")
    payload = context.get("payload", {})

    try:
        if op == "START_TRAJECTORY":
            # Accept either 'task_description' or 'goal' as the task
            task = payload.get("task_description", payload.get("goal", ""))
            initial_state = payload.get("initial_state", {})
            trajectory_id = start_trajectory(task, initial_state)
            return {"ok": True, "op": op, "payload": {"trajectory_id": trajectory_id}}

        elif op == "RECORD_ACTION":
            trajectory_id = payload.get("trajectory_id", "")
            # Accept either 'action_type' or 'action'
            action_type = payload.get("action_type", payload.get("action", ""))
            result = payload.get("result")
            # Accept 'status' as string or 'success' as boolean
            if "success" in payload and "status" not in payload:
                status = ActionStatus.SUCCESS if payload["success"] else ActionStatus.FAILED
            else:
                status = ActionStatus(payload.get("status", "success"))
            error = payload.get("error")

            action_id = record_action(
                trajectory_id, action_type, result, status, error
            )
            return {"ok": True, "op": op, "payload": {"action_id": action_id}}

        elif op == "EVALUATE":
            trajectory_id = payload.get("trajectory_id", "")
            evaluation = evaluate_trajectory(trajectory_id)
            return {"ok": True, "op": op, "payload": evaluation}

        elif op == "REFLECT":
            trajectory_id = payload.get("trajectory_id", "")
            reflection = generate_reflection(trajectory_id)
            return {"ok": True, "op": op, "payload": reflection.to_dict()}

        elif op == "ROLLBACK":
            trajectory_id = payload.get("trajectory_id", "")
            checkpoint_index = payload.get("checkpoint_index", -1)
            success = rollback_to_checkpoint(trajectory_id, checkpoint_index)
            return {"ok": True, "op": op, "payload": {"success": success}}

        elif op == "RETRY":
            trajectory_id = payload.get("trajectory_id", "")
            new_id = retry_trajectory(trajectory_id)
            return {"ok": True, "op": op, "payload": {"new_trajectory_id": new_id}}

        elif op == "COMPLETE":
            trajectory_id = payload.get("trajectory_id", "")
            success = payload.get("success", True)
            complete_trajectory(trajectory_id, success)
            return {"ok": True, "op": op, "payload": {"completed": True}}

        elif op == "CHECKPOINT":
            trajectory_id = payload.get("trajectory_id", "")
            description = payload.get("description", "")
            agent = get_agent()
            trajectory = agent.get_trajectory(trajectory_id)
            if not trajectory:
                return {"ok": False, "op": op, "error": f"Trajectory not found: {trajectory_id}"}
            checkpoint = trajectory.create_checkpoint(description)
            return {"ok": True, "op": op, "payload": {"checkpoint_id": checkpoint.checkpoint_id}}

        elif op == "GET_STATS":
            stats = get_reflexion_statistics()
            return {"ok": True, "op": op, "payload": stats}

        else:
            return {"ok": False, "op": op, "error": f"Unknown operation: {op}"}

    except Exception as e:
        return {"ok": False, "op": op, "error": str(e)}


service_api = handle


# Public API
__all__ = [
    "ActionStatus",
    "TrajectoryStatus",
    "ReflectionType",
    "ActionRecord",
    "Checkpoint",
    "Reflection",
    "Trajectory",
    "ReflexionAgent",
    "get_agent",
    "start_trajectory",
    "record_action",
    "evaluate_trajectory",
    "generate_reflection",
    "rollback_to_checkpoint",
    "retry_trajectory",
    "complete_trajectory",
    "get_reflexion_statistics",
    "handle",
    "service_api",
]
