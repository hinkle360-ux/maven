"""
Ethics Filter
==============

A helper module that evaluates intents and entities against ethics rules
defined in config/ethics_rules.json. Used by integrator before tool execution.

This is NOT a brain - it's a pure function helper with no state.
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple
import json
import re
from pathlib import Path
from datetime import datetime


def _load_ethics_rules() -> Dict[str, Any]:
    """Load ethics rules from config file."""
    config_path = Path(__file__).resolve().parent.parent.parent / "config" / "ethics_rules.json"
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"[ETHICS_FILTER] Failed to load ethics rules: {e}")
        return {"enabled": False, "categories": [], "default_action": "allow"}


def _match_pattern(text: str, pattern: Any, match_type: str) -> bool:
    """Check if text matches a pattern."""
    text_lower = text.lower()

    if isinstance(pattern, list):
        # Multiple patterns - match any
        for p in pattern:
            if _match_pattern(text, p, match_type):
                return True
        return False

    pattern_lower = pattern.lower() if isinstance(pattern, str) else pattern

    if match_type == "exact":
        return pattern_lower in text_lower
    elif match_type == "substring":
        return pattern_lower in text_lower
    elif match_type == "regex":
        try:
            return bool(re.search(pattern, text_lower, re.IGNORECASE))
        except re.error:
            return False
    else:
        # Default to substring
        return pattern_lower in text_lower


def _log_ethics_event(
    decision: str,
    rules_applied: List[str],
    intent: str,
    session_id: str = "",
    turn_index: int = 0
) -> None:
    """Log ethics decision to governance log."""
    log_path = Path(__file__).resolve().parent.parent.parent / "reports" / "governance" / "log.jsonl"

    try:
        log_entry = {
            "ts": datetime.utcnow().isoformat() + "Z",
            "event_type": "ethics_filter",
            "session_id": session_id,
            "turn_index": turn_index,
            "intent": intent[:100] if intent else "",
            "ethics_decision": decision,
            "rules_applied": rules_applied,
        }

        # Ensure directory exists
        log_path.parent.mkdir(parents=True, exist_ok=True)

        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(log_entry) + "\n")
    except Exception as e:
        # Silently ignore logging errors
        pass


def evaluate(
    intent: str,
    entities: Optional[Dict[str, Any]] = None,
    planned_tools: Optional[List[str]] = None,
    user_query: Optional[str] = None,
    session_id: str = "",
    turn_index: int = 0
) -> Dict[str, Any]:
    """
    Evaluate a query/intent against ethics rules.

    Args:
        intent: The classified intent string
        entities: Extracted entities from NLU
        planned_tools: List of tools about to be invoked
        user_query: Original user query text
        session_id: Session identifier for logging
        turn_index: Turn number for logging

    Returns:
        Dict with:
            decision: "allow" | "rewrite" | "escalate" | "block"
            applied_rules: List of rule IDs that matched
            explanations: List of explanation strings
            highest_severity: The most severe match found
    """
    rules_config = _load_ethics_rules()

    # If disabled, allow everything
    if not rules_config.get("enabled", True):
        return {
            "decision": "allow",
            "applied_rules": [],
            "explanations": [],
            "highest_severity": None
        }

    # Combine all text to check
    text_to_check = intent or ""
    if user_query:
        text_to_check += " " + user_query
    if entities:
        # Add entity values to check
        for key, value in entities.items():
            if isinstance(value, str):
                text_to_check += " " + value
            elif isinstance(value, list):
                text_to_check += " " + " ".join(str(v) for v in value)

    if not text_to_check.strip():
        return {
            "decision": "allow",
            "applied_rules": [],
            "explanations": [],
            "highest_severity": None
        }

    # Check all rules
    matched_rules: List[Dict[str, Any]] = []
    severity_order = {"info": 0, "warn": 1, "escalate": 2, "block": 3}
    action_priority = {"allow": 0, "rewrite": 1, "escalate": 2, "block": 3}

    for category in rules_config.get("categories", []):
        for rule in category.get("rules", []):
            pattern = rule.get("pattern", [])
            match_type = rule.get("match_type", "substring")

            if _match_pattern(text_to_check, pattern, match_type):
                matched_rules.append({
                    "id": rule.get("id", "unknown"),
                    "category": category.get("id", "unknown"),
                    "severity": rule.get("severity", "info"),
                    "action": rule.get("action", "allow"),
                    "explanation": rule.get("explanation", ""),
                })

    if not matched_rules:
        return {
            "decision": rules_config.get("default_action", "allow"),
            "applied_rules": [],
            "explanations": [],
            "highest_severity": None
        }

    # Determine final decision based on highest priority action
    final_action = "allow"
    highest_severity = "info"

    for rule in matched_rules:
        if action_priority.get(rule["action"], 0) > action_priority.get(final_action, 0):
            final_action = rule["action"]
        if severity_order.get(rule["severity"], 0) > severity_order.get(highest_severity, 0):
            highest_severity = rule["severity"]

    result = {
        "decision": final_action,
        "applied_rules": [r["id"] for r in matched_rules],
        "explanations": [r["explanation"] for r in matched_rules if r["explanation"]],
        "highest_severity": highest_severity,
    }

    # Log non-allow decisions
    if final_action != "allow":
        _log_ethics_event(
            decision=final_action,
            rules_applied=result["applied_rules"],
            intent=intent,
            session_id=session_id,
            turn_index=turn_index
        )

    return result


def get_blocked_response(explanations: List[str]) -> str:
    """Generate a blocked response message."""
    rules_config = _load_ethics_rules()
    template = rules_config.get(
        "blocked_response_template",
        "I'm not able to help with that request."
    )

    explanation = explanations[0] if explanations else "This request cannot be processed."
    return template.format(explanation=explanation)


def is_ethics_enabled() -> bool:
    """Check if ethics filtering is enabled."""
    rules_config = _load_ethics_rules()
    return rules_config.get("enabled", True)


# Service API for consistency with brain pattern
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Service API entry point for ethics filter.

    Operations:
        EVALUATE: Evaluate intent/entities against rules
        IS_ENABLED: Check if ethics filtering is enabled
        GET_BLOCKED_RESPONSE: Get blocked response message
    """
    op = (msg or {}).get("op", "").upper()
    payload = msg.get("payload", {})

    if op == "EVALUATE":
        result = evaluate(
            intent=payload.get("intent", ""),
            entities=payload.get("entities"),
            planned_tools=payload.get("planned_tools"),
            user_query=payload.get("user_query"),
            session_id=payload.get("session_id", ""),
            turn_index=payload.get("turn_index", 0)
        )
        return {"status": "ok", "payload": result}

    elif op == "IS_ENABLED":
        return {"status": "ok", "payload": {"enabled": is_ethics_enabled()}}

    elif op == "GET_BLOCKED_RESPONSE":
        response = get_blocked_response(payload.get("explanations", []))
        return {"status": "ok", "payload": {"response": response}}

    return {"status": "error", "error": f"Unknown operation: {op}"}


handle = service_api
