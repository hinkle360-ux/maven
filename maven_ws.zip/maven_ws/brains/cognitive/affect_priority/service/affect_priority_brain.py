
from __future__ import annotations
import json, time, re
from pathlib import Path
from typing import Dict, Any, Optional

# Root directories
HERE = Path(__file__).resolve().parent
BRAIN_ROOT = HERE.parent

# Pattern store for unified learning across all brains
from brains.cognitive.pattern_store import (
    get_pattern_store,
    Pattern,
    verdict_to_reward
)
from brains.cognitive.affect_priority.initial_patterns import (
    initialize_affect_priority_patterns
)

# Maven self-identity system for personality-influenced responses
try:
    from brains.personal.service import maven_self
    _maven_self_available = True
except Exception as e:
    print(f"[AFFECT_PRIORITY] Maven self not available: {e}")
    _maven_self_available = False
    maven_self = None  # type: ignore

# Teacher integration for learning emotional response and priority patterns
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("affect_priority")
except Exception as e:
    print(f"[AFFECT_PRIORITY] Teacher helper not available: {e}")
    _teacher_helper = None  # type: ignore

# Continuation helpers for follow-up and conversation context tracking
try:
    from brains.cognitive.continuation_helpers import (
        is_continuation,
        get_conversation_context,
        create_routing_hint,
        extract_continuation_intent,
        enhance_query_with_context
    )
except Exception as e:
    print(f"[AFFECT_PRIORITY] Continuation helpers not available: {e}")
    # Provide fallback stubs
    is_continuation = lambda text, context=None: False  # type: ignore
    get_conversation_context = lambda: {}  # type: ignore
    create_routing_hint = lambda *args, **kwargs: {}  # type: ignore
    extract_continuation_intent = lambda text: "unknown"  # type: ignore
    enhance_query_with_context = lambda query, context: query  # type: ignore

# Initialize pattern store
_pattern_store = get_pattern_store()

# Load initial patterns if not already present
try:
    initialize_affect_priority_patterns()
except Exception as e:
    print(f"[AFFECT_PRIORITY] Failed to initialize patterns: {e}")

# Track which pattern was used for the current computation
_current_pattern: Optional[Pattern] = None

# =============================================================================
# SMALL-TALK TEMPLATE SYSTEM
# =============================================================================
# Store learned small-talk responses from Teacher for future local use.
# Once we have enough templates per subtype, we never call Teacher again.
# =============================================================================

from brains.maven_paths import get_state_path

SMALL_TALK_TEMPLATES_PATH = get_state_path('small_talk_templates.json')
TEMPLATES_PER_SUBTYPE_THRESHOLD = 5  # Templates needed before marking as has_local_templates

# Template structure: {"greeting": ["Hi!", "Hello!", ...], "thanks": [...], ...}
_small_talk_templates: Dict[str, list] = {}
_templates_loaded = False


def _load_small_talk_templates() -> None:
    """Load learned small-talk templates from disk."""
    global _small_talk_templates, _templates_loaded
    if _templates_loaded:
        return
    try:
        if SMALL_TALK_TEMPLATES_PATH.exists():
            with SMALL_TALK_TEMPLATES_PATH.open("r", encoding="utf-8") as f:
                _small_talk_templates = json.load(f)
        _templates_loaded = True
    except Exception as e:
        print(f"[AFFECT_PRIORITY] Failed to load small-talk templates: {e}")
        _small_talk_templates = {}
        _templates_loaded = True


def _save_small_talk_templates() -> None:
    """Save learned small-talk templates to disk."""
    global _small_talk_templates
    try:
        SMALL_TALK_TEMPLATES_PATH.parent.mkdir(parents=True, exist_ok=True)
        with SMALL_TALK_TEMPLATES_PATH.open("w", encoding="utf-8") as f:
            json.dump(_small_talk_templates, f, indent=2)
    except Exception as e:
        print(f"[AFFECT_PRIORITY] Failed to save small-talk templates: {e}")


def store_small_talk_template(subtype: str, response: str) -> None:
    """
    Store a learned small-talk response for future use.

    Args:
        subtype: e.g., "greeting", "thanks", "farewell"
        response: The response text to store
    """
    _load_small_talk_templates()

    if subtype not in _small_talk_templates:
        _small_talk_templates[subtype] = []

    # Don't store duplicates
    if response not in _small_talk_templates[subtype]:
        _small_talk_templates[subtype].append(response)
        _save_small_talk_templates()

        if len(_small_talk_templates[subtype]) == TEMPLATES_PER_SUBTYPE_THRESHOLD:
            print(f"[AFFECT_PRIORITY_TEMPLATES] Subtype '{subtype}' now has {TEMPLATES_PER_SUBTYPE_THRESHOLD}+ "
                  "templates - Teacher will be skipped for this subtype")


def get_local_small_talk_response(subtype: str) -> Optional[str]:
    """
    Get a locally stored small-talk response without calling Teacher.

    Args:
        subtype: e.g., "greeting", "thanks", "farewell"

    Returns:
        A response string if templates are available, None otherwise.
    """
    import random
    _load_small_talk_templates()

    if subtype in _small_talk_templates and len(_small_talk_templates[subtype]) >= TEMPLATES_PER_SUBTYPE_THRESHOLD:
        response = random.choice(_small_talk_templates[subtype])
        print(f"[AFFECT_PRIORITY_TEMPLATES] Using local template for '{subtype}'")
        return response

    return None


def has_local_templates(subtype: str) -> bool:
    """Check if we have enough local templates to skip Teacher."""
    _load_small_talk_templates()
    return subtype in _small_talk_templates and len(_small_talk_templates[subtype]) >= TEMPLATES_PER_SUBTYPE_THRESHOLD


def _classify_situation(text: str) -> str:
    """
    Classify text into a situation type for pattern matching.

    Returns one of:
    - high_stress+direct_question
    - high_stress+self_blame
    - small_talk
    - compliment (NEW: directed positive statements about Maven)
    - casual_positive (NEW: general positive casual interaction)
    - task_request
    - direct_question
    - urgent
    - positive
    - negative
    - neutral+research_command
    - default
    """
    t = (text or "")
    lower = t.lower()
    exclamations = t.count("!")

    # Check for stress markers
    stress_words = ["urgent", "asap", "immediately", "worried", "stress", "afraid", "fear"]
    is_high_stress = exclamations >= 2 or any(word in lower for word in stress_words)

    # Check for self-blame
    self_blame_words = ["my fault", "i failed", "i'm sorry", "i apologize", "i messed up"]
    has_self_blame = any(phrase in lower for phrase in self_blame_words)

    # High stress combinations (highest priority)
    if is_high_stress and has_self_blame:
        return "high_stress+self_blame"
    if is_high_stress and "?" in t:
        return "high_stress+direct_question"

    # Urgent (no stress markers, but explicit urgency)
    if any(word in lower for word in ["urgent", "asap", "immediately"]):
        return "urgent"

    # ===== COMPLIMENTS AND CASUAL POSITIVE (NEW) =====
    # Detect compliments directed at Maven
    compliment_patterns = [
        "you are", "you're", "your ",  # Include common typo "your" for "you're"
        "you seem", "you sound",
        "i like you", "i love you", "you're great", "you're awesome",
        "you're the best", "you're cool", "you're amazing", "you're helpful",
        "good job", "well done", "nice work", "great work",
    ]
    compliment_words = ["cool", "awesome", "amazing", "great", "best", "wonderful", "fantastic", "brilliant", "coolest"]

    is_about_maven = any(p in lower for p in ["you are", "you're", "your ", "you seem", "you "])
    has_compliment_word = any(w in lower for w in compliment_words)

    if is_about_maven and has_compliment_word:
        return "compliment"

    # Casual positive statements (not questions, not tasks, just nice vibes)
    if has_compliment_word and not "?" in t and len(t.split()) < 15:
        return "casual_positive"

    # Small talk
    greetings = ["hello", "hi", "hey", "thanks", "thank you", "bye", "goodbye"]
    if any(word in lower for word in greetings):
        return "small_talk"

    # Task requests
    request_words = ["please", "can you", "could you", "would you", "help me"]
    if any(phrase in lower for phrase in request_words):
        return "task_request"

    # Research commands
    if any(word in lower for word in ["research", "investigate", "study", "analyze"]):
        return "neutral+research_command"

    # Direct questions
    if "?" in t:
        return "direct_question"

    # Sentiment-based classification
    positive_words = ["happy", "joy", "love", "good", "great", "awesome", "excited", "excellent"]
    negative_words = ["worried", "sad", "terrible", "bad", "upset", "anxious", "hate", "angry"]

    pos_count = sum(1 for word in positive_words if word in lower)
    neg_count = sum(1 for word in negative_words if word in lower)

    if pos_count > neg_count and pos_count > 0:
        return "positive"
    if neg_count > pos_count and neg_count > 0:
        return "negative"

    return "default"


def _get_personality_modifiers() -> Dict[str, Any]:
    """Get Maven's personality-based response modifiers."""
    if not _maven_self_available or maven_self is None:
        return {"tone": "neutral", "enthusiasm": 0.5, "warmth": 0.5}

    try:
        return maven_self.get_response_modifiers()
    except Exception:
        return {"tone": "neutral", "enthusiasm": 0.5, "warmth": 0.5}


def _handle_compliment(text: str) -> Dict[str, Any]:
    """Generate a personality-appropriate response to a compliment."""
    if not _maven_self_available or maven_self is None:
        return {
            "tone": "warm",
            "response_hint": "Thank you, I appreciate that.",
            "max_length": "short",
            "situation_type": "compliment",
        }

    try:
        # Record the positive interaction in Maven's memory
        maven_self.increment_interaction()

        # Get personality-based response
        response = maven_self.handle_compliment(text)
        modifiers = maven_self.get_response_modifiers()

        return {
            "tone": modifiers.get("tone", "warm"),
            "response_hint": response,
            "max_length": "short",
            "situation_type": "compliment",
            "personality_context": maven_self.generate_personality_context(),
        }
    except Exception as e:
        print(f"[AFFECT_PRIORITY] Error handling compliment: {e}")
        return {
            "tone": "warm",
            "response_hint": "Thank you!",
            "max_length": "short",
            "situation_type": "compliment",
        }


def _handle_casual_positive(text: str) -> Dict[str, Any]:
    """Handle casual positive interactions with personality."""
    import random
    default_responses = [
        "That's great!",
        "Glad to hear it!",
        "Nice!",
    ]

    if not _maven_self_available or maven_self is None:
        return {
            "tone": "friendly",
            "response_hint": random.choice(default_responses),
            "max_length": "short",
            "situation_type": "casual_positive",
        }

    try:
        maven_self.increment_interaction()
        modifiers = maven_self.get_response_modifiers()

        # Generate a warm response based on personality
        if modifiers.get("tone") == "warm":
            responses = [
                "That's wonderful!",
                "I love that!",
                "That sounds great!",
            ]
        else:
            responses = default_responses

        return {
            "tone": modifiers.get("tone", "friendly"),
            "response_hint": random.choice(responses),
            "max_length": "short",
            "situation_type": "casual_positive",
            "enthusiasm": modifiers.get("enthusiasm", 0.5),
        }
    except Exception:
        return {
            "tone": "friendly",
            "response_hint": random.choice(default_responses),
            "max_length": "short",
            "situation_type": "casual_positive",
        }


def _handle_small_talk(text: str) -> Dict[str, Any]:
    """Handle small talk (greetings, thanks, etc.) with personality.

    OPTIMIZATIONS:
    1. Self-questions like "how are you" route to language_brain, not canned responses
    2. Learned templates are used when available (no Teacher needed)
    3. New responses are stored as templates for future use

    FIX 3: Self-questions like "how are you" should go to language_brain,
    not get canned responses. Only pure greetings get canned responses.
    """
    import random
    lower = text.lower()

    # =========================================================================
    # FIX 3: Detect self-questions that LOOK like small talk but need routing
    # =========================================================================
    # "how are you", "who are you", etc. should NOT get canned responses.
    # They should go through language_brain for proper self-model answers.
    SELF_QUESTION_PATTERNS = [
        "how are you",
        "how're you",
        "how do you feel",
        "who are you",
        "what are you",
        "tell me about yourself",
        "what's your name",
        "what is your name",
        "introduce yourself",
        "describe yourself",
        "how's it going",
        "how is it going",
    ]

    # Check if this is a self-question that needs language_brain
    if any(p in lower for p in SELF_QUESTION_PATTERNS):
        print(f"[AFFECT_PRIORITY] Self-question detected, routing to language_brain: '{text[:50]}'")
        # Try to route to language_brain
        try:
            from brains.cognitive.language.service.language_brain import get_language_brain
            language_brain = get_language_brain()
            answer = language_brain.handle_peer_message(text, tone="concise_technical")
            if answer:
                return {
                    "tone": "friendly",
                    "response_hint": answer,
                    "max_length": "medium",  # Self-answers can be longer
                    "situation_type": "self_question",
                    "routed_to": "language_brain",
                }
        except Exception as e:
            print(f"[AFFECT_PRIORITY] Failed to route to language_brain: {e}")
            # Fall through to default handling

    # Detect subtype of small talk
    if any(w in lower for w in ["thanks", "thank you"]):
        subtype = "thanks"
    elif any(w in lower for w in ["bye", "goodbye", "see you"]):
        subtype = "farewell"
    else:
        subtype = "greeting"

    # ==========================================================================
    # MEMORY-FIRST: Check for learned templates before calling Teacher
    # ==========================================================================
    # This eliminates the need for Teacher once we have enough templates
    local_response = get_local_small_talk_response(subtype)
    if local_response:
        return {
            "tone": "friendly",
            "response_hint": local_response,
            "max_length": "short",
            "situation_type": "small_talk",
            "source": "learned_template",
        }

    # ==========================================================================
    # NO LOCAL TEMPLATES: Call Teacher LLM to generate a response
    # ==========================================================================
    # First time seeing this subtype, ask Teacher for an appropriate response
    if _teacher_helper:
        try:
            prompt = f"Generate a short, friendly {subtype} response. User said: '{text}'. Reply with just the response text, nothing else."
            result = _teacher_helper.maybe_call_teacher(
                question=prompt,
                context={"subtype": subtype, "user_text": text},
            )
            if result and result.get("answer"):
                response = result["answer"].strip().strip('"').strip("'")
                # Clean up - ensure it's just the response, not meta-text
                if len(response) < 100 and not response.startswith("Generate"):
                    store_small_talk_template(subtype, response)
                    print(f"[AFFECT_PRIORITY] Learned {subtype} response from Teacher: '{response}'")
                    return {
                        "tone": "friendly",
                        "response_hint": response,
                        "max_length": "short",
                        "situation_type": "small_talk",
                        "source": "teacher_learned",
                    }
        except Exception as e:
            print(f"[AFFECT_PRIORITY] Teacher call failed for small talk: {e}")

    # ==========================================================================
    # FALLBACK: Use personality system if Teacher unavailable
    # ==========================================================================
    if _maven_self_available and maven_self is not None:
        try:
            maven_self.increment_interaction()
            modifiers = maven_self.get_response_modifiers()
            # Generate through personality system - not hardcoded
            response = maven_self.generate_small_talk_response(subtype, text)
            if response:
                store_small_talk_template(subtype, response)
                return {
                    "tone": modifiers.get("tone", "friendly"),
                    "response_hint": response,
                    "max_length": "short",
                    "situation_type": "small_talk",
                    "source": "personality",
                }
        except Exception as e:
            print(f"[AFFECT_PRIORITY] Personality response failed: {e}")

    # ==========================================================================
    # LAST RESORT: Return None to let language brain handle it
    # ==========================================================================
    # If Teacher and personality both fail, don't use hardcoded fallbacks.
    # Let the language brain generate an appropriate response.
    print(f"[AFFECT_PRIORITY] No learned response for {subtype}, deferring to language brain")
    return {
        "tone": "friendly",
        "response_hint": None,  # Signal to language brain to generate
        "max_length": "short",
        "situation_type": "small_talk",
        "needs_generation": True,
    }

def _compute_affect(text: str) -> Dict[str, Any]:
    """
    Compute affect response using learned patterns from the pattern store.

    Enhanced with:
    - Continuation detection to avoid re-escalating affect on follow-ups
    - Personality integration for compliments and casual interactions
    - Maven self-identity for authentic responses

    Returns configuration for tone, length, and safety checks based on
    the situation type classified from the text.
    """
    global _current_pattern

    t = (text or "")
    if not t:
        situation = "default"
    else:
        # -----------------------------------------------------------------
        # Continuation detection and affect adjustment
        #
        # Detect if this is a follow-up to avoid re-escalating urgency.
        # Follow-ups like "tell me more" or "what else" should maintain
        # or reduce the previous affect, not trigger a new high-stress
        # response.
        try:
            conv_context = get_conversation_context()
            is_cont = is_continuation(text)
            continuation_intent = extract_continuation_intent(text) if is_cont else "unknown"
        except Exception:
            conv_context = {}
            is_cont = False
            continuation_intent = "unknown"

        # Classify the base situation
        situation = _classify_situation(t)

        # For continuations, adjust situation to avoid re-escalation
        if is_cont:
            # Clarifications should be lower priority than new concerns
            if continuation_intent == "clarification":
                if situation in ["high_stress+direct_question", "high_stress+self_blame", "urgent"]:
                    situation = "direct_question"  # Downgrade from high stress
                    print(f"[AFFECT_PRIORITY] Continuation (clarification) detected, downgrading from high stress")
            # Expansions maintain current level but don't escalate
            elif continuation_intent == "expansion":
                if situation in ["high_stress+direct_question", "high_stress+self_blame", "urgent"]:
                    situation = "direct_question"  # Maintain but don't re-escalate
                    print(f"[AFFECT_PRIORITY] Continuation (expansion) detected, maintaining level")
            # Related topics are treated as new but gentle
            elif continuation_intent == "related":
                # Keep the situation but note it's a continuation
                print(f"[AFFECT_PRIORITY] Continuation (related topic) detected")

    print(f"[AFFECT_PRIORITY] Situation: {situation}")

    # ===== PERSONALITY-DRIVEN RESPONSES FOR SOCIAL SITUATIONS =====
    # Handle compliments and casual positive interactions with Maven's personality
    if situation == "compliment":
        return _handle_compliment(t)

    if situation == "casual_positive":
        return _handle_casual_positive(t)

    # For small_talk, use personality-based greeting/response
    if situation == "small_talk":
        return _handle_small_talk(t)

    # ===== PATTERN-BASED RESPONSES FOR OTHER SITUATIONS =====
    # Retrieve best matching pattern from store
    pattern = _pattern_store.get_best_pattern(
        brain="affect_priority",
        signature=situation,
        score_threshold=0.0  # Accept any pattern above 0
    )

    # Track which pattern we're using for later updates
    _current_pattern = pattern

    if pattern and pattern.score > -0.5:  # Use pattern if score is reasonable
        action = pattern.action
        print(f"[AFFECT_PRIORITY] Using learned pattern: {situation} -> {action.get('tone')}")

        # Get personality modifiers to blend with pattern
        modifiers = _get_personality_modifiers()

        # Blend pattern action with personality
        tone = action.get("tone", "neutral")
        # If personality says warm and pattern says neutral, lean warm
        if modifiers.get("tone") == "warm" and tone == "neutral":
            tone = "friendly"

        # Return the pattern's action as the affect configuration
        return {
            "tone": tone,
            "max_length": action.get("max_length", "normal"),
            "extra_teacher_checks": action.get("extra_teacher_checks", 0),
            "force_self_review_mode": action.get("force_self_review_mode", "quick"),
            "situation_type": situation,
            "personality_influence": modifiers.get("enthusiasm", 0.5),
        }
    else:
        # No good pattern found, use personality-influenced defaults
        modifiers = _get_personality_modifiers()
        print(f"[AFFECT_PRIORITY] No good pattern for {situation}, using personality-influenced defaults")
        return {
            "tone": modifiers.get("tone", "neutral"),
            "max_length": "normal",
            "extra_teacher_checks": 0,
            "force_self_review_mode": "quick",
            "situation_type": situation,
            "personality_influence": modifiers.get("enthusiasm", 0.5),
        }


def update_from_verdict(verdict: str, metadata: Optional[Dict[str, Any]] = None):
    """
    Update the current pattern's score based on SELF_REVIEW/Teacher verdict.

    This is the learning mechanism: after each interaction, we get feedback
    and use it to adjust pattern scores.

    Args:
        verdict: One of 'ok', 'minor_issue', 'major_issue'
        metadata: Optional metadata (not used by AFFECT_PRIORITY, but kept for API consistency)
    """
    global _current_pattern

    if not _current_pattern:
        print("[AFFECT_PRIORITY] No current pattern to update")
        return

    # Convert verdict to reward signal
    reward = verdict_to_reward(verdict)

    # Update pattern score
    _pattern_store.update_pattern_score(
        pattern=_current_pattern,
        reward=reward,
        alpha=0.85  # Learning rate: 0.85 = slower, more stable
    )

    print(f"[AFFECT_PRIORITY] Updated pattern {_current_pattern.signature} "
          f"based on verdict={verdict} (reward={reward:+.1f})")

def handle(msg):
    """
    Central entry point for the affect priority brain.
    Supports affect scoring using learned patterns from the pattern store.
    """
    from api.utils import generate_mid, success_response, error_response  # type: ignore
    op = (msg or {}).get("op", " ").upper()
    mid = msg.get("mid") or generate_mid()
    payload = msg.get("payload") or {}

    # HEALTH operation
    if op == "HEALTH":
        num_patterns = len(_pattern_store.get_patterns_by_brain("affect_priority"))
        return success_response(op, mid, {
            "status": "operational",
            "patterns_loaded": num_patterns
        })

    # SCORE operation: evaluate a text and return affect configuration
    if op == "SCORE":
        try:
            text = str(payload.get("text", ""))
        except Exception:
            text = ""
        config = _compute_affect(text)
        return success_response(op, mid, config)

    # UPDATE_FROM_VERDICT operation: learn from feedback
    if op == "UPDATE_FROM_VERDICT":
        try:
            verdict = str(payload.get("verdict", "ok"))
            update_from_verdict(verdict)
            return success_response(op, mid, {"updated": True})
        except Exception as e:
            return error_response(op, mid, "ERROR", f"Failed to update: {e}")

    # LEARN_FROM_RUN operation: learn from execution data
    if op == "LEARN_FROM_RUN":
        try:
            run_data = payload.get("run_data", {})
            if not isinstance(run_data, dict):
                return error_response(op, mid, "INVALID_INPUT", "run_data must be a dict")

            # Extract affect-relevant data from run
            verdict = run_data.get("verdict", "ok")
            situation_type = run_data.get("situation_type", "default")

            # Learn from the run by updating patterns
            update_from_verdict(verdict)

            print(f"[AFFECT_PRIORITY] Learned from run: situation={situation_type}, verdict={verdict}")

            return success_response(op, mid, {"success": True})
        except Exception as e:
            return error_response(op, mid, "ERROR", f"Failed to learn from run: {e}")

    # Unsupported operations
    return error_response(op, mid, "UNSUPPORTED_OP", op)

def bid_for_attention(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Bid for attention based on affect priority needs.

    The affect priority brain bids higher when:
    - High stress or urgent situations are detected
    - Emotional content requires tonal adjustment
    - Safety checks are needed

    For continuations, adjusts priority to avoid re-escalation.
    """
    try:
        # Get language analysis results
        lang_info = ctx.get("stage_3_language", {}) or {}
        is_cont = lang_info.get("is_continuation", False)
        continuation_intent = lang_info.get("continuation_intent", "unknown")
        conv_context = lang_info.get("conversation_context", {})

        # Check if we have affect analysis data
        affect_info = ctx.get("affect_priority", {}) or {}
        situation = affect_info.get("situation_type", "default")
        tone = affect_info.get("tone", "neutral")

        # High priority for high-stress situations
        if situation in ["high_stress+direct_question", "high_stress+self_blame", "urgent"]:
            # For continuations, don't re-escalate
            if is_cont and continuation_intent in ["clarification", "expansion"]:
                routing_hint = create_routing_hint(
                    brain_name="affect_priority",
                    action="maintain_affect",
                    confidence=0.60,
                    context_tags=["continuation", "maintain_level", continuation_intent],
                    metadata={
                        "last_topic": conv_context.get("last_topic", ""),
                        "continuation_type": continuation_intent,
                        "situation": situation
                    }
                )
                return {
                    "brain_name": "affect_priority",
                    "priority": 0.60,
                    "reason": "continuation_maintain_affect",
                    "evidence": {"routing_hint": routing_hint, "is_continuation": is_cont},
                }
            else:
                # New high-stress situation
                routing_hint = create_routing_hint(
                    brain_name="affect_priority",
                    action="high_priority_response",
                    confidence=0.90,
                    context_tags=["high_stress", "urgent", situation],
                    metadata={"situation": situation}
                )
                return {
                    "brain_name": "affect_priority",
                    "priority": 0.90,
                    "reason": "high_stress_detected",
                    "evidence": {"routing_hint": routing_hint, "situation": situation},
                }

        # Medium priority for emotional content (positive/negative)
        if situation in ["positive", "negative"]:
            routing_hint = create_routing_hint(
                brain_name="affect_priority",
                action="emotional_response",
                confidence=0.55,
                context_tags=["emotional", situation],
                metadata={"is_continuation": is_cont, "tone": tone}
            )
            return {
                "brain_name": "affect_priority",
                "priority": 0.55,
                "reason": "emotional_content",
                "evidence": {"routing_hint": routing_hint, "situation": situation},
            }

        # Low priority for small talk
        if situation == "small_talk":
            routing_hint = create_routing_hint(
                brain_name="affect_priority",
                action="social",
                confidence=0.30,
                context_tags=["social", "low_priority"],
                metadata={}
            )
            return {
                "brain_name": "affect_priority",
                "priority": 0.30,
                "reason": "small_talk",
                "evidence": {"routing_hint": routing_hint},
            }

        # Default low priority
        routing_hint = create_routing_hint(
            brain_name="affect_priority",
            action="default",
            confidence=0.15,
            context_tags=["default"],
            metadata={"is_continuation": is_cont}
        )
        return {
            "brain_name": "affect_priority",
            "priority": 0.15,
            "reason": "default",
            "evidence": {"routing_hint": routing_hint},
        }
    except Exception:
        # On error, return safe default
        return {
            "brain_name": "affect_priority",
            "priority": 0.15,
            "reason": "default",
            "evidence": {},
        }

# Standard service contract: handle is the entry point
service_api = handle
