"""
Continuation Helpers
====================

Shared utilities for detecting and handling conversation continuations
across all cognitive brains.

Every cognitive brain must use these helpers to implement the three
required signals:
1. Follow-up detection (is_continuation)
2. History access (get_conversation_context)
3. Routing hints (create_routing_hint)

This ensures consistent continuation handling and enables Teacher learning.
"""

from __future__ import annotations
from typing import Dict, Any, Optional


# Follow-up patterns that indicate continuation
# Comprehensive list covering all variations of "tell me more" type requests
FOLLOW_UP_PATTERNS = [
    # Core expansion patterns
    "tell me more", "more about", "what about", "can you expand",
    "explain further", "more details", "continue", "go on",
    "elaborate", "what else", "anything else", "more on",
    "explain that", "about that", "more info", "keep going",
    "and?", "also?", "besides?", "additionally",
    "what about that", "say more", "more please",
    # Additional expansion variations
    "go deeper", "dive deeper", "can you expand on that",
    "expand on that", "tell me more about that",
    "more information", "more detail", "further detail",
    "give me more", "i want more", "want more",
    "deeper explanation", "in more detail",
    "explain more", "describe more", "say more about",
    "keep talking", "don't stop", "what more",
    "is there more", "anything more", "something more",
]

# Bare continuation words - these alone indicate continuation
# Must be checked as exact match (after stripping punctuation)
BARE_CONTINUATION_WORDS = {
    "more", "continue", "go on", "and", "also", "elaborate",
    "expand", "details", "explain", "yes", "yeah", "yep",
    "ok more", "okay more", "keep going", "next",
}


def is_continuation(text: str, context: Optional[Dict[str, Any]] = None) -> bool:
    """
    Detect if input text is a follow-up/continuation of previous conversation.

    Args:
        text: The user's input text
        context: Optional context dict with norm_type or other hints

    Returns:
        True if this appears to be a continuation, False otherwise

    Examples:
        >>> is_continuation("tell me more")
        True
        >>> is_continuation("more")
        True
        >>> is_continuation("what is a lion?")
        False
    """
    if not text:
        return False

    text_lower = text.lower().strip()
    # Strip punctuation for bare word matching
    text_bare = text_lower.rstrip("?!.,;:")

    # Check bare continuation words first (exact match)
    if text_bare in BARE_CONTINUATION_WORDS:
        return True

    # Check explicit follow-up patterns
    if any(pattern in text_lower for pattern in FOLLOW_UP_PATTERNS):
        return True

    # Check context hints (from sensorium classification)
    if context:
        norm_type = context.get("norm_type", "")
        if norm_type == "follow_up_question":
            return True

        classification = context.get("classification", "")
        if classification == "follow_up_question":
            return True

    # Very short queries that reference "that", "it", "this" are likely continuations
    if len(text_lower.split()) <= 3:
        pronoun_refs = ["that", "it", "this", "those", "these", "them"]
        if any(ref in text_lower for ref in pronoun_refs):
            return True

    return False


def get_conversation_context() -> Dict[str, Any]:
    """
    Retrieve conversation history from system_history and conversation state.

    Returns:
        Dictionary with:
        - last_topic: Most recent conversation topic
        - last_user_question: Previous user query
        - last_answer_subject: Subject of last response
        - thread_entities: Entities mentioned in conversation
        - conversation_depth: Number of turns in conversation
        - last_web_search: Last web search data (if any)
        - last_answer_source: Source of last answer (e.g., "web_search", "reasoning")
        - last_tool_name: Last tool used (e.g., "x", "grok", "browser_open")
        - last_tool_confidence: Confidence in last tool routing

    This enables brains to attach follow-ups to previous context and
    maintain tool continuity (e.g., continue chatting with grok).
    """
    context = {
        "last_topic": None,
        "last_user_question": None,
        "last_answer_subject": None,
        "thread_entities": [],
        "conversation_depth": 0,
        "last_web_search": None,
        "last_answer_source": None,
        "last_tool_name": None,
        "last_tool_confidence": 0.0,
    }

    # Try to get from system_history
    try:
        from brains.cognitive.system_history.service.system_history_brain import service_api
        result = service_api({"op": "GET_LAST_TOPIC", "payload": {}})
        if result.get("ok"):
            payload = result.get("payload", {})
            context["last_topic"] = payload.get("last_topic")
    except Exception:
        pass

    # Try to get from memory_librarian conversation state
    try:
        from brains.cognitive.memory_librarian.service.memory_librarian import _CONVERSATION_STATE
        context["last_user_question"] = _CONVERSATION_STATE.get("last_query", "")
        context["last_answer_subject"] = _CONVERSATION_STATE.get("last_response", "")
        context["thread_entities"] = _CONVERSATION_STATE.get("thread_entities", [])
        context["conversation_depth"] = _CONVERSATION_STATE.get("conversation_depth", 0)

        # Fallback to last_topic from conversation state if system_history didn't have it
        if not context["last_topic"]:
            context["last_topic"] = _CONVERSATION_STATE.get("last_topic", "")

        # Get last tool used for continuation routing
        context["last_tool_name"] = _CONVERSATION_STATE.get("last_tool_name", None)
        context["last_tool_confidence"] = _CONVERSATION_STATE.get("last_tool_confidence", 0.0)
    except Exception:
        pass

    # Try to get last web search state
    try:
        from brains.cognitive.memory_librarian.service.memory_librarian import get_last_web_search
        last_web = get_last_web_search()
        if last_web:
            context["last_web_search"] = last_web
            context["last_answer_source"] = "web_search"
    except Exception:
        pass

    return context


# Tool continuation patterns - words that suggest continuing with the same tool
TOOL_CONTINUATION_PATTERNS = [
    "say", "ask", "tell", "reply", "respond", "answer",
    "send", "post", "message", "chat", "talk",
    "again", "another", "more", "also", "too",
]


def should_continue_with_tool(text: str, last_tool: str) -> bool:
    """
    Check if this message should continue using the same tool.

    Args:
        text: Current user message
        last_tool: Name of the last tool used (e.g., "x", "grok")

    Returns:
        True if this appears to be a continuation that should use the same tool
    """
    if not text or not last_tool:
        return False

    text_lower = text.lower().strip()

    # Check for explicit tool reference
    if last_tool.lower() in text_lower:
        return True

    # Check for continuation patterns
    if any(pattern in text_lower for pattern in TOOL_CONTINUATION_PATTERNS):
        # Additional check: short message or doesn't look like a new command
        if len(text_lower.split()) < 10:
            return True

    return False


def get_last_web_search_state() -> Optional[Dict[str, Any]]:
    """
    Get the most recent web search results for follow-up handling.

    Returns:
        Dict with query, results, engine, answer, sources, or None if no search stored
    """
    try:
        from brains.cognitive.memory_librarian.service.memory_librarian import get_last_web_search
        return get_last_web_search()
    except Exception:
        return None


def followup_refers_to_last_search(query: str) -> bool:
    """
    Check if a follow-up query refers to the last web search topic.

    Args:
        query: The user's follow-up query

    Returns:
        True if the follow-up appears to reference the last web search topic
    """
    try:
        from brains.cognitive.memory_librarian.service.memory_librarian import followup_refers_to_web_search
        return followup_refers_to_web_search(query)
    except Exception:
        return False


def create_routing_hint(
    brain_name: str,
    action: str,
    confidence: float,
    context_tags: Optional[list] = None,
    metadata: Optional[Dict[str, Any]] = None
) -> Dict[str, Any]:
    """
    Create a standardized routing hint for the Integrator.

    Args:
        brain_name: Name of the brain providing the hint
        action: Suggested routing action (e.g., "expand_previous_reasoning")
        confidence: Confidence in this routing (0.0 to 1.0)
        context_tags: Optional list of context tags
        metadata: Optional additional metadata

    Returns:
        Standardized routing hint dictionary

    Example:
        >>> create_routing_hint("reasoning", "expand_previous_reasoning", 0.9,
        ...                     context_tags=["follow_up", "factual"])
        {
            "brain": "reasoning",
            "routing_hint": "expand_previous_reasoning",
            "confidence": 0.9,
            "context_tags": ["follow_up", "factual"],
            "metadata": {}
        }
    """
    return {
        "brain": brain_name,
        "routing_hint": action,
        "confidence": max(0.0, min(1.0, confidence)),  # Clamp to [0, 1]
        "context_tags": context_tags or [],
        "metadata": metadata or {}
    }


def enhance_query_with_context(query: str, context: Dict[str, Any]) -> str:
    """
    4.1: Enhanced continuation normalization.

    Rewrite generic continuation queries to be explicit:
    - "tell me more" -> "tell me more about {last_topic}"
    - "go deeper" -> "explain {last_topic} in more detail"
    - "what else" -> "what else about {last_topic}"
    - "expand on that" -> "expand on {last_topic}"

    Args:
        query: Original user query
        context: Conversation context from get_conversation_context()

    Returns:
        Enhanced query string

    Example:
        >>> enhance_query_with_context("tell me more",
        ...                           {"last_topic": "physics"})
        "tell me more about physics"
    """
    if not query or not context:
        return query

    last_topic = context.get("last_topic", "")
    query_lower = query.lower().strip()

    # If this is a bare follow-up and we have a topic, rewrite appropriately
    if is_continuation(query) and last_topic:
        # Avoid duplication
        if last_topic.lower() in query_lower:
            return query

        # 4.1: Continuation-specific rewrites for better clarity
        # These rewrites make the query more explicit for downstream processing
        rewrite_patterns = {
            # Generic "tell me more" type
            "tell me more": f"tell me more about {last_topic}",
            "more please": f"tell me more about {last_topic}",
            "more": f"tell me more about {last_topic}",
            "continue": f"continue explaining {last_topic}",
            "go on": f"continue explaining {last_topic}",
            # Depth requests
            "go deeper": f"explain {last_topic} in more detail",
            "dive deeper": f"explain {last_topic} in more detail",
            "deeper": f"explain {last_topic} in more depth",
            "in more detail": f"explain {last_topic} in more detail",
            "more detail": f"provide more detail about {last_topic}",
            "more details": f"provide more details about {last_topic}",
            # Expansion requests
            "expand on that": f"expand on {last_topic}",
            "elaborate": f"elaborate on {last_topic}",
            "elaborate on that": f"elaborate on {last_topic}",
            "explain more": f"explain {last_topic} in more detail",
            # What else type
            "what else": f"what else about {last_topic}",
            "anything else": f"what else should I know about {last_topic}",
        }

        # Check for pattern match
        for pattern, rewrite in rewrite_patterns.items():
            if query_lower == pattern or query_lower.rstrip("?!.,;:") == pattern:
                print(f"[CONTINUATION] Enhanced: '{query}' -> '{rewrite}'")
                return rewrite

        # Generic fallback: append topic
        enhanced = f"{query} about {last_topic}"
        print(f"[CONTINUATION] Enhanced (fallback): '{query}' -> '{enhanced}'")
        return enhanced

    return query


def get_continuation_signals(query: str, context: Dict[str, Any]) -> Dict[str, Any]:
    """
    4.2: Generate recent_behavior signals for continuation handling.

    Detects continuation patterns and sets appropriate flags for length planning.

    Args:
        query: The user's current query
        context: Conversation context

    Returns:
        Dictionary with:
        - is_continuation: bool
        - continuation_intent: str (expansion/clarification/related/unknown)
        - asked_for_more_detail_recently: bool (for length planner)
        - last_topic: str
        - enhanced_query: str
        - task_type_hint: str (suggested task type for routing)
    """
    signals = {
        "is_continuation": False,
        "continuation_intent": "unknown",
        "asked_for_more_detail_recently": False,
        "last_topic": context.get("last_topic", ""),
        "enhanced_query": query,
        "task_type_hint": None,
    }

    if not query:
        return signals

    # Check if this is a continuation
    is_cont = is_continuation(query, context)
    signals["is_continuation"] = is_cont

    if is_cont:
        # Get continuation intent
        intent = extract_continuation_intent(query)
        signals["continuation_intent"] = intent

        # 4.2: Set asked_for_more_detail_recently for expansion/depth requests
        # This flag is critical for length planner to choose "long" mode
        expansion_intents = ("expansion", "clarification")
        if intent in expansion_intents:
            signals["asked_for_more_detail_recently"] = True
            print(f"[CONTINUATION] Flagged as more_detail_request (intent={intent})")

        # Also check for explicit detail phrases
        query_lower = query.lower()
        detail_phrases = [
            "more detail", "more depth", "go deeper", "dive deeper",
            "explain more", "elaborate", "expand", "tell me more",
            "in detail", "comprehensive", "thorough"
        ]
        if any(phrase in query_lower for phrase in detail_phrases):
            signals["asked_for_more_detail_recently"] = True

        # Enhance the query
        signals["enhanced_query"] = enhance_query_with_context(query, context)

        # 4.2: Suggest task_type based on continuation type
        # Reuse last topic's task_type if available, otherwise infer from intent
        last_task_type = context.get("last_task_type")
        if last_task_type:
            signals["task_type_hint"] = last_task_type
        elif intent == "expansion":
            signals["task_type_hint"] = "explanation"  # Expansion is usually explanation
        elif intent == "clarification":
            signals["task_type_hint"] = "explanation"

    return signals


def should_use_continuation_routing(context: Dict[str, Any]) -> bool:
    """
    Determine if continuation-specific routing should be used.

    Args:
        context: Context dict with classification and history

    Returns:
        True if continuation routing is appropriate

    This helps brains decide whether to use expansion vs. fresh analysis.
    """
    # Check if classified as continuation
    if context.get("is_continuation"):
        return True

    # Check if there's a recent topic to continue from
    if context.get("last_topic") and context.get("conversation_depth", 0) > 0:
        return True

    return False


def extract_continuation_intent(text: str) -> str:
    """
    Extract the type of continuation being requested.

    Returns one of:
    - "expansion": User wants more details/elaboration
    - "clarification": User wants simpler explanation
    - "related": User wants related information
    - "unknown": Cannot determine intent

    This helps route to appropriate brain for handling.
    """
    text_lower = text.lower().strip()

    # Expansion requests
    expansion_markers = [
        "more", "expand", "elaborate", "continue", "further",
        "deeper", "detail", "tell me more"
    ]
    if any(marker in text_lower for marker in expansion_markers):
        return "expansion"

    # Clarification requests
    clarification_markers = [
        "explain", "clarify", "simpler", "don't understand",
        "what does that mean", "confused"
    ]
    if any(marker in text_lower for marker in clarification_markers):
        return "clarification"

    # Related information requests
    related_markers = [
        "what about", "how about", "what else", "also",
        "related", "similar", "besides"
    ]
    if any(marker in text_lower for marker in related_markers):
        return "related"

    return "unknown"
