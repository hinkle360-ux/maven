"""
Skill Tracker Module
=====================

Tracks skill levels per task type to determine:
- When the brain is competent enough to answer without LLM
- When validation is required
- When LLM fallback (teacher mode) should be used

Skill Levels:
- DEVELOPING: Still learning, LLM may be used as teacher
- PROFICIENT: Competent but validation recommended
- MASTERED: Can answer without LLM, validation optional

Each skill profile contains:
- success_count: Number of successful task completions
- failure_count: Number of failures or corrections needed
- rolling_accuracy: Recent accuracy (last N attempts)
- rolling_stability: Variance in performance
- last_cci_score: Last comprehensive coherence index score
"""

from __future__ import annotations
from enum import Enum
from typing import Dict, Any, Optional, List, Tuple
from pathlib import Path
import json
import time

# Local imports
try:
    from brains.memory.brain_memory import BrainMemory
except ImportError:
    BrainMemory = None

from brains.cognitive.learning_contract.task_types import TaskType


class SkillLevel(Enum):
    """Skill proficiency levels."""
    DEVELOPING = "developing"  # Brain still learning, LLM as teacher allowed
    PROFICIENT = "proficient"  # Competent, LLM as validator
    MASTERED = "mastered"      # Expert, LLM only for edge validation


# Thresholds for skill level transitions
SKILL_THRESHOLDS = {
    "developing_to_proficient": {
        "min_attempts": 10,
        "min_accuracy": 0.70,
        "max_variance": 0.15,
    },
    "proficient_to_mastered": {
        "min_attempts": 25,
        "min_accuracy": 0.90,
        "max_variance": 0.08,
        "min_streak": 5,  # Consecutive successes
    },
    "mastered_to_proficient": {
        # Regression conditions
        "accuracy_drop_to": 0.80,
        "failure_streak": 3,
    },
    "proficient_to_developing": {
        # Major regression
        "accuracy_drop_to": 0.60,
        "failure_streak": 5,
    },
}


class SkillProfile:
    """
    Skill profile for a single task type.

    Tracks performance metrics and determines skill level.
    """

    def __init__(
        self,
        task_type: TaskType,
        level: SkillLevel = SkillLevel.DEVELOPING,
        success_count: int = 0,
        failure_count: int = 0,
        recent_outcomes: Optional[List[bool]] = None,
        last_cci_score: float = 0.0,
        consecutive_successes: int = 0,
        consecutive_failures: int = 0,
        last_updated: float = 0.0,
    ):
        self.task_type = task_type
        self.level = level
        self.success_count = success_count
        self.failure_count = failure_count
        self.recent_outcomes = recent_outcomes or []  # Last 20 outcomes
        self.last_cci_score = last_cci_score
        self.consecutive_successes = consecutive_successes
        self.consecutive_failures = consecutive_failures
        self.last_updated = last_updated or time.time()

    @property
    def total_attempts(self) -> int:
        """Total number of attempts."""
        return self.success_count + self.failure_count

    @property
    def accuracy(self) -> float:
        """Overall accuracy rate."""
        if self.total_attempts == 0:
            return 0.0
        return self.success_count / self.total_attempts

    @property
    def rolling_accuracy(self) -> float:
        """Accuracy over recent outcomes (last 20)."""
        if not self.recent_outcomes:
            return 0.0
        return sum(1 for o in self.recent_outcomes if o) / len(self.recent_outcomes)

    @property
    def rolling_variance(self) -> float:
        """Variance in recent outcomes."""
        if len(self.recent_outcomes) < 5:
            return 1.0  # High variance when insufficient data
        mean = self.rolling_accuracy
        variance = sum((1.0 if o else 0.0 - mean) ** 2 for o in self.recent_outcomes)
        return variance / len(self.recent_outcomes)

    def record_outcome(self, success: bool, cci_score: Optional[float] = None) -> None:
        """
        Record a task completion outcome.

        Args:
            success: Whether the task was successful
            cci_score: Optional CCI score for this attempt
        """
        if success:
            self.success_count += 1
            self.consecutive_successes += 1
            self.consecutive_failures = 0
        else:
            self.failure_count += 1
            self.consecutive_failures += 1
            self.consecutive_successes = 0

        # Update recent outcomes (rolling window of 20)
        self.recent_outcomes.append(success)
        if len(self.recent_outcomes) > 20:
            self.recent_outcomes.pop(0)

        if cci_score is not None:
            self.last_cci_score = cci_score

        self.last_updated = time.time()

        # Check for level transitions
        self._update_level()

    def _update_level(self) -> None:
        """Update skill level based on current metrics."""
        thresholds = SKILL_THRESHOLDS

        if self.level == SkillLevel.DEVELOPING:
            # Check for promotion to PROFICIENT
            t = thresholds["developing_to_proficient"]
            if (
                self.total_attempts >= t["min_attempts"]
                and self.rolling_accuracy >= t["min_accuracy"]
                and self.rolling_variance <= t["max_variance"]
            ):
                print(f"[SKILL_TRACKER] {self.task_type.value}: DEVELOPING -> PROFICIENT")
                self.level = SkillLevel.PROFICIENT

        elif self.level == SkillLevel.PROFICIENT:
            # Check for promotion to MASTERED
            t_up = thresholds["proficient_to_mastered"]
            if (
                self.total_attempts >= t_up["min_attempts"]
                and self.rolling_accuracy >= t_up["min_accuracy"]
                and self.rolling_variance <= t_up["max_variance"]
                and self.consecutive_successes >= t_up["min_streak"]
            ):
                print(f"[SKILL_TRACKER] {self.task_type.value}: PROFICIENT -> MASTERED")
                self.level = SkillLevel.MASTERED

            # Check for regression to DEVELOPING
            t_down = thresholds["proficient_to_developing"]
            if (
                self.rolling_accuracy < t_down["accuracy_drop_to"]
                or self.consecutive_failures >= t_down["failure_streak"]
            ):
                print(f"[SKILL_TRACKER] {self.task_type.value}: PROFICIENT -> DEVELOPING (regression)")
                self.level = SkillLevel.DEVELOPING

        elif self.level == SkillLevel.MASTERED:
            # Check for regression to PROFICIENT
            t = thresholds["mastered_to_proficient"]
            if (
                self.rolling_accuracy < t["accuracy_drop_to"]
                or self.consecutive_failures >= t["failure_streak"]
            ):
                print(f"[SKILL_TRACKER] {self.task_type.value}: MASTERED -> PROFICIENT (regression)")
                self.level = SkillLevel.PROFICIENT

    def should_use_llm_teacher(self) -> bool:
        """Whether LLM should be used as fallback teacher."""
        return self.level == SkillLevel.DEVELOPING

    def should_use_llm_validator(self) -> bool:
        """Whether LLM should be used for validation."""
        return self.level in (SkillLevel.PROFICIENT, SkillLevel.MASTERED)

    def can_skip_llm(self) -> bool:
        """Whether the brain can answer without any LLM involvement."""
        return (
            self.level == SkillLevel.MASTERED
            and self.consecutive_successes >= 3
        )

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "task_type": self.task_type.value,
            "level": self.level.value,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "recent_outcomes": self.recent_outcomes,
            "last_cci_score": self.last_cci_score,
            "consecutive_successes": self.consecutive_successes,
            "consecutive_failures": self.consecutive_failures,
            "last_updated": self.last_updated,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SkillProfile":
        """Deserialize from dictionary."""
        return cls(
            task_type=TaskType(data.get("task_type", "unknown")),
            level=SkillLevel(data.get("level", "developing")),
            success_count=data.get("success_count", 0),
            failure_count=data.get("failure_count", 0),
            recent_outcomes=data.get("recent_outcomes", []),
            last_cci_score=data.get("last_cci_score", 0.0),
            consecutive_successes=data.get("consecutive_successes", 0),
            consecutive_failures=data.get("consecutive_failures", 0),
            last_updated=data.get("last_updated", 0.0),
        )


class SkillTracker:
    """
    Global skill tracker for all task types.

    Maintains skill profiles for each task type and provides
    methods for querying and updating skill levels.
    """

    def __init__(self):
        self._profiles: Dict[TaskType, SkillProfile] = {}
        self._memory: Optional[BrainMemory] = None
        self._load_profiles()

    def _load_profiles(self) -> None:
        """Load skill profiles from persistent storage."""
        # Initialize memory
        if BrainMemory:
            try:
                self._memory = BrainMemory("skill_tracker")
            except Exception as e:
                print(f"[SKILL_TRACKER] Memory init failed: {e}")

        # Try to load from memory
        if self._memory:
            try:
                records = self._memory.retrieve(query="skill_profile", limit=20)
                for record in records:
                    content = record.get("content", "")
                    if isinstance(content, str):
                        try:
                            data = json.loads(content)
                            profile = SkillProfile.from_dict(data)
                            self._profiles[profile.task_type] = profile
                        except (json.JSONDecodeError, ValueError):
                            pass
            except Exception as e:
                print(f"[SKILL_TRACKER] Failed to load profiles: {e}")

        # Initialize missing profiles
        for task_type in TaskType:
            if task_type not in self._profiles:
                self._profiles[task_type] = SkillProfile(task_type)

    def _save_profile(self, profile: SkillProfile) -> None:
        """Save a skill profile to persistent storage."""
        if not self._memory:
            return

        try:
            self._memory.store(
                content=json.dumps(profile.to_dict()),
                metadata={
                    "kind": "skill_profile",
                    "task_type": profile.task_type.value,
                    "level": profile.level.value,
                }
            )
        except Exception as e:
            print(f"[SKILL_TRACKER] Failed to save profile: {e}")

    def get_profile(self, task_type: TaskType) -> SkillProfile:
        """Get the skill profile for a task type."""
        if task_type not in self._profiles:
            self._profiles[task_type] = SkillProfile(task_type)
        return self._profiles[task_type]

    def record_outcome(
        self,
        task_type: TaskType,
        success: bool,
        cci_score: Optional[float] = None,
    ) -> SkillProfile:
        """
        Record an outcome for a task type.

        Args:
            task_type: The task type
            success: Whether the task was successful
            cci_score: Optional CCI score

        Returns:
            Updated skill profile
        """
        profile = self.get_profile(task_type)
        old_level = profile.level
        profile.record_outcome(success, cci_score)

        if profile.level != old_level:
            print(f"[SKILL_TRACKER] Level changed: {task_type.value} {old_level.value} -> {profile.level.value}")

        self._save_profile(profile)
        return profile

    def get_llm_mode(self, task_type: TaskType) -> Tuple[bool, bool, bool]:
        """
        Get LLM usage mode for a task type.

        Returns:
            Tuple of (use_as_teacher, use_as_validator, can_skip_llm)
        """
        profile = self.get_profile(task_type)
        return (
            profile.should_use_llm_teacher(),
            profile.should_use_llm_validator(),
            profile.can_skip_llm(),
        )

    def get_all_profiles(self) -> Dict[TaskType, SkillProfile]:
        """Get all skill profiles."""
        return dict(self._profiles)

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary of all skill levels."""
        summary = {
            "total_task_types": len(TaskType),
            "by_level": {
                "developing": 0,
                "proficient": 0,
                "mastered": 0,
            },
            "task_types": {},
        }

        for task_type, profile in self._profiles.items():
            level_key = profile.level.value
            summary["by_level"][level_key] += 1
            summary["task_types"][task_type.value] = {
                "level": profile.level.value,
                "accuracy": round(profile.rolling_accuracy, 3),
                "attempts": profile.total_attempts,
            }

        return summary


# Global singleton instance
_tracker: Optional[SkillTracker] = None


def get_skill_tracker() -> SkillTracker:
    """Get the global skill tracker instance."""
    global _tracker
    if _tracker is None:
        _tracker = SkillTracker()
    return _tracker


def record_task_outcome(
    task_type: TaskType,
    success: bool,
    cci_score: Optional[float] = None,
) -> SkillProfile:
    """
    Convenience function to record a task outcome.

    Args:
        task_type: The task type
        success: Whether successful
        cci_score: Optional CCI score

    Returns:
        Updated skill profile
    """
    return get_skill_tracker().record_outcome(task_type, success, cci_score)


def get_llm_mode(task_type: TaskType) -> Tuple[bool, bool, bool]:
    """
    Convenience function to get LLM mode for a task type.

    Returns:
        Tuple of (use_as_teacher, use_as_validator, can_skip_llm)
    """
    return get_skill_tracker().get_llm_mode(task_type)


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for skill tracking.

    Operations:
    - GET_PROFILE: Get skill profile for a task type
    - RECORD_OUTCOME: Record a success/failure for a task type
    - GET_LLM_MODE: Get whether LLM should be used as teacher/validator
    - GET_SUMMARY: Get summary of all skill levels
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    tracker = get_skill_tracker()

    if op == "GET_PROFILE":
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        profile = tracker.get_profile(task_type)
        return {
            "ok": True,
            "payload": profile.to_dict()
        }

    elif op == "RECORD_OUTCOME":
        task_type_str = payload.get("task_type", "unknown")
        success = payload.get("success", False)
        cci_score = payload.get("cci_score")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        profile = tracker.record_outcome(task_type, success, cci_score)
        return {
            "ok": True,
            "payload": profile.to_dict()
        }

    elif op == "GET_LLM_MODE":
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        use_teacher, use_validator, can_skip = tracker.get_llm_mode(task_type)
        return {
            "ok": True,
            "payload": {
                "use_as_teacher": use_teacher,
                "use_as_validator": use_validator,
                "can_skip_llm": can_skip,
                "skill_level": tracker.get_profile(task_type).level.value,
            }
        }

    elif op == "GET_SUMMARY":
        return {
            "ok": True,
            "payload": tracker.get_summary()
        }

    # Domain-based tracking operations
    elif op == "GET_DOMAIN_PROFILE":
        domain_str = payload.get("domain", "unknown")
        profile = get_domain_tracker().get_profile(domain_str)
        return {"ok": True, "payload": profile.to_dict()}

    elif op == "RECORD_DOMAIN_OUTCOME":
        domain_str = payload.get("domain", "unknown")
        success = payload.get("success", False)
        shadow_score = payload.get("shadow_score", 0.0)
        profile = get_domain_tracker().record_outcome(domain_str, success, shadow_score)
        return {"ok": True, "payload": profile.to_dict()}

    elif op == "CHECK_TAKEOVER_READY":
        domain_str = payload.get("domain", "unknown")
        result = get_domain_tracker().check_takeover_ready(domain_str)
        return {"ok": True, "payload": result}

    elif op == "GET_TAKEOVER_DOMAINS":
        domains = get_domain_tracker().get_takeover_domains()
        return {"ok": True, "payload": {"domains": domains}}

    elif op == "GET_DOMAIN_SUMMARY":
        return {"ok": True, "payload": get_domain_tracker().get_summary()}

    return {"ok": False, "error": f"Unknown op: {op}"}


# =============================================================================
# DOMAIN-BASED TRACKING (Learning Loop Architecture)
# =============================================================================
# Tracks performance per DOMAIN (maven_self, python_help, etc.)
# to determine when Maven can take over from Teacher in that domain.

# Thresholds for domain takeover
DOMAIN_TAKEOVER_THRESHOLDS = {
    "min_shadow_turns": 50,      # Minimum shadow comparisons needed
    "min_avg_shadow_score": 0.8, # Minimum average shadow score
    "max_complaint_rate": 0.05,  # Maximum user complaint rate
    "min_good_ratio": 0.8,       # Minimum ratio of good/comparable shadows
}


class DomainProfile:
    """
    Skill profile for a specific domain.

    Tracks shadow comparison performance to determine
    when Maven can take over from Teacher in this domain.
    """

    def __init__(
        self,
        domain: str,
        total_shadow_turns: int = 0,
        good_shadow_turns: int = 0,
        bad_shadow_turns: int = 0,
        total_shadow_score: float = 0.0,
        user_complaints: int = 0,
        teacher_quality_fails: int = 0,
        recent_outcomes: Optional[List[bool]] = None,
        recent_shadow_scores: Optional[List[float]] = None,
        takeover_enabled: bool = False,
        last_updated: float = 0.0,
    ):
        self.domain = domain
        self.total_shadow_turns = total_shadow_turns
        self.good_shadow_turns = good_shadow_turns
        self.bad_shadow_turns = bad_shadow_turns
        self.total_shadow_score = total_shadow_score
        self.user_complaints = user_complaints
        self.teacher_quality_fails = teacher_quality_fails
        self.recent_outcomes = recent_outcomes or []
        self.recent_shadow_scores = recent_shadow_scores or []
        self.takeover_enabled = takeover_enabled
        self.last_updated = last_updated or time.time()

    @property
    def avg_shadow_score(self) -> float:
        if self.total_shadow_turns == 0:
            return 0.0
        return self.total_shadow_score / self.total_shadow_turns

    @property
    def good_ratio(self) -> float:
        total = self.good_shadow_turns + self.bad_shadow_turns
        if total == 0:
            return 0.0
        return self.good_shadow_turns / total

    @property
    def complaint_rate(self) -> float:
        if self.total_shadow_turns == 0:
            return 0.0
        return self.user_complaints / self.total_shadow_turns

    @property
    def rolling_shadow_score(self) -> float:
        if not self.recent_shadow_scores:
            return 0.0
        return sum(self.recent_shadow_scores) / len(self.recent_shadow_scores)

    def record_shadow_outcome(
        self,
        success: bool,
        shadow_score: float = 0.0,
    ) -> None:
        """Record a shadow comparison outcome."""
        self.total_shadow_turns += 1
        self.total_shadow_score += shadow_score

        if success or shadow_score >= 0.7:
            self.good_shadow_turns += 1
        else:
            self.bad_shadow_turns += 1

        # Update rolling windows
        self.recent_outcomes.append(success)
        if len(self.recent_outcomes) > 50:
            self.recent_outcomes.pop(0)

        self.recent_shadow_scores.append(shadow_score)
        if len(self.recent_shadow_scores) > 50:
            self.recent_shadow_scores.pop(0)

        self.last_updated = time.time()

        # Check for takeover eligibility
        self._check_takeover_eligibility()

    def record_complaint(self) -> None:
        """Record a user complaint in this domain."""
        self.user_complaints += 1
        self.last_updated = time.time()
        self._check_takeover_eligibility()

    def record_quality_fail(self) -> None:
        """Record a Teacher quality failure."""
        self.teacher_quality_fails += 1
        self.last_updated = time.time()

    def _check_takeover_eligibility(self) -> None:
        """Check if domain is eligible for Maven takeover."""
        t = DOMAIN_TAKEOVER_THRESHOLDS

        was_enabled = self.takeover_enabled

        # Check all criteria
        eligible = (
            self.total_shadow_turns >= t["min_shadow_turns"]
            and self.avg_shadow_score >= t["min_avg_shadow_score"]
            and self.complaint_rate <= t["max_complaint_rate"]
            and self.good_ratio >= t["min_good_ratio"]
        )

        self.takeover_enabled = eligible

        if eligible and not was_enabled:
            print(f"[DOMAIN_TRACKER] Domain '{self.domain}' is now TAKEOVER READY!")
        elif not eligible and was_enabled:
            print(f"[DOMAIN_TRACKER] Domain '{self.domain}' lost takeover eligibility")

    def to_dict(self) -> Dict[str, Any]:
        return {
            "domain": self.domain,
            "total_shadow_turns": self.total_shadow_turns,
            "good_shadow_turns": self.good_shadow_turns,
            "bad_shadow_turns": self.bad_shadow_turns,
            "avg_shadow_score": self.avg_shadow_score,
            "good_ratio": self.good_ratio,
            "user_complaints": self.user_complaints,
            "complaint_rate": self.complaint_rate,
            "teacher_quality_fails": self.teacher_quality_fails,
            "rolling_shadow_score": self.rolling_shadow_score,
            "takeover_enabled": self.takeover_enabled,
            "last_updated": self.last_updated,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "DomainProfile":
        return cls(
            domain=data.get("domain", "unknown"),
            total_shadow_turns=data.get("total_shadow_turns", 0),
            good_shadow_turns=data.get("good_shadow_turns", 0),
            bad_shadow_turns=data.get("bad_shadow_turns", 0),
            total_shadow_score=data.get("total_shadow_score", 0.0),
            user_complaints=data.get("user_complaints", 0),
            teacher_quality_fails=data.get("teacher_quality_fails", 0),
            recent_outcomes=data.get("recent_outcomes", []),
            recent_shadow_scores=data.get("recent_shadow_scores", []),
            takeover_enabled=data.get("takeover_enabled", False),
            last_updated=data.get("last_updated", 0.0),
        )


class DomainTracker:
    """
    Tracks performance per domain for Maven takeover decisions.

    When a domain reaches takeover eligibility, Maven can answer
    directly without Teacher in that domain.
    """

    def __init__(self):
        self._profiles: Dict[str, DomainProfile] = {}
        self._memory: Optional[BrainMemory] = None
        self._load_profiles()

    def _load_profiles(self) -> None:
        """Load domain profiles from persistent storage."""
        if BrainMemory:
            try:
                self._memory = BrainMemory("domain_tracker")
            except Exception as e:
                print(f"[DOMAIN_TRACKER] Memory init failed: {e}")

        # Initialize common domains
        common_domains = [
            "maven_self", "project_maven", "python_help",
            "general_knowledge", "personal", "planning",
            "code_help", "unknown",
        ]
        for domain in common_domains:
            if domain not in self._profiles:
                self._profiles[domain] = DomainProfile(domain)

    def _save_profile(self, profile: DomainProfile) -> None:
        """Save a domain profile to persistent storage."""
        if not self._memory:
            return
        try:
            import json
            self._memory.store(
                content=json.dumps(profile.to_dict()),
                metadata={
                    "kind": "domain_profile",
                    "domain": profile.domain,
                    "takeover_enabled": profile.takeover_enabled,
                }
            )
        except Exception as e:
            print(f"[DOMAIN_TRACKER] Failed to save profile: {e}")

    def get_profile(self, domain: str) -> DomainProfile:
        """Get the profile for a domain."""
        if domain not in self._profiles:
            self._profiles[domain] = DomainProfile(domain)
        return self._profiles[domain]

    def record_outcome(
        self,
        domain: str,
        success: bool,
        shadow_score: float = 0.0,
    ) -> DomainProfile:
        """Record a shadow comparison outcome for a domain."""
        profile = self.get_profile(domain)
        profile.record_shadow_outcome(success, shadow_score)
        self._save_profile(profile)
        return profile

    def record_complaint(self, domain: str) -> None:
        """Record a user complaint for a domain."""
        profile = self.get_profile(domain)
        profile.record_complaint()
        self._save_profile(profile)

    def record_quality_fail(self, domain: str) -> None:
        """Record a Teacher quality failure for a domain."""
        profile = self.get_profile(domain)
        profile.record_quality_fail()
        self._save_profile(profile)

    def check_takeover_ready(self, domain: str) -> Dict[str, Any]:
        """Check if a domain is ready for Maven takeover."""
        profile = self.get_profile(domain)
        t = DOMAIN_TAKEOVER_THRESHOLDS

        return {
            "domain": domain,
            "ready": profile.takeover_enabled,
            "metrics": {
                "total_shadow_turns": profile.total_shadow_turns,
                "min_required": t["min_shadow_turns"],
                "avg_shadow_score": profile.avg_shadow_score,
                "min_required_score": t["min_avg_shadow_score"],
                "complaint_rate": profile.complaint_rate,
                "max_allowed_complaints": t["max_complaint_rate"],
                "good_ratio": profile.good_ratio,
                "min_required_ratio": t["min_good_ratio"],
            },
            "blocking_reasons": self._get_blocking_reasons(profile),
        }

    def _get_blocking_reasons(self, profile: DomainProfile) -> List[str]:
        """Get reasons why a domain is not takeover ready."""
        reasons = []
        t = DOMAIN_TAKEOVER_THRESHOLDS

        if profile.total_shadow_turns < t["min_shadow_turns"]:
            reasons.append(f"Not enough turns: {profile.total_shadow_turns}/{t['min_shadow_turns']}")
        if profile.avg_shadow_score < t["min_avg_shadow_score"]:
            reasons.append(f"Shadow score too low: {profile.avg_shadow_score:.2f}/{t['min_avg_shadow_score']}")
        if profile.complaint_rate > t["max_complaint_rate"]:
            reasons.append(f"Too many complaints: {profile.complaint_rate:.2f}/{t['max_complaint_rate']}")
        if profile.good_ratio < t["min_good_ratio"]:
            reasons.append(f"Good ratio too low: {profile.good_ratio:.2f}/{t['min_good_ratio']}")

        return reasons

    def get_takeover_domains(self) -> List[str]:
        """Get list of domains where Maven can take over."""
        return [
            domain for domain, profile in self._profiles.items()
            if profile.takeover_enabled
        ]

    def can_maven_answer(self, domain: str) -> bool:
        """Check if Maven can answer directly for a domain."""
        profile = self.get_profile(domain)
        return profile.takeover_enabled

    def get_summary(self) -> Dict[str, Any]:
        """Get summary of all domain profiles."""
        summary = {
            "total_domains": len(self._profiles),
            "takeover_ready": 0,
            "domains": {},
        }

        for domain, profile in self._profiles.items():
            if profile.takeover_enabled:
                summary["takeover_ready"] += 1
            summary["domains"][domain] = {
                "total_turns": profile.total_shadow_turns,
                "avg_score": round(profile.avg_shadow_score, 3),
                "good_ratio": round(profile.good_ratio, 3),
                "takeover_ready": profile.takeover_enabled,
            }

        return summary


# Global singleton
_domain_tracker: Optional[DomainTracker] = None


def get_domain_tracker() -> DomainTracker:
    """Get the global domain tracker instance."""
    global _domain_tracker
    if _domain_tracker is None:
        _domain_tracker = DomainTracker()
    return _domain_tracker


def record_domain_outcome(
    domain: str,
    success: bool,
    shadow_score: float = 0.0,
) -> DomainProfile:
    """Convenience function to record a domain outcome."""
    return get_domain_tracker().record_outcome(domain, success, shadow_score)


def can_maven_answer_for_domain(domain: str) -> bool:
    """Check if Maven can answer directly for a domain."""
    return get_domain_tracker().can_maven_answer(domain)


handle = service_api
