"""
Teacher Gating System
======================

Controls LLM access based on skill level for each task type.

Behavior by Skill Level:
- DEVELOPING: LLM as teacher (fallback), learn from every interaction
- PROFICIENT: LLM as validator only, brain answer is primary
- MASTERED: LLM only for edge validation, brain can skip LLM entirely

This module wraps Teacher calls and enforces the learning contract.
"""

from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from typing import Dict, Any, Optional, Callable
import time

from brains.cognitive.learning_contract.task_types import (
    TaskType,
    classify_task_type,
)
from brains.cognitive.learning_contract.skill_tracker import (
    get_skill_tracker,
    SkillLevel,
    record_task_outcome,
)
from brains.cognitive.learning_contract.episode_storage import (
    record_teacher_episode,
    record_validation_episode,
    BrainAttempt,
    LLMResponse,
    Evaluation,
    IdealBlueprint,
    FailureTrace,
    FailureCategory,
)
from brains.cognitive.learning_contract.rule_example_fusion import (
    get_fusion_engine,
)
from brains.cognitive.learning_contract.self_correction_pipeline import (
    run_self_correction,
)
from brains.cognitive.learning_contract.answer_fusion import (
    fuse_answers,
    FusedAnswer,
)


class TeacherMode(Enum):
    """Mode of teacher/LLM usage."""
    DISABLED = "disabled"       # No LLM access (teacher-free mode)
    TEACHER = "teacher"         # LLM as fallback teacher (generating)
    VALIDATOR = "validator"     # LLM as validator only (checking)
    FULL = "full"              # Full LLM access (for testing)


@dataclass
class GatingDecision:
    """Decision from the gating system."""
    mode: TeacherMode
    skill_level: SkillLevel
    reason: str
    brain_confidence: float = 0.0
    can_proceed_without_llm: bool = False


@dataclass
class TeacherResult:
    """Result from a gated teacher call."""
    answer: str
    source: str  # "brain", "teacher", "validator_approved", "validator_rejected"
    skill_level: SkillLevel
    episode_id: Optional[str] = None
    confidence: float = 0.0
    learning_occurred: bool = False


class TeacherGating:
    """
    Gating layer for Teacher/LLM access.

    Enforces the learning contract:
    - Brain tries first
    - LLM used only according to skill level
    - Every LLM interaction triggers learning
    """

    def __init__(self):
        self._teacher_api: Optional[Callable] = None
        self._teacher_free_mode: bool = False
        self._init_teacher()

    def _init_teacher(self) -> None:
        """Initialize connection to Teacher brain."""
        try:
            from brains.cognitive.teacher.service.teacher_brain import service_api
            self._teacher_api = service_api
        except ImportError:
            print("[TEACHER_GATING] Teacher brain not available")

    def set_teacher_free_mode(self, enabled: bool) -> None:
        """
        Enable/disable teacher-free mode.

        When enabled, all Teacher calls are blocked.
        Used for stress tests and skill evaluation.
        """
        self._teacher_free_mode = enabled
        print(f"[TEACHER_GATING] Teacher-free mode: {enabled}")

    def get_gating_decision(
        self,
        query: str,
        task_type: Optional[TaskType] = None,
        brain_confidence: float = 0.0,
    ) -> GatingDecision:
        """
        Get the gating decision for a query.

        Args:
            query: The user's query
            task_type: Pre-classified task type (or will be classified)
            brain_confidence: Brain's confidence in its answer

        Returns:
            GatingDecision indicating how LLM should be used
        """
        # Classify task type if not provided
        if task_type is None:
            task_type = classify_task_type(query)

        # Get skill level for this task type
        tracker = get_skill_tracker()
        profile = tracker.get_profile(task_type)
        skill_level = profile.level

        # Teacher-free mode overrides everything
        if self._teacher_free_mode:
            return GatingDecision(
                mode=TeacherMode.DISABLED,
                skill_level=skill_level,
                reason="Teacher-free mode enabled",
                brain_confidence=brain_confidence,
                can_proceed_without_llm=True,
            )

        # Decision based on skill level
        if skill_level == SkillLevel.DEVELOPING:
            # Can use LLM as teacher if brain confidence is low
            if brain_confidence < 0.6:
                return GatingDecision(
                    mode=TeacherMode.TEACHER,
                    skill_level=skill_level,
                    reason="Skill developing, brain confidence low - teacher allowed",
                    brain_confidence=brain_confidence,
                    can_proceed_without_llm=False,
                )
            else:
                return GatingDecision(
                    mode=TeacherMode.VALIDATOR,
                    skill_level=skill_level,
                    reason="Skill developing, brain confidence OK - validate only",
                    brain_confidence=brain_confidence,
                    can_proceed_without_llm=False,
                )

        elif skill_level == SkillLevel.PROFICIENT:
            # LLM as validator only
            return GatingDecision(
                mode=TeacherMode.VALIDATOR,
                skill_level=skill_level,
                reason="Skill proficient - validate only",
                brain_confidence=brain_confidence,
                can_proceed_without_llm=brain_confidence >= 0.8,
            )

        elif skill_level == SkillLevel.MASTERED:
            # Brain can proceed without LLM
            if brain_confidence >= 0.9:
                return GatingDecision(
                    mode=TeacherMode.DISABLED,
                    skill_level=skill_level,
                    reason="Skill mastered, high confidence - no LLM needed",
                    brain_confidence=brain_confidence,
                    can_proceed_without_llm=True,
                )
            else:
                return GatingDecision(
                    mode=TeacherMode.VALIDATOR,
                    skill_level=skill_level,
                    reason="Skill mastered, moderate confidence - edge validation",
                    brain_confidence=brain_confidence,
                    can_proceed_without_llm=True,
                )

        # Fallback
        return GatingDecision(
            mode=TeacherMode.TEACHER,
            skill_level=skill_level,
            reason="Unknown skill state - teacher allowed",
            brain_confidence=brain_confidence,
            can_proceed_without_llm=False,
        )

    def process_query(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> TeacherResult:
        """
        Process a query through the full learning contract pipeline.

        1. Classify task type
        2. Run brain-first attempt with self-correction
        3. Get gating decision
        4. Use LLM according to skill level
        5. Record learning episode
        6. Update skill level

        Args:
            query: The user's query
            context: Optional context

        Returns:
            TeacherResult with the answer and learning info
        """
        # Step 1: Classify task type
        task_type = classify_task_type(query, context)

        # Step 2: Run brain-first attempt with 3-pass self-correction
        correction_result = run_self_correction(query, task_type, context)
        brain_answer = correction_result.final_output
        brain_confidence = 0.5 + correction_result.confidence_boost

        # Adjust confidence if answer still needs work
        if correction_result.needs_llm:
            brain_confidence *= 0.8

        # Step 3: Get gating decision
        decision = self.get_gating_decision(query, task_type, brain_confidence)

        print(f"[TEACHER_GATING] Task: {task_type.value}, "
              f"Skill: {decision.skill_level.value}, "
              f"Mode: {decision.mode.value}")

        # Step 4: Handle based on mode
        if decision.mode == TeacherMode.DISABLED:
            # No LLM - return brain answer directly
            return TeacherResult(
                answer=brain_answer,
                source="brain",
                skill_level=decision.skill_level,
                confidence=brain_confidence,
                learning_occurred=False,
            )

        elif decision.mode == TeacherMode.TEACHER:
            # Use LLM as fallback teacher
            return self._use_as_teacher(
                query=query,
                task_type=task_type,
                brain_answer=brain_answer,
                brain_confidence=brain_confidence,
                correction_result=correction_result,
                context=context,
            )

        elif decision.mode == TeacherMode.VALIDATOR:
            # Use LLM as validator
            return self._use_as_validator(
                query=query,
                task_type=task_type,
                brain_answer=brain_answer,
                brain_confidence=brain_confidence,
                correction_result=correction_result,
                context=context,
            )

        # Fallback
        return TeacherResult(
            answer=brain_answer,
            source="brain",
            skill_level=decision.skill_level,
            confidence=brain_confidence,
            learning_occurred=False,
        )

    def _use_as_teacher(
        self,
        query: str,
        task_type: TaskType,
        brain_answer: str,
        brain_confidence: float,
        correction_result: Any,
        context: Optional[Dict[str, Any]],
    ) -> TeacherResult:
        """
        Use LLM as fallback teacher.

        The LLM generates an answer, but:
        - Brain's answer is compared to LLM's
        - A full learning episode is recorded
        - Skill level is updated
        """
        if not self._teacher_api:
            return TeacherResult(
                answer=brain_answer,
                source="brain",
                skill_level=SkillLevel.DEVELOPING,
                confidence=brain_confidence,
                learning_occurred=False,
            )

        # Call Teacher for answer
        try:
            teacher_result = self._teacher_api({
                "op": "TEACH",
                "payload": {
                    "question": query,
                    "context": context or {},
                }
            })

            if not teacher_result.get("ok"):
                # Teacher failed - use brain answer
                return TeacherResult(
                    answer=brain_answer,
                    source="brain",
                    skill_level=SkillLevel.DEVELOPING,
                    confidence=brain_confidence,
                    learning_occurred=False,
                )

            teacher_answer = teacher_result.get("payload", {}).get("answer", "")
            teacher_reasoning = teacher_result.get("payload", {}).get("reasoning", "")

        except Exception as e:
            print(f"[TEACHER_GATING] Teacher call failed: {e}")
            return TeacherResult(
                answer=brain_answer,
                source="brain",
                skill_level=SkillLevel.DEVELOPING,
                confidence=brain_confidence,
                learning_occurred=False,
            )

        # Compare brain and teacher answers
        brain_was_correct = self._compare_answers(brain_answer, teacher_answer)

        # CRITICAL: Fuse answers - brain must never output raw LLM
        # The brain incorporates teacher's teaching into its own answer
        fused_result = fuse_answers(
            brain_draft=brain_answer,
            teacher_answer=teacher_answer,
            task_type=task_type,
            brain_confidence=brain_confidence,
        )

        # Create learning episode
        brain_attempt = BrainAttempt(
            draft_output=brain_answer,
            reasoning_trace=["Brain-first synthesis", f"Fusion type: {fused_result.fusion_type}"],
            constraints_applied=[],
            confidence=brain_confidence,
            self_corrections=[{"fusion": c} for c in fused_result.changes_made],
        )

        llm_response = LLMResponse(
            role="teacher",
            reasoning=teacher_reasoning,
            final_answer=teacher_answer,
        )

        evaluation = Evaluation(
            brain_was_correct=brain_was_correct,
            failure_category=None if brain_was_correct else FailureCategory.UNKNOWN,
            what_was_wrong="" if brain_was_correct else "Brain answer differed from teacher",
            what_was_better=teacher_answer if not brain_was_correct else "",
            fix_applied="; ".join(fused_result.changes_made),
        )

        # Record episode
        episode = record_teacher_episode(
            task_type=task_type,
            input_query=query,
            brain_attempt=brain_attempt,
            llm_response=llm_response,
            evaluation=evaluation,
            context=context,
        )

        # Enqueue for background learning
        try:
            from brains.cognitive.learning_contract.learning_daemon import (
                enqueue_for_learning,
            )
            enqueue_for_learning(episode)
        except ImportError:
            pass

        # Update skill level
        record_task_outcome(task_type, brain_was_correct)

        # Learn from correction if needed
        if not brain_was_correct:
            get_fusion_engine().learn_from_correction(
                original_attempt=brain_answer,
                corrected_answer=teacher_answer,
                query=query,
                task_type=task_type,
            )

        # Return FUSED answer - brain authored, teacher informed
        # Confidence based on fusion type and brain contribution
        fused_confidence = 0.6 + (fused_result.brain_contribution * 0.3)

        return TeacherResult(
            answer=fused_result.fused_output,
            source="teacher_fused",  # Indicates fusion was applied
            skill_level=SkillLevel.DEVELOPING,
            episode_id=episode.episode_id,
            confidence=fused_confidence,
            learning_occurred=True,
        )

    def _use_as_validator(
        self,
        query: str,
        task_type: TaskType,
        brain_answer: str,
        brain_confidence: float,
        correction_result: Any,
        context: Optional[Dict[str, Any]],
    ) -> TeacherResult:
        """
        Use LLM as validator only.

        Brain's answer is primary. LLM just validates for:
        - Fact accuracy
        - Constraint adherence
        - Coherence
        - Structural correctness
        """
        if not self._teacher_api:
            return TeacherResult(
                answer=brain_answer,
                source="brain",
                skill_level=SkillLevel.PROFICIENT,
                confidence=brain_confidence,
                learning_occurred=False,
            )

        # Call Teacher for validation
        try:
            validation_result = self._teacher_api({
                "op": "TEACH",
                "payload": {
                    "question": f"Validate this answer to the question '{query}':\n\n{brain_answer}\n\nIs this answer correct, complete, and well-structured? Reply with APPROVED or REJECTED with brief reason.",
                    "context": context or {},
                }
            })

            if not validation_result.get("ok"):
                # Validation failed - use brain answer anyway
                return TeacherResult(
                    answer=brain_answer,
                    source="brain",
                    skill_level=SkillLevel.PROFICIENT,
                    confidence=brain_confidence,
                    learning_occurred=False,
                )

            validation_answer = validation_result.get("payload", {}).get("answer", "")
            approved = "APPROVED" in validation_answer.upper()

        except Exception as e:
            print(f"[TEACHER_GATING] Validation call failed: {e}")
            return TeacherResult(
                answer=brain_answer,
                source="brain",
                skill_level=SkillLevel.PROFICIENT,
                confidence=brain_confidence,
                learning_occurred=False,
            )

        # Create learning episode
        brain_attempt = BrainAttempt(
            draft_output=brain_answer,
            confidence=brain_confidence,
        )

        llm_response = LLMResponse(
            role="validator",
            final_answer=validation_answer,
            validation_verdict="approved" if approved else "rejected",
        )

        # Record episode
        episode = record_validation_episode(
            task_type=task_type,
            input_query=query,
            brain_attempt=brain_attempt,
            llm_response=llm_response,
            approved=approved,
            context=context,
        )

        # Enqueue for background learning
        try:
            from brains.cognitive.learning_contract.learning_daemon import (
                enqueue_for_learning,
            )
            enqueue_for_learning(episode)
        except ImportError:
            pass

        # Update skill level
        record_task_outcome(task_type, approved)

        # Determine source
        if approved:
            source = "validator_approved"
        else:
            source = "validator_rejected"
            # Brain still answers, but we record the feedback

        return TeacherResult(
            answer=brain_answer,  # Brain answer is always used
            source=source,
            skill_level=SkillLevel.PROFICIENT,
            episode_id=episode.episode_id,
            confidence=brain_confidence if approved else brain_confidence * 0.7,
            learning_occurred=True,
        )

    def _compare_answers(self, brain: str, teacher: str) -> bool:
        """
        Compare brain and teacher answers for correctness.

        Simple implementation - checks if they're substantively similar.
        """
        if not brain or not teacher:
            return False

        # Normalize
        brain_norm = brain.lower().strip()
        teacher_norm = teacher.lower().strip()

        # Check for high overlap
        brain_words = set(brain_norm.split())
        teacher_words = set(teacher_norm.split())

        if not brain_words or not teacher_words:
            return False

        overlap = len(brain_words & teacher_words)
        max_len = max(len(brain_words), len(teacher_words))

        # Consider correct if >50% word overlap
        return overlap / max_len > 0.5


# Global singleton
_gating: Optional[TeacherGating] = None


def get_teacher_gating() -> TeacherGating:
    """Get the global teacher gating instance."""
    global _gating
    if _gating is None:
        _gating = TeacherGating()
    return _gating


def process_with_learning_contract(
    query: str,
    context: Optional[Dict[str, Any]] = None,
) -> TeacherResult:
    """
    Process a query through the full learning contract.

    Convenience function for the main entry point.
    """
    return get_teacher_gating().process_query(query, context)


def set_teacher_free_mode(enabled: bool) -> None:
    """Enable/disable teacher-free mode."""
    get_teacher_gating().set_teacher_free_mode(enabled)


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for teacher gating.

    Operations:
    - PROCESS: Process a query through the learning contract
    - GET_DECISION: Get gating decision without processing
    - SET_MODE: Set teacher-free mode
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    gating = get_teacher_gating()

    if op == "PROCESS":
        query = payload.get("query", "")
        context = payload.get("context")
        result = gating.process_query(query, context)
        return {
            "ok": True,
            "payload": {
                "answer": result.answer,
                "source": result.source,
                "skill_level": result.skill_level.value,
                "episode_id": result.episode_id,
                "confidence": result.confidence,
                "learning_occurred": result.learning_occurred,
            }
        }

    elif op == "GET_DECISION":
        query = payload.get("query", "")
        task_type_str = payload.get("task_type")
        task_type = None
        if task_type_str:
            try:
                task_type = TaskType(task_type_str)
            except ValueError:
                pass
        brain_confidence = payload.get("brain_confidence", 0.5)
        decision = gating.get_gating_decision(query, task_type, brain_confidence)
        return {
            "ok": True,
            "payload": {
                "mode": decision.mode.value,
                "skill_level": decision.skill_level.value,
                "reason": decision.reason,
                "can_proceed_without_llm": decision.can_proceed_without_llm,
            }
        }

    elif op == "SET_MODE":
        teacher_free = payload.get("teacher_free", False)
        gating.set_teacher_free_mode(teacher_free)
        return {
            "ok": True,
            "payload": {"teacher_free_mode": teacher_free}
        }

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
