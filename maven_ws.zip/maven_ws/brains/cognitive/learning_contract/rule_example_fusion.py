"""
Rule + Example Fusion Engine
=============================

Synthesizes answers using:
1. Abstract rule for the task type
2. Similar examples from the example bank
3. Structural alignment with successful patterns

This happens INSIDE the brains (not via LLM).
The LLM is only used as fallback teacher or validator.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple
from pathlib import Path
import json
import re

try:
    from brains.memory.brain_memory import BrainMemory
except ImportError:
    BrainMemory = None

from brains.cognitive.learning_contract.task_types import (
    TaskType,
    get_task_type_rule,
    get_task_type_constraints,
)
from brains.cognitive.learning_contract.episode_storage import (
    get_episode_store,
    LearningEpisode,
    IdealBlueprint,
)


@dataclass
class Example:
    """A canonical example for a task type."""
    input_query: str
    ideal_output: str
    reasoning_pattern: str = ""
    constraints: List[str] = field(default_factory=list)
    anti_patterns: List[str] = field(default_factory=list)  # What NOT to do
    task_type: TaskType = TaskType.UNKNOWN
    success: bool = True
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class FusionResult:
    """Result of rule+example fusion."""
    synthesized_answer: str
    confidence: float
    rule_applied: str
    examples_used: List[str]  # Input queries of examples used
    constraints_applied: List[str]
    reasoning_trace: List[str]
    needs_llm: bool = False  # Whether LLM fallback is recommended


class ExampleBank:
    """
    Bank of canonical examples per task type.

    Stores both successful examples and anti-examples (corrected failures).
    """

    def __init__(self):
        self._memory: Optional[BrainMemory] = None
        self._examples: Dict[TaskType, List[Example]] = {t: [] for t in TaskType}
        self._init_memory()
        self._load_examples()

    def _init_memory(self) -> None:
        """Initialize memory storage."""
        if BrainMemory:
            try:
                self._memory = BrainMemory("example_bank")
            except Exception as e:
                print(f"[EXAMPLE_BANK] Memory init failed: {e}")

    def _load_examples(self) -> None:
        """Load examples from memory."""
        if not self._memory:
            return

        try:
            records = self._memory.retrieve(query="canonical_example", limit=500)
            for record in records:
                content = record.get("content", "")
                if isinstance(content, str):
                    try:
                        data = json.loads(content)
                        task_type = TaskType(data.get("task_type", "unknown"))
                        example = Example(
                            input_query=data.get("input_query", ""),
                            ideal_output=data.get("ideal_output", ""),
                            reasoning_pattern=data.get("reasoning_pattern", ""),
                            constraints=data.get("constraints", []),
                            anti_patterns=data.get("anti_patterns", []),
                            task_type=task_type,
                            success=data.get("success", True),
                            metadata=data.get("metadata", {}),
                        )
                        self._examples[task_type].append(example)
                    except (json.JSONDecodeError, ValueError):
                        pass
        except Exception as e:
            print(f"[EXAMPLE_BANK] Load failed: {e}")

    def add_example(self, example: Example) -> None:
        """Add an example to the bank."""
        self._examples[example.task_type].append(example)

        # Persist to memory
        if self._memory:
            try:
                self._memory.store(
                    content=json.dumps({
                        "input_query": example.input_query,
                        "ideal_output": example.ideal_output,
                        "reasoning_pattern": example.reasoning_pattern,
                        "constraints": example.constraints,
                        "anti_patterns": example.anti_patterns,
                        "task_type": example.task_type.value,
                        "success": example.success,
                        "metadata": example.metadata,
                    }),
                    metadata={
                        "kind": "canonical_example",
                        "task_type": example.task_type.value,
                        "success": example.success,
                    }
                )
            except Exception as e:
                print(f"[EXAMPLE_BANK] Store failed: {e}")

    def add_from_episode(self, episode: LearningEpisode) -> None:
        """Create an example from a learning episode."""
        if episode.llm_response:
            ideal_output = episode.llm_response.final_answer
        else:
            ideal_output = episode.brain_attempt.draft_output

        # Get reasoning pattern from blueprint if available
        reasoning_pattern = ""
        if episode.ideal_blueprint:
            reasoning_pattern = episode.ideal_blueprint.reasoning_pattern

        # Get anti-patterns from failure trace
        anti_patterns = []
        if episode.failure_trace:
            anti_patterns = episode.failure_trace.what_to_avoid

        example = Example(
            input_query=episode.input_query,
            ideal_output=ideal_output,
            reasoning_pattern=reasoning_pattern,
            constraints=episode.brain_attempt.constraints_applied,
            anti_patterns=anti_patterns,
            task_type=episode.task_type,
            success=episode.success,
            metadata={
                "episode_id": episode.episode_id,
                "episode_type": episode.episode_type.value,
            }
        )

        self.add_example(example)

    def get_examples(
        self,
        task_type: TaskType,
        limit: int = 5,
        include_failures: bool = True,
    ) -> List[Example]:
        """
        Get examples for a task type.

        Args:
            task_type: The task type
            limit: Maximum number of examples
            include_failures: Include corrected failures as anti-examples

        Returns:
            List of examples
        """
        examples = self._examples.get(task_type, [])

        if not include_failures:
            examples = [e for e in examples if e.success]

        # Sort by recency (if metadata has timestamp)
        examples = sorted(
            examples,
            key=lambda e: e.metadata.get("timestamp", 0),
            reverse=True
        )

        return examples[:limit]

    def find_similar(
        self,
        query: str,
        task_type: TaskType,
        limit: int = 3,
    ) -> List[Example]:
        """
        Find examples similar to a query.

        Uses simple keyword matching. Semantic search could be added.

        Args:
            query: The query to find similar examples for
            task_type: The task type to search within
            limit: Maximum number of examples

        Returns:
            List of similar examples
        """
        examples = self._examples.get(task_type, [])
        if not examples:
            return []

        query_words = set(query.lower().split())

        # Score examples by keyword overlap
        scored = []
        for example in examples:
            example_words = set(example.input_query.lower().split())
            overlap = len(query_words & example_words)
            if overlap > 0:
                scored.append((overlap, example))

        # Sort by overlap score
        scored.sort(key=lambda x: x[0], reverse=True)

        return [e for _, e in scored[:limit]]


class RuleExampleFusion:
    """
    Synthesizes answers using rule + example fusion.

    This is the core mechanism for brain-first answering.
    """

    def __init__(self):
        self._example_bank = ExampleBank()
        self._episode_store = get_episode_store()

    def synthesize(
        self,
        query: str,
        task_type: TaskType,
        context: Optional[Dict[str, Any]] = None,
    ) -> FusionResult:
        """
        Synthesize an answer using rule + example fusion.

        Args:
            query: The user's query
            task_type: The classified task type
            context: Optional context

        Returns:
            FusionResult with synthesized answer
        """
        reasoning_trace = []
        confidence = 0.5  # Start with moderate confidence

        # Step 1: Get the abstract rule
        rule = get_task_type_rule(task_type)
        reasoning_trace.append(f"Applied rule: {rule[:100]}...")

        # Step 2: Get constraints
        constraints = get_task_type_constraints(task_type)
        constraints_applied = list(constraints.keys())
        reasoning_trace.append(f"Constraints: {constraints_applied}")

        # Step 3: Find similar examples
        similar_examples = self._example_bank.find_similar(query, task_type, limit=3)

        # Also get recent successful episodes if not enough examples
        if len(similar_examples) < 2:
            episodes = self._episode_store.query_similar(query, task_type, limit=3)
            for ep in episodes:
                if ep.success and ep.llm_response:
                    similar_examples.append(Example(
                        input_query=ep.input_query,
                        ideal_output=ep.llm_response.final_answer,
                        task_type=ep.task_type,
                        success=True,
                    ))

        examples_used = [e.input_query for e in similar_examples]
        reasoning_trace.append(f"Found {len(similar_examples)} similar examples")

        # Step 4: Synthesize answer
        if similar_examples:
            # Use examples to guide synthesis
            answer, synth_confidence = self._synthesize_from_examples(
                query, task_type, rule, constraints, similar_examples
            )
            confidence = synth_confidence
            reasoning_trace.append("Synthesized from examples")
        else:
            # Pure rule-based synthesis
            answer, synth_confidence = self._synthesize_from_rule(
                query, task_type, rule, constraints
            )
            confidence = synth_confidence * 0.7  # Lower confidence without examples
            reasoning_trace.append("Synthesized from rule only (no examples)")

        # Step 5: Determine if LLM is needed
        needs_llm = confidence < 0.6 or len(similar_examples) == 0

        return FusionResult(
            synthesized_answer=answer,
            confidence=confidence,
            rule_applied=rule,
            examples_used=examples_used,
            constraints_applied=constraints_applied,
            reasoning_trace=reasoning_trace,
            needs_llm=needs_llm,
        )

    def _synthesize_from_examples(
        self,
        query: str,
        task_type: TaskType,
        rule: str,
        constraints: Dict[str, Any],
        examples: List[Example],
    ) -> Tuple[str, float]:
        """
        Synthesize answer guided by examples.

        This is a simplified implementation. A full implementation would:
        - Extract structural patterns from examples
        - Map query elements to example patterns
        - Generate answer following the pattern

        For now, we use examples to validate and adjust structure.
        """
        # Extract common patterns from examples
        patterns = self._extract_patterns(examples)

        # Build answer based on task type
        if task_type == TaskType.QA:
            answer = self._build_qa_answer(query, patterns, constraints)
        elif task_type == TaskType.EXPLANATION:
            answer = self._build_explanation_answer(query, patterns, constraints)
        elif task_type == TaskType.SUMMARIZATION:
            answer = self._build_summary_answer(query, patterns, constraints)
        else:
            answer = self._build_generic_answer(query, task_type, patterns, constraints)

        # Calculate confidence based on pattern strength
        confidence = min(0.9, 0.5 + len(examples) * 0.1)

        return answer, confidence

    def _synthesize_from_rule(
        self,
        query: str,
        task_type: TaskType,
        rule: str,
        constraints: Dict[str, Any],
    ) -> Tuple[str, float]:
        """
        Synthesize answer from rule alone (no examples).

        Lower confidence since no examples to validate against.
        """
        # Generic rule-based synthesis
        answer = self._build_generic_answer(query, task_type, [], constraints)
        confidence = 0.4  # Low confidence without examples

        return answer, confidence

    def _extract_patterns(self, examples: List[Example]) -> Dict[str, Any]:
        """Extract structural patterns from examples."""
        patterns = {
            "avg_length": 0,
            "has_bullet_points": False,
            "has_numbered_list": False,
            "common_phrases": [],
            "structure": [],
        }

        if not examples:
            return patterns

        lengths = []
        for example in examples:
            output = example.ideal_output
            lengths.append(len(output))

            if "- " in output or "• " in output:
                patterns["has_bullet_points"] = True
            if re.search(r"^\d+\.", output, re.MULTILINE):
                patterns["has_numbered_list"] = True

        patterns["avg_length"] = sum(lengths) // len(lengths) if lengths else 200

        return patterns

    def _build_qa_answer(
        self,
        query: str,
        patterns: Dict[str, Any],
        constraints: Dict[str, Any],
    ) -> str:
        """Build a Q&A style answer."""
        # For now, return a placeholder that indicates need for actual content
        return f"[Brain synthesis required for: {query[:50]}...]"

    def _build_explanation_answer(
        self,
        query: str,
        patterns: Dict[str, Any],
        constraints: Dict[str, Any],
    ) -> str:
        """Build an explanation answer."""
        return f"[Brain synthesis required for explanation: {query[:50]}...]"

    def _build_summary_answer(
        self,
        query: str,
        patterns: Dict[str, Any],
        constraints: Dict[str, Any],
    ) -> str:
        """Build a summary answer."""
        return f"[Brain synthesis required for summary: {query[:50]}...]"

    def _build_generic_answer(
        self,
        query: str,
        task_type: TaskType,
        patterns: List[Any],
        constraints: Dict[str, Any],
    ) -> str:
        """Build a generic answer for any task type."""
        return f"[Brain synthesis required for {task_type.value}: {query[:50]}...]"

    def learn_from_correction(
        self,
        original_attempt: str,
        corrected_answer: str,
        query: str,
        task_type: TaskType,
    ) -> None:
        """
        Learn from a correction (when LLM provided better answer).

        Adds the corrected version as an example for future reference.
        """
        # Create anti-pattern from original
        anti_patterns = [f"Avoid: {original_attempt[:100]}..."]

        example = Example(
            input_query=query,
            ideal_output=corrected_answer,
            anti_patterns=anti_patterns,
            task_type=task_type,
            success=True,
            metadata={"learned_from": "correction"},
        )

        self._example_bank.add_example(example)


# Global singleton
_fusion_engine: Optional[RuleExampleFusion] = None


def get_fusion_engine() -> RuleExampleFusion:
    """Get the global fusion engine instance."""
    global _fusion_engine
    if _fusion_engine is None:
        _fusion_engine = RuleExampleFusion()
    return _fusion_engine


def synthesize_answer(
    query: str,
    task_type: TaskType,
    context: Optional[Dict[str, Any]] = None,
) -> FusionResult:
    """
    Convenience function to synthesize an answer.

    Args:
        query: The user's query
        task_type: The classified task type
        context: Optional context

    Returns:
        FusionResult
    """
    return get_fusion_engine().synthesize(query, task_type, context)


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for rule+example fusion.

    Operations:
    - SYNTHESIZE: Synthesize an answer from rule + examples
    - ADD_EXAMPLE: Add a canonical example
    - LEARN_FROM_CORRECTION: Learn from a corrected answer
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    engine = get_fusion_engine()

    if op == "SYNTHESIZE":
        query = payload.get("query", "")
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        context = payload.get("context")

        result = engine.synthesize(query, task_type, context)

        return {
            "ok": True,
            "payload": {
                "answer": result.synthesized_answer,
                "confidence": result.confidence,
                "rule_applied": result.rule_applied,
                "examples_used": result.examples_used,
                "constraints_applied": result.constraints_applied,
                "reasoning_trace": result.reasoning_trace,
                "needs_llm": result.needs_llm,
            }
        }

    elif op == "ADD_EXAMPLE":
        example_data = payload.get("example", {})
        task_type_str = example_data.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN

        example = Example(
            input_query=example_data.get("input_query", ""),
            ideal_output=example_data.get("ideal_output", ""),
            reasoning_pattern=example_data.get("reasoning_pattern", ""),
            constraints=example_data.get("constraints", []),
            anti_patterns=example_data.get("anti_patterns", []),
            task_type=task_type,
            success=example_data.get("success", True),
        )

        engine._example_bank.add_example(example)
        return {"ok": True, "payload": {"added": True}}

    elif op == "LEARN_FROM_CORRECTION":
        original = payload.get("original_attempt", "")
        corrected = payload.get("corrected_answer", "")
        query = payload.get("query", "")
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN

        engine.learn_from_correction(original, corrected, query, task_type)
        return {"ok": True, "payload": {"learned": True}}

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
