"""
Answer Fusion Module
=====================

Fuses teacher (LLM) output with brain's draft to produce a
brain-authored answer that incorporates LLM teachings.

The brain must NEVER output the raw LLM answer. Instead:
1. Extract key elements from teacher's answer (facts, structure, tone)
2. Integrate them into brain's draft
3. Return fused answer that brain "authored"

This ensures the learning contract: brain learns from teacher
but maintains authorship of all outputs.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Tuple
import re

from brains.cognitive.learning_contract.task_types import TaskType


@dataclass
class FusedAnswer:
    """Result of answer fusion."""
    fused_output: str
    fusion_type: str  # "blend", "structure_adopt", "fact_inject", "tone_adjust"
    brain_contribution: float  # 0.0 to 1.0 - how much of original brain answer
    teacher_elements: List[str]  # What was borrowed from teacher
    changes_made: List[str]  # Description of changes


@dataclass
class ExtractedElements:
    """Elements extracted from teacher's answer."""
    facts: List[str] = field(default_factory=list)
    key_terms: List[str] = field(default_factory=list)
    structure: str = ""  # e.g., "numbered_list", "prose", "bullet_points"
    tone: str = ""  # e.g., "formal", "casual", "educational"
    rhetorical_pattern: str = ""  # e.g., "definition_then_example"
    opening_style: str = ""
    closing_style: str = ""


class AnswerFusion:
    """
    Fuses teacher output with brain draft.

    The brain must never output raw LLM. This class ensures
    the brain incorporates LLM teachings into its own answer.
    """

    def __init__(self):
        pass

    def fuse(
        self,
        brain_draft: str,
        teacher_answer: str,
        task_type: TaskType,
        brain_confidence: float = 0.5,
    ) -> FusedAnswer:
        """
        Fuse teacher's answer into brain's draft.

        Args:
            brain_draft: The brain's original attempt
            teacher_answer: The teacher's (LLM) answer
            task_type: The task type for context
            brain_confidence: Brain's confidence in its draft

        Returns:
            FusedAnswer with the fused output
        """
        # Extract elements from teacher
        teacher_elements = self._extract_elements(teacher_answer)
        brain_elements = self._extract_elements(brain_draft)

        changes_made = []
        teacher_borrowed = []

        # Determine fusion strategy based on confidence and task type
        if brain_confidence < 0.3:
            # Low confidence: heavily adopt teacher's structure
            fused, changes = self._structure_adopt(
                brain_draft, teacher_answer, teacher_elements, task_type
            )
            fusion_type = "structure_adopt"
            brain_contribution = 0.3
        elif brain_confidence < 0.6:
            # Medium confidence: blend answers
            fused, changes = self._blend(
                brain_draft, teacher_answer, brain_elements, teacher_elements, task_type
            )
            fusion_type = "blend"
            brain_contribution = 0.5
        else:
            # Higher confidence: inject specific facts/terms
            fused, changes = self._fact_inject(
                brain_draft, teacher_answer, teacher_elements, task_type
            )
            fusion_type = "fact_inject"
            brain_contribution = 0.8

        changes_made.extend(changes)

        # Always adjust tone if significantly different
        final_output, tone_changes = self._adjust_tone(
            fused, teacher_elements.tone, task_type
        )
        if tone_changes:
            changes_made.extend(tone_changes)

        # Track what was borrowed from teacher
        if teacher_elements.facts:
            teacher_borrowed.extend([f"Fact: {f[:50]}..." for f in teacher_elements.facts[:3]])
        if teacher_elements.structure and fusion_type == "structure_adopt":
            teacher_borrowed.append(f"Structure: {teacher_elements.structure}")
        if teacher_elements.tone:
            teacher_borrowed.append(f"Tone: {teacher_elements.tone}")

        return FusedAnswer(
            fused_output=final_output,
            fusion_type=fusion_type,
            brain_contribution=brain_contribution,
            teacher_elements=teacher_borrowed,
            changes_made=changes_made,
        )

    def _extract_elements(self, text: str) -> ExtractedElements:
        """Extract structural and content elements from text."""
        elements = ExtractedElements()

        if not text:
            return elements

        # Detect structure
        if re.search(r"^\d+\.", text, re.MULTILINE):
            elements.structure = "numbered_list"
        elif re.search(r"^[-•]", text, re.MULTILINE):
            elements.structure = "bullet_points"
        else:
            elements.structure = "prose"

        # Detect tone
        text_lower = text.lower()
        if any(w in text_lower for w in ["please note", "it should be noted", "formally"]):
            elements.tone = "formal"
        elif any(w in text_lower for w in ["hey", "cool", "awesome", "!"]):
            elements.tone = "casual"
        elif any(w in text_lower for w in ["think of", "imagine", "for example"]):
            elements.tone = "educational"
        else:
            elements.tone = "neutral"

        # Detect rhetorical pattern
        if text_lower.startswith(("the", "a ", "an ")):
            if "is" in text_lower[:50]:
                elements.rhetorical_pattern = "definition_first"
        if "for example" in text_lower or "such as" in text_lower:
            elements.rhetorical_pattern = "includes_examples"

        # Extract facts (sentences with factual markers)
        sentences = [s.strip() for s in text.split(".") if s.strip()]
        for sentence in sentences:
            s_lower = sentence.lower()
            if any(m in s_lower for m in ["is", "are", "was", "were", "means", "refers to"]):
                # Likely a factual statement
                elements.facts.append(sentence)

        # Extract key terms (capitalized multi-word phrases or technical terms)
        key_terms = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)+\b', text)
        elements.key_terms = key_terms[:5]

        # Opening and closing styles
        if sentences:
            elements.opening_style = self._get_sentence_style(sentences[0])
            elements.closing_style = self._get_sentence_style(sentences[-1])

        return elements

    def _get_sentence_style(self, sentence: str) -> str:
        """Categorize sentence style."""
        s_lower = sentence.lower().strip()
        if s_lower.startswith(("in summary", "in conclusion", "therefore")):
            return "conclusive"
        if s_lower.startswith(("the", "a ", "an ")):
            return "declarative"
        if "?" in sentence:
            return "questioning"
        if any(w in s_lower for w in ["should", "must", "important"]):
            return "prescriptive"
        return "neutral"

    def _structure_adopt(
        self,
        brain_draft: str,
        teacher_answer: str,
        teacher_elements: ExtractedElements,
        task_type: TaskType,
    ) -> Tuple[str, List[str]]:
        """
        Adopt teacher's structure while keeping some brain content.

        Used when brain confidence is very low.
        """
        changes = []

        # Start with teacher's structure but inject brain's key points
        brain_sentences = [s.strip() for s in brain_draft.split(".") if s.strip()]
        teacher_sentences = [s.strip() for s in teacher_answer.split(".") if s.strip()]

        if not teacher_sentences:
            return brain_draft, ["No teacher structure to adopt"]

        # Find unique brain contributions
        brain_unique = []
        for bs in brain_sentences:
            bs_words = set(bs.lower().split())
            has_overlap = False
            for ts in teacher_sentences:
                ts_words = set(ts.lower().split())
                overlap = len(bs_words & ts_words) / max(len(bs_words), 1)
                if overlap > 0.5:
                    has_overlap = True
                    break
            if not has_overlap and len(bs.split()) > 5:
                brain_unique.append(bs)

        # Build fused output
        if teacher_elements.structure == "numbered_list":
            fused_lines = []
            count = 1
            for ts in teacher_sentences[:5]:
                fused_lines.append(f"{count}. {ts}.")
                count += 1
            # Add brain's unique contribution as additional point
            if brain_unique:
                fused_lines.append(f"{count}. {brain_unique[0]}.")
                changes.append(f"Added brain point as item {count}")
            fused = "\n".join(fused_lines)
            changes.append("Adopted numbered list structure from teacher")
        elif teacher_elements.structure == "bullet_points":
            fused_lines = []
            for ts in teacher_sentences[:5]:
                fused_lines.append(f"- {ts}")
            if brain_unique:
                fused_lines.append(f"- {brain_unique[0]}")
                changes.append("Added brain point as bullet")
            fused = "\n".join(fused_lines)
            changes.append("Adopted bullet point structure from teacher")
        else:
            # Prose - interleave
            fused_sentences = teacher_sentences[:3]
            if brain_unique:
                fused_sentences.insert(1, brain_unique[0])
                changes.append("Interleaved brain insight into teacher prose")
            fused = ". ".join(fused_sentences) + "."
            changes.append("Adopted prose structure from teacher")

        return fused, changes

    def _blend(
        self,
        brain_draft: str,
        teacher_answer: str,
        brain_elements: ExtractedElements,
        teacher_elements: ExtractedElements,
        task_type: TaskType,
    ) -> Tuple[str, List[str]]:
        """
        Blend brain and teacher answers together.

        Used when brain has moderate confidence.
        """
        changes = []

        brain_sentences = [s.strip() for s in brain_draft.split(".") if s.strip()]
        teacher_sentences = [s.strip() for s in teacher_answer.split(".") if s.strip()]

        if not brain_sentences:
            return teacher_answer, ["Brain draft empty, using teacher"]
        if not teacher_sentences:
            return brain_draft, ["Teacher answer empty, using brain"]

        blended = []

        # Use teacher's opening if more effective
        if teacher_elements.opening_style in ("declarative", "conclusive"):
            blended.append(teacher_sentences[0])
            changes.append("Used teacher's stronger opening")
        else:
            blended.append(brain_sentences[0])

        # Interleave middle content
        brain_mid = brain_sentences[1:-1] if len(brain_sentences) > 2 else []
        teacher_mid = teacher_sentences[1:-1] if len(teacher_sentences) > 2 else []

        for i in range(max(len(brain_mid), len(teacher_mid))):
            if i < len(brain_mid):
                blended.append(brain_mid[i])
            if i < len(teacher_mid):
                # Only add teacher if not redundant
                t_words = set(teacher_mid[i].lower().split())
                is_redundant = False
                for existing in blended:
                    e_words = set(existing.lower().split())
                    if len(t_words & e_words) / max(len(t_words), 1) > 0.7:
                        is_redundant = True
                        break
                if not is_redundant:
                    blended.append(teacher_mid[i])
                    changes.append("Added non-redundant teacher content")

        # Use teacher's closing if conclusive
        if teacher_sentences and teacher_elements.closing_style == "conclusive":
            blended.append(teacher_sentences[-1])
            changes.append("Used teacher's conclusive ending")
        elif brain_sentences:
            blended.append(brain_sentences[-1])

        fused = ". ".join(blended) + "."
        return fused, changes

    def _fact_inject(
        self,
        brain_draft: str,
        teacher_answer: str,
        teacher_elements: ExtractedElements,
        task_type: TaskType,
    ) -> Tuple[str, List[str]]:
        """
        Inject specific facts from teacher into brain's answer.

        Used when brain has higher confidence.
        """
        changes = []
        fused = brain_draft

        # Inject key terms the brain missed
        for term in teacher_elements.key_terms:
            if term.lower() not in fused.lower():
                # Find a good insertion point
                sentences = fused.split(".")
                if len(sentences) > 1:
                    # Insert mention near the start
                    sentences[0] = f"{sentences[0]} (including {term})"
                    fused = ".".join(sentences)
                    changes.append(f"Injected key term: {term}")
                    break

        # Inject any critical facts the brain missed
        brain_words = set(fused.lower().split())
        for fact in teacher_elements.facts[:2]:
            fact_words = set(fact.lower().split())
            # If this fact has unique content
            unique_words = fact_words - brain_words
            if len(unique_words) > 5:
                # Add this fact
                if not fused.endswith("."):
                    fused += "."
                fused += f" Additionally, {fact.lower()}."
                changes.append(f"Injected fact: {fact[:40]}...")
                break

        return fused, changes

    def _adjust_tone(
        self,
        text: str,
        target_tone: str,
        task_type: TaskType,
    ) -> Tuple[str, List[str]]:
        """Adjust text tone to match target."""
        changes = []

        if not target_tone or target_tone == "neutral":
            return text, changes

        # Detect current tone
        current_elements = self._extract_elements(text)
        current_tone = current_elements.tone

        if current_tone == target_tone:
            return text, changes

        # Adjust formal -> educational
        if target_tone == "educational" and current_tone == "formal":
            # Add explanatory phrases
            text = text.replace("is defined as", "can be thought of as")
            text = text.replace("It should be noted that", "An important thing to know is that")
            if "for example" not in text.lower():
                sentences = text.split(".")
                if len(sentences) > 2:
                    sentences[1] = f"{sentences[1]}. For instance,"
                    text = ".".join(sentences)
            changes.append("Adjusted tone: formal -> educational")

        # Adjust casual -> formal for EXPLANATION tasks
        if target_tone == "formal" and current_tone == "casual":
            if task_type == TaskType.EXPLANATION:
                text = text.replace("cool", "interesting")
                text = text.replace("awesome", "notable")
                text = text.replace("!", ".")
                changes.append("Adjusted tone: casual -> formal")

        return text, changes


# Global singleton
_fusion: Optional[AnswerFusion] = None


def get_answer_fusion() -> AnswerFusion:
    """Get the global answer fusion instance."""
    global _fusion
    if _fusion is None:
        _fusion = AnswerFusion()
    return _fusion


def fuse_answers(
    brain_draft: str,
    teacher_answer: str,
    task_type: TaskType,
    brain_confidence: float = 0.5,
) -> FusedAnswer:
    """
    Convenience function to fuse answers.

    Args:
        brain_draft: The brain's original attempt
        teacher_answer: The teacher's (LLM) answer
        task_type: The task type
        brain_confidence: Brain's confidence in its draft

    Returns:
        FusedAnswer with the fused output
    """
    return get_answer_fusion().fuse(
        brain_draft, teacher_answer, task_type, brain_confidence
    )


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for answer fusion.

    Operations:
    - FUSE: Fuse brain draft with teacher answer
    - EXTRACT: Extract elements from text
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    fusion = get_answer_fusion()

    if op == "FUSE":
        brain_draft = payload.get("brain_draft", "")
        teacher_answer = payload.get("teacher_answer", "")
        task_type_str = payload.get("task_type", "unknown")
        brain_confidence = payload.get("brain_confidence", 0.5)

        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN

        result = fusion.fuse(brain_draft, teacher_answer, task_type, brain_confidence)

        return {
            "ok": True,
            "payload": {
                "fused_output": result.fused_output,
                "fusion_type": result.fusion_type,
                "brain_contribution": result.brain_contribution,
                "teacher_elements": result.teacher_elements,
                "changes_made": result.changes_made,
            }
        }

    elif op == "EXTRACT":
        text = payload.get("text", "")
        elements = fusion._extract_elements(text)

        return {
            "ok": True,
            "payload": {
                "facts": elements.facts,
                "key_terms": elements.key_terms,
                "structure": elements.structure,
                "tone": elements.tone,
                "rhetorical_pattern": elements.rhetorical_pattern,
            }
        }

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
