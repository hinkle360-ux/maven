"""
Learning Episode Storage
=========================

Stores full learning episodes whenever the LLM is touched.
Each episode contains:
- Task metadata (type, input query, context)
- Brain attempt (draft, reasoning trace, constraints)
- LLM response (if used)
- Evaluation (what was wrong, what was better)
- Derived artifacts (ideal blueprint, failure trace)

Episodes enable:
- Rule updates for task types
- Example bank expansion
- Skill level adjustments

Extended with Learning Loop Architecture (Phase 2):
- ConversationTurn: Every user message with full metadata
- StylePattern: How good answers look (learned from Teacher)
- MetaSignal: Performance signals for Maven improvement
"""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Dict, Any, Optional, List
from pathlib import Path
import json
import time
import hashlib

try:
    from brains.memory.brain_memory import BrainMemory
except ImportError:
    BrainMemory = None

from brains.cognitive.learning_contract.task_types import TaskType


class EpisodeType(Enum):
    """Type of learning episode."""
    TEACHER_FALLBACK = "teacher_fallback"  # LLM used as teacher (skill low)
    VALIDATION = "validation"              # LLM used as validator (skill high)
    SELF_CORRECTION = "self_correction"    # Brain self-corrected
    FAILURE = "failure"                    # Brain failed, needs learning


class FailureCategory(Enum):
    """Category of failure for learning."""
    FACT_ERROR = "fact_error"              # Incorrect facts
    STRUCTURE = "structure"                # Wrong structure/format
    CONSTRAINT = "constraint"              # Violated constraints
    COHERENCE = "coherence"                # Incoherent or contradictory
    INCOMPLETE = "incomplete"              # Missing required content
    EXCESSIVE = "excessive"                # Too much unnecessary content
    TONE = "tone"                          # Wrong tone/style
    UNKNOWN = "unknown"


# =============================================================================
# LEARNING LOOP ARCHITECTURE - NEW DATA MODELS
# =============================================================================

class RouteUsed(Enum):
    """How the query was routed."""
    TEACHER_FAST_PATH = "teacher_fast_path"  # Teacher answered directly
    MAVEN_DIRECT = "maven_direct"            # Maven answered without Teacher
    ACTION = "action"                        # Tool/action execution
    SELF_QUERY = "self_query"               # Internal self-knowledge query


class FollowupType(Enum):
    """Type of user followup signal."""
    TELL_ME_MORE = "tell_me_more"
    THATS_WRONG = "thats_wrong"
    POSITIVE = "positive"
    NONE = "none"


class SignalType(Enum):
    """Type of meta signal for learning."""
    TEACHER_QUALITY_FAIL = "teacher_quality_fail"
    USER_COMPLAINT = "user_complaint"
    SHADOW_BETTER_THAN_TEACHER = "shadow_better_than_teacher"
    SHADOW_WORSE_THAN_TEACHER = "shadow_worse_than_teacher"
    SHADOW_COMPARABLE = "shadow_comparable"
    IDENTITY_VIOLATION = "identity_violation"


class DomainGuess(Enum):
    """Domain classification for queries."""
    MAVEN_SELF = "maven_self"           # About Maven itself
    PROJECT_MAVEN = "project_maven"     # About Maven's codebase
    PYTHON_HELP = "python_help"         # Python programming help
    GENERAL_KNOWLEDGE = "general_knowledge"
    PERSONAL = "personal"               # User's personal info
    PLANNING = "planning"               # Planning/scheduling
    CODE_HELP = "code_help"            # General code help
    UNKNOWN = "unknown"


@dataclass
class QualityCheck:
    """Quality check result for a response."""
    approved: bool = False
    issues: List[str] = field(default_factory=list)
    severity: str = ""  # CRITICAL, HIGH, MEDIUM, LOW
    fix_applied: str = ""
    quality_score: float = 0.0


@dataclass
class UserFeedbackSignals:
    """User feedback signals for a turn."""
    followup_type: FollowupType = FollowupType.NONE
    explicit_feedback: str = ""
    implicit_signals: List[str] = field(default_factory=list)


@dataclass
class ConversationTurn:
    """
    Every user message with full metadata.

    This is the "anchor" record for the learning loop.
    Stores both teacher and maven answers for comparison.
    """
    # Identity
    id: str = ""
    timestamp: float = 0.0
    session_id: str = ""

    # Query
    user_query: str = ""

    # Routing
    route_used: RouteUsed = RouteUsed.TEACHER_FAST_PATH

    # Answers
    teacher_answer: str = ""
    maven_shadow_answer: str = ""  # Generated in background for learning

    # Tool usage
    tools_used: List[str] = field(default_factory=list)

    # Quality
    quality_check: QualityCheck = field(default_factory=QualityCheck)

    # User feedback
    user_feedback_signals: UserFeedbackSignals = field(default_factory=UserFeedbackSignals)

    # Classification
    domain_guess: DomainGuess = DomainGuess.UNKNOWN
    tags: List[str] = field(default_factory=list)

    # Confidence scores
    teacher_confidence: float = 0.0
    maven_confidence: float = 0.0

    # Comparison results (filled after shadow comparison)
    shadow_score: float = 0.0  # 0-1 similarity score
    comparison_notes: str = ""

    def __post_init__(self):
        if not self.id:
            self.id = self._generate_id()
        if not self.timestamp:
            self.timestamp = time.time()

    def _generate_id(self) -> str:
        content = f"{self.user_query}:{self.timestamp}:{time.time_ns()}"
        return f"turn_{hashlib.sha256(content.encode()).hexdigest()[:12]}"

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["route_used"] = self.route_used.value
        data["domain_guess"] = self.domain_guess.value
        data["user_feedback_signals"]["followup_type"] = self.user_feedback_signals.followup_type.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ConversationTurn":
        route = RouteUsed(data.get("route_used", "teacher_fast_path"))
        domain = DomainGuess(data.get("domain_guess", "unknown"))

        qc_data = data.get("quality_check", {})
        quality_check = QualityCheck(**qc_data) if qc_data else QualityCheck()

        ufs_data = data.get("user_feedback_signals", {})
        followup = FollowupType(ufs_data.get("followup_type", "none"))
        user_feedback = UserFeedbackSignals(
            followup_type=followup,
            explicit_feedback=ufs_data.get("explicit_feedback", ""),
            implicit_signals=ufs_data.get("implicit_signals", []),
        )

        return cls(
            id=data.get("id", ""),
            timestamp=data.get("timestamp", 0.0),
            session_id=data.get("session_id", ""),
            user_query=data.get("user_query", ""),
            route_used=route,
            teacher_answer=data.get("teacher_answer", ""),
            maven_shadow_answer=data.get("maven_shadow_answer", ""),
            tools_used=data.get("tools_used", []),
            quality_check=quality_check,
            user_feedback_signals=user_feedback,
            domain_guess=domain,
            tags=data.get("tags", []),
            teacher_confidence=data.get("teacher_confidence", 0.0),
            maven_confidence=data.get("maven_confidence", 0.0),
            shadow_score=data.get("shadow_score", 0.0),
            comparison_notes=data.get("comparison_notes", ""),
        )


@dataclass
class StylePattern:
    """
    Learned style pattern from good Teacher answers.

    Goal: Learn the shape of good answers so Maven can generate similar.
    """
    # Identity
    id: str = ""
    timestamp: float = 0.0

    # Source
    source_turn_id: str = ""
    example_text: str = ""

    # Answer type
    answer_type: str = ""  # explanation, code_help, step_by_step, small_talk, identity

    # Structure features
    has_code: bool = False
    has_examples: bool = False
    has_headers: bool = False
    has_bullets: bool = False
    avg_sentence_length: float = 0.0
    length_category: str = ""  # short (<100), medium (100-500), long (>500)
    word_count: int = 0

    # Usage context
    domain_guess: DomainGuess = DomainGuess.UNKNOWN
    tags: List[str] = field(default_factory=list)

    # Quality
    quality_score: float = 0.0
    usage_count: int = 0

    def __post_init__(self):
        if not self.id:
            self.id = f"style_{hashlib.sha256(self.example_text[:100].encode()).hexdigest()[:12]}"
        if not self.timestamp:
            self.timestamp = time.time()

    @classmethod
    def extract_from_answer(
        cls,
        answer: str,
        query: str,
        turn_id: str = "",
        domain: DomainGuess = DomainGuess.UNKNOWN,
        tags: List[str] = None,
    ) -> "StylePattern":
        """Extract a style pattern from a good teacher answer."""
        words = answer.split()
        word_count = len(words)

        # Determine length category
        if word_count < 100:
            length_cat = "short"
        elif word_count < 500:
            length_cat = "medium"
        else:
            length_cat = "long"

        # Calculate avg sentence length
        sentences = [s.strip() for s in answer.replace('!', '.').replace('?', '.').split('.') if s.strip()]
        avg_sent_len = sum(len(s.split()) for s in sentences) / max(len(sentences), 1)

        # Detect structure features
        has_code = '```' in answer or 'def ' in answer or 'class ' in answer
        has_examples = 'example' in answer.lower() or 'for instance' in answer.lower()
        has_headers = bool(answer.count('#') > 0 or answer.count('\n##') > 0)
        has_bullets = bool('- ' in answer or '* ' in answer or '\n1.' in answer)

        # Infer answer type
        query_lower = query.lower()
        if has_code or 'code' in query_lower:
            answer_type = "code_help"
        elif '1.' in answer or 'step' in query_lower:
            answer_type = "step_by_step"
        elif word_count < 50:
            answer_type = "small_talk"
        elif 'maven' in query_lower or 'who are you' in query_lower:
            answer_type = "identity"
        else:
            answer_type = "explanation"

        return cls(
            source_turn_id=turn_id,
            example_text=answer,
            answer_type=answer_type,
            has_code=has_code,
            has_examples=has_examples,
            has_headers=has_headers,
            has_bullets=has_bullets,
            avg_sentence_length=avg_sent_len,
            length_category=length_cat,
            word_count=word_count,
            domain_guess=domain,
            tags=tags or [],
        )

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["domain_guess"] = self.domain_guess.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StylePattern":
        domain = DomainGuess(data.get("domain_guess", "unknown"))
        return cls(
            id=data.get("id", ""),
            timestamp=data.get("timestamp", 0.0),
            source_turn_id=data.get("source_turn_id", ""),
            example_text=data.get("example_text", ""),
            answer_type=data.get("answer_type", ""),
            has_code=data.get("has_code", False),
            has_examples=data.get("has_examples", False),
            has_headers=data.get("has_headers", False),
            has_bullets=data.get("has_bullets", False),
            avg_sentence_length=data.get("avg_sentence_length", 0.0),
            length_category=data.get("length_category", ""),
            word_count=data.get("word_count", 0),
            domain_guess=domain,
            tags=data.get("tags", []),
            quality_score=data.get("quality_score", 0.0),
            usage_count=data.get("usage_count", 0),
        )


@dataclass
class MetaSignal:
    """
    Meta signal tracking how well Maven did.

    These signals drive the learning loop and domain takeover decisions.
    """
    # Identity
    id: str = ""
    timestamp: float = 0.0

    # Source
    source_turn_id: str = ""

    # Signal
    signal_type: SignalType = SignalType.SHADOW_COMPARABLE
    details: str = ""
    severity: float = 0.5  # 0-1 scale

    # Context
    domain: DomainGuess = DomainGuess.UNKNOWN
    task_type: str = ""

    # Metrics that triggered signal
    shadow_score: float = 0.0
    quality_score: float = 0.0

    def __post_init__(self):
        if not self.id:
            self.id = f"sig_{hashlib.sha256(f'{self.source_turn_id}:{self.signal_type.value}'.encode()).hexdigest()[:12]}"
        if not self.timestamp:
            self.timestamp = time.time()

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data["signal_type"] = self.signal_type.value
        data["domain"] = self.domain.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MetaSignal":
        signal_type = SignalType(data.get("signal_type", "shadow_comparable"))
        domain = DomainGuess(data.get("domain", "unknown"))
        return cls(
            id=data.get("id", ""),
            timestamp=data.get("timestamp", 0.0),
            source_turn_id=data.get("source_turn_id", ""),
            signal_type=signal_type,
            details=data.get("details", ""),
            severity=data.get("severity", 0.5),
            domain=domain,
            task_type=data.get("task_type", ""),
            shadow_score=data.get("shadow_score", 0.0),
            quality_score=data.get("quality_score", 0.0),
        )


# =============================================================================
# ORIGINAL DATA MODELS (preserved)
# =============================================================================

@dataclass
class BrainAttempt:
    """Record of the brain's attempt before LLM involvement."""
    draft_output: str = ""
    reasoning_trace: List[str] = field(default_factory=list)
    constraints_applied: List[str] = field(default_factory=list)
    confidence: float = 0.0
    self_corrections: List[Dict[str, str]] = field(default_factory=list)  # Pass 1, 2, 3


@dataclass
class LLMResponse:
    """Record of LLM response (teacher or validator)."""
    role: str = ""  # "teacher" or "validator"
    reasoning: str = ""
    final_answer: str = ""
    validation_verdict: Optional[str] = None  # "approved" / "rejected"
    validation_issues: List[str] = field(default_factory=list)


@dataclass
class Evaluation:
    """Evaluation of brain attempt vs ideal."""
    brain_was_correct: bool = False
    failure_category: Optional[FailureCategory] = None
    what_was_wrong: str = ""
    what_was_better: str = ""
    fix_applied: str = ""


@dataclass
class IdealBlueprint:
    """Derived ideal answer blueprint for future reference."""
    facts: List[str] = field(default_factory=list)
    reasoning_pattern: str = ""
    structure: str = ""
    tone: str = ""
    rhetorical_flow: str = ""
    constraints: List[str] = field(default_factory=list)


@dataclass
class FailureTrace:
    """What went wrong and how to avoid it."""
    divergence_point: str = ""
    what_to_avoid: List[str] = field(default_factory=list)
    correction_applied: str = ""


@dataclass
class LearningEpisode:
    """
    Complete learning episode record.

    Stored whenever the LLM is touched (teacher or validator).
    """
    # Identity
    episode_id: str = ""
    timestamp: float = 0.0
    episode_type: EpisodeType = EpisodeType.TEACHER_FALLBACK

    # Task metadata
    task_type: TaskType = TaskType.UNKNOWN
    input_query: str = ""
    context_snapshot: Dict[str, Any] = field(default_factory=dict)

    # Brain attempt
    brain_attempt: BrainAttempt = field(default_factory=BrainAttempt)

    # LLM involvement
    llm_response: Optional[LLMResponse] = None

    # Evaluation
    evaluation: Evaluation = field(default_factory=Evaluation)

    # Derived artifacts
    ideal_blueprint: Optional[IdealBlueprint] = None
    failure_trace: Optional[FailureTrace] = None

    # Skill impact
    skill_before: str = ""
    skill_after: str = ""
    success: bool = False

    def __post_init__(self):
        if not self.episode_id:
            self.episode_id = self._generate_id()
        if not self.timestamp:
            self.timestamp = time.time()

    def _generate_id(self) -> str:
        """Generate unique episode ID."""
        content = f"{self.input_query}:{self.timestamp}:{time.time_ns()}"
        return hashlib.sha256(content.encode()).hexdigest()[:16]

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        data = asdict(self)
        # Convert enums to strings
        data["episode_type"] = self.episode_type.value
        data["task_type"] = self.task_type.value
        if self.evaluation.failure_category:
            data["evaluation"]["failure_category"] = self.evaluation.failure_category.value
        return data

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "LearningEpisode":
        """Deserialize from dictionary."""
        # Convert strings back to enums
        episode_type = EpisodeType(data.get("episode_type", "teacher_fallback"))
        task_type = TaskType(data.get("task_type", "unknown"))

        # Parse nested dataclasses
        brain_attempt_data = data.get("brain_attempt", {})
        brain_attempt = BrainAttempt(**brain_attempt_data)

        llm_response = None
        if data.get("llm_response"):
            llm_response = LLMResponse(**data["llm_response"])

        eval_data = data.get("evaluation", {})
        failure_cat = eval_data.get("failure_category")
        if failure_cat:
            eval_data["failure_category"] = FailureCategory(failure_cat)
        evaluation = Evaluation(**eval_data)

        ideal_blueprint = None
        if data.get("ideal_blueprint"):
            ideal_blueprint = IdealBlueprint(**data["ideal_blueprint"])

        failure_trace = None
        if data.get("failure_trace"):
            failure_trace = FailureTrace(**data["failure_trace"])

        return cls(
            episode_id=data.get("episode_id", ""),
            timestamp=data.get("timestamp", 0.0),
            episode_type=episode_type,
            task_type=task_type,
            input_query=data.get("input_query", ""),
            context_snapshot=data.get("context_snapshot", {}),
            brain_attempt=brain_attempt,
            llm_response=llm_response,
            evaluation=evaluation,
            ideal_blueprint=ideal_blueprint,
            failure_trace=failure_trace,
            skill_before=data.get("skill_before", ""),
            skill_after=data.get("skill_after", ""),
            success=data.get("success", False),
        )


class EpisodeStore:
    """
    Storage and retrieval for learning episodes.

    Uses BrainMemory for persistent storage with semantic indexing.
    """

    def __init__(self):
        self._memory: Optional[BrainMemory] = None
        self._cache: Dict[str, LearningEpisode] = {}  # Recent episodes
        self._init_memory()

    def _init_memory(self) -> None:
        """Initialize memory storage."""
        if BrainMemory:
            try:
                self._memory = BrainMemory("episode_store")
            except Exception as e:
                print(f"[EPISODE_STORE] Memory init failed: {e}")

    def store(self, episode: LearningEpisode) -> str:
        """
        Store a learning episode.

        Args:
            episode: The episode to store

        Returns:
            Episode ID
        """
        # Add to cache
        self._cache[episode.episode_id] = episode

        # Persist to memory
        if self._memory:
            try:
                self._memory.store(
                    content=json.dumps(episode.to_dict()),
                    metadata={
                        "kind": "learning_episode",
                        "episode_type": episode.episode_type.value,
                        "task_type": episode.task_type.value,
                        "success": episode.success,
                        "episode_id": episode.episode_id,
                    }
                )
            except Exception as e:
                print(f"[EPISODE_STORE] Store failed: {e}")

        return episode.episode_id

    def get(self, episode_id: str) -> Optional[LearningEpisode]:
        """Get an episode by ID."""
        # Check cache first
        if episode_id in self._cache:
            return self._cache[episode_id]

        # Query memory
        if self._memory:
            try:
                records = self._memory.retrieve(
                    query=episode_id,
                    limit=1
                )
                for record in records:
                    content = record.get("content", "")
                    if isinstance(content, str):
                        try:
                            data = json.loads(content)
                            episode = LearningEpisode.from_dict(data)
                            self._cache[episode_id] = episode
                            return episode
                        except (json.JSONDecodeError, ValueError):
                            pass
            except Exception as e:
                print(f"[EPISODE_STORE] Query failed: {e}")

        return None

    def query_by_task_type(
        self,
        task_type: TaskType,
        limit: int = 10,
        success_only: bool = False,
    ) -> List[LearningEpisode]:
        """
        Query episodes by task type.

        Args:
            task_type: The task type to query
            limit: Maximum number of episodes to return
            success_only: If True, only return successful episodes

        Returns:
            List of matching episodes
        """
        episodes = []

        if self._memory:
            try:
                search_query = task_type.value
                if success_only:
                    search_query += " success"

                records = self._memory.retrieve(query=search_query, limit=limit)
                for record in records:
                    content = record.get("content", "")
                    if isinstance(content, str):
                        try:
                            data = json.loads(content)
                            episode = LearningEpisode.from_dict(data)
                            episodes.append(episode)
                        except (json.JSONDecodeError, ValueError):
                            pass
            except Exception as e:
                print(f"[EPISODE_STORE] Query failed: {e}")

        return episodes

    def query_similar(
        self,
        query: str,
        task_type: Optional[TaskType] = None,
        limit: int = 5,
    ) -> List[LearningEpisode]:
        """
        Query episodes similar to a query string.

        Uses semantic search if available.

        Args:
            query: The query to find similar episodes for
            task_type: Optional task type filter
            limit: Maximum number of episodes

        Returns:
            List of similar episodes
        """
        episodes = []

        if self._memory:
            try:
                # Try semantic search first
                if hasattr(self._memory, "semantic_search"):
                    records = self._memory.semantic_search(query, limit=limit * 2)
                else:
                    records = self._memory.retrieve(query=query, limit=limit * 2)

                for record in records:
                    content = record.get("content", "")
                    metadata = record.get("metadata", {})

                    # Filter by task type if specified
                    if task_type and metadata.get("task_type") != task_type.value:
                        continue

                    if isinstance(content, str):
                        try:
                            data = json.loads(content)
                            episode = LearningEpisode.from_dict(data)
                            episodes.append(episode)
                            if len(episodes) >= limit:
                                break
                        except (json.JSONDecodeError, ValueError):
                            pass
            except Exception as e:
                print(f"[EPISODE_STORE] Semantic query failed: {e}")

        return episodes

    def get_failure_examples(
        self,
        task_type: TaskType,
        failure_category: Optional[FailureCategory] = None,
        limit: int = 5,
    ) -> List[LearningEpisode]:
        """
        Get failure examples for learning.

        Args:
            task_type: The task type
            failure_category: Optional filter by failure category
            limit: Maximum number of examples

        Returns:
            List of failure episodes
        """
        episodes = []

        if self._memory:
            try:
                records = self._memory.retrieve(
                    query=f"{task_type.value} failure",
                    limit=limit * 2
                )
                for record in records:
                    content = record.get("content", "")
                    if isinstance(content, str):
                        try:
                            data = json.loads(content)
                            episode = LearningEpisode.from_dict(data)

                            # Filter by failure category if specified
                            if failure_category:
                                if episode.evaluation.failure_category != failure_category:
                                    continue

                            episodes.append(episode)
                            if len(episodes) >= limit:
                                break
                        except (json.JSONDecodeError, ValueError):
                            pass
            except Exception as e:
                print(f"[EPISODE_STORE] Failure query failed: {e}")

        return episodes

    def get_statistics(self) -> Dict[str, Any]:
        """Get storage statistics."""
        stats = {
            "cache_size": len(self._cache),
            "by_task_type": {},
            "by_episode_type": {},
            "success_rate": 0.0,
        }

        # Calculate from cache (available episodes)
        total = 0
        success_count = 0
        for episode_id, episode in self._cache.items():
            total += 1
            if episode.success:
                success_count += 1

            # Count by task type
            tt = episode.task_type.value
            stats["by_task_type"][tt] = stats["by_task_type"].get(tt, 0) + 1

            # Count by episode type
            et = episode.episode_type.value
            stats["by_episode_type"][et] = stats["by_episode_type"].get(et, 0) + 1

        if total > 0:
            stats["success_rate"] = success_count / total

        return stats


# Global singleton
_store: Optional[EpisodeStore] = None


def get_episode_store() -> EpisodeStore:
    """Get the global episode store instance."""
    global _store
    if _store is None:
        _store = EpisodeStore()
    return _store


def record_teacher_episode(
    task_type: TaskType,
    input_query: str,
    brain_attempt: BrainAttempt,
    llm_response: LLMResponse,
    evaluation: Evaluation,
    ideal_blueprint: Optional[IdealBlueprint] = None,
    failure_trace: Optional[FailureTrace] = None,
    context: Optional[Dict[str, Any]] = None,
) -> LearningEpisode:
    """
    Record an episode where LLM was used as teacher.

    Args:
        task_type: The task type
        input_query: The user's query
        brain_attempt: The brain's attempt
        llm_response: The LLM's response
        evaluation: Evaluation of the attempt
        ideal_blueprint: Optional ideal answer blueprint
        failure_trace: Optional failure trace
        context: Optional context snapshot

    Returns:
        The stored episode
    """
    episode = LearningEpisode(
        episode_type=EpisodeType.TEACHER_FALLBACK,
        task_type=task_type,
        input_query=input_query,
        context_snapshot=context or {},
        brain_attempt=brain_attempt,
        llm_response=llm_response,
        evaluation=evaluation,
        ideal_blueprint=ideal_blueprint,
        failure_trace=failure_trace,
        success=evaluation.brain_was_correct,
    )

    get_episode_store().store(episode)
    return episode


def record_validation_episode(
    task_type: TaskType,
    input_query: str,
    brain_attempt: BrainAttempt,
    llm_response: LLMResponse,
    approved: bool,
    context: Optional[Dict[str, Any]] = None,
) -> LearningEpisode:
    """
    Record an episode where LLM was used as validator.

    Args:
        task_type: The task type
        input_query: The user's query
        brain_attempt: The brain's attempt
        llm_response: The validator's response
        approved: Whether the answer was approved
        context: Optional context snapshot

    Returns:
        The stored episode
    """
    evaluation = Evaluation(
        brain_was_correct=approved,
        what_was_wrong="" if approved else llm_response.reasoning,
    )

    episode = LearningEpisode(
        episode_type=EpisodeType.VALIDATION,
        task_type=task_type,
        input_query=input_query,
        context_snapshot=context or {},
        brain_attempt=brain_attempt,
        llm_response=llm_response,
        evaluation=evaluation,
        success=approved,
    )

    get_episode_store().store(episode)
    return episode


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for episode storage.

    Operations:
    - STORE: Store a learning episode
    - GET: Get an episode by ID
    - QUERY_TASK_TYPE: Query episodes by task type
    - QUERY_SIMILAR: Query similar episodes
    - GET_STATISTICS: Get storage statistics
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    store = get_episode_store()

    if op == "STORE":
        episode_data = payload.get("episode", {})
        episode = LearningEpisode.from_dict(episode_data)
        episode_id = store.store(episode)
        return {
            "ok": True,
            "payload": {"episode_id": episode_id}
        }

    elif op == "GET":
        episode_id = payload.get("episode_id", "")
        episode = store.get(episode_id)
        if episode:
            return {
                "ok": True,
                "payload": episode.to_dict()
            }
        return {"ok": False, "error": f"Episode not found: {episode_id}"}

    elif op == "QUERY_TASK_TYPE":
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        limit = payload.get("limit", 10)
        success_only = payload.get("success_only", False)
        episodes = store.query_by_task_type(task_type, limit, success_only)
        return {
            "ok": True,
            "payload": {
                "episodes": [e.to_dict() for e in episodes],
                "count": len(episodes),
            }
        }

    elif op == "QUERY_SIMILAR":
        query = payload.get("query", "")
        task_type = None
        if payload.get("task_type"):
            try:
                task_type = TaskType(payload["task_type"])
            except ValueError:
                pass
        limit = payload.get("limit", 5)
        episodes = store.query_similar(query, task_type, limit)
        return {
            "ok": True,
            "payload": {
                "episodes": [e.to_dict() for e in episodes],
                "count": len(episodes),
            }
        }

    elif op == "GET_STATISTICS":
        return {
            "ok": True,
            "payload": store.get_statistics()
        }

    # Learning Loop Architecture operations
    elif op == "STORE_TURN":
        turn_data = payload.get("turn", {})
        turn = ConversationTurn.from_dict(turn_data)
        turn_id = get_turn_store().store(turn)
        return {"ok": True, "payload": {"turn_id": turn_id}}

    elif op == "GET_TURN":
        turn_id = payload.get("turn_id", "")
        turn = get_turn_store().get(turn_id)
        if turn:
            return {"ok": True, "payload": turn.to_dict()}
        return {"ok": False, "error": f"Turn not found: {turn_id}"}

    elif op == "STORE_STYLE":
        style_data = payload.get("style", {})
        style = StylePattern.from_dict(style_data)
        style_id = get_style_store().store(style)
        return {"ok": True, "payload": {"style_id": style_id}}

    elif op == "GET_STYLE_FOR_CONTEXT":
        domain = DomainGuess(payload.get("domain", "unknown"))
        tags = payload.get("tags", [])
        style = get_style_store().get_best_match(domain, tags)
        if style:
            return {"ok": True, "payload": style.to_dict()}
        return {"ok": True, "payload": None}

    elif op == "STORE_SIGNAL":
        signal_data = payload.get("signal", {})
        signal = MetaSignal.from_dict(signal_data)
        signal_id = get_signal_store().store(signal)
        return {"ok": True, "payload": {"signal_id": signal_id}}

    elif op == "GET_DOMAIN_STATS":
        domain = DomainGuess(payload.get("domain", "unknown"))
        stats = get_signal_store().get_domain_stats(domain)
        return {"ok": True, "payload": stats}

    return {"ok": False, "error": f"Unknown op: {op}"}


# =============================================================================
# LEARNING LOOP STORES
# =============================================================================

class ConversationTurnStore:
    """Storage for conversation turns."""

    def __init__(self):
        self._memory: Optional[BrainMemory] = None
        self._cache: Dict[str, ConversationTurn] = {}
        self._init_memory()

    def _init_memory(self) -> None:
        if BrainMemory:
            try:
                self._memory = BrainMemory("conversation_turns")
            except Exception as e:
                print(f"[TURN_STORE] Memory init failed: {e}")

    def store(self, turn: ConversationTurn) -> str:
        self._cache[turn.id] = turn

        if self._memory:
            try:
                self._memory.store(
                    content=json.dumps(turn.to_dict()),
                    metadata={
                        "kind": "conversation_turn",
                        "turn_id": turn.id,
                        "domain": turn.domain_guess.value,
                        "route": turn.route_used.value,
                        "has_shadow": bool(turn.maven_shadow_answer),
                    }
                )
            except Exception as e:
                print(f"[TURN_STORE] Store failed: {e}")

        return turn.id

    def get(self, turn_id: str) -> Optional[ConversationTurn]:
        if turn_id in self._cache:
            return self._cache[turn_id]

        if self._memory:
            try:
                records = self._memory.retrieve(query=turn_id, limit=1)
                for record in records:
                    content = record.get("content", "")
                    if isinstance(content, str):
                        try:
                            data = json.loads(content)
                            turn = ConversationTurn.from_dict(data)
                            self._cache[turn_id] = turn
                            return turn
                        except (json.JSONDecodeError, ValueError):
                            pass
            except Exception:
                pass
        return None

    def get_recent(self, limit: int = 10, session_id: str = "") -> List[ConversationTurn]:
        """Get recent turns, optionally filtered by session."""
        turns = []
        for turn in sorted(self._cache.values(), key=lambda t: t.timestamp, reverse=True):
            if session_id and turn.session_id != session_id:
                continue
            turns.append(turn)
            if len(turns) >= limit:
                break
        return turns


class StylePatternStore:
    """Storage for learned style patterns."""

    def __init__(self):
        self._memory: Optional[BrainMemory] = None
        self._cache: Dict[str, StylePattern] = {}
        self._by_domain: Dict[DomainGuess, List[StylePattern]] = {}
        self._init_memory()

    def _init_memory(self) -> None:
        if BrainMemory:
            try:
                self._memory = BrainMemory("style_patterns")
            except Exception as e:
                print(f"[STYLE_STORE] Memory init failed: {e}")

    def store(self, pattern: StylePattern) -> str:
        self._cache[pattern.id] = pattern

        # Index by domain
        if pattern.domain_guess not in self._by_domain:
            self._by_domain[pattern.domain_guess] = []
        self._by_domain[pattern.domain_guess].append(pattern)

        if self._memory:
            try:
                self._memory.store(
                    content=json.dumps(pattern.to_dict()),
                    metadata={
                        "kind": "style_pattern",
                        "pattern_id": pattern.id,
                        "domain": pattern.domain_guess.value,
                        "answer_type": pattern.answer_type,
                        "has_code": pattern.has_code,
                    }
                )
            except Exception as e:
                print(f"[STYLE_STORE] Store failed: {e}")

        return pattern.id

    def get_best_match(
        self,
        domain: DomainGuess,
        tags: List[str] = None,
        answer_type: str = "",
    ) -> Optional[StylePattern]:
        """Find the best matching style pattern for context."""
        candidates = self._by_domain.get(domain, [])

        if not candidates:
            # Fall back to any domain
            candidates = list(self._cache.values())

        if not candidates:
            return None

        # Score candidates
        def score(p: StylePattern) -> float:
            s = p.quality_score
            if answer_type and p.answer_type == answer_type:
                s += 0.3
            if tags:
                overlap = len(set(p.tags) & set(tags))
                s += overlap * 0.1
            return s

        candidates.sort(key=score, reverse=True)
        return candidates[0] if candidates else None


class MetaSignalStore:
    """Storage for meta signals."""

    def __init__(self):
        self._memory: Optional[BrainMemory] = None
        self._cache: List[MetaSignal] = []
        self._by_domain: Dict[DomainGuess, List[MetaSignal]] = {}
        self._init_memory()

    def _init_memory(self) -> None:
        if BrainMemory:
            try:
                self._memory = BrainMemory("meta_signals")
            except Exception as e:
                print(f"[SIGNAL_STORE] Memory init failed: {e}")

    def store(self, signal: MetaSignal) -> str:
        self._cache.append(signal)

        # Index by domain
        if signal.domain not in self._by_domain:
            self._by_domain[signal.domain] = []
        self._by_domain[signal.domain].append(signal)

        if self._memory:
            try:
                self._memory.store(
                    content=json.dumps(signal.to_dict()),
                    metadata={
                        "kind": "meta_signal",
                        "signal_id": signal.id,
                        "signal_type": signal.signal_type.value,
                        "domain": signal.domain.value,
                        "severity": signal.severity,
                    }
                )
            except Exception as e:
                print(f"[SIGNAL_STORE] Store failed: {e}")

        return signal.id

    def get_domain_stats(self, domain: DomainGuess) -> Dict[str, Any]:
        """Get aggregate statistics for a domain."""
        signals = self._by_domain.get(domain, [])

        if not signals:
            return {
                "domain": domain.value,
                "total_signals": 0,
                "shadow_better_count": 0,
                "shadow_worse_count": 0,
                "shadow_comparable_count": 0,
                "avg_shadow_score": 0.0,
                "ready_for_takeover": False,
            }

        shadow_better = sum(1 for s in signals if s.signal_type == SignalType.SHADOW_BETTER_THAN_TEACHER)
        shadow_worse = sum(1 for s in signals if s.signal_type == SignalType.SHADOW_WORSE_THAN_TEACHER)
        shadow_comp = sum(1 for s in signals if s.signal_type == SignalType.SHADOW_COMPARABLE)

        avg_score = sum(s.shadow_score for s in signals) / len(signals)

        # Takeover readiness: at least 50 signals, 80%+ comparable/better, avg score > 0.8
        total = len(signals)
        good_ratio = (shadow_better + shadow_comp) / total if total > 0 else 0
        ready = total >= 50 and good_ratio >= 0.8 and avg_score >= 0.8

        return {
            "domain": domain.value,
            "total_signals": total,
            "shadow_better_count": shadow_better,
            "shadow_worse_count": shadow_worse,
            "shadow_comparable_count": shadow_comp,
            "avg_shadow_score": avg_score,
            "good_ratio": good_ratio,
            "ready_for_takeover": ready,
        }


# Global singletons
_turn_store: Optional[ConversationTurnStore] = None
_style_store: Optional[StylePatternStore] = None
_signal_store: Optional[MetaSignalStore] = None


def get_turn_store() -> ConversationTurnStore:
    global _turn_store
    if _turn_store is None:
        _turn_store = ConversationTurnStore()
    return _turn_store


def get_style_store() -> StylePatternStore:
    global _style_store
    if _style_store is None:
        _style_store = StylePatternStore()
    return _style_store


def get_signal_store() -> MetaSignalStore:
    global _signal_store
    if _signal_store is None:
        _signal_store = MetaSignalStore()
    return _signal_store


# =============================================================================
# CONVENIENCE FUNCTIONS FOR LEARNING LOOP
# =============================================================================

def store_conversation_turn(
    user_query: str,
    teacher_answer: str,
    route_used: RouteUsed = RouteUsed.TEACHER_FAST_PATH,
    maven_shadow_answer: str = "",
    tools_used: List[str] = None,
    quality_check: QualityCheck = None,
    domain_guess: DomainGuess = DomainGuess.UNKNOWN,
    tags: List[str] = None,
    session_id: str = "",
) -> ConversationTurn:
    """Store a conversation turn and return it."""
    turn = ConversationTurn(
        session_id=session_id,
        user_query=user_query,
        route_used=route_used,
        teacher_answer=teacher_answer,
        maven_shadow_answer=maven_shadow_answer,
        tools_used=tools_used or [],
        quality_check=quality_check or QualityCheck(),
        domain_guess=domain_guess,
        tags=tags or [],
    )
    get_turn_store().store(turn)
    return turn


def learn_style_from_answer(
    answer: str,
    query: str,
    turn_id: str = "",
    domain: DomainGuess = DomainGuess.UNKNOWN,
    tags: List[str] = None,
    quality_score: float = 0.8,
) -> Optional[StylePattern]:
    """Extract and store a style pattern from a good answer."""
    # Only learn from answers with sufficient length
    if len(answer.split()) < 20:
        return None

    pattern = StylePattern.extract_from_answer(
        answer=answer,
        query=query,
        turn_id=turn_id,
        domain=domain,
        tags=tags,
    )
    pattern.quality_score = quality_score
    get_style_store().store(pattern)
    return pattern


def record_meta_signal(
    turn_id: str,
    signal_type: SignalType,
    domain: DomainGuess,
    shadow_score: float = 0.0,
    quality_score: float = 0.0,
    details: str = "",
    task_type: str = "",
) -> MetaSignal:
    """Record a meta signal for learning."""
    # Compute severity based on signal type
    if signal_type in (SignalType.TEACHER_QUALITY_FAIL, SignalType.IDENTITY_VIOLATION):
        severity = 0.9
    elif signal_type == SignalType.SHADOW_WORSE_THAN_TEACHER:
        severity = 0.7
    elif signal_type == SignalType.USER_COMPLAINT:
        severity = 0.8
    else:
        severity = 0.5

    signal = MetaSignal(
        source_turn_id=turn_id,
        signal_type=signal_type,
        details=details,
        severity=severity,
        domain=domain,
        task_type=task_type,
        shadow_score=shadow_score,
        quality_score=quality_score,
    )
    get_signal_store().store(signal)
    return signal


def check_domain_takeover_ready(domain: DomainGuess) -> Dict[str, Any]:
    """Check if a domain is ready for Maven to take over."""
    return get_signal_store().get_domain_stats(domain)


handle = service_api
