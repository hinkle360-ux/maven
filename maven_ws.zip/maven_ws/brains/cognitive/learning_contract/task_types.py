"""
Task Type Classification System
================================

Defines the 8 broad task types for Maven's learning contract.
Every user request is tagged with one of these types to enable
task-specific skill tracking and learning.

Task Types:
- summarization: Compress information while preserving essentials
- rewriting: Transform text (style, tone, format changes)
- explanation: Make concepts understandable
- qa: Answer factual questions
- reason_giving: Justify decisions or conclusions
- planning: Create action plans or sequences
- self_consistency: Check internal coherence
- epistemic_check: Handle unknowns and uncertainty
- meta_analysis: Analyze reasoning patterns (like Turn 7 logic)
"""

from __future__ import annotations
from enum import Enum
from typing import Dict, Any, Optional, List
import re


class TaskType(Enum):
    """Broad task type categories for skill tracking."""
    SUMMARIZATION = "summarization"
    REWRITING = "rewriting"
    EXPLANATION = "explanation"
    QA = "qa"
    REASON_GIVING = "reason_giving"
    PLANNING = "planning"
    SELF_CONSISTENCY = "self_consistency"
    EPISTEMIC_CHECK = "epistemic_check"
    META_ANALYSIS = "meta_analysis"
    UNKNOWN = "unknown"


# Pattern-based task type detection
# Each pattern maps to a task type
TASK_TYPE_PATTERNS: Dict[TaskType, List[str]] = {
    TaskType.SUMMARIZATION: [
        r"\bsummar",
        r"\btl;?dr\b",
        r"\bbrief\b.*\b(version|overview)\b",
        r"\bkey\s+points?\b",
        r"\bcondense\b",
        r"\bshorten\b",
        r"\bhighlights?\b",
        r"\bmain\s+ideas?\b",
        r"\bgist\b",
    ],
    TaskType.REWRITING: [
        r"\brewrite\b",
        r"\brephrase\b",
        r"\breword\b",
        r"\bparaphrase\b",
        r"\bsay\s+(this|it|that)\s+(differently|another\s+way)\b",
        r"\bmake\s+(it|this)\s+(more|less)\b",
        r"\bconvert\s+(to|into)\b",
        r"\btranslate\b",
        r"\bsimplify\b",
        r"\bformalize\b",
    ],
    TaskType.EXPLANATION: [
        r"\bexplain\b",
        r"\bwhat\s+is\b",
        r"\bwhat\s+are\b",
        r"\bhow\s+does\b",
        r"\bhow\s+do\b",
        r"\bwhy\s+is\b",
        r"\bwhy\s+are\b",
        r"\bwhy\s+does\b",
        r"\bwhy\s+do\b",
        r"\bdefine\b",
        r"\bdescribe\b",
        r"\btell\s+me\s+about\b",
        r"\bhelp\s+me\s+understand\b",
        r"\bwhat\s+does\s+.*\s+mean\b",
        r"\bbreak\s+(it|this)\s+down\b",
    ],
    TaskType.QA: [
        r"\bwho\s+(is|was|are|were)\b",
        r"\bwhen\s+(did|was|is|will)\b",
        r"\bwhere\s+(is|was|are|were|did)\b",
        r"\bhow\s+many\b",
        r"\bhow\s+much\b",
        r"\bhow\s+long\b",
        r"\bhow\s+old\b",
        r"\bwhich\s+(is|are|was|were)\b",
        r"\bis\s+(it|this|that)\s+true\b",
        r"\bdid\s+.*\s+(happen|occur)\b",
        r"\bcan\s+you\s+tell\s+me\b",
        r"\bdo\s+you\s+know\b",
    ],
    TaskType.REASON_GIVING: [
        r"\bwhy\s+should\b",
        r"\bwhy\s+not\b",
        r"\bgive\s+me\s+reasons?\b",
        r"\bjustify\b",
        r"\bexplain\s+why\b",
        r"\bwhat\s+are\s+the\s+reasons?\b",
        r"\bwhat\s+makes\b",
        r"\bwhat\s+causes?\b",
        r"\bbecause\s+of\s+what\b",
        r"\breasoning\s+behind\b",
        r"\bsupport\s+(this|your)\s+(claim|argument)\b",
    ],
    TaskType.PLANNING: [
        r"\bplan\b",
        r"\bsteps?\s+to\b",
        r"\bhow\s+(do|can|should)\s+i\b",
        r"\bwhat\s+should\s+i\s+do\b",
        r"\bwhat\s+are\s+the\s+steps\b",
        r"\bguide\s+me\b",
        r"\bwalk\s+me\s+through\b",
        r"\bprocess\s+for\b",
        r"\bstrategy\b",
        r"\bapproach\s+to\b",
        r"\bsequence\b",
        r"\border\s+of\s+operations\b",
        r"\broadmap\b",
    ],
    TaskType.SELF_CONSISTENCY: [
        r"\bconsisten(t|cy)\b",
        r"\bcontradic(t|tion)\b",
        r"\bmakes?\s+sense\b",
        r"\bcheck\s+(if|whether)\b",
        r"\bverify\b",
        r"\bvalidate\b",
        r"\blog(ic|ical)\b",
        r"\bcoherent\b",
        r"\balign(ed|s)?\s+with\b",
        r"\bmatch(es)?\b",
    ],
    TaskType.EPISTEMIC_CHECK: [
        r"\bare\s+you\s+sure\b",
        r"\bhow\s+certain\b",
        r"\bhow\s+confident\b",
        r"\bdo\s+you\s+know\s+for\s+sure\b",
        r"\bis\s+this\s+(certain|definite)\b",
        r"\buncertain\b",
        r"\bunknown\b",
        r"\bpossib(le|ly|ility)\b",
        r"\bmight\s+be\b",
        r"\bcould\s+be\b",
        r"\bdon'?t\s+know\b",
        r"\bnot\s+sure\b",
        r"\bguess\b",
        r"\bestimate\b",
    ],
    TaskType.META_ANALYSIS: [
        r"\banalyze\s+(your|the|my)\s+(reasoning|logic|argument)\b",
        r"\bmeta\b",
        r"\bthink\s+about\s+(how|what)\s+you\b",
        r"\breflect\s+on\b",
        r"\bwhat\s+was\s+your\s+(reasoning|logic)\b",
        r"\bhow\s+did\s+you\s+(reach|arrive|get)\b",
        r"\bexplain\s+your\s+(thought|reasoning)\s+process\b",
        r"\bwhy\s+did\s+you\s+(say|conclude|decide)\b",
        r"\bwalk\s+me\s+through\s+your\s+(logic|reasoning)\b",
        r"\bcritique\s+(your|the)\b",
    ],
}


def classify_task_type(query: str, context: Optional[Dict[str, Any]] = None) -> TaskType:
    """
    Classify a user query into one of the broad task types.

    Args:
        query: The user's input query
        context: Optional context with hints (e.g., prior classification)

    Returns:
        The detected TaskType

    Examples:
        >>> classify_task_type("Summarize this article")
        TaskType.SUMMARIZATION
        >>> classify_task_type("What is photosynthesis?")
        TaskType.EXPLANATION
        >>> classify_task_type("Who invented the telephone?")
        TaskType.QA
    """
    if not query:
        return TaskType.UNKNOWN

    query_lower = query.lower().strip()

    # Check context hints first (from prior classification)
    if context:
        hint = context.get("task_type_hint")
        if hint:
            try:
                return TaskType(hint)
            except ValueError:
                pass

    # Pattern-based classification
    scores: Dict[TaskType, int] = {t: 0 for t in TaskType}

    for task_type, patterns in TASK_TYPE_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, query_lower):
                scores[task_type] += 1

    # Find highest scoring type
    max_score = max(scores.values())
    if max_score > 0:
        for task_type, score in scores.items():
            if score == max_score:
                return task_type

    # Fallback heuristics
    if "?" in query:
        # Questions default to QA or EXPLANATION
        if any(query_lower.startswith(w) for w in ["what", "how", "why"]):
            return TaskType.EXPLANATION
        return TaskType.QA

    # Default: treat as explanation request
    return TaskType.EXPLANATION


def get_task_type_rule(task_type: TaskType) -> str:
    """
    Get the abstract rule for a task type.

    These rules guide the brain's synthesis approach before
    considering examples.

    Args:
        task_type: The task type to get the rule for

    Returns:
        The abstract rule as a string
    """
    rules = {
        TaskType.SUMMARIZATION: (
            "Compress the source content while preserving core events, "
            "essential facts, and key relationships. Omit redundant details, "
            "examples that don't add meaning, and tangential information. "
            "Maintain the original structure's logic but express it concisely."
        ),
        TaskType.REWRITING: (
            "Transform the input text to match the target style, tone, or format "
            "while preserving the original meaning. Adapt vocabulary, sentence "
            "structure, and complexity to the target audience. Ensure no meaning "
            "is lost or added in the transformation."
        ),
        TaskType.EXPLANATION: (
            "Make the concept understandable by building from what the user likely "
            "already knows. Use analogies, examples, and progressive complexity. "
            "Address the 'why' and 'how' not just the 'what'. Anticipate and "
            "answer likely follow-up questions."
        ),
        TaskType.QA: (
            "Provide a direct, accurate answer to the question. State the answer "
            "first, then provide supporting context if needed. Cite sources when "
            "relevant. If uncertain, say so clearly. Don't over-explain simple "
            "factual answers."
        ),
        TaskType.REASON_GIVING: (
            "Provide clear justifications structured as: claim → evidence → "
            "connection. Use multiple independent reasons when available. "
            "Address potential counterarguments. Make the logical chain explicit."
        ),
        TaskType.PLANNING: (
            "Break down the goal into concrete, actionable steps. Order steps "
            "logically with dependencies explicit. Include decision points and "
            "alternatives where relevant. Estimate effort/complexity for each step."
        ),
        TaskType.SELF_CONSISTENCY: (
            "Check for internal contradictions, logical gaps, and alignment with "
            "prior statements. Flag any inconsistencies explicitly. Explain what "
            "would need to change for consistency. Distinguish hard contradictions "
            "from acceptable nuance."
        ),
        TaskType.EPISTEMIC_CHECK: (
            "Assess and communicate certainty levels honestly. Distinguish between "
            "known facts, inferences, assumptions, and speculation. Quantify "
            "confidence when possible. Explain what would increase certainty."
        ),
        TaskType.META_ANALYSIS: (
            "Analyze the reasoning process itself, not just the conclusion. "
            "Identify assumptions, logical steps, and potential weaknesses. "
            "Compare to alternative reasoning paths. Evaluate validity and "
            "soundness separately."
        ),
        TaskType.UNKNOWN: (
            "Analyze the request to understand the user's underlying need. "
            "Ask clarifying questions if intent is unclear. Default to helpful "
            "explanation if ambiguous."
        ),
    }
    return rules.get(task_type, rules[TaskType.UNKNOWN])


def get_task_type_constraints(task_type: TaskType) -> Dict[str, Any]:
    """
    Get default constraints for a task type.

    Args:
        task_type: The task type

    Returns:
        Dictionary of constraints (length, format, etc.)
    """
    constraints = {
        TaskType.SUMMARIZATION: {
            "length_ratio": 0.25,  # Target ~25% of original length
            "preserve": ["key_facts", "main_events", "conclusions"],
            "omit": ["examples", "tangents", "repetition"],
        },
        TaskType.REWRITING: {
            "preserve_meaning": True,
            "match_length": True,  # Similar length to original
            "adapt_to_audience": True,
        },
        TaskType.EXPLANATION: {
            "structure": ["context", "definition", "mechanism", "examples"],
            "depth": "progressive",  # Start simple, add complexity
            "include_analogies": True,
        },
        TaskType.QA: {
            "answer_first": True,
            "concise": True,
            "cite_sources": True,
            "express_uncertainty": True,
        },
        TaskType.REASON_GIVING: {
            "structure": ["claim", "evidence", "connection"],
            "multiple_reasons": True,
            "address_counterarguments": True,
        },
        TaskType.PLANNING: {
            "numbered_steps": True,
            "explicit_dependencies": True,
            "include_alternatives": True,
            "estimate_effort": True,
        },
        TaskType.SELF_CONSISTENCY: {
            "explicit_comparison": True,
            "flag_contradictions": True,
            "suggest_resolutions": True,
        },
        TaskType.EPISTEMIC_CHECK: {
            "quantify_confidence": True,
            "distinguish_types": ["fact", "inference", "assumption", "speculation"],
            "explain_gaps": True,
        },
        TaskType.META_ANALYSIS: {
            "analyze_process": True,
            "identify_assumptions": True,
            "compare_alternatives": True,
            "evaluate_validity": True,
        },
        TaskType.UNKNOWN: {
            "clarify_intent": True,
            "default_helpful": True,
        },
    }
    return constraints.get(task_type, constraints[TaskType.UNKNOWN])


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for task type classification.

    Operations:
    - CLASSIFY: Classify a query into a task type
    - GET_RULE: Get the abstract rule for a task type
    - GET_CONSTRAINTS: Get default constraints for a task type
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})

    if op == "CLASSIFY":
        query = payload.get("query", "")
        context = payload.get("context")
        task_type = classify_task_type(query, context)
        return {
            "ok": True,
            "payload": {
                "task_type": task_type.value,
                "task_type_enum": task_type,
                "rule": get_task_type_rule(task_type),
                "constraints": get_task_type_constraints(task_type),
            }
        }

    elif op == "GET_RULE":
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        return {
            "ok": True,
            "payload": {"rule": get_task_type_rule(task_type)}
        }

    elif op == "GET_CONSTRAINTS":
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        return {
            "ok": True,
            "payload": {"constraints": get_task_type_constraints(task_type)}
        }

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
