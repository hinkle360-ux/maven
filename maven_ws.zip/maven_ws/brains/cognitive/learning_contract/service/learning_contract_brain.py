"""
Learning Contract Brain
========================

Main orchestrator for the Learning Contract system.

This brain coordinates:
1. Task type classification
2. Skill tracking
3. 3-pass self-correction
4. Episode storage
5. Rule+example fusion
6. Teacher gating

Entry point for all learning contract operations.

Contract Summary:
- Brains always try first
- LLM as fallback teacher (developing) or validator (proficient/mastered)
- Every LLM touch triggers full learning episode storage
- Skills evolve: DEVELOPING -> PROFICIENT -> MASTERED
"""

from __future__ import annotations
from typing import Dict, Any, Optional
from dataclasses import dataclass

# Import all learning contract components
from brains.cognitive.learning_contract.task_types import (
    TaskType,
    classify_task_type,
    get_task_type_rule,
    get_task_type_constraints,
)
from brains.cognitive.learning_contract.skill_tracker import (
    get_skill_tracker,
    SkillLevel,
    SkillProfile,
    record_task_outcome,
    get_llm_mode,
)
from brains.cognitive.learning_contract.episode_storage import (
    get_episode_store,
    LearningEpisode,
    EpisodeType,
)
from brains.cognitive.learning_contract.rule_example_fusion import (
    get_fusion_engine,
    synthesize_answer,
    FusionResult,
)
from brains.cognitive.learning_contract.self_correction_pipeline import (
    run_self_correction,
    SelfCorrectionResult,
)
from brains.cognitive.learning_contract.teacher_gating import (
    get_teacher_gating,
    process_with_learning_contract,
    set_teacher_free_mode,
    TeacherResult,
    TeacherMode,
)


@dataclass
class ContractResult:
    """Full result from the learning contract pipeline."""
    # Final answer
    answer: str
    confidence: float

    # Classification
    task_type: TaskType
    task_type_rule: str

    # Skill info
    skill_level: SkillLevel
    skill_updated: bool

    # Process info
    brain_tried_first: bool
    self_correction_passes: int
    llm_used: bool
    llm_mode: str  # "teacher", "validator", or "none"

    # Learning
    learning_occurred: bool
    episode_id: Optional[str]

    # Source tracing
    source: str  # "brain", "teacher", "validator_approved", "validator_rejected"


class LearningContractBrain:
    """
    Main orchestrator for the learning contract.

    Ensures brains always try first, LLM is gated by skill level,
    and every LLM interaction triggers learning.
    """

    def __init__(self):
        self._tracker = get_skill_tracker()
        self._store = get_episode_store()
        self._fusion = get_fusion_engine()
        self._gating = get_teacher_gating()

    def process(
        self,
        query: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> ContractResult:
        """
        Process a query through the full learning contract.

        Pipeline:
        1. Classify task type
        2. Get skill level
        3. Run brain-first with 3-pass self-correction
        4. Gate LLM access based on skill
        5. Store learning episode if LLM touched
        6. Update skill level
        7. Return result with full tracing

        Args:
            query: The user's query
            context: Optional context

        Returns:
            ContractResult with full process trace
        """
        # Step 1: Classify task type
        task_type = classify_task_type(query, context)
        rule = get_task_type_rule(task_type)

        print(f"[LEARNING_CONTRACT] Task type: {task_type.value}")

        # Step 2: Get current skill level
        profile = self._tracker.get_profile(task_type)
        initial_skill = profile.level

        print(f"[LEARNING_CONTRACT] Skill level: {initial_skill.value}")

        # Step 3: Process through gated pipeline
        result = process_with_learning_contract(query, context)

        # Step 4: Determine what happened
        llm_mode = "none"
        if result.source == "teacher":
            llm_mode = "teacher"
        elif "validator" in result.source:
            llm_mode = "validator"

        # Step 5: Check if skill was updated
        new_profile = self._tracker.get_profile(task_type)
        skill_updated = new_profile.level != initial_skill

        return ContractResult(
            answer=result.answer,
            confidence=result.confidence,
            task_type=task_type,
            task_type_rule=rule,
            skill_level=new_profile.level,
            skill_updated=skill_updated,
            brain_tried_first=True,  # Always true per contract
            self_correction_passes=3,  # Pipeline runs 3 passes
            llm_used=llm_mode != "none",
            llm_mode=llm_mode,
            learning_occurred=result.learning_occurred,
            episode_id=result.episode_id,
            source=result.source,
        )

    def get_skill_summary(self) -> Dict[str, Any]:
        """Get summary of all skill levels."""
        return self._tracker.get_summary()

    def get_episode_stats(self) -> Dict[str, Any]:
        """Get episode storage statistics."""
        return self._store.get_statistics()

    def set_teacher_free_mode(self, enabled: bool) -> None:
        """Enable/disable teacher-free mode."""
        set_teacher_free_mode(enabled)

    def force_skill_level(
        self,
        task_type: TaskType,
        level: SkillLevel,
    ) -> None:
        """
        Force a skill level (for testing).

        Args:
            task_type: The task type
            level: The level to set
        """
        profile = self._tracker.get_profile(task_type)
        profile.level = level
        print(f"[LEARNING_CONTRACT] Forced {task_type.value} to {level.value}")


# Global singleton
_brain: Optional[LearningContractBrain] = None


def get_learning_contract_brain() -> LearningContractBrain:
    """Get the global learning contract brain instance."""
    global _brain
    if _brain is None:
        _brain = LearningContractBrain()
    return _brain


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point.

    Operations:
    - PROCESS: Process a query through the learning contract
    - GET_SKILL_SUMMARY: Get all skill levels
    - GET_EPISODE_STATS: Get episode storage statistics
    - SET_TEACHER_FREE: Enable/disable teacher-free mode
    - CLASSIFY_TASK: Classify a query's task type
    - GET_SKILL_FOR_TASK: Get skill info for a task type
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    brain = get_learning_contract_brain()

    if op == "PROCESS":
        query = payload.get("query", "")
        context = payload.get("context")
        result = brain.process(query, context)
        return {
            "ok": True,
            "payload": {
                "answer": result.answer,
                "confidence": result.confidence,
                "task_type": result.task_type.value,
                "task_type_rule": result.task_type_rule[:200] + "...",
                "skill_level": result.skill_level.value,
                "skill_updated": result.skill_updated,
                "brain_tried_first": result.brain_tried_first,
                "self_correction_passes": result.self_correction_passes,
                "llm_used": result.llm_used,
                "llm_mode": result.llm_mode,
                "learning_occurred": result.learning_occurred,
                "episode_id": result.episode_id,
                "source": result.source,
            }
        }

    elif op == "GET_SKILL_SUMMARY":
        return {
            "ok": True,
            "payload": brain.get_skill_summary()
        }

    elif op == "GET_EPISODE_STATS":
        return {
            "ok": True,
            "payload": brain.get_episode_stats()
        }

    elif op == "SET_TEACHER_FREE":
        enabled = payload.get("enabled", False)
        brain.set_teacher_free_mode(enabled)
        return {
            "ok": True,
            "payload": {"teacher_free_mode": enabled}
        }

    elif op == "CLASSIFY_TASK":
        query = payload.get("query", "")
        context = payload.get("context")
        task_type = classify_task_type(query, context)
        return {
            "ok": True,
            "payload": {
                "task_type": task_type.value,
                "rule": get_task_type_rule(task_type),
                "constraints": get_task_type_constraints(task_type),
            }
        }

    elif op == "GET_SKILL_FOR_TASK":
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        profile = get_skill_tracker().get_profile(task_type)
        use_teacher, use_validator, can_skip = get_llm_mode(task_type)
        return {
            "ok": True,
            "payload": {
                "task_type": task_type.value,
                "level": profile.level.value,
                "accuracy": profile.rolling_accuracy,
                "total_attempts": profile.total_attempts,
                "use_as_teacher": use_teacher,
                "use_as_validator": use_validator,
                "can_skip_llm": can_skip,
            }
        }

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
