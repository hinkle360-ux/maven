"""
Background Learning Daemon
===========================

Continuous background learning from stored episodes.
Runs when not answering live queries.

Priority scoring:
- Low skill task_type → higher priority
- Severe failures → higher priority
- Repeated failure pattern → higher priority
- Critic was confidently wrong → higher priority
- Some weight for recency

Updates:
- Skill profiles (success/failure counts)
- Rules for task types (via derived patterns)
- Example banks (canonical examples)
- Critic parameters (confidence adjustments)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable
from threading import Thread, Event
from queue import PriorityQueue
import time
import json

from brains.cognitive.learning_contract.task_types import TaskType
from brains.cognitive.learning_contract.episode_storage import (
    get_episode_store,
    LearningEpisode,
    EpisodeType,
    FailureCategory,
)
from brains.cognitive.learning_contract.skill_tracker import (
    get_skill_tracker,
    SkillLevel,
)
from brains.cognitive.learning_contract.rule_example_fusion import (
    get_fusion_engine,
    Example,
)
from brains.cognitive.learning_contract.self_correction_pipeline import (
    get_self_correction_pipeline,
    CriticType,
    Critique,
    CriticPass,
)


# Priority thresholds (lower number = higher priority)
PRIORITY_BASE = 100
PRIORITY_LOW_SKILL = 30
PRIORITY_SEVERE_FAILURE = 25
PRIORITY_REPEATED_PATTERN = 35
PRIORITY_CRITIC_WRONG = 40
PRIORITY_RECENCY_WEIGHT = 0.5  # Hours factor


@dataclass(order=True)
class PrioritizedEpisode:
    """Episode with computed priority for processing."""
    priority: float
    episode_id: str = field(compare=False)
    episode: Optional[LearningEpisode] = field(compare=False, default=None)
    priority_breakdown: Dict[str, float] = field(compare=False, default_factory=dict)


@dataclass
class LearningUpdate:
    """Record of a learning update made by the daemon."""
    update_type: str  # "skill", "example", "rule", "critic"
    task_type: str
    description: str
    timestamp: float = 0.0
    episode_id: str = ""

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = time.time()


class LearningPriorityScorer:
    """
    Computes priority scores for learning episodes.

    Lower score = higher priority (to work with min-heap).
    """

    def __init__(self):
        self._skill_tracker = get_skill_tracker()
        self._failure_patterns: Dict[str, int] = {}  # Pattern -> count

    def score(self, episode: LearningEpisode) -> PrioritizedEpisode:
        """
        Compute priority score for an episode.

        Args:
            episode: The learning episode to score

        Returns:
            PrioritizedEpisode with computed priority
        """
        breakdown = {}
        priority = PRIORITY_BASE

        # Factor 1: Low skill task type → higher priority
        profile = self._skill_tracker.get_profile(episode.task_type)
        if profile.level == SkillLevel.DEVELOPING:
            priority -= PRIORITY_LOW_SKILL
            breakdown["low_skill"] = PRIORITY_LOW_SKILL
        elif profile.level == SkillLevel.PROFICIENT:
            priority -= PRIORITY_LOW_SKILL // 2
            breakdown["medium_skill"] = PRIORITY_LOW_SKILL // 2

        # Factor 2: Severe failures → higher priority
        if episode.evaluation and episode.evaluation.failure_category:
            severity = self._get_failure_severity(episode.evaluation.failure_category)
            priority_boost = int(PRIORITY_SEVERE_FAILURE * severity)
            priority -= priority_boost
            breakdown["failure_severity"] = priority_boost

        # Factor 3: Repeated failure pattern → higher priority
        pattern_key = self._get_pattern_key(episode)
        pattern_count = self._failure_patterns.get(pattern_key, 0)
        if pattern_count >= 2:
            priority -= PRIORITY_REPEATED_PATTERN
            breakdown["repeated_pattern"] = PRIORITY_REPEATED_PATTERN

        # Factor 4: Critic was confidently wrong → higher priority
        if self._was_critic_wrong(episode):
            priority -= PRIORITY_CRITIC_WRONG
            breakdown["critic_wrong"] = PRIORITY_CRITIC_WRONG

        # Factor 5: Recency weight (more recent = slightly higher priority)
        hours_ago = (time.time() - episode.timestamp) / 3600
        recency_penalty = min(20, int(hours_ago * PRIORITY_RECENCY_WEIGHT))
        priority += recency_penalty
        breakdown["recency_penalty"] = -recency_penalty

        return PrioritizedEpisode(
            priority=priority,
            episode_id=episode.episode_id,
            episode=episode,
            priority_breakdown=breakdown,
        )

    def _get_failure_severity(self, category: FailureCategory) -> float:
        """Get severity weight for a failure category."""
        severity_map = {
            FailureCategory.FACT_ERROR: 1.0,      # Most severe
            FailureCategory.COHERENCE: 0.9,
            FailureCategory.CONSTRAINT: 0.8,
            FailureCategory.STRUCTURE: 0.6,
            FailureCategory.INCOMPLETE: 0.5,
            FailureCategory.TONE: 0.3,
            FailureCategory.EXCESSIVE: 0.3,
            FailureCategory.UNKNOWN: 0.4,
        }
        return severity_map.get(category, 0.5)

    def _get_pattern_key(self, episode: LearningEpisode) -> str:
        """Get a pattern key for detecting repeated failures."""
        parts = [episode.task_type.value]
        if episode.evaluation and episode.evaluation.failure_category:
            parts.append(episode.evaluation.failure_category.value)
        return ":".join(parts)

    def _was_critic_wrong(self, episode: LearningEpisode) -> bool:
        """Check if the internal critic was confidently wrong."""
        # If brain thought it was correct but LLM disagreed
        if not episode.success and episode.brain_attempt.confidence > 0.7:
            return True
        # If brain thought it was wrong but LLM approved
        if episode.success and episode.brain_attempt.confidence < 0.3:
            return True
        return False

    def record_pattern(self, episode: LearningEpisode) -> None:
        """Record a failure pattern for tracking."""
        pattern_key = self._get_pattern_key(episode)
        self._failure_patterns[pattern_key] = \
            self._failure_patterns.get(pattern_key, 0) + 1


class LearningDaemon:
    """
    Background learning daemon.

    Processes learning episodes in priority order and updates:
    - Skill profiles
    - Rules for task types
    - Example banks
    - Critic parameters
    """

    def __init__(self, process_interval: float = 5.0):
        """
        Initialize the learning daemon.

        Args:
            process_interval: Seconds between processing cycles
        """
        self._scorer = LearningPriorityScorer()
        self._queue: PriorityQueue[PrioritizedEpisode] = PriorityQueue()
        self._stop_event = Event()
        self._thread: Optional[Thread] = None
        self._process_interval = process_interval
        self._is_busy = False  # True when answering live queries
        self._updates: List[LearningUpdate] = []

        # Limits
        self._max_queue_size = 1000
        self._max_updates_per_cycle = 10

        # Track processed episodes
        self._processed_ids: set = set()

    def start(self) -> None:
        """Start the background daemon."""
        if self._thread and self._thread.is_alive():
            return  # Already running

        self._stop_event.clear()
        self._thread = Thread(target=self._run, daemon=True)
        self._thread.start()
        print("[LEARNING_DAEMON] Started background learning")

    def stop(self) -> None:
        """Stop the background daemon."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=2.0)
        print("[LEARNING_DAEMON] Stopped")

    def pause(self) -> None:
        """Pause processing (when answering live queries)."""
        self._is_busy = True

    def resume(self) -> None:
        """Resume processing (when idle)."""
        self._is_busy = False

    def enqueue(self, episode: LearningEpisode) -> None:
        """
        Add an episode to the learning queue.

        Args:
            episode: The episode to process
        """
        if episode.episode_id in self._processed_ids:
            return  # Already processed

        if self._queue.qsize() >= self._max_queue_size:
            # Drop oldest low-priority items
            try:
                self._queue.get_nowait()
            except Exception:
                pass

        prioritized = self._scorer.score(episode)
        self._queue.put(prioritized)

        # Track failure patterns
        if not episode.success:
            self._scorer.record_pattern(episode)

    def _run(self) -> None:
        """Main daemon loop."""
        while not self._stop_event.is_set():
            # Wait if busy with live queries
            if self._is_busy:
                time.sleep(0.5)
                continue

            # Process next batch
            processed = 0
            while processed < self._max_updates_per_cycle and not self._queue.empty():
                try:
                    prioritized = self._queue.get_nowait()
                    if prioritized.episode:
                        self._process_episode(prioritized)
                        processed += 1
                except Exception as e:
                    print(f"[LEARNING_DAEMON] Process error: {e}")
                    break

            # Wait for next cycle
            self._stop_event.wait(self._process_interval)

    def _process_episode(self, prioritized: PrioritizedEpisode) -> None:
        """
        Process a single episode and make learning updates.

        Args:
            prioritized: The prioritized episode to process
        """
        episode = prioritized.episode
        if not episode:
            return

        self._processed_ids.add(episode.episode_id)

        # Update skill profile
        self._update_skill_profile(episode)

        # Update example bank
        self._update_example_bank(episode)

        # Update critic parameters
        self._update_critic_params(episode)

        # Log processing
        print(f"[LEARNING_DAEMON] Processed {episode.episode_id[:8]}... "
              f"(priority={prioritized.priority:.1f}, "
              f"type={episode.task_type.value})")

    def _update_skill_profile(self, episode: LearningEpisode) -> None:
        """Update skill profile from episode."""
        tracker = get_skill_tracker()

        # Record outcome
        cci_score = None
        if episode.evaluation:
            # Derive CCI score from evaluation
            if episode.evaluation.brain_was_correct:
                cci_score = 0.8 + (episode.brain_attempt.confidence * 0.2)
            else:
                cci_score = 0.2 + (episode.brain_attempt.confidence * 0.3)

        profile = tracker.record_outcome(
            episode.task_type,
            episode.success,
            cci_score
        )

        self._updates.append(LearningUpdate(
            update_type="skill",
            task_type=episode.task_type.value,
            description=f"Updated skill: {profile.level.value} "
                       f"(acc={profile.rolling_accuracy:.2f})",
            episode_id=episode.episode_id,
        ))

    def _update_example_bank(self, episode: LearningEpisode) -> None:
        """Add episode to example bank if appropriate."""
        # Only add successful episodes or failures with corrections
        if not episode.success and not episode.llm_response:
            return

        fusion_engine = get_fusion_engine()

        # Determine ideal output
        if episode.llm_response:
            ideal_output = episode.llm_response.final_answer
        else:
            ideal_output = episode.brain_attempt.draft_output

        if not ideal_output:
            return

        # Get anti-patterns from failure
        anti_patterns = []
        if episode.failure_trace and episode.failure_trace.what_to_avoid:
            anti_patterns = episode.failure_trace.what_to_avoid

        # Get reasoning pattern from blueprint
        reasoning_pattern = ""
        if episode.ideal_blueprint:
            reasoning_pattern = episode.ideal_blueprint.reasoning_pattern

        example = Example(
            input_query=episode.input_query,
            ideal_output=ideal_output,
            reasoning_pattern=reasoning_pattern,
            constraints=episode.brain_attempt.constraints_applied,
            anti_patterns=anti_patterns,
            task_type=episode.task_type,
            success=episode.success,
            metadata={
                "episode_id": episode.episode_id,
                "episode_type": episode.episode_type.value,
                "timestamp": episode.timestamp,
            }
        )

        fusion_engine._example_bank.add_example(example)

        self._updates.append(LearningUpdate(
            update_type="example",
            task_type=episode.task_type.value,
            description=f"Added example: {episode.input_query[:50]}...",
            episode_id=episode.episode_id,
        ))

    def _update_critic_params(self, episode: LearningEpisode) -> None:
        """Update critic parameters based on episode outcome."""
        pipeline = get_self_correction_pipeline()
        critic = pipeline.get_critic()

        # Determine if critic was correct
        brain_confidence = episode.brain_attempt.confidence

        # If brain was confident but wrong, or uncertain but right
        was_confident = brain_confidence > 0.6
        was_correct = episode.success

        # Critic agreement with LLM
        llm_agreed = was_confident == was_correct

        # Update multiple critic types based on failure category
        critic_types_to_update = [CriticType.FORMAT, CriticType.INTENT]

        if episode.evaluation and episode.evaluation.failure_category:
            category = episode.evaluation.failure_category
            if category == FailureCategory.STRUCTURE:
                critic_types_to_update.append(CriticType.SECTIONS)
            elif category == FailureCategory.COHERENCE:
                critic_types_to_update.extend([
                    CriticType.LOGIC,
                    CriticType.CONTRADICTIONS
                ])
            elif category == FailureCategory.CONSTRAINT:
                critic_types_to_update.append(CriticType.LENGTH)
            elif category == FailureCategory.TONE:
                critic_types_to_update.append(CriticType.STYLE)

        for ct in critic_types_to_update:
            critique = Critique(
                critic_type=ct,
                critic_pass=CriticPass.DEEP,
                issue_found=not was_correct,
                confidence=brain_confidence,
            )
            critic.record_validation_outcome(
                critique,
                llm_agreed=llm_agreed,
                error_category=episode.evaluation.failure_category.value
                    if episode.evaluation and episode.evaluation.failure_category
                    else "",
            )

        self._updates.append(LearningUpdate(
            update_type="critic",
            task_type=episode.task_type.value,
            description=f"Updated {len(critic_types_to_update)} critic params",
            episode_id=episode.episode_id,
        ))

    def get_statistics(self) -> Dict[str, Any]:
        """Get daemon statistics."""
        return {
            "is_running": self._thread is not None and self._thread.is_alive(),
            "is_busy": self._is_busy,
            "queue_size": self._queue.qsize(),
            "processed_count": len(self._processed_ids),
            "recent_updates": len(self._updates),
            "updates_by_type": self._count_updates_by_type(),
        }

    def _count_updates_by_type(self) -> Dict[str, int]:
        """Count updates by type."""
        counts: Dict[str, int] = {}
        for update in self._updates[-100:]:  # Last 100 updates
            counts[update.update_type] = counts.get(update.update_type, 0) + 1
        return counts

    def get_recent_updates(self, limit: int = 20) -> List[Dict[str, Any]]:
        """Get recent learning updates."""
        return [
            {
                "update_type": u.update_type,
                "task_type": u.task_type,
                "description": u.description,
                "timestamp": u.timestamp,
                "episode_id": u.episode_id,
            }
            for u in self._updates[-limit:]
        ]

    def load_pending_episodes(self) -> int:
        """
        Load unprocessed episodes from storage.

        Returns:
            Number of episodes loaded
        """
        store = get_episode_store()
        loaded = 0

        # Load recent episodes for each task type
        for task_type in TaskType:
            try:
                episodes = store.query_by_task_type(task_type, limit=20)
                for episode in episodes:
                    if episode.episode_id not in self._processed_ids:
                        self.enqueue(episode)
                        loaded += 1
            except Exception as e:
                print(f"[LEARNING_DAEMON] Load error for {task_type.value}: {e}")

        return loaded


# Global singleton
_daemon: Optional[LearningDaemon] = None


def get_learning_daemon() -> LearningDaemon:
    """Get the global learning daemon instance."""
    global _daemon
    if _daemon is None:
        _daemon = LearningDaemon()
    return _daemon


def start_learning_daemon() -> None:
    """Start the background learning daemon."""
    daemon = get_learning_daemon()
    daemon.start()

    # Load pending episodes
    loaded = daemon.load_pending_episodes()
    print(f"[LEARNING_DAEMON] Loaded {loaded} pending episodes")


def stop_learning_daemon() -> None:
    """Stop the background learning daemon."""
    if _daemon:
        _daemon.stop()


def pause_learning() -> None:
    """Pause learning (during live queries)."""
    if _daemon:
        _daemon.pause()


def resume_learning() -> None:
    """Resume learning (when idle)."""
    if _daemon:
        _daemon.resume()


def enqueue_for_learning(episode: LearningEpisode) -> None:
    """Add an episode to the learning queue."""
    daemon = get_learning_daemon()
    daemon.enqueue(episode)


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for learning daemon.

    Operations:
    - START: Start the daemon
    - STOP: Stop the daemon
    - PAUSE: Pause processing
    - RESUME: Resume processing
    - ENQUEUE: Add episode to queue
    - GET_STATS: Get daemon statistics
    - GET_UPDATES: Get recent updates
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    daemon = get_learning_daemon()

    if op == "START":
        daemon.start()
        loaded = daemon.load_pending_episodes()
        return {
            "ok": True,
            "payload": {"started": True, "loaded_episodes": loaded}
        }

    elif op == "STOP":
        daemon.stop()
        return {"ok": True, "payload": {"stopped": True}}

    elif op == "PAUSE":
        daemon.pause()
        return {"ok": True, "payload": {"paused": True}}

    elif op == "RESUME":
        daemon.resume()
        return {"ok": True, "payload": {"resumed": True}}

    elif op == "ENQUEUE":
        episode_data = payload.get("episode", {})
        from brains.cognitive.learning_contract.episode_storage import (
            LearningEpisode as LE
        )
        episode = LE.from_dict(episode_data)
        daemon.enqueue(episode)
        return {"ok": True, "payload": {"queued": True}}

    elif op == "GET_STATS":
        return {
            "ok": True,
            "payload": daemon.get_statistics()
        }

    elif op == "GET_UPDATES":
        limit = payload.get("limit", 20)
        return {
            "ok": True,
            "payload": {"updates": daemon.get_recent_updates(limit)}
        }

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
