"""
3-Pass Hybrid Critic Pipeline
==============================

Internal self-correction passes that happen BEFORE any LLM involvement.

Pass 1: Shallow Critic
  - Basic constraints (length, counts, format)
  - Obvious factual mismatches
  - Trivial coherence issues

Pass 2: Structural Critic
  - Reasoning structure
  - Logical soundness
  - Required steps/sections present
  - Proper example integration

Pass 3: Deep Critic
  - Deeper logic and contradictions
  - Flow and style
  - Full constraint adherence
  - Task intent alignment

After these 3 passes, the brain has a "best effort" answer with NO LLM used.

The critic module hooks into:
- self_review_brain (primary)
- self_dmn (meta-critic)
- self_introspection

Architecture:
- Primary: Meta-self-trained critic that learns from its own mistakes
- Fallback: Hybrid critic (rules + examples + static weights)
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, Optional, List, Callable, Tuple
from enum import Enum
import time
import json

from brains.cognitive.learning_contract.task_types import (
    TaskType,
    get_task_type_constraints,
)
from brains.cognitive.learning_contract.rule_example_fusion import (
    synthesize_answer,
    FusionResult,
)


class CriticType(Enum):
    """Types of internal critics."""
    # Shallow pass
    FORMAT = "format"               # Format and structure
    LENGTH = "length"               # Length constraints
    BASIC_COHERENCE = "basic_coherence"  # Basic coherence

    # Structural pass
    REASONING = "reasoning"         # Reasoning structure
    LOGIC = "logic"                 # Logical soundness
    SECTIONS = "sections"           # Required sections

    # Deep pass
    CONTRADICTIONS = "contradictions"  # Internal contradictions
    FLOW = "flow"                   # Narrative flow
    STYLE = "style"                 # Style/tone fit
    INTENT = "intent"               # Task intent alignment


class CriticPass(Enum):
    """The three critic passes."""
    SHALLOW = "shallow"
    STRUCTURAL = "structural"
    DEEP = "deep"


@dataclass
class Critique:
    """A single critique from the internal critic."""
    critic_type: CriticType
    critic_pass: CriticPass
    issue_found: bool
    issue_description: str = ""
    suggestion: str = ""
    severity: float = 0.0  # 0.0 = minor, 1.0 = critical
    confidence: float = 0.5  # Critic's confidence in this judgment


@dataclass
class CorrectionPass:
    """Record of a single correction pass."""
    pass_type: CriticPass
    pass_number: int
    input_text: str
    critiques: List[Critique] = field(default_factory=list)
    output_text: str = ""
    changes_made: List[str] = field(default_factory=list)
    duration_ms: float = 0.0


@dataclass
class SelfCorrectionResult:
    """Result of the full 3-pass self-correction pipeline."""
    initial_draft: str
    final_output: str
    passes: List[CorrectionPass] = field(default_factory=list)
    total_issues_found: int = 0
    total_corrections_made: int = 0
    confidence_boost: float = 0.0
    needs_llm: bool = False
    critic_confidence: float = 0.5  # Overall critic confidence


@dataclass
class CriticLearningRecord:
    """Record of critic performance for meta-learning."""
    critique_id: str = ""
    critic_pass: str = ""
    critic_type: str = ""
    was_correct: Optional[bool] = None  # Set after validation
    llm_disagreed: bool = False
    error_category: str = ""
    timestamp: float = 0.0


class ShallowCritic:
    """
    Pass 1: Shallow Critic

    Checks:
    - Basic constraints (length, counts, format)
    - Obvious factual mismatches (wrong color, wrong number)
    - Trivial coherence issues (incomplete sentences, missing punctuation)
    """

    def critique(
        self,
        text: str,
        task_type: TaskType,
        constraints: Dict[str, Any],
    ) -> List[Critique]:
        """Run shallow critique."""
        critiques = []

        # Format check
        format_critique = self._check_format(text, constraints)
        if format_critique.issue_found:
            critiques.append(format_critique)

        # Length check
        length_critique = self._check_length(text, task_type, constraints)
        if length_critique.issue_found:
            critiques.append(length_critique)

        # Basic coherence
        coherence_critique = self._check_basic_coherence(text)
        if coherence_critique.issue_found:
            critiques.append(coherence_critique)

        return critiques

    def _check_format(self, text: str, constraints: Dict[str, Any]) -> Critique:
        """Check basic format requirements."""
        issues = []

        # Check for numbered list if required
        if constraints.get("numbered_steps"):
            if not any(f"{i}." in text or f"{i})" in text for i in range(1, 10)):
                issues.append("Missing numbered steps")

        # Check for bullet points if expected
        if constraints.get("use_bullets"):
            if "-" not in text and "•" not in text:
                issues.append("Missing bullet points")

        # Check for answer_first constraint
        if constraints.get("answer_first"):
            first_sentence = text.split(".")[0] if text else ""
            filler_starts = ["well,", "to understand", "before we", "let me explain"]
            if any(first_sentence.lower().startswith(f) for f in filler_starts):
                issues.append("Answer should come first, not after explanation")

        if issues:
            return Critique(
                critic_type=CriticType.FORMAT,
                critic_pass=CriticPass.SHALLOW,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Fix format to match requirements",
                severity=0.4,
                confidence=0.8,
            )

        return Critique(
            critic_type=CriticType.FORMAT,
            critic_pass=CriticPass.SHALLOW,
            issue_found=False,
            confidence=0.9,
        )

    def _check_length(
        self,
        text: str,
        task_type: TaskType,
        constraints: Dict[str, Any],
    ) -> Critique:
        """Check length constraints."""
        word_count = len(text.split())

        issues = []

        # Check concise constraint
        if constraints.get("concise") and word_count > 150:
            issues.append(f"Too verbose ({word_count} words) for concise answer")

        # Check minimum length for explanations
        if task_type == TaskType.EXPLANATION and word_count < 20:
            issues.append("Explanation too brief")

        # Check length ratio for summaries
        if constraints.get("length_ratio"):
            # Would need original length to check this properly
            pass

        if issues:
            return Critique(
                critic_type=CriticType.LENGTH,
                critic_pass=CriticPass.SHALLOW,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Adjust length to meet constraints",
                severity=0.3,
                confidence=0.85,
            )

        return Critique(
            critic_type=CriticType.LENGTH,
            critic_pass=CriticPass.SHALLOW,
            issue_found=False,
            confidence=0.9,
        )

    def _check_basic_coherence(self, text: str) -> Critique:
        """Check for basic coherence issues."""
        issues = []

        # Check for incomplete sentences
        sentences = [s.strip() for s in text.split(".") if s.strip()]
        for s in sentences:
            # Very short "sentences" that aren't standalone
            if len(s) < 5 and not s.endswith((":", "?")):
                issues.append("Contains fragments or incomplete sentences")
                break

        # Check for missing punctuation at end
        if text.strip() and not text.strip()[-1] in ".?!":
            issues.append("Missing ending punctuation")

        # Check for placeholder text
        placeholders = ["TBD", "TODO", "[...]", "[insert", "[add"]
        for ph in placeholders:
            if ph.lower() in text.lower():
                issues.append(f"Contains placeholder: {ph}")
                break

        if issues:
            return Critique(
                critic_type=CriticType.BASIC_COHERENCE,
                critic_pass=CriticPass.SHALLOW,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Complete sentences and remove placeholders",
                severity=0.5,
                confidence=0.9,
            )

        return Critique(
            critic_type=CriticType.BASIC_COHERENCE,
            critic_pass=CriticPass.SHALLOW,
            issue_found=False,
            confidence=0.85,
        )


class StructuralCritic:
    """
    Pass 2: Structural Critic

    Checks:
    - Reasoning structure (claims backed by evidence)
    - Logical soundness (no invalid inferences)
    - Required steps/sections present
    - Proper integration of examples
    """

    def critique(
        self,
        text: str,
        task_type: TaskType,
        constraints: Dict[str, Any],
    ) -> List[Critique]:
        """Run structural critique."""
        critiques = []

        # Reasoning structure check
        reasoning_critique = self._check_reasoning_structure(text, task_type)
        if reasoning_critique.issue_found:
            critiques.append(reasoning_critique)

        # Logic check
        logic_critique = self._check_logic(text)
        if logic_critique.issue_found:
            critiques.append(logic_critique)

        # Required sections check
        sections_critique = self._check_sections(text, task_type, constraints)
        if sections_critique.issue_found:
            critiques.append(sections_critique)

        return critiques

    def _check_reasoning_structure(
        self,
        text: str,
        task_type: TaskType,
    ) -> Critique:
        """Check if reasoning is properly structured."""
        issues = []
        text_lower = text.lower()

        if task_type == TaskType.REASON_GIVING:
            # Should have claims backed by evidence
            evidence_markers = ["because", "since", "due to", "as shown", "evidence"]
            if not any(m in text_lower for m in evidence_markers):
                issues.append("Reasons given without supporting evidence")

        if task_type == TaskType.EXPLANATION:
            # Should have logical flow
            structure_markers = ["first", "then", "finally", "because", "therefore"]
            if len(text) > 200 and not any(m in text_lower for m in structure_markers):
                issues.append("Explanation lacks clear structure markers")

        if issues:
            return Critique(
                critic_type=CriticType.REASONING,
                critic_pass=CriticPass.STRUCTURAL,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Add supporting evidence and structure",
                severity=0.5,
                confidence=0.7,
            )

        return Critique(
            critic_type=CriticType.REASONING,
            critic_pass=CriticPass.STRUCTURAL,
            issue_found=False,
            confidence=0.75,
        )

    def _check_logic(self, text: str) -> Critique:
        """Check for logical issues."""
        issues = []
        text_lower = text.lower()

        # Check for contradicting connectors
        contradiction_pairs = [
            ("always", "never"),
            ("all", "none"),
            ("definitely", "possibly"),
            ("must", "cannot"),
        ]

        for word1, word2 in contradiction_pairs:
            if word1 in text_lower and word2 in text_lower:
                # Check if they're in the same context (simplified)
                issues.append(f"Potential logical contradiction: '{word1}' and '{word2}'")
                break

        # Check for unsupported absolute claims
        absolute_markers = ["always", "never", "all", "none", "everyone", "nobody"]
        for marker in absolute_markers:
            if marker in text_lower:
                # Check if qualified (simplified)
                if "usually" not in text_lower and "often" not in text_lower:
                    issues.append(f"Unqualified absolute claim: '{marker}'")
                    break

        if issues:
            return Critique(
                critic_type=CriticType.LOGIC,
                critic_pass=CriticPass.STRUCTURAL,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Qualify absolute claims or resolve contradictions",
                severity=0.6,
                confidence=0.65,
            )

        return Critique(
            critic_type=CriticType.LOGIC,
            critic_pass=CriticPass.STRUCTURAL,
            issue_found=False,
            confidence=0.7,
        )

    def _check_sections(
        self,
        text: str,
        task_type: TaskType,
        constraints: Dict[str, Any],
    ) -> Critique:
        """Check if required sections are present."""
        issues = []

        expected_structure = constraints.get("structure", [])
        text_lower = text.lower()

        # Check for expected structural elements
        if "context" in expected_structure:
            if not any(w in text_lower for w in ["context", "background", "to understand"]):
                issues.append("Missing context section")

        if "definition" in expected_structure:
            if not any(w in text_lower for w in ["is defined as", "means", "refers to"]):
                issues.append("Missing definition")

        if "examples" in expected_structure or constraints.get("include_analogies"):
            if not any(w in text_lower for w in ["for example", "such as", "like"]):
                issues.append("Missing examples or analogies")

        if issues:
            return Critique(
                critic_type=CriticType.SECTIONS,
                critic_pass=CriticPass.STRUCTURAL,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Add missing structural elements",
                severity=0.4,
                confidence=0.6,
            )

        return Critique(
            critic_type=CriticType.SECTIONS,
            critic_pass=CriticPass.STRUCTURAL,
            issue_found=False,
            confidence=0.7,
        )


class DeepCritic:
    """
    Pass 3: Deep Critic

    Checks:
    - Deeper logic and contradictions
    - Flow and style
    - Full constraint adherence
    - Task intent alignment
    """

    def __init__(self):
        self._self_review = None
        self._self_dmn = None
        self._init_brain_modules()

    def _init_brain_modules(self) -> None:
        """Initialize connections to brain modules for deep critique."""
        try:
            from brains.cognitive.self_review.service.self_review_brain import service_api
            self._self_review = service_api
        except ImportError:
            pass

        try:
            from brains.cognitive.self_dmn.service.self_dmn_brain import service_api
            self._self_dmn = service_api
        except ImportError:
            pass

    def critique(
        self,
        text: str,
        task_type: TaskType,
        constraints: Dict[str, Any],
        query: str = "",
    ) -> List[Critique]:
        """Run deep critique."""
        critiques = []

        # Contradictions check
        contradictions_critique = self._check_contradictions(text)
        if contradictions_critique.issue_found:
            critiques.append(contradictions_critique)

        # Flow check
        flow_critique = self._check_flow(text)
        if flow_critique.issue_found:
            critiques.append(flow_critique)

        # Style check
        style_critique = self._check_style(text, task_type)
        if style_critique.issue_found:
            critiques.append(style_critique)

        # Intent alignment check
        intent_critique = self._check_intent_alignment(text, query, task_type)
        if intent_critique.issue_found:
            critiques.append(intent_critique)

        # Use self_review if available
        if self._self_review:
            brain_critiques = self._get_brain_critique(text, task_type)
            critiques.extend(brain_critiques)

        return critiques

    def _check_contradictions(self, text: str) -> Critique:
        """Check for internal contradictions."""
        issues = []

        sentences = [s.strip() for s in text.split(".") if s.strip()]

        # Look for sentence pairs that might contradict
        for i, s1 in enumerate(sentences):
            for s2 in sentences[i+1:]:
                # Simplified contradiction detection
                s1_lower = s1.lower()
                s2_lower = s2.lower()

                # Check for "X is Y" then "X is not Y" patterns
                if "is" in s1_lower and "is not" in s2_lower:
                    # Extract subject and check if same
                    words1 = s1_lower.split("is")[0].strip().split()
                    words2 = s2_lower.split("is not")[0].strip().split()
                    if words1 and words2 and words1[-1] == words2[-1]:
                        issues.append("Possible self-contradiction detected")
                        break

        if issues:
            return Critique(
                critic_type=CriticType.CONTRADICTIONS,
                critic_pass=CriticPass.DEEP,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Resolve contradicting statements",
                severity=0.7,
                confidence=0.5,  # Lower confidence for complex detection
            )

        return Critique(
            critic_type=CriticType.CONTRADICTIONS,
            critic_pass=CriticPass.DEEP,
            issue_found=False,
            confidence=0.6,
        )

    def _check_flow(self, text: str) -> Critique:
        """Check narrative flow."""
        issues = []

        sentences = [s.strip() for s in text.split(".") if s.strip()]

        # Check for abrupt topic changes (simplified)
        if len(sentences) >= 3:
            for i in range(len(sentences) - 1):
                s1_words = set(sentences[i].lower().split())
                s2_words = set(sentences[i+1].lower().split())
                # Remove common words
                common = {"the", "a", "an", "is", "are", "was", "were", "to", "of", "and"}
                s1_content = s1_words - common
                s2_content = s2_words - common
                # If no overlap, might be abrupt
                if s1_content and s2_content and not (s1_content & s2_content):
                    issues.append("Potentially abrupt topic transition")
                    break

        # Check for very long run-on sentences
        for s in sentences:
            if len(s.split()) > 60:
                issues.append("Contains very long sentences affecting readability")
                break

        if issues:
            return Critique(
                critic_type=CriticType.FLOW,
                critic_pass=CriticPass.DEEP,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Improve transitions and sentence length",
                severity=0.3,
                confidence=0.5,
            )

        return Critique(
            critic_type=CriticType.FLOW,
            critic_pass=CriticPass.DEEP,
            issue_found=False,
            confidence=0.6,
        )

    def _check_style(self, text: str, task_type: TaskType) -> Critique:
        """Check style/tone appropriateness."""
        issues = []
        text_lower = text.lower()

        # Check for inappropriate casualness in formal contexts
        casual_markers = ["gonna", "wanna", "kinda", "sorta", "lol", "btw"]
        if task_type in (TaskType.EXPLANATION, TaskType.REASON_GIVING):
            for marker in casual_markers:
                if marker in text_lower:
                    issues.append(f"Casual language '{marker}' in formal context")
                    break

        # Check for excessive hedging
        hedge_markers = ["maybe", "possibly", "might", "could be", "perhaps"]
        hedge_count = sum(1 for h in hedge_markers if h in text_lower)
        if hedge_count >= 4:
            issues.append("Excessive hedging reduces authority")

        if issues:
            return Critique(
                critic_type=CriticType.STYLE,
                critic_pass=CriticPass.DEEP,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Adjust tone for context",
                severity=0.2,
                confidence=0.7,
            )

        return Critique(
            critic_type=CriticType.STYLE,
            critic_pass=CriticPass.DEEP,
            issue_found=False,
            confidence=0.75,
        )

    def _check_intent_alignment(
        self,
        text: str,
        query: str,
        task_type: TaskType,
    ) -> Critique:
        """Check if answer aligns with task intent."""
        issues = []

        if not query:
            return Critique(
                critic_type=CriticType.INTENT,
                critic_pass=CriticPass.DEEP,
                issue_found=False,
                confidence=0.5,
            )

        query_lower = query.lower()
        text_lower = text.lower()

        # Extract key entities from query
        query_words = set(query_lower.split()) - {"what", "how", "why", "is", "the", "a", "an"}

        # Check if key query terms appear in answer
        overlap = sum(1 for w in query_words if w in text_lower and len(w) > 3)

        if len(query_words) > 0 and overlap == 0:
            issues.append("Answer may not address the specific question")

        # Task-specific intent checks
        if task_type == TaskType.QA:
            # Should have a direct answer
            if len(text) > 500 and not any(
                text_lower.startswith(s) for s in ["the answer", "yes", "no", "it is"]
            ):
                issues.append("Q&A response doesn't start with direct answer")

        if issues:
            return Critique(
                critic_type=CriticType.INTENT,
                critic_pass=CriticPass.DEEP,
                issue_found=True,
                issue_description="; ".join(issues),
                suggestion="Ensure answer addresses the specific question",
                severity=0.6,
                confidence=0.55,
            )

        return Critique(
            critic_type=CriticType.INTENT,
            critic_pass=CriticPass.DEEP,
            issue_found=False,
            confidence=0.6,
        )

    def _get_brain_critique(
        self,
        text: str,
        task_type: TaskType,
    ) -> List[Critique]:
        """Get critiques from brain modules if available."""
        critiques = []

        if self._self_review:
            try:
                result = self._self_review({
                    "op": "HANDLE_REVIEW",
                    "payload": {
                        "answer": text,
                        "mode": "quick_check",
                    }
                })
                if result.get("ok"):
                    payload = result.get("payload", {})
                    if payload.get("needs_correction"):
                        critiques.append(Critique(
                            critic_type=CriticType.CONTRADICTIONS,
                            critic_pass=CriticPass.DEEP,
                            issue_found=True,
                            issue_description=payload.get("feedback", "Self-review flagged issues"),
                            severity=0.5,
                            confidence=0.7,
                        ))
            except Exception:
                pass

        return critiques


class HybridCritic:
    """
    Combined critic with all three passes.

    Primary: Meta-self-trained critic (learns from mistakes)
    Fallback: Rule-based critic (static patterns)
    """

    def __init__(self):
        self._shallow = ShallowCritic()
        self._structural = StructuralCritic()
        self._deep = DeepCritic()

        # Meta-learning state
        self._learning_records: List[CriticLearningRecord] = []
        self._confidence_adjustments: Dict[str, float] = {}  # Type -> adjustment

    def run_all_passes(
        self,
        text: str,
        task_type: TaskType,
        constraints: Dict[str, Any],
        query: str = "",
    ) -> Tuple[List[Critique], float]:
        """
        Run all three critic passes.

        Returns:
            Tuple of (all critiques, overall confidence)
        """
        all_critiques = []

        # Pass 1: Shallow
        shallow_critiques = self._shallow.critique(text, task_type, constraints)
        all_critiques.extend(shallow_critiques)

        # Pass 2: Structural
        structural_critiques = self._structural.critique(text, task_type, constraints)
        all_critiques.extend(structural_critiques)

        # Pass 3: Deep
        deep_critiques = self._deep.critique(text, task_type, constraints, query)
        all_critiques.extend(deep_critiques)

        # Apply confidence adjustments from learning
        for critique in all_critiques:
            key = critique.critic_type.value
            if key in self._confidence_adjustments:
                critique.confidence *= (1 + self._confidence_adjustments[key])
                critique.confidence = min(1.0, max(0.0, critique.confidence))

        # Calculate overall confidence
        if all_critiques:
            confidences = [c.confidence for c in all_critiques]
            overall_confidence = sum(confidences) / len(confidences)
        else:
            overall_confidence = 0.8

        return all_critiques, overall_confidence

    def record_validation_outcome(
        self,
        critique: Critique,
        llm_agreed: bool,
        error_category: str = "",
    ) -> None:
        """
        Record outcome of LLM validation for meta-learning.

        Called after LLM validates brain's answer.
        """
        record = CriticLearningRecord(
            critique_id=f"{critique.critic_type.value}_{time.time_ns()}",
            critic_pass=critique.critic_pass.value,
            critic_type=critique.critic_type.value,
            was_correct=llm_agreed,
            llm_disagreed=not llm_agreed,
            error_category=error_category,
            timestamp=time.time(),
        )
        self._learning_records.append(record)

        # Adaptive update
        self._update_confidence_adjustment(critique.critic_type.value, llm_agreed)

    def _update_confidence_adjustment(self, critic_type: str, was_correct: bool) -> None:
        """
        Update confidence adjustment for a critic type.

        Implements adaptive learning rate:
        - Low confidence / frequently wrong -> aggressive updates
        - High confidence / accurate -> slow updates
        """
        current = self._confidence_adjustments.get(critic_type, 0.0)

        # Count recent outcomes for this type
        recent = [r for r in self._learning_records[-50:]
                  if r.critic_type == critic_type]
        if not recent:
            accuracy = 0.5
        else:
            accuracy = sum(1 for r in recent if r.was_correct) / len(recent)

        # Adaptive learning rate
        if accuracy < 0.5:
            # Low accuracy -> aggressive updates
            learning_rate = 0.2
        elif accuracy < 0.7:
            # Medium accuracy -> moderate updates
            learning_rate = 0.1
        else:
            # High accuracy -> slow updates
            learning_rate = 0.03

        # Update
        if was_correct:
            self._confidence_adjustments[critic_type] = current + learning_rate * 0.1
        else:
            self._confidence_adjustments[critic_type] = current - learning_rate * 0.2

        # Clamp to reasonable range
        self._confidence_adjustments[critic_type] = max(
            -0.5, min(0.5, self._confidence_adjustments[critic_type])
        )


class SelfCorrectionPipeline:
    """
    3-pass self-correction pipeline.

    Runs internal critiques and corrections before LLM involvement.
    """

    def __init__(self):
        self._critic = HybridCritic()

    def run(
        self,
        query: str,
        task_type: TaskType,
        context: Optional[Dict[str, Any]] = None,
    ) -> SelfCorrectionResult:
        """
        Run the full 3-pass self-correction pipeline.

        Args:
            query: The user's query
            task_type: The classified task type
            context: Optional context

        Returns:
            SelfCorrectionResult with all passes recorded
        """
        # Get constraints for this task type
        constraints = get_task_type_constraints(task_type)

        # Get initial draft from rule + example fusion
        fusion_result = synthesize_answer(query, task_type, context)
        initial_draft = fusion_result.synthesized_answer

        passes = []
        current_text = initial_draft
        total_issues = 0
        total_corrections = 0

        # Run each pass
        for pass_idx, pass_type in enumerate([
            CriticPass.SHALLOW,
            CriticPass.STRUCTURAL,
            CriticPass.DEEP,
        ]):
            start_time = time.time()

            # Get critiques for this pass
            if pass_type == CriticPass.SHALLOW:
                critiques = self._critic._shallow.critique(
                    current_text, task_type, constraints
                )
            elif pass_type == CriticPass.STRUCTURAL:
                critiques = self._critic._structural.critique(
                    current_text, task_type, constraints
                )
            else:  # DEEP
                critiques = self._critic._deep.critique(
                    current_text, task_type, constraints, query
                )

            # Count issues
            issues_in_pass = len([c for c in critiques if c.issue_found])
            total_issues += issues_in_pass

            # Apply corrections
            corrected_text, changes = self._apply_corrections(
                current_text, critiques, pass_type
            )
            total_corrections += len(changes)

            duration_ms = (time.time() - start_time) * 1000

            # Record this pass
            pass_record = CorrectionPass(
                pass_type=pass_type,
                pass_number=pass_idx + 1,
                input_text=current_text,
                critiques=critiques,
                output_text=corrected_text,
                changes_made=changes,
                duration_ms=duration_ms,
            )
            passes.append(pass_record)

            current_text = corrected_text

        # Run final combined critique for confidence
        all_critiques, overall_confidence = self._critic.run_all_passes(
            current_text, task_type, constraints, query
        )

        # Calculate confidence boost
        confidence_boost = 0.0
        if total_corrections > 0:
            confidence_boost = min(0.2, total_corrections * 0.05)

        # Determine if LLM is still needed
        needs_llm = fusion_result.needs_llm

        # If critical issues remain, LLM is needed
        critical_issues = [c for c in all_critiques if c.issue_found and c.severity >= 0.6]
        if critical_issues:
            needs_llm = True

        # If overall confidence is low, LLM is needed
        if overall_confidence < 0.5:
            needs_llm = True

        return SelfCorrectionResult(
            initial_draft=initial_draft,
            final_output=current_text,
            passes=passes,
            total_issues_found=total_issues,
            total_corrections_made=total_corrections,
            confidence_boost=confidence_boost,
            needs_llm=needs_llm,
            critic_confidence=overall_confidence,
        )

    def _apply_corrections(
        self,
        text: str,
        critiques: List[Critique],
        pass_type: CriticPass,
    ) -> Tuple[str, List[str]]:
        """
        Apply corrections based on critiques.

        Returns (corrected_text, list of changes made)
        """
        changes = []
        corrected = text

        for critique in critiques:
            if not critique.issue_found:
                continue

            # Apply corrections based on pass type and critic type
            if pass_type == CriticPass.SHALLOW:
                if critique.critic_type == CriticType.BASIC_COHERENCE:
                    if "Missing ending punctuation" in critique.issue_description:
                        if not corrected.strip().endswith((".", "?", "!")):
                            corrected = corrected.strip() + "."
                            changes.append("Added ending punctuation")

            elif pass_type == CriticPass.STRUCTURAL:
                # Structural corrections would reorder/restructure
                if critique.critic_type == CriticType.SECTIONS:
                    changes.append(f"Flagged: {critique.issue_description}")

            elif pass_type == CriticPass.DEEP:
                # Deep corrections require more complex rewrites
                if critique.critic_type == CriticType.FLOW:
                    changes.append(f"Flagged for flow improvement: {critique.issue_description}")

        return corrected, changes

    def get_critic(self) -> HybridCritic:
        """Get the hybrid critic for learning updates."""
        return self._critic


# Global singleton
_pipeline: Optional[SelfCorrectionPipeline] = None


def get_self_correction_pipeline() -> SelfCorrectionPipeline:
    """Get the global self-correction pipeline instance."""
    global _pipeline
    if _pipeline is None:
        _pipeline = SelfCorrectionPipeline()
    return _pipeline


def run_self_correction(
    query: str,
    task_type: TaskType,
    context: Optional[Dict[str, Any]] = None,
) -> SelfCorrectionResult:
    """
    Convenience function to run self-correction.

    Args:
        query: The user's query
        task_type: The classified task type
        context: Optional context

    Returns:
        SelfCorrectionResult
    """
    return get_self_correction_pipeline().run(query, task_type, context)


# Service API for brain contract compliance
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for self-correction pipeline.

    Operations:
    - RUN: Run the full 3-pass self-correction pipeline
    - CRITIQUE: Run all critics on text
    - RECORD_OUTCOME: Record LLM validation outcome for meta-learning
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})
    pipeline = get_self_correction_pipeline()

    if op == "RUN":
        query = payload.get("query", "")
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        context = payload.get("context")

        result = pipeline.run(query, task_type, context)

        return {
            "ok": True,
            "payload": {
                "initial_draft": result.initial_draft,
                "final_output": result.final_output,
                "passes": [
                    {
                        "pass_type": p.pass_type.value,
                        "pass_number": p.pass_number,
                        "critiques_count": len(p.critiques),
                        "issues_found": len([c for c in p.critiques if c.issue_found]),
                        "changes_made": p.changes_made,
                        "duration_ms": p.duration_ms,
                    }
                    for p in result.passes
                ],
                "total_issues_found": result.total_issues_found,
                "total_corrections_made": result.total_corrections_made,
                "confidence_boost": result.confidence_boost,
                "critic_confidence": result.critic_confidence,
                "needs_llm": result.needs_llm,
            }
        }

    elif op == "CRITIQUE":
        text = payload.get("text", "")
        task_type_str = payload.get("task_type", "unknown")
        try:
            task_type = TaskType(task_type_str)
        except ValueError:
            task_type = TaskType.UNKNOWN
        query = payload.get("query", "")
        constraints = get_task_type_constraints(task_type)

        critiques, confidence = pipeline._critic.run_all_passes(
            text, task_type, constraints, query
        )

        return {
            "ok": True,
            "payload": {
                "critiques": [
                    {
                        "type": c.critic_type.value,
                        "pass": c.critic_pass.value,
                        "issue_found": c.issue_found,
                        "description": c.issue_description,
                        "suggestion": c.suggestion,
                        "severity": c.severity,
                        "confidence": c.confidence,
                    }
                    for c in critiques
                ],
                "total_issues": len([c for c in critiques if c.issue_found]),
                "overall_confidence": confidence,
            }
        }

    elif op == "RECORD_OUTCOME":
        # Record LLM validation outcome for meta-learning
        critic_type = payload.get("critic_type", "")
        llm_agreed = payload.get("llm_agreed", True)
        error_category = payload.get("error_category", "")

        # Create a dummy critique for the record
        try:
            ct = CriticType(critic_type)
        except ValueError:
            ct = CriticType.FORMAT

        critique = Critique(
            critic_type=ct,
            critic_pass=CriticPass.DEEP,
            issue_found=True,
        )

        pipeline.get_critic().record_validation_outcome(
            critique, llm_agreed, error_category
        )

        return {"ok": True, "payload": {"recorded": True}}

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
