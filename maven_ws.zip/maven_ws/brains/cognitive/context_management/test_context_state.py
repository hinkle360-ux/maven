"""
test_context_state.py
~~~~~~~~~~~~~~~~~~~~~

Tests for the ContextState abstraction.

Run with: python -m unittest brains.cognitive.context_management.test_context_state -v
"""

import unittest
from datetime import datetime, timedelta

from brains.cognitive.context_management.context_state import (
    ContextState,
    ConversationTurn,
    WebSearchState,
    WorkingMemoryEntry,
    AttentionFocus,
    ToolExecutionState,
    ContextStateManager,
    get_context,
    get_or_create_context,
    reset_context,
)


class TestConversationTurn(unittest.TestCase):
    """Tests for ConversationTurn dataclass."""

    def test_create_turn(self):
        turn = ConversationTurn(
            turn_id="turn_1",
            query="Hello",
            response="Hi there!",
            topic="greeting",
            entities=["user"],
        )
        self.assertEqual(turn.turn_id, "turn_1")
        self.assertEqual(turn.query, "Hello")
        self.assertEqual(turn.topic, "greeting")

    def test_turn_to_dict(self):
        turn = ConversationTurn(
            turn_id="turn_1",
            query="Hello",
            response="Hi",
            topic="greeting",
            entities=[],
        )
        d = turn.to_dict()
        self.assertIn("turn_id", d)
        self.assertIn("timestamp", d)


class TestWebSearchState(unittest.TestCase):
    """Tests for WebSearchState dataclass."""

    def test_empty_search_not_active(self):
        ws = WebSearchState()
        self.assertFalse(ws.is_active())

    def test_search_with_query_is_active(self):
        ws = WebSearchState(query="test query")
        self.assertTrue(ws.is_active())

    def test_clear_search(self):
        ws = WebSearchState(query="test", engine="bing")
        ws.clear()
        self.assertFalse(ws.is_active())
        self.assertEqual(ws.query, "")
        self.assertEqual(ws.engine, "")


class TestWorkingMemoryEntry(unittest.TestCase):
    """Tests for WorkingMemoryEntry dataclass."""

    def test_entry_without_expiry_not_expired(self):
        entry = WorkingMemoryEntry(key="test", value="value")
        self.assertFalse(entry.is_expired())

    def test_entry_with_future_expiry_not_expired(self):
        future = datetime.now() + timedelta(hours=1)
        entry = WorkingMemoryEntry(key="test", value="value", expires_at=future)
        self.assertFalse(entry.is_expired())

    def test_entry_with_past_expiry_is_expired(self):
        past = datetime.now() - timedelta(hours=1)
        entry = WorkingMemoryEntry(key="test", value="value", expires_at=past)
        self.assertTrue(entry.is_expired())


class TestContextState(unittest.TestCase):
    """Tests for the main ContextState class."""

    def setUp(self):
        self.ctx = ContextState.create()

    def test_create_generates_id(self):
        ctx = ContextState.create()
        self.assertIsNotNone(ctx.conversation_id)
        self.assertEqual(ctx.turn_count, 0)

    def test_record_turn_increments_count(self):
        self.ctx.record_turn(
            query="What time is it?",
            response="It's 3pm",
            topic="time",
        )
        self.assertEqual(self.ctx.turn_count, 1)
        self.assertEqual(self.ctx.last_query, "What time is it?")
        self.assertEqual(self.ctx.last_topic, "time")

    def test_record_multiple_turns(self):
        self.ctx.record_turn(query="q1", response="r1", topic="t1")
        self.ctx.record_turn(query="q2", response="r2", topic="t2")
        self.ctx.record_turn(query="q3", response="r3", topic="t3")

        self.assertEqual(self.ctx.turn_count, 3)
        self.assertEqual(len(self.ctx.recent_turns), 3)
        self.assertEqual(self.ctx.last_query, "q3")

    def test_record_turn_merges_entities(self):
        self.ctx.record_turn(query="q1", response="r1", entities=["A", "B"])
        self.ctx.record_turn(query="q2", response="r2", entities=["B", "C"])

        self.assertEqual(self.ctx.thread_entities, ["A", "B", "C"])

    def test_recent_turns_pruned_to_max(self):
        ctx = ContextState.create()
        ctx.max_recent_turns = 3

        for i in range(5):
            ctx.record_turn(query=f"q{i}", response=f"r{i}")

        self.assertEqual(len(ctx.recent_turns), 3)
        self.assertEqual(ctx.recent_turns[0].query, "q2")

    def test_record_web_search(self):
        self.ctx.record_web_search(
            query="weather in NYC",
            engine="bing",
            results=[{"title": "Weather"}],
            answer="Sunny",
        )

        self.assertTrue(self.ctx.web_search.is_active())
        self.assertEqual(self.ctx.web_search.query, "weather in NYC")
        self.assertEqual(self.ctx.web_search.engine, "bing")

    def test_followup_refers_to_search_generic(self):
        self.ctx.record_web_search(query="AI news", engine="bing", results=[])

        self.assertTrue(self.ctx.followup_refers_to_search("tell me more"))
        self.assertTrue(self.ctx.followup_refers_to_search("what else"))
        self.assertFalse(self.ctx.followup_refers_to_search("what's the weather"))

    def test_followup_refers_to_search_topic_mention(self):
        self.ctx.record_web_search(query="python programming", engine="bing", results=[])

        self.assertTrue(self.ctx.followup_refers_to_search("more about python"))

    def test_clear_web_search(self):
        self.ctx.record_web_search(query="test", engine="bing", results=[])
        self.ctx.clear_web_search()

        self.assertFalse(self.ctx.web_search.is_active())

    def test_add_to_working_memory(self):
        entry = self.ctx.add_to_working_memory(
            key="test_key",
            value={"data": "value"},
            tags=["tag1"],
            confidence=0.9,
        )

        self.assertEqual(entry.key, "test_key")
        self.assertEqual(len(self.ctx.working_memory), 1)

    def test_add_to_working_memory_with_ttl(self):
        entry = self.ctx.add_to_working_memory(
            key="expiring",
            value="data",
            ttl_seconds=3600,
        )

        self.assertIsNotNone(entry.expires_at)
        self.assertFalse(entry.is_expired())

    def test_get_from_working_memory_by_key(self):
        self.ctx.add_to_working_memory(key="k1", value="v1")
        self.ctx.add_to_working_memory(key="k2", value="v2")

        results = self.ctx.get_from_working_memory(key="k1")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].value, "v1")

    def test_get_from_working_memory_by_tag(self):
        self.ctx.add_to_working_memory(key="k1", value="v1", tags=["important"])
        self.ctx.add_to_working_memory(key="k2", value="v2", tags=["normal"])

        results = self.ctx.get_from_working_memory(tag="important")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].key, "k1")

    def test_working_memory_prunes_expired(self):
        past = datetime.now() - timedelta(hours=1)
        self.ctx.working_memory.append(WorkingMemoryEntry(
            key="expired",
            value="old",
            expires_at=past,
        ))
        self.ctx.add_to_working_memory(key="fresh", value="new")

        results = self.ctx.get_from_working_memory()
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].key, "fresh")

    def test_record_attention_shift(self):
        shift = self.ctx.record_attention_shift(
            from_focus="idle",
            to_focus="query_processing",
            reason="user input",
        )

        self.assertEqual(shift.from_focus, "idle")
        self.assertEqual(len(self.ctx.attention_history), 1)

    def test_start_tool_execution(self):
        tool = self.ctx.start_tool_execution(
            tool_name="grok_tool",
            method="parse_and_run",
        )

        self.assertIsNotNone(self.ctx.active_tool)
        self.assertEqual(tool.tool_name, "grok_tool")
        self.assertEqual(tool.status, "running")

    def test_complete_tool_execution(self):
        self.ctx.start_tool_execution(tool_name="grok", method="run")
        completed = self.ctx.complete_tool_execution(status="completed")

        self.assertIsNone(self.ctx.active_tool)
        self.assertEqual(len(self.ctx.recent_tools), 1)
        self.assertEqual(completed.status, "completed")

    def test_to_dict_and_from_dict(self):
        self.ctx.record_turn(query="Hello", response="Hi", topic="greeting")
        self.ctx.record_web_search(query="test", engine="bing", results=[])

        d = self.ctx.to_dict()
        restored = ContextState.from_dict(d)

        self.assertEqual(restored.turn_count, 1)
        self.assertEqual(restored.last_query, "Hello")
        self.assertEqual(restored.web_search.query, "test")

    def test_get_summary(self):
        self.ctx.record_turn(query="Hello", response="Hi")
        self.ctx.record_web_search(query="test", engine="bing", results=[])

        summary = self.ctx.get_summary()
        self.assertEqual(summary["turn_count"], 1)
        self.assertTrue(summary["has_active_search"])


class TestContextStateMigration(unittest.TestCase):
    """Tests for migrating from legacy globals."""

    def test_from_legacy_globals(self):
        conv_state = {
            "last_query": "Hello",
            "last_response": "Hi there",
            "last_topic": "greeting",
            "thread_entities": ["user"],
            "conversation_depth": 5,
        }
        web_search = {
            "query": "weather",
            "engine": "bing",
            "results": [{"title": "Weather"}],
        }
        working_memory = [
            {"key": "fact1", "value": "data", "tags": ["important"]},
        ]
        attention_history = [
            {"from": "idle", "to": "active", "reason": "input"},
        ]

        ctx = ContextState.from_legacy_globals(
            conv_state, web_search, working_memory, attention_history
        )

        self.assertEqual(ctx.last_query, "Hello")
        self.assertEqual(ctx.turn_count, 5)
        self.assertEqual(ctx.web_search.query, "weather")
        self.assertEqual(len(ctx.working_memory), 1)
        self.assertEqual(len(ctx.attention_history), 1)


class TestContextStateManager(unittest.TestCase):
    """Tests for the singleton context manager."""

    def setUp(self):
        # Reset singleton state between tests
        reset_context()

    def test_get_returns_none_initially(self):
        reset_context()
        # After reset, get_context returns the new context, not None
        # Let me check - actually reset() returns the new context
        # So we need to create a fresh manager state

    def test_get_or_create_creates_context(self):
        ctx = get_or_create_context()
        self.assertIsNotNone(ctx)
        self.assertIsInstance(ctx, ContextState)

    def test_get_or_create_returns_same_context(self):
        ctx1 = get_or_create_context()
        ctx2 = get_or_create_context()
        self.assertIs(ctx1, ctx2)

    def test_reset_creates_new_context(self):
        ctx1 = get_or_create_context()
        ctx1.record_turn(query="hello", response="hi")

        ctx2 = reset_context()
        self.assertEqual(ctx2.turn_count, 0)


if __name__ == "__main__":
    unittest.main()
