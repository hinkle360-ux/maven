"""
Fine-Grained Substep Context Injection
======================================

Provides context injection at the substep level within brains.

For true "context alongside every action" behavior, brains can use
this module to emit context events for internal operations, not just
at the stage level.

Design principles:
- Decorator-based injection for minimal code changes
- Context is rebuilt for each substep
- Substep context is written to blackboard for inspection
- No performance penalty if not used
"""

from __future__ import annotations
from typing import Dict, Any, Callable, Optional, List, TYPE_CHECKING
from functools import wraps
import time
import logging

if TYPE_CHECKING:
    from brains.cognitive.context_management.context_bundle import ContextBundle

logger = logging.getLogger(__name__)


class SubstepContextManager:
    """
    Manages context injection at the substep level within brains.

    Allows brains to emit context events for internal operations,
    providing fine-grained context throughout processing.
    """

    def __init__(self, context_mgr, blackboard: Dict[str, Any]):
        """
        Initialize substep context manager.

        Args:
            context_mgr: The main context manager (MavenContextManager)
            blackboard: Reference to the current blackboard
        """
        self.context_mgr = context_mgr
        self.blackboard = blackboard
        self._substep_history: List[Dict[str, Any]] = []

    def with_context(
        self,
        actor: str,
        stage: str,
        task_type: str,
    ) -> Callable:
        """
        Decorator that injects context before a substep function runs.

        Usage:
            @substep_context.with_context(
                actor="planner",
                stage="apply_constraints",
                task_type="planning"
            )
            def _apply_constraints(self, plan, constraints):
                # Context is already in blackboard["substep_context"]
                context = self.blackboard.get("substep_context", {})
                ...

        Args:
            actor: The brain/actor performing this substep
            stage: The substep stage name
            task_type: Type of task

        Returns:
            Decorated function with context injection
        """
        def decorator(func: Callable) -> Callable:
            @wraps(func)
            def wrapper(*args, **kwargs):
                # Extract input for context query
                input_text = self._extract_substep_input(args, kwargs)

                # Build context for this substep
                start_time = time.time()

                try:
                    bundle = self.context_mgr.build_bundle(
                        actor=actor,
                        stage=stage,
                        task_type=task_type,
                        input_text=input_text,
                        constraints=kwargs.get("constraints", {}),
                    )

                    # Update blackboard with substep context
                    self.blackboard["substep_context"] = bundle
                    self.blackboard["substep_actor"] = actor
                    self.blackboard["substep_stage"] = stage

                    # Record in history
                    elapsed_ms = (time.time() - start_time) * 1000
                    self._substep_history.append({
                        "actor": actor,
                        "stage": stage,
                        "task_type": task_type,
                        "input_text": input_text[:100] if input_text else "",
                        "elapsed_ms": elapsed_ms,
                        "bundle_id": bundle.get("bundle_id") if isinstance(bundle, dict) else getattr(bundle, "bundle_id", None),
                    })

                except Exception as e:
                    logger.warning(f"[SUBSTEP_CONTEXT] Failed to build context for {stage}: {e}")

                # Call original function
                return func(*args, **kwargs)

            return wrapper
        return decorator

    def inject_context(
        self,
        actor: str,
        stage: str,
        task_type: str,
        input_text: str,
    ) -> Dict[str, Any]:
        """
        Manually inject context for a substep (non-decorator usage).

        Use this when the decorator approach doesn't fit.

        Args:
            actor: The brain/actor
            stage: The substep stage
            task_type: Type of task
            input_text: Input for context query

        Returns:
            The context bundle dict
        """
        start_time = time.time()

        try:
            bundle = self.context_mgr.build_bundle(
                actor=actor,
                stage=stage,
                task_type=task_type,
                input_text=input_text,
            )

            # Update blackboard
            self.blackboard["substep_context"] = bundle
            self.blackboard["substep_actor"] = actor
            self.blackboard["substep_stage"] = stage

            # Record in history
            elapsed_ms = (time.time() - start_time) * 1000
            self._substep_history.append({
                "actor": actor,
                "stage": stage,
                "task_type": task_type,
                "input_text": input_text[:100] if input_text else "",
                "elapsed_ms": elapsed_ms,
                "bundle_id": bundle.get("bundle_id") if isinstance(bundle, dict) else getattr(bundle, "bundle_id", None),
            })

            return bundle

        except Exception as e:
            logger.warning(f"[SUBSTEP_CONTEXT] Failed to build context: {e}")
            return {}

    def get_substep_context(self) -> Optional[Dict[str, Any]]:
        """Get the current substep context from blackboard."""
        return self.blackboard.get("substep_context")

    def get_substep_history(self) -> List[Dict[str, Any]]:
        """Get history of substep context injections."""
        return self._substep_history.copy()

    def clear_substep_context(self) -> None:
        """Clear substep context from blackboard."""
        self.blackboard.pop("substep_context", None)
        self.blackboard.pop("substep_actor", None)
        self.blackboard.pop("substep_stage", None)

    def _extract_substep_input(self, args, kwargs) -> str:
        """
        Extract meaningful input from function args for context query.

        Tries to find a string argument that looks like input text.
        """
        # Check kwargs for common input names
        for key in ["query", "text", "input", "input_text", "content"]:
            if key in kwargs and isinstance(kwargs[key], str):
                return kwargs[key]

        # Check positional args for strings
        for arg in args:
            if isinstance(arg, str) and len(arg) > 0:
                return arg

        # Check kwargs values for any string
        for value in kwargs.values():
            if isinstance(value, str) and len(value) > 10:
                return value

        return ""


# =============================================================================
# CONTEXT-INJECTED BRAIN MIXIN
# =============================================================================

class SubstepContextMixin:
    """
    Mixin class that adds substep context capabilities to brains.

    Usage:
        class PlannerBrain(ContextAwareBrain, SubstepContextMixin):
            def _execute_with_context(self, query, bundle, blackboard):
                # Initialize substep context
                self.init_substep_context(blackboard)

                # Use substep context
                with self.substep_context("apply_constraints", "planning"):
                    self._apply_constraints(plan, constraints)
    """

    _substep_manager: Optional[SubstepContextManager] = None

    def init_substep_context(self, blackboard: Dict[str, Any]) -> None:
        """
        Initialize substep context manager for this brain.

        Args:
            blackboard: The current blackboard
        """
        from brains.cognitive.context_management.service.context_manager import (
            get_maven_context_manager
        )
        self._substep_manager = SubstepContextManager(
            context_mgr=get_maven_context_manager(),
            blackboard=blackboard,
        )

    def substep_context(
        self,
        stage: str,
        task_type: str,
        input_text: str = "",
    ) -> "SubstepContextGuard":
        """
        Context manager for substep context injection.

        Usage:
            with self.substep_context("validate", "validation"):
                # Context is injected for this block
                ...
        """
        if not self._substep_manager:
            raise RuntimeError("Substep context not initialized. Call init_substep_context first.")

        return SubstepContextGuard(
            manager=self._substep_manager,
            actor=getattr(self, "brain_name", "unknown"),
            stage=stage,
            task_type=task_type,
            input_text=input_text,
        )


class SubstepContextGuard:
    """
    Context manager guard for substep context injection.

    Ensures context is injected on entry and optionally cleaned up on exit.
    """

    def __init__(
        self,
        manager: SubstepContextManager,
        actor: str,
        stage: str,
        task_type: str,
        input_text: str = "",
    ):
        self.manager = manager
        self.actor = actor
        self.stage = stage
        self.task_type = task_type
        self.input_text = input_text
        self._bundle: Optional[Dict[str, Any]] = None

    def __enter__(self) -> Dict[str, Any]:
        """Inject context on entry."""
        self._bundle = self.manager.inject_context(
            actor=self.actor,
            stage=self.stage,
            task_type=self.task_type,
            input_text=self.input_text,
        )
        return self._bundle

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Clean up on exit (optional)."""
        # Don't clear - let the main context remain for inspection
        pass
