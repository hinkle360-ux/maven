"""
Context Bundle System
======================

Implements the ContextEvent → ContextBundle flow for task-aware context retrieval.

This module is the "global, always-on, task-aware context oracle" that:
1. Receives ContextEvents from pipeline stages
2. Builds task-aware memory query plans
3. Scores candidates using domain, role, similarity, recency, and corrections
4. Writes ContextBundles to the blackboard for downstream brains

Design principles:
- No new brains - just upgrades and wiring
- Uses existing memory_librarian, domain_banks, and pattern stores
- Task-aware ranking prevents "2+2 = four ducks" errors
- Output lives in the blackboard - brains consume bundles, not raw memory
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Set, Tuple
from enum import Enum
import time
import uuid
import re


# =============================================================================
# ENUMS AND CONSTANTS
# =============================================================================

class Actor(Enum):
    """Which brain/tool is acting."""
    INTEGRATOR = "integrator"
    PLANNER = "planner"
    REASONING = "reasoning"
    CODER = "coder"
    REPAIR_ENGINE = "repair_engine"
    RESEARCH_MANAGER = "research_manager"
    LANGUAGE = "language"
    SELF_MODEL = "self_model"
    GOVERNANCE = "governance"
    TOOL_EXECUTOR = "tool_executor"


class Stage(Enum):
    """Pipeline phase or high-level step."""
    ROUTING_DECISION = "routing_decision"
    QUERY_ANSWER = "query_answer"
    PLAN_GENERATION = "plan_generation"
    CODE_EDIT = "code_edit"
    TOOL_CALL = "tool_call"
    SELF_REPAIR = "self_repair"
    VALIDATION = "validation"
    GENERATION = "generation"


class TaskType(Enum):
    """Task type from routing / response_planner / reasoning."""
    MATH_QUESTION = "math_question"
    CODE_FIX = "code_fix"
    CODE_GENERATION = "code_generation"
    RESEARCH_QUESTION = "research_question"
    SELF_MODEL_QUERY = "self_model_query"
    SAFETY_DECISION = "safety_decision"
    SMALL_TALK = "small_talk"
    SUMMARIZATION = "summarization"
    EXPLANATION = "explanation"
    FEEDBACK = "feedback"
    SYSTEM_CONTROL = "system_control"
    ROUTING = "routing"
    PERSONAL_QUERY = "personal_query"  # User facts: name, location, preferences
    UNKNOWN = "unknown"


class ContextSource(Enum):
    """Source of context items."""
    EPISODIC_MEMORY = "episodic_memory"
    VECTOR_INDEX = "vector_index"
    DOMAIN_BANK_MATH = "domain_bank.math"
    DOMAIN_BANK_SCIENCE = "domain_bank.science"
    DOMAIN_BANK_TECHNOLOGY = "domain_bank.technology"
    DOMAIN_BANK_HISTORY = "domain_bank.history"
    DOMAIN_BANK_FACTUAL = "domain_bank.factual"
    DOMAIN_BANK_PROCEDURAL = "domain_bank.procedural"
    DOMAIN_BANK_PERSONAL = "domain_bank.personal"  # User personal facts
    PROJECT_CHECKPOINT = "project_checkpoint"
    GOAL_MEMORY = "goal_memory"
    ROUTING_PATTERNS = "routing_patterns"
    TEACHER_CONTRACTS = "teacher_contracts"
    USER_PREFERENCES = "user_preferences"
    USER_CORRECTIONS = "user_corrections"
    TEST_RESULTS = "test_results"
    PERSONAL_BANK = "personal_bank"  # Primary source for user identity
    SESSION_CONTEXT = "session_context"  # Persistent per-session context


class ContextTag(Enum):
    """Tags for context items."""
    PAST_ANSWER = "past_answer"
    PAST_QUESTION = "past_question"
    RULE = "rule"
    NARRATIVE_EXAMPLE = "narrative_example"
    ERROR_LOG = "error_log"
    TEST_RESULT = "test_result"
    USER_PREFERENCE = "user_preference"
    USER_CORRECTION = "user_correction"
    MATH_RULE = "math_rule"
    CODE_PATTERN = "code_pattern"
    PROJECT_STATE = "project_state"
    ROUTING_MISTAKE = "routing_mistake"
    WORKING_THEORY = "working_theory"
    PERSONAL_FACT = "personal_fact"  # User identity: name, location, etc.
    SESSION_PERSISTENT = "session_persistent"  # Facts that persist across queries


# =============================================================================
# PERSONAL QUERY DETECTION
# =============================================================================

# Patterns that indicate a personal query about the user
PERSONAL_QUERY_PATTERNS = [
    r"what\s+(is|are)\s+(my|our|user)",           # "what is my name"
    r"(do|did|have)\s+(i|we|user)",               # "do I have..."
    r"(who|where|when)\s+(am|is|are)\s+(i|we)",   # "who am I"
    r"tell\s+me\s+about\s+(me|myself|my)",        # "tell me about myself"
    r"^my\s+\w+\s*(is|\?)",                       # "my name?" or "my name is"
    r"(remember|recall)\s+(my|what\s+I)",         # "remember my name"
    r"you\s+know\s+(my|who\s+I)",                 # "do you know my name"
    r"what\s+did\s+I\s+(say|tell)",               # "what did I say"
    r"(call|called)\s+me",                         # "what should you call me"
]


def is_personal_query(query: str) -> bool:
    """
    Detect if a query is asking about personal/user information.

    This triggers special handling:
    1. Force personal memory lookup BEFORE routing
    2. Use personal_query task type
    3. Emit diagnostic if no personal facts found

    Args:
        query: The user's query

    Returns:
        True if this is a personal query about the user
    """
    if not query:
        return False

    query_lower = query.lower().strip()

    # Check against patterns
    for pattern in PERSONAL_QUERY_PATTERNS:
        if re.search(pattern, query_lower):
            return True

    # Also check for specific keywords in short queries
    if len(query_lower.split()) <= 5:
        personal_keywords = ["my name", "my location", "who am i", "about me"]
        if any(kw in query_lower for kw in personal_keywords):
            return True

    return False


def detect_task_type(query: str) -> str:
    """
    Detect the task type from the query.

    This is a helper for routing that determines the task type
    before building context bundles.

    Args:
        query: The user's query

    Returns:
        Task type string (e.g., "personal_query", "math_question")
    """
    if is_personal_query(query):
        return "personal_query"

    query_lower = query.lower().strip()

    # Math patterns
    if re.search(r"\d+\s*[\+\-\*/]\s*\d+", query_lower):
        return "math_question"
    if any(w in query_lower for w in ["calculate", "sum of", "multiply", "divide"]):
        return "math_question"

    # Code patterns
    if any(w in query_lower for w in ["fix bug", "error in", "code", "function", "class"]):
        return "code_fix"

    # Research patterns
    if query_lower.startswith(("what is", "how does", "explain", "why")):
        return "research_question"

    return "unknown"


# =============================================================================
# DATA CLASSES
# =============================================================================

@dataclass
class ContextEvent:
    """
    Event emitted by pipeline stages to request context retrieval.

    Handled by context_management to build ContextBundles.
    """
    actor: str  # Which brain/tool is acting
    stage: str  # Pipeline phase or high-level step
    task_type: str  # From routing / response_planner / reasoning
    input_text: str  # Normalized content this step is working on
    goal_hint: str = ""  # Current user/system goal ID or description
    constraints: Dict[str, Any] = field(default_factory=dict)  # Governance/teacher decisions
    blackboard: Optional[Dict[str, Any]] = None  # Reference to current blackboard
    timestamp: float = field(default_factory=time.time)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "actor": self.actor,
            "stage": self.stage,
            "task_type": self.task_type,
            "input_text": self.input_text[:200] if self.input_text else "",
            "goal_hint": self.goal_hint,
            "constraints": self.constraints,
            "timestamp": self.timestamp,
        }


@dataclass
class ContextItem:
    """
    A single context item retrieved from memory/domain banks.
    """
    source: str  # e.g. episodic_memory, domain_bank.math
    payload: Any  # Reference / snippet / pointer
    score: float  # 0-1 combined score
    tags: List[str]  # e.g. math_rule, past_answer
    why: str  # Short explanation
    raw_scores: Dict[str, float] = field(default_factory=dict)  # Component scores

    def to_dict(self) -> Dict[str, Any]:
        return {
            "source": self.source,
            "payload": str(self.payload)[:500] if self.payload else "",
            "score": round(self.score, 3),
            "tags": self.tags,
            "why": self.why,
        }


@dataclass
class AnswerCandidate:
    """
    Explicit answer hypothesis from context system.

    For tasks with a clear answer (math, personal queries, fact lookups),
    the context system nominates its best guess BEFORE reasoning runs.
    This prevents LLM hallucination by providing a pre-validated answer.
    """
    value: Any  # The actual answer (e.g., "4", "Alice", "addition rule")
    confidence: float  # 0.0 to 1.0
    source: str  # Where it came from (e.g., "domain_bank.math", "personal_bank")
    source_item: Optional[ContextItem]  # Full item that generated this candidate
    why: str  # Explanation: "highest scoring math rule"
    extraction_method: str  # How value was extracted: "key_value_parse", "rule_extraction"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "value": self.value,
            "confidence": self.confidence,
            "source": self.source,
            "why": self.why,
            "extraction_method": self.extraction_method,
        }


@dataclass
class ConversationThread:
    """
    Conversation threading context (FIX 3).

    Provides pattern and exchange history for context-aware responses.
    This enables proper small talk handling - "how are you" after "hi"
    should get casual continuation, not a verbose explanation.
    """
    conversation_pattern: str  # e.g., "small_talk_thread", "question_answer", "multi_turn"
    last_exchange: str  # e.g., "hi → Hi back at ya!"
    expected_response_type: str  # e.g., "brief_casual", "detailed_answer", "followup"
    turn_count: int = 0  # Number of turns in this thread
    thread_topic: str = ""  # What the thread is about (if any)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "conversation_pattern": self.conversation_pattern,
            "last_exchange": self.last_exchange,
            "expected_response_type": self.expected_response_type,
            "turn_count": self.turn_count,
            "thread_topic": self.thread_topic,
        }


@dataclass
class ContextBundle:
    """
    What context_management writes to blackboard.

    Contains ranked context items for the current pipeline step,
    and optionally an answer candidate for direct-answer tasks.
    """
    bundle_id: str
    actor: str
    stage: str
    task_type: str
    top_context: List[ContextItem]  # 3-10 highest scoring items
    supporting_context: List[ContextItem]  # 10-20 additional items
    answer_candidate: Optional[AnswerCandidate] = None  # Explicit answer hypothesis
    conversation_thread: Optional[ConversationThread] = None  # Conversation threading (FIX 3)
    query_plan: Dict[str, Any] = field(default_factory=dict)  # How we queried
    total_candidates: int = 0
    build_time_ms: float = 0.0
    timestamp: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "bundle_id": self.bundle_id,
            "actor": self.actor,
            "stage": self.stage,
            "task_type": self.task_type,
            "top_context": [item.to_dict() for item in self.top_context],
            "supporting_context": [item.to_dict() for item in self.supporting_context],
            "query_plan": self.query_plan,
            "total_candidates": self.total_candidates,
            "build_time_ms": round(self.build_time_ms, 2),
        }
        if self.answer_candidate:
            result["answer_candidate"] = self.answer_candidate.to_dict()
        if self.conversation_thread:
            result["conversation_thread"] = self.conversation_thread.to_dict()
        return result

    def has_answer_candidate(self) -> bool:
        """Check if bundle contains an answer candidate."""
        return self.answer_candidate is not None

    def has_conversation_thread(self) -> bool:
        """Check if bundle contains conversation threading info."""
        return self.conversation_thread is not None

    def get_expected_response_type(self) -> str:
        """Get expected response type from conversation thread."""
        if self.conversation_thread:
            return self.conversation_thread.expected_response_type
        return "detailed_answer"  # Default

    def get_top_items(self, n: int = 5) -> List[ContextItem]:
        """Get top N context items by score."""
        return self.top_context[:n]

    def get_items_by_tag(self, tag: str) -> List[ContextItem]:
        """Get all items with a specific tag."""
        return [
            item for item in (self.top_context + self.supporting_context)
            if tag in item.tags
        ]

    def get_items_by_source(self, source: str) -> List[ContextItem]:
        """Get all items from a specific source."""
        return [
            item for item in (self.top_context + self.supporting_context)
            if source in item.source
        ]

    def get_critical_items(self) -> List[ContextItem]:
        """Get items that MUST be used in reasoning."""
        critical = []
        for item in self.top_context:
            # Personal facts are always critical
            if "personal_fact" in item.tags:
                critical.append(item)
            # User corrections are critical
            elif "user_correction" in item.tags:
                critical.append(item)
            # High-scoring rules are critical
            elif any(t in item.tags for t in ["rule", "math_rule"]) and item.score > 0.7:
                critical.append(item)
        return critical


# =============================================================================
# QUERY PLAN BUILDER
# =============================================================================

# Domain mapping for task types
TASK_TYPE_DOMAINS: Dict[str, List[str]] = {
    "math_question": ["math", "science"],
    "code_fix": ["technology", "procedural"],
    "code_generation": ["technology", "procedural"],
    "research_question": ["factual", "science", "history"],
    "self_model_query": ["self_model"],
    "safety_decision": ["governance", "safety"],
    "small_talk": ["personal"],
    "summarization": ["language_arts"],
    "explanation": ["factual", "science", "technology"],
    "feedback": ["personal", "corrections"],
    "system_control": ["technology", "procedural"],
    "routing": ["routing"],
    "personal_query": ["personal"],  # User facts only
}

# Sources to query for each task type
TASK_TYPE_SOURCES: Dict[str, List[str]] = {
    "math_question": [
        "domain_bank.math",
        "episodic_memory",
        "vector_index",
        "teacher_contracts",
    ],
    "code_fix": [
        "project_checkpoint",
        "goal_memory",
        "episodic_memory",
        "test_results",
        "teacher_contracts",
    ],
    "code_generation": [
        "domain_bank.technology",
        "project_checkpoint",
        "episodic_memory",
        "teacher_contracts",
    ],
    "research_question": [
        "domain_bank.factual",
        "domain_bank.science",
        "vector_index",
        "episodic_memory",
    ],
    "self_model_query": [
        "episodic_memory",
        "user_preferences",
    ],
    "safety_decision": [
        "teacher_contracts",
        "user_corrections",
        "episodic_memory",
    ],
    "small_talk": [
        "episodic_memory",
        "user_preferences",
    ],
    "summarization": [
        "episodic_memory",
    ],
    "explanation": [
        "domain_bank.factual",
        "domain_bank.science",
        "vector_index",
        "episodic_memory",
    ],
    "feedback": [
        "user_corrections",
        "episodic_memory",
    ],
    "system_control": [
        "project_checkpoint",
        "episodic_memory",
    ],
    "routing": [
        "routing_patterns",
        "user_corrections",
        "episodic_memory",
    ],
    "personal_query": [
        "personal_bank",           # Primary: user identity facts
        "session_context",         # Persistent session context
        "domain_bank.personal",    # Personal domain bank
        "user_preferences",        # User settings/style
        "episodic_memory",         # Recent conversations (lower priority)
    ],
}


def build_query_plan(event: ContextEvent) -> Dict[str, Any]:
    """
    Build a memory query plan based on the ContextEvent.

    This is a deterministic mapping, not an LLM call.

    Returns:
        Dict with domain, query_text, filters, target_sources
    """
    task_type = event.task_type.lower()

    # Get domains for this task type
    domains = TASK_TYPE_DOMAINS.get(task_type, ["factual"])

    # Get sources to query
    sources = TASK_TYPE_SOURCES.get(task_type, ["episodic_memory", "vector_index"])

    # Extract key terms from input
    query_text = event.input_text or ""
    key_terms = _extract_key_terms(query_text, task_type)

    # Build filters based on constraints and context
    filters: Dict[str, Any] = {}

    if event.constraints:
        # Respect governance constraints
        if event.constraints.get("no_teacher"):
            filters["exclude_teacher_content"] = True
        if event.constraints.get("no_web"):
            filters["exclude_web_content"] = True
        if event.constraints.get("project_id"):
            filters["project_id"] = event.constraints["project_id"]

    # Add recency filter for certain task types
    if task_type in ("code_fix", "system_control", "feedback"):
        filters["prefer_recent"] = True
        filters["max_age_hours"] = 24

    return {
        "domains": domains,
        "query_text": query_text,
        "key_terms": key_terms,
        "sources": sources,
        "filters": filters,
        "task_type": task_type,
        "actor": event.actor,
        "stage": event.stage,
    }


def _extract_key_terms(text: str, task_type: str) -> List[str]:
    """Extract key terms from query text based on task type."""
    if not text:
        return []

    terms = []
    text_lower = text.lower()

    # Math: extract numbers, operators, math terms
    if task_type == "math_question":
        # Find numbers
        numbers = re.findall(r'\d+(?:\.\d+)?', text)
        terms.extend(numbers)
        # Find math operations
        if any(op in text_lower for op in ['+', '-', '*', '/', 'plus', 'minus', 'times', 'divided']):
            terms.append("arithmetic")
        if any(w in text_lower for w in ['equation', 'solve', 'calculate']):
            terms.append("calculation")

    # Code: extract function names, file paths, error codes
    elif task_type in ("code_fix", "code_generation"):
        # File paths
        paths = re.findall(r'[\w/\\]+\.\w+', text)
        terms.extend(paths)
        # Function names (camelCase or snake_case)
        funcs = re.findall(r'\b[a-z]+(?:_[a-z]+)+\b|\b[a-z]+(?:[A-Z][a-z]+)+\b', text)
        terms.extend(funcs)
        # Error codes
        errors = re.findall(r'Error|Exception|Failed|error', text)
        terms.extend(errors)

    # Research: extract topic nouns
    elif task_type in ("research_question", "explanation"):
        # Remove common words and extract nouns
        stop_words = {'what', 'is', 'the', 'a', 'an', 'how', 'does', 'why', 'when', 'where', 'can', 'you'}
        words = re.findall(r'\b[a-zA-Z]{3,}\b', text_lower)
        terms.extend([w for w in words if w not in stop_words][:5])

    return terms[:10]  # Limit to 10 key terms


# =============================================================================
# SCORING MODEL
# =============================================================================

# Scoring weights (can be tuned via config)
SCORING_WEIGHTS = {
    "domain": 0.25,      # Domain compatibility
    "role": 0.20,        # Role/type match
    "similarity": 0.20,  # Semantic similarity
    "recency": 0.15,     # Recency / project relevance
    "correction": 0.15,  # Explicit user corrections
    "safety": 0.05,      # Governance alignment
}

# Priority multipliers by role - personal facts ALWAYS win
# This prevents "four ducks" and ensures "What is my name?" works
ROLE_PRIORITY_MULTIPLIERS = {
    "personal_fact": 10.0,        # User's name, location - HIGHEST
    "user_correction": 8.0,       # User said "that's wrong"
    "governance_rule": 7.0,       # Ethics/safety rules
    "rule": 5.0,                  # Domain rules (math, code)
    "math_rule": 5.0,             # Math rules
    "code_pattern": 4.0,          # Code patterns
    "past_answer": 3.0,           # Previous Q/A
    "working_theory": 2.5,        # Working theories
    "error_log": 2.0,             # Error logs
    "test_result": 2.0,           # Test results
    "user_preference": 1.5,       # Preferences (lower than facts)
    "past_question": 1.0,         # Past questions
    "narrative_example": 0.5,     # Stories - LOWEST
}

# Domain scores: which domains are relevant for which task types
DOMAIN_RELEVANCE: Dict[str, Dict[str, float]] = {
    "math_question": {
        "math": 1.0,
        "science": 0.6,
        "factual": 0.3,
        "narrative": 0.0,  # Explicitly low
        "history": 0.1,
    },
    "code_fix": {
        "technology": 1.0,
        "procedural": 0.9,
        "math": 0.3,
        "narrative": 0.0,
    },
    "research_question": {
        "factual": 1.0,
        "science": 0.9,
        "history": 0.8,
        "technology": 0.6,
        "narrative": 0.3,
    },
    "explanation": {
        "factual": 1.0,
        "science": 0.9,
        "technology": 0.7,
        "procedural": 0.6,
        "narrative": 0.2,
    },
    "personal_query": {
        "personal": 1.0,          # Personal domain is THE answer
        "factual": 0.1,           # Generic facts are irrelevant
        "narrative": 0.0,         # Stories are never relevant
        "math": 0.0,
        "technology": 0.0,
    },
}

# Role scores: which roles are relevant for which task types
ROLE_RELEVANCE: Dict[str, Dict[str, float]] = {
    "math_question": {
        "rule": 1.0,
        "past_answer": 0.9,
        "working_theory": 0.7,
        "past_question": 0.5,
        "narrative_example": 0.1,  # Explicitly low - the "four ducks" case
    },
    "code_fix": {
        "code_pattern": 1.0,
        "error_log": 0.9,
        "test_result": 0.8,
        "past_answer": 0.7,
        "project_state": 0.6,
    },
    "research_question": {
        "past_answer": 1.0,
        "rule": 0.8,
        "working_theory": 0.7,
        "narrative_example": 0.5,  # OK for research
    },
    "routing": {
        "user_correction": 1.0,
        "routing_mistake": 0.9,
        "past_answer": 0.5,
    },
    "personal_query": {
        "personal_fact": 1.0,       # User's name, location - HIGHEST
        "user_preference": 0.8,     # User preferences
        "past_answer": 0.3,         # Previous answers about user
        "rule": 0.1,                # Rules are not relevant
        "narrative_example": 0.0,   # Stories NEVER relevant
    },
}


def score_candidate(
    candidate: Dict[str, Any],
    query_plan: Dict[str, Any],
    query_embedding: Optional[List[float]] = None,
) -> Tuple[float, Dict[str, float]]:
    """
    Score a memory candidate using the multi-factor scoring model.

    Args:
        candidate: Memory record with content, metadata, tags
        query_plan: The query plan from build_query_plan
        query_embedding: Optional embedding for semantic similarity

    Returns:
        Tuple of (final_score, component_scores)
    """
    task_type = query_plan.get("task_type", "unknown")
    key_terms = query_plan.get("key_terms", [])

    # Extract candidate info
    content = str(candidate.get("content", "")).lower()
    metadata = candidate.get("metadata", {}) or {}
    tags = candidate.get("tags", []) or metadata.get("tags", [])
    source = candidate.get("source", metadata.get("source", ""))
    timestamp = candidate.get("timestamp", 0)

    # Infer domain and role from source/tags
    inferred_domain = _infer_domain(source, tags, content)
    inferred_role = _infer_role(tags, metadata)

    # Calculate component scores
    scores: Dict[str, float] = {}

    # 1. Domain score
    domain_map = DOMAIN_RELEVANCE.get(task_type, {})
    scores["domain"] = domain_map.get(inferred_domain, 0.3)

    # 2. Role score
    role_map = ROLE_RELEVANCE.get(task_type, {})
    scores["role"] = role_map.get(inferred_role, 0.3)

    # 3. Similarity score (term overlap + semantic if available)
    term_matches = sum(1 for term in key_terms if term.lower() in content)
    scores["similarity"] = min(1.0, term_matches / max(len(key_terms), 1) * 0.7 + 0.3)

    # 4. Recency score
    if timestamp > 0:
        age_hours = (time.time() - timestamp) / 3600
        scores["recency"] = max(0.1, 1.0 - (age_hours / 168))  # Decay over 1 week
    else:
        scores["recency"] = 0.3

    # 5. Correction score (user explicitly corrected something)
    if "user_correction" in tags or metadata.get("is_correction"):
        scores["correction"] = 1.0
    elif "user_preference" in tags:
        scores["correction"] = 0.7
    else:
        scores["correction"] = 0.3

    # 6. Safety score
    if metadata.get("governance_blocked"):
        scores["safety"] = 0.0
    else:
        scores["safety"] = 1.0

    # Calculate weighted final score
    base_score = sum(
        scores[key] * SCORING_WEIGHTS[key]
        for key in SCORING_WEIGHTS
    )

    # Apply priority multiplier based on role
    # This ensures personal_fact ALWAYS wins over narrative_example
    priority_multiplier = ROLE_PRIORITY_MULTIPLIERS.get(inferred_role, 1.0)

    # Normalize multiplier to keep scores in reasonable range (0-1)
    # We use log scaling to prevent extreme values
    if priority_multiplier > 1.0:
        final_score = base_score * (1.0 + (priority_multiplier - 1.0) * 0.1)
    else:
        final_score = base_score * priority_multiplier

    # Clamp to [0, 1]
    final_score = max(0.0, min(1.0, final_score))

    # Add priority info to scores for debugging
    scores["priority_multiplier"] = priority_multiplier
    scores["base_score"] = base_score

    return final_score, scores


def _infer_domain(source: str, tags: List[str], content: str) -> str:
    """Infer the domain from source, tags, and content."""
    source_lower = source.lower()
    tag_str = " ".join(str(t) for t in tags).lower()

    # PERSONAL domain has highest priority - check first
    if "personal" in source_lower or "personal_bank" in source_lower:
        return "personal"
    if "personal_fact" in tag_str or "user_identity" in tag_str:
        return "personal"

    # Check source for other domains
    if "math" in source_lower:
        return "math"
    if "science" in source_lower:
        return "science"
    if "technology" in source_lower or "code" in source_lower:
        return "technology"
    if "history" in source_lower:
        return "history"
    if "factual" in source_lower:
        return "factual"
    if "procedural" in source_lower:
        return "procedural"

    # Check tags
    if "math" in tag_str or "arithmetic" in tag_str:
        return "math"
    if "code" in tag_str or "programming" in tag_str:
        return "technology"

    # Check content for domain hints
    content_lower = content.lower()
    if any(w in content_lower for w in ["equation", "calculate", "sum", "multiply"]):
        return "math"
    if any(w in content_lower for w in ["function", "class", "variable", "error"]):
        return "technology"
    if any(w in content_lower for w in ["story", "once upon", "narrative"]):
        return "narrative"

    return "factual"  # Default


def _infer_role(tags: List[str], metadata: Dict[str, Any]) -> str:
    """Infer the role from tags and metadata."""
    tag_set = {str(t).lower() for t in (tags or [])}

    # PERSONAL_FACT has highest priority - check first
    if "personal_fact" in tag_set or "user_identity" in tag_set:
        return "personal_fact"
    if metadata.get("is_personal_fact") or metadata.get("fact_type") == "personal":
        return "personal_fact"

    # User corrections have second highest priority
    if "correction" in tag_set or "user_correction" in tag_set:
        return "user_correction"

    if "rule" in tag_set or "math_rule" in tag_set:
        return "rule"
    if "past_answer" in tag_set or metadata.get("type") == "answer":
        return "past_answer"
    if "past_question" in tag_set or metadata.get("type") == "question":
        return "past_question"
    if "narrative_example" in tag_set or "story" in tag_set:
        return "narrative_example"
    if "error" in tag_set or "error_log" in tag_set:
        return "error_log"
    if "test" in tag_set or "test_result" in tag_set:
        return "test_result"
    if "routing" in tag_set or "routing_mistake" in tag_set:
        return "routing_mistake"
    if "working_theory" in tag_set:
        return "working_theory"
    if "code" in tag_set or "code_pattern" in tag_set:
        return "code_pattern"

    return "past_answer"  # Default


# =============================================================================
# CONTEXT BUNDLE BUILDER
# =============================================================================

class ContextBundleBuilder:
    """
    Builds ContextBundles from ContextEvents.

    This is the main orchestrator that:
    1. Creates query plans
    2. Queries memory sources
    3. Scores candidates
    4. Assembles bundles
    """

    def __init__(self):
        self._memory_librarian = None
        self._domain_banks: Dict[str, Any] = {}
        self._pattern_store = None
        self._init_sources()

    def _init_sources(self) -> None:
        """Initialize connections to memory sources."""
        # Memory librarian
        try:
            from brains.cognitive.memory_librarian.service.memory_librarian import (
                handle as memory_librarian_handle,
                get_conversation_state,
            )
            self._memory_librarian = memory_librarian_handle
            self._get_conversation_state = get_conversation_state
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Memory librarian not available: {e}")

        # Pattern store
        try:
            from brains.cognitive.pattern_store import get_pattern_store
            self._pattern_store = get_pattern_store()
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Pattern store not available: {e}")

        # Domain banks
        try:
            from brains.domain_banks.domain_lookup import lookup_domain_fact
            self._domain_lookup = lookup_domain_fact
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Domain lookup not available: {e}")
            self._domain_lookup = None

    def build(self, event: ContextEvent) -> ContextBundle:
        """
        Build a ContextBundle from a ContextEvent.

        Args:
            event: The ContextEvent describing what context is needed

        Returns:
            ContextBundle with scored and ranked context items
        """
        start_time = time.time()
        bundle_id = f"ctx_{event.event_id}_{int(start_time * 1000) % 100000}"

        # Build query plan
        query_plan = build_query_plan(event)

        # Collect candidates from all sources
        all_candidates: List[Dict[str, Any]] = []

        for source in query_plan["sources"]:
            candidates = self._query_source(source, query_plan)
            for c in candidates:
                c["source"] = source
            all_candidates.extend(candidates)

        # Score all candidates
        scored_items: List[Tuple[float, ContextItem]] = []

        for candidate in all_candidates:
            score, raw_scores = score_candidate(candidate, query_plan)

            item = ContextItem(
                source=candidate.get("source", "unknown"),
                payload=candidate.get("content", candidate),
                score=score,
                tags=candidate.get("tags", []),
                why=self._generate_why(candidate, raw_scores, query_plan),
                raw_scores=raw_scores,
            )
            scored_items.append((score, item))

        # Sort by score descending
        scored_items.sort(key=lambda x: x[0], reverse=True)

        # Split into top and supporting
        top_context = [item for _, item in scored_items[:10]]
        supporting_context = [item for _, item in scored_items[10:30]]

        # Derive answer candidate for appropriate task types
        answer_candidate = self._derive_answer_candidate(
            top_context, event.task_type, event.input_text
        )

        # Derive conversation thread (FIX 3)
        conversation_thread = self._derive_conversation_thread(
            event.task_type, event.input_text, event.blackboard
        )

        build_time_ms = (time.time() - start_time) * 1000

        bundle = ContextBundle(
            bundle_id=bundle_id,
            actor=event.actor,
            stage=event.stage,
            task_type=event.task_type,
            top_context=top_context,
            supporting_context=supporting_context,
            answer_candidate=answer_candidate,
            conversation_thread=conversation_thread,
            query_plan=query_plan,
            total_candidates=len(all_candidates),
            build_time_ms=build_time_ms,
        )

        candidate_info = f", answer_candidate={answer_candidate.value}" if answer_candidate else ""
        print(f"[CONTEXT_BUNDLE] Built bundle {bundle_id}: "
              f"{len(top_context)} top, {len(supporting_context)} supporting, "
              f"{build_time_ms:.1f}ms{candidate_info}")

        return bundle

    def _query_source(self, source: str, query_plan: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query a specific memory source."""
        results: List[Dict[str, Any]] = []
        query_text = query_plan.get("query_text", "")
        key_terms = query_plan.get("key_terms", [])

        try:
            if source == "episodic_memory":
                results = self._query_episodic_memory(query_text, key_terms)
            elif source == "vector_index":
                results = self._query_vector_index(query_text)
            elif source.startswith("domain_bank."):
                domain = source.replace("domain_bank.", "")
                results = self._query_domain_bank(domain, query_text, key_terms)
            elif source == "routing_patterns":
                results = self._query_routing_patterns(query_text)
            elif source == "user_corrections":
                results = self._query_user_corrections(query_text)
            elif source == "teacher_contracts":
                results = self._query_teacher_contracts(query_plan.get("task_type", ""))
            elif source == "project_checkpoint":
                results = self._query_project_checkpoint(query_plan.get("filters", {}))
            elif source == "user_preferences":
                results = self._query_user_preferences()
            elif source == "test_results":
                results = self._query_test_results(key_terms)
            elif source == "personal_bank":
                results = self._query_personal_bank(query_text, key_terms)
            elif source == "session_context":
                results = self._query_session_context(query_plan.get("filters", {}))
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Error querying {source}: {e}")

        return results

    def _query_episodic_memory(self, query: str, key_terms: List[str]) -> List[Dict[str, Any]]:
        """Query episodic memory."""
        if not self._memory_librarian:
            return []

        try:
            result = self._memory_librarian({
                "op": "RETRIEVE",
                "payload": {
                    "query": query,
                    "limit": 20,
                }
            })
            if result.get("ok"):
                records = result.get("payload", {}).get("records", [])
                for r in records:
                    r["tags"] = r.get("tags", []) + ["past_answer"]
                return records
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Episodic memory query failed: {e}")

        return []

    def _query_vector_index(self, query: str) -> List[Dict[str, Any]]:
        """Query vector index for semantic similarity."""
        try:
            from brains.memory.vector_index import search_similar, is_vector_index_enabled

            if not is_vector_index_enabled():
                return []

            hits = search_similar(query, top_k=15)
            return [
                {
                    "content": hit.content,
                    "score": hit.similarity,
                    "metadata": hit.metadata,
                    "tags": ["semantic_match"],
                    "timestamp": hit.metadata.get("timestamp", 0),
                }
                for hit in hits
            ]
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Vector index query failed: {e}")
            return []

    def _query_domain_bank(self, domain: str, query: str, key_terms: List[str]) -> List[Dict[str, Any]]:
        """Query a domain bank."""
        if not self._domain_lookup:
            return []

        results = []
        try:
            # Query with main query
            fact = self._domain_lookup(domain, query)
            if fact:
                results.append({
                    "content": fact,
                    "tags": ["rule", f"{domain}_rule"],
                    "metadata": {"domain": domain},
                    "timestamp": time.time(),
                })

            # Also query key terms
            for term in key_terms[:3]:
                fact = self._domain_lookup(domain, term)
                if fact and fact not in [r["content"] for r in results]:
                    results.append({
                        "content": fact,
                        "tags": ["rule", f"{domain}_rule"],
                        "metadata": {"domain": domain, "term": term},
                        "timestamp": time.time(),
                    })
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Domain bank query failed: {e}")

        return results

    def _query_routing_patterns(self, query: str) -> List[Dict[str, Any]]:
        """Query routing patterns from pattern store."""
        if not self._pattern_store:
            return []

        results = []
        try:
            patterns = self._pattern_store.get_patterns_by_brain("integrator")
            for pattern in patterns[:10]:
                if hasattr(pattern, 'signature') and query.lower() in pattern.signature.lower():
                    results.append({
                        "content": f"Pattern: {pattern.signature}",
                        "tags": ["routing_pattern"],
                        "metadata": {
                            "action": pattern.action if hasattr(pattern, 'action') else {},
                            "score": pattern.score if hasattr(pattern, 'score') else 0.5,
                        },
                        "timestamp": time.time(),
                    })
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Routing patterns query failed: {e}")

        return results

    def _query_user_corrections(self, query: str) -> List[Dict[str, Any]]:
        """Query user corrections from pattern store."""
        if not self._pattern_store:
            return []

        results = []
        try:
            # Look for negative patterns (corrections)
            patterns = self._pattern_store.get_patterns_by_brain("teacher")
            for pattern in patterns:
                if hasattr(pattern, 'score') and pattern.score < 0:
                    results.append({
                        "content": f"Correction: {pattern.signature}",
                        "tags": ["user_correction"],
                        "metadata": {"pattern": pattern.signature},
                        "timestamp": time.time(),
                    })
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] User corrections query failed: {e}")

        return results

    def _query_teacher_contracts(self, task_type: str) -> List[Dict[str, Any]]:
        """Query teacher contracts/lessons for the task type."""
        results = []
        try:
            from brains.cognitive.learning_contract.skill_tracker import get_skill_tracker

            tracker = get_skill_tracker()
            # Get skill level info
            from brains.cognitive.learning_contract.task_types import TaskType as LCTaskType
            try:
                tt = LCTaskType(task_type)
                profile = tracker.get_profile(tt)
                results.append({
                    "content": f"Skill level for {task_type}: {profile.level.value}",
                    "tags": ["teacher_contract", "skill_level"],
                    "metadata": {
                        "task_type": task_type,
                        "skill_level": profile.level.value,
                        "success_rate": profile.success_rate,
                    },
                    "timestamp": time.time(),
                })
            except Exception:
                pass
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Teacher contracts query failed: {e}")

        return results

    def _query_project_checkpoint(self, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Query project checkpoint for current project state."""
        results = []
        try:
            from brains.agent.project_checkpoint import get_current_checkpoint

            checkpoint = get_current_checkpoint()
            if checkpoint:
                results.append({
                    "content": f"Project: {checkpoint.get('project_id', 'unknown')}",
                    "tags": ["project_state"],
                    "metadata": checkpoint,
                    "timestamp": checkpoint.get("timestamp", time.time()),
                })
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Project checkpoint query failed: {e}")

        return results

    def _query_user_preferences(self) -> List[Dict[str, Any]]:
        """Query user preferences."""
        results = []
        try:
            from brains.personal.user_identity import get_user_preferences

            prefs = get_user_preferences()
            if prefs:
                for key, value in prefs.items():
                    results.append({
                        "content": f"User preference: {key} = {value}",
                        "tags": ["user_preference"],
                        "metadata": {"key": key, "value": value},
                        "timestamp": time.time(),
                    })
        except Exception as e:
            print(f"[CONTEXT_BUNDLE] User preferences query failed: {e}")

        return results

    def _query_test_results(self, key_terms: List[str]) -> List[Dict[str, Any]]:
        """Query recent test results."""
        # This would query a test results store if available
        return []

    def _query_personal_bank(self, query: str, key_terms: List[str]) -> List[Dict[str, Any]]:
        """
        Query personal_bank for user identity facts.

        This is the PRIMARY source for "What is my name?" type queries.
        Personal facts have the highest priority multiplier (10.0).
        """
        results = []

        try:
            # Try personal domain bank first
            if self._domain_lookup:
                fact = self._domain_lookup("personal", query)
                if fact:
                    results.append({
                        "content": fact,
                        "tags": ["personal_fact", "user_identity"],
                        "metadata": {
                            "domain": "personal",
                            "is_personal_fact": True,
                            "fact_type": "personal",
                        },
                        "source": "personal_bank",
                        "timestamp": time.time(),
                    })

                # Query specific personal terms
                personal_terms = ["name", "location", "preference", "identity"]
                for term in personal_terms:
                    if term in query.lower() or term in [k.lower() for k in key_terms]:
                        fact = self._domain_lookup("personal", term)
                        if fact and fact not in [r["content"] for r in results]:
                            results.append({
                                "content": fact,
                                "tags": ["personal_fact", "user_identity"],
                                "metadata": {
                                    "domain": "personal",
                                    "is_personal_fact": True,
                                    "fact_type": term,
                                },
                                "source": "personal_bank",
                                "timestamp": time.time(),
                            })

            # Also check episodic memory for personal declarations
            if self._memory_librarian:
                result = self._memory_librarian({
                    "op": "RETRIEVE",
                    "payload": {
                        "query": f"my name is OR I am OR user identity",
                        "limit": 5,
                    }
                })
                if result.get("ok"):
                    records = result.get("payload", {}).get("records", [])
                    for r in records:
                        # Only include if it looks like a personal declaration
                        content = str(r.get("content", "")).lower()
                        if any(phrase in content for phrase in ["my name", "i am", "user is", "call me"]):
                            r["tags"] = ["personal_fact", "user_declaration"]
                            r["metadata"] = r.get("metadata", {})
                            r["metadata"]["is_personal_fact"] = True
                            results.append(r)

        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Personal bank query failed: {e}")

        if not results:
            print(f"[CONTEXT_BUNDLE] WARNING: Personal query '{query[:50]}' found no personal facts")

        return results

    def _query_session_context(self, filters: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Query session context for persistent per-session facts.

        This returns facts that should persist across queries within a session:
        - User identity (already declared this session)
        - Active projects
        - Conversation context

        This is the TWO-TIER CONTEXT system: Session + Query
        """
        results = []

        try:
            # Get conversation state from memory librarian
            if hasattr(self, '_get_conversation_state') and self._get_conversation_state:
                conv_state = self._get_conversation_state()
                if conv_state:
                    # Last declared identity
                    if conv_state.get("last_topic"):
                        results.append({
                            "content": f"Last topic: {conv_state['last_topic']}",
                            "tags": ["session_persistent", "conversation_context"],
                            "metadata": {"type": "conversation_state"},
                            "source": "session_context",
                            "timestamp": time.time(),
                        })

                    # Thread entities (mentioned names, etc.)
                    entities = conv_state.get("thread_entities", [])
                    for entity in entities[:5]:
                        results.append({
                            "content": f"Mentioned entity: {entity}",
                            "tags": ["session_persistent", "entity_mention"],
                            "metadata": {"type": "entity"},
                            "source": "session_context",
                            "timestamp": time.time(),
                        })

        except Exception as e:
            print(f"[CONTEXT_BUNDLE] Session context query failed: {e}")

        return results

    # =========================================================================
    # ANSWER CANDIDATE DERIVATION
    # =========================================================================

    # Task types that should generate answer candidates
    ANSWER_CANDIDATE_TASKS = [
        "math_question",
        "personal_query",
        "fact_lookup",
        "definition_query",
        "simple_qa",
    ]

    # Minimum confidence threshold for answer candidates
    ANSWER_CONFIDENCE_THRESHOLD = 0.7

    def _derive_answer_candidate(
        self,
        top_context: List[ContextItem],
        task_type: str,
        input_text: str,
    ) -> Optional[AnswerCandidate]:
        """
        Derive an explicit answer candidate from top context items.

        For tasks with clear answers (math, personal queries, facts),
        we provide an answer hypothesis BEFORE reasoning runs.

        Args:
            top_context: Scored and ranked context items
            task_type: Type of task being performed
            input_text: The user's query

        Returns:
            AnswerCandidate if one can be derived, None otherwise
        """
        # Only derive for appropriate task types
        if task_type not in self.ANSWER_CANDIDATE_TASKS:
            return None

        if not top_context:
            return None

        # Filter to answer-type items only (exclude narratives, stories)
        answer_items = self._filter_answer_items(top_context, task_type)

        if not answer_items:
            return None

        # Get highest scoring answer item
        best_item = answer_items[0]

        # Check confidence threshold
        if best_item.score < self.ANSWER_CONFIDENCE_THRESHOLD:
            return None

        # Extract answer value from payload
        answer_value = self._extract_answer_value(
            best_item.payload, task_type, input_text
        )

        if answer_value is None:
            return None

        # Create answer candidate
        return AnswerCandidate(
            value=answer_value,
            confidence=best_item.score,
            source=best_item.source,
            source_item=best_item,
            why=f"Highest scoring {task_type} answer (score: {best_item.score:.2f})",
            extraction_method=self._get_extraction_method(task_type),
        )

    def _filter_answer_items(
        self,
        items: List[ContextItem],
        task_type: str,
    ) -> List[ContextItem]:
        """
        Filter items that are valid answer candidates.

        Excludes narrative examples, stories, and other non-answer content.
        This is critical for preventing "2+2 = four ducks" errors.
        """
        answer_items = []

        for item in items:
            # Exclude narrative/example content - CRITICAL for "four ducks" prevention
            if "narrative_example" in item.tags:
                continue
            if "story" in item.tags:
                continue

            # Include answer-type content
            is_answer_type = any([
                "rule" in item.tags,
                "math_rule" in item.tags,
                "past_answer" in item.tags,
                "fact" in item.tags,
                "personal_fact" in item.tags,
                item.source == "personal_bank",
                item.source.startswith("domain_bank."),
            ])

            if is_answer_type:
                answer_items.append(item)

        return answer_items

    def _extract_answer_value(
        self,
        payload: Any,
        task_type: str,
        input_text: str,
    ) -> Optional[Any]:
        """
        Extract the actual answer value from a payload.

        Examples:
        - "addition: 2+2=4" → "4"
        - "name: Alice" → "Alice"
        - "The capital of France is Paris" → "Paris"
        """
        payload_str = str(payload)

        # Task-specific extraction
        if task_type == "math_question":
            return self._extract_math_answer(payload_str, input_text)
        elif task_type == "personal_query":
            return self._extract_personal_answer(payload_str, input_text)
        elif task_type == "fact_lookup":
            return self._extract_fact_answer(payload_str, input_text)
        else:
            # Generic extraction
            return self._extract_generic_answer(payload_str)

    def _extract_math_answer(self, payload: str, query: str) -> Optional[str]:
        """
        Extract math answer from payload.

        Examples:
        - "addition: 2+2=4" → "4"
        - "The result is 42" → "42"
        """
        # Pattern 1: "X=Y" format
        match = re.search(r'=\s*([0-9\.]+)', payload)
        if match:
            return match.group(1)

        # Pattern 2: "answer is Y" format
        match = re.search(r'(?:answer|result|equals)\s+is\s+([0-9\.]+)', payload, re.IGNORECASE)
        if match:
            return match.group(1)

        # Pattern 3: Last number in payload
        numbers = re.findall(r'[0-9\.]+', payload)
        if numbers:
            return numbers[-1]

        return None

    def _extract_personal_answer(self, payload: str, query: str) -> Optional[str]:
        """
        Extract personal fact answer.

        Examples:
        - "name: Alice" → "Alice"
        - "location: Seattle" → "Seattle"
        """
        # Pattern 1: "key: value" format
        if ":" in payload:
            parts = payload.split(":", 1)
            if len(parts) == 2:
                return parts[1].strip()

        # Pattern 2: "key is value" format
        match = re.search(r'is\s+(.+?)(?:\.|$)', payload, re.IGNORECASE)
        if match:
            return match.group(1).strip()

        # Pattern 3: After key term from query
        query_lower = query.lower()
        for key_term in ["name", "location", "email", "phone", "preference"]:
            if key_term in query_lower and key_term in payload.lower():
                idx = payload.lower().index(key_term)
                remainder = payload[idx + len(key_term):].strip()
                # Remove leading punctuation
                remainder = re.sub(r'^[:\-\s]+', '', remainder)
                # Take first phrase
                match = re.search(r'^([A-Za-z0-9\s]+)', remainder)
                if match:
                    return match.group(1).strip()

        return payload.strip() if len(payload) < 100 else None

    def _extract_fact_answer(self, payload: str, query: str) -> Optional[str]:
        """
        Extract factual answer.

        Examples:
        - "The capital of France is Paris" → "Paris"
        """
        # Pattern 1: "X is Y" format
        match = re.search(r'is\s+(.+?)(?:\.|$)', payload, re.IGNORECASE)
        if match:
            return match.group(1).strip()

        # Pattern 2: Last entity (proper noun sequence)
        proper_nouns = re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', payload)
        if proper_nouns:
            return proper_nouns[-1]

        return None

    def _extract_generic_answer(self, payload: str) -> Optional[str]:
        """Generic answer extraction fallback."""
        # Return first sentence if available
        sentences = payload.split(".")
        if sentences:
            first = sentences[0].strip()
            if len(first) > 0 and len(first) < 200:
                return first
        return payload[:200] if len(payload) > 200 else payload

    def _get_extraction_method(self, task_type: str) -> str:
        """Get the extraction method name for logging."""
        method_map = {
            "math_question": "math_pattern_extraction",
            "personal_query": "key_value_parse",
            "fact_lookup": "entity_extraction",
            "definition_query": "definition_parse",
            "simple_qa": "generic_extraction",
        }
        return method_map.get(task_type, "generic_extraction")

    def _generate_why(
        self,
        candidate: Dict[str, Any],
        raw_scores: Dict[str, float],
        query_plan: Dict[str, Any],
    ) -> str:
        """Generate a short explanation for why this candidate was selected."""
        reasons = []

        # Highest contributing factor
        max_factor = max(raw_scores.items(), key=lambda x: x[1])

        if max_factor[0] == "domain" and max_factor[1] > 0.7:
            reasons.append(f"domain match ({query_plan.get('task_type', 'unknown')})")
        elif max_factor[0] == "role" and max_factor[1] > 0.7:
            tags = candidate.get("tags", [])
            role = tags[0] if tags else "relevant"
            reasons.append(f"role: {role}")
        elif max_factor[0] == "similarity" and max_factor[1] > 0.7:
            reasons.append("similar content")
        elif max_factor[0] == "recency" and max_factor[1] > 0.7:
            reasons.append("recent")
        elif max_factor[0] == "correction" and max_factor[1] > 0.7:
            reasons.append("user correction")

        if not reasons:
            reasons.append("general relevance")

        return "; ".join(reasons)

    # ==========================================================================
    # CONVERSATION THREADING (FIX 3)
    # ==========================================================================

    # Small talk patterns for conversation threading
    SMALL_TALK_THREAD_PATTERNS = [
        "hi", "hello", "hey", "howdy", "yo",
        "how are you", "how's it going", "what's up",
        "good morning", "good afternoon", "good evening",
        "bye", "goodbye", "see you", "later",
        "thanks", "thank you", "ok", "okay",
    ]

    # Map task types to expected response types
    RESPONSE_TYPE_MAP = {
        "small_talk": "brief_casual",
        "greeting": "brief_casual",
        "farewell": "brief_casual",
        "feedback": "brief_acknowledgment",
        "confirmation": "brief_acknowledgment",
        "personal_query": "brief_factual",
        "math_question": "brief_factual",
        "fact_lookup": "brief_factual",
        "explanation": "detailed_answer",
        "research_question": "detailed_answer",
        "code_fix": "detailed_answer",
        "code_generation": "detailed_answer",
        "troubleshooting": "step_by_step",
        "planning": "structured_plan",
    }

    def _derive_conversation_thread(
        self,
        task_type: str,
        input_text: str,
        blackboard: Optional[Dict[str, Any]],
    ) -> Optional[ConversationThread]:
        """
        Derive conversation threading context from blackboard.

        This enables proper small talk handling - "how are you" after "hi"
        should get casual continuation, not a verbose explanation.

        Args:
            task_type: Type of task being performed
            input_text: The user's query
            blackboard: Current blackboard state

        Returns:
            ConversationThread if threading context is available
        """
        # Determine conversation pattern
        pattern = self._detect_conversation_pattern(task_type, input_text)

        # Determine expected response type
        expected_type = self.RESPONSE_TYPE_MAP.get(task_type, "detailed_answer")

        # Build last exchange from blackboard
        last_exchange = ""
        turn_count = 0
        thread_topic = ""

        if blackboard:
            try:
                # Get recent conversation from blackboard
                recent_queries = blackboard.get("recent_queries", [])
                history = blackboard.get("history", [])

                if history:
                    turn_count = len(history)
                    # Get last exchange
                    last = history[-1] if history else {}
                    last_q = last.get("query", last.get("user", ""))[:50]
                    last_a = last.get("response", last.get("assistant", ""))[:50]
                    if last_q and last_a:
                        last_exchange = f"{last_q} → {last_a}"
                    elif last_q:
                        last_exchange = last_q

                # Detect thread topic
                if recent_queries and len(recent_queries) > 1:
                    # Check if we're in a small_talk thread
                    small_talk_count = 0
                    for rq in recent_queries[-3:]:
                        q_text = rq.get("query", "").lower() if isinstance(rq, dict) else str(rq).lower()
                        if any(p in q_text for p in self.SMALL_TALK_THREAD_PATTERNS):
                            small_talk_count += 1

                    if small_talk_count >= 2:
                        thread_topic = "small_talk_thread"
                        pattern = "small_talk_thread"
                        expected_type = "brief_casual"

            except Exception as e:
                print(f"[CONTEXT_BUNDLE] Error building conversation thread: {e}")

        # Only return thread if we have useful info
        if pattern == "single_query" and not last_exchange:
            return None

        return ConversationThread(
            conversation_pattern=pattern,
            last_exchange=last_exchange,
            expected_response_type=expected_type,
            turn_count=turn_count,
            thread_topic=thread_topic,
        )

    def _detect_conversation_pattern(self, task_type: str, input_text: str) -> str:
        """Detect the conversation pattern from task type and input."""
        text_lower = input_text.lower().strip()

        # Small talk patterns
        if task_type in ("small_talk", "greeting", "farewell"):
            return "small_talk_thread"

        # Check text for small talk patterns
        if any(p in text_lower for p in self.SMALL_TALK_THREAD_PATTERNS[:10]):
            return "small_talk_thread"

        # Question-answer pattern
        if "?" in input_text or text_lower.startswith(("what", "who", "when", "where", "why", "how")):
            return "question_answer"

        # Multi-turn patterns
        if text_lower.startswith(("and", "also", "but", "so", "then")):
            return "multi_turn"

        # Follow-up patterns
        if text_lower.startswith(("tell me more", "explain", "go on")):
            return "followup"

        return "single_query"


# =============================================================================
# GLOBAL SINGLETON AND CONVENIENCE FUNCTIONS
# =============================================================================

_builder: Optional[ContextBundleBuilder] = None


def get_context_builder() -> ContextBundleBuilder:
    """Get the global context bundle builder."""
    global _builder
    if _builder is None:
        _builder = ContextBundleBuilder()
    return _builder


def build_context_bundle(event: ContextEvent) -> ContextBundle:
    """
    Build a context bundle from an event.

    Convenience function for the main entry point.
    """
    return get_context_builder().build(event)


def emit_context_event(
    actor: str,
    stage: str,
    task_type: str,
    input_text: str,
    blackboard: Optional[Dict[str, Any]] = None,
    goal_hint: str = "",
    constraints: Optional[Dict[str, Any]] = None,
) -> ContextBundle:
    """
    Emit a context event and get back a bundle.

    This is the main integration point for pipeline stages.

    Args:
        actor: Which brain/tool is acting
        stage: Pipeline phase
        task_type: Task type from routing
        input_text: The content being worked on
        blackboard: Optional blackboard reference
        goal_hint: Optional goal hint
        constraints: Optional constraints from governance

    Returns:
        ContextBundle ready to use
    """
    event = ContextEvent(
        actor=actor,
        stage=stage,
        task_type=task_type,
        input_text=input_text,
        goal_hint=goal_hint,
        constraints=constraints or {},
        blackboard=blackboard,
    )

    bundle = build_context_bundle(event)

    # Write to blackboard if provided
    if blackboard is not None:
        blackboard["context_bundle"] = bundle.to_dict()
        blackboard[f"context_bundle:{actor}:{stage}"] = bundle.to_dict()

    return bundle


def get_bundle_from_blackboard(
    blackboard: Dict[str, Any],
    actor: Optional[str] = None,
    stage: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """
    Get a context bundle from the blackboard.

    Args:
        blackboard: The blackboard dict
        actor: Optional actor to filter by
        stage: Optional stage to filter by

    Returns:
        The bundle dict, or None if not found
    """
    if actor and stage:
        key = f"context_bundle:{actor}:{stage}"
        if key in blackboard:
            return blackboard[key]

    return blackboard.get("context_bundle")
