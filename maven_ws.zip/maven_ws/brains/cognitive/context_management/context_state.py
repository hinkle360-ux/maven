"""
context_state.py
~~~~~~~~~~~~~~~~

ContextState abstraction for Maven's conversation tracking.

This module provides a structured replacement for the scattered module-level
globals in memory_librarian.py:
- _CONVERSATION_STATE
- _LAST_WEB_SEARCH
- _WORKING_MEMORY
- _ATTENTION_HISTORY
- _RECENT_QUERIES

The ContextState is stored in the Blackboard's 'context' lane, providing:
- Immutable snapshots for debugging
- Clear ownership and visibility
- Easy serialization for persistence

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
import uuid
import threading


# -----------------------------------------------------------------------------
# Sub-State Dataclasses
# -----------------------------------------------------------------------------

@dataclass
class ConversationTurn:
    """A single conversation turn (query + response pair)."""
    turn_id: str
    query: str
    response: str
    topic: str
    entities: List[str]
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "turn_id": self.turn_id,
            "query": self.query,
            "response": self.response,
            "topic": self.topic,
            "entities": self.entities,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class WebSearchState:
    """State from the last web search operation."""
    query: str = ""
    normalized_topic: str = ""
    engine: str = ""
    results: List[Dict[str, Any]] = field(default_factory=list)
    answer: str = ""
    sources: List[str] = field(default_factory=list)
    timestamp: Optional[datetime] = None

    def is_active(self) -> bool:
        """Check if there's an active search to reference."""
        return bool(self.query)

    def clear(self) -> None:
        """Clear the search state."""
        self.query = ""
        self.normalized_topic = ""
        self.engine = ""
        self.results = []
        self.answer = ""
        self.sources = []
        self.timestamp = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "query": self.query,
            "normalized_topic": self.normalized_topic,
            "engine": self.engine,
            "results": self.results,
            "answer": self.answer,
            "sources": self.sources,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
        }


@dataclass
class WorkingMemoryEntry:
    """A single entry in working memory with TTL."""
    key: str
    value: Any
    tags: List[str] = field(default_factory=list)
    confidence: float = 1.0
    expires_at: Optional[datetime] = None
    created_at: datetime = field(default_factory=datetime.now)

    def is_expired(self, now: Optional[datetime] = None) -> bool:
        """Check if this entry has expired."""
        if self.expires_at is None:
            return False
        now = now or datetime.now()
        return now > self.expires_at

    def to_dict(self) -> Dict[str, Any]:
        return {
            "key": self.key,
            "value": self.value,
            "tags": self.tags,
            "confidence": self.confidence,
            "expires_at": self.expires_at.isoformat() if self.expires_at else None,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class AttentionFocus:
    """Records a focus transition in the attention system."""
    from_focus: str
    to_focus: str
    reason: str
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "from_focus": self.from_focus,
            "to_focus": self.to_focus,
            "reason": self.reason,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class ToolExecutionState:
    """State of an active or recent tool execution."""
    tool_name: str
    method: str
    status: str  # "pending", "running", "completed", "failed"
    started_at: datetime = field(default_factory=datetime.now)
    completed_at: Optional[datetime] = None
    result_entry_id: Optional[str] = None  # Reference to blackboard entry

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tool_name": self.tool_name,
            "method": self.method,
            "status": self.status,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "result_entry_id": self.result_entry_id,
        }


# -----------------------------------------------------------------------------
# Main ContextState Class
# -----------------------------------------------------------------------------

@dataclass
class ContextState:
    """
    Unified conversation and execution context for Maven.

    This replaces the scattered globals in memory_librarian.py with a
    single, structured state object that can be:
    - Stored in the blackboard's 'context' lane
    - Serialized for persistence
    - Passed between pipeline stages
    - Inspected for debugging

    Usage:
        ctx = ContextState.create()
        ctx.record_turn(query="What time is it?", response="It's 3pm", topic="time")
        ctx.record_web_search(query="weather", engine="bing", results=[...])

        # Store in blackboard
        bb.add_entry(
            owner="context_manager",
            lane="context",
            visibility="internal",
            payload=ctx.to_dict(),
        )
    """

    # Identity
    conversation_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = field(default_factory=datetime.now)

    # Conversation state (replaces _CONVERSATION_STATE)
    turn_count: int = 0
    last_query: str = ""
    last_response: str = ""
    last_topic: str = ""
    thread_entities: List[str] = field(default_factory=list)
    recent_turns: List[ConversationTurn] = field(default_factory=list)

    # Web search state (replaces _LAST_WEB_SEARCH)
    web_search: WebSearchState = field(default_factory=WebSearchState)

    # Working memory (replaces _WORKING_MEMORY)
    working_memory: List[WorkingMemoryEntry] = field(default_factory=list)

    # Attention history (replaces _ATTENTION_HISTORY)
    attention_history: List[AttentionFocus] = field(default_factory=list)

    # Active tool execution tracking
    active_tool: Optional[ToolExecutionState] = None
    recent_tools: List[ToolExecutionState] = field(default_factory=list)

    # Configuration
    max_recent_turns: int = 10
    max_working_memory: int = 50
    max_attention_history: int = 20
    max_recent_tools: int = 5

    # ---------------------------------------------------------------------
    # Factory Methods
    # ---------------------------------------------------------------------

    @classmethod
    def create(cls, conversation_id: Optional[str] = None) -> "ContextState":
        """Create a new ContextState instance."""
        return cls(
            conversation_id=conversation_id or str(uuid.uuid4()),
        )

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ContextState":
        """Reconstruct ContextState from serialized dict."""
        ctx = cls(
            conversation_id=data.get("conversation_id", str(uuid.uuid4())),
            turn_count=data.get("turn_count", 0),
            last_query=data.get("last_query", ""),
            last_response=data.get("last_response", ""),
            last_topic=data.get("last_topic", ""),
            thread_entities=data.get("thread_entities", []),
        )

        # Restore web search state
        ws_data = data.get("web_search", {})
        if ws_data:
            ctx.web_search = WebSearchState(
                query=ws_data.get("query", ""),
                normalized_topic=ws_data.get("normalized_topic", ""),
                engine=ws_data.get("engine", ""),
                results=ws_data.get("results", []),
                answer=ws_data.get("answer", ""),
                sources=ws_data.get("sources", []),
            )

        return ctx

    @classmethod
    def from_legacy_globals(
        cls,
        conversation_state: Dict[str, Any],
        last_web_search: Dict[str, Any],
        working_memory: List[Dict[str, Any]],
        attention_history: List[Dict[str, Any]],
    ) -> "ContextState":
        """
        Create ContextState from legacy module-level globals.

        This migration helper allows gradual transition from the old
        scattered state to the new unified ContextState.
        """
        ctx = cls.create()

        # Migrate _CONVERSATION_STATE
        ctx.last_query = conversation_state.get("last_query", "")
        ctx.last_response = conversation_state.get("last_response", "")
        ctx.last_topic = conversation_state.get("last_topic", "")
        ctx.thread_entities = conversation_state.get("thread_entities", [])
        ctx.turn_count = conversation_state.get("conversation_depth", 0)

        # Migrate _LAST_WEB_SEARCH
        ctx.web_search = WebSearchState(
            query=last_web_search.get("query", ""),
            normalized_topic=last_web_search.get("normalized_topic", ""),
            engine=last_web_search.get("engine", ""),
            results=last_web_search.get("results", []),
            answer=last_web_search.get("answer", ""),
            sources=last_web_search.get("sources", []),
        )

        # Migrate _WORKING_MEMORY
        for entry in working_memory:
            ctx.working_memory.append(WorkingMemoryEntry(
                key=entry.get("key", ""),
                value=entry.get("value"),
                tags=entry.get("tags", []),
                confidence=entry.get("confidence", 1.0),
            ))

        # Migrate _ATTENTION_HISTORY
        for entry in attention_history:
            ctx.attention_history.append(AttentionFocus(
                from_focus=entry.get("from", ""),
                to_focus=entry.get("to", ""),
                reason=entry.get("reason", ""),
            ))

        return ctx

    # ---------------------------------------------------------------------
    # Conversation Tracking
    # ---------------------------------------------------------------------

    def record_turn(
        self,
        query: str,
        response: str,
        topic: str = "",
        entities: Optional[List[str]] = None,
    ) -> ConversationTurn:
        """
        Record a conversation turn.

        Args:
            query: User's query
            response: System's response
            topic: Extracted topic
            entities: Extracted entities

        Returns:
            The created ConversationTurn
        """
        self.turn_count += 1
        self.last_query = query
        self.last_response = response

        if topic:
            self.last_topic = topic

        if entities:
            # Merge entities, keeping unique
            seen = set(self.thread_entities)
            for e in entities:
                if e not in seen:
                    self.thread_entities.append(e)
                    seen.add(e)

        turn = ConversationTurn(
            turn_id=f"turn_{self.turn_count}",
            query=query,
            response=response,
            topic=topic or self.last_topic,
            entities=entities or [],
        )

        self.recent_turns.append(turn)

        # Prune to max
        if len(self.recent_turns) > self.max_recent_turns:
            self.recent_turns = self.recent_turns[-self.max_recent_turns:]

        return turn

    def get_conversation_context(self) -> Dict[str, Any]:
        """Get conversation context for prompts/reasoning."""
        return {
            "turn_count": self.turn_count,
            "last_query": self.last_query,
            "last_response": self.last_response,
            "last_topic": self.last_topic,
            "thread_entities": self.thread_entities,
            "recent_turns": [t.to_dict() for t in self.recent_turns[-3:]],
        }

    # ---------------------------------------------------------------------
    # Web Search Tracking
    # ---------------------------------------------------------------------

    def record_web_search(
        self,
        query: str,
        engine: str,
        results: List[Dict[str, Any]],
        answer: str = "",
        sources: Optional[List[str]] = None,
        normalized_topic: str = "",
    ) -> None:
        """Record a web search operation."""
        self.web_search = WebSearchState(
            query=query,
            normalized_topic=normalized_topic or query.lower().strip(),
            engine=engine,
            results=results,
            answer=answer,
            sources=sources or [],
            timestamp=datetime.now(),
        )

    def clear_web_search(self) -> None:
        """Clear the web search state."""
        self.web_search.clear()

    def followup_refers_to_search(self, query: str) -> bool:
        """Check if a follow-up query refers to the last search."""
        if not self.web_search.is_active():
            return False

        query_lower = query.lower().strip()

        # Generic follow-ups
        generic_patterns = [
            "tell me more",
            "more about",
            "what else",
            "anything else",
            "continue",
            "go on",
            "elaborate",
            "explain more",
        ]

        for pattern in generic_patterns:
            if pattern in query_lower:
                return True

        # Check if topic is mentioned
        if self.web_search.normalized_topic in query_lower:
            return True

        return False

    # ---------------------------------------------------------------------
    # Working Memory
    # ---------------------------------------------------------------------

    def add_to_working_memory(
        self,
        key: str,
        value: Any,
        tags: Optional[List[str]] = None,
        confidence: float = 1.0,
        ttl_seconds: Optional[int] = None,
    ) -> WorkingMemoryEntry:
        """Add an entry to working memory."""
        expires_at = None
        if ttl_seconds:
            from datetime import timedelta
            expires_at = datetime.now() + timedelta(seconds=ttl_seconds)

        entry = WorkingMemoryEntry(
            key=key,
            value=value,
            tags=tags or [],
            confidence=confidence,
            expires_at=expires_at,
        )

        self.working_memory.append(entry)
        self._prune_working_memory()

        return entry

    def get_from_working_memory(
        self,
        key: Optional[str] = None,
        tag: Optional[str] = None,
    ) -> List[WorkingMemoryEntry]:
        """Get entries from working memory."""
        self._prune_working_memory()

        results = []
        for entry in self.working_memory:
            if key and entry.key != key:
                continue
            if tag and tag not in entry.tags:
                continue
            results.append(entry)

        return results

    def _prune_working_memory(self) -> None:
        """Remove expired entries and enforce max size."""
        now = datetime.now()
        self.working_memory = [
            e for e in self.working_memory
            if not e.is_expired(now)
        ]

        if len(self.working_memory) > self.max_working_memory:
            self.working_memory = self.working_memory[-self.max_working_memory:]

    # ---------------------------------------------------------------------
    # Attention Tracking
    # ---------------------------------------------------------------------

    def record_attention_shift(
        self,
        from_focus: str,
        to_focus: str,
        reason: str = "",
    ) -> AttentionFocus:
        """Record an attention/focus transition."""
        shift = AttentionFocus(
            from_focus=from_focus,
            to_focus=to_focus,
            reason=reason,
        )

        self.attention_history.append(shift)

        if len(self.attention_history) > self.max_attention_history:
            self.attention_history = self.attention_history[-self.max_attention_history:]

        return shift

    # ---------------------------------------------------------------------
    # Tool Execution Tracking
    # ---------------------------------------------------------------------

    def start_tool_execution(
        self,
        tool_name: str,
        method: str,
    ) -> ToolExecutionState:
        """Record the start of a tool execution."""
        if self.active_tool:
            # Move previous to recent
            self.recent_tools.append(self.active_tool)
            if len(self.recent_tools) > self.max_recent_tools:
                self.recent_tools = self.recent_tools[-self.max_recent_tools:]

        self.active_tool = ToolExecutionState(
            tool_name=tool_name,
            method=method,
            status="running",
        )

        return self.active_tool

    def complete_tool_execution(
        self,
        status: str = "completed",
        result_entry_id: Optional[str] = None,
    ) -> Optional[ToolExecutionState]:
        """Record the completion of a tool execution."""
        if not self.active_tool:
            return None

        self.active_tool.status = status
        self.active_tool.completed_at = datetime.now()
        self.active_tool.result_entry_id = result_entry_id

        completed = self.active_tool
        self.recent_tools.append(completed)
        self.active_tool = None

        if len(self.recent_tools) > self.max_recent_tools:
            self.recent_tools = self.recent_tools[-self.max_recent_tools:]

        return completed

    # ---------------------------------------------------------------------
    # Serialization
    # ---------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "conversation_id": self.conversation_id,
            "created_at": self.created_at.isoformat(),
            "turn_count": self.turn_count,
            "last_query": self.last_query,
            "last_response": self.last_response,
            "last_topic": self.last_topic,
            "thread_entities": self.thread_entities,
            "recent_turns": [t.to_dict() for t in self.recent_turns],
            "web_search": self.web_search.to_dict(),
            "working_memory": [e.to_dict() for e in self.working_memory],
            "attention_history": [a.to_dict() for a in self.attention_history],
            "active_tool": self.active_tool.to_dict() if self.active_tool else None,
            "recent_tools": [t.to_dict() for t in self.recent_tools],
        }

    def get_summary(self) -> Dict[str, Any]:
        """Get a summary for logging/debugging."""
        return {
            "conversation_id": self.conversation_id[:8] + "...",
            "turn_count": self.turn_count,
            "last_topic": self.last_topic,
            "has_active_search": self.web_search.is_active(),
            "working_memory_size": len(self.working_memory),
            "active_tool": self.active_tool.tool_name if self.active_tool else None,
        }

    def __repr__(self) -> str:
        return f"ContextState(turns={self.turn_count}, topic={self.last_topic!r})"


# -----------------------------------------------------------------------------
# Thread-Safe Context Manager
# -----------------------------------------------------------------------------

class ContextStateManager:
    """
    Thread-safe manager for the active ContextState.

    This provides a global access point while ensuring thread safety
    during the transition from module-level globals.

    Usage:
        manager = ContextStateManager()
        ctx = manager.get_or_create()
        ctx.record_turn(...)
    """

    _instance: Optional["ContextStateManager"] = None
    _lock = threading.Lock()

    def __new__(cls) -> "ContextStateManager":
        """Singleton pattern."""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._state: Optional[ContextState] = None
                    cls._instance._state_lock = threading.Lock()
        return cls._instance

    def get(self) -> Optional[ContextState]:
        """Get the current context state, or None if not initialized."""
        with self._state_lock:
            return self._state

    def get_or_create(self, conversation_id: Optional[str] = None) -> ContextState:
        """Get the current context state, creating if needed."""
        with self._state_lock:
            if self._state is None:
                self._state = ContextState.create(conversation_id)
            return self._state

    def set(self, state: ContextState) -> None:
        """Set the current context state."""
        with self._state_lock:
            self._state = state

    def reset(self) -> ContextState:
        """Reset to a fresh context state."""
        with self._state_lock:
            self._state = ContextState.create()
            return self._state

    def snapshot(self) -> Optional[Dict[str, Any]]:
        """Get a serialized snapshot of current state."""
        with self._state_lock:
            if self._state:
                return self._state.to_dict()
            return None


# Convenience singleton access
_context_manager = ContextStateManager()


def get_context() -> Optional[ContextState]:
    """Get the current context state."""
    return _context_manager.get()


def get_or_create_context(conversation_id: Optional[str] = None) -> ContextState:
    """Get or create the current context state."""
    return _context_manager.get_or_create(conversation_id)


def reset_context() -> ContextState:
    """Reset to a fresh context state."""
    return _context_manager.reset()


# -----------------------------------------------------------------------------
# Exports
# -----------------------------------------------------------------------------

__all__ = [
    "ConversationTurn",
    "WebSearchState",
    "WorkingMemoryEntry",
    "AttentionFocus",
    "ToolExecutionState",
    "ContextState",
    "ContextStateManager",
    "get_context",
    "get_or_create_context",
    "reset_context",
]
