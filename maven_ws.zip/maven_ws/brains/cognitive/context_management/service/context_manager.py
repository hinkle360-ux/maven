"""
Context Management
===================

This module implements simple context management utilities for the
Maven cognitive architecture.  Context refers to the mutable
pipeline state that accumulates information across stages and turns.
Without management, context can grow indefinitely and bias future
decisions.  The functions here implement basic temporal decay and
reconstruction heuristics.

Features include:

* ``apply_decay`` – reduce the influence of old numeric fields by
  multiplying them by a decay factor.
* ``reconstruct_context`` – merge a list of prior context snapshots
  into a fresh context, preferring newer values and combining lists.

These helpers are intentionally lightweight.  They can be extended
in future releases to support more sophisticated decay functions
(e.g. exponential, contextual) or to persist and retrieve context
across sessions.
"""

from __future__ import annotations

from typing import Any, Dict, List, Iterable, Optional, Union
import time

# Pattern store for unified learning across all brains
from brains.cognitive.pattern_store import (
    get_pattern_store,
    Pattern,
    verdict_to_reward
)
from brains.cognitive.context_management.initial_patterns import (
    initialize_context_management_patterns
)

# Context bundle system for task-aware context retrieval
try:
    from brains.cognitive.context_management.context_bundle import (
        ContextEvent,
        ContextBundle,
        build_context_bundle,
        emit_context_event,
        get_bundle_from_blackboard,
        get_context_builder,
    )
    _context_bundle_available = True
except Exception as e:
    print(f"[CONTEXT_MANAGEMENT] Context bundle system not available: {e}")
    _context_bundle_available = False

# Teacher integration for learning context tracking and management strategies
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("context_management")
except Exception as e:
    print(f"[CONTEXT_MANAGEMENT] Teacher helper not available: {e}")
    _teacher_helper = None  # type: ignore

# Initialize pattern store
_pattern_store = get_pattern_store()

# Load initial patterns if not already present
try:
    initialize_context_management_patterns()
except Exception as e:
    print(f"[CONTEXT_MANAGEMENT] Failed to initialize patterns: {e}")

# Track which pattern was used for the current decay
_current_pattern: Optional[Pattern] = None

# =============================================================================
# PHASE 2: ACTION REQUEST TRACKING
# =============================================================================
# Track the last actionable request so follow-ups like "do it please" can
# execute the previous request.

from dataclasses import dataclass, field
from datetime import datetime
import re

@dataclass
class ActionRequest:
    """Represents a pending actionable request that can be executed on confirmation."""
    request_type: str  # e.g., "write_story", "search", "explain", "create"
    original_text: str  # The original user request text
    payload: Dict[str, Any]  # Structured data extracted from the request
    timestamp: datetime = field(default_factory=datetime.now)
    executed: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_type": self.request_type,
            "original_text": self.original_text,
            "payload": self.payload,
            "timestamp": self.timestamp.isoformat(),
            "executed": self.executed,
        }


# Module-level storage for the last open action request
_last_open_action_request: Optional[ActionRequest] = None


# Patterns for detecting confirmation/acknowledgment messages
# These indicate the user wants to continue with a previous topic/action
CONFIRMATION_PATTERNS = [
    # Action confirmations
    r"^do\s+it\s*,?\s*please\.?$",
    r"^do\s+it\.?$",
    r"^go\s+ahead\.?$",
    r"^ok\s*,?\s*do\s+it\.?$",
    r"^please\s+do\.?$",
    r"^please\s+do\s+it\.?$",
    r"^proceed\.?$",
    r"^execute\.?$",
    r"^make\s+it\s+happen\.?$",
    r"^do\s+that\.?$",

    # Simple affirmatives (need context from previous turn)
    r"^yes\.?$",
    r"^yeah\.?$",
    r"^yep\.?$",
    r"^yup\.?$",
    r"^sure\.?$",
    r"^ok(ay)?\.?$",
    r"^alright\.?$",
    r"^yes\s*,?\s*please\.?$",
    r"^yes\s*,?\s*do\s+it\.?$",
    r"^yeah\s*,?\s*do\s+it\.?$",
    r"^sure\s*,?\s*go\s+ahead\.?$",
    r"^alright\s*,?\s*do\s+it\.?$",
    r"^ok(ay)?\s*,?\s*please\.?$",

    # Continuation requests
    r"^tell\s+me\s+more\.?$",
    r"^more\.?$",
    r"^go\s+on\.?$",
    r"^continue\.?$",
    r"^and\s*\??$",
    r"^and\s+then\s*\??$",
    r"^what\s+else\s*\??$",
    r"^anything\s+else\s*\??$",
    r"^elaborate\.?$",
    r"^explain\.?$",
    r"^details\.?$",
    r"^like\s+what\s*\??$",
    r"^such\s+as\s*\??$",
    r"^for\s+example\s*\??$",
]


# Patterns for detecting actionable requests (not just questions)
# Format: (pattern, request_type, topic_group_index)
# topic_group_index: which capture group contains the topic (0 = no specific topic group)
ACTION_REQUEST_PATTERNS = [
    # Write/Create patterns with topic extraction
    # "write a story about birds" -> topic = "birds"
    (r"\b(can you |could you )?(write|create|make|generate|compose)\s+(?:me\s+)?(?:a\s+)?(story|poem|essay|script|article|song|code|function|program)\s+(?:about|on|regarding|for)\s+(.+)", "write_content"),
    (r"\b(can you |could you )?(write|create|make|generate|compose)\s+(?:me\s+)?(?:a\s+)?(story|poem|essay|script|article|song)\b", "write_content"),
    (r"\b(write|create|make|generate|compose)\s+(?:me\s+)?(?:a\s+)?(.+)", "write_content"),
    # Search patterns
    (r"\b(can you |could you )?(search|look up|find|research)\s+(?:for\s+)?(.+)", "search"),
    (r"\b(can you |could you )?(search|look up|find|research)\b", "search"),
    # Explain patterns
    (r"\b(can you |could you )?(explain|describe|tell me about|elaborate on)\s+(.+)", "explain"),
    (r"\b(can you |could you )?(explain|describe|tell me about|elaborate on)\b", "explain"),
    # Calculate/Compute patterns
    (r"\b(can you |could you )?(calculate|compute|figure out|determine)\s+(.+)", "calculate"),
    (r"\b(can you |could you )?(calculate|compute|figure out|determine)\b", "calculate"),
    # Run/Execute patterns
    (r"\b(can you |could you )?(run|execute|perform|do)\b.*\b(command|script|code|program)\b", "execute"),
    # Summarize patterns
    (r"\b(can you |could you )?(summarize|sum up|give me a summary)\s+(?:of\s+)?(.+)", "summarize"),
    (r"\b(can you |could you )?(summarize|sum up|give me a summary)\b", "summarize"),
    # Translate patterns
    (r"\b(can you |could you )?(translate)\s+(.+)", "translate"),
    (r"\b(can you |could you )?(translate)\b", "translate"),
]


def is_confirmation_message(text: str) -> bool:
    """
    Check if a message is a short acknowledgment/confirmation like "do it please".

    Args:
        text: The user message text

    Returns:
        True if the message matches a confirmation pattern
    """
    if not text:
        return False

    text_clean = text.strip().lower()

    # Only short messages can be confirmations
    if len(text_clean) > 50:
        return False

    for pattern in CONFIRMATION_PATTERNS:
        if re.match(pattern, text_clean, re.IGNORECASE):
            return True

    return False


def extract_action_request(text: str) -> Optional[ActionRequest]:
    """
    Extract an actionable request from user text.

    If the text matches a pattern for an actionable request (like "can you write
    me a story about birds"), extract the request type and payload.

    Args:
        text: The user message text

    Returns:
        ActionRequest if the text is an actionable request, None otherwise
    """
    if not text:
        return None

    text_lower = text.lower().strip()

    for pattern, request_type in ACTION_REQUEST_PATTERNS:
        match = re.search(pattern, text_lower, re.IGNORECASE)
        if match:
            # Extract the subject/topic from the request
            # For write_content requests, try to extract:
            # 1. The content type (story, poem, etc.)
            # 2. The topic (what it's about)
            groups = match.groups()
            content_type = ""
            topic = ""

            if request_type == "write_content":
                # Look for content type (story, poem, etc.) and topic
                for i, g in enumerate(groups):
                    if g and g.strip():
                        g_clean = g.strip()
                        # Check if this is a content type
                        if g_clean in ["story", "poem", "essay", "script", "article", "song", "code", "function", "program"]:
                            content_type = g_clean
                        # The last non-empty, non-content-type group is likely the topic
                        elif g_clean not in ["can you ", "could you ", "can you", "could you"]:
                            topic = g_clean

                # If we didn't find a topic in groups, try to extract it from the full text
                if not topic:
                    # Try to extract topic after "about", "on", "regarding", "for"
                    topic_match = re.search(r"\b(?:about|on|regarding|for)\s+(.+?)(?:\?|$)", text_lower)
                    if topic_match:
                        topic = topic_match.group(1).strip()

            else:
                # For other request types, use the last non-empty group as subject
                for g in reversed(groups):
                    if g and g.strip() and g.strip() not in ["can you ", "could you "]:
                        topic = g.strip()
                        break

            # Create the action request with structured payload
            payload = {
                "subject": topic or content_type,
                "matched_pattern": pattern,
                "match_groups": [g for g in groups if g],
            }

            # Add specific fields for write_content requests
            if request_type == "write_content":
                payload["intent"] = "write_story" if content_type == "story" else f"write_{content_type}" if content_type else "write_content"
                payload["content_type"] = content_type
                payload["topic"] = topic
                payload["arguments"] = {"topic": topic} if topic else {}

            print(f"[CONTEXT_MANAGER] Extracted action request: type={request_type}, content_type={content_type}, topic={topic}")

            return ActionRequest(
                request_type=request_type,
                original_text=text,
                payload=payload
            )

    return None


def store_action_request(request: ActionRequest) -> None:
    """
    Store an actionable request for potential follow-up execution.

    Args:
        request: The ActionRequest to store
    """
    global _last_open_action_request
    _last_open_action_request = request
    print(f"[CONTEXT_MANAGER] Stored action request: type={request.request_type}, text='{request.original_text[:50]}...'")


def get_last_action_request() -> Optional[ActionRequest]:
    """
    Get the last stored action request.

    Returns:
        The last ActionRequest, or None if none stored
    """
    return _last_open_action_request


def clear_action_request() -> None:
    """Clear the stored action request."""
    global _last_open_action_request
    _last_open_action_request = None


def mark_action_executed() -> None:
    """Mark the current action request as executed."""
    global _last_open_action_request
    if _last_open_action_request:
        _last_open_action_request.executed = True


def get_follow_up_context() -> Optional[Dict[str, Any]]:
    """
    Get context for a follow-up execution.

    If there's a pending action request and the user sends a confirmation,
    this returns the context needed to execute that action.

    Returns:
        Dict with action context if available, None otherwise
    """
    if not _last_open_action_request:
        return None

    if _last_open_action_request.executed:
        return None

    return {
        "is_follow_up": True,
        "original_request": _last_open_action_request.original_text,
        "request_type": _last_open_action_request.request_type,
        "payload": _last_open_action_request.payload,
        "timestamp": _last_open_action_request.timestamp.isoformat(),
    }


def _ensure_pattern_object(pattern: Any, default_signature: str = "global:default") -> Optional[Pattern]:
    """
    Ensure that a pattern is a proper Pattern object.

    Handles the bug where _current_pattern can become a string or dict
    instead of a Pattern object.

    Args:
        pattern: The pattern to normalize
        default_signature: Default signature if conversion is needed

    Returns:
        A proper Pattern object, or None if pattern is None/invalid
    """
    if pattern is None:
        return None

    if isinstance(pattern, Pattern):
        return pattern

    if isinstance(pattern, str):
        # Pattern is a plain string - convert to Pattern object
        print(f"[CONTEXT_MANAGEMENT] WARNING: Converting string to Pattern: {pattern[:50]}")
        return Pattern(
            brain="context_management",
            signature=pattern if pattern else default_signature,
            action={},
            score=0.5
        )

    if isinstance(pattern, dict):
        # Pattern is a dict - convert to Pattern object
        print(f"[CONTEXT_MANAGEMENT] WARNING: Converting dict to Pattern")
        return Pattern(
            brain="context_management",
            signature=str(pattern.get("signature", pattern.get("text", default_signature))),
            action=pattern.get("action", {}) if isinstance(pattern.get("action"), dict) else {},
            score=float(pattern.get("score", 0.5))
        )

    # Unknown type - log and return default
    print(f"[CONTEXT_MANAGEMENT] WARNING: Unknown pattern type: {type(pattern).__name__}")
    return Pattern(
        brain="context_management",
        signature=default_signature,
        action={},
        score=0.5
    )


def _classify_decay_type(ctx: Dict[str, Any]) -> str:
    """Classify context to determine which decay pattern to use."""
    if not isinstance(ctx, dict) or len(ctx) < 2:
        return "global:default_decay"

    # Check for specific content types
    if any(k in ctx for k in ["answer", "response", "output"]):
        return "global:answer_decay"
    if any(k in ctx for k in ["affect", "emotion", "sentiment"]):
        return "global:affect_decay"

    return "global:default_decay"


# =============================================================================
# REFERENCE RESOLUTION - Handles pronouns and references to previous turns
# =============================================================================

# Pronouns and reference words that need resolution
REFERENCE_PATTERNS = [
    r'\b(he|she|it|they|him|her|them|his|hers|their|theirs)\b',
    r'\b(that|this|these|those|the same)\b',
    r'\b(the above|the previous|what you said|you mentioned)\b',
]


def contains_reference(text: str) -> bool:
    """
    Check if text contains pronouns or references that need resolution.

    Args:
        text: User query or message

    Returns:
        True if text contains resolvable references
    """
    if not text:
        return False

    text_lower = text.lower()

    for pattern in REFERENCE_PATTERNS:
        if re.search(pattern, text_lower):
            return True

    return False


def resolve_references(
    query: str,
    recent_turns: List[Dict[str, Any]],
    entities: List[str],
) -> Dict[str, Any]:
    """
    Resolve pronouns and references in a query using context.

    Uses Teacher to learn reference resolution patterns.

    Args:
        query: The current user query
        recent_turns: List of recent conversation turns
        entities: Known entities from conversation

    Returns:
        Dict with:
            - resolved_query: Query with references resolved
            - resolutions: List of {reference, resolved_to} pairs
            - confidence: Resolution confidence
            - learned: Whether this pattern was learned
    """
    global _teacher_helper

    if not contains_reference(query):
        return {
            "resolved_query": query,
            "resolutions": [],
            "confidence": 1.0,
            "learned": False,
        }

    # Build context for resolution
    context_str = ""
    if recent_turns:
        for turn in recent_turns[-3:]:  # Last 3 turns
            q = turn.get("query", "")
            r = turn.get("response", "")[:200]
            if q:
                context_str += f"User: {q}\n"
            if r:
                context_str += f"Maven: {r}\n"

    entities_str = ", ".join(entities[-10:]) if entities else "none"

    # Try to use learned patterns first
    pattern_key = f"reference:{query.lower()[:50]}"
    learned_pattern = _pattern_store.get_best_pattern(
        brain="context_management",
        signature=pattern_key,
        score_threshold=0.7,
    )

    if learned_pattern and hasattr(learned_pattern, 'action'):
        action = learned_pattern.action
        if isinstance(action, dict) and action.get("resolved_query"):
            print(f"[CONTEXT_MANAGEMENT] Using learned reference resolution")
            return {
                "resolved_query": action["resolved_query"],
                "resolutions": action.get("resolutions", []),
                "confidence": learned_pattern.score,
                "learned": True,
            }

    # Use Teacher to resolve references
    if _teacher_helper:
        try:
            result = _teacher_helper.maybe_call_teacher(
                question=f"""Resolve references in this query:

QUERY: "{query}"

RECENT CONVERSATION:
{context_str}

KNOWN ENTITIES: {entities_str}

Instructions:
1. Identify any pronouns (he, she, it, they, etc.) or references (that, this, the above)
2. Determine what each reference refers to based on context
3. Return the query with references replaced by explicit terms

Respond in JSON:
{{
    "resolved_query": "the query with references replaced",
    "resolutions": [
        {{"reference": "he", "resolved_to": "John"}},
        {{"reference": "that", "resolved_to": "the Python script"}}
    ],
    "confidence": 0.9
}}""",
                context={
                    "recent_turns": recent_turns,
                    "entities": entities,
                    "task": "reference_resolution"
                }
            )

            if result and result.get("answer"):
                answer = result["answer"]

                # Parse JSON from answer
                try:
                    json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', answer, re.DOTALL)
                    if json_match:
                        parsed = json.loads(json_match.group())

                        resolved_query = parsed.get("resolved_query", query)
                        resolutions = parsed.get("resolutions", [])
                        confidence = float(parsed.get("confidence", 0.7))

                        # Store learned pattern
                        _pattern_store.update_pattern_score(
                            pattern=Pattern(
                                brain="context_management",
                                signature=pattern_key,
                                action={
                                    "resolved_query": resolved_query,
                                    "resolutions": resolutions,
                                },
                                score=confidence,
                            ),
                            reward=0.5,  # Initial reward
                            alpha=0.9,
                        )

                        print(f"[CONTEXT_MANAGEMENT] Resolved references: {resolutions}")

                        return {
                            "resolved_query": resolved_query,
                            "resolutions": resolutions,
                            "confidence": confidence,
                            "learned": True,
                        }
                except json.JSONDecodeError:
                    print(f"[CONTEXT_MANAGEMENT] Could not parse resolution JSON")

        except Exception as e:
            print(f"[CONTEXT_MANAGEMENT] Reference resolution failed: {e}")

    # Fallback: simple entity substitution
    resolved = query
    resolutions = []

    for entity in entities[-5:]:  # Try recent entities
        # Simple pronoun replacement (very basic)
        for pronoun in ["it", "that", "this"]:
            if re.search(rf'\b{pronoun}\b', resolved.lower()):
                resolved = re.sub(rf'\b{pronoun}\b', entity, resolved, count=1, flags=re.IGNORECASE)
                resolutions.append({"reference": pronoun, "resolved_to": entity})
                break
        if resolutions:
            break

    return {
        "resolved_query": resolved,
        "resolutions": resolutions,
        "confidence": 0.4 if resolutions else 0.1,
        "learned": False,
    }


import json


def apply_decay(
    ctx: Dict[str, Any],
    decay: float = 0.9,
    session_context: Optional[Dict[str, Any]] = None,
    _is_recursive: bool = False
) -> Dict[str, Any]:
    """
    Apply temporal decay to numeric fields in a context dictionary using learned patterns.

    Numeric values (ints or floats) are multiplied by the provided
    decay factor, reducing their magnitude over time.  Nested
    dictionaries are decayed recursively.  Non‑numeric fields are
    preserved unchanged.

    Args:
        ctx: The context dictionary to decay.
        decay: A multiplicative factor between 0 and 1.  Values
            closer to zero cause faster forgetting.
        session_context: Optional context about the session type (for pattern matching)
        _is_recursive: Internal flag to avoid pattern lookup on recursive calls

    Returns:
        A new dictionary with decayed values; the original context is
        not modified.
    """
    global _current_pattern

    if not isinstance(ctx, dict):
        return {}

    # Only do pattern lookup at the top level, not in recursive calls
    effective_decay = decay

    if not _is_recursive:
        global _current_pattern

        # Classify the decay type
        decay_type = _classify_decay_type(ctx)

        # Try to find a learned pattern
        pattern = _pattern_store.get_best_pattern(
            brain="context_management",
            signature=decay_type,
            score_threshold=0.0  # Accept any pattern above 0
        )

        # Track which pattern we're using for later updates
        # Use _ensure_pattern_object to handle any type safely
        _current_pattern = _ensure_pattern_object(pattern, decay_type)

        # Determine effective decay factor
        if _current_pattern and hasattr(_current_pattern, 'score') and _current_pattern.score > -0.5:
            action = _current_pattern.action if hasattr(_current_pattern, 'action') else {}
            # Defensive check: ensure action is a dict before calling .get()
            if isinstance(action, dict):
                learned_decay = action.get("decay_factor", decay)
                effective_decay = learned_decay
                print(f"[CONTEXT_MANAGEMENT] Using learned decay: {effective_decay:.3f} for {decay_type}")
            else:
                print(f"[CONTEXT_MANAGEMENT] Warning: pattern.action is not a dict (type={type(action).__name__}), using default decay")
                effective_decay = decay
        else:
            print(f"[CONTEXT_MANAGEMENT] Using default decay: {effective_decay:.3f}")

    # Apply decay recursively
    decayed: Dict[str, Any] = {}
    for key, value in ctx.items():
        if isinstance(value, dict):
            # Pass _is_recursive=True to avoid pattern lookup in nested dicts
            decayed[key] = apply_decay(value, effective_decay, session_context, _is_recursive=True)
        elif isinstance(value, (int, float)):
            decayed[key] = value * effective_decay
        else:
            decayed[key] = value

    return decayed


def update_from_verdict(verdict: str, metadata: Optional[Dict[str, Any]] = None):
    """
    Update the current pattern's score based on SELF_REVIEW/Teacher verdict.

    For CONTEXT_MANAGEMENT, we also consider:
    - context_loss: caused incoherent answer → negative reward
    - too_much_context: kept too much, repetitive → negative reward

    Args:
        verdict: One of 'ok', 'minor_issue', 'major_issue'
        metadata: Optional dict with 'context_loss', 'too_much_context' flags
    """
    global _current_pattern

    if not _current_pattern:
        print("[CONTEXT_MANAGEMENT] No current pattern to update")
        return

    # Normalize _current_pattern to ensure it's a proper Pattern object
    _current_pattern = _ensure_pattern_object(_current_pattern, "global:default")

    if not _current_pattern:
        print("[CONTEXT_MANAGEMENT] Could not normalize current pattern, skipping update")
        return

    # Start with base reward from verdict
    reward = verdict_to_reward(verdict)

    # Adjust based on context-specific metadata
    if metadata and isinstance(metadata, dict):
        if metadata.get("context_loss"):
            reward -= 0.5  # Context loss is bad
        if metadata.get("too_much_context"):
            reward -= 0.3  # Too much context is wasteful

    # Clamp reward to [-1, 1]
    reward = max(-1.0, min(1.0, reward))

    # Update pattern score
    _pattern_store.update_pattern_score(
        pattern=_current_pattern,
        reward=reward,
        alpha=0.85  # Learning rate: 0.85 = slower, more stable
    )

    print(f"[CONTEXT_MANAGEMENT] Updated pattern {_current_pattern.signature} "
          f"based on verdict={verdict} (reward={reward:+.1f})")


def reconstruct_context(history: Iterable[Dict[str, Any]]) -> Dict[str, Any]:
    """Reconstruct a context from a sequence of prior contexts.

    When resuming a long session, it may be necessary to combine
    multiple context snapshots (e.g. from previous turns) into a
    single current context.  This function iterates through the
    provided contexts in order, merging their keys.  Later contexts
    override earlier ones for scalar values.  For lists, values are
    concatenated.  Nested dictionaries are merged recursively.

    Args:
        history: An iterable of context dictionaries ordered from
            oldest to newest.
    Returns:
        A single context dictionary representing the merged result.
    """
    merged: Dict[str, Any] = {}
    for ctx in history:
        if not isinstance(ctx, dict):
            continue
        for key, value in ctx.items():
            if key not in merged:
                merged[key] = value
            else:
                existing = merged[key]
                # If both are dicts, merge recursively
                if isinstance(existing, dict) and isinstance(value, dict):
                    merged[key] = reconstruct_context([existing, value])
                # If both are lists, append new items
                elif isinstance(existing, list) and isinstance(value, list):
                    merged[key] = existing + value
                # Otherwise, prefer the newer value
                else:
                    merged[key] = value
    return merged


def handle(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Context Management service API.

    Supported operations:
    - APPLY_DECAY: Apply temporal decay to context
    - RECONSTRUCT: Reconstruct context from history
    - HEALTH: Health check

    Args:
        msg: Request with 'op' and optional 'payload'

    Returns:
        Response dict with 'ok' and 'payload' or 'error'
    """
    op = (msg or {}).get("op", "").upper()
    payload = msg.get("payload") or {}

    if op == "APPLY_DECAY":
        try:
            ctx = payload.get("context", {})
            decay = payload.get("decay", 0.9)
            decayed = apply_decay(ctx, decay)
            return {
                "ok": True,
                "payload": {
                    "context": decayed
                }
            }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "DECAY_FAILED",
                    "message": str(e)
                }
            }

    if op == "RECONSTRUCT":
        try:
            history = payload.get("history", [])
            merged = reconstruct_context(history)
            return {
                "ok": True,
                "payload": {
                    "context": merged
                }
            }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "RECONSTRUCT_FAILED",
                    "message": str(e)
                }
            }

    if op == "HEALTH":
        num_patterns = len(_pattern_store.get_patterns_by_brain("context_management"))
        return {
            "ok": True,
            "payload": {
                "status": "operational",
                "patterns_loaded": num_patterns
            }
        }

    if op == "RESOLVE_REFERENCES":
        # Resolve pronouns and references in a query
        try:
            query = str(payload.get("query", ""))
            recent_turns = payload.get("recent_turns", [])
            entities = payload.get("entities", [])

            result = resolve_references(query, recent_turns, entities)

            return {
                "ok": True,
                "payload": result
            }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "RESOLVE_FAILED",
                    "message": str(e)
                }
            }

    # COHERENCY FIX: Direct answer for reference clarification questions
    if op == "ANSWER_REFERENCE_CLARIFICATION":
        # When user asks "What is it?" - provide DIRECT answer
        try:
            pronoun = str(payload.get("pronoun", "it"))
            recent_turns = payload.get("recent_turns", [])
            entities = payload.get("entities", [])
            last_topic = payload.get("last_topic", "")

            # Try to find what the pronoun refers to
            referent = None

            # Check last topic first
            if last_topic:
                referent = last_topic

            # Check recent entities
            elif entities:
                referent = entities[-1]  # Most recent entity

            # Check recent turns for mentioned topics
            elif recent_turns:
                for turn in reversed(recent_turns[-3:]):
                    response = turn.get("response", "")
                    query = turn.get("query", "")
                    # Look for nouns/topics mentioned
                    if response:
                        # Simple extraction: find last noun phrase mentioned
                        import re
                        nouns = re.findall(r'\b(?:the |a |an |your )?(\w+(?:\s+\w+)?)\b', response)
                        if nouns:
                            referent = nouns[-1]
                            break

            if referent:
                # DIRECT ANSWER - no dodging
                direct_answer = f"'{pronoun.capitalize()}' refers to {referent}."
                return {
                    "ok": True,
                    "payload": {
                        "direct_answer": direct_answer,
                        "pronoun": pronoun,
                        "referent": referent,
                        "confidence": 0.8
                    }
                }
            else:
                # Honest admission when we can't resolve
                return {
                    "ok": True,
                    "payload": {
                        "direct_answer": f"I'm not sure what '{pronoun}' refers to in this context. Could you clarify what you're asking about?",
                        "pronoun": pronoun,
                        "referent": None,
                        "confidence": 0.3
                    }
                }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "CLARIFICATION_FAILED",
                    "message": str(e)
                }
            }

    if op == "UPDATE_FROM_VERDICT":
        try:
            verdict = str(payload.get("verdict", "ok"))
            metadata = payload.get("metadata")
            update_from_verdict(verdict, metadata)
            return {
                "ok": True,
                "payload": {
                    "updated": True
                }
            }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "UPDATE_FAILED",
                    "message": str(e)
                }
            }

    # PHASE 2: Action request tracking operations
    if op == "CHECK_CONFIRMATION":
        # Check if the message is a confirmation like "do it please"
        text = str(payload.get("text", ""))
        is_confirmation = is_confirmation_message(text)
        follow_up_context = None
        if is_confirmation:
            follow_up_context = get_follow_up_context()
        return {
            "ok": True,
            "payload": {
                "is_confirmation": is_confirmation,
                "has_pending_action": follow_up_context is not None,
                "follow_up_context": follow_up_context,
            }
        }

    if op == "EXTRACT_ACTION_REQUEST":
        # Extract an actionable request from user text
        text = str(payload.get("text", ""))
        action_request = extract_action_request(text)
        if action_request:
            # Store it for potential follow-up
            store_action_request(action_request)
            return {
                "ok": True,
                "payload": {
                    "is_action_request": True,
                    "action_request": action_request.to_dict(),
                }
            }
        else:
            return {
                "ok": True,
                "payload": {
                    "is_action_request": False,
                    "action_request": None,
                }
            }

    if op == "GET_PENDING_ACTION":
        # Get the last pending action request
        action_request = get_last_action_request()
        if action_request:
            return {
                "ok": True,
                "payload": {
                    "has_pending_action": True,
                    "action_request": action_request.to_dict(),
                }
            }
        else:
            return {
                "ok": True,
                "payload": {
                    "has_pending_action": False,
                    "action_request": None,
                }
            }

    if op == "MARK_ACTION_EXECUTED":
        # Mark the current action as executed
        mark_action_executed()
        return {
            "ok": True,
            "payload": {
                "marked": True
            }
        }

    if op == "CLEAR_ACTION_REQUEST":
        # Clear the stored action request
        clear_action_request()
        return {
            "ok": True,
            "payload": {
                "cleared": True
            }
        }

    # ==========================================================================
    # CONTEXT BUNDLE OPERATIONS
    # ==========================================================================

    if op == "BUILD_CONTEXT_BUNDLE":
        # Build a context bundle from an event
        if not _context_bundle_available:
            return {
                "ok": False,
                "error": {
                    "code": "CONTEXT_BUNDLE_UNAVAILABLE",
                    "message": "Context bundle system not available"
                }
            }

        try:
            event = ContextEvent(
                actor=str(payload.get("actor", "unknown")),
                stage=str(payload.get("stage", "unknown")),
                task_type=str(payload.get("task_type", "unknown")),
                input_text=str(payload.get("input_text", "")),
                goal_hint=str(payload.get("goal_hint", "")),
                constraints=payload.get("constraints", {}),
            )
            bundle = build_context_bundle(event)
            return {
                "ok": True,
                "payload": {
                    "bundle": bundle.to_dict()
                }
            }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "BUILD_BUNDLE_FAILED",
                    "message": str(e)
                }
            }

    if op == "EMIT_CONTEXT_EVENT":
        # Emit a context event and get back a bundle (writes to blackboard)
        if not _context_bundle_available:
            return {
                "ok": False,
                "error": {
                    "code": "CONTEXT_BUNDLE_UNAVAILABLE",
                    "message": "Context bundle system not available"
                }
            }

        try:
            bundle = emit_context_event(
                actor=str(payload.get("actor", "unknown")),
                stage=str(payload.get("stage", "unknown")),
                task_type=str(payload.get("task_type", "unknown")),
                input_text=str(payload.get("input_text", "")),
                blackboard=payload.get("blackboard"),
                goal_hint=str(payload.get("goal_hint", "")),
                constraints=payload.get("constraints"),
            )
            return {
                "ok": True,
                "payload": {
                    "bundle": bundle.to_dict(),
                    "bundle_id": bundle.bundle_id,
                }
            }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "EMIT_EVENT_FAILED",
                    "message": str(e)
                }
            }

    if op == "GET_CONTEXT_BUNDLE":
        # Get a context bundle from the blackboard
        if not _context_bundle_available:
            return {
                "ok": False,
                "error": {
                    "code": "CONTEXT_BUNDLE_UNAVAILABLE",
                    "message": "Context bundle system not available"
                }
            }

        try:
            blackboard = payload.get("blackboard", {})
            actor = payload.get("actor")
            stage = payload.get("stage")
            bundle = get_bundle_from_blackboard(blackboard, actor, stage)
            return {
                "ok": True,
                "payload": {
                    "bundle": bundle,
                    "found": bundle is not None,
                }
            }
        except Exception as e:
            return {
                "ok": False,
                "error": {
                    "code": "GET_BUNDLE_FAILED",
                    "message": str(e)
                }
            }

    return {
        "ok": False,
        "error": {
            "code": "UNSUPPORTED_OP",
            "message": op
        }
    }


# Standard service contract: handle is the entry point
service_api = handle


# =============================================================================
# CONTEXT MANAGER INTERFACE IMPLEMENTATION
# =============================================================================
# This implements the ContextManagerInterface from brains/base/context_aware_brain.py
# to enable mandatory context protocol across all context-aware brains.

class MavenContextManager:
    """
    Implementation of ContextManagerInterface for Maven.

    Connects the ContextAwareBrain base class with the existing
    Context Bundle system.
    """

    def __init__(self):
        self._usage_reports: List[Dict[str, Any]] = []

    def build_bundle(
        self,
        actor: str,
        stage: str,
        task_type: str,
        input_text: str,
        constraints: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """
        Build a context bundle for the given event.

        Args:
            actor: The brain/actor requesting context
            stage: Pipeline stage
            task_type: Type of task being performed
            input_text: Input text/query
            constraints: Optional constraints dict

        Returns:
            Context bundle dict with top_context, supporting_context, etc.
        """
        if not _context_bundle_available:
            # Return empty bundle structure if bundle system unavailable
            return {
                "bundle_id": f"fallback-{time.time()}",
                "top_context": [],
                "supporting_context": [],
                "query_plan": {"sources": []},
                "is_fallback": True,
            }

        try:
            event = ContextEvent(
                actor=actor,
                stage=stage,
                task_type=task_type,
                input_text=input_text,
                constraints=constraints or {},
            )
            bundle = build_context_bundle(event)
            return bundle.to_dict()
        except Exception as e:
            print(f"[MAVEN_CONTEXT_MANAGER] Bundle build failed: {e}")
            return {
                "bundle_id": f"error-{time.time()}",
                "top_context": [],
                "supporting_context": [],
                "query_plan": {"sources": []},
                "error": str(e),
            }

    def report_usage(self, report) -> None:
        """
        Report how context was used (for learning).

        Args:
            report: ContextUsageReport from the brain
        """
        try:
            # Store report for analysis
            report_dict = {
                "brain_name": report.brain_name,
                "context_items_provided": report.context_items_provided,
                "context_items_used": report.context_items_used,
                "items_used_ids": report.items_used_ids,
                "processing_time_ms": report.processing_time_ms,
                "context_was_helpful": report.context_was_helpful,
                "notes": report.notes,
                "timestamp": time.time(),
            }
            self._usage_reports.append(report_dict)

            # Keep only last 100 reports
            if len(self._usage_reports) > 100:
                self._usage_reports = self._usage_reports[-100:]

            # If context wasn't helpful, log for future improvement
            if not report.context_was_helpful:
                print(f"[MAVEN_CONTEXT_MANAGER] Context not helpful for {report.brain_name}: {report.notes}")

        except Exception as e:
            print(f"[MAVEN_CONTEXT_MANAGER] Failed to record usage report: {e}")

    def get_usage_stats(self) -> Dict[str, Any]:
        """Get statistics about context usage."""
        if not self._usage_reports:
            return {"total_reports": 0}

        total = len(self._usage_reports)
        helpful_count = sum(1 for r in self._usage_reports if r.get("context_was_helpful", False))
        avg_items_provided = sum(r.get("context_items_provided", 0) for r in self._usage_reports) / total
        avg_items_used = sum(r.get("context_items_used", 0) for r in self._usage_reports) / total

        return {
            "total_reports": total,
            "helpful_rate": helpful_count / total if total > 0 else 0,
            "avg_items_provided": avg_items_provided,
            "avg_items_used": avg_items_used,
            "usage_efficiency": avg_items_used / avg_items_provided if avg_items_provided > 0 else 0,
        }


# Global Maven context manager instance
_maven_context_manager: Optional[MavenContextManager] = None


def get_maven_context_manager() -> MavenContextManager:
    """Get or create the global Maven context manager."""
    global _maven_context_manager
    if _maven_context_manager is None:
        _maven_context_manager = MavenContextManager()
    return _maven_context_manager


def initialize_context_protocol() -> None:
    """
    Initialize the mandatory context protocol.

    This should be called at system startup to wire the context manager
    with the ContextAwareBrain base class.
    """
    try:
        from brains.base.context_aware_brain import set_context_manager
        manager = get_maven_context_manager()
        set_context_manager(manager)
        import sys
        print("[MAVEN_CONTEXT_MANAGER] Context protocol initialized", file=sys.stderr)
    except ImportError as e:
        import sys
        print(f"[MAVEN_CONTEXT_MANAGER] Could not initialize context protocol: {e}", file=sys.stderr)
    except Exception as e:
        import sys
        print(f"[MAVEN_CONTEXT_MANAGER] Context protocol initialization failed: {e}", file=sys.stderr)