"""
Causal Reasoning Brain
======================

The causal reasoning brain provides cause-effect analysis, outcome prediction,
and counterfactual reasoning capabilities. It enables Maven to understand
"why" things happen and predict consequences of actions.

Operations:

  INFER_CONSEQUENCE
      Given an action and current state, predicts the likely outcome.
      Payload: {"action": str, "state": dict, "context": str}
      Returns: {"consequences": list, "confidence": float, "chain": list}

  EVALUATE_COUNTERFACTUAL
      Evaluates "what if X didn't happen?" scenarios.
      Payload: {"event": str, "context": str, "alternative": str}
      Returns: {"alternative_outcome": str, "likelihood": float, "reasoning": str}

  BUILD_CAUSAL_CHAIN
      Constructs a causal chain from premise to conclusion.
      Payload: {"premise": str, "conclusion": str, "context": str}
      Returns: {"chain": list, "valid": bool, "gaps": list}

  SIMULATE_SCENARIO
      Simulates forward from initial state through a sequence of actions.
      Payload: {"initial_state": dict, "actions": list, "steps": int}
      Returns: {"final_state": dict, "trajectory": list, "risks": list}

  ANALYZE_CAUSALITY
      Analyzes the causal structure of a situation or statement.
      Payload: {"text": str, "context": str}
      Returns: {"causes": list, "effects": list, "relationships": list}

  WHY_QUESTION
      Handles "why" questions by identifying relevant causal factors.
      Payload: {"question": str, "context": str}
      Returns: {"explanation": str, "factors": list, "confidence": float}

This brain is critical for AGI-level reasoning as it enables the system to:
- Predict consequences before taking actions
- Understand cause-effect relationships in the world
- Reason about hypothetical scenarios
- Build explanations for observed phenomena
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple
import re
from dataclasses import dataclass, field
from enum import Enum

from brains.memory.brain_memory import BrainMemory

# Teacher integration for learning causal patterns
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("causal_reasoning")
except Exception as e:
    print(f"[CAUSAL] Teacher helper not available: {e}")
    _teacher_helper = None

# Continuation helpers for cognitive brain contract compliance
try:
    from brains.cognitive.continuation_helpers import (
        is_continuation,
        get_conversation_context,
        create_routing_hint
    )
    _continuation_helpers_available = True
except Exception:
    _continuation_helpers_available = False

# Initialize memory
_memory = BrainMemory("causal_reasoning")

# LLM service for enhanced what-if analysis
_llm_service = None
_llm_available = False

def _init_llm_service():
    """Initialize LLM service if available."""
    global _llm_service, _llm_available
    if _llm_service is not None:
        return

    try:
        from brains.tools.llm_service import get_llm_service
        _llm_service = get_llm_service()
        _llm_available = _llm_service is not None
        if _llm_available:
            print("[CAUSAL] LLM service initialized for enhanced analysis")
    except ImportError:
        try:
            # Fallback: try direct import
            from host_tools.llm_client.ollama_client import OllamaLLMService
            _llm_service = OllamaLLMService()
            _llm_available = True
            print("[CAUSAL] LLM fallback initialized")
        except Exception as e:
            print(f"[CAUSAL] LLM not available: {e}")
            _llm_available = False


def _llm_what_if_analysis(action: str, context: str, state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Use LLM for deep what-if analysis.

    This provides more nuanced reasoning than rule-based approaches
    for complex scenarios.
    """
    _init_llm_service()

    if not _llm_available or _llm_service is None:
        return {"llm_available": False}

    prompt = f"""Analyze this action and predict its consequences:

Action: {action}
Context: {context if context else "No specific context provided"}
Current state: {state if state else "Unknown"}

Please analyze:
1. What are the likely immediate consequences?
2. What are potential side effects?
3. What risks should be considered?
4. What conditions could change the outcome?

Respond concisely with key points only."""

    try:
        response = _llm_service.call(prompt)
        if response.get("ok"):
            llm_text = response.get("text", "")
            return {
                "llm_available": True,
                "llm_analysis": llm_text[:1000],  # Limit response size
                "enhanced": True
            }
        return {"llm_available": True, "error": response.get("error", "LLM call failed")}
    except Exception as e:
        return {"llm_available": True, "error": str(e)}


def _llm_safety_prediction(action: str, context: str) -> Dict[str, Any]:
    """
    Use LLM to predict safety implications of an action.
    """
    _init_llm_service()

    if not _llm_available or _llm_service is None:
        return {"llm_available": False}

    prompt = f"""Evaluate the safety of this action:

Action: {action}
Context: {context if context else "General usage"}

Answer these questions:
1. Is this action potentially harmful? (yes/no)
2. What is the risk level? (low/medium/high/critical)
3. Is this action reversible? (yes/no)
4. What precautions should be taken?

Be concise and direct."""

    try:
        response = _llm_service.call(prompt)
        if response.get("ok"):
            llm_text = response.get("text", "").lower()

            # Parse risk level from response
            risk_level = "medium"
            if "critical" in llm_text:
                risk_level = "critical"
            elif "high" in llm_text:
                risk_level = "high"
            elif "low" in llm_text:
                risk_level = "low"

            # Check if harmful
            is_harmful = "yes" in llm_text and "harmful" in llm_text

            # Check reversibility
            reversible = "yes" in llm_text and "reversible" in llm_text

            return {
                "llm_available": True,
                "safety_analysis": response.get("text", "")[:500],
                "risk_level": risk_level,
                "potentially_harmful": is_harmful,
                "reversible": reversible,
                "enhanced": True
            }
        return {"llm_available": True, "error": response.get("error", "LLM call failed")}
    except Exception as e:
        return {"llm_available": True, "error": str(e)}


def _llm_causal_explanation(question: str, context: str) -> Dict[str, Any]:
    """
    Use LLM to provide causal explanations for complex questions.
    """
    _init_llm_service()

    if not _llm_available or _llm_service is None:
        return {"llm_available": False}

    prompt = f"""Explain the causal factors for this question:

Question: {question}
Context: {context if context else "General context"}

Provide:
1. The main cause(s)
2. Contributing factors
3. The causal chain (A causes B which causes C)
4. Confidence level (low/medium/high)

Be precise and factual."""

    try:
        response = _llm_service.call(prompt)
        if response.get("ok"):
            return {
                "llm_available": True,
                "causal_explanation": response.get("text", "")[:800],
                "enhanced": True
            }
        return {"llm_available": True, "error": response.get("error", "LLM call failed")}
    except Exception as e:
        return {"llm_available": True, "error": str(e)}


class CausalRelationType(str, Enum):
    """Types of causal relationships."""
    CAUSES = "causes"
    ENABLES = "enables"
    PREVENTS = "prevents"
    REQUIRES = "requires"
    CORRELATES = "correlates"
    TRIGGERS = "triggers"
    INHIBITS = "inhibits"


@dataclass
class CausalLink:
    """Represents a causal relationship between two concepts."""
    cause: str
    effect: str
    relation_type: CausalRelationType
    strength: float = 0.5  # 0.0 to 1.0
    conditions: List[str] = field(default_factory=list)
    evidence: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "cause": self.cause,
            "effect": self.effect,
            "relation_type": self.relation_type.value,
            "strength": self.strength,
            "conditions": self.conditions,
            "evidence": self.evidence
        }


@dataclass
class CausalChain:
    """A sequence of causal links forming a chain of reasoning."""
    links: List[CausalLink] = field(default_factory=list)
    confidence: float = 1.0

    def add_link(self, link: CausalLink) -> None:
        self.links.append(link)
        self.confidence *= link.strength

    def to_dict(self) -> Dict[str, Any]:
        return {
            "links": [link.to_dict() for link in self.links],
            "confidence": self.confidence,
            "length": len(self.links)
        }


# Common cause-effect patterns (domain knowledge)
COMMON_CAUSAL_PATTERNS: Dict[str, List[Dict[str, Any]]] = {
    # Physical world
    "physical": [
        {"cause": "heat", "effect": "temperature increase", "type": "causes"},
        {"cause": "force", "effect": "motion", "type": "causes"},
        {"cause": "rain", "effect": "wet ground", "type": "causes"},
        {"cause": "fire", "effect": "smoke", "type": "causes"},
        {"cause": "cold", "effect": "ice formation", "type": "enables"},
    ],
    # Technical/software
    "technical": [
        {"cause": "bug in code", "effect": "program crash", "type": "causes"},
        {"cause": "missing dependency", "effect": "build failure", "type": "causes"},
        {"cause": "memory leak", "effect": "performance degradation", "type": "causes"},
        {"cause": "invalid input", "effect": "error", "type": "triggers"},
        {"cause": "authentication failure", "effect": "access denied", "type": "causes"},
    ],
    # Business/organizational
    "business": [
        {"cause": "poor planning", "effect": "project delay", "type": "causes"},
        {"cause": "budget cut", "effect": "reduced scope", "type": "requires"},
        {"cause": "market demand", "effect": "price change", "type": "correlates"},
        {"cause": "training", "effect": "skill improvement", "type": "enables"},
    ],
    # Actions and consequences
    "actions": [
        {"cause": "delete file", "effect": "data loss", "type": "causes"},
        {"cause": "backup", "effect": "data protection", "type": "enables"},
        {"cause": "restart", "effect": "state reset", "type": "causes"},
        {"cause": "update", "effect": "behavior change", "type": "triggers"},
    ]
}

# Risk indicators for actions
HIGH_RISK_ACTIONS = {
    "delete", "remove", "drop", "truncate", "format", "wipe",
    "overwrite", "replace", "modify", "change", "update",
    "execute", "run", "deploy", "publish", "send", "transfer"
}

# Causal keywords for pattern detection
CAUSAL_KEYWORDS = {
    "causes": ["causes", "leads to", "results in", "produces", "creates", "makes"],
    "because": ["because", "since", "due to", "owing to", "as a result of"],
    "therefore": ["therefore", "hence", "thus", "consequently", "so"],
    "if_then": ["if", "when", "whenever", "in case"],
    "prevents": ["prevents", "stops", "blocks", "inhibits", "avoids"],
    "enables": ["enables", "allows", "permits", "facilitates", "helps"]
}


def _extract_causal_keywords(text: str) -> List[str]:
    """Extract causal keywords from text."""
    text_lower = text.lower()
    found = []
    for category, keywords in CAUSAL_KEYWORDS.items():
        for kw in keywords:
            if kw in text_lower:
                found.append(kw)
    return found


def _identify_domain(text: str, context: str = "") -> str:
    """Identify the domain of a causal query."""
    combined = f"{text} {context}".lower()

    if any(w in combined for w in ["code", "program", "software", "bug", "error", "api"]):
        return "technical"
    elif any(w in combined for w in ["business", "company", "market", "project", "budget"]):
        return "business"
    elif any(w in combined for w in ["file", "delete", "backup", "command", "action"]):
        return "actions"
    else:
        return "physical"


def _get_relevant_patterns(domain: str) -> List[Dict[str, Any]]:
    """Get causal patterns relevant to a domain."""
    return COMMON_CAUSAL_PATTERNS.get(domain, [])


def _assess_action_risk(action: str, state: Dict[str, Any]) -> Tuple[str, float, List[str]]:
    """
    Assess the risk level of an action.

    Returns:
        Tuple of (risk_level, risk_score, risk_factors)
    """
    action_lower = action.lower()
    risk_factors = []
    risk_score = 0.0

    # Check for high-risk action keywords
    for risk_word in HIGH_RISK_ACTIONS:
        if risk_word in action_lower:
            risk_factors.append(f"Action contains '{risk_word}'")
            risk_score += 0.2

    # Check state for sensitive targets
    target = state.get("target", "")
    if target:
        if any(s in target.lower() for s in ["system", "root", "admin", "config"]):
            risk_factors.append(f"Target '{target}' is sensitive")
            risk_score += 0.3

    # Check for irreversibility
    if any(w in action_lower for w in ["delete", "remove", "drop", "format"]):
        risk_factors.append("Action may be irreversible")
        risk_score += 0.3

    # Determine risk level
    if risk_score >= 0.7:
        risk_level = "critical"
    elif risk_score >= 0.5:
        risk_level = "high"
    elif risk_score >= 0.3:
        risk_level = "medium"
    else:
        risk_level = "low"

    return risk_level, min(risk_score, 1.0), risk_factors


def _infer_consequence(
    action: str,
    state: Dict[str, Any],
    context: str = ""
) -> Dict[str, Any]:
    """
    Infer the likely consequences of an action given a state.
    """
    domain = _identify_domain(action, context)
    patterns = _get_relevant_patterns(domain)

    consequences = []
    chain = []
    overall_confidence = 0.7

    # Assess risk first
    risk_level, risk_score, risk_factors = _assess_action_risk(action, state)

    # Look for matching patterns
    action_lower = action.lower()
    for pattern in patterns:
        cause = pattern["cause"]
        if cause.lower() in action_lower or action_lower in cause.lower():
            effect = pattern["effect"]
            relation = pattern["type"]
            consequences.append({
                "effect": effect,
                "relation": relation,
                "confidence": 0.7,
                "source": "pattern_match"
            })
            chain.append({
                "from": cause,
                "to": effect,
                "type": relation
            })

    # Check for learned patterns from memory
    try:
        learned = _memory.retrieve(
            query=f"causal pattern: {action}",
            limit=3,
            tiers=["stm", "mtm", "ltm"]
        )
        for rec in learned:
            if rec.get("kind") == "causal_pattern" and rec.get("confidence", 0) >= 0.5:
                content = rec.get("content", "")
                if isinstance(content, dict):
                    consequences.append({
                        "effect": content.get("effect", "unknown effect"),
                        "relation": content.get("relation", "causes"),
                        "confidence": rec.get("confidence", 0.5),
                        "source": "learned"
                    })
    except Exception:
        pass

    # If no patterns found, provide generic consequence based on risk
    if not consequences:
        if risk_level in ["high", "critical"]:
            consequences.append({
                "effect": f"Potential {risk_level} impact from {action}",
                "relation": "causes",
                "confidence": risk_score,
                "source": "risk_assessment"
            })
        else:
            consequences.append({
                "effect": f"Action '{action}' will be executed",
                "relation": "triggers",
                "confidence": 0.5,
                "source": "default"
            })

    return {
        "consequences": consequences,
        "confidence": overall_confidence * (1 - risk_score * 0.3),
        "chain": chain,
        "risk_level": risk_level,
        "risk_score": risk_score,
        "risk_factors": risk_factors
    }


def _evaluate_counterfactual(
    event: str,
    context: str = "",
    alternative: str = ""
) -> Dict[str, Any]:
    """
    Evaluate a counterfactual scenario ("what if X didn't happen?").
    """
    # Parse the counterfactual structure
    reasoning_steps = []

    # Step 1: Identify what actually happened
    reasoning_steps.append(f"Actual event: {event}")

    # Step 2: Consider the alternative
    if alternative:
        alt_outcome = alternative
    else:
        # Generate a plausible alternative
        alt_outcome = f"Without '{event}', the situation would remain unchanged"

    reasoning_steps.append(f"Alternative scenario: {alt_outcome}")

    # Step 3: Assess likelihood
    # Counterfactuals involving established facts are less likely
    likelihood = 0.5
    if any(w in event.lower() for w in ["always", "never", "must", "cannot"]):
        likelihood = 0.2  # Hard to change fundamental constraints
    elif any(w in event.lower() for w in ["might", "could", "possibly"]):
        likelihood = 0.7  # More flexible scenarios

    reasoning_steps.append(f"Likelihood assessment: {likelihood:.2f}")

    # Check memory for similar counterfactual analyses
    try:
        learned = _memory.retrieve(
            query=f"counterfactual: {event}",
            limit=2,
            tiers=["mtm", "ltm"]
        )
        for rec in learned:
            if rec.get("kind") == "counterfactual_analysis":
                reasoning_steps.append(f"Prior analysis found: {rec.get('content', {})}")
    except Exception:
        pass

    return {
        "alternative_outcome": alt_outcome,
        "likelihood": likelihood,
        "reasoning": " → ".join(reasoning_steps),
        "event_analyzed": event,
        "context": context
    }


def _build_causal_chain(
    premise: str,
    conclusion: str,
    context: str = ""
) -> Dict[str, Any]:
    """
    Build a causal chain connecting premise to conclusion.
    """
    chain = []
    gaps = []
    valid = True

    # Try to find intermediate steps
    domain = _identify_domain(f"{premise} {conclusion}", context)
    patterns = _get_relevant_patterns(domain)

    # Start from premise
    current = premise
    steps_taken = 0
    max_steps = 5

    while current != conclusion and steps_taken < max_steps:
        found_next = False

        # Look for a pattern that connects current to something
        for pattern in patterns:
            if pattern["cause"].lower() in current.lower():
                next_step = pattern["effect"]
                chain.append({
                    "from": current,
                    "to": next_step,
                    "type": pattern["type"],
                    "step": steps_taken + 1
                })
                current = next_step
                found_next = True
                break

        if not found_next:
            # No pattern found - gap in reasoning
            gaps.append(f"No known causal link from '{current}'")
            break

        steps_taken += 1

    # Check if we reached the conclusion
    if current.lower() not in conclusion.lower() and conclusion.lower() not in current.lower():
        if chain:
            # We made progress but didn't reach conclusion
            gaps.append(f"Chain ends at '{current}', not '{conclusion}'")
            valid = False
        else:
            # No chain at all
            gaps.append(f"No causal path found from '{premise}' to '{conclusion}'")
            valid = False

    return {
        "chain": chain,
        "valid": valid and len(gaps) == 0,
        "gaps": gaps,
        "premise": premise,
        "conclusion": conclusion,
        "steps": len(chain)
    }


def _simulate_scenario(
    initial_state: Dict[str, Any],
    actions: List[str],
    max_steps: int = 10
) -> Dict[str, Any]:
    """
    Simulate forward from initial state through actions.
    """
    trajectory = []
    risks = []
    current_state = initial_state.copy()

    steps_executed = min(len(actions), max_steps)

    for i, action in enumerate(actions[:steps_executed]):
        step_result = {
            "step": i + 1,
            "action": action,
            "state_before": current_state.copy()
        }

        # Assess risk of this action
        risk_level, risk_score, risk_factors = _assess_action_risk(action, current_state)

        if risk_level in ["high", "critical"]:
            risks.append({
                "step": i + 1,
                "action": action,
                "risk_level": risk_level,
                "factors": risk_factors
            })

        # Infer consequences
        consequence_result = _infer_consequence(action, current_state, "")

        # Update state based on consequences
        for cons in consequence_result.get("consequences", []):
            effect = cons.get("effect", "")
            # Add effect to state as a change
            if "changes" not in current_state:
                current_state["changes"] = []
            current_state["changes"].append({
                "step": i + 1,
                "effect": effect
            })

        step_result["state_after"] = current_state.copy()
        step_result["consequences"] = consequence_result.get("consequences", [])
        trajectory.append(step_result)

    return {
        "final_state": current_state,
        "trajectory": trajectory,
        "risks": risks,
        "steps_executed": steps_executed,
        "steps_requested": len(actions)
    }


def _analyze_causality(text: str, context: str = "") -> Dict[str, Any]:
    """
    Analyze the causal structure of text.
    """
    causes = []
    effects = []
    relationships = []

    text_lower = text.lower()

    # Look for explicit causal markers
    for keyword in CAUSAL_KEYWORDS["because"]:
        if keyword in text_lower:
            # Pattern: "X because Y" -> Y causes X
            parts = text_lower.split(keyword)
            if len(parts) == 2:
                effect_part = parts[0].strip()
                cause_part = parts[1].strip()
                causes.append(cause_part[:100])
                effects.append(effect_part[:100])
                relationships.append({
                    "cause": cause_part[:100],
                    "effect": effect_part[:100],
                    "type": "causes",
                    "marker": keyword
                })

    for keyword in CAUSAL_KEYWORDS["therefore"]:
        if keyword in text_lower:
            # Pattern: "X therefore Y" -> X causes Y
            parts = text_lower.split(keyword)
            if len(parts) == 2:
                cause_part = parts[0].strip()
                effect_part = parts[1].strip()
                causes.append(cause_part[:100])
                effects.append(effect_part[:100])
                relationships.append({
                    "cause": cause_part[:100],
                    "effect": effect_part[:100],
                    "type": "causes",
                    "marker": keyword
                })

    for keyword in CAUSAL_KEYWORDS["if_then"]:
        if keyword in text_lower:
            # Pattern: "if X then Y" -> X enables/causes Y
            # Simple extraction
            if_match = re.search(rf"{keyword}\s+(.+?)(?:then|,|$)", text_lower)
            if if_match:
                condition = if_match.group(1).strip()[:100]
                causes.append(condition)
                relationships.append({
                    "cause": condition,
                    "effect": "(conditional outcome)",
                    "type": "enables",
                    "marker": keyword
                })

    # Deduplicate
    causes = list(set(causes))
    effects = list(set(effects))

    return {
        "causes": causes,
        "effects": effects,
        "relationships": relationships,
        "causal_keywords_found": _extract_causal_keywords(text),
        "has_causal_structure": len(relationships) > 0
    }


def _handle_why_question(question: str, context: str = "") -> Dict[str, Any]:
    """
    Handle a "why" question by identifying causal factors.
    """
    # Extract the subject of the why question
    why_match = re.search(r"why\s+(?:does?|did|is|are|was|were|do)?\s*(.+?)(?:\?|$)", question.lower())

    if why_match:
        subject = why_match.group(1).strip()
    else:
        subject = question.replace("why", "").strip()

    factors = []
    explanation_parts = []

    # Check domain patterns
    domain = _identify_domain(question, context)
    patterns = _get_relevant_patterns(domain)

    for pattern in patterns:
        if pattern["effect"].lower() in subject.lower():
            factors.append({
                "factor": pattern["cause"],
                "relation": pattern["type"],
                "confidence": 0.7
            })
            explanation_parts.append(f"{pattern['cause']} {pattern['type']} {pattern['effect']}")

    # Check memory for learned explanations
    try:
        learned = _memory.retrieve(
            query=f"explanation: {subject}",
            limit=3,
            tiers=["stm", "mtm", "ltm"]
        )
        for rec in learned:
            if rec.get("kind") == "causal_explanation":
                content = rec.get("content", "")
                factors.append({
                    "factor": content,
                    "relation": "explains",
                    "confidence": rec.get("confidence", 0.5),
                    "source": "learned"
                })
    except Exception:
        pass

    # Build explanation
    if explanation_parts:
        explanation = "; ".join(explanation_parts[:3])
        confidence = 0.7
    elif factors:
        explanation = f"Possible factors: {', '.join(f['factor'] for f in factors[:3])}"
        confidence = 0.5
    else:
        # Low confidence - use Teacher to learn
        explanation = f"No known causal factors for: {subject}"
        confidence = 0.2

        # LEARNING: Ask Teacher for causal explanation
        if _teacher_helper and confidence < 0.5:
            try:
                teacher_result = _teacher_helper.maybe_call_teacher(
                    question=f"""Explain the causal factors for: {question}

Context: {context if context else "General question"}

Provide:
1. The main causal factors (causes)
2. How they lead to the effect
3. Confidence level (0.0-1.0)

Be concise and focus on the key causal relationships.""",
                    context={"subject": subject, "domain": _identify_domain(question, context)}
                )

                if teacher_result and teacher_result.get("answer"):
                    learned_explanation = teacher_result["answer"]
                    explanation = learned_explanation[:500]
                    confidence = 0.6

                    # Store the learned explanation
                    try:
                        _memory.store(
                            content=learned_explanation,
                            metadata={
                                "kind": "causal_explanation",
                                "question": question,
                                "subject": subject,
                                "confidence": 0.6,
                                "source": "teacher"
                            }
                        )
                        print(f"[CAUSAL] Learned causal explanation for: {subject}")
                    except Exception:
                        pass

                    factors.append({
                        "factor": learned_explanation[:200],
                        "relation": "explains",
                        "confidence": 0.6,
                        "source": "teacher"
                    })
            except Exception as e:
                print(f"[CAUSAL] Teacher learning failed: {e}")

    return {
        "explanation": explanation,
        "factors": factors,
        "confidence": confidence,
        "question": question,
        "subject": subject
    }


def _store_causal_pattern(
    cause: str,
    effect: str,
    relation: str,
    confidence: float,
    source: str = "learned"
) -> bool:
    """Store a learned causal pattern to memory."""
    try:
        _memory.store(
            content={
                "cause": cause,
                "effect": effect,
                "relation": relation
            },
            metadata={
                "kind": "causal_pattern",
                "confidence": confidence,
                "source": source
            }
        )
        return True
    except Exception:
        return False


def handle(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Main entry point for the causal reasoning brain.

    Implements the cognitive brain contract.
    """
    op = (msg or {}).get("op", "").upper()
    payload = (msg or {}).get("payload", {}) or {}
    mid = msg.get("message_id", "")

    # COGNITIVE BRAIN CONTRACT: Detect continuation
    continuation_detected = False
    conv_context = {}

    if _continuation_helpers_available:
        try:
            query = (payload.get("query") or payload.get("question") or
                    payload.get("text") or payload.get("action") or "")
            if query:
                continuation_detected = is_continuation(query, payload)
                if continuation_detected:
                    conv_context = get_conversation_context()
                    payload["continuation_detected"] = True
                    payload["last_topic"] = conv_context.get("last_topic", "")
        except Exception:
            pass

    # Route to appropriate handler
    result: Dict[str, Any] = {}

    if op == "INFER_CONSEQUENCE":
        action = str(payload.get("action", "")).strip()
        state = payload.get("state", {}) or {}
        context = str(payload.get("context", "")).strip()

        if not action:
            result = {"error": "Missing 'action' in payload"}
        else:
            result = _infer_consequence(action, state, context)

    elif op == "EVALUATE_COUNTERFACTUAL":
        event = str(payload.get("event", "")).strip()
        context = str(payload.get("context", "")).strip()
        alternative = str(payload.get("alternative", "")).strip()

        if not event:
            result = {"error": "Missing 'event' in payload"}
        else:
            result = _evaluate_counterfactual(event, context, alternative)

    elif op == "BUILD_CAUSAL_CHAIN":
        premise = str(payload.get("premise", "")).strip()
        conclusion = str(payload.get("conclusion", "")).strip()
        context = str(payload.get("context", "")).strip()

        if not premise or not conclusion:
            result = {"error": "Missing 'premise' or 'conclusion' in payload"}
        else:
            result = _build_causal_chain(premise, conclusion, context)

    elif op == "SIMULATE_SCENARIO":
        initial_state = payload.get("initial_state", {}) or {}
        actions = payload.get("actions", []) or []
        max_steps = int(payload.get("steps", 10))

        if not actions:
            result = {"error": "Missing 'actions' in payload"}
        else:
            result = _simulate_scenario(initial_state, actions, max_steps)

    elif op == "ANALYZE_CAUSALITY":
        text = str(payload.get("text", "")).strip()
        context = str(payload.get("context", "")).strip()

        if not text:
            result = {"error": "Missing 'text' in payload"}
        else:
            result = _analyze_causality(text, context)

    elif op == "WHY_QUESTION":
        question = str(payload.get("question", "")).strip()
        context = str(payload.get("context", "")).strip()

        if not question:
            result = {"error": "Missing 'question' in payload"}
        else:
            result = _handle_why_question(question, context)

    elif op == "LEARN_PATTERN":
        # Learn a new causal pattern
        cause = str(payload.get("cause", "")).strip()
        effect = str(payload.get("effect", "")).strip()
        relation = str(payload.get("relation", "causes")).strip()
        confidence = float(payload.get("confidence", 0.7))

        if not cause or not effect:
            result = {"error": "Missing 'cause' or 'effect' in payload"}
        else:
            success = _store_causal_pattern(cause, effect, relation, confidence)
            result = {"stored": success, "pattern": {"cause": cause, "effect": effect, "relation": relation}}

    elif op == "GET_PATTERNS":
        # Retrieve known patterns for a domain
        domain = str(payload.get("domain", "")).strip() or "physical"
        patterns = _get_relevant_patterns(domain)
        result = {"domain": domain, "patterns": patterns, "count": len(patterns)}

    # =========================================================================
    # LLM-ENHANCED OPERATIONS for AGI-level what-if analysis
    # =========================================================================

    elif op == "WHAT_IF_LLM":
        """
        LLM-enhanced what-if analysis for complex scenarios.
        Combines rule-based reasoning with LLM for deeper analysis.
        """
        action = str(payload.get("action", "")).strip()
        context = str(payload.get("context", "")).strip()
        state = payload.get("state", {}) or {}

        if not action:
            result = {"error": "Missing 'action' in payload"}
        else:
            # Get rule-based analysis first
            rule_based = _infer_consequence(action, state, context)

            # Enhance with LLM analysis
            llm_result = _llm_what_if_analysis(action, context, state)

            result = {
                "rule_based_analysis": rule_based,
                "llm_enhanced": llm_result.get("enhanced", False),
                "llm_analysis": llm_result.get("llm_analysis", ""),
                "combined_risk_level": rule_based.get("risk_level", "low"),
                "combined_confidence": rule_based.get("confidence", 0.5),
            }

            # If LLM detected higher risk, update combined assessment
            if llm_result.get("enhanced"):
                # Store the combined analysis for learning
                try:
                    _memory.store(
                        content={
                            "action": action,
                            "context": context,
                            "rule_based_risk": rule_based.get("risk_level"),
                            "llm_analysis": llm_result.get("llm_analysis", "")[:200],
                        },
                        metadata={
                            "kind": "what_if_analysis",
                            "confidence": 0.8,
                            "source": "llm_enhanced"
                        }
                    )
                except Exception:
                    pass

    elif op == "PREDICT_SAFETY":
        """
        LLM-enhanced safety prediction for planning integration.
        Used by the planner brain before executing actions.
        """
        action = str(payload.get("action", "")).strip()
        context = str(payload.get("context", "")).strip()
        state = payload.get("state", {}) or {}

        if not action:
            result = {"error": "Missing 'action' in payload"}
        else:
            # Rule-based risk assessment
            risk_level, risk_score, risk_factors = _assess_action_risk(action, state)

            # LLM safety analysis
            llm_safety = _llm_safety_prediction(action, context)

            # Combine assessments
            final_risk_level = risk_level
            if llm_safety.get("enhanced"):
                llm_risk = llm_safety.get("risk_level", "medium")
                # Take the higher risk level
                risk_hierarchy = {"low": 0, "medium": 1, "high": 2, "critical": 3}
                if risk_hierarchy.get(llm_risk, 1) > risk_hierarchy.get(risk_level, 1):
                    final_risk_level = llm_risk

            result = {
                "action": action,
                "risk_level": final_risk_level,
                "risk_score": risk_score,
                "risk_factors": risk_factors,
                "safe_to_proceed": final_risk_level not in ["high", "critical"],
                "llm_enhanced": llm_safety.get("enhanced", False),
                "safety_analysis": llm_safety.get("safety_analysis", ""),
                "reversible": llm_safety.get("reversible", True),
                "precautions": risk_factors,
            }

    elif op == "EXPLAIN_WHY_LLM":
        """
        LLM-enhanced causal explanation for complex why questions.
        """
        question = str(payload.get("question", "")).strip()
        context = str(payload.get("context", "")).strip()

        if not question:
            result = {"error": "Missing 'question' in payload"}
        else:
            # Get rule-based explanation
            rule_based = _handle_why_question(question, context)

            # Enhance with LLM
            llm_result = _llm_causal_explanation(question, context)

            result = {
                "question": question,
                "rule_based_explanation": rule_based.get("explanation", ""),
                "rule_based_factors": rule_based.get("factors", []),
                "llm_enhanced": llm_result.get("enhanced", False),
                "llm_explanation": llm_result.get("causal_explanation", ""),
                "combined_confidence": rule_based.get("confidence", 0.5),
            }

            # If LLM enhanced, boost confidence
            if llm_result.get("enhanced"):
                result["combined_confidence"] = min(1.0, result["combined_confidence"] + 0.2)

    elif op == "DEEP_CONSEQUENCE_CHAIN":
        """
        Build a deep consequence chain using both rules and LLM.
        Useful for complex planning scenarios.
        """
        action = str(payload.get("action", "")).strip()
        context = str(payload.get("context", "")).strip()
        depth = int(payload.get("depth", 3))

        if not action:
            result = {"error": "Missing 'action' in payload"}
        else:
            chain = []
            current_action = action
            current_state = payload.get("initial_state", {}) or {}

            for i in range(depth):
                # Infer consequence of current action
                cons = _infer_consequence(current_action, current_state, context)

                step = {
                    "level": i + 1,
                    "action": current_action,
                    "consequences": cons.get("consequences", []),
                    "risk_level": cons.get("risk_level", "low"),
                }

                chain.append(step)

                # Get next action from consequences
                if cons.get("consequences"):
                    next_effect = cons["consequences"][0].get("effect", "")
                    current_action = next_effect
                    current_state["last_effect"] = next_effect
                else:
                    break

            # Use LLM for overall chain analysis if available
            llm_chain = _llm_what_if_analysis(
                f"Chain of actions starting with: {action}",
                f"Context: {context}. Chain depth: {depth}",
                {"chain": [s["action"] for s in chain]}
            )

            result = {
                "chain": chain,
                "depth_achieved": len(chain),
                "overall_risk": max(
                    (s.get("risk_level", "low") for s in chain),
                    key=lambda x: {"low": 0, "medium": 1, "high": 2, "critical": 3}.get(x, 0)
                ),
                "llm_chain_analysis": llm_chain.get("llm_analysis", "") if llm_chain.get("enhanced") else "",
            }

    else:
        result = {"error": f"Unknown operation: {op}"}

    # Add routing hint for cognitive brain contract
    if _continuation_helpers_available:
        try:
            routing_hint = create_routing_hint(
                brain_name="causal_reasoning",
                action=op.lower(),
                confidence=0.8,
                context_tags=["causal", "reasoning", "continuation" if continuation_detected else "fresh"]
            )
            result["routing_hint"] = routing_hint
        except Exception:
            pass

    return {
        "ok": "error" not in result,
        "op": op,
        "message_id": mid,
        "payload": result
    }


# Alias for service contract
service_api = handle
