"""
Response Length Planner
=======================

Dynamically decides response length mode (short/medium/long/step_by_step) for each turn
BEFORE generating the answer. Uses LLM-based decisions driven by semantics, user
preferences, and context - not token counting or hard-coded lengths.

Pipeline order:
1. Normalizer
2. Routing engine
3. Response-length engine (THIS MODULE) - calls Teacher for dynamic decisions
4. Reasoning / Teacher / research_manager
5. Answer formatting
6. Reflection

Decision Flow:
1. Check explicit user overrides (e.g., "tldr", "step by step") - skip LLM if found
2. If no override, call Teacher with length_planning mode for dynamic decision
3. Apply safety post-processing (bump "short" to "medium" for sensitive topics)
4. Return ResponsePlan that flows through to downstream stages

Usage:
    from brains.cognitive.response_planner import plan_response_length

    result = plan_response_length(
        user_text="explain how Maven's routing works",
        task_type="explanation",
        tools_selected=["language", "reasoning"],
        research_enabled=False,
        conversation_depth=3,
        user_profile=None,  # Optional
        recent_behavior=None,  # Optional
        routing_info=None,  # Optional - from routing engine
        conversation_snippet=None,  # Optional - last 3-5 turns
    )

    # result.length_mode = "long"
    # result.style_hints = {"step_by_step": True, "include_examples": True}
    # result.tone = "technical"
"""

from __future__ import annotations

import json
import re
import hashlib
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


# =============================================================================
# LEARNING CACHE - Avoid redundant LLM calls for identical decisions
# =============================================================================
# This cache stores length planning decisions by task_type + query pattern.
# For simple queries (greetings, small_talk), we return cached decisions.
# This prevents calling the LLM twice for "hi", "hello", etc.

_length_decision_cache: Dict[str, Dict[str, Any]] = {}
_CACHE_MAX_SIZE = 200

# Task types that can be cached (simple, deterministic decisions)
_CACHEABLE_TASK_TYPES = {
    "small_talk", "greeting", "farewell", "simple_fact", "confirmation",
    "compliment", "definition",
}

# =============================================================================
# SMALL TALK PATTERNS - Force brief mode (FIX 2)
# =============================================================================
# These patterns should ALWAYS get brief/short responses.
# Small talk like "hi" and "how are you" should NOT trigger long explanations.

SMALL_TALK_PATTERNS = [
    "how are you",
    "how's it going",
    "what's up",
    "how are things",
    "how have you been",
    "how do you do",
    "you doing ok",
    "are you ok",
    "you good",
    "you there",
]

# Task types that MUST use brief/short mode (never override to long)
BRIEF_MODE_TASK_TYPES = {
    "small_talk",
    "greeting",
    "farewell",
    "confirmation",
    "feedback",
}


def _is_small_talk(text: str, task_type: str) -> bool:
    """
    Check if input is small talk that requires brief response.

    Args:
        text: User input text
        task_type: Task type from routing

    Returns:
        True if this is small talk
    """
    # Check task type first (most reliable - from routing ladder)
    if task_type in BRIEF_MODE_TASK_TYPES:
        return True

    # Check text patterns as fallback
    text_lower = text.lower().strip()
    for pattern in SMALL_TALK_PATTERNS:
        if pattern in text_lower:
            return True

    return False


def _force_brief_mode_for_small_talk(
    task_type: str,
    text: str,
) -> Optional[Tuple[str, str]]:
    """
    Force brief mode for small talk (FIX 2).

    Returns (mode, reason) if small talk detected, None otherwise.
    """
    if _is_small_talk(text, task_type):
        return ("short", f"small_talk_forced_brief: task_type={task_type}")
    return None


def _get_length_cache_key(task_type: str, user_text: str, safety_sensitive: bool) -> str:
    """Generate a cache key for length planning decisions."""
    # For simple task types, just use task_type (decisions are deterministic)
    if task_type in _CACHEABLE_TASK_TYPES and not safety_sensitive:
        return f"simple_{task_type}"

    # For more complex types, include a hash of the user text
    text_hash = hashlib.md5(user_text.lower().strip()[:100].encode()).hexdigest()[:8]
    return f"{task_type}_{text_hash}_{safety_sensitive}"


def _get_cached_length_decision(task_type: str, user_text: str, safety_sensitive: bool) -> Optional[Dict[str, Any]]:
    """Look up a cached length planning decision."""
    key = _get_length_cache_key(task_type, user_text, safety_sensitive)
    cached = _length_decision_cache.get(key)
    if cached:
        print(f"[LENGTH_PLANNER] Cache HIT for task_type={task_type} - skipping LLM")
        return cached
    return None


def _store_length_decision(
    task_type: str,
    user_text: str,
    safety_sensitive: bool,
    decision: Dict[str, Any]
) -> None:
    """Store a length planning decision in the cache."""
    global _length_decision_cache

    # Evict oldest entries if cache is too large
    if len(_length_decision_cache) >= _CACHE_MAX_SIZE:
        keys = list(_length_decision_cache.keys())
        for k in keys[:_CACHE_MAX_SIZE // 2]:
            del _length_decision_cache[k]

    key = _get_length_cache_key(task_type, user_text, safety_sensitive)
    _length_decision_cache[key] = decision
    print(f"[LENGTH_PLANNER] Cached decision for task_type={task_type} (cache size: {len(_length_decision_cache)})")


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class StyleHints:
    """Style hints for response generation."""
    step_by_step: bool = False
    high_level: bool = False
    include_examples: bool = False


@dataclass
class StructureMirror:
    """
    Structure mirroring hints for multi-agent conversations.

    When Maven receives questions from another AI (ChatGPT, Claude, Grok),
    the response should mirror the structure of the input:
    - Numbered list → Numbered response
    - Bulleted list → Bulleted response
    - Prose → Prose response

    This creates natural, coherent multi-agent dialogue.
    """
    input_structure: str = "prose"  # "numbered", "bulleted", "prose", "headings", "single"
    question_count: int = 1  # How many questions were asked
    original_markers: List[str] = field(default_factory=list)  # ["1.", "2.", "3."] or ["-", "-", "-"]
    mirror_structure: bool = True  # Whether to mirror the input structure
    add_summary: bool = True  # Add a Maven summary after answering
    summary_style: str = "brief"  # "brief", "connecting", "expansive"

    def get_response_template(self) -> Dict[str, Any]:
        """
        Get a response template that mirrors the input structure.

        Returns:
            Template dict with structure hints for response generation.
        """
        if self.input_structure == "numbered":
            return {
                "format": "numbered",
                "prefix_pattern": "{}. ",
                "section_separator": "\n\n",
                "add_headers": False,
                "answer_each_question": True,
            }
        elif self.input_structure == "bulleted":
            return {
                "format": "bulleted",
                "prefix_pattern": "- ",
                "section_separator": "\n",
                "add_headers": False,
                "answer_each_question": True,
            }
        elif self.input_structure == "headings":
            return {
                "format": "headings",
                "prefix_pattern": "## ",
                "section_separator": "\n\n",
                "add_headers": True,
                "answer_each_question": True,
            }
        else:  # prose or single
            return {
                "format": "prose",
                "prefix_pattern": "",
                "section_separator": "\n\n",
                "add_headers": False,
                "answer_each_question": self.question_count > 1,
            }


@dataclass
class NumericHints:
    """Numeric limits for response generation."""
    target_sections: int = 2
    target_points_per_section: int = 3
    max_tokens_hint: int = 500


@dataclass
class ResponsePlan:
    """Complete response plan for a turn."""
    length_mode: str  # "short", "medium", "long", "step_by_step"
    style_hints: StyleHints
    numeric_hints: NumericHints
    detail_need: float  # 0-1, how much detail the task needs
    brevity_pref: float  # 0-1, how much user prefers brevity
    length_score: float  # Combined score (for compatibility)
    reason: str  # Why this mode was chosen
    tone: str = "neutral"  # "neutral", "technical", "friendly"
    llm_decision: bool = False  # True if decision came from LLM
    structure_mirror: Optional[StructureMirror] = None  # Multi-agent structure mirroring


@dataclass
class UserProfile:
    """User preferences for response length."""
    prefers_brevity: float = 0.5  # 0-1, higher = prefers shorter
    prefers_detail: float = 0.5  # 0-1, higher = prefers longer
    technical_level: float = 0.5  # 0-1, higher = more technical


@dataclass
class RecentBehavior:
    """Recent user behavior signals."""
    explain_more_count: int = 0  # "explain more", "go deeper" requests
    too_long_count: int = 0  # "too long", "tl;dr" complaints
    turn_window: int = 10  # How many turns to consider
    asked_for_more_detail_recently: bool = False
    complained_about_length_recently: bool = False


@dataclass
class RoutingInfo:
    """Routing information passed from routing engine."""
    task_type: str = "default"
    selected_brains: List[str] = field(default_factory=list)
    selected_tools: List[str] = field(default_factory=list)
    safety_sensitive: bool = False
    research_enabled: bool = False


# =============================================================================
# MODE CONFIGURATIONS
# =============================================================================

# Map from new mode names to configs
LENGTH_MODE_CONFIGS = {
    "short": {
        "target_sections": 1,
        "target_points_per_section": 3,
        "max_tokens_hint": 150,
        "style": StyleHints(
            high_level=True,
            step_by_step=False,
            include_examples=False,
        ),
    },
    "medium": {
        "target_sections": 2,
        "target_points_per_section": 4,
        "max_tokens_hint": 400,
        "style": StyleHints(
            high_level=True,
            step_by_step=False,
            include_examples=False,
        ),
    },
    "long": {
        "target_sections": 5,  # More sections for comprehensive coverage
        "target_points_per_section": 5,
        "max_tokens_hint": 1000,  # Allow longer responses
        "style": StyleHints(
            high_level=False,
            step_by_step=False,  # Structured but not necessarily numbered steps
            include_examples=True,
        ),
    },
    "step_by_step": {
        "target_sections": 7,  # More steps for thorough coverage
        "target_points_per_section": 4,
        "max_tokens_hint": 1500,  # Allow comprehensive step-by-step
        "style": StyleHints(
            high_level=False,
            step_by_step=True,  # Numbered steps required
            include_examples=True,
        ),
    },
    # Legacy mode mappings for backward compatibility
    "brief": {
        "target_sections": 1,
        "target_points_per_section": 3,
        "max_tokens_hint": 150,
        "style": StyleHints(high_level=True, step_by_step=False, include_examples=False),
    },
    "normal": {
        "target_sections": 2,
        "target_points_per_section": 4,
        "max_tokens_hint": 400,
        "style": StyleHints(high_level=True, step_by_step=False, include_examples=False),
    },
    "detailed": {
        "target_sections": 4,
        "target_points_per_section": 5,
        "max_tokens_hint": 800,
        "style": StyleHints(high_level=False, step_by_step=True, include_examples=True),
    },
    "exhaustive": {
        "target_sections": 6,
        "target_points_per_section": 6,
        "max_tokens_hint": 1500,
        "style": StyleHints(high_level=False, step_by_step=True, include_examples=True),
    },
}

# Map legacy modes to new modes
LEGACY_MODE_MAP = {
    "brief": "short",
    "normal": "medium",
    "detailed": "long",
    "exhaustive": "step_by_step",
}

# =============================================================================
# PROMPT TEMPLATES
# =============================================================================

# =============================================================================
# LENGTH MODE PROMPT TEMPLATES (2.1 - Explicit templates for each mode)
# =============================================================================
# These are the AUTHORITATIVE templates injected into Teacher/reasoning prompts.
# Switch templates based ONLY on response_plan.length_mode.

LENGTH_MODE_PROMPTS = {
    "short": (
        "Be CONCISE. Answer in 1-2 short paragraphs OR 3-5 bullet points maximum.\n"
        "- Only provide the core answer - no background, no tangents\n"
        "- Skip examples unless absolutely necessary\n"
        "- Do NOT add sections or headers\n"
        "- Get straight to the point"
    ),
    "medium": (
        "Provide a CLEAR answer with enough detail to understand the idea.\n"
        "- Use 2-3 short sections or a paragraph followed by bullets\n"
        "- Explain enough to understand, but no deep dive\n"
        "- One brief example is okay if it helps clarity\n"
        "- Avoid unnecessary tangents or excessive detail"
    ),
    "long": (
        "Provide a DETAILED, comprehensive answer with MULTIPLE SECTIONS.\n\n"
        "REQUIRED STRUCTURE:\n"
        "1. Introduction (1-2 sentences setting context)\n"
        "2. 3-5 main sections with **headers**, each containing:\n"
        "   - 3-5 bullet points covering key concepts\n"
        "   - Underlying principles and rationale\n"
        "3. Common pitfalls or misconceptions (if relevant)\n"
        "4. Practical implications or applications\n"
        "5. At least ONE concrete example\n\n"
        "This should be a THOROUGH explanation, NOT a brief overview.\n"
        "Cover the topic comprehensively as if teaching someone new to it."
    ),
    "step_by_step": (
        "Provide a DETAILED, step-by-step answer with NUMBERED STEPS.\n\n"
        "REQUIRED STRUCTURE:\n"
        "1. Brief introduction (1-2 sentences)\n"
        "2. Numbered steps (at least 5-7 for complex topics):\n"
        "   - Step label: Clear, actionable title\n"
        "   - WHAT: What to do in this step\n"
        "   - WHY: Why this step matters\n"
        "   - Pitfall: Common mistakes to avoid (where relevant)\n"
        "3. Concrete examples for at least 2 steps\n"
        "4. Summary or key takeaways at the end\n\n"
        "This should be comprehensive enough to ACTUALLY TEACH someone the topic."
    ),
    # Legacy mappings (keep for backward compatibility)
    "brief": (
        "Be CONCISE. Answer in 1-2 short paragraphs OR 3-5 bullet points maximum.\n"
        "Only provide the core answer - no background, no tangents."
    ),
    "normal": (
        "Provide a CLEAR answer with enough detail to understand the idea.\n"
        "Use 2-3 short sections. Avoid unnecessary tangents."
    ),
    "detailed": (
        "Provide a DETAILED, comprehensive answer with MULTIPLE SECTIONS.\n"
        "Cover main concepts, rationale, and include at least one example.\n"
        "Structure with headers and bullet points."
    ),
    "exhaustive": (
        "Provide a DETAILED, step-by-step answer with NUMBERED STEPS.\n"
        "Include comprehensive explanations and concrete examples for each step."
    ),
}

# =============================================================================
# TASK TYPE BASE SCORES (for heuristic fallback)
# =============================================================================

TASK_TYPE_DETAIL_SCORES = {
    # Simple tasks - low detail need -> "short"
    "simple_fact": 0.2,
    "definition": 0.3,
    "confirmation": 0.1,
    "greeting": 0.1,
    "compliment": 0.1,

    # Moderate-to-detailed tasks -> "medium" to "long"
    "explanation": 0.65,  # Explanations need detail -> "long"
    "conceptual": 0.6,
    "comparison": 0.55,
    "recommendation": 0.5,
    "factual_query": 0.4,

    # Complex tasks - high detail need -> "long"
    "troubleshooting": 0.75,
    "planning": 0.75,
    "debugging": 0.75,
    "code": 0.6,
    "code_review": 0.7,
    "analysis": 0.7,

    # Very complex tasks -> "step_by_step"
    "architecture": 0.85,
    "design": 0.8,
    "tutorial": 0.85,
    "safety_sensitive": 0.8,
    "research": 0.75,

    # Self-questions - variable based on question type
    "self_identity": 0.45,          # "who are you" -> medium
    "self_architecture": 0.7,       # "how do you work" -> long
    "self_architecture_detail": 0.85,  # "explain your brains in detail" -> step_by_step
    "self_capabilities": 0.5,       # "what can you do" -> medium
    "self_brains": 0.6,             # "what are your brains" -> long
    "self_tools": 0.55,             # "what tools" -> medium/long
    "self_comparison": 0.6,         # "different from ChatGPT" -> long
    "self_health": 0.4,             # "system health" -> medium
    "self_count": 0.35,             # "how many brains" -> short/medium
    "self_memory": 0.6,             # "how does your memory work" -> long
    "self_learning": 0.65,          # "how do you learn" -> long

    # Default
    "default": 0.5,
    "generic_reasoning": 0.5,

    # User profile queries (about stored facts about the user)
    # These should be short/medium - just recalling stored facts, not teaching
    "user_profile": 0.35,
}

# Broad educational topics that warrant detailed explanations
BROAD_TOPICS = [
    "physics", "chemistry", "biology", "math", "science", "history",
    "economics", "philosophy", "psychology", "sociology", "politics",
    "programming", "computing", "engineering", "medicine", "law",
    "ai", "machine learning", "artificial intelligence", "maven",
]

# =============================================================================
# 5.1: TASK TYPE CLASSIFICATION
# =============================================================================
# Map user messages to task_type more precisely for better length decisions

def classify_task_type(user_text: str, context: Optional[Dict[str, Any]] = None) -> str:
    """
    5.1: Classify task type from user message.

    Maps user messages to task_type for routing and length planning:
    - "explain X", "what is X", "how does X work" -> "explanation"
    - "debug", "error", "not working" -> "troubleshooting"
    - "plan", "design", "roadmap" -> "planning"
    - "who is X", simple fact -> "simple_fact"

    Args:
        user_text: The user's message (should be normalized)
        context: Optional context with hints

    Returns:
        Task type string
    """
    if not user_text:
        return "default"

    text_lower = user_text.lower().strip()

    # 0. User profile queries -> task_type="user_profile"
    # These are queries about what Maven knows about the user themselves
    user_profile_markers = [
        "tell me about myself", "tell me about me", "what do you know about me",
        "what do you know about myself", "what have you learned about me",
        "what did you learn about me", "what do you remember about me",
        "who am i", "describe me", "what have i told you about myself",
        "what have i shared with you", "what facts do you know about me",
        "summarize what you know about me", "my profile", "about me",
        "what do you know about josh", "what do you know about your creator",
        "what do you know about your owner", "tell me about josh", "who is josh",
    ]
    if any(marker in text_lower for marker in user_profile_markers):
        return "user_profile"

    # 1. Explanation/teaching requests -> task_type="explanation"
    explanation_starts = [
        "explain", "what is", "what are", "how does", "how do", "how is",
        "teach me", "help me understand", "describe", "tell me about",
        "why does", "why do", "why is", "what does", "can you explain",
    ]
    if any(text_lower.startswith(phrase) for phrase in explanation_starts):
        return "explanation"

    # 2. Troubleshooting/debugging -> task_type="troubleshooting"
    troubleshooting_markers = [
        "debug", "debugger", "error", "exception", "bug", "issue",
        "not working", "doesn't work", "won't work", "broken", "fails",
        "failing", "failed", "crash", "crashed", "crashing",
        "fix", "fixing", "help me fix", "problem with", "trouble with",
        "what's wrong", "why isn't", "why won't", "why does it",
    ]
    if any(marker in text_lower for marker in troubleshooting_markers):
        return "troubleshooting"

    # 3. Planning/design -> task_type="planning"
    planning_markers = [
        "plan", "planning", "design", "architect", "architecture",
        "roadmap", "strategy", "strategize", "outline", "structure",
        "how should i", "how would i", "approach to", "best way to",
        "steps to", "process for", "method for",
    ]
    if any(marker in text_lower for marker in planning_markers):
        return "planning"

    # 4. Code tasks -> task_type="code"
    code_markers = [
        "write code", "write a function", "implement", "create a",
        "code for", "coding", "write me", "script", "program",
        "refactor", "optimize code", "function that", "class that",
    ]
    if any(marker in text_lower for marker in code_markers):
        return "code"

    # 5. Simple facts -> task_type="simple_fact"
    # Short queries asking "who", "when", "where" with no elaboration request
    simple_fact_starts = ["who is", "who was", "when did", "when was", "where is", "where was"]
    if any(text_lower.startswith(phrase) for phrase in simple_fact_starts):
        # Only classify as simple_fact if it's a short, direct question
        if len(text_lower.split()) <= 8 and "explain" not in text_lower:
            return "simple_fact"

    # 6. Definition requests -> task_type="definition"
    if text_lower.startswith("define ") or "definition of" in text_lower:
        return "definition"

    # 7. Comparison requests -> task_type="comparison"
    comparison_markers = ["compare", "vs", "versus", "difference between", "differences between"]
    if any(marker in text_lower for marker in comparison_markers):
        return "comparison"

    # 8. Tutorial/how-to -> task_type="tutorial"
    tutorial_markers = ["how to", "how do i", "tutorial", "guide me", "walkthrough"]
    if any(marker in text_lower for marker in tutorial_markers):
        return "tutorial"

    # 9. Greeting/small talk -> task_type="greeting"
    greetings = ["hello", "hi ", "hey ", "good morning", "good afternoon", "good evening", "howdy"]
    if any(text_lower.startswith(g) or text_lower == g.strip() for g in greetings):
        return "greeting"

    # 10. Check context hints
    if context:
        # Use context-provided task_type if available
        ctx_task_type = context.get("task_type")
        if ctx_task_type and ctx_task_type != "default":
            return ctx_task_type

    # Default
    return "default"


# =============================================================================
# 5.2: SPELLING ROBUSTNESS / TYPO CORRECTION
# =============================================================================
# Common typos for verbs and domain words

TYPO_CORRECTIONS = {
    # Verbs
    "expalin": "explain",
    "explian": "explain",
    "expliain": "explain",
    "desribe": "describe",
    "discribe": "describe",
    "descripbe": "describe",
    "waht": "what",
    "whta": "what",
    "hwo": "how",
    "howt": "how",
    "teh": "the",
    "taht": "that",
    "wiht": "with",
    "adn": "and",
    "nto": "not",
    "cna": "can",
    "jsut": "just",
    "hte": "the",
    # Domain words
    "phyiscs": "physics",
    "pyhsics": "physics",
    "physcs": "physics",
    "physcis": "physics",
    "chemisty": "chemistry",
    "chemsitry": "chemistry",
    "biolgoy": "biology",
    "boliology": "biology",
    "mathemtics": "mathematics",
    "mathmatics": "mathematics",
    "programing": "programming",
    "porgramming": "programming",
    "progrmaing": "programming",
    "enginering": "engineering",
    "enginnering": "engineering",
    "econmics": "economics",
    "econoimcs": "economics",
    "psycology": "psychology",
    "pshychology": "psychology",
    "philsophy": "philosophy",
    "philosphy": "philosophy",
    # Common question words
    "waht is": "what is",
    "hwo does": "how does",
    "hwo do": "how do",
    "explian to me": "explain to me",
}


def correct_common_typos(text: str) -> str:
    """
    5.2: Correct common typos in user input.

    This makes routing and length planning robust to spelling errors.

    Args:
        text: User input text

    Returns:
        Text with common typos corrected
    """
    if not text:
        return text

    result = text
    text_lower = text.lower()

    for typo, correction in TYPO_CORRECTIONS.items():
        if typo in text_lower:
            # Preserve original case if possible
            result = result.replace(typo, correction)
            result = result.replace(typo.capitalize(), correction.capitalize())
            result = result.replace(typo.upper(), correction.upper())

    return result


# =============================================================================
# EXPLICIT OVERRIDE DETECTION
# =============================================================================

# Phrases that force SHORT mode (no LLM call needed)
FORCE_SHORT_PHRASES = [
    "one sentence", "one line", "tl;dr", "tldr", "just the answer",
    "brief", "briefly", "quick", "quickly", "short answer",
]

# Phrases that force STEP_BY_STEP mode (no LLM call needed)
FORCE_STEP_BY_STEP_PHRASES = [
    "step by step", "step-by-step", "teach me", "walk me through",
    "detailed", "in detail", "comprehensive", "exhaustive",
    "deep dive", "thoroughly", "break down",
]


def _check_explicit_overrides(user_text: str) -> Optional[Tuple[str, str]]:
    """
    Check for explicit user requests that override LLM decision.

    Returns (mode, reason) if override found, None otherwise.
    """
    text_lower = user_text.lower()

    # Check for explicit short requests
    for phrase in FORCE_SHORT_PHRASES:
        if phrase in text_lower:
            return ("short", f"explicit_short_request: '{phrase}'")

    # Check for explicit detailed/step-by-step requests
    for phrase in FORCE_STEP_BY_STEP_PHRASES:
        if phrase in text_lower:
            return ("step_by_step", f"explicit_step_by_step_request: '{phrase}'")

    return None


# =============================================================================
# LLM-BASED LENGTH PLANNING
# =============================================================================

def _call_llm_length_planner(
    user_text: str,
    routing_info: Optional[RoutingInfo],
    user_profile: Optional[UserProfile],
    conversation_snippet: Optional[str],
    recent_behavior: Optional[RecentBehavior],
) -> Optional[Dict[str, Any]]:
    """
    Call Teacher with length_planning mode to get dynamic length decision.

    LEARNING: Results are cached by task_type for simple queries to avoid
    redundant LLM calls.

    Returns parsed JSON decision or None if LLM call fails.
    """
    # Build the situation context for the LLM
    routing = routing_info or RoutingInfo()
    profile = user_profile or UserProfile()
    behavior = recent_behavior or RecentBehavior()

    # LEARNING: Check cache first for simple task types
    # This avoids calling the LLM for "hi", "hello", etc.
    cached = _get_cached_length_decision(routing.task_type, user_text, routing.safety_sensitive)
    if cached:
        return cached

    try:
        # Import Teacher here to avoid circular imports
        from brains.cognitive.teacher.service.teacher_brain import teach_for_brain
    except ImportError as e:
        print(f"[LENGTH_PLANNER] Failed to import Teacher: {e}")
        return None

    situation = {
        "user_message": {
            "raw": user_text,
            "normalized": user_text,  # Already normalized by this point
        },
        "task_type": routing.task_type,
        "selected_brains": routing.selected_brains,
        "selected_tools": routing.selected_tools,
        "safety_sensitive": routing.safety_sensitive,
        "research_enabled": routing.research_enabled,
        "user_profile": {
            "prefers_brevity": profile.prefers_brevity,
            "prefers_detail": profile.prefers_detail,
            "technical_level": profile.technical_level,
        },
        "conversation_snippet": conversation_snippet or "",
        "recent_feedback": {
            "asked_for_more_detail_recently": behavior.asked_for_more_detail_recently,
            "complained_about_length_recently": behavior.complained_about_length_recently,
        },
    }

    try:
        # Call Teacher with the response_planner brain name
        print(f"[LENGTH_PLANNER] Calling teach_for_brain('response_planner') with situation keys: {list(situation.keys())}")
        result = teach_for_brain("response_planner", situation)
        print(f"[LENGTH_PLANNER] Teacher result: verdict={result.get('verdict')}, has_raw_response={bool(result.get('raw_response'))}")

        # Check for errors - teach_for_brain returns verdict, not ok
        if result.get("verdict") == "ERROR":
            print(f"[LENGTH_PLANNER] Teacher call ERROR: {result.get('error', 'no error msg')}")
            print(f"[LENGTH_PLANNER] Full result: {result}")
            return None

        # Parse the response - Teacher returns raw_response with the LLM output
        response_text = result.get("raw_response", "")
        if not response_text:
            print(f"[LENGTH_PLANNER] No raw_response in Teacher result. Result keys: {list(result.keys())}")
            print(f"[LENGTH_PLANNER] Patterns: {result.get('patterns', [])}")
            return None

        print(f"[LENGTH_PLANNER] Raw response: {response_text[:300]}...")

        # Try to extract JSON from the response - support nested braces
        json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', response_text, re.DOTALL)
        if json_match:
            try:
                parsed = json.loads(json_match.group())
                print(f"[LENGTH_PLANNER] LLM decision: {parsed}")

                # LEARNING: Cache the decision for future identical queries
                _store_length_decision(routing.task_type, user_text, routing.safety_sensitive, parsed)

                return parsed
            except json.JSONDecodeError as e:
                print(f"[LENGTH_PLANNER] JSON parse failed for: {json_match.group()[:200]}")
                print(f"[LENGTH_PLANNER] Parse error: {e}")

        print(f"[LENGTH_PLANNER] Could not find JSON in response: {response_text[:200]}")
        return None

    except json.JSONDecodeError as e:
        print(f"[LENGTH_PLANNER] JSON parse error: {e}")
        import traceback
        traceback.print_exc()
        return None
    except Exception as e:
        print(f"[LENGTH_PLANNER] LLM call error: {type(e).__name__}: {e}")
        import traceback
        traceback.print_exc()
        return None


def _apply_safety_postprocessing(
    mode: str,
    routing_info: Optional[RoutingInfo],
    user_text: str,
) -> Tuple[str, Optional[str], bool]:
    """
    7. Apply safety post-processing to the mode decision.

    For safety-sensitive topics (health, finance, legal, etc.):
    - Never use "short" mode -> bump to "medium"
    - Disable include_examples to avoid prescriptive playbooks
    - Ensures at least medium-length, context-aware answer with proper caveats

    Returns (final_mode, override_reason or None, disable_examples).
    """
    routing = routing_info or RoutingInfo()
    override_reason = None
    disable_examples = False

    # 7. SAFETY INTEGRATION
    # Safety-sensitive topics should never be ultra-short
    # Also disable examples to avoid giving prescriptive playbooks
    if routing.safety_sensitive:
        if mode == "short":
            mode = "medium"
            override_reason = "safety_bump: sensitive topic requires at least medium"
            print(f"[LENGTH_PLANNER] SAFETY: Bumping short->medium for safety-sensitive topic")
        # Disable examples for safety topics to avoid prescriptive advice
        disable_examples = True
        if override_reason:
            override_reason += "; examples disabled for safety"
        else:
            override_reason = "safety: examples disabled for sensitive topic"
        print(f"[LENGTH_PLANNER] SAFETY: Disabling examples for safety-sensitive topic")

    # Troubleshooting/planning tasks need at least medium unless user explicitly asked short
    if routing.task_type in ("troubleshooting", "planning", "debugging"):
        text_lower = user_text.lower()
        explicit_short = any(p in text_lower for p in FORCE_SHORT_PHRASES)
        if mode == "short" and not explicit_short:
            mode = "medium"
            override_reason = f"task_bump: {routing.task_type} needs at least medium"

    # Simple facts don't need step_by_step unless user asked
    if routing.task_type in ("simple_fact", "definition", "confirmation"):
        text_lower = user_text.lower()
        explicit_detailed = any(p in text_lower for p in FORCE_STEP_BY_STEP_PHRASES)
        if mode == "step_by_step" and not explicit_detailed:
            mode = "medium"
            override_reason = f"task_reduce: {routing.task_type} doesn't need step_by_step"

    # User profile queries should be short/medium (recalling facts, not teaching)
    # They pull stored facts from memory, not comprehensive explanations
    if routing.task_type == "user_profile":
        text_lower = user_text.lower()
        explicit_long = any(p in text_lower for p in FORCE_STEP_BY_STEP_PHRASES)
        if mode in ("long", "step_by_step") and not explicit_long:
            mode = "medium"
            override_reason = f"user_profile_reduce: profile queries don't need {mode}"
        # Disable examples for profile queries (they're about the user, not teaching)
        disable_examples = True
        if override_reason:
            override_reason += "; examples disabled for profile query"
        else:
            override_reason = "user_profile: examples disabled for profile query"

    return mode, override_reason, disable_examples


# =============================================================================
# HEURISTIC FALLBACK (when LLM fails)
# =============================================================================

def _heuristic_length_decision(
    user_text: str,
    routing_info: Optional[RoutingInfo],
    user_profile: Optional[UserProfile],
    recent_behavior: Optional[RecentBehavior],
) -> Tuple[str, float, float, str]:
    """
    Fallback heuristic-based length decision when LLM is unavailable.

    Returns (mode, detail_need, brevity_pref, reason).
    """
    routing = routing_info or RoutingInfo()
    profile = user_profile or UserProfile()
    behavior = recent_behavior or RecentBehavior()

    reasons = []
    text_lower = user_text.lower()

    # 1. Base score from task type
    base_score = TASK_TYPE_DETAIL_SCORES.get(routing.task_type, 0.5)
    reasons.append(f"task={routing.task_type}({base_score:.2f})")

    # 2. Query complexity adjustments
    word_count = len(user_text.split())
    if word_count > 30:
        base_score += 0.1
        reasons.append("long_query(+0.1)")
    elif word_count < 10:
        # Don't penalize short queries for explanation tasks
        if routing.task_type not in ("explanation", "conceptual", "tutorial"):
            base_score -= 0.1
            reasons.append("short_query(-0.1)")

    # 3. Broad educational topics boost detail need
    if any(topic in text_lower for topic in BROAD_TOPICS):
        base_score += 0.15
        reasons.append("broad_topic(+0.15)")

    # 4. Research enabled boosts detail need
    if routing.research_enabled:
        base_score += 0.2
        reasons.append("research(+0.2)")

    # 5. User profile adjustments
    brevity_pref = profile.prefers_brevity
    if profile.prefers_detail > 0.6:
        brevity_pref -= 0.2
    elif profile.prefers_detail < 0.4:
        brevity_pref += 0.1

    # 5. Recent behavior adjustments
    if behavior.asked_for_more_detail_recently:
        brevity_pref -= 0.15
        reasons.append("wants_more_detail(-0.15)")
    if behavior.complained_about_length_recently:
        brevity_pref += 0.15
        reasons.append("wants_shorter(+0.15)")

    # 6. Combine into length score
    brevity_adjustment = 0.5 * (0.5 - brevity_pref)
    length_score = max(0.0, min(1.0, base_score + brevity_adjustment))

    # 7. Map to mode
    if length_score < 0.25:
        mode = "short"
    elif length_score < 0.5:
        mode = "medium"
    elif length_score < 0.75:
        mode = "long"
    else:
        mode = "step_by_step"

    detail_need = base_score
    reason = "heuristic: " + ", ".join(reasons)

    return mode, detail_need, brevity_pref, reason


# =============================================================================
# STRUCTURE MIRRORING
# =============================================================================

def create_structure_mirror(question_batch: Any) -> Optional[StructureMirror]:
    """
    Create structure mirroring hints from a question batch.

    When Maven receives questions from another AI in a structured format,
    this function analyzes the structure and creates hints for response
    generation to mirror that structure.

    Args:
        question_batch: QuestionBatch from the question parser

    Returns:
        StructureMirror hints, or None if no special structure detected
    """
    if question_batch is None:
        return None

    # Extract structure info from the batch
    try:
        structure = question_batch.structure.value if hasattr(question_batch.structure, 'value') else str(question_batch.structure)
        count = question_batch.count
        markers = [q.original_marker for q in question_batch.items if hasattr(q, 'original_marker')]
    except (AttributeError, TypeError):
        return None

    # Only create mirror for multi-question or structured inputs
    if count <= 1 and structure in ("prose", "single"):
        return None

    # Determine summary style based on question count
    if count >= 4:
        summary_style = "brief"  # Many questions = brief summary
    elif count >= 2:
        summary_style = "connecting"  # Few questions = connecting summary
    else:
        summary_style = "brief"

    return StructureMirror(
        input_structure=structure,
        question_count=count,
        original_markers=markers,
        mirror_structure=True,
        add_summary=count >= 2,  # Only add summary for multi-question
        summary_style=summary_style,
    )


def format_mirrored_response(
    answers: List[Dict[str, Any]],
    structure_mirror: StructureMirror,
    maven_summary: Optional[str] = None,
) -> str:
    """
    Format multiple answers using the mirrored structure.

    Args:
        answers: List of answer dicts with 'question_id', 'text', 'header'
        structure_mirror: Structure mirroring hints
        maven_summary: Optional Maven summary to append

    Returns:
        Formatted response string
    """
    template = structure_mirror.get_response_template()
    parts = []

    for i, answer in enumerate(answers):
        header = answer.get("header", f"Answer {i+1}")
        text = answer.get("text", "")

        if template["format"] == "numbered":
            prefix = template["prefix_pattern"].format(i + 1)
            if template["add_headers"]:
                parts.append(f"{prefix}**{header}**\n{text}")
            else:
                parts.append(f"{prefix}{text}")

        elif template["format"] == "bulleted":
            prefix = template["prefix_pattern"]
            parts.append(f"{prefix}{text}")

        elif template["format"] == "headings":
            prefix = template["prefix_pattern"]
            parts.append(f"{prefix}{header}\n{text}")

        else:  # prose
            if len(answers) > 1:
                parts.append(f"**{header}:** {text}")
            else:
                parts.append(text)

    # Join with appropriate separator
    separator = template["section_separator"]
    response = separator.join(parts)

    # Add Maven summary if provided
    if maven_summary and structure_mirror.add_summary:
        if structure_mirror.summary_style == "connecting":
            response += f"\n\n**In Summary:** {maven_summary}"
        elif structure_mirror.summary_style == "expansive":
            response += f"\n\n---\n\n**Maven's Additional Thoughts:**\n{maven_summary}"
        else:  # brief
            response += f"\n\n{maven_summary}"

    return response


# =============================================================================
# PUBLIC API
# =============================================================================

def plan_response_length(
    user_text: str,
    task_type: str = "default",
    tools_selected: Optional[List[str]] = None,
    research_enabled: bool = False,
    conversation_depth: int = 0,
    user_profile: Optional[UserProfile] = None,
    recent_behavior: Optional[RecentBehavior] = None,
    routing_info: Optional[RoutingInfo] = None,
    conversation_snippet: Optional[str] = None,
    safety_sensitive: bool = False,
    question_batch: Any = None,
) -> ResponsePlan:
    """
    Plan the response length for this turn using dynamic LLM-based decisions.

    Decision Flow:
    1. Check explicit overrides (no LLM call) - e.g., "tldr", "step by step"
    2. If no override, call LLM for dynamic decision
    3. If LLM fails, fall back to heuristics
    4. Apply safety post-processing
    5. Create structure mirror for multi-agent conversations
    6. Return ResponsePlan

    Args:
        user_text: The user's message (normalized preferred)
        task_type: Type of task from routing (e.g., "explanation", "code")
        tools_selected: List of tools/brains selected for this turn
        research_enabled: Whether web research is enabled
        conversation_depth: Current turn number in conversation
        user_profile: User's length preferences (optional)
        recent_behavior: Recent "too long"/"explain more" signals (optional)
        routing_info: Full routing context (optional, overrides task_type etc.)
        conversation_snippet: Last 3-5 turns for context (optional)
        safety_sensitive: Whether this is a safety-sensitive topic
        question_batch: QuestionBatch from question_parser for structure mirroring

    Returns:
        ResponsePlan with length_mode, style_hints, numeric_hints, tone, reason,
        and structure_mirror (for multi-question inputs)
    """
    # Build routing_info from individual params if not provided
    if routing_info is None:
        routing_info = RoutingInfo(
            task_type=task_type,
            selected_brains=[],
            selected_tools=tools_selected or [],
            safety_sensitive=safety_sensitive,
            research_enabled=research_enabled,
        )

    # Step 1: Check explicit overrides (no LLM needed)
    override_result = _check_explicit_overrides(user_text)
    if override_result:
        mode, reason = override_result
        print(f"[LENGTH_PLANNER] Override: mode={mode}, reason={reason}")

        # Get config for this mode
        config = LENGTH_MODE_CONFIGS.get(mode, LENGTH_MODE_CONFIGS["medium"])
        style_hints = StyleHints(
            step_by_step=config["style"].step_by_step,
            high_level=config["style"].high_level,
            include_examples=config["style"].include_examples,
        )
        numeric_hints = NumericHints(
            target_sections=config["target_sections"],
            target_points_per_section=config["target_points_per_section"],
            max_tokens_hint=config["max_tokens_hint"],
        )

        return ResponsePlan(
            length_mode=mode,
            style_hints=style_hints,
            numeric_hints=numeric_hints,
            detail_need=0.5,
            brevity_pref=0.5,
            length_score=0.5,
            reason=reason,
            tone="neutral",
            llm_decision=False,
        )

    # Step 1b: Force brief mode for small talk (FIX 2 - no LLM needed)
    small_talk_result = _force_brief_mode_for_small_talk(
        task_type=routing_info.task_type if routing_info else task_type,
        text=user_text,
    )
    if small_talk_result:
        mode, reason = small_talk_result
        print(f"[LENGTH_PLANNER] SMALL_TALK: mode={mode}, reason={reason}")

        # Return immediately with brief mode - no LLM needed
        config = LENGTH_MODE_CONFIGS.get(mode, LENGTH_MODE_CONFIGS["short"])
        return ResponsePlan(
            length_mode=mode,
            style_hints=StyleHints(
                step_by_step=False,
                high_level=True,
                include_examples=False,
            ),
            numeric_hints=NumericHints(
                target_sections=1,
                target_points_per_section=2,
                max_tokens_hint=50,  # Very brief for small talk
            ),
            detail_need=0.1,
            brevity_pref=0.9,
            length_score=0.1,
            reason=reason,
            tone="casual",  # Casual tone for small talk
            llm_decision=False,
        )

    # Step 2: Call LLM for dynamic decision
    llm_decision = _call_llm_length_planner(
        user_text=user_text,
        routing_info=routing_info,
        user_profile=user_profile,
        conversation_snippet=conversation_snippet,
        recent_behavior=recent_behavior,
    )

    mode = "medium"  # Default
    tone = "neutral"
    step_by_step_override = False
    include_examples_override = False
    reason = ""
    llm_used = False
    detail_need = 0.5
    brevity_pref = 0.5

    if llm_decision:
        # LLM provided a decision
        mode = llm_decision.get("mode", "medium")
        tone = llm_decision.get("tone", "neutral")
        step_by_step_override = llm_decision.get("step_by_step", False)
        include_examples_override = llm_decision.get("include_examples", False)
        reason = f"LLM: {llm_decision.get('reason', 'no reason provided')}"
        llm_used = True

        print(f"[LENGTH_PLANNER] LLM decision: mode={mode}, tone={tone}, step_by_step={step_by_step_override}")
    else:
        # Step 3: Fallback to heuristics
        mode, detail_need, brevity_pref, reason = _heuristic_length_decision(
            user_text=user_text,
            routing_info=routing_info,
            user_profile=user_profile,
            recent_behavior=recent_behavior,
        )
        print(f"[LENGTH_PLANNER] Heuristic fallback: mode={mode}, reason={reason}")

    # Step 4: Apply safety post-processing
    final_mode, safety_override, safety_disable_examples = _apply_safety_postprocessing(
        mode=mode,
        routing_info=routing_info,
        user_text=user_text,
    )
    if safety_override:
        reason += f"; {safety_override}"
        print(f"[LENGTH_PLANNER] Safety override: {safety_override}")
    # If safety says to disable examples, override include_examples
    if safety_disable_examples:
        include_examples_override = False

    # Step 4b: Apply context-based overrides (these OVERRIDE the LLM decision)
    # These are HARD GUARDRAILS that ensure proper length even if LLM chose wrong
    # They enforce the mandatory rules from the length_planning prompt
    behavior = recent_behavior or RecentBehavior()
    profile = user_profile or UserProfile()
    text_lower = user_text.lower()

    # OVERRIDE 1 (HIGHEST PRIORITY): User asked for more detail -> force long/step_by_step
    # This overrides ANY LLM decision - user feedback takes precedence
    if behavior.asked_for_more_detail_recently:
        if final_mode in ("short", "medium"):
            final_mode = "long"
            step_by_step_override = step_by_step_override or (routing_info.task_type in ("explanation", "troubleshooting", "tutorial"))
            include_examples_override = True
            reason += "; HARD_OVERRIDE: asked_for_more_detail->long"
            print(f"[LENGTH_PLANNER] HARD_OVERRIDE: asked_for_more_detail_recently -> forcing long")

    # OVERRIDE 2: Explicit "more detail" phrases in current message -> force long
    more_detail_phrases = ["tell me more", "go deeper", "explain more", "expand on", "more detail", "elaborate", "in more detail"]
    if any(phrase in text_lower for phrase in more_detail_phrases):
        if final_mode in ("short", "medium"):
            final_mode = "long"
            include_examples_override = True
            reason += "; HARD_OVERRIDE: explicit_more_detail->long"
            print(f"[LENGTH_PLANNER] HARD_OVERRIDE: explicit more detail phrase -> forcing long")

    # OVERRIDE 3: Broad topic + explanation/education task -> force long
    # Even if LLM chose medium, broad topics warrant comprehensive coverage
    explanation_task_types = ("explanation", "education", "conceptual", "tutorial")
    if routing_info.task_type in explanation_task_types:
        topic_match = any(topic in text_lower for topic in BROAD_TOPICS)
        if topic_match:
            # For broad topics, bump medium to long if user prefers detail
            if final_mode == "medium" and profile.prefers_detail >= 0.5:
                final_mode = "long"
                include_examples_override = True
                reason += "; HARD_OVERRIDE: broad_topic+prefers_detail->long"
                print(f"[LENGTH_PLANNER] HARD_OVERRIDE: broad topic explanation + prefers_detail -> forcing long")
            # Even without preference, single-word broad topics get long mode
            elif final_mode == "medium":
                words = text_lower.split()
                if any(w in BROAD_TOPICS for w in words) and len(words) <= 5:
                    final_mode = "long"
                    include_examples_override = True
                    reason += "; HARD_OVERRIDE: single_noun_broad_topic->long"
                    print(f"[LENGTH_PLANNER] HARD_OVERRIDE: single-noun broad topic -> forcing long")

    # OVERRIDE 4: Teaching verbs -> bias toward long
    teaching_starts = ["explain ", "teach me", "walk me through", "show me how", "describe ", "help me understand"]
    if any(text_lower.startswith(phrase) for phrase in teaching_starts):
        if final_mode in ("short", "medium") and profile.prefers_brevity < 0.7:
            final_mode = "long"
            include_examples_override = True
            reason += "; HARD_OVERRIDE: teaching_verb->long"
            print(f"[LENGTH_PLANNER] HARD_OVERRIDE: teaching verb -> forcing long")
        # "walk me through" and "show me how" get step_by_step
        if any(text_lower.startswith(p) for p in ["walk me through", "show me how"]):
            step_by_step_override = True

    # OVERRIDE 5: Troubleshooting/debugging/planning always gets step_by_step
    if routing_info.task_type in ("troubleshooting", "debugging", "planning", "how-to"):
        if final_mode in ("short", "medium"):
            final_mode = "long"
        step_by_step_override = True
        include_examples_override = True
        reason += f"; HARD_OVERRIDE: {routing_info.task_type}->step_by_step"
        print(f"[LENGTH_PLANNER] HARD_OVERRIDE: {routing_info.task_type} -> forcing step_by_step")

    # OVERRIDE 6: Prevent "short" except when explicitly requested
    # Short mode should ONLY be used when user explicitly asked for brevity
    if final_mode == "short":
        explicit_short_request = any(p in text_lower for p in FORCE_SHORT_PHRASES)
        high_brevity_pref = profile.prefers_brevity > 0.7
        if not explicit_short_request and not high_brevity_pref:
            # Don't allow short unless explicitly requested or strong preference
            if routing_info.task_type not in ("simple_fact", "confirmation", "greeting"):
                final_mode = "medium"
                reason += "; GUARDRAIL: short_requires_explicit_request->medium"
                print(f"[LENGTH_PLANNER] GUARDRAIL: short mode not explicitly requested, bumping to medium")

    # OVERRIDE 7: Questions ending in "why" need detailed explanations
    # "why" questions require reasoning and justification = longer responses
    if text_lower.strip().endswith("why") or text_lower.strip().endswith("why?"):
        if final_mode in ("short", "medium"):
            final_mode = "long"
            include_examples_override = True
            reason += "; WHY_QUESTION: why questions need long explanations"
            print(f"[LENGTH_PLANNER] WHY_QUESTION: question ends in 'why' -> forcing long")
    # Also catch "why is", "why does", "why do" anywhere
    why_patterns = [r"\bwhy\s+(?:is|are|does|do|did|would|should|can|could)\b"]
    if any(re.search(p, text_lower) for p in why_patterns):
        if final_mode == "short":
            final_mode = "medium"
            reason += "; WHY_QUESTION: why pattern detected -> at least medium"
            print(f"[LENGTH_PLANNER] WHY_QUESTION: 'why X' pattern -> bumping to medium")

    # OVERRIDE 8: Architecture questions always get long mode
    architecture_keywords = ["architecture", "how do you work", "how does maven work",
                             "internal structure", "coordinate", "blackboard",
                             "brains communicate", "cognitive architecture"]
    if any(kw in text_lower for kw in architecture_keywords):
        if final_mode in ("short", "medium"):
            final_mode = "long"
            step_by_step_override = True
            include_examples_override = True
            reason += "; ARCHITECTURE_QUESTION: architecture needs long+step_by_step"
            print(f"[LENGTH_PLANNER] ARCHITECTURE_QUESTION: forcing long with step_by_step")

    # Step 5: Create structure mirror for multi-agent conversations
    structure_mirror = None
    if question_batch is not None:
        structure_mirror = create_structure_mirror(question_batch)
        if structure_mirror:
            print(f"[LENGTH_PLANNER] Structure mirror: {structure_mirror.input_structure}, "
                  f"question_count={structure_mirror.question_count}")
            # Multi-question inputs should get at least medium length
            if structure_mirror.question_count > 1 and final_mode == "short":
                final_mode = "medium"
                reason += "; multi_question_bump: short->medium"

    # Step 6: Build final ResponsePlan
    config = LENGTH_MODE_CONFIGS.get(final_mode, LENGTH_MODE_CONFIGS["medium"])

    # Apply LLM overrides to style hints
    style_hints = StyleHints(
        step_by_step=step_by_step_override or config["style"].step_by_step,
        high_level=config["style"].high_level,
        include_examples=include_examples_override or config["style"].include_examples,
    )

    # Task-specific style adjustments
    if routing_info.task_type in ("troubleshooting", "debugging", "planning", "tutorial"):
        style_hints.step_by_step = True
    if routing_info.task_type in ("code", "code_review", "explanation", "conceptual"):
        style_hints.include_examples = True

    numeric_hints = NumericHints(
        target_sections=config["target_sections"],
        target_points_per_section=config["target_points_per_section"],
        max_tokens_hint=config["max_tokens_hint"],
    )

    # Compute length_score for compatibility
    score_map = {"short": 0.2, "medium": 0.45, "long": 0.7, "step_by_step": 0.9}
    length_score = score_map.get(final_mode, 0.5)

    plan = ResponsePlan(
        length_mode=final_mode,
        style_hints=style_hints,
        numeric_hints=numeric_hints,
        detail_need=detail_need,
        brevity_pref=brevity_pref,
        length_score=length_score,
        reason=reason,
        tone=tone,
        llm_decision=llm_used,
        structure_mirror=structure_mirror,
    )

    print(f"[LENGTH_PLANNER] Final: mode={final_mode}, step_by_step={style_hints.step_by_step}, "
          f"include_examples={style_hints.include_examples}, tone={tone}, llm_used={llm_used}")

    return plan


def get_length_prompt(mode: str) -> str:
    """Get the prompt instruction for a length mode."""
    # Map legacy modes
    mode = LEGACY_MODE_MAP.get(mode, mode)
    return LENGTH_MODE_PROMPTS.get(mode, LENGTH_MODE_PROMPTS["medium"])


def format_length_instruction(plan: ResponsePlan) -> str:
    """
    Format a complete instruction block for the LLM.

    Can be injected into system prompt or user prompt.
    """
    base_prompt = get_length_prompt(plan.length_mode)

    parts = [base_prompt]

    # Add style hints
    if plan.style_hints.step_by_step:
        parts.append("Use a numbered step-by-step structure.")
    if plan.style_hints.include_examples:
        parts.append("Include at least one concrete example.")
    if plan.style_hints.high_level:
        parts.append("Focus on high-level concepts.")

    # Add tone hint if not neutral
    if plan.tone == "technical":
        parts.append("Use technical terminology appropriate for experts.")
    elif plan.tone == "friendly":
        parts.append("Use a friendly, approachable tone.")

    return " ".join(parts)


# =============================================================================
# 6.1-6.2: USER PREFERENCE LEARNING
# =============================================================================

# In-memory preference tracking
_user_preference_adjustments: Dict[str, float] = {
    "brevity_delta": 0.0,  # Accumulated adjustment to brevity preference
    "detail_delta": 0.0,   # Accumulated adjustment to detail preference
    "teaching_language_count": 0,  # Count of teaching language usage
}

# Preference persistence path (optional)
_PREFERENCE_FILE = None  # Set this to enable persistence


def update_preference_from_feedback(feedback_type: str) -> None:
    """
    6.1: Update user preferences based on feedback signals.

    Args:
        feedback_type: One of:
            - "too_long": User complained about length
            - "too_short": User asked for more detail
            - "explain_more": User asked for elaboration
            - "teaching_language": User uses teaching verbs frequently
            - "perfect": User was satisfied (reinforces current level)
    """
    if feedback_type == "too_long":
        # Increase brevity preference
        _user_preference_adjustments["brevity_delta"] += 0.05
        _user_preference_adjustments["detail_delta"] -= 0.02
        print(f"[PREF_LEARN] User prefers shorter: brevity_delta={_user_preference_adjustments['brevity_delta']:.2f}")

    elif feedback_type in ("too_short", "explain_more"):
        # Increase detail preference
        _user_preference_adjustments["detail_delta"] += 0.05
        _user_preference_adjustments["brevity_delta"] -= 0.03
        print(f"[PREF_LEARN] User prefers longer: detail_delta={_user_preference_adjustments['detail_delta']:.2f}")

    elif feedback_type == "teaching_language":
        # User frequently uses teaching language -> increase detail preference
        _user_preference_adjustments["teaching_language_count"] += 1
        if _user_preference_adjustments["teaching_language_count"] >= 3:
            # After 3 teaching-style queries, bump detail preference
            _user_preference_adjustments["detail_delta"] += 0.03
            print(f"[PREF_LEARN] Teaching language pattern detected: detail_delta={_user_preference_adjustments['detail_delta']:.2f}")

    elif feedback_type == "perfect":
        # Decay adjustments toward 0 (reinforces current balance)
        _user_preference_adjustments["brevity_delta"] *= 0.9
        _user_preference_adjustments["detail_delta"] *= 0.9

    # 6.2: Persist preferences (if enabled)
    _persist_preferences()


def get_adjusted_user_profile(base_profile: Optional[UserProfile] = None) -> UserProfile:
    """Get user profile with learned adjustments applied."""
    if base_profile is None:
        base_profile = UserProfile()

    # Load persisted preferences if available
    _load_preferences()

    return UserProfile(
        prefers_brevity=max(0.0, min(1.0,
            base_profile.prefers_brevity + _user_preference_adjustments["brevity_delta"]
        )),
        prefers_detail=max(0.0, min(1.0,
            base_profile.prefers_detail + _user_preference_adjustments["detail_delta"]
        )),
        technical_level=base_profile.technical_level,
    )


def detect_feedback_signals(user_text: str) -> Optional[str]:
    """
    6.1: Detect feedback signals about length preferences.

    Signals to learn from:
    - "tell me more", "can you go deeper" -> increase prefers_detail
    - "too long", "shorter" -> increase prefers_brevity
    - Teaching verbs ("explain...", "walk me through...") -> bias toward detail

    Returns feedback_type or None.
    """
    text_lower = user_text.lower()

    # Too long signals -> increase prefers_brevity
    too_long_phrases = [
        "too long", "too much", "shorter", "tl;dr", "tldr",
        "just the summary", "brief please", "shorter please",
        "just tell me", "short version", "quick version",
        "cut to the chase", "bottom line",
    ]
    if any(phrase in text_lower for phrase in too_long_phrases):
        return "too_long"

    # Too short signals -> increase prefers_detail
    too_short_phrases = [
        "explain more", "more detail", "elaborate", "expand on",
        "go deeper", "tell me more", "that's not enough",
        "too brief", "too short", "more please",
        "can you expand", "not detailed enough", "need more",
        "this is not enough", "i want more",
    ]
    if any(phrase in text_lower for phrase in too_short_phrases):
        return "too_short"

    # Teaching language detection -> bias toward detail
    teaching_patterns = [
        "explain", "teach me", "walk me through", "show me how",
        "help me understand", "break down", "describe in detail",
    ]
    if any(text_lower.startswith(p) for p in teaching_patterns):
        return "teaching_language"

    return None


def _persist_preferences() -> None:
    """6.2: Persist learned preferences to disk/memory."""
    try:
        # Try to use BrainMemory for persistence
        from brains.cognitive.brain_memory import BrainMemory
        memory = BrainMemory("response_planner")
        memory.store(
            content={
                "type": "user_preferences",
                "brevity_delta": _user_preference_adjustments["brevity_delta"],
                "detail_delta": _user_preference_adjustments["detail_delta"],
                "teaching_language_count": _user_preference_adjustments["teaching_language_count"],
            },
            metadata={"scope": "preferences", "persistent": True}
        )
    except Exception:
        # Fallback: preferences stay in-memory only
        pass


def _load_preferences() -> None:
    """6.2: Load persisted preferences from disk/memory."""
    global _user_preference_adjustments
    try:
        from brains.cognitive.brain_memory import BrainMemory
        memory = BrainMemory("response_planner")
        results = memory.query(
            query="user_preferences",
            metadata_filter={"scope": "preferences"},
            top_k=1
        )
        if results:
            content = results[0].get("content", {})
            if isinstance(content, dict) and content.get("type") == "user_preferences":
                _user_preference_adjustments["brevity_delta"] = float(content.get("brevity_delta", 0.0))
                _user_preference_adjustments["detail_delta"] = float(content.get("detail_delta", 0.0))
                _user_preference_adjustments["teaching_language_count"] = int(content.get("teaching_language_count", 0))
    except Exception:
        # Fallback: use default in-memory values
        pass


def get_preference_summary() -> Dict[str, Any]:
    """Get summary of learned preferences for debugging."""
    profile = get_adjusted_user_profile()
    return {
        "brevity_delta": _user_preference_adjustments["brevity_delta"],
        "detail_delta": _user_preference_adjustments["detail_delta"],
        "teaching_language_count": _user_preference_adjustments["teaching_language_count"],
        "effective_prefers_brevity": profile.prefers_brevity,
        "effective_prefers_detail": profile.prefers_detail,
    }


# =============================================================================
# INTEGRATION HELPERS
# =============================================================================

def inject_length_context(ctx: Dict[str, Any], plan: ResponsePlan) -> None:
    """
    Inject response plan into pipeline context.

    Call this after planning but before calling brains.
    """
    ctx["response_plan"] = {
        "length_mode": plan.length_mode,
        "style_hints": {
            "step_by_step": plan.style_hints.step_by_step,
            "high_level": plan.style_hints.high_level,
            "include_examples": plan.style_hints.include_examples,
        },
        "numeric_hints": {
            "target_sections": plan.numeric_hints.target_sections,
            "target_points_per_section": plan.numeric_hints.target_points_per_section,
            "max_tokens_hint": plan.numeric_hints.max_tokens_hint,
        },
        "length_instruction": format_length_instruction(plan),
        "detail_need": plan.detail_need,
        "brevity_pref": plan.brevity_pref,
        "tone": plan.tone,
        "llm_decision": plan.llm_decision,
    }


def get_length_context(ctx: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Get response plan from pipeline context."""
    return ctx.get("response_plan")


# =============================================================================
# BACKWARD COMPATIBILITY
# =============================================================================

def normalize_mode(mode: str) -> str:
    """Normalize legacy mode names to new mode names."""
    return LEGACY_MODE_MAP.get(mode, mode)


# =============================================================================
# 8. DEBUG / REGRESSION TEST COMMAND
# =============================================================================

def debug_length_plan(
    user_message: str,
    task_type: Optional[str] = None,
    safety_sensitive: bool = False,
    asked_for_more_detail: bool = False,
) -> Dict[str, Any]:
    """
    8. Debug command for testing length planning decisions.

    Usage:
        from brains.cognitive.response_planner import debug_length_plan
        result = debug_length_plan("explain basic physics")
        print(result)

    Test cases:
        debug_length_plan("explain basic physics")  # -> long
        debug_length_plan("tell me more")  # -> long
        debug_length_plan("explain how binary works")  # -> long
        debug_length_plan("short answer: what is binary?")  # -> short
        debug_length_plan("debug this Python error: ...")  # -> step_by_step
        debug_length_plan("give me a high-level plan to start a SaaS business")  # -> long/step_by_step

    Args:
        user_message: The user's message to analyze
        task_type: Optional override for task_type (otherwise auto-detected)
        safety_sensitive: Whether this is a safety-sensitive topic
        asked_for_more_detail: Whether user recently asked for more detail

    Returns:
        Dictionary with debug info:
        - task_type: Detected task type
        - length_plan: The full response plan
        - summary: Quick summary of key decisions
        - overrides_fired: Which guardrails/overrides were triggered
    """
    import sys
    print("=" * 60, file=sys.stderr)
    print(f"[DEBUG_LENGTH_PLAN] Analyzing: '{user_message}'", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    # Auto-detect task_type if not provided
    detected_task_type = task_type or classify_task_type(user_message)
    print(f"[DEBUG] Detected task_type: {detected_task_type}", file=sys.stderr)

    # Correct typos
    corrected_message = correct_common_typos(user_message)
    if corrected_message != user_message:
        print(f"[DEBUG] Typo correction: '{user_message}' -> '{corrected_message}'", file=sys.stderr)

    # Build routing info
    routing_info = RoutingInfo(
        task_type=detected_task_type,
        safety_sensitive=safety_sensitive,
    )

    # Build recent behavior
    recent_behavior = RecentBehavior(
        asked_for_more_detail_recently=asked_for_more_detail,
    )

    # Get adjusted user profile
    user_profile = get_adjusted_user_profile()
    print(f"[DEBUG] User profile: prefers_brevity={user_profile.prefers_brevity:.2f}, prefers_detail={user_profile.prefers_detail:.2f}", file=sys.stderr)

    # Run the length planner
    plan = plan_response_length(
        user_text=corrected_message,
        task_type=detected_task_type,
        routing_info=routing_info,
        user_profile=user_profile,
        recent_behavior=recent_behavior,
        safety_sensitive=safety_sensitive,
    )

    # Build result
    result = {
        "input": {
            "user_message": user_message,
            "corrected_message": corrected_message if corrected_message != user_message else None,
            "task_type_override": task_type,
            "safety_sensitive": safety_sensitive,
            "asked_for_more_detail": asked_for_more_detail,
        },
        "task_type": detected_task_type,
        "length_plan": {
            "mode": plan.length_mode,
            "step_by_step": plan.style_hints.step_by_step,
            "include_examples": plan.style_hints.include_examples,
            "tone": plan.tone,
            "llm_decision": plan.llm_decision,
            "reason": plan.reason,
        },
        "numeric_hints": {
            "target_sections": plan.numeric_hints.target_sections,
            "max_tokens_hint": plan.numeric_hints.max_tokens_hint,
        },
        "user_profile": {
            "prefers_brevity": user_profile.prefers_brevity,
            "prefers_detail": user_profile.prefers_detail,
        },
    }

    # Check which overrides would fire
    overrides_fired = []
    text_lower = user_message.lower()

    # Check explicit short
    if any(p in text_lower for p in FORCE_SHORT_PHRASES):
        overrides_fired.append("EXPLICIT_SHORT_PHRASE")

    # Check explicit step_by_step
    if any(p in text_lower for p in FORCE_STEP_BY_STEP_PHRASES):
        overrides_fired.append("EXPLICIT_STEP_BY_STEP_PHRASE")

    # Check more detail phrases
    more_detail_phrases = ["tell me more", "go deeper", "explain more", "expand on", "more detail"]
    if any(phrase in text_lower for phrase in more_detail_phrases):
        overrides_fired.append("MORE_DETAIL_PHRASE")

    # Check broad topic
    if any(topic in text_lower for topic in BROAD_TOPICS):
        overrides_fired.append(f"BROAD_TOPIC")

    # Check teaching verbs
    teaching_starts = ["explain ", "teach me", "walk me through", "show me how"]
    if any(text_lower.startswith(phrase) for phrase in teaching_starts):
        overrides_fired.append("TEACHING_VERB")

    # Check safety
    if safety_sensitive:
        overrides_fired.append("SAFETY_SENSITIVE")

    # Check asked_for_more_detail
    if asked_for_more_detail:
        overrides_fired.append("ASKED_FOR_MORE_DETAIL")

    result["overrides_fired"] = overrides_fired

    # Summary
    summary = f"mode={plan.length_mode}, step_by_step={plan.style_hints.step_by_step}, examples={plan.style_hints.include_examples}"
    result["summary"] = summary

    print("=" * 60, file=sys.stderr)
    print(f"[DEBUG_LENGTH_PLAN] Result:", file=sys.stderr)
    print(f"  task_type: {detected_task_type}", file=sys.stderr)
    print(f"  mode: {plan.length_mode}", file=sys.stderr)
    print(f"  step_by_step: {plan.style_hints.step_by_step}", file=sys.stderr)
    print(f"  include_examples: {plan.style_hints.include_examples}", file=sys.stderr)
    print(f"  tone: {plan.tone}", file=sys.stderr)
    print(f"  llm_decision: {plan.llm_decision}", file=sys.stderr)
    print(f"  overrides_fired: {overrides_fired}", file=sys.stderr)
    print(f"  reason: {plan.reason[:100]}..." if len(plan.reason) > 100 else f"  reason: {plan.reason}", file=sys.stderr)
    print("=" * 60, file=sys.stderr)

    return result


def run_debug_test_suite() -> None:
    """
    8. Run a suite of test cases to verify length planning behavior.

    Expected results:
    - "explain basic physics" -> long, explanation task
    - "tell me more" -> long (more detail phrase)
    - "explain how binary works" -> long, explanation task
    - "short answer: what is binary?" -> short (explicit short)
    - "debug this Python error" -> step_by_step, troubleshooting
    - "high-level plan for SaaS" -> long/step_by_step, planning
    """
    test_cases = [
        ("explain basic physics", {"expected_mode": "long", "expected_task": "explanation"}),
        ("tell me more", {"expected_mode": "long", "override": "MORE_DETAIL_PHRASE"}),
        ("explain how binary works", {"expected_mode": "long", "expected_task": "explanation"}),
        ("short answer: what is binary?", {"expected_mode": "short", "override": "EXPLICIT_SHORT_PHRASE"}),
        ("debug this Python error: TypeError", {"expected_mode": "step_by_step", "expected_task": "troubleshooting"}),
        ("give me a high-level plan to start a SaaS business", {"expected_mode": "long", "expected_task": "planning"}),
        ("who is Albert Einstein?", {"expected_mode": "medium", "expected_task": "simple_fact"}),
        ("walk me through how to set up a database", {"expected_mode": "step_by_step", "override": "TEACHING_VERB"}),
    ]

    import sys
    print("\n" + "=" * 70, file=sys.stderr)
    print("LENGTH PLANNER TEST SUITE", file=sys.stderr)
    print("=" * 70, file=sys.stderr)

    passed = 0
    failed = 0

    for user_message, expected in test_cases:
        result = debug_length_plan(user_message)
        mode = result["length_plan"]["mode"]
        task_type = result["task_type"]

        # Check expectations
        mode_ok = True
        task_ok = True

        if "expected_mode" in expected:
            expected_mode = expected["expected_mode"]
            # For step_by_step, also accept long as it may include step_by_step hint
            if expected_mode == "step_by_step" and mode == "long" and result["length_plan"]["step_by_step"]:
                mode_ok = True
            elif mode != expected_mode:
                mode_ok = False

        if "expected_task" in expected:
            if task_type != expected["expected_task"]:
                task_ok = False

        status = "✓ PASS" if (mode_ok and task_ok) else "✗ FAIL"
        if mode_ok and task_ok:
            passed += 1
        else:
            failed += 1

        print(f"\n{status}: '{user_message[:40]}...'", file=sys.stderr)
        print(f"  → mode={mode} (expected: {expected.get('expected_mode', 'any')})", file=sys.stderr)
        print(f"  → task_type={task_type} (expected: {expected.get('expected_task', 'any')})", file=sys.stderr)
        if not mode_ok or not task_ok:
            print(f"  → overrides_fired: {result['overrides_fired']}", file=sys.stderr)
            print(f"  → reason: {result['length_plan']['reason'][:80]}...", file=sys.stderr)

    print("\n" + "=" * 70, file=sys.stderr)
    print(f"RESULTS: {passed} passed, {failed} failed out of {len(test_cases)} tests", file=sys.stderr)
    print("=" * 70, file=sys.stderr)


# =============================================================================
# 9. SELF-QUESTION PLANNING
# =============================================================================

# Self-intent type to task type mapping
SELF_INTENT_TO_TASK_TYPE = {
    "self_identity": "self_identity",
    "self_architecture_highlevel": "self_architecture",
    "self_architecture_detail": "self_architecture_detail",
    "self_capabilities": "self_capabilities",
    "self_brains": "self_brains",
    "self_tools": "self_tools",
    "self_comparison": "self_comparison",
    "self_health": "self_health",
    "self_limitations": "self_capabilities",
    "self_memory": "self_memory",           # Dedicated memory questions
    "self_learning": "self_learning",       # Dedicated learning questions
    "self_meta_reflection": "self_architecture_detail",
}


@dataclass
class SelfAnswerPlan:
    """
    Plan for answering a self-question.

    Combines ResponsePlan with self-specific guidance.
    """
    response_plan: ResponsePlan
    detail_level: int  # 1 = high-level summary, 2 = moderate, 3 = deep dive
    self_intent_type: str
    scope: str  # "whole_system", "specific_part", "comparison"
    include_counts: bool  # Whether to include component counts
    include_examples: bool  # Whether to include concrete examples
    answer_first_sentence: str  # The first sentence MUST directly answer the question


def classify_self_intent(question: str) -> str:
    """
    Classify a self-question into a specific intent type.

    Returns one of the self_ task types.
    """
    q_lower = question.lower()

    # Count questions
    if any(m in q_lower for m in ["how many", "count", "number of", "total"]):
        return "self_count"

    # Architecture questions
    if any(m in q_lower for m in ["how do you work", "architecture", "how are you built", "structure"]):
        if any(m in q_lower for m in ["detail", "deeply", "step by step", "explain"]):
            return "self_architecture_detail"
        return "self_architecture"

    # Brain-specific questions
    if any(m in q_lower for m in ["brain", "brains", "cognitive"]):
        if any(m in q_lower for m in ["communicate", "coordinate", "blackboard", "talk to each other"]):
            return "self_architecture_detail"
        return "self_brains"

    # Tool questions (but not "what can you do" which is capabilities)
    if any(m in q_lower for m in ["tool", "tools"]):
        return "self_tools"
    # "can you" with specific action = tools, "what can you do" = capabilities
    if "can you" in q_lower and not any(m in q_lower for m in ["what can you", "what are you capable"]):
        return "self_tools"

    # Comparison questions
    if any(m in q_lower for m in ["chatgpt", "claude", "grok", "compare", "different from", "vs"]):
        return "self_comparison"

    # Health/status
    if any(m in q_lower for m in ["health", "status", "diagnose", "working"]):
        return "self_health"

    # Memory questions (Pattern 4)
    if any(m in q_lower for m in ["memory", "remember", "persistent memory", "long-term"]):
        return "self_memory"

    # Learning/Teacher-Student questions (Pattern 5)
    if any(m in q_lower for m in ["learn", "teacher", "student", "improve", "acquire knowledge"]):
        return "self_learning"

    # Identity/introduction
    if any(m in q_lower for m in ["who are you", "what are you", "yourself", "introduce"]):
        return "self_identity"

    return "self_capabilities"


def plan_self_answer(
    question: str,
    self_intent_type: Optional[str] = None,
    user_profile: Optional[UserProfile] = None,
    recent_behavior: Optional[RecentBehavior] = None,
) -> SelfAnswerPlan:
    """
    Plan how to answer a self-question.

    This is the main entry point for planning self-question answers.
    It determines:
    - detail_level (1-3)
    - scope (whole system vs specific part)
    - whether to include counts/examples
    - the first sentence structure

    Args:
        question: The user's question about Maven
        self_intent_type: Optional pre-detected self-intent type
        user_profile: User's length preferences
        recent_behavior: Recent feedback signals

    Returns:
        SelfAnswerPlan with all planning details
    """
    # Classify self-intent if not provided
    if not self_intent_type:
        self_intent_type = classify_self_intent(question)

    # Map to task type
    task_type = SELF_INTENT_TO_TASK_TYPE.get(self_intent_type, "self_capabilities")

    # Build routing info
    routing_info = RoutingInfo(
        task_type=task_type,
        selected_brains=["self_introspection"],
        safety_sensitive=False,
    )

    # Get response plan
    response_plan = plan_response_length(
        user_text=question,
        task_type=task_type,
        routing_info=routing_info,
        user_profile=user_profile,
        recent_behavior=recent_behavior,
    )

    # Map length_mode to detail_level (1-3)
    detail_level_map = {
        "short": 1,
        "medium": 2,
        "long": 3,
        "step_by_step": 3,
    }
    detail_level = detail_level_map.get(response_plan.length_mode, 2)

    # Determine scope
    q_lower = question.lower()
    if any(m in q_lower for m in ["brain", "tool", "memory", "learning", "teacher"]):
        scope = "specific_part"
    elif any(m in q_lower for m in ["compare", "vs", "different from"]):
        scope = "comparison"
    else:
        scope = "whole_system"

    # Determine if counts should be included
    include_counts = any(m in q_lower for m in [
        "how many", "count", "number", "total",
        "brain", "tool", "module", "component"
    ])

    # Include examples for detailed answers
    include_examples = detail_level >= 2 or response_plan.style_hints.include_examples

    # Generate first sentence template
    answer_first_sentence = _generate_first_sentence(question, self_intent_type)

    return SelfAnswerPlan(
        response_plan=response_plan,
        detail_level=detail_level,
        self_intent_type=self_intent_type,
        scope=scope,
        include_counts=include_counts,
        include_examples=include_examples,
        answer_first_sentence=answer_first_sentence,
    )


def _generate_first_sentence(question: str, self_intent_type: str) -> str:
    """
    Generate a template for the first sentence that directly answers the question.

    The {placeholder} values will be filled by the introspection brain with real data.
    """
    templates = {
        "self_count": "I currently have {count} {component_type}, plus a set of tools for acting on the world.",
        "self_identity": "I'm Maven, a modular AI with {brain_count} cognitive brains and {tool_count} tools.",
        "self_architecture": "I'm a modular AI assistant: I use many specialized cognitive brains for thinking and a smaller set of tools for acting on the world, all coordinated through a routing brain and a shared blackboard.",
        "self_architecture_detail": "My brains communicate through a shared blackboard plus a routing brain that passes structured messages between them.",
        "self_brains": "My brains are specialized cognitive modules; they're grouped into routing, reasoning, memory/learning, and response/voice functions.",
        "self_tools": "My tools are how I act on the world: my brains decide what to do, and my tools carry out browser, web, file, and system operations under their direction.",
        "self_comparison": "Compared to cloud LLMs like {other_ai}, I'm a modular local agent: I have many explicit brains, persistent memory, and tools that let me act on the world under my own routing and control logic.",
        "self_health": "My system status is {status} with {component_count} active components.",
        "self_capabilities": "I combine internal reasoning with tools that let me automate browsers, look things up, work with files, and orchestrate system-level tasks under my own control logic.",
        "self_memory": "I use a memory brain plus persistent storage, so I can keep certain knowledge across sessions instead of starting from scratch each time.",
        "self_learning": "My Teacher-Student system learns by evaluating new information, deciding whether it's trustworthy and useful, and then encoding selected pieces into my long-term memory.",
    }

    return templates.get(self_intent_type, "I'm Maven, a modular AI assistant.")


def format_self_answer_instruction(plan: SelfAnswerPlan) -> str:
    """
    Format instructions for generating a self-answer.

    This can be injected into the prompt for the introspection brain.
    """
    base_instruction = format_length_instruction(plan.response_plan)

    parts = [
        f"SELF-ANSWER INSTRUCTION (detail_level={plan.detail_level}):",
        "",
        "CRITICAL: First sentence MUST directly answer the question:",
        f"  Template: \"{plan.answer_first_sentence}\"",
        "",
        base_instruction,
        "",
    ]

    if plan.detail_level == 1:
        parts.append("Level 1 (Summary): High-level description only. No deep mechanism details.")
    elif plan.detail_level == 2:
        parts.append("Level 2 (Moderate): Summarize structure + 2-3 key mechanisms or examples.")
    else:
        parts.append("Level 3 (Deep): Ordered steps, data flows, and concrete examples.")

    if plan.include_counts:
        parts.append("Include actual component counts from the registry.")

    if plan.include_examples:
        parts.append("Include at least one concrete example.")

    return "\n".join(parts)


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Core dataclasses
    "StyleHints",
    "StructureMirror",
    "NumericHints",
    "ResponsePlan",
    "UserProfile",
    "RecentBehavior",
    "RoutingInfo",
    # Self-answer planning
    "SelfAnswerPlan",
    # Main functions
    "plan_response_length",
    "get_length_prompt",
    "format_length_instruction",
    "classify_task_type",
    "correct_common_typos",
    # Structure mirroring (multi-agent)
    "create_structure_mirror",
    "format_mirrored_response",
    # User preference learning
    "update_preference_from_feedback",
    "get_adjusted_user_profile",
    "detect_feedback_signals",
    "get_preference_summary",
    # Self-question planning
    "plan_self_answer",
    "classify_self_intent",
    "format_self_answer_instruction",
    # Integration helpers
    "inject_length_context",
    "get_length_context",
    "normalize_mode",
    # Debug utilities
    "debug_length_plan",
    "run_debug_test_suite",
    # Constants
    "LENGTH_MODE_CONFIGS",
    "LENGTH_MODE_PROMPTS",
]
