"""
Response Quality Checker
========================

FIX 3 & 4: Quality checker with identity protection kill rules
and emergency fallback for repeated failures.

Catches hallucinations before they reach user.
"""

from __future__ import annotations

import logging
from typing import Dict, Any, List, Optional, Callable

logger = logging.getLogger(__name__)


class ResponseQualityChecker:
    """
    Quality checker with identity protection.
    Catches hallucinations before they reach user.
    """

    def __init__(self, memory_librarian=None):
        """
        Initialize the quality checker.

        Args:
            memory_librarian: Optional memory librarian for emergency fallback
        """
        self.memory = memory_librarian
        self.emergency_fallback = EmergencyFallback(memory_librarian)

    def check(self, query: str, response: str) -> Dict[str, Any]:
        """
        Check response quality.
        Returns approval or list of issues to fix.

        Args:
            query: The user's original query
            response: The generated response to check

        Returns:
            Dict with:
            - approved: bool
            - issues: List[str]
            - severity: str (optional, for critical issues)
            - fix: str (optional, suggested fix action)
            - quality_score: float (optional, for approved responses)
        """
        issues = []
        response_lower = response.lower() if response else ""

        # KILL RULE 1: Identity violation (Grok's addition)
        identity_violations = [
            "i am a large language model",
            "i am an ai assistant created by",
            "i'm a large language model",
            "i am an llm",
            "i'm an llm",
            "i am chatgpt",
            "i am claude",
            "i am gpt-4",
            "i am gpt-3",
            "i don't have memory",
            "i don't have memories",
            "i can't execute code",
            "i cannot execute code",
            "i don't have access to",
            "i do not have access to",
            "i cannot browse the web",
            "i can't browse the web",
            "i cannot search the internet",
            "i don't have the ability to",
            "i do not have the ability to",
            "as an ai language model",
            "as a language model",
            "i was trained by openai",
            "i was created by openai",
            "i was trained by anthropic",
            "i was created by anthropic",
        ]

        for violation in identity_violations:
            if violation in response_lower:
                issues.append(f"IDENTITY VIOLATION: '{violation}' - Maven is NOT a generic LLM")
                return {
                    "approved": False,
                    "issues": issues,
                    "severity": "CRITICAL",
                    "fix": "regenerate_with_strong_identity"
                }

        # KILL RULE 1b: Fake action claims (hallucinated tool execution)
        # These indicate Maven is claiming to do things it didn't actually do
        fake_action_patterns = [
            # File operations - various phrasings
            "file delete successful",
            "file deleted successfully",
            "deleted successfully",
            "delete successful",
            "successfully deleted",
            "i've deleted the file",
            "i deleted the file",
            "i will now delete",
            "executing command",
            "process complete",
            # Memory claims
            "i've cleared the memory",
            "i cleared the memory",
            # Browsing claims
            "i've browsed through",
            "i browsed through",
            "i'm browsing",
            # Roleplay asterisks - any action in asterisks
            "*browses",
            "*checks",
            "*searches",
            "*executes",
            "*runs",
            "*deletes",
            "*ahem*",
            "*looks",
            "*reads",
            "*opens",
            "*clicks",
            "*types",
            "*navigates",
            # Other fake claims
            "let me check my internal",
            "let me browse",
            "i'll display a message box",
            "i'll show a message box",
            "executing deletion",
            "command executed",
        ]

        for fake_action in fake_action_patterns:
            if fake_action in response_lower:
                issues.append(f"FAKE ACTION: '{fake_action}' - Cannot claim actions not performed")
                return {
                    "approved": False,
                    "issues": issues,
                    "severity": "CRITICAL",
                    "fix": "regenerate_honest"
                }

        # KILL RULE 1c: Topic contamination - bringing up old unrelated topics
        # Detect when response references topics not in the current query
        unrelated_topic_indicators = [
            ("jim's sisters", "jim"),
            ("purple things", "purple"),
            ("as for jim", "jim"),
            ("regarding jim", "jim"),
            ("about jim", "jim"),
            ("jim has", "jim"),
        ]

        for phrase, topic_word in unrelated_topic_indicators:
            if phrase in response_lower and topic_word not in query_lower:
                issues.append(f"TOPIC CONTAMINATION: '{phrase}' mentioned but not asked about")
                return {
                    "approved": False,
                    "issues": issues,
                    "severity": "HIGH",
                    "fix": "regenerate_focused"
                }

        # KILL RULE 1d: Excessive personal name usage
        # Maven should not use the user's name unless specifically asked about creator
        query_lower = query.lower() if query else ""
        is_creator_question = any(phrase in query_lower for phrase in [
            "who created you", "who made you", "who built you",
            "your creator", "your maker", "your author",
            "who is your creator", "who's your creator"
        ])

        if not is_creator_question:
            # Check for excessive personal name usage (names appear 2+ times)
            import re
            # Common first names pattern - capitalized words that appear multiple times
            words = response.split()
            capitalized_words = [w for w in words if w and w[0].isupper() and len(w) > 2]
            word_counts = {}
            for w in capitalized_words:
                clean_w = re.sub(r'[^\w]', '', w)
                if clean_w and clean_w[0].isupper():
                    word_counts[clean_w] = word_counts.get(clean_w, 0) + 1

            # If any name-like word appears 3+ times, it's excessive
            for word, count in word_counts.items():
                if count >= 3 and word not in ["Maven", "I", "The", "This", "That", "What", "How", "Why", "When", "Where"]:
                    issues.append(f"EXCESSIVE NAME: '{word}' used {count} times - don't overuse personal names")
                    return {
                        "approved": False,
                        "issues": issues,
                        "severity": "MEDIUM",
                        "fix": "regenerate_without_name"
                    }

        # KILL RULE 1e: Context denial detection (FIX 12)
        # Catches when teacher says "I don't have that stored" but context was provided.
        # The actual grounding check (comparing against context) happens in _post_check_response()
        # in run_maven.py, which has access to the context. Here we just flag the denial pattern.
        context_denial_phrases = [
            "i don't have that information",
            "i don't have that stored",
            "i don't have that in memory",
            "i don't have that in my memory",
            "i'm not sure about that detail",
            "i don't have information about",
            "i don't recall",
            "i don't have a record",
            "we didn't discuss",
            "i don't have your",
            "i don't have that specific information",
        ]

        # Only flag if this looks like a memory/recall question (not a capability question)
        is_memory_query = any(p in query_lower for p in [
            "what", "who", "when", "where", "how many", "how much",
            "my name", "my ", "about me", "do you know", "do you remember",
            "did we", "what did", "tell me about", "summary", "summarize",
            "what was", "what were", "recall", "remember",
        ])

        if is_memory_query:
            for phrase in context_denial_phrases:
                if phrase in response_lower:
                    issues.append(f"CONTEXT_DENIAL: Response claims '{phrase}' — may be ignoring provided context")
                    return {
                        "approved": False,
                        "issues": issues,
                        "severity": "HIGH",
                        "fix": "regenerate_grounded",
                        "denial_phrase": phrase,
                    }

        # KILL RULE 2: Too short (Grok's addition)
        # But allow short responses for greetings, identity questions, and casual chat
        word_count = len(response.split()) if response else 0
        query_lower = query.lower().strip()

        # Pure greetings - "Hello!" is a valid response, allow 1+ words
        is_pure_greeting = query_lower in ["hi", "hello", "hey", "yo", "hiya", "greetings"]

        # Other casual queries that can have short responses (5+ words)
        allows_short = any([
            "short" in query_lower,
            "how are you" in query_lower,
            "who are you" in query_lower,
            "what are you" in query_lower,
            "your name" in query_lower,
            "thanks" in query_lower,
            "thank you" in query_lower,
            # Added: More conversational patterns that allow short responses
            query_lower.startswith("who "),
            query_lower.startswith("what "),
            query_lower.startswith("is "),
            query_lower.startswith("are "),
            query_lower.startswith("do "),
            query_lower.startswith("can "),
            query_lower.startswith("will "),
            "favorite" in query_lower,
            "colour" in query_lower,
            "color" in query_lower,
            "remember" in query_lower,
            "my " in query_lower,
            "?" in query,  # Questions can have shorter answers
        ])

        # Determine minimum word count based on query type
        if is_pure_greeting:
            min_words = 1  # "Hello!" is fine
        elif allows_short:
            min_words = 5  # Short but substantive
        else:
            min_words = 15  # Complex queries need real answers

        if word_count < min_words:
            issues.append(f"Response too short ({word_count} words) - likely truncation")
            return {
                "approved": False,
                "issues": issues,
                "severity": "HIGH",
                "fix": "regenerate_longer"
            }

        # Check 3: Code requested but missing
        if self._code_requested(query) and not self._has_code(response):
            issues.append("Code requested but not provided")
            return {
                "approved": False,
                "issues": issues,
                "fix": "add_code_examples"
            }

        # Check 4: Examples requested but missing
        if self._examples_requested(query) and not self._has_examples(response):
            issues.append("Examples requested but not provided")
            return {
                "approved": False,
                "issues": issues,
                "fix": "add_examples"
            }

        # Check 5: Empty or whitespace-only response
        if not response or not response.strip():
            issues.append("Empty response")
            return {
                "approved": False,
                "issues": issues,
                "severity": "CRITICAL",
                "fix": "regenerate"
            }

        # All checks passed
        return {
            "approved": True,
            "issues": [],
            "quality_score": self._calculate_quality_score(response)
        }

    def check_with_retries(
        self,
        query: str,
        response_generator: Callable[[str], str],
        max_retries: int = 3
    ) -> str:
        """
        Check response quality with retries and emergency fallback.

        Args:
            query: The user's original query
            response_generator: Function that generates a response given the query
            max_retries: Maximum number of retry attempts

        Returns:
            The approved response or emergency fallback
        """
        failed_responses = []

        for attempt in range(max_retries):
            # Generate response
            response = response_generator(query)

            # Check quality
            quality = self.check(query, response)

            if quality["approved"]:
                return response

            # Not approved - store failure
            failed_responses.append(response)
            logger.warning(f"[QUALITY] Attempt {attempt+1} failed: {quality['issues']}")
            print(f"[QUALITY_CHECK] Attempt {attempt+1} failed: {quality['issues']}")

            # Try to fix based on issues
            fix_type = quality.get("fix", "")
            if fix_type == "regenerate_with_strong_identity":
                # Add stronger identity context for next attempt
                print("[QUALITY_CHECK] Regenerating with stronger identity context...")
                continue
            elif fix_type == "regenerate_longer":
                # Request longer response
                print("[QUALITY_CHECK] Regenerating with longer output...")
                continue
            elif fix_type == "add_code_examples":
                # Add explicit code instruction
                print("[QUALITY_CHECK] Regenerating with code examples...")
                continue
            elif fix_type == "add_examples":
                # Add explicit examples instruction
                print("[QUALITY_CHECK] Regenerating with examples...")
                continue

        # All retries failed - use emergency fallback
        return self.emergency_fallback.handle_repeated_failure(query, failed_responses)

    def _code_requested(self, query: str) -> bool:
        """Check if user requested code."""
        keywords = ['code', 'script', 'function', 'program', 'show me code',
                    'write code', 'python', 'javascript', 'java', 'coding']
        return any(kw in query.lower() for kw in keywords)

    def _has_code(self, response: str) -> bool:
        """Check if response has code blocks."""
        if not response:
            return False
        return ('```' in response or
                'def ' in response or
                'function ' in response or
                'class ' in response or
                'import ' in response)

    def _examples_requested(self, query: str) -> bool:
        """Check if user requested examples."""
        keywords = ['example', 'show me', 'demonstrate', 'illustrate',
                    'give me an example', 'for instance']
        return any(kw in query.lower() for kw in keywords)

    def _has_examples(self, response: str) -> bool:
        """Check if response has concrete examples."""
        if not response:
            return False
        indicators = ['for example', 'for instance', '```', 'like:', 'such as:',
                      'e.g.', 'here is', "here's", 'consider:', '1.', '- ']
        return any(ind in response.lower() for ind in indicators)

    def _calculate_quality_score(self, response: str) -> float:
        """
        Calculate a quality score for an approved response.

        Higher scores indicate better quality:
        - Length: Appropriate length scores higher
        - Structure: Well-structured responses score higher
        - Completeness: Complete sentences score higher

        Returns:
            Float between 0.0 and 1.0
        """
        if not response:
            return 0.0

        score = 0.5  # Base score

        # Length bonus (optimal: 50-500 words)
        word_count = len(response.split())
        if 50 <= word_count <= 500:
            score += 0.2
        elif 20 <= word_count < 50 or 500 < word_count <= 1000:
            score += 0.1

        # Structure bonus (paragraphs, lists, code blocks)
        if '\n\n' in response:
            score += 0.1
        if '```' in response:
            score += 0.1
        if any(marker in response for marker in ['1.', '2.', '- ', '* ']):
            score += 0.1

        return min(1.0, score)


class EmergencyFallback:
    """
    Emergency fallback when quality check fails repeatedly.
    Never let Maven hang or return garbage.
    """

    def __init__(self, memory_librarian=None):
        self.memory = memory_librarian
        self.max_retries = 3

    def handle_repeated_failure(self, query: str, failed_responses: List[str]) -> str:
        """
        Emergency fallback after 3 failed quality checks.

        Args:
            query: The user's original query
            failed_responses: List of failed response attempts

        Returns:
            A safe fallback response
        """
        logger.error(f"[EMERGENCY_FALLBACK] 3 quality failures for: {query}")
        print(f"[EMERGENCY_FALLBACK] 3 quality failures for query: {query[:50]}...")

        # Get any relevant facts from memory
        facts_text = ""
        if self.memory:
            try:
                if hasattr(self.memory, 'search'):
                    facts = self.memory.search(query=query, limit=3)
                elif hasattr(self.memory, 'retrieve'):
                    facts = self.memory.retrieve(query=query, limit=3)
                else:
                    facts = []

                if facts:
                    facts_text = "\n\nHere's what I know:\n" + "\n".join([
                        f"- {f.get('content', str(f))[:100]}" for f in facts
                    ])
            except Exception as e:
                logger.warning(f"[EMERGENCY_FALLBACK] Memory search failed: {e}")

        # Try to extract any useful content from failed responses
        useful_content = self._extract_useful_content(failed_responses)
        if useful_content:
            facts_text += f"\n\n{useful_content}"

        return f"""I'm having trouble generating a perfect response right now.

Let me be direct: {facts_text}

Could you rephrase your question or let me know if you want me to try a different approach?"""

    def _extract_useful_content(self, failed_responses: List[str]) -> str:
        """
        Try to extract any useful content from failed responses.

        Args:
            failed_responses: List of failed response attempts

        Returns:
            Any useful extracted content
        """
        for response in failed_responses:
            if not response:
                continue

            # Skip responses that are too short
            if len(response.split()) < 10:
                continue

            # Skip responses with identity violations
            violations = ['large language model', 'ai assistant created by',
                          "i don't have memory", "i can't execute"]
            if any(v in response.lower() for v in violations):
                continue

            # If we have a decent response without violations, use first part
            lines = response.split('\n')
            useful_lines = []
            for line in lines[:5]:  # First 5 lines
                if len(line.strip()) > 10:
                    useful_lines.append(line.strip())
            if useful_lines:
                return '\n'.join(useful_lines)

        return ""


# Export public API
__all__ = [
    "ResponseQualityChecker",
    "EmergencyFallback",
]
