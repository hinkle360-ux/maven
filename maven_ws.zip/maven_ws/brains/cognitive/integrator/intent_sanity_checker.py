"""
Intent Sanity Checker
=====================

Final gate that verifies the response actually fulfills the user's request.

This prevents nonsense like:
- User: "maven have a convo with grok about medicine for 20 minutes"
- Bad response: "Maven and Grok are Java tools..."

The sanity checker asks: "Does this response actually DO what the user asked?"
If not, it either reroutes or fails gracefully.
"""

from __future__ import annotations
import re
from enum import Enum
from typing import Dict, Any, Optional, List
from dataclasses import dataclass

# Import intent classifier
try:
    from brains.cognitive.integrator.intent_classifier import (
        IntentType,
        classify_intent,
        get_capability_for_query,
    )
    _classifier_available = True
except ImportError:
    _classifier_available = False


class SanityVerdict(Enum):
    """Result of sanity check."""
    PASS = "pass"              # Response matches intent
    FAIL_WRONG_TYPE = "fail_wrong_type"    # Action request got explanation
    FAIL_TOOL_NOT_CALLED = "fail_tool_not_called"  # Tool should have been called
    FAIL_INCOMPLETE = "fail_incomplete"      # Action started but not completed
    REROUTE = "reroute"            # Should try a different route


@dataclass
class SanityCheckResult:
    """Result of the sanity check."""
    verdict: SanityVerdict
    confidence: float
    reasoning: str
    suggested_action: Optional[str] = None  # e.g., "call_agency_tool:grok_conversation"
    original_intent: Optional[IntentType] = None
    response_type_detected: Optional[str] = None  # "explanation", "action_confirmation", etc.


# ============================================================================
# Response Type Detection
# ============================================================================

def detect_response_type(response: str) -> str:
    """
    Detect what type of response this is.

    Returns one of:
    - "action_confirmation": Confirms an action was taken
    - "action_in_progress": Action is happening
    - "explanation": Explains a concept
    - "refusal": Cannot do the requested action
    - "question": Asks the user for clarification
    - "small_talk": Greeting, thanks, etc.
    - "unknown": Cannot determine
    """
    response_lower = response.lower()

    # Action confirmation patterns
    action_patterns = [
        r"i('ll| will) (do|start|run|execute|open|send|post|create)",
        r"(starting|running|executing|opening|sending|posting|creating)",
        r"(done|completed|finished|success)",
        r"i('ve| have) (started|run|executed|opened|sent|posted|created)",
        r"here('s| is) (the|your) (result|output)",
        r"session (started|complete|finished)",
        r"(talking|chatting|conversing) with",
    ]

    for pattern in action_patterns:
        if re.search(pattern, response_lower):
            return "action_confirmation"

    # Refusal patterns
    refusal_patterns = [
        r"i (can't|cannot|can not|won't|am not able to)",
        r"(sorry|unfortunately).*(can't|cannot|unable|not able)",
        r"this (is|isn't) not (possible|available|configured)",
        r"(tool|feature|capability) (is|isn't) not (available|configured|enabled)",
    ]

    for pattern in refusal_patterns:
        if re.search(pattern, response_lower):
            return "refusal"

    # Question patterns (asking for clarification)
    question_patterns = [
        r"what (do you|would you) (mean|like|want)",
        r"could you (clarify|specify|explain)",
        r"which (one|file|option)",
        r"\?$",
    ]

    for pattern in question_patterns:
        if re.search(pattern, response_lower):
            return "question"

    # Explanation patterns - these indicate we're EXPLAINING not DOING
    explanation_patterns = [
        r"^(maven|grok|chatgpt|python|java) (is|are) (a|an|the)",
        r"^(the|a|an) \w+ (is|are) (a|an|the)",
        r"(here('s| is) (an|a) (explanation|overview|summary))",
        r"(let me explain|to understand|basically|essentially)",
        r"(in (this|the) (context|case)|fundamentally)",
        r"^\*\*understanding",
        r"^\*\*what (is|are)",
        r"introduction:\s*\n",  # Structured explanation
        r"^\d+\.\s+\*\*",  # Numbered list with headers = explanation
    ]

    for pattern in explanation_patterns:
        if re.search(pattern, response_lower, re.MULTILINE):
            return "explanation"

    # Small talk
    small_talk_patterns = [
        r"^(hi|hello|hey|good (morning|afternoon|evening))",
        r"^(you're welcome|no problem|glad to help)",
        r"^(thanks|thank you) for",
    ]

    for pattern in small_talk_patterns:
        if re.search(pattern, response_lower):
            return "small_talk"

    return "unknown"


# ============================================================================
# Main Sanity Checker
# ============================================================================

def check_intent_sanity(
    user_query: str,
    draft_response: str,
    context: Optional[Dict[str, Any]] = None
) -> SanityCheckResult:
    """
    Check if the draft response actually satisfies the user's intent.

    This is the FINAL GATE before a response is returned to the user.

    Args:
        user_query: The original user query
        draft_response: The response we're about to return
        context: Optional context with routing info, tool calls, etc.

    Returns:
        SanityCheckResult indicating if the response is appropriate
    """
    context = context or {}

    # -------------------------------------------------------------------------
    # Step 1: Classify the original intent
    # -------------------------------------------------------------------------
    if _classifier_available:
        intent_classification = classify_intent(user_query)
        original_intent = intent_classification.intent_type
        matched_capability = intent_classification.matched_capability
    else:
        original_intent = IntentType.QUESTION
        matched_capability = None

    # -------------------------------------------------------------------------
    # Step 2: Detect what type of response we generated
    # -------------------------------------------------------------------------
    response_type = detect_response_type(draft_response)

    # -------------------------------------------------------------------------
    # Step 3: Check for mismatches
    # -------------------------------------------------------------------------

    # CRITICAL CHECK: Action request got an explanation
    if original_intent == IntentType.ACTION_REQUEST and response_type == "explanation":
        # This is the exact bug: user asked for action, got explanation
        return SanityCheckResult(
            verdict=SanityVerdict.FAIL_WRONG_TYPE,
            confidence=0.9,
            reasoning=f"User requested an action (capability: {matched_capability}) but got an explanation instead",
            suggested_action=f"call_agency_tool:{matched_capability}" if matched_capability else "retry_as_action",
            original_intent=original_intent,
            response_type_detected=response_type,
        )

    # Check if a tool should have been called but wasn't
    if original_intent == IntentType.ACTION_REQUEST:
        tool_was_called = context.get("agency_tool_executed", False)
        tool_was_attempted = context.get("agency_tool") is not None

        if matched_capability and not tool_was_called and not tool_was_attempted:
            return SanityCheckResult(
                verdict=SanityVerdict.FAIL_TOOL_NOT_CALLED,
                confidence=0.85,
                reasoning=f"Action request for '{matched_capability}' but no tool was called",
                suggested_action=f"call_agency_tool:{matched_capability}",
                original_intent=original_intent,
                response_type_detected=response_type,
            )

    # Check for refusals - these are acceptable if the tool genuinely can't work
    if response_type == "refusal":
        # Refusals are okay - user gets clear feedback
        return SanityCheckResult(
            verdict=SanityVerdict.PASS,
            confidence=0.8,
            reasoning="Response is a clear refusal with explanation",
            original_intent=original_intent,
            response_type_detected=response_type,
        )

    # Check for action confirmation - this is what we want for action requests
    if original_intent == IntentType.ACTION_REQUEST and response_type == "action_confirmation":
        return SanityCheckResult(
            verdict=SanityVerdict.PASS,
            confidence=0.95,
            reasoning="Action request received action confirmation",
            original_intent=original_intent,
            response_type_detected=response_type,
        )

    # Questions getting explanations is correct
    if original_intent == IntentType.QUESTION and response_type == "explanation":
        return SanityCheckResult(
            verdict=SanityVerdict.PASS,
            confidence=0.9,
            reasoning="Question received explanation",
            original_intent=original_intent,
            response_type_detected=response_type,
        )

    # Default: pass with lower confidence
    return SanityCheckResult(
        verdict=SanityVerdict.PASS,
        confidence=0.6,
        reasoning="No clear mismatch detected",
        original_intent=original_intent,
        response_type_detected=response_type,
    )


def should_reroute(check_result: SanityCheckResult) -> bool:
    """Check if we should reroute based on sanity check result."""
    return check_result.verdict in (
        SanityVerdict.FAIL_WRONG_TYPE,
        SanityVerdict.FAIL_TOOL_NOT_CALLED,
        SanityVerdict.REROUTE,
    )


def get_reroute_target(check_result: SanityCheckResult) -> Optional[str]:
    """Get the suggested reroute target."""
    if check_result.suggested_action and check_result.suggested_action.startswith("call_agency_tool:"):
        return check_result.suggested_action.split(":", 1)[1]
    return None


# ============================================================================
# Quick API
# ============================================================================

def is_response_sane(
    user_query: str,
    draft_response: str,
    context: Optional[Dict[str, Any]] = None
) -> bool:
    """
    Quick check: is this response appropriate for the query?

    Returns True if the response passes sanity check, False otherwise.
    """
    result = check_intent_sanity(user_query, draft_response, context)
    return result.verdict == SanityVerdict.PASS
