"""
LLM Intent Classifier
=====================

Uses Teacher LLM to classify user intent, then learns from outcomes.
Much smarter than pattern matching - understands semantic meaning.

This replaces brittle keyword-based routing with true intent understanding:
- "give me examples of python" -> code_generation (not just "show me code")
- "demonstrate how to use loops" -> code_generation
- "can you write a script for me" -> code_generation
- "I need help with programming" -> code_generation

ARCHITECTURE:
1. Check learned patterns first (FAST PATH - no LLM call)
2. If no match or low confidence, use LLM to classify (LEARNING PATH)
3. Store classifications for future learning
4. Learn from user corrections to improve routing

MEMORY-FIRST PRINCIPLE:
We always check memory/patterns before calling the LLM. The LLM is a teacher,
not the primary classifier. Over time, the system learns and needs fewer LLM calls.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from brains.maven_paths import get_state_path
from typing import Any, Dict, List, Optional, Tuple

# Import teacher for LLM classification
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_available = True
except ImportError:
    _teacher_available = False
    TeacherHelper = None  # type: ignore

# Import memory librarian for storing learned patterns
try:
    from brains.cognitive.memory_librarian.service.memory_librarian import (
        MemoryLibrarian,
        get_memory_librarian,
    )
    _memory_available = True
except ImportError:
    _memory_available = False
    MemoryLibrarian = None  # type: ignore
    get_memory_librarian = None  # type: ignore

# Import upgrade engine for generating upgrade proposals
try:
    from brains.governance.upgrade_engine.service.upgrade_engine import (
        UpgradeEngine,
        get_upgrade_engine,
    )
    _upgrade_engine_available = True
except ImportError:
    _upgrade_engine_available = False
    UpgradeEngine = None  # type: ignore
    get_upgrade_engine = None  # type: ignore

# Storage paths
MAVEN_DIR = get_state_path()
ROUTING_PATTERNS_PATH = MAVEN_DIR / "routing" / "learned_patterns.json"
ROUTING_CORRECTIONS_PATH = MAVEN_DIR / "routing" / "corrections.jsonl"
ROUTING_STATS_PATH = MAVEN_DIR / "routing" / "routing_stats.json"


def _ensure_dir(path: Path) -> None:
    """Ensure parent directory exists."""
    path.parent.mkdir(parents=True, exist_ok=True)


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class IntentClassification:
    """
    Result of LLM intent classification.

    Captures everything needed for routing decisions and learning.
    """
    primary_intent: str  # code_generation, factual_question, self_query, etc.
    user_expectation: str  # code, explanation, data, action
    recommended_brains: List[str]
    recommended_tools: List[str] = field(default_factory=list)
    secondary_intents: List[str] = field(default_factory=list)
    confidence: float = 0.5
    reasoning: str = ""
    source: str = "llm"  # "llm", "cached", "pattern", "fallback"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "IntentClassification":
        return cls(
            primary_intent=data.get("primary_intent", "unknown"),
            user_expectation=data.get("user_expectation", "unknown"),
            recommended_brains=data.get("recommended_brains", ["language"]),
            recommended_tools=data.get("recommended_tools", []),
            secondary_intents=data.get("secondary_intents", []),
            confidence=data.get("confidence", 0.5),
            reasoning=data.get("reasoning", ""),
            source=data.get("source", "unknown"),
            timestamp=data.get("timestamp", datetime.now().isoformat()),
        )


@dataclass
class RoutingOutcome:
    """
    Outcome of a routing decision, used for learning.
    """
    verdict: str  # "ok", "correction", "incomplete"
    should_have_routed_to: Optional[str] = None
    user_feedback: Optional[str] = None
    brains_used: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())


# =============================================================================
# AVAILABLE BRAINS REGISTRY
# =============================================================================

AVAILABLE_BRAINS = {
    "coder": {
        "capability": "Generate, analyze, and explain code",
        "best_for": ["code examples", "scripts", "functions", "debugging", "programming help"],
        "output_type": "code + explanation",
        "keywords": ["code", "script", "function", "program", "debug", "python", "javascript",
                    "implement", "write code", "coding", "programming", "developer"]
    },
    "reasoning": {
        "capability": "Answer questions using facts and logic",
        "best_for": ["explanations", "how things work", "factual queries", "analysis"],
        "output_type": "explanation",
        "keywords": ["explain", "why", "how", "understand", "reason", "analyze", "think"]
    },
    "self_model": {
        "capability": "Answer questions about Maven itself",
        "best_for": ["who/what is Maven", "Maven's code", "Maven's capabilities", "identity"],
        "output_type": "self-knowledge",
        "keywords": ["maven", "yourself", "your brains", "your architecture", "who are you"]
    },
    "planner": {
        "capability": "Break down complex tasks into steps",
        "best_for": ["multi-step tasks", "project planning", "workflows", "sequences"],
        "output_type": "step-by-step plan",
        "keywords": ["plan", "steps", "workflow", "sequence", "break down", "organize"]
    },
    "research_manager": {
        "capability": "Deep research using web search",
        "best_for": ["current events", "research topics", "fact-finding", "news"],
        "output_type": "research report",
        "keywords": ["research", "search", "find out", "look up", "current", "news", "latest"]
    },
    "language": {
        "capability": "Creative writing and text generation",
        "best_for": ["stories", "emails", "documents", "creative content", "conversation"],
        "output_type": "prose",
        "keywords": ["write", "email", "story", "document", "letter", "message", "chat"]
    },
    "action_engine": {
        "capability": "Execute tools and perform actions",
        "best_for": ["file operations", "shell commands", "system tasks"],
        "output_type": "action results",
        "keywords": ["run", "execute", "create file", "delete", "open", "launch"]
    },
    "memory_librarian": {
        "capability": "Manage and retrieve memories",
        "best_for": ["recall past conversations", "what we discussed", "remember"],
        "output_type": "memory retrieval",
        "keywords": ["remember", "recall", "what did we", "earlier", "last time", "history"]
    },
}


# =============================================================================
# LLM INTENT CLASSIFIER
# =============================================================================

class LLMIntentClassifier:
    """
    Classify user intent using LLM understanding.
    Learns from successful and failed routings.

    MEMORY-FIRST: Always check learned patterns before calling LLM.
    """

    def __init__(self, teacher_helper: Optional[TeacherHelper] = None):
        """
        Initialize the classifier.

        Args:
            teacher_helper: Optional TeacherHelper instance. If None, will create one.
        """
        self.teacher = teacher_helper
        self.memory = get_memory_librarian() if _memory_available and get_memory_librarian else None

        # Load learned patterns from disk
        self.learned_patterns: Dict[str, Dict[str, Any]] = {}
        self._load_learned_patterns()

        # Stats tracking
        self.stats = {
            "total_classifications": 0,
            "cache_hits": 0,
            "llm_calls": 0,
            "corrections_received": 0,
            "patterns_learned": 0,
        }
        self._load_stats()

    def _load_learned_patterns(self) -> None:
        """Load learned routing patterns from disk."""
        try:
            if ROUTING_PATTERNS_PATH.exists():
                with ROUTING_PATTERNS_PATH.open("r", encoding="utf-8") as f:
                    self.learned_patterns = json.load(f)
                print(f"[LLM_CLASSIFIER] Loaded {len(self.learned_patterns)} learned patterns")
        except Exception as e:
            print(f"[LLM_CLASSIFIER] Failed to load patterns: {e}")
            self.learned_patterns = {}

    def _save_learned_patterns(self) -> None:
        """Save learned routing patterns to disk."""
        try:
            _ensure_dir(ROUTING_PATTERNS_PATH)
            with ROUTING_PATTERNS_PATH.open("w", encoding="utf-8") as f:
                json.dump(self.learned_patterns, f, indent=2)
        except Exception as e:
            print(f"[LLM_CLASSIFIER] Failed to save patterns: {e}")

    def _load_stats(self) -> None:
        """Load routing stats from disk."""
        try:
            if ROUTING_STATS_PATH.exists():
                with ROUTING_STATS_PATH.open("r", encoding="utf-8") as f:
                    self.stats.update(json.load(f))
        except Exception:
            pass

    def _save_stats(self) -> None:
        """Save routing stats to disk."""
        try:
            _ensure_dir(ROUTING_STATS_PATH)
            with ROUTING_STATS_PATH.open("w", encoding="utf-8") as f:
                json.dump(self.stats, f, indent=2)
        except Exception:
            pass

    def classify_intent(self, query: str, context: Optional[Dict[str, Any]] = None) -> IntentClassification:
        """
        Classify user intent using LLM.

        MEMORY-FIRST: Check learned patterns before calling LLM.

        Args:
            query: The user's query text
            context: Optional conversation context

        Returns:
            IntentClassification with routing recommendations
        """
        self.stats["total_classifications"] += 1

        if not query:
            return self._fallback_classification("empty query")

        # STEP 1: Check for learned pattern (FAST PATH)
        cached = self._check_learned_patterns(query)
        if cached and cached.confidence > 0.85:
            self.stats["cache_hits"] += 1
            print(f"[LLM_CLASSIFIER] Cache hit: '{query[:50]}...' -> {cached.recommended_brains}")
            return cached

        # STEP 2: Quick pattern matching for high-confidence cases
        pattern_match = self._quick_pattern_match(query)
        if pattern_match and pattern_match.confidence > 0.9:
            self._store_classification(query, pattern_match)
            return pattern_match

        # STEP 3: Use LLM to classify (LEARNING PATH)
        self.stats["llm_calls"] += 1
        classification = self._classify_with_llm(query, context)

        # Store for learning
        self._store_classification(query, classification)
        self._save_stats()

        return classification

    def _quick_pattern_match(self, query: str) -> Optional[IntentClassification]:
        """
        Quick pattern matching for obvious cases.
        This avoids LLM calls for very clear intents.
        """
        query_lower = query.lower().strip()

        # Code generation patterns (expanded)
        code_patterns = [
            r"^(write|create|generate|make|build)\s+(a\s+)?(code|script|function|program|class)",
            r"^(show|give)\s+(me\s+)?(code|examples?)\s+(of|for)",
            r"(code|script|function)\s+(for|that|to)\s+",
            r"^(how\s+to|how\s+do\s+i)\s+(code|implement|program|write)",
            r"(python|javascript|java|c\+\+|typescript|rust|go)\s+(code|script|function|example)",
            r"^can\s+you\s+(write|create|generate|make)\s+(a\s+)?(code|script|program)",
            r"^(demonstrate|illustrate)\s+how\s+to\s+(use|implement|code)",
            r"help\s+(me\s+)?(with\s+)?(coding|programming|debugging)",
            r"^i\s+need\s+(a\s+)?(code|script|program|function)",
        ]

        for pattern in code_patterns:
            if re.search(pattern, query_lower):
                return IntentClassification(
                    primary_intent="code_generation",
                    user_expectation="code",
                    recommended_brains=["coder", "reasoning"],
                    recommended_tools=["python_exec"],
                    confidence=0.92,
                    reasoning="Matched code generation pattern",
                    source="pattern",
                )

        # Self-query patterns
        self_patterns = [
            r"^(who|what)\s+(are|is)\s+you",
            r"^tell\s+me\s+about\s+yourself",
            r"your\s+(brains?|architecture|capabilities|system)",
            r"^(how\s+do\s+you|what\s+can\s+you)",
            r"^introduce\s+yourself",
        ]

        for pattern in self_patterns:
            if re.search(pattern, query_lower):
                return IntentClassification(
                    primary_intent="self_query",
                    user_expectation="self-knowledge",
                    recommended_brains=["self_model"],
                    confidence=0.95,
                    reasoning="Matched self-query pattern",
                    source="pattern",
                )

        # Research patterns
        research_patterns = [
            r"^(research|look\s+up|search\s+for|find\s+out)",
            r"(latest|current|recent)\s+(news|updates|information)",
            r"^what\s+is\s+happening\s+(with|in)",
        ]

        for pattern in research_patterns:
            if re.search(pattern, query_lower):
                return IntentClassification(
                    primary_intent="research",
                    user_expectation="research report",
                    recommended_brains=["research_manager", "reasoning"],
                    recommended_tools=["web_search"],
                    confidence=0.90,
                    reasoning="Matched research pattern",
                    source="pattern",
                )

        # Planning patterns
        plan_patterns = [
            r"^(plan|break\s+down|organize|outline)",
            r"^(step\s+by\s+step|how\s+should\s+i\s+approach)",
            r"(create|make)\s+(a\s+)?(plan|workflow|roadmap)",
        ]

        for pattern in plan_patterns:
            if re.search(pattern, query_lower):
                return IntentClassification(
                    primary_intent="planning",
                    user_expectation="step-by-step plan",
                    recommended_brains=["planner", "reasoning"],
                    confidence=0.88,
                    reasoning="Matched planning pattern",
                    source="pattern",
                )

        return None

    def _classify_with_llm(self, query: str, context: Optional[Dict[str, Any]] = None) -> IntentClassification:
        """
        Use Teacher LLM to understand user intent.

        This is called only when:
        1. No learned pattern exists
        2. Pattern match has low confidence
        """
        # Build classification prompt
        prompt = self._build_classification_prompt(query, context)

        # Try to get teacher response
        if self.teacher and _teacher_available:
            try:
                response = self.teacher.teach_for_brain(
                    brain_name="routing",
                    question=prompt,
                    response_plan={"mode": "short", "format": "json"}
                )

                if response and response.get("answer"):
                    classification = self._parse_classification(response["answer"])
                    classification.source = "llm"
                    return classification

            except Exception as e:
                print(f"[LLM_CLASSIFIER] Teacher call failed: {e}")

        # Try alternative: use Ollama directly if teacher not available
        try:
            from brains.cognitive.teacher.ollama_client import call_ollama

            system_msg = "You are an intent classifier. Respond ONLY with valid JSON."
            response = call_ollama(
                prompt=prompt,
                system=system_msg,
                max_tokens=500,
                temperature=0.1,
            )

            if response:
                classification = self._parse_classification(response)
                classification.source = "llm"
                return classification

        except Exception as e:
            print(f"[LLM_CLASSIFIER] Ollama call failed: {e}")

        # Fallback to keyword-based classification
        return self._keyword_based_classification(query)

    def _build_classification_prompt(self, query: str, context: Optional[Dict[str, Any]] = None) -> str:
        """Build prompt for LLM intent classification."""

        brain_descriptions = "\n".join([
            f"- {name}: {info['capability']} (best for: {', '.join(info['best_for'])})"
            for name, info in AVAILABLE_BRAINS.items()
        ])

        context_str = ""
        if context:
            recent_turns = context.get("recent_turns", [])
            if recent_turns:
                context_str = f"\nRECENT CONVERSATION:\n{json.dumps(recent_turns[-3:], indent=2)}"

        return f'''Analyze this user query and determine the best routing.

USER QUERY: "{query}"
{context_str}

AVAILABLE BRAINS:
{brain_descriptions}

YOUR TASK:
Determine which brain(s) should handle this query.

Consider:
1. What is the user REALLY asking for? Look beyond keywords.
2. What type of response do they expect? (code, explanation, action, etc.)
3. Which brain is BEST suited to provide that?

IMPORTANT:
- "show me examples of python" = code_generation (they want CODE, not explanation)
- "demonstrate how to use loops" = code_generation (they want CODE examples)
- "can you write a script" = code_generation (they want CODE)
- "I need help with programming" = code_generation (they likely want CODE)
- "explain how loops work" = factual_question (they want EXPLANATION)

Respond in this EXACT JSON format:
{{
  "primary_intent": "<one of: code_generation, factual_question, self_query, creative_writing, data_analysis, reasoning_problem, small_talk, system_command, research, planning>",
  "user_expectation": "<what user expects: code, explanation, data, action, conversation>",
  "recommended_brains": ["<brain1>", "<brain2>"],
  "recommended_tools": ["<tool1>", "<tool2>"],
  "confidence": 0.95,
  "reasoning": "<explain why this routing makes sense>"
}}

Classification:'''

    def _parse_classification(self, response: str) -> IntentClassification:
        """Parse LLM classification response."""
        try:
            # Look for JSON block in response
            json_match = re.search(r'\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\}', response, re.DOTALL)
            if json_match:
                data = json.loads(json_match.group())

                # Validate required fields
                if "primary_intent" in data and "recommended_brains" in data:
                    return IntentClassification(
                        primary_intent=data.get("primary_intent", "unknown"),
                        user_expectation=data.get("user_expectation", "unknown"),
                        recommended_brains=data.get("recommended_brains", ["language"]),
                        recommended_tools=data.get("recommended_tools", []),
                        confidence=float(data.get("confidence", 0.7)),
                        reasoning=data.get("reasoning", "")[:200],
                        source="llm",
                    )
        except json.JSONDecodeError:
            pass
        except Exception as e:
            print(f"[LLM_CLASSIFIER] Parse error: {e}")

        # Fallback: extract from text
        return self._extract_from_text(response)

    def _extract_from_text(self, response: str) -> IntentClassification:
        """Extract classification from unstructured text response."""
        response_lower = response.lower()

        # Try to infer intent from response text
        intent = "unknown"
        brains = ["language"]

        if any(w in response_lower for w in ["code", "script", "programming", "coder"]):
            intent = "code_generation"
            brains = ["coder", "reasoning"]
        elif any(w in response_lower for w in ["research", "search", "web"]):
            intent = "research"
            brains = ["research_manager"]
        elif any(w in response_lower for w in ["self", "maven", "identity"]):
            intent = "self_query"
            brains = ["self_model"]
        elif any(w in response_lower for w in ["plan", "steps", "workflow"]):
            intent = "planning"
            brains = ["planner"]
        elif any(w in response_lower for w in ["explain", "reason", "factual"]):
            intent = "factual_question"
            brains = ["reasoning"]

        return IntentClassification(
            primary_intent=intent,
            user_expectation="unknown",
            recommended_brains=brains,
            confidence=0.5,
            reasoning=response[:200],
            source="llm_extracted",
        )

    def _keyword_based_classification(self, query: str) -> IntentClassification:
        """
        Fallback keyword-based classification when LLM is unavailable.

        This is better than nothing but less accurate than LLM.
        """
        query_lower = query.lower()

        # Score each brain based on keyword matches
        brain_scores: Dict[str, float] = {}

        for brain_name, brain_info in AVAILABLE_BRAINS.items():
            score = 0.0
            keywords = brain_info.get("keywords", [])

            for keyword in keywords:
                if keyword in query_lower:
                    score += 1.0

            # Normalize by keyword count
            if keywords:
                brain_scores[brain_name] = score / len(keywords)

        # Get best matching brain
        if brain_scores:
            best_brain = max(brain_scores, key=brain_scores.get)
            best_score = brain_scores[best_brain]

            if best_score > 0:
                brain_info = AVAILABLE_BRAINS.get(best_brain, {})
                return IntentClassification(
                    primary_intent=brain_info.get("best_for", ["query"])[0].replace(" ", "_"),
                    user_expectation=brain_info.get("output_type", "unknown"),
                    recommended_brains=[best_brain],
                    confidence=min(best_score + 0.3, 0.7),  # Cap at 0.7 for keyword matching
                    reasoning="Keyword-based classification",
                    source="fallback",
                )

        return self._fallback_classification("no keywords matched")

    def _fallback_classification(self, reason: str) -> IntentClassification:
        """Return safe fallback classification."""
        return IntentClassification(
            primary_intent="unknown",
            user_expectation="unknown",
            recommended_brains=["language"],
            confidence=0.3,
            reasoning=f"Fallback: {reason}",
            source="fallback",
        )

    def _check_learned_patterns(self, query: str) -> Optional[IntentClassification]:
        """
        Check if we've learned a pattern for similar queries.

        Uses:
        1. Exact match in learned patterns
        2. Similarity search in memory (if available)
        """
        query_key = query.lower().strip()

        # Check exact match in learned patterns
        if query_key in self.learned_patterns:
            pattern = self.learned_patterns[query_key]
            classification = IntentClassification.from_dict(pattern.get("classification", {}))
            classification.source = "cached"
            return classification

        # Check for similar patterns (fuzzy match)
        for stored_query, pattern in self.learned_patterns.items():
            # Simple similarity: check if most words match
            stored_words = set(stored_query.split())
            query_words = set(query_key.split())

            if len(stored_words) > 2 and len(query_words) > 2:
                intersection = stored_words & query_words
                union = stored_words | query_words
                similarity = len(intersection) / len(union) if union else 0

                if similarity > 0.7:
                    classification = IntentClassification.from_dict(pattern.get("classification", {}))
                    classification.source = "cached"
                    classification.confidence = min(classification.confidence, 0.8)  # Reduce for fuzzy match
                    return classification

        # Check memory for similar queries (if available)
        if self.memory and _memory_available:
            try:
                similar = self.memory.search(
                    query=query,
                    domain="routing_patterns",
                    limit=3
                )

                if similar:
                    for item in similar:
                        similarity_score = item.get("similarity", 0)
                        if similarity_score > 0.85:
                            metadata = item.get("metadata", {})
                            if "classification" in metadata:
                                classification = IntentClassification.from_dict(metadata["classification"])
                                classification.source = "memory"
                                return classification
            except Exception as e:
                print(f"[LLM_CLASSIFIER] Memory search failed: {e}")

        return None

    def _store_classification(self, query: str, classification: IntentClassification) -> None:
        """Store classification for future learning."""
        query_key = query.lower().strip()

        # Store in local patterns
        self.learned_patterns[query_key] = {
            "query": query,
            "classification": classification.to_dict(),
            "timestamp": datetime.now().isoformat(),
            "reinforcement_count": 1,
        }

        self._save_learned_patterns()
        self.stats["patterns_learned"] = len(self.learned_patterns)

        # Also store in memory (if available)
        if self.memory and _memory_available:
            try:
                self.memory.store(
                    content=f"Routing: {query} -> {classification.recommended_brains}",
                    domain="routing_patterns",
                    tags=["routing_decision", "intent_classification"],
                    importance=0.7,
                    metadata={
                        "query": query,
                        "classification": classification.to_dict(),
                        "timestamp": datetime.now().isoformat(),
                    }
                )
            except Exception as e:
                print(f"[LLM_CLASSIFIER] Memory store failed: {e}")

    def learn_from_outcome(self, query: str, classification: IntentClassification,
                          outcome: RoutingOutcome) -> None:
        """
        Learn from routing outcome.

        If routing was good (user satisfied), reinforce pattern.
        If routing was bad (user corrected), learn correction.
        """
        self.stats["corrections_received"] += 1 if outcome.verdict == "correction" else 0

        if outcome.verdict == "ok":
            # Good routing - increase confidence
            self._reinforce_pattern(query, classification)

        elif outcome.verdict == "correction":
            # User corrected us - learn better routing
            self._learn_correction(query, classification, outcome)

        elif outcome.verdict == "incomplete":
            # Routing was partial - maybe needed multiple brains
            self._learn_multi_brain_routing(query, classification, outcome)

        self._save_stats()

    def _reinforce_pattern(self, query: str, classification: IntentClassification) -> None:
        """Reinforce successful routing pattern."""
        query_key = query.lower().strip()

        if query_key in self.learned_patterns:
            pattern = self.learned_patterns[query_key]

            # Increase confidence
            old_confidence = pattern["classification"].get("confidence", 0.5)
            new_confidence = min(old_confidence + 0.05, 0.99)
            pattern["classification"]["confidence"] = new_confidence

            # Increase reinforcement count
            pattern["reinforcement_count"] = pattern.get("reinforcement_count", 1) + 1

            self._save_learned_patterns()

            print(f"[LLM_CLASSIFIER] Reinforced pattern: '{query[:30]}...' "
                  f"(confidence: {old_confidence:.2f} -> {new_confidence:.2f})")

    def _learn_correction(self, query: str, wrong_classification: IntentClassification,
                         outcome: RoutingOutcome) -> None:
        """Learn from routing mistake."""
        correct_brain = outcome.should_have_routed_to

        if not correct_brain:
            return

        query_key = query.lower().strip()

        # Update the learned pattern with correct routing
        if correct_brain in AVAILABLE_BRAINS:
            brain_info = AVAILABLE_BRAINS[correct_brain]

            corrected_classification = IntentClassification(
                primary_intent=brain_info["best_for"][0].replace(" ", "_"),
                user_expectation=brain_info["output_type"],
                recommended_brains=[correct_brain],
                confidence=0.95,  # High confidence since user corrected
                reasoning=f"Learned from user correction: {outcome.user_feedback}",
                source="correction",
            )

            self.learned_patterns[query_key] = {
                "query": query,
                "classification": corrected_classification.to_dict(),
                "timestamp": datetime.now().isoformat(),
                "reinforcement_count": 1,
                "was_correction": True,
                "original_routing": wrong_classification.recommended_brains,
            }

            self._save_learned_patterns()

        # Store correction in corrections log
        correction_entry = {
            "query": query,
            "wrong_routing": wrong_classification.to_dict(),
            "correct_routing": correct_brain,
            "user_feedback": outcome.user_feedback,
            "timestamp": datetime.now().isoformat(),
        }

        try:
            _ensure_dir(ROUTING_CORRECTIONS_PATH)
            with ROUTING_CORRECTIONS_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps(correction_entry) + "\n")
        except Exception as e:
            print(f"[LLM_CLASSIFIER] Failed to log correction: {e}")

        print(f"[LLM_CLASSIFIER] Learned correction: '{query[:30]}...' "
              f"should route to {correct_brain}, not {wrong_classification.recommended_brains}")

        # Check if we should generate an upgrade proposal
        self._check_for_upgrade_proposal(query, wrong_classification, correct_brain)

    def _learn_multi_brain_routing(self, query: str, classification: IntentClassification,
                                   outcome: RoutingOutcome) -> None:
        """Learn that query needs multiple brains."""
        query_key = query.lower().strip()

        if query_key in self.learned_patterns:
            pattern = self.learned_patterns[query_key]

            # Add the additional brains that were needed
            current_brains = set(pattern["classification"].get("recommended_brains", []))
            used_brains = set(outcome.brains_used)

            combined_brains = list(current_brains | used_brains)
            pattern["classification"]["recommended_brains"] = combined_brains
            pattern["classification"]["reasoning"] += f" (expanded: {outcome.user_feedback or 'multi-brain needed'})"

            self._save_learned_patterns()

            print(f"[LLM_CLASSIFIER] Expanded routing: '{query[:30]}...' -> {combined_brains}")

    def _check_for_upgrade_proposal(self, query: str, wrong_classification: IntentClassification,
                                    correct_brain: str) -> None:
        """
        Check if we should generate an upgrade proposal.

        If the same mistake happens repeatedly (3+ times), generate a proposal
        to fix the routing logic permanently.
        """
        if not _upgrade_engine_available:
            return

        try:
            # Count similar corrections
            correction_count = 0
            pattern_queries = []

            if ROUTING_CORRECTIONS_PATH.exists():
                with ROUTING_CORRECTIONS_PATH.open("r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            entry = json.loads(line)
                            # Check if same wrong_routing -> correct_brain pattern
                            if (entry.get("correct_routing") == correct_brain and
                                wrong_classification.recommended_brains[0] in entry.get("wrong_routing", {}).get("recommended_brains", [])):
                                correction_count += 1
                                pattern_queries.append(entry.get("query", ""))
                        except json.JSONDecodeError:
                            continue

            # Generate upgrade proposal if pattern repeats 3+ times
            if correction_count >= 3:
                self._generate_upgrade_proposal(
                    pattern_queries=pattern_queries,
                    wrong_brain=wrong_classification.recommended_brains[0],
                    correct_brain=correct_brain,
                    count=correction_count,
                )

        except Exception as e:
            print(f"[LLM_CLASSIFIER] Failed to check for upgrade proposal: {e}")

    def _generate_upgrade_proposal(self, pattern_queries: List[str], wrong_brain: str,
                                   correct_brain: str, count: int) -> None:
        """Generate an upgrade proposal to fix repeated routing failures."""
        try:
            upgrade_engine = get_upgrade_engine() if get_upgrade_engine else None

            if not upgrade_engine:
                print(f"[LLM_CLASSIFIER] Upgrade engine not available")
                return

            proposal = {
                "id": f"routing_upgrade_{int(time.time())}",
                "origin": "llm_intent_classifier",
                "trigger": "repeated_routing_failure",

                "motivation": (
                    f"Routing is failing for a pattern of queries. "
                    f"Queries are being sent to '{wrong_brain}' when they should go to '{correct_brain}'. "
                    f"This has happened {count} times."
                ),

                "evidence": {
                    "sample_queries": pattern_queries[:5],
                    "wrong_brain": wrong_brain,
                    "correct_brain": correct_brain,
                    "occurrence_count": count,
                },

                "change_type": "routing_rule",

                "scope": [
                    "brains/cognitive/integrator/llm_intent_classifier.py",
                    "brains/routing/routing_engine.py",
                ],

                "suggested_fix": {
                    "type": "add_routing_pattern",
                    "description": f"Add pattern to route queries similar to these to {correct_brain}",
                    "route_to": correct_brain,
                    "priority": 0.95,
                },

                "risk_level": "low",
            }

            # Submit to upgrade engine
            upgrade_engine.submit_proposal(proposal)

            print(f"[LLM_CLASSIFIER] Generated upgrade proposal: {proposal['id']}")
            print(f"  - Pattern: '{wrong_brain}' -> '{correct_brain}' ({count} occurrences)")

        except Exception as e:
            print(f"[LLM_CLASSIFIER] Failed to generate upgrade proposal: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get routing statistics."""
        return {
            **self.stats,
            "pattern_count": len(self.learned_patterns),
            "cache_hit_rate": (
                self.stats["cache_hits"] / self.stats["total_classifications"]
                if self.stats["total_classifications"] > 0 else 0
            ),
        }


# =============================================================================
# SINGLETON ACCESSOR
# =============================================================================

_classifier_instance: Optional[LLMIntentClassifier] = None


def get_llm_intent_classifier() -> LLMIntentClassifier:
    """Get the singleton LLM intent classifier instance."""
    global _classifier_instance

    if _classifier_instance is None:
        # Try to create teacher helper for the classifier
        teacher = None
        if _teacher_available and TeacherHelper:
            try:
                teacher = TeacherHelper("routing")
            except Exception as e:
                print(f"[LLM_CLASSIFIER] Could not create teacher helper: {e}")

        _classifier_instance = LLMIntentClassifier(teacher_helper=teacher)

    return _classifier_instance


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "LLMIntentClassifier",
    "IntentClassification",
    "RoutingOutcome",
    "AVAILABLE_BRAINS",
    "get_llm_intent_classifier",
]
