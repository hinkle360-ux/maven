"""
Routing Feedback System
=======================

Learns from user corrections and routing outcomes.

When a user says "no, I want actual CODE" after Maven gives an explanation,
this module:
1. Detects the correction
2. Identifies what brain should have been used
3. Updates the intent classifier with the correct routing
4. Generates upgrade proposals for repeated failures

This is the key to making Maven's routing LEARN from mistakes.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, asdict
from datetime import datetime
from pathlib import Path
from brains.maven_paths import get_state_path
from typing import Any, Dict, List, Optional, Tuple

# Import intent classifier for learning
try:
    from brains.cognitive.integrator.llm_intent_classifier import (
        LLMIntentClassifier,
        IntentClassification,
        RoutingOutcome,
        get_llm_intent_classifier,
    )
    _classifier_available = True
except ImportError:
    _classifier_available = False
    LLMIntentClassifier = None  # type: ignore
    IntentClassification = None  # type: ignore
    RoutingOutcome = None  # type: ignore
    get_llm_intent_classifier = None  # type: ignore

# Import upgrade engine for generating proposals
try:
    from brains.governance.upgrade_engine.service.upgrade_engine import (
        get_upgrade_engine,
    )
    _upgrade_engine_available = True
except ImportError:
    _upgrade_engine_available = False
    get_upgrade_engine = None  # type: ignore

# Storage paths
MAVEN_DIR = get_state_path()
FEEDBACK_LOG_PATH = MAVEN_DIR / "routing" / "feedback_log.jsonl"


def _ensure_dir(path: Path) -> None:
    """Ensure parent directory exists."""
    path.parent.mkdir(parents=True, exist_ok=True)


# =============================================================================
# CORRECTION DETECTION PATTERNS
# =============================================================================

# Patterns that indicate user is correcting Maven's routing
CORRECTION_PATTERNS = [
    # Explicit correction
    (r"^no,?\s+(i\s+)?(want|need|meant|asked\s+for)\s+(?:actual\s+)?(code|script|program)", "coder"),
    (r"^no,?\s+(i\s+)?(want|need)\s+an?\s+explanation", "reasoning"),
    (r"^no,?\s+(i\s+)?meant\s+research", "research_manager"),
    (r"^no,?\s+i\s+want\s+you\s+to\s+(do|execute|run)", "action_engine"),

    # Implicit correction (rephrasing)
    (r"^(give|show)\s+me\s+(the\s+)?(actual\s+)?code", "coder"),
    (r"^(write|generate|create)\s+(the\s+)?code", "coder"),
    (r"^(just\s+)?(explain|tell\s+me)", "reasoning"),
    (r"^(search|look\s+up|research)\s+(this|it|that)", "research_manager"),
    (r"^(run|execute|do)\s+(this|it|that)", "action_engine"),

    # Frustration indicators
    (r"^i\s+(didn'?t|did\s+not)\s+(ask|want)\s+for\s+(that|an?\s+explanation)", "coder"),
    (r"^that'?s\s+not\s+what\s+i\s+(asked|meant|wanted)", None),  # Needs inference
    (r"^(wrong|incorrect),?\s+i\s+(want|need|meant)", None),  # Needs inference

    # Clarification requests
    (r"^let\s+me\s+(rephrase|clarify)", None),
    (r"^what\s+i\s+(actually\s+)?(meant|want)", None),
]


# Compiled patterns
_COMPILED_CORRECTION_PATTERNS = [
    (re.compile(pattern, re.IGNORECASE), brain)
    for pattern, brain in CORRECTION_PATTERNS
]


# =============================================================================
# FEEDBACK DATA STRUCTURES
# =============================================================================

@dataclass
class FeedbackEntry:
    """
    A single feedback entry from user interaction.
    """
    original_query: str
    maven_response_type: str  # "explanation", "code", "action", etc.
    user_correction: str
    inferred_desired_brain: Optional[str]
    routing_used: List[str]
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    session_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# =============================================================================
# ROUTING FEEDBACK CLASS
# =============================================================================

class RoutingFeedback:
    """
    Collect and learn from routing feedback.

    This class:
    1. Detects when users correct Maven's responses
    2. Infers what routing should have been used
    3. Feeds corrections to the intent classifier for learning
    4. Tracks patterns of routing failures
    """

    def __init__(self):
        """Initialize the feedback system."""
        self.classifier = get_llm_intent_classifier() if _classifier_available else None

        # Track current conversation context
        self._last_query: Optional[str] = None
        self._last_routing: Optional[IntentClassification] = None
        self._last_response_type: Optional[str] = None

        # Feedback stats
        self.stats = {
            "corrections_detected": 0,
            "successful_learnings": 0,
            "inference_failures": 0,
        }

    def set_current_context(self, query: str, routing: IntentClassification,
                           response_type: str) -> None:
        """
        Set the current conversation context.

        Call this after Maven produces a response, so the feedback system
        knows what was routed and how.

        Args:
            query: The original user query
            routing: The classification/routing that was used
            response_type: What type of response was given ("code", "explanation", etc.)
        """
        self._last_query = query
        self._last_routing = routing
        self._last_response_type = response_type

    def process_user_message(self, message: str) -> Optional[FeedbackEntry]:
        """
        Process a user message to detect corrections.

        Args:
            message: The user's message

        Returns:
            FeedbackEntry if correction detected, None otherwise
        """
        # Check if this is a correction
        correction_result = self._detect_correction(message)

        if not correction_result:
            return None

        is_correction, desired_brain = correction_result

        if not is_correction:
            return None

        self.stats["corrections_detected"] += 1

        # If we couldn't infer the desired brain from patterns, try inference
        if desired_brain is None:
            desired_brain = self._infer_desired_brain(message)

        if desired_brain is None:
            self.stats["inference_failures"] += 1
            print(f"[ROUTING_FEEDBACK] Correction detected but couldn't infer desired brain")
            return None

        # Create feedback entry
        feedback = FeedbackEntry(
            original_query=self._last_query or "",
            maven_response_type=self._last_response_type or "unknown",
            user_correction=message,
            inferred_desired_brain=desired_brain,
            routing_used=self._last_routing.recommended_brains if self._last_routing else [],
        )

        # Learn from correction
        self._apply_correction(feedback)

        # Log feedback
        self._log_feedback(feedback)

        return feedback

    def _detect_correction(self, message: str) -> Optional[Tuple[bool, Optional[str]]]:
        """
        Detect if message is a correction and extract desired brain.

        Returns:
            Tuple of (is_correction, desired_brain) or None if no correction
        """
        message_stripped = message.strip()

        # Check against correction patterns
        for pattern, brain in _COMPILED_CORRECTION_PATTERNS:
            if pattern.search(message_stripped):
                return (True, brain)

        # Check for implicit correction (user immediately rephrases)
        if self._is_immediate_rephrase(message_stripped):
            return (True, None)  # Needs inference

        return None

    def _is_immediate_rephrase(self, message: str) -> bool:
        """
        Check if message is an immediate rephrase (implicit correction).

        Indicators:
        - Very short follow-up that seems like a clarification
        - Message starts with "I meant" or similar
        """
        message_lower = message.lower()

        rephrase_indicators = [
            "i meant",
            "i want",
            "i need",
            "i'm asking for",
            "what i wanted",
            "actually,",
            "no,",
            "not that,",
        ]

        for indicator in rephrase_indicators:
            if message_lower.startswith(indicator):
                return True

        return False

    def _infer_desired_brain(self, correction: str) -> Optional[str]:
        """
        Infer which brain the user wanted from their correction message.

        Uses keyword analysis and context.
        """
        correction_lower = correction.lower()

        # Code indicators
        code_keywords = [
            "code", "script", "function", "program", "implement", "write",
            "python", "javascript", "example code", "snippet"
        ]
        if any(kw in correction_lower for kw in code_keywords):
            return "coder"

        # Explanation indicators
        explain_keywords = [
            "explain", "explanation", "understand", "how does", "why",
            "tell me about", "describe", "what is"
        ]
        if any(kw in correction_lower for kw in explain_keywords):
            return "reasoning"

        # Research indicators
        research_keywords = [
            "search", "look up", "research", "find out", "current", "latest",
            "news", "web"
        ]
        if any(kw in correction_lower for kw in research_keywords):
            return "research_manager"

        # Action indicators
        action_keywords = [
            "run", "execute", "do", "perform", "action", "create file",
            "delete", "move", "open"
        ]
        if any(kw in correction_lower for kw in action_keywords):
            return "action_engine"

        # Plan indicators
        plan_keywords = [
            "plan", "steps", "break down", "workflow", "organize"
        ]
        if any(kw in correction_lower for kw in plan_keywords):
            return "planner"

        # Self indicators
        self_keywords = [
            "yourself", "maven", "who are you", "your brains"
        ]
        if any(kw in correction_lower for kw in self_keywords):
            return "self_model"

        # Couldn't infer
        return None

    def _apply_correction(self, feedback: FeedbackEntry) -> None:
        """
        Apply correction to the intent classifier.

        This teaches the classifier to route similarly to the corrected brain.
        """
        if not self.classifier or not self._last_routing:
            return

        if not feedback.inferred_desired_brain:
            return

        # Create outcome for learning
        outcome = RoutingOutcome(
            verdict="correction",
            should_have_routed_to=feedback.inferred_desired_brain,
            user_feedback=feedback.user_correction,
            brains_used=feedback.routing_used,
        )

        # Feed to classifier for learning
        try:
            self.classifier.learn_from_outcome(
                query=feedback.original_query,
                classification=self._last_routing,
                outcome=outcome,
            )
            self.stats["successful_learnings"] += 1

            print(f"[ROUTING_FEEDBACK] Learned: '{feedback.original_query[:30]}...' "
                  f"should route to {feedback.inferred_desired_brain}")

        except Exception as e:
            print(f"[ROUTING_FEEDBACK] Failed to apply correction: {e}")

    def _log_feedback(self, feedback: FeedbackEntry) -> None:
        """Log feedback entry for analysis."""
        try:
            _ensure_dir(FEEDBACK_LOG_PATH)
            with FEEDBACK_LOG_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps(feedback.to_dict()) + "\n")
        except Exception as e:
            print(f"[ROUTING_FEEDBACK] Failed to log feedback: {e}")

    def process_routing_outcome(self, query: str, brains_used: List[str],
                               user_verdict: str) -> None:
        """
        Learn from explicit routing outcome.

        Called when we have a clear signal about whether routing was successful.

        Args:
            query: The original query
            brains_used: Which brains were used
            user_verdict: "ok", "incomplete", or "wrong_brain"
        """
        if not self.classifier or not self._last_routing:
            return

        outcome = RoutingOutcome(
            verdict=user_verdict,
            brains_used=brains_used,
        )

        try:
            self.classifier.learn_from_outcome(
                query=query,
                classification=self._last_routing,
                outcome=outcome,
            )
        except Exception as e:
            print(f"[ROUTING_FEEDBACK] Failed to process outcome: {e}")

    def mark_routing_successful(self) -> None:
        """
        Mark the last routing as successful.

        Call this when user seems satisfied with the response.
        """
        if not self.classifier or not self._last_routing or not self._last_query:
            return

        outcome = RoutingOutcome(verdict="ok")

        try:
            self.classifier.learn_from_outcome(
                query=self._last_query,
                classification=self._last_routing,
                outcome=outcome,
            )
        except Exception as e:
            print(f"[ROUTING_FEEDBACK] Failed to mark success: {e}")

    def get_stats(self) -> Dict[str, Any]:
        """Get feedback statistics."""
        return dict(self.stats)


# =============================================================================
# AUTOMATIC CORRECTION DETECTION
# =============================================================================

def detect_user_correction(current_message: str, last_response_type: str) -> Optional[str]:
    """
    Quick check if current message indicates user is correcting Maven.

    Args:
        current_message: The user's current message
        last_response_type: What type of response Maven just gave

    Returns:
        The inferred desired brain if correction detected, None otherwise
    """
    message_lower = current_message.lower().strip()

    # Check for explicit correction markers
    explicit_corrections = [
        "no, i want",
        "no, i need",
        "no, i meant",
        "no, give me",
        "no, show me",
        "that's not what i",
        "i didn't ask for",
        "wrong,",
        "not that,",
    ]

    is_explicit_correction = any(message_lower.startswith(marker) for marker in explicit_corrections)

    if not is_explicit_correction:
        return None

    # Infer what they wanted
    feedback = RoutingFeedback()
    return feedback._infer_desired_brain(current_message)


def is_positive_feedback(message: str) -> bool:
    """
    Check if message indicates positive feedback about last response.

    Args:
        message: The user's message

    Returns:
        True if message indicates satisfaction
    """
    message_lower = message.lower().strip()

    positive_indicators = [
        "thanks",
        "thank you",
        "perfect",
        "great",
        "good",
        "nice",
        "exactly",
        "that's what i",
        "yes, that's",
        "awesome",
        "helpful",
    ]

    return any(indicator in message_lower for indicator in positive_indicators)


# =============================================================================
# SINGLETON ACCESSOR
# =============================================================================

_feedback_instance: Optional[RoutingFeedback] = None


def get_routing_feedback() -> RoutingFeedback:
    """Get the singleton routing feedback instance."""
    global _feedback_instance

    if _feedback_instance is None:
        _feedback_instance = RoutingFeedback()

    return _feedback_instance


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "RoutingFeedback",
    "FeedbackEntry",
    "get_routing_feedback",
    "detect_user_correction",
    "is_positive_feedback",
]
