"""
Agency Routing Patterns
=======================

Routing patterns that map user queries to agency tool capabilities.
This prevents the echo bug by routing tool-requiring queries directly
to the appropriate agency modules instead of falling back to Teacher.

Pattern Format:
{
    "signatures": ["keyword1", "keyword2", ...],
    "tool": "module_path.function_name",
    "confidence": 0.9,
    "bypass_teacher": True
}
"""

from __future__ import annotations
from typing import Dict, List, Any, Optional


# Agency tool routing patterns
AGENCY_PATTERNS = [
    # Self-Introspection Patterns
    {
        "signatures": [
            "scan codebase", "scan code", "scan yourself", "scan your code",
            "introspect", "self introspect", "analyze codebase",
            "analyze your code", "analyze yourself", "scan directory",
            "scan files", "scan python files", "scan brains",
            "scan architecture", "analyze architecture"
        ],
        "tool": "brains.tools.self_introspection.get_self_introspection",
        "method": "generate_self_knowledge_report",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Full codebase introspection and analysis"
    },
    {
        "signatures": [
            "list brains", "show brains", "what brains", "brain list",
            "brain analysis", "analyze brains", "brain compliance",
            "check brains", "brain status"
        ],
        "tool": "brains.tools.self_introspection.get_self_introspection",
        "method": "analyze_all_brains",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Analyze brain compliance and structure"
    },
    {
        "signatures": [
            "circular dependencies", "dependency cycles", "import cycles",
            "check dependencies", "analyze dependencies", "dependency graph"
        ],
        "tool": "brains.tools.self_introspection.get_self_introspection",
        "method": "analyze_dependencies",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Analyze code dependencies"
    },

    # Filesystem Agency Patterns
    {
        "signatures": [
            "scan directory tree", "list directory", "show files",
            "list files", "directory structure", "file tree",
            "show directory", "explore files"
        ],
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "scan_directory_tree",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Scan filesystem directory structure"
    },
    {
        "signatures": [
            "list python files", "show python files", "find python files",
            "python file list", "py files"
        ],
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "list_python_files",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "List all Python files"
    },
    {
        "signatures": [
            "read file", "show file", "display file", "file contents",
            "view file", "cat file"
        ],
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "read_file",
        "confidence": 0.85,
        "bypass_teacher": True,
        "description": "Read file contents",
        "requires_args": True
    },
    {
        "signatures": [
            "analyze python file", "parse python", "analyze code",
            "code structure", "find class", "find function",
            "class definition", "function definition"
        ],
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "analyze_python_file",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Analyze Python file structure"
    },

    # Git Operations Patterns
    {
        "signatures": [
            "git status", "repo status", "repository status",
            "git state", "check git", "git info"
        ],
        "tool": "brains.tools.git_tool.git_get_repo_info",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Get complete repository information"
    },
    {
        "signatures": [
            "git log", "commit log", "commit history",
            "show commits", "recent commits"
        ],
        "tool": "brains.tools.git_tool.git_log",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Show git commit log"
    },
    {
        "signatures": [
            "git branches", "list branches", "show branches",
            "branch list", "all branches"
        ],
        "tool": "brains.tools.git_tool.git_list_branches",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "List git branches"
    },
    {
        "signatures": [
            "current branch", "which branch", "branch name",
            "active branch"
        ],
        "tool": "brains.tools.git_tool.git_current_branch",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Get current branch name"
    },

    # Hot-Reload Patterns
    {
        "signatures": [
            "reload module", "hot reload", "reload brain",
            "refresh module", "reload code"
        ],
        "tool": "brains.tools.hot_reload.get_hot_reload_manager",
        "method": "reload_module",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Reload Python module at runtime",
        "requires_args": True
    },
    {
        "signatures": [
            "loaded modules", "list modules", "show modules",
            "module list", "maven modules"
        ],
        "tool": "brains.tools.hot_reload.get_hot_reload_manager",
        "method": "get_loaded_maven_modules",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "List loaded Maven modules"
    },

    # Coder Patterns - Code Generation
    {
        "signatures": [
            "coder:", "use coder:", "coder write", "coder generate",
            "write a function", "write a python function",
            "generate code", "generate a function", "create function",
            "write code", "code a function"
        ],
        "tool": "brains.cognitive.coder.service.coder_brain",
        "method": "GENERATE",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Generate code using the coder brain",
        "return_code_directly": True
    },
    {
        "signatures": [
            "return only the code", "return only code", "just the code",
            "show me the code", "give me the code", "code only",
            "return only the full updated function", "return only the function"
        ],
        "tool": "brains.cognitive.coder.service.coder_brain",
        "method": "EXTEND",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Return extended code output directly",
        "return_code_directly": True,
        "is_code_follow_up": True
    },
    # Coder Patterns - Function Extension
    {
        "signatures": [
            "extend that function", "extend the function",
            "modify that function", "update that function",
            "change that function", "add to that function"
        ],
        "tool": "brains.cognitive.coder.service.coder_brain",
        "method": "EXTEND",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Extend the last generated function with new specs",
        "return_code_directly": True,
        "is_extension": True
    },
    # Coder Patterns - Bullet Point Specs (accumulate for extension)
    {
        "signatures": [
            "- if both", "- if one", "if both are lists",
            "if one is a scalar", "broadcast it"
        ],
        "tool": "brains.cognitive.coder.service.coder_brain",
        "method": "ADD_SPEC",
        "confidence": 0.85,
        "bypass_teacher": True,
        "description": "Add a specification for function extension",
        "is_spec_accumulation": True
    },

    # Normalization Introspection Patterns
    {
        "signatures": [
            "last normalized", "normalized message", "last normalized user message",
            "show me your last normalized", "normalized input",
            "what did you normalize", "your last normalized"
        ],
        "tool": "brains.cognitive.sensorium.service.sensorium_brain",
        "method": "GET_LAST_NORMALIZED",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Get the last normalized user message",
        "direct_memory_query": True
    },

    # Inventory Patterns
    {
        "signatures": [
            "inventory:", "inventory: list", "list all cognitive brains",
            "list cognitive brains", "brain inventory", "inventory brains",
            "count brains", "how many brains", "enumerate brains",
            "inventory: list all cognitive brains",
            "report the total count"
        ],
        "tool": "brains.cognitive.inventory.service.inventory_brain",
        "method": "LIST",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "List all cognitive brains with count"
    },

    # Browser Patterns - Web Browsing Automation
    # NOTE: tool name should match what's in system_capabilities (browser_runtime)
    {
        "signatures": [
            "browser:", "browser: open", "open https://", "open http://",
            "fetch url", "browse to", "open website", "visit website",
            "browser open", "browser fetch", "open url", "navigate to",
            "go to website", "load page", "load website", "open google",
            "go to google", "open example", "go to example"
        ],
        "tool": "browser_runtime",
        "method": "OPEN_URL",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Open a URL in the browser"
    },
    # Default search (DuckDuckGo - no CAPTCHA)
    {
        "signatures": [
            "search for", "search", "look up", "find", "web search",
            "search the web", "find online", "look up online",
            "search online", "look for", "query"
        ],
        "tool": "browser_runtime",
        "method": "SEARCH",
        "engine": "ddg",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Perform a web search (default: DuckDuckGo)"
    },
    # Google-specific search
    {
        "signatures": [
            "google", "google search", "search google", "google for",
            "search on google", "use google", "google it",
            "open google search"
        ],
        "tool": "browser_runtime",
        "method": "SEARCH",
        "engine": "google",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Search using Google (may require CAPTCHA)"
    },
    # Bing-specific search
    {
        "signatures": [
            "bing", "bing search", "search bing", "bing for",
            "search on bing", "use bing", "open bing search"
        ],
        "tool": "browser_runtime",
        "method": "SEARCH",
        "engine": "bing",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Search using Bing"
    },
    # DuckDuckGo-specific search
    {
        "signatures": [
            "ddg", "duckduckgo", "duck duck go", "ddg search",
            "search ddg", "search duckduckgo", "use duckduckgo",
            "open duckduckgo search"
        ],
        "tool": "browser_runtime",
        "method": "SEARCH",
        "engine": "ddg",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Search using DuckDuckGo (recommended, no CAPTCHA)"
    },
    {
        "signatures": [
            "browse for", "browse the web for", "browser: search",
            "browser: browse", "use browser to", "use the browser"
        ],
        "tool": "browser_runtime",
        "method": "BROWSE",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Execute a browsing task"
    },

    # =========================================================================
    # WEB SEARCH TOOL - Direct web search with result synthesis
    # =========================================================================
    # These patterns go directly to web_search_tool for synthesized answers
    {
        "signatures": [
            "what new games", "what games are", "new games coming out",
            "latest games", "upcoming games", "recent games",
            "games releasing", "game releases"
        ],
        "tool": "brains.agent.tools.web_search_tool.web_search_tool",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Search for game release information",
        "is_web_search": True
    },
    {
        "signatures": [
            "search the web", "web search for", "search online for",
            "look up online", "find online", "search internet for",
            "look online for", "online search"
        ],
        "tool": "brains.agent.tools.web_search_tool.web_search_tool",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Perform web search with answer synthesis",
        "is_web_search": True
    },
    {
        "signatures": [
            "news about", "latest news", "recent news",
            "what's happening with", "updates on", "current news"
        ],
        "tool": "brains.agent.tools.web_search_tool.web_search_tool",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Search for news and current events",
        "is_web_search": True
    },
    {
        "signatures": [
            "what is the latest", "what are the newest",
            "what's new in", "what's coming in", "upcoming"
        ],
        "tool": "brains.agent.tools.web_search_tool.web_search_tool",
        "confidence": 0.85,
        "bypass_teacher": True,
        "description": "Search for latest/upcoming information",
        "is_web_search": True
    },

    # Diagnostic Patterns
    {
        "signatures": [
            "diagnose", "diagnostic", "system check", "health check",
            "system status", "check system", "troubleshoot",
            "find issues", "detect problems"
        ],
        "tool": "brains.tools.self_introspection.get_self_introspection",
        "method": "generate_self_knowledge_report",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Run system diagnostics"
    },
    {
        "signatures": [
            "missing functions", "missing methods", "detect missing",
            "find missing", "function detection"
        ],
        "tool": "brains.tools.self_introspection.get_self_introspection",
        "method": "detect_missing_functions",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Detect missing functions in brains"
    },

    # =========================================================================
    # FULL_AGENCY MODE - Shell and Command Execution Patterns
    # =========================================================================
    {
        "signatures": [
            "run command", "execute command", "run shell", "shell command",
            "terminal command", "run in terminal", "execute in shell",
            "run this command", "execute this", "do command"
        ],
        "tool": "brains.agent.tools.intent_resolver_tools.maybe_execute_tool",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Execute a shell command",
        "requires_args": True
    },
    {
        "signatures": [
            "install package", "pip install", "npm install", "apt install",
            "install with pip", "install with npm", "add package"
        ],
        "tool": "brains.agent.tools.intent_resolver_tools.maybe_execute_tool",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Install a package",
        "requires_args": True
    },

    # Python Execution Patterns
    {
        "signatures": [
            "run python", "execute python", "run this python",
            "python code", "run python code", "execute python code",
            "run script", "execute script"
        ],
        "tool": "brains.agent.tools.intent_resolver_tools.maybe_execute_tool",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Execute Python code",
        "requires_args": True
    },

    # Web Operations Patterns
    {
        "signatures": [
            "fetch url", "get url", "download from", "open url",
            "browse to url", "visit url", "navigate to url",
            "http get", "http fetch"
        ],
        "tool": "browser_runtime",
        "method": "FETCH_URL",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Fetch content from a URL",
        "requires_args": True
    },
    {
        "signatures": [
            "search online", "web search", "internet search",
            "look up online", "find online", "search internet"
        ],
        "tool": "browser_runtime",
        "method": "SEARCH",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Perform a web search"
    },

    # Advanced Git Operations
    {
        "signatures": [
            "git commit", "commit changes", "make commit",
            "commit with message", "save changes to git"
        ],
        "tool": "brains.tools.git_tool.git_commit",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Commit changes to git",
        "requires_args": True
    },
    {
        "signatures": [
            "git push", "push changes", "push to remote",
            "push to origin", "upload changes"
        ],
        "tool": "brains.tools.git_tool.git_push",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Push changes to remote"
    },
    {
        "signatures": [
            "git pull", "pull changes", "pull from remote",
            "pull from origin", "download changes", "sync repo"
        ],
        "tool": "brains.tools.git_tool.git_pull",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Pull changes from remote"
    },
    {
        "signatures": [
            "git clone", "clone repo", "clone repository",
            "download repo", "get repo"
        ],
        "tool": "brains.tools.git_tool.git_clone",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Clone a git repository",
        "requires_args": True
    },

    # File Operation Patterns (Natural Language)
    {
        "signatures": [
            "delete file", "remove file", "rm file",
            "delete the file", "remove the file"
        ],
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "delete_file",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Delete a file",
        "requires_args": True
    },
    {
        "signatures": [
            "copy file", "cp file", "duplicate file",
            "copy the file", "make a copy"
        ],
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "copy_file",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Copy a file",
        "requires_args": True
    },
    {
        "signatures": [
            "move file", "mv file", "rename file",
            "move the file", "rename the file"
        ],
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "move_file",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Move or rename a file",
        "requires_args": True
    },

    # =========================================================================
    # TIME TOOL - Real-time clock access
    # =========================================================================
    {
        "signatures": [
            "what time is it", "what's the time", "whats the time",
            "current time", "tell me the time", "time now",
            "what time", "the time please", "show time"
        ],
        "tool": "time_now",
        "method": "GET_TIME",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Get current time from system clock"
    },
    {
        "signatures": [
            "what date is it", "what's the date", "whats the date",
            "current date", "tell me the date", "today's date",
            "what day is it", "what day", "the date please"
        ],
        "tool": "time_now",
        "method": "GET_DATE",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Get current date from system clock"
    },
    {
        "signatures": [
            "what's today", "whats today", "today",
            "what month is it", "what year is it", "what week"
        ],
        "tool": "time_now",
        "method": "GET_CALENDAR",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Get calendar information from system clock"
    },

    # =========================================================================
    # SHELL TOOL - Execute shell commands
    # =========================================================================
    {
        "signatures": [
            "run command", "execute command", "shell command",
            "run shell", "execute shell", "terminal command",
            "run in terminal", "execute in terminal"
        ],
        "tool": "shell_tool",
        "method": "RUN",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Execute a shell command"
    },
    {
        "signatures": [
            "run python", "execute python", "python script",
            "run script", "execute script"
        ],
        "tool": "shell_tool",
        "method": "RUN_PYTHON",
        "confidence": 0.9,
        "bypass_teacher": True,
        "description": "Execute Python code"
    },

    # =========================================================================
    # GROK CONVERSATION SESSION - Autonomous conversations with Grok
    # =========================================================================
    {
        "signatures": [
            "have a convo with grok about",
            "have a conversation with grok about",
            "have convo with grok about",
            "convo with grok about",
            "conversation with grok about",
            "maven have a convo with grok",
            "maven convo with grok",
        ],
        "tool": "brains.tools.grok_conversation_session.get_grok_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.98,
        "bypass_teacher": True,
        "description": "Start autonomous conversation session with Grok",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "talk to grok about",
            "chat with grok about",
            "discuss with grok about",
            "grok discussion about",
            "grok chat about",
            # "and" connector patterns (e.g., "talk to grok and explain yourself")
            "talk to grok and",
            "chat with grok and",
            "discuss with grok and",
        ],
        "tool": "brains.tools.grok_conversation_session.get_grok_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Start conversation with Grok",
        "is_autonomous_conversation": True,
    },
    # Simple "talk to grok" without "about" - opens a conversation
    {
        "signatures": [
            "talk to grok",
            "chat with grok",
            "message grok",
            "open grok",
            "start grok",
            "grok",
        ],
        "tool": "brains.tools.grok_conversation_session.get_grok_conversation_controller",
        "method": "start_session",
        "confidence": 0.90,
        "bypass_teacher": True,
        "description": "Start a Grok conversation session",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "grok session about",
            "grok session on",
            "grok conversation about",
            "autonomous grok session",
            "have grok discuss",
            "have grok explore",
        ],
        "tool": "brains.tools.grok_conversation_session.get_grok_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Start Grok conversation session",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "start grok conversation",
            "start grok session",
            "begin grok conversation",
            "begin grok session",
        ],
        "tool": "brains.tools.grok_conversation_session.get_grok_conversation_controller",
        "method": "start_session",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Start a Grok conversation session",
        "is_autonomous_conversation": True,
        "requires_args": True,
    },

    # =========================================================================
    # ChatGPT Conversation Session Patterns
    # =========================================================================
    {
        "signatures": [
            "have a convo with chatgpt about",
            "have a conversation with chatgpt about",
            "convo with chatgpt about",
            "conversation with chatgpt about",
            "maven have a convo with chatgpt",
            "maven convo with chatgpt",
        ],
        "tool": "brains.tools.chatgpt_conversation_session.get_chatgpt_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.98,
        "bypass_teacher": True,
        "description": "Start autonomous conversation session with ChatGPT",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "talk to chatgpt about",
            "chat with chatgpt about",
            "discuss with chatgpt about",
            "chatgpt discussion about",
            "chatgpt chat about",
            # "and" connector patterns (e.g., "talk to chatgpt and explain yourself")
            "talk to chatgpt and",
            "chat with chatgpt and",
            "discuss with chatgpt and",
        ],
        "tool": "brains.tools.chatgpt_conversation_session.get_chatgpt_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Start conversation with ChatGPT",
        "is_autonomous_conversation": True,
    },
    # Simple "talk to chatgpt" without "about" - opens a conversation
    {
        "signatures": [
            "talk to chatgpt",
            "chat with chatgpt",
            "message chatgpt",
            "open chatgpt",
            "start chatgpt",
            "chatgpt",
        ],
        "tool": "brains.tools.chatgpt_conversation_session.get_chatgpt_conversation_controller",
        "method": "start_session",
        "confidence": 0.90,
        "bypass_teacher": True,
        "description": "Start a ChatGPT conversation session",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "chatgpt session about",
            "chatgpt session on",
            "chatgpt conversation about",
            "autonomous chatgpt session",
            "have chatgpt discuss",
            "have chatgpt explore",
        ],
        "tool": "brains.tools.chatgpt_conversation_session.get_chatgpt_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Start ChatGPT conversation session",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "talk to gpt about",
            "chat with gpt about",
            "convo with gpt about",
            "gpt session about",
            # "and" connector patterns
            "talk to gpt and",
            "chat with gpt and",
            "convo with gpt and",
        ],
        "tool": "brains.tools.chatgpt_conversation_session.get_chatgpt_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.93,
        "bypass_teacher": True,
        "description": "Start GPT conversation session (shorthand)",
        "is_autonomous_conversation": True,
    },

    # =========================================================================
    # Claude Conversation Session Patterns
    # =========================================================================
    {
        "signatures": [
            "have a convo with claude about",
            "have a conversation with claude about",
            "convo with claude about",
            "conversation with claude about",
            "maven have a convo with claude",
            "maven convo with claude",
        ],
        "tool": "brains.tools.claude_conversation_session.get_claude_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.98,
        "bypass_teacher": True,
        "description": "Start autonomous conversation session with Claude",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "talk to claude about",
            "chat with claude about",
            "discuss with claude about",
            "claude discussion about",
            "claude chat about",
            # "and" connector patterns (e.g., "talk to claude and explain yourself")
            "talk to claude and",
            "chat with claude and",
            "discuss with claude and",
        ],
        "tool": "brains.tools.claude_conversation_session.get_claude_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Start conversation with Claude",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "claude session about",
            "claude session on",
            "claude conversation about",
            "autonomous claude session",
            "have claude discuss",
            "have claude explore",
        ],
        "tool": "brains.tools.claude_conversation_session.get_claude_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": "Start Claude conversation session",
        "is_autonomous_conversation": True,
    },
    {
        "signatures": [
            "talk to anthropic about",
            "chat with anthropic about",
            "anthropic session about",
            # "and" connector patterns
            "talk to anthropic and",
            "chat with anthropic and",
        ],
        "tool": "brains.tools.claude_conversation_session.get_claude_conversation_controller",
        "method": "parse_and_run",
        "confidence": 0.93,
        "bypass_teacher": True,
        "description": "Start Anthropic/Claude conversation session",
        "is_autonomous_conversation": True,
    },
]


def match_agency_pattern(query: str, threshold: float = 0.7) -> Optional[Dict[str, Any]]:
    """
    Match a user query against agency routing patterns.

    IMPORTANT: This function should only match queries that are clearly requesting
    tool EXECUTION, not queries asking for information or examples ABOUT tools/code.

    Exclusion patterns:
    - "show me example of X" -> wants EXAMPLES, not execution
    - "give me examples of X" -> wants EXAMPLES, not execution
    - "demonstrate how to X" -> wants DEMONSTRATION, not execution
    - "explain X code" -> wants EXPLANATION, not execution
    - "help me with X" -> wants HELP, not execution

    Args:
        query: User query text (lowercased)
        threshold: Minimum confidence threshold

    Returns:
        Matched pattern dict or None if no match
    """
    import re
    query_lower = query.lower().strip()

    # =========================================================================
    # EXCLUSION PATTERNS: These queries want INFORMATION, not EXECUTION
    # =========================================================================
    # If a query matches these, it should NOT be routed to tool execution
    # even if it contains tool-related keywords like "python code"
    exclusion_patterns = [
        # Example/demonstration requests -> want to see code, not run it
        r"^show\s+(?:me\s+)?(?:an?\s+)?example",
        r"^give\s+(?:me\s+)?(?:some\s+)?example",
        r"^(?:can\s+you\s+)?demonstrate",
        r"example\s+(?:of|for)\s+",
        r"examples?\s+(?:of|for)\s+",
        # Help/explanation requests -> want explanation, not execution
        r"^help\s+(?:me\s+)?(?:with|understand)",
        r"^explain\s+",
        r"^tell\s+me\s+(?:about|how)",
        r"^what\s+(?:is|are)\s+",
        r"^how\s+(?:does|do|to)\s+",
        # COHERENCY FIX: Entity/person queries -> want memory lookup, not tools
        r"^who\s+(?:is|was|are|were)\s+",  # "Who is Max?"
        r"^who's\s+",                       # "Who's Max?"
        r"^what\s+do\s+you\s+know\s+about\s+",  # "What do you know about Max?"
        r"^do\s+you\s+(?:know|remember)\s+",    # "Do you know Max?"
        # Learning requests
        r"^(?:i\s+)?(?:want\s+to\s+)?learn\s+",
        r"^teach\s+me\s+",
        r"^show\s+me\s+how\s+to\s+",
        # Generic information requests
        r"^(?:can\s+you\s+)?write\s+(?:a|an|some)\s+",
        r"^(?:can\s+you\s+)?generate\s+(?:a|an|some)\s+",
        r"^(?:can\s+you\s+)?create\s+(?:a|an|some)\s+",
    ]

    # DEBUG: Print what we're checking
    print(f"[AGENCY_MATCH] Checking query: '{query_lower}'")

    for exclusion in exclusion_patterns:
        if re.search(exclusion, query_lower):
            print(f"[AGENCY_MATCH] ✓ EXCLUDED by pattern: {exclusion}")
            return None  # Don't match tool execution for info requests

    print(f"[AGENCY_MATCH] No exclusion matched, continuing to pattern matching...")

    # =========================================================================
    # SPECIAL CASE: File path detection for filesystem operations
    # =========================================================================
    # If query contains a file path + filesystem verb, match directly
    file_path_match = _detect_filesystem_command(query_lower)
    if file_path_match:
        return file_path_match

    # =========================================================================
    # PHRASE-BASED MATCHING: Signatures should match as phrases, not just words
    # =========================================================================
    # Remove punctuation and split into words
    query_words = set(re.findall(r'\b\w+\b', query_lower))

    best_match = None
    best_score = 0.0

    for pattern in AGENCY_PATTERNS:
        # Calculate match score
        matches = 0
        has_phrase_match = False

        for signature in pattern["signatures"]:
            # First: Check for exact phrase match (stronger)
            if signature.lower() in query_lower:
                has_phrase_match = True
                matches += 2  # Bonus for phrase match

            # Second: Check word-level match (weaker)
            else:
                sig_words = set(re.findall(r'\b\w+\b', signature.lower()))
                # Require at least 70% of signature words to be present
                # AND the signature must have at least 2 words
                if len(sig_words) >= 2:
                    overlap = len(sig_words & query_words)
                    if overlap >= len(sig_words) * 0.7:
                        # Additional check: signature words should appear close together
                        # For short signatures, require exact phrase or skip
                        if len(sig_words) <= 2:
                            # For 2-word signatures, require phrase match
                            continue
                        matches += 1

        if matches > 0:
            # Score based on pattern confidence
            # Phrase matches get higher scores
            if has_phrase_match:
                match_bonus = min(matches * 0.05, 0.2)
                score = pattern["confidence"] + match_bonus
            else:
                # Word-only matches get lower score
                score = pattern["confidence"] * 0.7

            if score > best_score and score >= threshold:
                best_score = score
                best_match = pattern.copy()
                best_match["match_score"] = score

    # Extract args from query for special tools
    if best_match:
        tool = best_match.get("tool", "")
        method = best_match.get("method", "")

        if tool == "browser_runtime":
            best_match["args"] = _extract_browser_args(query_lower, method)
        elif tool == "shell_tool":
            best_match["args"] = _extract_shell_args(query_lower)
        elif tool == "time_now":
            # Time tool doesn't need args - it just gets current time
            best_match["args"] = {}
        elif "filesystem_agency" in tool:
            # Filesystem tools need path extraction
            best_match["args"] = _extract_filesystem_args(query_lower, method)
        elif best_match.get("is_autonomous_conversation"):
            # Conversation tools (ChatGPT, Grok, Claude) need the original query text
            # so they can parse the topic and other parameters
            best_match["args"] = {"text": query_lower}

    return best_match


def _extract_shell_args(query: str) -> Dict[str, Any]:
    """
    Extract shell command from query text.

    Patterns like:
    - "run command ls -la" -> {"command": "ls -la"}
    - "execute git status" -> {"command": "git status"}

    Args:
        query: Lowercased user query

    Returns:
        Dict with extracted command
    """
    import re
    args = {}

    # Patterns that indicate a command follows
    command_patterns = [
        r'run\s+command\s+(.+)',
        r'execute\s+command\s+(.+)',
        r'shell\s+command\s+(.+)',
        r'run\s+shell\s+(.+)',
        r'execute\s+shell\s+(.+)',
        r'terminal\s+command\s+(.+)',
        r'run\s+in\s+terminal\s+(.+)',
        r'execute\s+in\s+terminal\s+(.+)',
        r'run\s+`([^`]+)`',  # backtick syntax
        r'execute\s+`([^`]+)`',
    ]

    for pattern in command_patterns:
        match = re.search(pattern, query, re.IGNORECASE)
        if match:
            args["command"] = match.group(1).strip()
            return args

    # Fallback: try to extract anything after common command verbs
    simple_patterns = [
        r'^run\s+(.+)',
        r'^execute\s+(.+)',
    ]
    for pattern in simple_patterns:
        match = re.search(pattern, query, re.IGNORECASE)
        if match:
            cmd = match.group(1).strip()
            # Don't treat "run python" as a command
            if cmd not in ("python", "script", "command", "shell"):
                args["command"] = cmd
                return args

    return args


def _extract_browser_args(query: str, method: str) -> Dict[str, Any]:
    """
    Extract browser operation arguments from query text.

    For OPEN_URL: extracts URL from patterns like "open google.com", "browse to example.com"
    For SEARCH: extracts search query from patterns like "search for python tutorials"

    Args:
        query: Lowercased user query
        method: Browser method (OPEN_URL, SEARCH, BROWSE, etc.)

    Returns:
        Dict with extracted arguments (url, query, etc.)
    """
    import re
    args = {}

    if method in ("OPEN_URL", "BROWSE", "FETCH_URL"):
        # Pattern 1: Full URLs (https://..., http://...)
        url_match = re.search(r'(https?://[^\s]+)', query)
        if url_match:
            args["url"] = url_match.group(1)
            return args

        # Pattern 2: Domain names like "google.com", "example.org"
        domain_match = re.search(r'\b([a-z0-9][-a-z0-9]*\.(?:com|org|net|io|dev|app|ai|edu|gov|co|uk|de|fr|jp|cn|xyz|info|biz|tv|me|us)[^\s]*)', query)
        if domain_match:
            domain = domain_match.group(1)
            # Add https:// prefix if not present
            if not domain.startswith("http"):
                domain = "https://" + domain
            args["url"] = domain
            return args

        # Pattern 3: Known sites without TLD - "open google", "go to youtube"
        known_sites = {
            "google": "https://www.google.com",
            "youtube": "https://www.youtube.com",
            "github": "https://github.com",
            "chatgpt": "https://chat.openai.com",
            "openai": "https://openai.com",
            "twitter": "https://twitter.com",
            "x": "https://x.com",
            "reddit": "https://www.reddit.com",
            "wikipedia": "https://wikipedia.org",
            "amazon": "https://www.amazon.com",
            "facebook": "https://www.facebook.com",
            "linkedin": "https://www.linkedin.com",
            "stackoverflow": "https://stackoverflow.com",
            "bing": "https://www.bing.com",
            "duckduckgo": "https://duckduckgo.com",
            "ddg": "https://duckduckgo.com",
        }
        for site_name, site_url in known_sites.items():
            if site_name in query:
                args["url"] = site_url
                return args

    elif method == "SEARCH":
        # Extract search query - everything after search keywords
        search_patterns = [
            r'search\s+(?:for\s+)?(.+)',
            r'look\s+up\s+(.+)',
            r'find\s+(.+)',
            r'google\s+(?:for\s+)?(.+)',
            r'bing\s+(?:for\s+)?(.+)',
            r'duckduckgo\s+(?:for\s+)?(.+)',
            r'ddg\s+(?:for\s+)?(.+)',
        ]
        for pattern in search_patterns:
            match = re.search(pattern, query)
            if match:
                args["query"] = match.group(1).strip()
                return args
        # Fallback: use entire query as search
        args["query"] = query

    return args


def _extract_filesystem_args(query: str, method: str) -> Dict[str, Any]:
    """
    Extract filesystem operation arguments from query text.

    For delete_file: extracts path from "delete C:\\path\\file.txt"
    For copy_file: extracts source and destination
    For move_file: extracts source and destination
    For read_file: extracts path

    Args:
        query: User query (may be lowercased)
        method: Filesystem method (delete_file, copy_file, move_file, etc.)

    Returns:
        Dict with extracted arguments (path, source, destination, etc.)
    """
    import re
    args = {}

    # Pattern for file paths - handles Windows (C:\...) and Unix (/path/...)
    # Also handles quoted paths and paths with spaces
    path_patterns = [
        r'"([^"]+)"',  # Quoted path: "C:\my file.txt"
        r"'([^']+)'",  # Single quoted: 'C:\my file.txt'
        r'([A-Za-z]:[\\\/][^\s,]+)',  # Windows path: C:\path\file.txt
        r'(\/[^\s,]+)',  # Unix absolute path: /path/file.txt
        r'(\.[\\\/][^\s,]+)',  # Relative path: ./path/file.txt
        r'(~[\\\/][^\s,]+)',  # Home path: ~/path/file.txt
    ]

    def extract_paths(text: str) -> list:
        """Extract all file paths from text."""
        paths = []
        for pattern in path_patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            paths.extend(matches)
        return paths

    # Get paths from the query
    paths = extract_paths(query)

    if method == "delete_file":
        if paths:
            args["path"] = paths[0]
        else:
            # Try to get filename after "delete" keyword
            match = re.search(r'(?:delete|remove|rm)\s+(?:file\s+)?(\S+)', query, re.IGNORECASE)
            if match:
                args["path"] = match.group(1)

    elif method == "copy_file":
        if len(paths) >= 2:
            args["source"] = paths[0]
            args["destination"] = paths[1]
        elif len(paths) == 1:
            args["source"] = paths[0]
            # Try to find destination after "to" keyword
            match = re.search(r'\bto\s+(\S+)', query, re.IGNORECASE)
            if match:
                args["destination"] = match.group(1)

    elif method == "move_file":
        if len(paths) >= 2:
            args["source"] = paths[0]
            args["destination"] = paths[1]
        elif len(paths) == 1:
            args["source"] = paths[0]
            # Try to find destination after "to" keyword
            match = re.search(r'\bto\s+(\S+)', query, re.IGNORECASE)
            if match:
                args["destination"] = match.group(1)

    elif method == "read_file":
        if paths:
            args["path"] = paths[0]
        else:
            # Try to get filename after "read" keyword
            match = re.search(r'(?:read|view|cat|show)\s+(?:file\s+)?(\S+)', query, re.IGNORECASE)
            if match:
                args["path"] = match.group(1)

    elif method in ("scan_directory_tree", "list_directory"):
        if paths:
            args["path"] = paths[0]
        # Otherwise defaults to current directory

    elif method == "list_python_files":
        if paths:
            args["path"] = paths[0]
        # Otherwise defaults to current directory

    return args


def _detect_filesystem_command(query: str) -> Optional[Dict[str, Any]]:
    """
    Detect filesystem commands by looking for verb + file path patterns.

    This handles natural language commands like:
    - "delete C:\\Users\\test.txt"
    - "remove /home/user/file.txt"
    - "copy file.txt to backup.txt"

    Args:
        query: Lowercased user query

    Returns:
        Pattern dict if filesystem command detected, None otherwise
    """
    import re

    # Debug: print what we're checking
    print(f"[FILESYSTEM_CHECK] Checking query: {query[:60]}...")

    # COHERENCY FIX: Check for URLs first - these are NOT file paths
    # URLs should be routed to browser, not filesystem
    has_url = re.search(r'(?:https?://|www\.|\.com(?:\s|$)|\.org(?:\s|$)|\.net(?:\s|$)|\.io(?:\s|$))', query, re.IGNORECASE)
    if has_url:
        print(f"[FILESYSTEM_CHECK] URL detected, returning None (not a file path)")
        return None

    # File path patterns - handle both forward slashes and backslashes
    # Also handle Windows paths without backslashes (C:/Users/...)
    has_windows_path = re.search(r'[a-zA-Z]:[\\\/]', query) or re.search(r'[a-zA-Z]:', query)
    has_unix_path = re.search(r'(?:^|\s)\/\w', query) or re.search(r'(?:^|\s)\.\/\w', query)
    has_home_path = re.search(r'(?:^|\s)~[\\\/]', query)
    has_quoted_path = re.search(r'["\'][^"\']+["\']', query)

    # Also check for .txt, .py, .exe etc file extensions
    # COHERENCY FIX: Exclude web domains (.com, .org, .net, .io, .edu, .gov)
    has_file_extension = re.search(r'\.\w{2,4}(?:\s|$)', query)
    if has_file_extension:
        # Check if it's a web domain, not a file extension
        ext_match = has_file_extension.group(0).strip().lower()
        web_domains = ['.com', '.org', '.net', '.io', '.edu', '.gov', '.co', '.uk', '.ca', '.au']
        if ext_match in web_domains:
            print(f"[FILESYSTEM_CHECK] Web domain '{ext_match}' detected, not a file extension")
            has_file_extension = None

    has_file_path = has_windows_path or has_unix_path or has_home_path or has_quoted_path or has_file_extension

    print(f"[FILESYSTEM_CHECK] Path detection: win={bool(has_windows_path)}, unix={bool(has_unix_path)}, home={bool(has_home_path)}, quoted={bool(has_quoted_path)}, ext={bool(has_file_extension)}")

    if not has_file_path:
        print("[FILESYSTEM_CHECK] No file path detected, returning None")
        return None

    # Filesystem verbs and their methods
    verb_mapping = {
        "delete": "delete_file",
        "remove": "delete_file",
        "rm": "delete_file",
        "del": "delete_file",
        "erase": "delete_file",
        "copy": "copy_file",
        "cp": "copy_file",
        "duplicate": "copy_file",
        "move": "move_file",
        "mv": "move_file",
        "rename": "move_file",
        "read": "read_file",
        "cat": "read_file",
        "view": "read_file",
        "show": "read_file",
        "open": "read_file",
        "type": "read_file",
        "list": "scan_directory_tree",
        "ls": "scan_directory_tree",
        "dir": "scan_directory_tree",
    }

    # Check if query starts with or contains a filesystem verb
    query_words = query.split()
    first_word = query_words[0] if query_words else ""
    print(f"[FILESYSTEM_CHECK] First word: '{first_word}', looking for verbs...")

    method = None
    for verb, m in verb_mapping.items():
        # Check if verb is at the start or near start of query
        if first_word == verb or (len(query_words) > 1 and query_words[1] == verb):
            print(f"[FILESYSTEM_CHECK] Matched verb '{verb}' -> method '{m}'")
            method = m
            break
        # Also check if verb appears anywhere followed by a path indicator
        if re.search(rf'\b{verb}\b.*(?:[A-Za-z]:[\\\/]|\/\w|\.[\\\/]|~[\\\/])', query):
            print(f"[FILESYSTEM_CHECK] Matched verb '{verb}' with path pattern -> method '{m}'")
            method = m
            break

    if not method:
        print("[FILESYSTEM_CHECK] No verb matched, returning None")
        return None

    # Extract args
    args = _extract_filesystem_args(query, method)
    print(f"[FILESYSTEM_CHECK] Extracted args: {args}")

    # Build the pattern result
    result = {
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": method,
        "confidence": 0.95,
        "bypass_teacher": True,
        "description": f"Filesystem operation: {method}",
        "requires_args": True,
        "match_score": 0.95,
        "args": args
    }

    print(f"[FILESYSTEM_CHECK] Returning match for {method}")
    return result


def _is_tool_execution_allowed() -> bool:
    """Check if tool execution is allowed based on current profile/mode."""
    try:
        from brains.tools.execution_guard import get_execution_status, ExecMode
        status = get_execution_status()

        # SAFE_CHAT mode - no tools allowed
        if status.mode == ExecMode.SAFE_CHAT:
            return False

        # DISABLED mode - no tools allowed
        if status.mode == ExecMode.DISABLED:
            return False

        # FULL_AGENCY or FULL mode with effective=True - tools allowed
        if status.mode in (ExecMode.FULL_AGENCY, ExecMode.FULL) and status.effective:
            return True

        # READ_ONLY mode - only read operations allowed (partial)
        if status.mode == ExecMode.READ_ONLY:
            return True

        return False
    except Exception:
        return False


def should_bypass_teacher(query: str) -> bool:
    """
    Determine if a query should bypass Teacher and go directly to agency tools.

    This function respects the current execution profile:
    - In SAFE_CHAT mode, always returns False (no tool access)
    - In FULL_AGENCY mode, routes to tools as appropriate
    - In other modes, checks execution status

    Args:
        query: User query text

    Returns:
        True if query should use agency tools directly
    """
    # Check if tool execution is allowed
    if not _is_tool_execution_allowed():
        return False

    pattern = match_agency_pattern(query)
    return pattern is not None and pattern.get("bypass_teacher", False)


def get_tool_for_query(query: str) -> Optional[str]:
    """
    Get the tool path for a query.

    Args:
        query: User query text

    Returns:
        Tool import path or None
    """
    pattern = match_agency_pattern(query)
    return pattern["tool"] if pattern else None


def get_method_for_query(query: str) -> Optional[str]:
    """
    Get the method name for a query.

    Args:
        query: User query text

    Returns:
        Method name or None
    """
    pattern = match_agency_pattern(query)
    return pattern.get("method") if pattern else None


def explain_routing_decision(query: str) -> Dict[str, Any]:
    """
    Explain why a query was routed a particular way.

    Args:
        query: User query text

    Returns:
        Dictionary explaining routing decision
    """
    pattern = match_agency_pattern(query)

    if pattern:
        return {
            "routed_to": "agency_tool",
            "tool": pattern["tool"],
            "method": pattern.get("method"),
            "confidence": pattern["match_score"],
            "description": pattern["description"],
            "bypass_teacher": pattern["bypass_teacher"]
        }
    else:
        return {
            "routed_to": "teacher_fallback",
            "reason": "No agency pattern matched",
            "suggestion": "Add routing pattern or improve query specificity"
        }


# Export all patterns for external use
def get_all_patterns() -> List[Dict[str, Any]]:
    """Get all agency routing patterns."""
    return AGENCY_PATTERNS.copy()
