"""
Routing Decision Ladder
========================

Hard-coded decision ladder for routing that executes BEFORE any other routing logic.
This ensures critical routing rules cannot be bypassed.

Priority Order:
1. Explicit system commands (cpu, ram, pc scan, etc.)
2. Follow-up control phrases (summarize this, shorter, etc.)
3. Small-talk detection (hi, hello, how are you, etc.)
4. Self-identity gate (what are you, who are you, etc.)
5. Feedback/clarification (that's not right, not really, etc.)
6. Fallback to normal routing

This ladder PREVENTS:
- Small-talk triggering reasoning/Teacher
- "how are you" triggering self_model
- "cpu" in system context going to research
- "summarize this" becoming personality response
"""

from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional, List, Tuple
from enum import Enum
import re


class LadderIntent(Enum):
    """Intent types from the routing ladder."""
    SYSTEM_CONTROL = "system_control"       # cpu, ram, pc scan, kill process
    SUMMARIZATION = "summarization"         # summarize this, shorter, tl;dr
    SMALL_TALK = "small_talk"              # hi, hello, how are you
    SELF_IDENTITY = "self_identity"        # what are you, who are you (about Maven)
    PERSONAL_QUERY = "personal_query"      # what is my name, who am I (about USER)
    FEEDBACK = "feedback"                   # that's not right, not really
    CLARIFICATION = "clarification"        # explain more, what do you mean
    RESEARCH = "research"                   # what is X, how does Y work
    NONE = "none"                          # no match, continue to normal routing


@dataclass
class LadderDecision:
    """Result from the routing ladder."""
    intent: LadderIntent
    confidence: float
    reason: str
    target_brain: Optional[str] = None
    target_tool: Optional[str] = None
    allow_teacher: bool = False
    allow_reasoning: bool = False
    use_last_answer: bool = False
    matched_pattern: str = ""


# =============================================================================
# PATTERN DEFINITIONS
# =============================================================================

# System control commands (high priority when in system context)
SYSTEM_CONTROL_PATTERNS = [
    r"^(cpu|ram|gpu|memory|disk)$",                    # Single-word system queries
    r"^(cpu|ram|gpu|memory|disk)\s+(usage|load|stats?|info)$",
    r"^pc\s+scan$",
    r"^scan\s+(pc|system|computer)$",
    r"^system\s+(status|info|scan)$",
    r"^(kill|stop|terminate)\s+(process|pid)\s+\d+$",
    r"^(open|launch|start|run)\s+\w+",
    r"^(show|list|get)\s+(processes|tasks|apps)$",
]

# Follow-up control phrases that operate on last answer
FOLLOWUP_CONTROL_PATTERNS = [
    r"^(summarize|summarise)\s+(this|that|it)$",
    r"^(summarize|summarise)$",
    r"^tl;?\s*dr$",
    r"^tldr$",
    r"^(make|keep)\s+(it|this|that)\s+(shorter|simpler|brief)$",
    r"^(shorter|simpler|brief)(er)?$",
    r"^(short|brief)\s+version$",
    r"^(explain|tell)\s+(me\s+)?more$",
    r"^(go|dig)\s+(deeper|further)$",
    r"^what\s+do\s+you\s+mean(\?)?$",
    r"^elaborate(\s+on\s+(this|that))?$",
]

# Small-talk patterns - NEVER trigger reasoning or Teacher
SMALL_TALK_PATTERNS = [
    # Greetings
    r"^(hi|hello|hey|hiya|yo|sup|howdy)$",
    r"^(hi|hello|hey)\s+(there|maven|buddy|friend)?$",
    r"^good\s+(morning|afternoon|evening|night)$",
    r"^(what'?s?\s+up|how'?s?\s+it\s+going|how\s+are\s+(you|things))(\?)?$",
    r"^you\s+(there|around|available)(\?)?$",
    # Farewells
    r"^(bye|goodbye|see\s+(you|ya)|later|cya|ttyl)$",
    r"^(good\s+)?night$",
    # Thanks
    r"^(thanks?|thank\s+you|ty|thx)(\s+(a\s+lot|so\s+much|very\s+much))?$",
    r"^(much\s+)?appreciated$",
    # Acknowledgements
    r"^(ok|okay|k|cool|nice|great|awesome|perfect|sounds\s+good)$",
    r"^(got\s+it|understood|i\s+see|makes\s+sense)$",
    # Emotional/casual
    r"^i\s+hope\s+(you\s+)?(will|do|can)$",
    r"^(i'?ll|let\s+me)\s+try$",
    r"^(that'?s?|it'?s?)\s+(fine|good|okay|alright)$",
]

# Self-identity patterns - ONLY these trigger self_model
SELF_IDENTITY_PATTERNS = [
    r"^what\s+are\s+you(\?)?$",
    r"^who\s+are\s+you(\?)?$",
    r"^(what|who)\s+is\s+maven(\?)?$",
    r"^how\s+do\s+you\s+work(\?)?$",
    r"^(describe|explain)\s+(your|maven'?s?)\s+(architecture|system|design)$",
    r"^what\s+(can\s+)?you\s+do(\?)?$",
    r"^what\s+are\s+your\s+(capabilities|features|abilities)(\?)?$",
    r"^(tell\s+me\s+)?about\s+yourself$",
]

# Patterns that should NOT trigger self_model (emotional/casual)
SELF_IDENTITY_NEGATIVE_PATTERNS = [
    r"^how\s+are\s+you(\?)?$",          # NOT self-identity, it's small-talk
    r"^how'?s?\s+it\s+going(\?)?$",
    r"^you\s+(good|okay|alright)(\?)?$",
    r"^are\s+you\s+(there|okay|alright|working)(\?)?$",
    r"^you\s+there(\?)?$",
]

# Personal query patterns - asking about USER (not Maven)
# CRITICAL: These must be checked BEFORE self_identity to route correctly
PERSONAL_QUERY_PATTERNS = [
    r"^what\s+(is|are)\s+my\s+\w+(\?)?$",      # "what is my name?"
    r"^who\s+am\s+i(\?)?$",                     # "who am I?"
    r"^(what|where)\s+am\s+i(\?)?$",            # "what am I?" "where am I?"
    r"^(do|did)\s+(you|i)\s+(know|have)\s+my",  # "do you know my name"
    r"^(tell\s+me\s+)?about\s+(me|myself)$",    # "tell me about me"
    r"^my\s+name(\?)?$",                        # "my name?"
    r"^(what|who)\s+did\s+I\s+(say|tell)",      # "what did I say"
    r"^(remember|recall)\s+my\s+",              # "remember my name"
    r"^what\s+(should\s+)?(you\s+)?call\s+me",  # "what should you call me"
]

# Feedback patterns - user correcting or disagreeing
FEEDBACK_PATTERNS = [
    r"^(that'?s?\s+)?(not\s+)?(right|correct|accurate)$",
    r"^(no|nope|nah)$",
    r"^not\s+really$",
    r"^(that'?s?\s+)?(wrong|incorrect|inaccurate)$",
    r"^i\s+don'?t\s+think\s+(so|that'?s?\s+right)$",
    r"^(actually|um),?\s+no$",
    r"^try\s+again$",
]

# Research patterns - allowed to use Teacher
RESEARCH_PATTERNS = [
    r"^what\s+is\s+(a\s+)?\w+(\?)?$",
    r"^how\s+does\s+\w+\s+work(\?)?$",
    r"^(explain|describe)\s+\w+",
    r"^why\s+(do|does|is|are)\s+",
    r"^(tell\s+me\s+)?about\s+\w+$",
]


# =============================================================================
# DECISION LADDER
# =============================================================================

def _match_any(text: str, patterns: List[str]) -> Tuple[bool, str]:
    """Check if text matches any pattern, return (matched, pattern)."""
    text_lower = text.lower().strip()
    for pattern in patterns:
        if re.match(pattern, text_lower, re.IGNORECASE):
            return True, pattern
    return False, ""


def _is_in_system_context(context: Optional[Dict[str, Any]]) -> bool:
    """Check if we're in a system/PC context from recent queries."""
    if not context:
        return False

    # Check last query/answer context
    last_tool = context.get("last_tool_name", "")
    last_task = context.get("last_task_type", "")
    last_subject = context.get("last_answer_subject", "")
    recent_queries = context.get("recent_queries", [])

    # System context indicators
    system_tools = {"pc", "system", "shell", "process", "disk"}
    system_subjects = {"cpu", "ram", "gpu", "memory", "process", "system", "pc"}

    if any(t in last_tool.lower() for t in system_tools):
        return True
    if any(s in last_subject.lower() for s in system_subjects):
        return True
    if last_task in ("system_control", "system_task"):
        return True

    # Check recent queries for system context
    for q in recent_queries[-3:]:
        q_text = q.get("text", "").lower() if isinstance(q, dict) else str(q).lower()
        if any(s in q_text for s in ["pc scan", "cpu", "ram", "process", "system"]):
            return True

    return False


def run_routing_ladder(
    text: str,
    context: Optional[Dict[str, Any]] = None,
) -> LadderDecision:
    """
    Execute the routing decision ladder.

    This runs BEFORE any other routing and returns immediately if matched.

    Args:
        text: The user's query text
        context: Optional context with last_tool_name, last_task_type, etc.

    Returns:
        LadderDecision with intent and routing instructions
    """
    text_clean = text.strip()
    context = context or {}

    # =========================================================================
    # STEP 1: Check explicit system commands FIRST
    # =========================================================================
    matched, pattern = _match_any(text_clean, SYSTEM_CONTROL_PATTERNS)
    if matched:
        return LadderDecision(
            intent=LadderIntent.SYSTEM_CONTROL,
            confidence=0.95,
            reason="Explicit system control command",
            target_tool="pc",
            allow_teacher=False,
            allow_reasoning=False,
            matched_pattern=pattern,
        )

    # Single-word system queries depend on context
    text_lower = text_clean.lower()
    if text_lower in ("cpu", "ram", "gpu", "memory", "disk") and _is_in_system_context(context):
        return LadderDecision(
            intent=LadderIntent.SYSTEM_CONTROL,
            confidence=0.90,
            reason="Single-word system query in system context",
            target_tool="pc",
            allow_teacher=False,
            allow_reasoning=False,
            matched_pattern="single_word_system",
        )

    # =========================================================================
    # STEP 2: Check follow-up control phrases
    # =========================================================================
    matched, pattern = _match_any(text_clean, FOLLOWUP_CONTROL_PATTERNS)
    if matched:
        # Check if we have a last answer to operate on
        has_last_answer = bool(context.get("last_answer_text") or
                               context.get("last_answer_subject"))

        if "summarize" in pattern or "tldr" in pattern or "tl;" in pattern or "short" in pattern:
            return LadderDecision(
                intent=LadderIntent.SUMMARIZATION,
                confidence=0.95,
                reason="Summarization request on last answer",
                target_brain="language",
                allow_teacher=True,  # May need Teacher for good summarization
                allow_reasoning=False,
                use_last_answer=True,
                matched_pattern=pattern,
            )
        else:
            return LadderDecision(
                intent=LadderIntent.CLARIFICATION,
                confidence=0.90,
                reason="Clarification/expansion request",
                target_brain="language",
                allow_teacher=True,
                allow_reasoning=False,
                use_last_answer=True,
                matched_pattern=pattern,
            )

    # =========================================================================
    # STEP 3: Check small-talk (NEVER Teacher, NEVER reasoning)
    # =========================================================================
    matched, pattern = _match_any(text_clean, SMALL_TALK_PATTERNS)
    if matched:
        return LadderDecision(
            intent=LadderIntent.SMALL_TALK,
            confidence=0.95,
            reason="Small-talk detected - no Teacher, no reasoning",
            target_brain="personality",
            allow_teacher=False,
            allow_reasoning=False,
            matched_pattern=pattern,
        )

    # =========================================================================
    # STEP 4: Check PERSONAL queries BEFORE self-identity
    # CRITICAL: "what is my name" is about USER, not about Maven
    # =========================================================================
    matched, pattern = _match_any(text_clean, PERSONAL_QUERY_PATTERNS)
    if matched:
        return LadderDecision(
            intent=LadderIntent.PERSONAL_QUERY,
            confidence=0.95,
            reason="Personal query about USER - route to memory_librarian with personal_bank",
            target_brain="memory_librarian",
            allow_teacher=False,  # Personal facts come from MEMORY, not Teacher
            allow_reasoning=False,  # No reasoning needed - just memory lookup
            matched_pattern=pattern,
        )

    # =========================================================================
    # STEP 5: Check self-identity (narrow gate) - about MAVEN, not user
    # =========================================================================
    # FIRST check negative patterns - "how are you" is NOT self-identity
    matched_neg, _ = _match_any(text_clean, SELF_IDENTITY_NEGATIVE_PATTERNS)
    if matched_neg:
        # This is small-talk, not self-identity
        return LadderDecision(
            intent=LadderIntent.SMALL_TALK,
            confidence=0.90,
            reason="Emotional query - small-talk, not self-identity",
            target_brain="personality",
            allow_teacher=False,
            allow_reasoning=False,
            matched_pattern="emotional_small_talk",
        )

    # Now check actual self-identity patterns (about Maven)
    matched, pattern = _match_any(text_clean, SELF_IDENTITY_PATTERNS)
    if matched:
        return LadderDecision(
            intent=LadderIntent.SELF_IDENTITY,
            confidence=0.95,
            reason="Self-identity query about MAVEN - route to self_model",
            target_brain="self_model",
            allow_teacher=False,  # Self-identity NEVER uses Teacher
            allow_reasoning=False,
            matched_pattern=pattern,
        )

    # =========================================================================
    # STEP 5: Check feedback/disagreement
    # =========================================================================
    matched, pattern = _match_any(text_clean, FEEDBACK_PATTERNS)
    if matched:
        return LadderDecision(
            intent=LadderIntent.FEEDBACK,
            confidence=0.90,
            reason="Feedback/disagreement - ask for clarification",
            target_brain="language",
            allow_teacher=False,
            allow_reasoning=False,
            use_last_answer=True,
            matched_pattern=pattern,
        )

    # =========================================================================
    # STEP 6: Check research patterns (allowed to use Teacher)
    # =========================================================================
    matched, pattern = _match_any(text_clean, RESEARCH_PATTERNS)
    if matched:
        return LadderDecision(
            intent=LadderIntent.RESEARCH,
            confidence=0.70,  # Lower confidence - may need more routing
            reason="Research question - allowed to use Teacher",
            target_brain="reasoning",
            allow_teacher=True,
            allow_reasoning=True,
            matched_pattern=pattern,
        )

    # =========================================================================
    # STEP 7: No match - continue to normal routing
    # =========================================================================
    return LadderDecision(
        intent=LadderIntent.NONE,
        confidence=0.0,
        reason="No ladder match - continue to normal routing",
        allow_teacher=True,
        allow_reasoning=True,
    )


def should_skip_teacher(decision: LadderDecision) -> bool:
    """Check if Teacher should be skipped based on ladder decision."""
    return not decision.allow_teacher


def should_skip_reasoning(decision: LadderDecision) -> bool:
    """Check if reasoning should be skipped based on ladder decision."""
    return not decision.allow_reasoning


def get_small_talk_response(text: str) -> str:
    """
    Generate a canned response for small-talk.

    These are deterministic, no LLM needed.
    """
    text_lower = text.lower().strip()

    # Greetings
    if re.match(r"^(hi|hello|hey|hiya|yo|sup|howdy)", text_lower):
        return "Hello! How can I help you today?"

    if re.match(r"^good\s+morning", text_lower):
        return "Good morning! What would you like to work on?"

    if re.match(r"^good\s+afternoon", text_lower):
        return "Good afternoon! How can I assist you?"

    if re.match(r"^good\s+evening", text_lower):
        return "Good evening! What can I do for you?"

    if re.match(r"^(what'?s?\s+up|how'?s?\s+it\s+going)", text_lower):
        return "All systems operational. What would you like to work on?"

    if re.match(r"^how\s+are\s+(you|things)", text_lower):
        return "I don't have feelings, but I'm running normally. How can I help?"

    if re.match(r"^you\s+(there|around|available)", text_lower):
        return "Yes, I'm here. What do you need?"

    # Farewells
    if re.match(r"^(bye|goodbye|see\s+(you|ya)|later|cya|ttyl)", text_lower):
        return "Goodbye! Feel free to return anytime."

    if re.match(r"^(good\s+)?night", text_lower):
        return "Good night! Take care."

    # Thanks
    if re.match(r"^(thanks?|thank\s+you|ty|thx)", text_lower):
        return "You're welcome!"

    if re.match(r"^(much\s+)?appreciated", text_lower):
        return "Happy to help!"

    # Acknowledgements
    if re.match(r"^(ok|okay|k|cool|nice|great|awesome|perfect)", text_lower):
        return "Let me know if you need anything else."

    if re.match(r"^(got\s+it|understood|i\s+see|makes\s+sense)", text_lower):
        return "Great! Is there anything else?"

    # Emotional/casual
    if re.match(r"^i\s+hope\s+(you\s+)?(will|do|can)", text_lower):
        return "I'll do my best."

    if re.match(r"^(that'?s?|it'?s?)\s+(fine|good|okay|alright)", text_lower):
        return "Okay. Anything else I can help with?"

    # Default
    return "I'm here to help. What would you like to do?"


def get_feedback_response() -> str:
    """Generate a response for feedback/disagreement."""
    return "I see. What specifically wasn't right? I'll try to improve."


# =============================================================================
# SERVICE API
# =============================================================================

def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point for routing ladder.

    Operations:
    - CLASSIFY: Run the routing ladder on a query
    - GET_RESPONSE: Get canned response for small-talk/feedback
    """
    op = msg.get("op", "")
    payload = msg.get("payload", {})

    if op == "CLASSIFY":
        text = payload.get("text", "")
        context = payload.get("context")

        decision = run_routing_ladder(text, context)

        return {
            "ok": True,
            "payload": {
                "intent": decision.intent.value,
                "confidence": decision.confidence,
                "reason": decision.reason,
                "target_brain": decision.target_brain,
                "target_tool": decision.target_tool,
                "allow_teacher": decision.allow_teacher,
                "allow_reasoning": decision.allow_reasoning,
                "use_last_answer": decision.use_last_answer,
                "matched_pattern": decision.matched_pattern,
            }
        }

    elif op == "GET_RESPONSE":
        text = payload.get("text", "")
        intent = payload.get("intent", "small_talk")

        if intent == "small_talk":
            response = get_small_talk_response(text)
        elif intent == "feedback":
            response = get_feedback_response()
        else:
            response = "I'm here to help."

        return {
            "ok": True,
            "payload": {"response": response}
        }

    return {"ok": False, "error": f"Unknown op: {op}"}


handle = service_api
