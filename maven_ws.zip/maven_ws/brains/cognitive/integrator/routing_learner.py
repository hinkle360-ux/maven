"""
Routing Learner
===============

Continuously improves routing through analysis of past decisions.

This module:
1. Analyzes routing decision history
2. Identifies patterns of failures
3. Generates upgrade proposals for persistent issues
4. Tracks performance metrics per brain

Runs periodically (e.g., every 100 queries or on system idle).
"""

from __future__ import annotations

import json
import time
from collections import defaultdict
from dataclasses import dataclass, field, asdict
from datetime import datetime, timedelta
from pathlib import Path
from brains.maven_paths import get_state_path
from typing import Any, Dict, List, Optional, Tuple, Set

# Import memory librarian for storing learned patterns
try:
    from brains.cognitive.memory_librarian.service.memory_librarian import (
        get_memory_librarian,
    )
    _memory_available = True
except ImportError:
    _memory_available = False
    get_memory_librarian = None  # type: ignore

# Import upgrade engine for generating proposals
try:
    from brains.governance.upgrade_engine.service.upgrade_engine import (
        get_upgrade_engine,
    )
    _upgrade_engine_available = True
except ImportError:
    _upgrade_engine_available = False
    get_upgrade_engine = None  # type: ignore

# Storage paths
MAVEN_DIR = get_state_path()
ROUTING_PATTERNS_PATH = MAVEN_DIR / "routing" / "learned_patterns.json"
ROUTING_CORRECTIONS_PATH = MAVEN_DIR / "routing" / "corrections.jsonl"
ROUTING_DECISIONS_PATH = MAVEN_DIR / "routing" / "decisions.jsonl"
ROUTING_ANALYSIS_PATH = MAVEN_DIR / "routing" / "analysis_results.json"
UPGRADE_PROPOSALS_PATH = MAVEN_DIR / "routing" / "upgrade_proposals.jsonl"


def _ensure_dir(path: Path) -> None:
    """Ensure parent directory exists."""
    path.parent.mkdir(parents=True, exist_ok=True)


# =============================================================================
# DATA STRUCTURES
# =============================================================================

@dataclass
class RoutingAnalysis:
    """
    Analysis results for routing performance.
    """
    total_queries: int = 0
    brain_usage: Dict[str, int] = field(default_factory=dict)
    success_rate_by_brain: Dict[str, float] = field(default_factory=dict)
    common_misroutes: List[Dict[str, Any]] = field(default_factory=list)
    confidence_distribution: List[float] = field(default_factory=list)
    weak_spots: List[Dict[str, Any]] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class RoutingWeakness:
    """
    Identified routing weakness requiring attention.
    """
    weakness_type: str  # "low_success_rate", "repeated_misroute", "low_confidence"
    brain: Optional[str] = None
    pattern: Optional[str] = None
    wrong_brain: Optional[str] = None
    correct_brain: Optional[str] = None
    count: int = 0
    severity: float = 0.0
    recommendation: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class UpgradeProposal:
    """
    Proposal for routing system upgrade.
    """
    id: str
    origin: str = "routing_learner"
    trigger: str = "performance_analysis"
    motivation: str = ""
    evidence: Dict[str, Any] = field(default_factory=dict)
    change_type: str = "routing_rule"
    scope: List[str] = field(default_factory=list)
    suggested_fix: Dict[str, Any] = field(default_factory=dict)
    risk_level: str = "low"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    status: str = "pending"

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


# =============================================================================
# ROUTING LEARNER
# =============================================================================

class RoutingLearner:
    """
    Analyze routing patterns and generate improvements.

    This class periodically analyzes routing decisions to:
    1. Identify patterns of failures
    2. Track performance by brain
    3. Generate upgrade proposals for persistent issues
    """

    def __init__(self):
        """Initialize the routing learner."""
        self.memory = get_memory_librarian() if _memory_available and get_memory_librarian else None
        self.upgrade_engine = get_upgrade_engine() if _upgrade_engine_available and get_upgrade_engine else None

        # Analysis state
        self.last_analysis_time: Optional[datetime] = None
        self.query_count_since_analysis: int = 0

        # Thresholds
        self.analysis_query_threshold = 100  # Run analysis every N queries
        self.analysis_time_threshold = timedelta(hours=6)  # Or every N hours
        self.weakness_severity_threshold = 0.7  # Generate proposals above this

        # Load last analysis
        self._load_last_analysis()

    def _load_last_analysis(self) -> None:
        """Load last analysis results from disk."""
        try:
            if ROUTING_ANALYSIS_PATH.exists():
                with ROUTING_ANALYSIS_PATH.open("r", encoding="utf-8") as f:
                    data = json.load(f)
                    timestamp = data.get("timestamp")
                    if timestamp:
                        self.last_analysis_time = datetime.fromisoformat(timestamp)
        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to load last analysis: {e}")

    def record_query(self) -> None:
        """Record that a query was processed."""
        self.query_count_since_analysis += 1

        # Check if we should run analysis
        if self._should_run_analysis():
            self.analyze_routing_performance()

    def _should_run_analysis(self) -> bool:
        """Check if we should run routing analysis."""
        # Check query threshold
        if self.query_count_since_analysis >= self.analysis_query_threshold:
            return True

        # Check time threshold
        if self.last_analysis_time:
            time_since = datetime.now() - self.last_analysis_time
            if time_since >= self.analysis_time_threshold:
                return True

        return False

    def analyze_routing_performance(self) -> RoutingAnalysis:
        """
        Analyze routing decisions and identify improvements.

        Steps:
        1. Load routing history
        2. Calculate per-brain metrics
        3. Identify weak spots
        4. Generate upgrade proposals if needed
        """
        print("[ROUTING_LEARNER] Starting routing performance analysis...")

        # Reset counter
        self.query_count_since_analysis = 0
        self.last_analysis_time = datetime.now()

        # Load routing history
        routing_history = self._load_routing_history()
        corrections = self._load_corrections()

        # Analyze patterns
        analysis = self._analyze_patterns(routing_history, corrections)

        # Identify weak spots
        weak_spots = self._identify_weak_spots(analysis, corrections)
        analysis.weak_spots = [w.to_dict() for w in weak_spots]

        # Generate upgrade proposals for severe weaknesses
        for weakness in weak_spots:
            if weakness.severity >= self.weakness_severity_threshold:
                self._generate_upgrade_proposal(weakness)

        # Save analysis results
        self._save_analysis(analysis)

        print(f"[ROUTING_LEARNER] Analysis complete: {analysis.total_queries} queries, "
              f"{len(weak_spots)} weaknesses identified")

        return analysis

    def _load_routing_history(self, days: int = 7) -> List[Dict[str, Any]]:
        """Load routing decisions from the last N days."""
        routing_history = []
        cutoff = datetime.now() - timedelta(days=days)

        # Load from routing patterns file
        try:
            if ROUTING_PATTERNS_PATH.exists():
                with ROUTING_PATTERNS_PATH.open("r", encoding="utf-8") as f:
                    patterns = json.load(f)

                    for query, data in patterns.items():
                        timestamp_str = data.get("timestamp", "")
                        if timestamp_str:
                            try:
                                timestamp = datetime.fromisoformat(timestamp_str)
                                if timestamp >= cutoff:
                                    routing_history.append({
                                        "query": query,
                                        "classification": data.get("classification", {}),
                                        "timestamp": timestamp_str,
                                        "reinforcement_count": data.get("reinforcement_count", 0),
                                    })
                            except ValueError:
                                continue
        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to load routing patterns: {e}")

        # Load from decisions log
        try:
            if ROUTING_DECISIONS_PATH.exists():
                with ROUTING_DECISIONS_PATH.open("r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            entry = json.loads(line)
                            timestamp_str = entry.get("timestamp", "")
                            if timestamp_str:
                                timestamp = datetime.fromisoformat(timestamp_str.rstrip("Z"))
                                if timestamp >= cutoff:
                                    routing_history.append(entry)
                        except (json.JSONDecodeError, ValueError):
                            continue
        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to load decisions log: {e}")

        return routing_history

    def _load_corrections(self) -> List[Dict[str, Any]]:
        """Load routing corrections."""
        corrections = []

        try:
            if ROUTING_CORRECTIONS_PATH.exists():
                with ROUTING_CORRECTIONS_PATH.open("r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            corrections.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue
        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to load corrections: {e}")

        return corrections

    def _analyze_patterns(self, routing_history: List[Dict[str, Any]],
                         corrections: List[Dict[str, Any]]) -> RoutingAnalysis:
        """Analyze routing patterns for insights."""
        analysis = RoutingAnalysis()
        analysis.total_queries = len(routing_history)

        # Track brain usage
        brain_usage: Dict[str, int] = defaultdict(int)
        brain_successes: Dict[str, int] = defaultdict(int)
        brain_failures: Dict[str, int] = defaultdict(int)
        confidence_values: List[float] = []

        # Process routing history
        for decision in routing_history:
            classification = decision.get("classification", {})
            brains = classification.get("recommended_brains", [])

            # Track brain usage
            for brain in brains:
                brain_usage[brain] += 1

            # Track confidence
            confidence = classification.get("confidence", 0)
            if confidence > 0:
                confidence_values.append(confidence)

            # Track reinforcement (success indicator)
            reinforcement = decision.get("reinforcement_count", 0)
            if reinforcement > 1:
                for brain in brains:
                    brain_successes[brain] += 1

        # Process corrections (failures)
        for correction in corrections:
            wrong_routing = correction.get("wrong_routing", {})
            wrong_brains = wrong_routing.get("recommended_brains", [])

            for brain in wrong_brains:
                brain_failures[brain] += 1

        # Calculate success rates
        for brain, usage in brain_usage.items():
            successes = brain_successes.get(brain, 0)
            failures = brain_failures.get(brain, 0)
            total = successes + failures

            if total > 0:
                success_rate = successes / total
            elif usage > 0:
                # No explicit feedback - assume 70% success
                success_rate = 0.7
            else:
                success_rate = 0.0

            analysis.success_rate_by_brain[brain] = success_rate

        analysis.brain_usage = dict(brain_usage)
        analysis.confidence_distribution = confidence_values

        return analysis

    def _identify_weak_spots(self, analysis: RoutingAnalysis,
                            corrections: List[Dict[str, Any]]) -> List[RoutingWeakness]:
        """Identify routing weaknesses."""
        weaknesses: List[RoutingWeakness] = []

        # Check for brains with low success rates
        for brain, success_rate in analysis.success_rate_by_brain.items():
            if success_rate < 0.6:
                weaknesses.append(RoutingWeakness(
                    weakness_type="low_success_rate",
                    brain=brain,
                    count=analysis.brain_usage.get(brain, 0),
                    severity=1.0 - success_rate,
                    recommendation=f"Improve routing to {brain} brain - current success rate: {success_rate:.0%}"
                ))

        # Check for repeated misroutes (same wrong_brain -> correct_brain pattern)
        misroute_patterns: Dict[Tuple[str, str], List[str]] = defaultdict(list)

        for correction in corrections:
            wrong_routing = correction.get("wrong_routing", {})
            wrong_brains = wrong_routing.get("recommended_brains", [])
            correct_brain = correction.get("correct_routing")
            query = correction.get("query", "")

            if wrong_brains and correct_brain:
                key = (wrong_brains[0], correct_brain)
                misroute_patterns[key].append(query)

        # Create weaknesses for repeated misroutes
        for (wrong_brain, correct_brain), queries in misroute_patterns.items():
            if len(queries) >= 3:
                # Find common pattern in queries
                common_words = self._find_common_pattern(queries)

                weaknesses.append(RoutingWeakness(
                    weakness_type="repeated_misroute",
                    wrong_brain=wrong_brain,
                    correct_brain=correct_brain,
                    pattern=common_words,
                    count=len(queries),
                    severity=min(len(queries) / 10, 1.0),
                    recommendation=f"Route queries matching '{common_words}' to {correct_brain} instead of {wrong_brain}"
                ))

        # Check for low confidence patterns
        if analysis.confidence_distribution:
            low_confidence_count = sum(1 for c in analysis.confidence_distribution if c < 0.5)
            low_confidence_ratio = low_confidence_count / len(analysis.confidence_distribution)

            if low_confidence_ratio > 0.3:
                weaknesses.append(RoutingWeakness(
                    weakness_type="low_confidence",
                    count=low_confidence_count,
                    severity=low_confidence_ratio,
                    recommendation=f"Many queries ({low_confidence_ratio:.0%}) have low routing confidence - consider adding more patterns"
                ))

        return weaknesses

    def _find_common_pattern(self, queries: List[str]) -> str:
        """Find common words/patterns in a list of queries."""
        if not queries:
            return ""

        # Tokenize all queries
        word_counts: Dict[str, int] = defaultdict(int)
        stopwords = {"a", "an", "the", "is", "are", "was", "were", "be", "been",
                     "to", "of", "in", "for", "on", "with", "at", "by", "from",
                     "i", "me", "my", "you", "your", "it", "this", "that"}

        for query in queries:
            words = set(query.lower().split())
            words = words - stopwords

            for word in words:
                if len(word) > 2:  # Skip very short words
                    word_counts[word] += 1

        # Find words that appear in most queries
        threshold = len(queries) * 0.6
        common_words = [
            word for word, count in word_counts.items()
            if count >= threshold
        ]

        # Sort by frequency
        common_words.sort(key=lambda w: word_counts[w], reverse=True)

        return " ".join(common_words[:5]) if common_words else queries[0][:30]

    def _generate_upgrade_proposal(self, weakness: RoutingWeakness) -> None:
        """Generate upgrade proposal to fix a routing weakness."""
        proposal = UpgradeProposal(
            id=f"routing_upgrade_{int(time.time())}",
            origin="routing_learner",
            trigger="performance_analysis",
            scope=[
                "brains/cognitive/integrator/llm_intent_classifier.py",
                "brains/routing/routing_engine.py",
            ],
        )

        if weakness.weakness_type == "low_success_rate":
            proposal.motivation = (
                f"Brain '{weakness.brain}' has low routing success rate. "
                f"Success rate: {(1 - weakness.severity):.0%}, "
                f"Total queries: {weakness.count}."
            )
            proposal.evidence = {
                "brain": weakness.brain,
                "success_rate": 1 - weakness.severity,
                "query_count": weakness.count,
            }
            proposal.suggested_fix = {
                "type": "improve_brain_detection",
                "brain": weakness.brain,
                "description": f"Improve keyword patterns and LLM prompts for routing to {weakness.brain}",
            }

        elif weakness.weakness_type == "repeated_misroute":
            proposal.motivation = (
                f"Repeated misrouting detected. Queries are being sent to "
                f"'{weakness.wrong_brain}' when they should go to '{weakness.correct_brain}'. "
                f"This has happened {weakness.count} times. "
                f"Common pattern: '{weakness.pattern}'."
            )
            proposal.evidence = {
                "pattern": weakness.pattern,
                "wrong_brain": weakness.wrong_brain,
                "correct_brain": weakness.correct_brain,
                "occurrence_count": weakness.count,
            }
            proposal.suggested_fix = {
                "type": "add_routing_pattern",
                "pattern": weakness.pattern,
                "route_to": weakness.correct_brain,
                "priority": 0.95,
                "description": f"Add pattern '{weakness.pattern}' -> {weakness.correct_brain}",
            }

        elif weakness.weakness_type == "low_confidence":
            proposal.motivation = (
                f"Many queries ({weakness.count}) have low routing confidence. "
                f"This suggests the classifier needs more training patterns."
            )
            proposal.evidence = {
                "low_confidence_count": weakness.count,
                "severity": weakness.severity,
            }
            proposal.suggested_fix = {
                "type": "add_classification_patterns",
                "description": "Expand keyword patterns and consider adding more LLM classification examples",
            }
            proposal.risk_level = "medium"

        proposal.risk_level = "low" if weakness.severity < 0.8 else "medium"

        # Submit to upgrade engine if available
        if self.upgrade_engine:
            try:
                self.upgrade_engine.submit_proposal(proposal.to_dict())
                print(f"[ROUTING_LEARNER] Submitted upgrade proposal: {proposal.id}")
            except Exception as e:
                print(f"[ROUTING_LEARNER] Failed to submit proposal: {e}")

        # Also save locally
        self._save_proposal(proposal)

    def _save_proposal(self, proposal: UpgradeProposal) -> None:
        """Save upgrade proposal to disk."""
        try:
            _ensure_dir(UPGRADE_PROPOSALS_PATH)
            with UPGRADE_PROPOSALS_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps(proposal.to_dict()) + "\n")
        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to save proposal: {e}")

    def _save_analysis(self, analysis: RoutingAnalysis) -> None:
        """Save analysis results to disk."""
        try:
            _ensure_dir(ROUTING_ANALYSIS_PATH)
            with ROUTING_ANALYSIS_PATH.open("w", encoding="utf-8") as f:
                json.dump(analysis.to_dict(), f, indent=2)
        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to save analysis: {e}")

    def get_analysis_summary(self) -> Dict[str, Any]:
        """Get a summary of the latest analysis."""
        try:
            if ROUTING_ANALYSIS_PATH.exists():
                with ROUTING_ANALYSIS_PATH.open("r", encoding="utf-8") as f:
                    return json.load(f)
        except Exception:
            pass

        return {
            "status": "no_analysis_available",
            "message": "Run analyze_routing_performance() to generate analysis",
        }

    def get_pending_proposals(self) -> List[Dict[str, Any]]:
        """Get list of pending upgrade proposals."""
        proposals = []

        try:
            if UPGRADE_PROPOSALS_PATH.exists():
                with UPGRADE_PROPOSALS_PATH.open("r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            proposal = json.loads(line)
                            if proposal.get("status") == "pending":
                                proposals.append(proposal)
                        except json.JSONDecodeError:
                            continue
        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to load proposals: {e}")

        return proposals

    def mark_proposal_applied(self, proposal_id: str) -> None:
        """Mark a proposal as applied."""
        # Load all proposals
        all_proposals = []

        try:
            if UPGRADE_PROPOSALS_PATH.exists():
                with UPGRADE_PROPOSALS_PATH.open("r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            all_proposals.append(json.loads(line))
                        except json.JSONDecodeError:
                            continue

            # Update status
            for proposal in all_proposals:
                if proposal.get("id") == proposal_id:
                    proposal["status"] = "applied"
                    proposal["applied_at"] = datetime.now().isoformat()

            # Write back
            with UPGRADE_PROPOSALS_PATH.open("w", encoding="utf-8") as f:
                for proposal in all_proposals:
                    f.write(json.dumps(proposal) + "\n")

        except Exception as e:
            print(f"[ROUTING_LEARNER] Failed to mark proposal applied: {e}")


# =============================================================================
# SINGLETON ACCESSOR
# =============================================================================

_learner_instance: Optional[RoutingLearner] = None


def get_routing_learner() -> RoutingLearner:
    """Get the singleton routing learner instance."""
    global _learner_instance

    if _learner_instance is None:
        _learner_instance = RoutingLearner()

    return _learner_instance


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "RoutingLearner",
    "RoutingAnalysis",
    "RoutingWeakness",
    "UpgradeProposal",
    "get_routing_learner",
]
