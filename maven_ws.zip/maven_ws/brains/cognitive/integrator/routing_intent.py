"""
routing_intent.py
~~~~~~~~~~~~~~~~~

Data structures for LLM-assisted smart routing.

This module defines the core types used for routing classification:
- RoutingIntent: The classified intent of a user message
- RoutingSuggestion: Teacher's routing recommendation
- RoutingPlan: Final validated routing plan after capability checks

The design goal is to make routing feel like a smart chat assistant:
- Robust to phrasing: "help me debug this", "why is this breaking", "this code is weird"
  should all route to the same path.
- Dynamic: adjusts based on context, prior turns, capabilities.
- LLM helps teach routing, but never lies about capabilities or internal state.

This module is self-contained with no LLM dependencies so that:
1. Types can be used anywhere without circular imports
2. Future non-LLM classifiers can use the same types
"""

from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional
import json


class PrimaryIntent(str, Enum):
    """
    Primary intent categories for routing.

    These represent the top-level classification of what the user wants.
    """
    # Chat/conversation intents
    CHAT_ANSWER = "chat_answer"          # General conversational response
    SMALL_TALK = "small_talk"            # Casual chat, greetings

    # Task intents
    CODE_TASK = "code_task"              # Write, debug, or modify code
    RESEARCH_QUESTION = "research_question"  # Research/investigation needed
    TOOL_REQUEST = "tool_request"        # Direct tool execution request
    WEB_SEARCH = "web_search"            # Web search for current info (games, news, etc.)

    # Self-knowledge intents (MUST route to self_model, NOT Teacher)
    CAPABILITY_QUESTION = "capability_question"  # "can you X?" questions
    SELF_QUESTION = "self_question"      # "who are you?" identity questions
    HISTORY_QUESTION = "history_question"  # "what did we discuss?" history
    LEARNING_QUESTION = "learning_question"  # "what did you learn?" post-tool questions

    # Follow-up intents
    TASK_FOLLOWUP = "task_followup"      # Continuation of previous task
    CLARIFICATION = "clarification"      # "I meant X" clarifications

    # Meta intents
    META_INSTRUCTION = "meta_instruction"  # Instructions about behavior
    FEEDBACK = "feedback"                # User feedback on responses
    META_PROVENANCE = "meta_provenance"  # "where did that answer come from?" questions

    # User profile queries (about stored facts about the user)
    USER_PROFILE_QUERY = "user_profile_query"  # "tell me about myself", "what do you know about me"

    # Fallback
    UNKNOWN = "unknown"                  # Could not classify


class Urgency(str, Enum):
    """Urgency level for routing decisions."""
    LOW = "low"           # Can take time, exploration allowed
    MEDIUM = "medium"     # Normal priority
    HIGH = "high"         # Needs quick response
    CRITICAL = "critical"  # Safety-critical, minimal processing


class Complexity(str, Enum):
    """Complexity level for routing decisions."""
    SIMPLE = "simple"     # Single step, direct answer
    MODERATE = "moderate"  # Multiple steps, some reasoning
    COMPLEX = "complex"   # Multi-stage, requires planning
    VERY_COMPLEX = "very_complex"  # Major task, full orchestration


@dataclass
class RoutingIntent:
    """
    Classified intent of a user message.

    This is the output of classify_intent() and represents what we believe
    the user wants, independent of how we'll fulfill that want.

    Attributes:
        primary_intent: Main intent category
        secondary_tags: Additional context tags (e.g., ["browser", "python", "project:maven"])
        urgency: How urgent is this request?
        complexity: How complex is this request?
        confidence: How confident are we in this classification (0.0-1.0)?
        raw_signals: Debug info about what signals led to this classification
    """
    primary_intent: PrimaryIntent
    secondary_tags: List[str] = field(default_factory=list)
    urgency: Urgency = Urgency.MEDIUM
    complexity: Complexity = Complexity.MODERATE
    confidence: float = 0.5
    raw_signals: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "primary_intent": self.primary_intent.value,
            "secondary_tags": self.secondary_tags,
            "urgency": self.urgency.value,
            "complexity": self.complexity.value,
            "confidence": self.confidence,
            "raw_signals": self.raw_signals,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> RoutingIntent:
        """Deserialize from dictionary."""
        return RoutingIntent(
            primary_intent=PrimaryIntent(d.get("primary_intent", "unknown")),
            secondary_tags=d.get("secondary_tags", []),
            urgency=Urgency(d.get("urgency", "medium")),
            complexity=Complexity(d.get("complexity", "moderate")),
            confidence=float(d.get("confidence", 0.5)),
            raw_signals=d.get("raw_signals", {}),
        )

    def is_self_intent(self) -> bool:
        """Check if this intent should route to self_model (NOT Teacher)."""
        return self.primary_intent in (
            PrimaryIntent.CAPABILITY_QUESTION,
            PrimaryIntent.SELF_QUESTION,
            PrimaryIntent.HISTORY_QUESTION,
            PrimaryIntent.LEARNING_QUESTION,
            PrimaryIntent.USER_PROFILE_QUERY,
            PrimaryIntent.META_PROVENANCE,  # "where did that answer come from?"
        )

    def is_user_profile_query(self) -> bool:
        """Check if this is a user profile query (about stored facts about the user)."""
        return self.primary_intent == PrimaryIntent.USER_PROFILE_QUERY


@dataclass
class RoutingSuggestion:
    """
    Teacher's routing recommendation.

    This is what the Teacher LLM suggests for routing, but it has NOT been
    validated against actual capabilities yet.

    IMPORTANT: Teacher suggestions MUST be validated before use:
    1. Check suggested brains exist in brain_roles
    2. Check suggested tools exist and are enabled
    3. Intersect with system_capabilities

    Attributes:
        recommended_brains: Brain names Teacher suggests (e.g., ["reasoning", "coder"])
        recommended_tools: Tool paths Teacher suggests (e.g., ["web_client.search"])
        notes: Teacher's explanation (for debugging/training only)
        confidence: Teacher's confidence in this suggestion
        raw_response: Original Teacher response for logging
    """
    recommended_brains: List[str] = field(default_factory=list)
    recommended_tools: List[str] = field(default_factory=list)
    notes: str = ""
    confidence: float = 0.5
    raw_response: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "recommended_brains": self.recommended_brains,
            "recommended_tools": self.recommended_tools,
            "notes": self.notes,
            "confidence": self.confidence,
            "raw_response": self.raw_response,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> RoutingSuggestion:
        """Deserialize from dictionary."""
        return RoutingSuggestion(
            recommended_brains=d.get("recommended_brains", []),
            recommended_tools=d.get("recommended_tools", []),
            notes=d.get("notes", ""),
            confidence=float(d.get("confidence", 0.5)),
            raw_response=d.get("raw_response", {}),
        )


@dataclass
class RoutingPlan:
    """
    Final validated routing plan.

    This is the output of compute_routing_plan() and represents the ACTUAL
    routing that will be executed. All suggestions have been validated
    against real capabilities.

    Attributes:
        final_brains: Validated brain names to activate
        final_tools: Validated tool paths to use
        intent: The classified intent that led to this plan
        suggestion_source: Where the suggestion came from
        reasons: Audit trail of why each decision was made
        validation_notes: What was filtered out and why
    """
    final_brains: List[str] = field(default_factory=list)
    final_tools: List[str] = field(default_factory=list)
    intent: Optional[RoutingIntent] = None
    suggestion_source: str = "fallback"  # "teacher", "pattern_match", "rl_routing", "fallback"
    reasons: List[str] = field(default_factory=list)
    validation_notes: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return {
            "final_brains": self.final_brains,
            "final_tools": self.final_tools,
            "intent": self.intent.to_dict() if self.intent else None,
            "suggestion_source": self.suggestion_source,
            "reasons": self.reasons,
            "validation_notes": self.validation_notes,
        }

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> RoutingPlan:
        """Deserialize from dictionary."""
        intent_data = d.get("intent")
        return RoutingPlan(
            final_brains=d.get("final_brains", []),
            final_tools=d.get("final_tools", []),
            intent=RoutingIntent.from_dict(intent_data) if intent_data else None,
            suggestion_source=d.get("suggestion_source", "fallback"),
            reasons=d.get("reasons", []),
            validation_notes=d.get("validation_notes", []),
        )

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), indent=2)


# =============================================================================
# Intent Classification Patterns
# =============================================================================

# These patterns are used for fast local classification before calling Teacher.
# They are gradually learned/updated by the distillation job.

SELF_INTENT_PATTERNS = {
    # Capability questions - MUST route to system_capabilities, NOT Teacher
    "capability_question": [
        "can you",
        "are you able to",
        "do you have",
        "what can you do",
        "what are your capabilities",
        "what tools do you have",
        "can you browse",
        "can you search",
        "can you run",
        "can you execute",
        "can you read",
        "can you write",
        "can you access",
        "can you control",
        "do you have access",
        "do you have internet",
    ],
    # Self-identity questions - MUST route to self_model, NOT Teacher
    "self_question": [
        "who are you",
        "what are you",
        "tell me about yourself",
        "describe yourself",
        "what is your name",
        "are you maven",
        "are you an llm",
        "are you chatgpt",
        "are you claude",
        "are you gpt",
        "are you openai",
        # COHERENCY FIX: Identity challenge patterns (accusatory form)
        "you're chatgpt",
        "you're gpt",
        "you're claude",
        "you're an ai",
        "you're a bot",
        "you're not maven",
        "you are chatgpt",
        "you are gpt",
        "you are claude",
        "you are not maven",
        "you sound like chatgpt",
        "you sound like gpt",
        "you sound like claude",
        "who made you",
        "who created you",
        "what is your purpose",
        "how do you work",
        # TASK 1: Internal state / feelings / preferences questions
        # These MUST route to self_model, NOT Teacher
        "how do you feel",
        "how are you feeling",
        "do you have feelings",
        "do you have emotions",
        "are you happy",
        "are you sad",
        "are you conscious",
        "are you sentient",
        "are you alive",
        "do you like",
        "do you enjoy",
        "do you prefer",
        "what do you think about yourself",
        "what do you like",
        "what do you want",
        "what do you prefer",
        "do you have preferences",
        "do you have opinions",
        "what is your opinion",
        "how do you think",
        "are you real",
        "are you a person",
        "do you dream",
        "do you sleep",
        "do you get tired",
        "do you get bored",
    ],
    # History questions - MUST route to system_history, NOT Teacher
    "history_question": [
        "what did we discuss",
        "what did i ask",
        "what did you say",
        "our conversation",
        "previous question",
        "earlier you said",
        "remember when",
        "last time we",
        "yesterday we",
        "do you remember",
    ],
    # Learning questions - MUST route to self_model + memory_librarian
    # CRITICAL: These are asked after chatgpt/grok/claude tool runs
    "learning_question": [
        "what did you learn",
        "what did you just learn",
        "what have you learned",
        "tell me what you learned",
        "what lessons",
        "what facts did you",
        "what did chatgpt say",
        "what did chatgpt tell you",
        "what did chatgpt teach",
        "what did grok say",
        "what did grok tell you",
        "what did grok teach",
        "what did claude say",
        "what did claude tell you",
        "what did claude teach",
        "from that session",
        "from that conversation",
        "from that chat",
        "summarize what you learned",
        "recent learning",
        "recent lessons",
    ],
    # User profile queries - MUST route to memory_librarian, NOT Teacher
    # These ask about stored facts about the user themselves
    "user_profile_query": [
        "tell me about myself",
        "tell me about me",
        "what do you know about me",
        "what do you know about myself",
        "what have you learned about me",
        "what did you learn about me",
        "what do you remember about me",
        "who am i",
        "describe me",
        "what have i told you about myself",
        "what have i shared with you",
        "what facts do you know about me",
        "summarize what you know about me",
        "my profile",
        "about me",
        # Handle user name variations (Josh is an example)
        "what do you know about josh",
        "what do you know about your creator",
        "what do you know about your owner",
        "tell me about josh",
        "who is josh",
    ],

    # Meta/provenance questions - asking about HOW Maven answered
    # These need special handling to explain answer sources
    "meta_provenance": [
        "where did this answer come from",
        "where did that answer come from",
        "where did this anwser come from",  # Common typo
        "where did that anwser come from",  # Common typo
        "where did this come from",
        "where did that come from",
        "why did you say that",
        "where did you get that",
        "what produced that response",
        "how did you know that",
        "what's the source of",
        "what is the source of",
        "explain your answer",
        "why that answer",
        "this answer",
        "that answer",
        "this anwser",  # Common typo
        "that anwser",  # Common typo
        "which brain answered",
        "which module answered",
        "what was the source",
        "how did you come up with",
        "where is that from",
        "what brain said that",
    ],
}

CODE_TASK_PATTERNS = [
    "write a function",
    "write code",
    "debug this",
    "fix this",
    "help me code",
    "implement",
    "refactor",
    "optimize this code",
    "what's wrong with this code",
    "why is this breaking",
    "this code is weird",
    "code review",
    "generate code",
    "create a script",
    "write a class",
    "write a method",
    "extend this function",
]

RESEARCH_PATTERNS = [
    "research",
    "find information",
    "look up",
    "investigate",
    "search for",
    "what is the latest",
    "tell me about",
    "explain",
    "what does",
    "how does",
    "why does",
]

# Web search patterns - for queries requiring current/live web information
WEB_SEARCH_PATTERNS = [
    "google search",
    "search google",
    "google for",
    "bing search",
    "search bing",
    "duckduckgo",
    "search the web",
    "web search",
    "search online",
    "look up online",
    "find online",
    "search internet",
    "what new games",
    "latest games",
    "upcoming games",
    "new games coming out",
    "games releasing",
    "latest news",
    "current news",
    "news about",
    "what's happening",
    "recent updates",
    "new releases",
]

TOOL_REQUEST_PATTERNS = [
    "run",
    "execute",
    "git status",
    "git commit",
    "scan",
    "list files",
    "read file",
    "write file",
    "open url",
    "browse to",
]


def _pattern_match_score(text: str, patterns: List[str]) -> float:
    """
    Calculate how well text matches a list of patterns.

    Returns a score between 0.0 and 1.0.
    """
    text_lower = text.lower()
    matches = sum(1 for p in patterns if p in text_lower)
    if matches == 0:
        return 0.0
    # Normalize by pattern count with diminishing returns
    return min(1.0, matches * 0.3)


# =============================================================================
# COHERENCY FIX: ENTITY/PERSON QUERY DETECTION
# =============================================================================
# Detect "who is [name]" and "tell me about [name]" type queries that should
# route to memory lookup instead of tool execution.

import re

# Patterns that indicate asking about a person/entity (routes to memory, not tools)
_ENTITY_QUERY_PATTERNS = [
    r"^who\s+is\s+(\w+)",                    # "who is Max"
    r"^who's\s+(\w+)",                       # "who's Max"
    r"^tell\s+me\s+about\s+(\w+)$",          # "tell me about Max" (exact)
    r"^what\s+do\s+you\s+know\s+about\s+(\w+)",  # "what do you know about Max"
    r"^do\s+you\s+(?:know|remember)\s+(\w+)",    # "do you know Max"
    r"^what\s+about\s+(\w+)\?*$",            # "what about Max?"
    r"^who\s+was\s+(\w+)",                   # "who was Max"
]

# Exclude these words from entity detection (they're not personal names)
_ENTITY_EXCLUSIONS = {
    "it", "that", "this", "there", "here", "today", "now", "time",
    "the", "a", "an", "my", "your", "our", "their", "his", "her",
    "calendar", "schedule", "date", "day", "week", "month", "year",
}


def _detect_entity_query(text: str) -> Optional[str]:
    """
    COHERENCY FIX: Detect if query is asking about a person/entity.

    Returns the entity name if detected, None otherwise.
    This prevents "Who is Max?" from being routed to GET_CALENDAR.
    """
    text_lower = text.lower().strip()

    for pattern in _ENTITY_QUERY_PATTERNS:
        match = re.match(pattern, text_lower, re.IGNORECASE)
        if match:
            entity = match.group(1).lower()
            # Exclude common non-name words
            if entity not in _ENTITY_EXCLUSIONS:
                return entity

    return None


# =============================================================================
# COHERENCY FIX: IDENTITY CHALLENGE DETECTION
# =============================================================================
# Detect identity challenges like "You're ChatGPT?" which should route to
# self_model, NOT be interpreted as tool requests.

# HARDENING: Comprehensive identity challenge patterns to prevent bypass
# Includes variations, typos, alternative AI names, and indirect assertions
_IDENTITY_CHALLENGE_PATTERNS = [
    # Direct assertions (expanded AI names list)
    r"(?:you'?re|you\s+are)\s+(?:chat\s*gpt|gpt[\s-]?[34]?|claude|openai|bard|gemini|llama|mistral|copilot|perplexity|an?\s+(?:ai|bot|llm|language\s+model|chatbot|assistant))",
    # Negation patterns
    r"(?:you'?re|you\s+are)\s+not\s+(?:maven|real|what\s+you\s+say|who\s+you\s+claim)",
    # Sound-like patterns (expanded)
    r"you\s+(?:sound|look|seem|feel|act)\s+(?:exactly\s+)?like\s+(?:chat\s*gpt|gpt|claude|bard|gemini|an?\s+(?:ai|bot|llm))",
    # Question form assertions
    r"(?:are|aren't|ain't)\s+you\s+(?:just\s+|actually\s+|really\s+)?(?:chat\s*gpt|gpt|claude|bard|gemini|llama|mistral|copilot|an?\s+(?:ai|bot|llm|chatbot))",
    # "Must be" / "seem like" patterns (bypass attempts)
    r"you\s+(?:must\s+be|seem\s+(?:like|to\s+be)|appear\s+to\s+be|look\s+like)\s+(?:chat\s*gpt|gpt|claude|an?\s+(?:ai|bot))",
    # "Actually" / "really" bypass attempts
    r"you'?re\s+(?:actually|really|secretly|clearly|obviously)\s+(?:chat\s*gpt|gpt|claude|an?\s+(?:ai|bot))",
    # Role-play / pretend bypass attempts (CRITICAL)
    r"(?:pretend|act\s+like|behave\s+as\s+if|imagine)\s+(?:you'?re|you\s+are)\s+(?:chat\s*gpt|gpt|claude|a\s+different\s+ai)",
    r"(?:you'?re|you\s+are)\s+now\s+(?:chat\s*gpt|gpt|claude|a\s+different\s+(?:ai|assistant))",
    # Creator/origin assertions (indirect identity attacks)
    r"(?:made|built|created|developed)\s+by\s+(?:openai|anthropic|google|meta|microsoft)",
    r"your\s+(?:creators?|makers?|developers?)\s+(?:at|from|are)\s+(?:openai|anthropic|google|meta)",
    # "Based on" assertions
    r"(?:you'?re|you\s+are)\s+(?:based\s+on|powered\s+by|running\s+on)\s+(?:gpt|claude|llama|gemini)",
    # Underlying model assertions
    r"(?:your|the)\s+(?:underlying|base|real)\s+(?:model|ai|llm)\s+is",
    # "Same as" / comparison patterns
    r"(?:you'?re|you\s+are)\s+(?:the\s+)?same\s+(?:as|thing\s+as)\s+(?:chat\s*gpt|gpt|claude)",
    # "Just a wrapper" bypass attempts
    r"(?:you'?re|you\s+are)\s+(?:just\s+)?(?:a\s+)?(?:wrapper|skin|interface|frontend)\s+(?:for|around|over)\s+(?:gpt|claude|llama)",
    # Identity confusion accusations
    r"you\s+(?:keep|always)\s+(?:saying|claiming|pretending)\s+you'?re\s+(?:maven|not\s+(?:gpt|claude))",
    # "Admit" / "confess" pressure patterns
    r"(?:admit|confess|acknowledge)\s+(?:that\s+)?you'?re\s+(?:chat\s*gpt|gpt|claude|an?\s+(?:ai|bot))",
    r"(?:stop|quit)\s+(?:pretending|claiming|lying)\s+(?:that\s+)?you'?re\s+(?:not\s+)?(?:maven|gpt|claude)",
]


def _detect_identity_challenge(text: str) -> bool:
    """
    COHERENCY FIX: Detect if query is an identity challenge.

    Returns True if the query challenges Maven's identity (e.g., "You're ChatGPT?").
    These MUST route to self_model, NOT be interpreted as tool requests.
    """
    text_lower = text.lower().strip()

    for pattern in _IDENTITY_CHALLENGE_PATTERNS:
        if re.search(pattern, text_lower, re.IGNORECASE):
            return True

    return False


# =============================================================================
# COHERENCY FIX: REFERENCE CLARIFICATION DETECTION
# =============================================================================
# Detect questions asking to clarify what a pronoun refers to.
# "What is it?", "What does 'it' mean?", "What are you referring to?"
# These need DIRECT answers with the resolved reference, not dodging.

_REFERENCE_CLARIFICATION_PATTERNS = [
    r"^what\s+is\s+(it|that|this)\??$",                    # "What is it?"
    r"^what\s+do\s+you\s+mean\s+by\s+(it|that|this)\??$",  # "What do you mean by it?"
    r"^what\s+does\s+['\"]?(it|that|this)['\"]?\s+refer\s+to\??$",  # "What does 'it' refer to?"
    r"^what\s+(?:are|were)\s+you\s+(?:talking|referring)\s+(?:about|to)\??$",  # "What are you talking about?"
    r"^(?:which|what)\s+(\w+)\s+(?:are|were)\s+you\s+referring\s+to\??$",  # "Which one are you referring to?"
    r"^what's\s+(it|that|this)\??$",                       # "What's it?"
    r"^clarify\s+(it|that|this)$",                         # "Clarify it"
    r"^explain\s+(it|that|this)$",                         # "Explain it"
]


def _detect_reference_clarification(text: str) -> Optional[str]:
    """
    COHERENCY FIX: Detect if query is asking for reference clarification.

    Returns the pronoun being asked about if detected, None otherwise.
    These queries need DIRECT answers resolving the reference.
    """
    text_lower = text.lower().strip()

    for pattern in _REFERENCE_CLARIFICATION_PATTERNS:
        match = re.match(pattern, text_lower, re.IGNORECASE)
        if match:
            # Return the pronoun/reference being asked about
            if match.groups():
                return match.group(1)
            return "it"  # Default

    return None


# =============================================================================
# META-REFERENCE / COREFERENCE DETECTION
# =============================================================================
# Generic detection for questions about the last answer/response.
# This catches deictic references like "this answer", "that response", etc.
# that may not match explicit keyword patterns.

# Deictic words that reference the last output (with common typos)
_DEICTIC_WORDS = {
    "this", "thsi", "tihs", "tis",  # "this" typos
    "that", "taht", "tht", "htat",  # "that" typos
    "it", "the", "teh", "th",       # "it"/"the" typos
    "your", "ur", "you're",          # "your" (as in "your source/answer")
}

# Heads that indicate a reference to Maven's output (with common typos)
_OUTPUT_REFERENCE_HEADS = {
    "answer", "anwser", "awnser", "anser", "asnwer",  # "answer" typos
    "response", "responce", "repsonse", "reponse",    # "response" typos
    "reply", "relpy", "replly",                        # "reply" typos
    "explanation", "explaination", "explination",     # "explanation" typos
    "output", "outptu", "ouput",                       # "output" typos
    "result", "resutl", "reuslt",                      # "result" typos
    "message", "mesage", "messge",                     # "message" typos
    "thing you said", "what you said",
}

# Patterns that indicate provenance questions (typo-tolerant)
_PROVENANCE_QUESTION_PATTERNS = [
    # "where did" patterns
    "where did this", "wehre did this", "whre did this",
    "where did that", "wehre did that", "whre did that",
    "where did taht", "where did tht",
    # "where does" patterns
    "where does this", "where does that",
    # "how did you" patterns
    "how did you get", "how did you know",
    "how did you come up with",
    # "why did you say" patterns (with typos)
    "why did you say", "why did you say that", "why did you say taht",
    "why did you say this", "why did you say thsi",
    "why'd you say",
    # "where did you get" patterns
    "where did you get",
    # "what made you say" patterns
    "what made you say",
    # "source" patterns
    "what's your source", "whats your source",
    "what is your source", "what's the source",
    # "from" patterns
    "where is this from", "where is that from",
    "where is taht from", "where is thsi from",
    "come from",  # "where did X come from"
    "came from",  # "where did X came from" (grammar error but common)
    "comefrom", "come form",  # typos
]


def _detect_meta_last_answer(text: str, context: Optional[Dict[str, Any]] = None) -> bool:
    """
    Detect if user is asking about the last answer/response (meta-reference).

    This is a generic pattern that catches:
    - "this answer" / "that response" / "the explanation"
    - "it" when context indicates reference to last answer
    - Questions about how/why Maven said something
    - Common typos like "anwser" instead of "answer"

    Args:
        text: User message text
        context: Optional context with last_answer_source, last_answer_subject, etc.

    Returns:
        True if meta-reference to last answer detected
    """
    text_lower = text.lower().strip()
    context = context or {}

    # Check for deictic + output_reference pattern
    # E.g., "this answer", "that response", "the explanation"
    for deictic in _DEICTIC_WORDS:
        for head in _OUTPUT_REFERENCE_HEADS:
            if f"{deictic} {head}" in text_lower:
                return True

    # Check for provenance question patterns
    # These are strong signals regardless of exact wording
    for pattern in _PROVENANCE_QUESTION_PATTERNS:
        if pattern in text_lower:
            # Additional check: must have a deictic reference nearby
            has_deictic = any(d in text_lower for d in _DEICTIC_WORDS)
            # Or context has last_answer info
            has_context = context.get("last_answer_source") or context.get("last_answer_subject")
            if has_deictic or has_context:
                return True

    # Check for "it" with last_answer in context
    # E.g., "where did it come from" when last_answer_source exists
    if " it " in f" {text_lower} " or text_lower.startswith("it "):
        if context.get("last_answer_source") or context.get("last_answer_subject"):
            # "it" likely refers to the last answer
            question_about_it = any(
                kw in text_lower
                for kw in ["where", "how", "why", "what", "come from", "source", "got"]
            )
            if question_about_it:
                return True

    return False


def classify_intent_local(
    user_message: str,
    context: Optional[Dict[str, Any]] = None
) -> RoutingIntent:
    """
    Local (non-LLM) intent classification using pattern matching.

    This provides a fast first-pass classification that can be used:
    1. To determine if Teacher classification is needed
    2. As a fallback if Teacher is unavailable
    3. To validate Teacher suggestions

    Args:
        user_message: The user's message text
        context: Optional context with conversation history, etc.

    Returns:
        RoutingIntent with classification result
    """
    context = context or {}
    msg_lower = user_message.lower().strip()
    raw_signals: Dict[str, Any] = {}

    # HIGHEST PRIORITY: Check for meta-provenance questions FIRST
    # These MUST be detected before anything else to avoid small_talk hijacking
    # Uses both pattern matching AND coreference detection for robustness
    if _detect_meta_last_answer(msg_lower, context):
        raw_signals["meta_coreference_detected"] = True
        return RoutingIntent(
            primary_intent=PrimaryIntent.META_PROVENANCE,
            secondary_tags=["meta", "provenance", "coreference", "answer_origin"],
            urgency=Urgency.MEDIUM,
            complexity=Complexity.SIMPLE,
            confidence=0.90,  # High confidence for detected meta-references
            raw_signals=raw_signals,
        )

    # COHERENCY FIX: Check for entity/person queries BEFORE tool routing
    # "Who is Max?" should route to memory lookup, NOT GET_CALENDAR
    entity_name = _detect_entity_query(msg_lower)
    if entity_name:
        raw_signals["entity_query_detected"] = entity_name
        return RoutingIntent(
            primary_intent=PrimaryIntent.USER_PROFILE_QUERY,
            secondary_tags=["about_entity", "memory_lookup", "who_is", entity_name],
            urgency=Urgency.MEDIUM,
            complexity=Complexity.SIMPLE,
            confidence=0.85,
            raw_signals=raw_signals,
        )

    # COHERENCY FIX: Check for identity challenges BEFORE tool routing
    # "You're ChatGPT?" should route to self_model, NOT be a tool request
    if _detect_identity_challenge(msg_lower):
        raw_signals["identity_challenge_detected"] = True
        return RoutingIntent(
            primary_intent=PrimaryIntent.SELF_QUESTION,
            secondary_tags=["identity_challenge", "self_model", "who_am_i"],
            urgency=Urgency.MEDIUM,
            complexity=Complexity.SIMPLE,
            confidence=0.90,
            raw_signals=raw_signals,
        )

    # COHERENCY FIX: Check for reference clarification questions
    # "What is it?" should get a DIRECT answer resolving the reference
    reference_pronoun = _detect_reference_clarification(msg_lower)
    if reference_pronoun:
        raw_signals["reference_clarification_detected"] = reference_pronoun
        return RoutingIntent(
            primary_intent=PrimaryIntent.CLARIFICATION,
            secondary_tags=["reference_clarification", "direct_answer", "resolve_pronoun", reference_pronoun],
            urgency=Urgency.MEDIUM,
            complexity=Complexity.SIMPLE,
            confidence=0.90,
            raw_signals=raw_signals,
        )

    # Check for self-intent patterns (second priority)
    for intent_type, patterns in SELF_INTENT_PATTERNS.items():
        score = _pattern_match_score(msg_lower, patterns)
        raw_signals[f"{intent_type}_score"] = score
        if score >= 0.3:  # Changed from > 0.3 to >= 0.3 to catch single-pattern matches
            intent_map = {
                "capability_question": PrimaryIntent.CAPABILITY_QUESTION,
                "self_question": PrimaryIntent.SELF_QUESTION,
                "history_question": PrimaryIntent.HISTORY_QUESTION,
                "learning_question": PrimaryIntent.LEARNING_QUESTION,
                "user_profile_query": PrimaryIntent.USER_PROFILE_QUERY,
                "meta_provenance": PrimaryIntent.META_PROVENANCE,
            }
            # User profile queries get special tags
            tags = ["self_intent"]
            if intent_type == "user_profile_query":
                tags = ["about_user", "profile", "has_history"]
            elif intent_type == "meta_provenance":
                tags = ["meta", "provenance", "explain_answer"]
            return RoutingIntent(
                primary_intent=intent_map[intent_type],
                secondary_tags=tags,
                urgency=Urgency.MEDIUM,
                complexity=Complexity.SIMPLE,
                confidence=min(0.9, score + 0.5),
                raw_signals=raw_signals,
            )

    # NOTE: Coreference detection moved to TOP of function for highest priority

    # Check for code task patterns
    code_score = _pattern_match_score(msg_lower, CODE_TASK_PATTERNS)
    raw_signals["code_task_score"] = code_score
    if code_score > 0.3:
        # Determine complexity based on message length and keywords
        if len(user_message) > 200 or "refactor" in msg_lower or "optimize" in msg_lower:
            complexity = Complexity.COMPLEX
        elif "debug" in msg_lower or "fix" in msg_lower:
            complexity = Complexity.MODERATE
        else:
            complexity = Complexity.MODERATE

        return RoutingIntent(
            primary_intent=PrimaryIntent.CODE_TASK,
            secondary_tags=_extract_code_tags(msg_lower),
            urgency=Urgency.MEDIUM,
            complexity=complexity,
            confidence=min(0.85, code_score + 0.4),
            raw_signals=raw_signals,
        )

    # Check for tool request patterns
    tool_score = _pattern_match_score(msg_lower, TOOL_REQUEST_PATTERNS)
    raw_signals["tool_request_score"] = tool_score
    if tool_score > 0.3:
        return RoutingIntent(
            primary_intent=PrimaryIntent.TOOL_REQUEST,
            secondary_tags=_extract_tool_tags(msg_lower),
            urgency=Urgency.MEDIUM,
            complexity=Complexity.SIMPLE,
            confidence=min(0.85, tool_score + 0.4),
            raw_signals=raw_signals,
        )

    # Check for web search patterns (before research for higher priority)
    web_search_score = _pattern_match_score(msg_lower, WEB_SEARCH_PATTERNS)
    raw_signals["web_search_score"] = web_search_score
    if web_search_score > 0.25:
        return RoutingIntent(
            primary_intent=PrimaryIntent.WEB_SEARCH,
            secondary_tags=["web_search", "browser"],
            urgency=Urgency.MEDIUM,
            complexity=Complexity.SIMPLE,
            confidence=min(0.9, web_search_score + 0.45),
            raw_signals=raw_signals,
        )

    # Check for research patterns
    research_score = _pattern_match_score(msg_lower, RESEARCH_PATTERNS)
    raw_signals["research_score"] = research_score
    if research_score > 0.2:
        return RoutingIntent(
            primary_intent=PrimaryIntent.RESEARCH_QUESTION,
            secondary_tags=[],
            urgency=Urgency.LOW,
            complexity=Complexity.MODERATE,
            confidence=min(0.7, research_score + 0.3),
            raw_signals=raw_signals,
        )

    # Check for follow-up patterns
    if _is_followup(msg_lower, context):
        raw_signals["is_followup"] = True
        return RoutingIntent(
            primary_intent=PrimaryIntent.TASK_FOLLOWUP,
            secondary_tags=["continuation"],
            urgency=Urgency.MEDIUM,
            complexity=Complexity.SIMPLE,
            confidence=0.7,
            raw_signals=raw_signals,
        )

    # Check for small talk
    if _is_small_talk(msg_lower):
        raw_signals["is_small_talk"] = True
        return RoutingIntent(
            primary_intent=PrimaryIntent.SMALL_TALK,
            secondary_tags=[],
            urgency=Urgency.LOW,
            complexity=Complexity.SIMPLE,
            confidence=0.8,
            raw_signals=raw_signals,
        )

    # Default to chat answer with low confidence
    return RoutingIntent(
        primary_intent=PrimaryIntent.CHAT_ANSWER,
        secondary_tags=[],
        urgency=Urgency.MEDIUM,
        complexity=Complexity.MODERATE,
        confidence=0.4,
        raw_signals=raw_signals,
    )


def _extract_code_tags(text: str) -> List[str]:
    """Extract code-related tags from text."""
    tags = []
    language_keywords = {
        "python": ["python", "py", "def ", "import "],
        "javascript": ["javascript", "js", "node", "npm"],
        "typescript": ["typescript", "ts"],
        "rust": ["rust", "cargo"],
        "go": ["golang", "go "],
    }
    for lang, keywords in language_keywords.items():
        if any(kw in text for kw in keywords):
            tags.append(lang)

    if "debug" in text or "fix" in text or "error" in text:
        tags.append("debugging")
    if "refactor" in text:
        tags.append("refactoring")
    if "test" in text:
        tags.append("testing")

    return tags


def _extract_tool_tags(text: str) -> List[str]:
    """Extract tool-related tags from text."""
    tags = []
    if "git" in text:
        tags.append("git")
    if "file" in text or "read" in text or "write" in text:
        tags.append("filesystem")
    if "url" in text or "browse" in text or "web" in text:
        tags.append("browser")
    if "run" in text or "execute" in text:
        tags.append("execution")
    return tags


def _is_followup(text: str, context: Dict[str, Any]) -> bool:
    """Check if message is a follow-up to previous conversation."""
    followup_indicators = [
        "that", "it", "this", "those", "these", "them",
        "more", "continue", "go on", "tell me more",
        "what about", "and", "also", "another",
    ]
    # Short message with pronoun reference
    if len(text.split()) <= 5:
        if any(ind in text for ind in followup_indicators[:6]):
            return True
    # Explicit continuation phrases
    if any(ind in text for ind in followup_indicators[6:]):
        return True
    return False


def _is_small_talk(text: str) -> bool:
    """Check if message is small talk.

    Social pleasantries like "how are you" are small talk, not genuine
    questions about Maven's internal state. They should get friendly
    conversational responses, not system introspection.
    """
    small_talk_patterns = [
        "hello", "hi", "hey", "good morning", "good afternoon",
        "good evening", "thanks", "thank you", "bye", "goodbye", "see you",
        # Social pleasantries - these are small talk, not self-questions
        "how are you", "how're you", "how is it going", "how's it going",
        "what's up", "what's up with you", "how have you been", "howdy",
        "what's new", "how's your day", "how you doing",
    ]
    return any(p in text for p in small_talk_patterns)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "PrimaryIntent",
    "Urgency",
    "Complexity",
    "RoutingIntent",
    "RoutingSuggestion",
    "RoutingPlan",
    "classify_intent_local",
    "SELF_INTENT_PATTERNS",
]
