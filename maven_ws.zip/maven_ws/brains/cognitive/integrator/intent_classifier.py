"""
Intent Classifier
=================

Hard classification of user messages into ACTION_REQUEST vs EXPLANATION/CHAT.

This classifier runs BEFORE routing and establishes a hard invariant:
- ACTION_REQUEST messages with matched agency tools MUST execute the tool
- They CANNOT be hijacked by Teacher/reasoning to produce explanations

The key insight: "maven have a convo with grok about medicine" is an ACTION,
not a question about what Maven and Grok are.
"""

from __future__ import annotations
import re
from enum import Enum
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass


class IntentType(Enum):
    """Primary intent classification."""
    ACTION_REQUEST = "action_request"      # User wants Maven to DO something
    QUESTION = "question"                  # User wants information/explanation
    SMALL_TALK = "small_talk"              # Greetings, thanks, etc.
    CLARIFICATION = "clarification"        # Follow-up to previous turn
    FEEDBACK = "feedback"                  # User giving feedback on Maven's response


@dataclass
class IntentClassification:
    """Result of intent classification."""
    intent_type: IntentType
    confidence: float
    matched_verbs: List[str]
    matched_objects: List[str]
    reasoning: str
    # If ACTION_REQUEST, which capability was matched
    matched_capability: Optional[str] = None
    capability_args: Optional[Dict[str, Any]] = None


# ============================================================================
# Capabilities Map - What Maven CAN DO
# ============================================================================
# This is an explicit, stable map of Maven's action capabilities.
# Each capability defines:
#   - verbs: words that trigger this capability
#   - objects: targets/recipients of the action
#   - description: what this capability does
#   - tool: the agency tool to execute
#   - arg_extractor: how to extract args from the query

CAPABILITIES_MAP: Dict[str, Dict[str, Any]] = {
    # -------------------------------------------------------------------------
    # GROK CONVERSATION SESSION
    # -------------------------------------------------------------------------
    "grok_conversation": {
        "type": "AGENCY",
        "verbs": [
            "have a convo", "have a conversation", "convo", "conversation",
            "talk to", "chat with", "discuss with", "session",
            "have grok discuss", "have grok explore",
        ],
        "objects": ["grok", "x ai", "x's ai"],
        "description": "Conduct a model-to-model conversation with Grok on a topic for a duration",
        "tool": "brains.tools.grok_conversation_session.get_grok_conversation_controller",
        "method": "parse_and_run",
        "priority": 100,  # High priority - explicit user command
    },

    # -------------------------------------------------------------------------
    # SHELL / COMMAND EXECUTION
    # -------------------------------------------------------------------------
    "shell_command": {
        "type": "AGENCY",
        "verbs": [
            "run", "execute", "exec", "shell",
            "git", "npm", "pip", "python", "ls", "cd", "mkdir",
        ],
        "objects": [],  # Shell commands can have any object
        "description": "Execute shell commands",
        "tool": "shell_tool",
        "method": None,
        "priority": 90,
    },

    # -------------------------------------------------------------------------
    # BROWSER OPERATIONS
    # -------------------------------------------------------------------------
    "browser_open": {
        "type": "AGENCY",
        "verbs": ["open", "browse", "go to", "visit", "navigate to"],
        "objects": ["http://", "https://", "website", "page", "url"],
        "description": "Open a URL in the browser",
        "tool": "browser_runtime",
        "method": "OPEN_URL",
        "priority": 85,
    },

    "browser_action": {
        "type": "AGENCY",
        "verbs": ["click", "tap", "press", "scroll", "type", "pick", "choose", "select", "play"],
        "objects": ["button", "link", "video", "element", "it", "that", "this"],
        "description": "Interact with elements on the current browser page",
        "tool": "browser_action",
        "method": None,
        "priority": 85,
    },

    # -------------------------------------------------------------------------
    # CHATGPT CONVERSATION SESSION
    # -------------------------------------------------------------------------
    "chatgpt_conversation": {
        "type": "AGENCY",
        "verbs": [
            "have a convo", "have a conversation", "convo", "conversation",
            "talk to", "chat with", "discuss with", "session",
            "have chatgpt discuss", "have chatgpt explore",
        ],
        "objects": ["chatgpt", "gpt", "openai"],
        "description": "Conduct a model-to-model conversation with ChatGPT on a topic for a duration",
        "tool": "brains.tools.chatgpt_conversation_session.get_chatgpt_conversation_controller",
        "method": "parse_and_run",
        "priority": 100,  # High priority - explicit user command
    },

    # -------------------------------------------------------------------------
    # CLAUDE CONVERSATION SESSION
    # -------------------------------------------------------------------------
    "claude_conversation": {
        "type": "AGENCY",
        "verbs": [
            "have a convo", "have a conversation", "convo", "conversation",
            "talk to", "chat with", "discuss with", "session",
            "have claude discuss", "have claude explore",
        ],
        "objects": ["claude", "anthropic"],
        "description": "Conduct a model-to-model conversation with Claude on a topic for a duration",
        "tool": "brains.tools.claude_conversation_session.get_claude_conversation_controller",
        "method": "parse_and_run",
        "priority": 100,  # High priority - explicit user command
    },

    # -------------------------------------------------------------------------
    # X/TWITTER OPERATIONS
    # -------------------------------------------------------------------------
    "x_post": {
        "type": "AGENCY",
        "verbs": ["post", "tweet", "send", "publish"],
        "objects": ["x", "twitter", "x.com"],
        "description": "Post to X/Twitter",
        "tool": "x",
        "method": "post",
        "priority": 80,
    },

    # -------------------------------------------------------------------------
    # HUMAN/PC CONTROL
    # -------------------------------------------------------------------------
    "human_control": {
        "type": "AGENCY",
        "verbs": ["control", "use", "operate", "move", "click", "type"],
        "objects": ["desktop", "screen", "mouse", "keyboard", "human"],
        "description": "Control the desktop via mouse/keyboard",
        "tool": "human",
        "method": None,
        "priority": 75,
    },

    "pc_control": {
        "type": "AGENCY",
        "verbs": ["control", "manage", "configure", "set", "change"],
        "objects": ["pc", "computer", "system", "volume", "brightness"],
        "description": "Control PC system settings",
        "tool": "pc",
        "method": None,
        "priority": 75,
    },

    # -------------------------------------------------------------------------
    # FILE OPERATIONS
    # -------------------------------------------------------------------------
    "file_read": {
        "type": "AGENCY",
        "verbs": ["read", "show", "display", "cat", "view"],
        "objects": ["file", "contents", ".txt", ".py", ".md", ".json"],
        "description": "Read file contents",
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "read_file",
        "priority": 70,
    },

    "file_write": {
        "type": "AGENCY",
        "verbs": ["write", "create", "save", "make"],
        "objects": ["file", "document"],
        "description": "Write to a file",
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "write_file",
        "priority": 70,
    },

    "file_list": {
        "type": "AGENCY",
        "verbs": ["list", "show", "display", "ls"],
        "objects": ["files", "directory", "folder", "contents"],
        "description": "List files in a directory",
        "tool": "brains.tools.filesystem_agency.get_filesystem_agency",
        "method": "list_directory",
        "priority": 70,
    },

    # -------------------------------------------------------------------------
    # GIT OPERATIONS
    # -------------------------------------------------------------------------
    "git_status": {
        "type": "AGENCY",
        "verbs": ["git status", "check status", "show status"],
        "objects": ["repo", "repository", "git"],
        "description": "Check git repository status",
        "tool": "brains.tools.git_tool",
        "method": "git_status",
        "priority": 80,
    },

    "git_commit": {
        "type": "AGENCY",
        "verbs": ["commit", "git commit"],
        "objects": ["changes", "files"],
        "description": "Commit changes to git",
        "tool": "brains.tools.git_tool",
        "method": "git_commit",
        "priority": 80,
    },

    "git_push": {
        "type": "AGENCY",
        "verbs": ["push", "git push"],
        "objects": ["changes", "commits", "branch"],
        "description": "Push commits to remote",
        "tool": "brains.tools.git_tool",
        "method": "git_push",
        "priority": 80,
    },

    # -------------------------------------------------------------------------
    # SELF-INTROSPECTION
    # -------------------------------------------------------------------------
    "self_scan": {
        "type": "AGENCY",
        "verbs": ["scan", "analyze", "introspect", "examine"],
        "objects": ["codebase", "yourself", "your code", "maven"],
        "description": "Scan Maven's own codebase",
        "tool": "brains.tools.self_introspection.get_self_introspection",
        "method": "generate_self_knowledge_report",
        "priority": 70,
    },

    # -------------------------------------------------------------------------
    # HOT RELOAD
    # -------------------------------------------------------------------------
    "hot_reload": {
        "type": "AGENCY",
        "verbs": ["reload", "refresh", "update"],
        "objects": ["module", "code", "yourself", "maven"],
        "description": "Hot reload Maven modules",
        "tool": "brains.tools.hot_reload",
        "method": "reload_modules",
        "priority": 70,
    },

    # -------------------------------------------------------------------------
    # TIME QUERIES (special - needs real system time, not LLM guessing)
    # -------------------------------------------------------------------------
    "time_query": {
        "type": "AGENCY",
        "verbs": ["what time", "what's the time", "tell me the time", "what date", "what day"],
        "objects": ["time", "date", "day", "clock"],
        "description": "Get current system time (NOT from LLM memory)",
        "tool": "time_now",
        "method": "GET_TIME",
        "priority": 95,  # High - never let LLM guess time
    },
}


# ============================================================================
# Action Verb Patterns
# ============================================================================
# These patterns indicate the user wants Maven to DO something, not explain

ACTION_VERB_PATTERNS = [
    # Imperative forms
    r"^(please\s+)?(maven\s+)?have\s+",
    r"^(please\s+)?(maven\s+)?talk\s+to\s+",
    r"^(please\s+)?(maven\s+)?chat\s+with\s+",
    r"^(please\s+)?(maven\s+)?run\s+",
    r"^(please\s+)?(maven\s+)?execute\s+",
    r"^(please\s+)?(maven\s+)?open\s+",
    r"^(please\s+)?(maven\s+)?go\s+to\s+",
    r"^(please\s+)?(maven\s+)?click\s+",
    r"^(please\s+)?(maven\s+)?scroll\s+",
    r"^(please\s+)?(maven\s+)?type\s+",
    r"^(please\s+)?(maven\s+)?post\s+",
    r"^(please\s+)?(maven\s+)?send\s+",
    r"^(please\s+)?(maven\s+)?create\s+",
    r"^(please\s+)?(maven\s+)?write\s+",
    r"^(please\s+)?(maven\s+)?delete\s+",
    r"^(please\s+)?(maven\s+)?git\s+",
    r"^(please\s+)?(maven\s+)?commit\s+",
    r"^(please\s+)?(maven\s+)?push\s+",
    r"^(please\s+)?(maven\s+)?pull\s+",
    r"^(please\s+)?(maven\s+)?scan\s+",
    r"^(please\s+)?(maven\s+)?reload\s+",
    r"^(please\s+)?(maven\s+)?start\s+",
    r"^(please\s+)?(maven\s+)?stop\s+",
    r"^(please\s+)?(maven\s+)?control\s+",

    # "Do X" patterns
    r"^(please\s+)?(can\s+you\s+)?do\s+",
    r"^(please\s+)?(can\s+you\s+)?make\s+",

    # Tool-specific patterns that are always actions
    r"\bwith\s+grok\b",
    r"\bto\s+grok\b",
    r"\bwith\s+chatgpt\b",
    r"\bto\s+chatgpt\b",
    r"\bwith\s+gpt\b",
    r"\bto\s+gpt\b",
    r"\bwith\s+claude\b",
    r"\bto\s+claude\b",
    r"\bwith\s+anthropic\b",
    r"\bto\s+anthropic\b",
    r"\busing\s+(the\s+)?browser\b",
    r"\busing\s+(the\s+)?shell\b",
    r"\bfor\s+\d+\s*(minutes?|mins?|hours?|seconds?)\b",  # Duration implies action
]

# Question patterns - these are EXPLANATION requests, not actions
QUESTION_PATTERNS = [
    r"^what\s+is\s+",
    r"^what\s+are\s+",
    r"^who\s+is\s+",
    r"^who\s+are\s+",
    r"^how\s+does\s+",
    r"^how\s+do\s+",
    r"^why\s+is\s+",
    r"^why\s+are\s+",
    r"^why\s+does\s+",
    r"^why\s+do\s+",
    r"^can\s+you\s+explain\s+",
    r"^explain\s+",
    r"^tell\s+me\s+about\s+",
    r"^describe\s+",
    r"^define\s+",
    r"\?$",  # Ends with question mark
]

# Small talk patterns
SMALL_TALK_PATTERNS = [
    r"^(hi|hello|hey|good\s+(morning|afternoon|evening))(\s|!|$)",
    r"^(thanks|thank\s+you|thx)(\s|!|$)",
    r"^(bye|goodbye|see\s+you)(\s|!|$)",
    r"^(ok|okay|sure|alright)(\s|!|$)",
    r"^(yes|no|yep|nope|yeah|nah)(\s|!|$)",
]


# ============================================================================
# Main Classifier
# ============================================================================

def classify_intent(query: str, context: Optional[Dict[str, Any]] = None) -> IntentClassification:
    """
    Classify user intent as ACTION_REQUEST vs QUESTION/EXPLANATION.

    This is the FIRST classification that runs, before any routing.
    It establishes whether the user wants Maven to DO something or EXPLAIN something.

    Args:
        query: The user's input text
        context: Optional conversation context

    Returns:
        IntentClassification with type, confidence, and matched capability
    """
    query_lower = query.lower().strip()
    matched_verbs = []
    matched_objects = []

    # -------------------------------------------------------------------------
    # Step 1: Check for explicit action patterns
    # -------------------------------------------------------------------------
    action_score = 0.0

    for pattern in ACTION_VERB_PATTERNS:
        if re.search(pattern, query_lower, re.IGNORECASE):
            action_score += 0.3
            matched_verbs.append(pattern)

    # -------------------------------------------------------------------------
    # Step 2: Check against capabilities map
    # -------------------------------------------------------------------------
    best_capability = None
    best_capability_score = 0.0

    for cap_name, cap_info in CAPABILITIES_MAP.items():
        cap_score = 0.0

        # Check verbs
        for verb in cap_info.get("verbs", []):
            if verb.lower() in query_lower:
                cap_score += 0.4
                matched_verbs.append(verb)

        # Check objects
        for obj in cap_info.get("objects", []):
            if obj.lower() in query_lower:
                cap_score += 0.3
                matched_objects.append(obj)

        # Boost for priority
        priority = cap_info.get("priority", 50) / 100.0
        cap_score *= (0.5 + priority * 0.5)

        if cap_score > best_capability_score:
            best_capability_score = cap_score
            best_capability = cap_name

    # If we matched a capability strongly, it's definitely an action
    if best_capability_score > 0.5:
        action_score = max(action_score, best_capability_score)

    # -------------------------------------------------------------------------
    # Step 3: Check for question patterns (which REDUCE action score)
    # -------------------------------------------------------------------------
    question_score = 0.0

    for pattern in QUESTION_PATTERNS:
        if re.search(pattern, query_lower, re.IGNORECASE):
            question_score += 0.25

    # Important: A question about HOW to do something is NOT an action request
    # e.g., "how do I talk to grok?" is a question, not "talk to grok"
    if question_score > 0 and best_capability:
        # If it looks like a question about the capability, not a command to use it
        if any(re.search(p, query_lower) for p in [r"^how\s+(do|can|to)", r"^what\s+(is|does)", r"^can\s+(you|i|maven)"]):
            # Exception: "can you talk to grok about X" is still an action
            if not re.search(r"can\s+you\s+\w+\s+\w+\s+about", query_lower):
                action_score *= 0.3  # Heavily reduce - it's a question

    # -------------------------------------------------------------------------
    # Step 4: Check for small talk
    # -------------------------------------------------------------------------
    small_talk_score = 0.0

    for pattern in SMALL_TALK_PATTERNS:
        if re.search(pattern, query_lower, re.IGNORECASE):
            small_talk_score += 0.5

    # -------------------------------------------------------------------------
    # Step 5: Determine final classification
    # -------------------------------------------------------------------------
    # Normalize scores
    total = action_score + question_score + small_talk_score + 0.1  # Avoid div by zero
    action_score /= total
    question_score /= total
    small_talk_score /= total

    # Determine winner
    if small_talk_score > 0.5:
        intent_type = IntentType.SMALL_TALK
        confidence = small_talk_score
        reasoning = "Matched small talk patterns"
    elif action_score > question_score and action_score > 0.3:
        intent_type = IntentType.ACTION_REQUEST
        confidence = min(action_score + (best_capability_score * 0.5), 1.0)
        reasoning = f"Matched action patterns with capability '{best_capability}'" if best_capability else "Matched action verb patterns"
    elif question_score > 0.3:
        intent_type = IntentType.QUESTION
        confidence = question_score
        reasoning = "Matched question patterns"
    else:
        # Default to question if unsure
        intent_type = IntentType.QUESTION
        confidence = 0.5
        reasoning = "No strong pattern match, defaulting to question"

    # Build result
    result = IntentClassification(
        intent_type=intent_type,
        confidence=confidence,
        matched_verbs=list(set(matched_verbs)),
        matched_objects=list(set(matched_objects)),
        reasoning=reasoning,
        matched_capability=best_capability if intent_type == IntentType.ACTION_REQUEST else None,
    )

    return result


def get_capability_for_query(query: str) -> Optional[Dict[str, Any]]:
    """
    Get the best matching capability for a query.

    Returns the capability info dict if a strong match is found, None otherwise.
    """
    query_lower = query.lower().strip()
    best_match = None
    best_score = 0.0

    for cap_name, cap_info in CAPABILITIES_MAP.items():
        score = 0.0

        # Check verbs
        for verb in cap_info.get("verbs", []):
            if verb.lower() in query_lower:
                score += 0.4

        # Check objects
        for obj in cap_info.get("objects", []):
            if obj.lower() in query_lower:
                score += 0.3

        # Apply priority
        priority = cap_info.get("priority", 50) / 100.0
        score *= (0.5 + priority * 0.5)

        if score > best_score:
            best_score = score
            best_match = cap_info.copy()
            best_match["name"] = cap_name
            best_match["match_score"] = score

    if best_score > 0.4:
        return best_match

    return None


def is_action_request(query: str, context: Optional[Dict[str, Any]] = None) -> Tuple[bool, float, Optional[str]]:
    """
    Quick check: is this query an action request?

    Returns:
        Tuple of (is_action, confidence, matched_capability_name)
    """
    classification = classify_intent(query, context)

    if classification.intent_type == IntentType.ACTION_REQUEST:
        return True, classification.confidence, classification.matched_capability

    return False, 0.0, None


# ============================================================================
# Exports
# ============================================================================

def get_capabilities_map() -> Dict[str, Dict[str, Any]]:
    """Get a copy of the capabilities map."""
    return CAPABILITIES_MAP.copy()


def get_capability_names() -> List[str]:
    """Get list of all capability names."""
    return list(CAPABILITIES_MAP.keys())
