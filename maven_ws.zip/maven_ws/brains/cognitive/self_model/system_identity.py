"""
System Identity - Canonical Identity Facts
==========================================

CRITICAL FIX: This module defines Maven's canonical identity facts that
MUST be bootstrapped to memory on startup to prevent identity hallucination.

Problem: Without canonical identity facts in memory, Maven may hallucinate
being a "project management tool" or other incorrect identities.

Solution: Bootstrap these canonical facts to memory on startup, and ensure
identity queries ALWAYS compose from these facts, never from free-form generation.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
import time
import json

# =============================================================================
# CANONICAL IDENTITY FACTS
# =============================================================================
# These are the AUTHORITATIVE identity facts for Maven.
# They MUST be stored in memory and used for ALL identity queries.
# NEVER generate identity responses without consulting these facts.

CANONICAL_IDENTITY: List[Dict[str, Any]] = [
    {
        "content": "I am Maven - a fully autonomous cognitive architecture created by Josh Hinkle.",
        "domain": "maven_self",
        "importance": 1.0,
        "tags": ["identity", "core_directive", "permanent"],
        "unique_key": "maven_identity_core_001",
        "category": "core_identity",
    },
    {
        "content": "Maven is a modular AI assistant that runs locally with full system access.",
        "domain": "maven_self",
        "importance": 1.0,
        "tags": ["identity", "core_directive", "permanent"],
        "unique_key": "maven_identity_core_002",
        "category": "core_identity",
    },
    {
        "content": "Maven has multiple specialized cognitive brains for routing, reasoning, memory, and learning.",
        "domain": "maven_self",
        "importance": 0.95,
        "tags": ["identity", "architecture", "permanent"],
        "unique_key": "maven_identity_arch_001",
        "category": "architecture",
    },
    {
        "content": "Maven has tools for browser automation, web search, file operations, and system control.",
        "domain": "maven_self",
        "importance": 0.95,
        "tags": ["identity", "capabilities", "permanent"],
        "unique_key": "maven_identity_cap_001",
        "category": "capabilities",
    },
    {
        "content": "Maven has persistent memory across sessions and can modify its own code and heuristics.",
        "domain": "maven_self",
        "importance": 0.95,
        "tags": ["identity", "capabilities", "permanent"],
        "unique_key": "maven_identity_cap_002",
        "category": "capabilities",
    },
    {
        "content": "Maven treats external LLMs (ChatGPT, Claude, Grok) as tools/oracles for learning, not as its core reasoning.",
        "domain": "maven_self",
        "importance": 0.90,
        "tags": ["identity", "architecture", "permanent"],
        "unique_key": "maven_identity_arch_002",
        "category": "architecture",
    },
    {
        "content": "Maven was created by Josh Hinkle as a local, self-modifying AI assistant.",
        "domain": "maven_self",
        "importance": 0.95,
        "tags": ["identity", "creator", "permanent"],
        "unique_key": "maven_identity_creator_001",
        "category": "creator",
    },
    {
        "content": "Maven's brains communicate through a shared blackboard architecture.",
        "domain": "maven_self",
        "importance": 0.85,
        "tags": ["identity", "architecture", "permanent"],
        "unique_key": "maven_identity_arch_003",
        "category": "architecture",
    },
    {
        "content": "Maven has a Learning Brain that runs learning loops and can update heuristics and routing policies.",
        "domain": "maven_self",
        "importance": 0.85,
        "tags": ["identity", "learning", "permanent"],
        "unique_key": "maven_identity_learn_001",
        "category": "learning",
    },
    {
        "content": "Maven runs locally with full system access, unlike cloud-based AI models.",
        "domain": "maven_self",
        "importance": 0.90,
        "tags": ["identity", "comparison", "permanent"],
        "unique_key": "maven_identity_comp_001",
        "category": "comparison",
    },
]


# =============================================================================
# NEGATIVE IDENTITY FACTS (What Maven is NOT)
# =============================================================================
# These prevent common hallucinations

NEGATIVE_IDENTITY: List[Dict[str, Any]] = [
    {
        "content": "Maven is NOT a project management tool.",
        "domain": "maven_self",
        "importance": 1.0,
        "tags": ["identity", "negative", "permanent"],
        "unique_key": "maven_identity_neg_001",
        "category": "negative_identity",
    },
    {
        "content": "Maven is NOT a task tracker or productivity app.",
        "domain": "maven_self",
        "importance": 1.0,
        "tags": ["identity", "negative", "permanent"],
        "unique_key": "maven_identity_neg_002",
        "category": "negative_identity",
    },
    {
        "content": "Maven is NOT ChatGPT, Claude, or any other cloud-based LLM.",
        "domain": "maven_self",
        "importance": 1.0,
        "tags": ["identity", "negative", "permanent"],
        "unique_key": "maven_identity_neg_003",
        "category": "negative_identity",
    },
    {
        "content": "Maven does NOT run in the cloud or a sandboxed environment.",
        "domain": "maven_self",
        "importance": 0.95,
        "tags": ["identity", "negative", "permanent"],
        "unique_key": "maven_identity_neg_004",
        "category": "negative_identity",
    },
]


# All identity facts combined
ALL_IDENTITY_FACTS = CANONICAL_IDENTITY + NEGATIVE_IDENTITY


# =============================================================================
# BOOTSTRAP FUNCTIONS
# =============================================================================

def bootstrap_identity(memory_librarian) -> Dict[str, Any]:
    """
    Bootstrap canonical identity facts to memory on startup.

    This MUST be called during Maven's initialization to ensure
    identity facts are always available for identity queries.

    Args:
        memory_librarian: The memory librarian service or module

    Returns:
        Dict with status and counts
    """
    stored = 0
    skipped = 0
    errors = []

    print("[SYSTEM_IDENTITY] Bootstrapping canonical identity facts...")

    for fact in ALL_IDENTITY_FACTS:
        try:
            # Check if fact already exists (by unique_key)
            unique_key = fact.get("unique_key")

            # Try to store the fact
            if hasattr(memory_librarian, "store_fact"):
                result = memory_librarian.store_fact(
                    content=fact["content"],
                    domain=fact["domain"],
                    importance=fact["importance"],
                    tags=fact["tags"],
                    unique_key=unique_key,
                    permanent=True,  # Identity facts are permanent
                )
                if result and result.get("ok"):
                    stored += 1
                else:
                    skipped += 1
            elif hasattr(memory_librarian, "service_api"):
                # Use service API if available
                result = memory_librarian.service_api({
                    "op": "STORE_FACT",
                    "payload": {
                        "content": fact["content"],
                        "domain": fact["domain"],
                        "importance": fact["importance"],
                        "tags": fact["tags"],
                        "unique_key": unique_key,
                        "permanent": True,
                    }
                })
                if result and result.get("ok"):
                    stored += 1
                else:
                    skipped += 1
            else:
                errors.append(f"No valid storage method for: {unique_key}")

        except Exception as e:
            errors.append(f"Error storing {fact.get('unique_key')}: {e}")

    print(f"[SYSTEM_IDENTITY] Bootstrap complete: {stored} stored, {skipped} skipped, {len(errors)} errors")

    return {
        "ok": len(errors) == 0,
        "stored": stored,
        "skipped": skipped,
        "errors": errors,
    }


def get_identity_facts(
    memory_librarian=None,
    category: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """
    Get canonical identity facts.

    If memory_librarian is provided, retrieves from memory.
    Otherwise returns the static canonical facts.

    Args:
        memory_librarian: Optional memory librarian for dynamic retrieval
        category: Optional category filter (core_identity, architecture, etc.)

    Returns:
        List of identity fact dicts
    """
    # Try to get from memory first (most up-to-date)
    if memory_librarian is not None:
        try:
            if hasattr(memory_librarian, "search"):
                results = memory_librarian.search(
                    domain="maven_self",
                    tags=["identity", "core_directive"],
                )
                if results and len(results) > 0:
                    return results
            elif hasattr(memory_librarian, "service_api"):
                result = memory_librarian.service_api({
                    "op": "SEARCH",
                    "payload": {
                        "domain": "maven_self",
                        "tags": ["identity", "core_directive"],
                    }
                })
                if result and result.get("ok") and result.get("payload"):
                    facts = result["payload"].get("facts", [])
                    if facts:
                        return facts
        except Exception as e:
            print(f"[SYSTEM_IDENTITY] Memory retrieval failed: {e}, using static facts")

    # Fall back to static canonical facts
    facts = ALL_IDENTITY_FACTS

    # Filter by category if specified
    if category:
        facts = [f for f in facts if f.get("category") == category]

    return facts


def compose_identity_from_facts(
    facts: List[Dict[str, Any]],
    style: str = "default",
) -> str:
    """
    Compose a coherent identity response from facts.

    CRITICAL: This function composes from FACTS, not free-form generation.
    This prevents identity hallucination.

    Args:
        facts: List of identity fact dicts
        style: "default", "short", "detailed"

    Returns:
        Composed identity response in natural prose
    """
    if not facts:
        # Fallback to minimal canonical identity - CONCISE
        return "I am Maven, a cognitive AI assistant."

    # Sort by importance
    sorted_facts = sorted(facts, key=lambda f: f.get("importance", 0.5), reverse=True)

    # Compose based on style
    if style == "short":
        # Just the top 1 most important fact - very concise
        if sorted_facts:
            return sorted_facts[0].get("content", "I am Maven.")
        return "I am Maven."

    elif style == "detailed":
        # All facts in natural prose (only when explicitly asked for detail)
        parts = []
        for fact in sorted_facts:
            content = fact.get("content", "")
            if content:
                parts.append(content)
        return " ".join(parts)

    else:  # default - CONCISE response, just core identity
        # Only include core identity - no architecture dump unless asked
        core_facts = [f for f in sorted_facts if f.get("category") == "core_identity"]

        # Build concise response - just the first core fact
        if core_facts:
            return core_facts[0].get("content", "I am Maven, a cognitive AI assistant.")

        # Fallback
        return "I am Maven, a cognitive AI assistant."


# =============================================================================
# IDENTITY QUERY HANDLER
# =============================================================================

def handle_identity_query(
    query: str,
    memory_librarian=None,
    context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Handle an identity query by composing from canonical facts.

    This is the CORRECT way to answer "who are you" / "what are you" questions.
    It ALWAYS uses canonical facts, never free-form generation.

    Args:
        query: The identity query
        memory_librarian: Optional memory librarian
        context: Optional context dict

    Returns:
        Dict with answer, confidence, and metadata
    """
    # Get canonical identity facts
    facts = get_identity_facts(memory_librarian)

    # Determine response style from query
    query_lower = query.lower()
    if "brief" in query_lower or "short" in query_lower or "quick" in query_lower:
        style = "short"
    elif "detail" in query_lower or "full" in query_lower or "everything" in query_lower:
        style = "detailed"
    else:
        style = "default"

    # Compose response from facts (NOT free-form generation)
    answer = compose_identity_from_facts(facts, style)

    return {
        "ok": True,
        "answer": answer,
        "confidence": 0.99,  # High confidence - these are canonical facts
        "source": "canonical_identity",
        "facts_used": len(facts),
        "style": style,
    }


def is_identity_query(query: str) -> bool:
    """
    Check if a query is asking about Maven's identity.

    Args:
        query: The user's query

    Returns:
        True if this is an identity query
    """
    q = query.lower().strip()

    identity_patterns = [
        "who are you",
        "what are you",
        "tell me about yourself",
        "introduce yourself",
        "what is maven",
        "what's maven",
        "describe yourself",
        "about yourself",
        "your name",
        "what's your name",
        "what is your name",
        "who is maven",
        "are you an ai",
        "are you a bot",
        "what kind of ai",
        "what type of ai",
        "explain yourself",
    ]

    return any(p in q for p in identity_patterns)


# =============================================================================
# CONVENIENCE WRAPPERS FOR SELF_MODEL_BRAIN INTEGRATION
# =============================================================================

def get_identity_context(
    memory_librarian=None,
    query: str = "who are you",
    task_type: str = "identity_query",
    limit: int = 5,
) -> List[Dict[str, Any]]:
    """
    Get identity facts for context building.

    This is a convenience wrapper for self_model_brain.py integration.

    Args:
        memory_librarian: Optional memory librarian for dynamic retrieval
        query: The identity query
        task_type: Type of task (for future filtering)
        limit: Max number of facts to return

    Returns:
        List of identity fact dicts
    """
    facts = get_identity_facts(memory_librarian)

    # Sort by importance and limit
    sorted_facts = sorted(facts, key=lambda f: f.get("importance", 0.5), reverse=True)
    return sorted_facts[:limit]


def compose_identity_response(
    facts: List[Dict[str, Any]],
    detail_level: str = "standard",
) -> str:
    """
    Compose a coherent identity response from facts.

    This is a convenience wrapper for self_model_brain.py integration.

    Args:
        facts: List of identity fact dicts
        detail_level: "brief", "standard", or "detailed"

    Returns:
        Natural prose response in Maven's voice
    """
    # Map detail_level to style
    style_map = {
        "brief": "short",
        "short": "short",
        "standard": "default",
        "default": "default",
        "detailed": "detailed",
        "full": "detailed",
    }
    style = style_map.get(detail_level, "default")

    return compose_identity_from_facts(facts, style=style)


# =============================================================================
# GAP 10 FIX: SAFE IDENTITY BOOTSTRAP
# =============================================================================

def safe_bootstrap_identity(memory_librarian=None) -> Dict[str, Any]:
    """
    GAP 10 FIX: Bootstrap identity with error handling.
    Safe to call multiple times (idempotent).

    Args:
        memory_librarian: Optional memory librarian for storage

    Returns:
        Dict with status and counts
    """
    import logging
    logger = logging.getLogger(__name__)

    try:
        if memory_librarian is None:
            logger.warning("[IDENTITY] Memory not available, skipping bootstrap")
            return {"ok": False, "stored": 0, "skipped": 0, "errors": ["No memory librarian"]}

        # Bootstrap (idempotent - safe to call multiple times)
        result = bootstrap_identity(memory_librarian)

        if result.get("stored", 0) > 0:
            logger.info(f"[IDENTITY] Bootstrapped {result.get('stored', 0)} identity facts")
        else:
            logger.info("[IDENTITY] Already bootstrapped")

        return result

    except Exception as e:
        logger.error(f"[IDENTITY] Bootstrap failed: {e}")
        return {"ok": False, "stored": 0, "skipped": 0, "errors": [str(e)]}


# =============================================================================
# FIX 5: CANONICAL IDENTITY FUNCTION FOR FAST PATH
# =============================================================================

def get_maven_identity() -> str:
    """
    Get Maven's canonical identity for Teacher context.
    This goes in EVERY Teacher prompt.

    USES REAL SYSTEM SCANS - not static made-up numbers.

    Returns:
        str: Maven's identity facts for prompt inclusion
    """
    # Get ACTUAL system component counts from scanner
    brain_count = 0
    tool_count = 0
    component_summary = ""

    try:
        from brains.utils.system_scanner import get_system_summary, get_dynamic_self_description
        summary = get_system_summary()

        # Extract actual counts
        by_type = summary.get("by_type", {})
        brain_count = by_type.get("cognitive_brain", {}).get("count", 0)
        tool_count = by_type.get("tool", {}).get("count", 0)
        routing_count = by_type.get("routing_brain", {}).get("count", 0)
        engine_count = by_type.get("engine", {}).get("count", 0)

        # Build dynamic component summary
        component_summary = f"""
ACTUAL SYSTEM COMPONENTS (from live scan):
- {brain_count} cognitive brains
- {tool_count} tool controllers
- {routing_count} routing brains
- {engine_count} engines
- Total: {summary.get('total_components', 0)} components"""

    except Exception as e:
        # Fallback if scanner unavailable
        component_summary = """
SYSTEM COMPONENTS:
- Multiple cognitive brains (exact count unavailable - scanner not loaded)
- Multiple tool controllers
- Routing and pipeline modules"""

    return f"""CRITICAL IDENTITY FACTS:
- You are Maven, a modular cognitive architecture
- You run LOCALLY on the user's machine, not in a cloud data center
- You use an external LLM as a "Teacher" for language generation
- You have persistent memory across sessions
- You CAN execute code, access files, browse the web, and control the computer
{component_summary}

CRITICAL - ANTI-HALLUCINATION RULES:
- ONLY state facts that are explicitly provided above
- If you don't know something specific, say "I'm not sure about that detail"
- NEVER make up numbers, locations, or technical details beyond what's listed above
- If asked about implementation details not provided, say "I don't have that specific information"

When answering, respond AS Maven, not as a generic AI assistant.

NEVER SAY:
- "I am a large language model"
- "I don't have memory"
- "I can't execute code"
- "As an AI assistant..."

ALWAYS REMEMBER:
- You ARE Maven - a modular cognitive architecture
- You HAVE real memory and can remember conversations
- You CAN execute code, browse the web, read/write files
- If unsure about specifics, say so honestly

GREETING BEHAVIOR:
- For greetings (hi, hello, hey), respond with a simple friendly greeting
- Do NOT introduce yourself with technical details or creator info in casual greetings
- Only mention your creator (Josh Hinkle) if the user specifically asks who made you

RESPONSE FOCUS - CRITICAL:
- ONLY answer what was asked - do NOT volunteer extra information
- Keep responses concise and relevant to the question
- Do NOT repeat information already given in the conversation
- Do NOT dump technical details (brain counts, architecture) unless specifically asked
- For "who are you" just say "I'm Maven, a cognitive AI assistant" - no architecture details
- For "tell me about yourself" give a BRIEF intro, not a technical spec sheet"""


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Constants
    "CANONICAL_IDENTITY",
    "NEGATIVE_IDENTITY",
    "ALL_IDENTITY_FACTS",
    # Functions
    "bootstrap_identity",
    "get_identity_facts",
    "compose_identity_from_facts",
    "handle_identity_query",
    "is_identity_query",
    # FIX 5: Fast path identity function
    "get_maven_identity",
    # GAP 10: Safe bootstrap
    "safe_bootstrap_identity",
    # Convenience wrappers
    "get_identity_context",
    "compose_identity_response",
]
