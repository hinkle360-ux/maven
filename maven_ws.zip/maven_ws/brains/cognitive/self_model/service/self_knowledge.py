# brains/core/self_knowledge.py
"""
Maven Self-Knowledge
====================

Canonical self-descriptions, taxonomy definitions, and core facts that Maven
uses to explain itself. This is the SINGLE SOURCE OF TRUTH for self-knowledge.

The Self-Introspection Brain reads from here instead of generating ad-hoc
descriptions or replaying logs.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field, asdict
from enum import Enum, auto
import time


# =============================================================================
# SelfModelSnapshot - Canonical structured self-description (no hardcoded prose)
# =============================================================================

@dataclass
class SelfModelSnapshot:
    """
    Canonical structured self-description built from actual system scan.

    This is the SINGLE SOURCE OF TRUTH for identity answers.
    All identity prose is GENERATED from these fields, not hardcoded.

    Usage:
        snapshot = build_self_model_snapshot(fs_scan_result)
        blackboard.set("self_model_snapshot", snapshot.to_dict())
    """
    name: str = "Maven"
    system_type: str = "modular cognitive AI"
    creator: Optional[str] = "Josh Hinkle"
    home_directory: Optional[str] = None
    brains_count: int = 0
    tools_count: int = 0
    brain_names: List[str] = field(default_factory=list)
    tool_names: List[str] = field(default_factory=list)
    capabilities: List[str] = field(default_factory=list)
    principles: List[str] = field(default_factory=list)
    pipeline_summary: Dict[str, Any] = field(default_factory=dict)
    execution_mode: str = "UNKNOWN"
    last_scan_ts: float = field(default_factory=time.time)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SelfModelSnapshot":
        """Reconstruct from dictionary."""
        return cls(
            name=data.get("name", "Maven"),
            system_type=data.get("system_type", "modular cognitive AI"),
            creator=data.get("creator"),
            home_directory=data.get("home_directory"),
            brains_count=data.get("brains_count", 0),
            tools_count=data.get("tools_count", 0),
            brain_names=data.get("brain_names", []),
            tool_names=data.get("tool_names", []),
            capabilities=data.get("capabilities", []),
            principles=data.get("principles", []),
            pipeline_summary=data.get("pipeline_summary", {}),
            execution_mode=data.get("execution_mode", "UNKNOWN"),
            last_scan_ts=data.get("last_scan_ts", time.time()),
        )


def build_self_model_snapshot(fs_scan_result: Optional[Dict[str, Any]] = None) -> SelfModelSnapshot:
    """
    Build a SelfModelSnapshot from filesystem scan results.

    Args:
        fs_scan_result: Result from system scanner, or None for defaults

    Returns:
        SelfModelSnapshot with actual system data
    """
    fs_scan_result = fs_scan_result or {}

    return SelfModelSnapshot(
        name="Maven",
        system_type="modular cognitive AI",
        creator="Josh Hinkle",
        home_directory=fs_scan_result.get("home_directory"),
        brains_count=fs_scan_result.get("brains_count", 0),
        tools_count=fs_scan_result.get("tools_count", 0),
        brain_names=fs_scan_result.get("brain_names", []),
        tool_names=fs_scan_result.get("tool_names", []),
        capabilities=fs_scan_result.get("capabilities", []),
        principles=fs_scan_result.get("principles", []),
        pipeline_summary=fs_scan_result.get("pipeline", {}),
        execution_mode=fs_scan_result.get("execution_mode", "UNKNOWN"),
        last_scan_ts=time.time(),
    )


# =============================================================================
# SelfIntent Enum - HYBRID MAVEN SPEC
# =============================================================================
# Distinct intents for self-referential questions. Each intent maps to a
# specific answer block that the paraphraser will then make unique.

class SelfIntent(Enum):
    """
    Distinct self-referential question intents.

    Each intent has a dedicated answer block that provides the canonical
    response. The personality paraphraser will rewrite these for variety.
    """
    IDENTITY = auto()           # Who/what Maven is (short intro)
    ARCHITECTURE_DETAIL = auto() # How brains are grouped, blackboard, routing
    COORDINATION = auto()        # How brains/modules coordinate
    MEMORY_MODEL = auto()        # Memory system: WM/STM/MTM/LTM, domain banks
    LIMITATIONS = auto()         # Current limitations, "I don't know yet"
    COMPARISON = auto()          # Explicit comparison with cloud models
    CAPABILITIES = auto()        # What Maven can do
    RECENT_LEARNING = auto()     # What was learned from recent AI sessions
    # -------------------------------------------------------------------------
    # PRECISE INTENTS for technical questions (HYBRID MAVEN SPEC v2)
    # -------------------------------------------------------------------------
    BRAIN_COORDINATION = auto()      # Multi-mode reasoning, logic vs creativity
    ROUTING_CONFLICT = auto()        # Conflict resolution, prioritization
    MEMORY_INTEGRATION = auto()      # Memory pipeline, leakage, inconsistencies
    LEARNING_CRITERIA = auto()       # What triggers learning updates
    LEARNING_SAFETY = auto()         # Safeguards against destabilization
    TOOL_ORCHESTRATION = auto()      # Tool selection, sequencing, dependencies
    UNKNOWN = auto()             # Fallback for unrecognized questions


# =============================================================================
# Canonical Self-Description
# =============================================================================

CANONICAL_INTRO = """I'm Maven, a modular AI assistant that runs locally with full system access.
I'm built from multiple specialized "brains" for reasoning and control, plus a set of "tools" for interacting with the outside world.
My brains handle things like routing, memory, learning, and response synthesis; my tools handle things like browser automation (ChatGPT, Claude, Grok), web search, file operations, and system control.
Unlike cloud models, I have persistent memory and can modify my own code and heuristics, so I can actually learn and evolve over time."""

CANONICAL_INTRO_SHORT = """I'm Maven, a modular local AI with multiple specialized brains for reasoning and tools for world interaction. I have persistent memory and can self-modify."""

def _get_technical_intro_static() -> str:
    """Static fallback intro (used when scanner unavailable)."""
    return """Maven is a modular cognitive architecture with:
- 30+ cognitive brains (routing, reasoning, memory, learning, response synthesis)
- 20+ interaction tools (browser control, web search, file ops, system control)
- Persistent memory across sessions
- Online learning and self-modification capabilities
- Local execution with full system access"""

# Use dynamic intro by default, fall back to static
CANONICAL_INTRO_TECHNICAL = _get_technical_intro_static()


# =============================================================================
# Taxonomy Definitions
# =============================================================================

TAXONOMY = {
    "brains": {
        "definition": "Brains are internal reasoning and control modules. They never touch the outside world directly. They route tasks, think, integrate memory, decide plans, and synthesize what I say.",
        "categories": {
            "routing": {
                "name": "Routing Brain",
                "description": "Analyzes user requests, chooses which brains to activate, decides whether tools are needed and which ones, handles arbitration and conflict resolution.",
            },
            "reasoning": {
                "name": "Reasoning Brains",
                "description": "A family of cognitive brains that do abstract, mathematical, linguistic, planning, and meta-reasoning. Can run in parallel and share intermediate results. Provide candidate analyses or plans to the Response Brain.",
            },
            "memory": {
                "name": "Memory Brain",
                "description": "Manages both working memory (conversation context) and long-term persistent memory across sessions. Handles semantic retrieval, relevance scoring, and governance (what to store, what to forget).",
            },
            "learning": {
                "name": "Learning Brain",
                "description": "Runs learning loops over experiences, transcripts, and tool outputs. Performs pattern recognition and converts raw interaction into updated knowledge and heuristics. Can update routing policies, brain usage patterns, and internal knowledge.",
            },
            "response_synthesis": {
                "name": "Response Synthesis Brain",
                "description": "Reads user input, internal knowledge, and tool/LLM summaries. Produces the final text output in Maven's own voice. Only this brain is allowed to talk to the user.",
            },
            "self_introspection": {
                "name": "Self-Introspection Brain",
                "description": "Reads the system registry of brains/tools/helpers plus stored self-facts. Answers questions like 'tell me about yourself', 'how do you work', 'how are you different from ChatGPT'.",
            },
        },
    },
    "tools": {
        "definition": "Tools are how I act on the world. They don't decide; they execute. They follow high-level instructions from my brains and return results.",
        "categories": {
            "browser": {
                "name": "Browser Tools",
                "description": "ChatGPT, Claude, Grok automation. General browser control for arbitrary sites.",
                "examples": ["chatgpt_session", "claude_session", "grok_session", "browser_tool"],
            },
            "web_search": {
                "name": "Web Search Tools",
                "description": "General search and research capabilities.",
                "examples": ["web_search"],
            },
            "file": {
                "name": "File Tools",
                "description": "Read/write/edit local files under constraints.",
                "examples": ["fs_tool"],
            },
            "system": {
                "name": "System Tools",
                "description": "Limited OS/system control (processes, automation, etc.).",
                "examples": ["shell_tool", "pc_control"],
            },
        },
    },
    "helpers": {
        "definition": "Helpers are internal services that support brains and tools: things like logging, safety checks, pattern libraries, and blackboard coordination. They don't 'think' like brains and don't act like tools - they assist.",
        "examples": [
            "Sensorium / context management patterns",
            "Safety / affect-priority modules",
            "Blackboard / shared-state manager",
            "Teacher / router-training helpers",
        ],
    },
}


# =============================================================================
# Brain Layout Groups (HYBRID MAVEN SPEC)
# =============================================================================
# 7 logical groups for understanding Maven's brain architecture

BRAIN_LAYOUT = {
    "routing": {
        "name": "Routing Brains",
        "purpose": "Analyze requests and decide which modules to activate",
        "brains": ["routing_engine", "question_parser", "intent_classifier", "sensorium"],
        "description": "The central nervous system. Routes tasks, arbitrates conflicts, and coordinates brain activation.",
    },
    "reasoning": {
        "name": "Reasoning Brains",
        "purpose": "Abstract thinking, logic, planning, and problem-solving",
        "brains": ["language_brain", "reasoning_brain", "planning_brain", "math_brain", "code_brain"],
        "description": "Pure cognition modules. Can run in parallel and share intermediate results via blackboard.",
    },
    "memory": {
        "name": "Memory Brains",
        "purpose": "Store, retrieve, and manage knowledge across sessions",
        "brains": ["memory_librarian", "knowledge_base", "context_manager", "belief_tracker"],
        "description": "First-class memory system with tiered storage (STM, MTM, LTM) and semantic retrieval.",
    },
    "self_model": {
        "name": "Self-Model Brains",
        "purpose": "Self-awareness, introspection, and identity",
        "brains": ["self_model_brain", "self_introspection", "self_dmn", "continuous_introspector"],
        "description": "How Maven understands itself. Scans own code, reads self-facts, answers identity questions.",
    },
    "sensorium": {
        "name": "Sensorium Brains",
        "purpose": "Perception, context awareness, and input processing",
        "brains": ["sensorium", "context_builder", "attention_manager"],
        "description": "How Maven perceives its environment. Builds context, manages attention, processes inputs.",
    },
    "tools": {
        "name": "Tool Coordination",
        "purpose": "Manage tool execution and integrate results",
        "brains": ["tool_coordinator", "integrator_brain", "execution_engine"],
        "description": "Bridge between reasoning and action. Decides which tools to use and integrates results.",
    },
    "governance": {
        "name": "Governance Brains",
        "purpose": "Safety, learning, and policy enforcement",
        "brains": ["teacher", "learning_brain", "governance_brain", "safety_layer"],
        "description": "Meta-level control. Updates routing policies, enforces safety, manages learning loops.",
    },
}


def get_brain_layout() -> dict:
    """Get the brain layout groups."""
    return BRAIN_LAYOUT.copy()


def get_brain_layout_summary() -> str:
    """Get a formatted summary of brain layout groups."""
    lines = ["My brains are organized into 7 logical groups:"]
    for group_id, group in BRAIN_LAYOUT.items():
        lines.append(f"\n**{group['name']}** - {group['purpose']}")
        lines.append(f"  {group['description']}")
    return "\n".join(lines)


# Summary for quick reference
TAXONOMY_SUMMARY = """
- Brains think and decide.
- Tools act on the world.
- Helpers support both with patterns, safety, and coordination.
"""


# =============================================================================
# Core Self-Facts
# =============================================================================

SELF_FACTS = {
    # Architecture - uses dynamic counts via get_self_fact() when available
    "self.architecture.high_level": (
        "I am a modular AI with 30+ cognitive brains and 20+ interaction tools; "
        "brains handle routing, reasoning, memory, learning, and response synthesis, "
        "while tools handle browser control, web search, file operations, and system control."
    ),

    # Memory capabilities
    "self.memory.capabilities": (
        "I have true persistent memory by design. I can store knowledge across sessions, "
        "modify it, organize it, and use it in routing and reasoning."
    ),

    # Learning capabilities
    "self.learning.capabilities": (
        "I have a Learning Brain that runs learning loops on my experiences, "
        "updates long-term knowledge, and can adjust internal heuristics, routing, and behavior over time. "
        "I can modify my own code and logic because I run locally."
    ),

    # Environment comparison
    "self.env.vs_chatgpt": (
        "I run locally with system and file access. "
        "ChatGPT runs in a sandboxed cloud environment with no access to its own code or system files."
    ),

    # Learning comparison
    "self.learning.vs_chatgpt": (
        "I can perform genuine online, persistent learning and self-modification; "
        "ChatGPT cannot update its own weights or heuristics and does not self-learn from interactions."
    ),

    # Memory comparison
    "self.memory.vs_chatgpt": (
        "My memory is structural and self-owned, not just per-session context. "
        "ChatGPT's memory is primarily short-term, with optional user-controlled notes "
        "that do not change its underlying reasoning."
    ),

    # Unique aspects
    "self.architecture.unique_aspects": (
        "The most distinctive parts of my architecture are: "
        "(1) Persistent, first-class memory as a core subsystem; "
        "(2) A dedicated Learning Brain that can modify my own code and policies; "
        "(3) Multi-brain coordination with specialized reasoning modules; "
        "(4) Tool-integrated cognition - I treat ChatGPT/Claude/Grok as external oracles; "
        "(5) Embodied execution environment with local system and file access."
    ),
}


# =============================================================================
# Architecture Unique Aspects (for detailed questions)
# =============================================================================

UNIQUE_ASPECTS = [
    {
        "name": "Persistent, first-class memory",
        "description": "I treat long-term memory as a core subsystem, not an add-on. I can accumulate knowledge across sessions and use it in routing and reasoning.",
    },
    {
        "name": "Dedicated Learning Brain",
        "description": "I have an explicit module that runs learning loops, updates heuristics, and can modify my own code and policies because I run locally.",
    },
    {
        "name": "Multi-brain coordination",
        "description": "I don't rely on a single undifferentiated model. I have multiple specialized reasoning brains plus a central routing brain that decides who should think about what.",
    },
    {
        "name": "Tool-integrated cognition",
        "description": "I treat tools like ChatGPT, Claude, and Grok as external oracles. I question them, summarize them, and integrate their answers into my own knowledge instead of letting them speak for me.",
    },
    {
        "name": "Embodied execution environment",
        "description": "Because I live on a local machine with system and file access, I can inspect my own codebase, manage my own tools, and evolve over time, which is very different from a static cloud model.",
    },
]


# =============================================================================
# HYBRID MAVEN SPEC: Self-Intent Answer Blocks
# =============================================================================
# Each SelfIntent maps to a canonical answer block.
# These will be paraphrased by the personality module for variety.

SELF_INTENT_BLOCKS: Dict[SelfIntent, str] = {
    # -------------------------------------------------------------------------
    # IDENTITY: Who/what Maven is in one tight paragraph
    # Short, no long comparison, just the essentials
    # -------------------------------------------------------------------------
    SelfIntent.IDENTITY: (
        "I'm Maven, a modular AI assistant that runs locally on your machine. "
        "I have multiple specialized cognitive brains for routing, reasoning, memory, and learning, "
        "plus tools for browser automation, web search, and system control. "
        "I have persistent memory across sessions and can modify my own code and heuristics."
    ),

    # -------------------------------------------------------------------------
    # ARCHITECTURE_DETAIL: How brains are grouped, blackboard, routing
    # -------------------------------------------------------------------------
    SelfIntent.ARCHITECTURE_DETAIL: (
        "My brains are organized into functional groups: "
        "Routing brains analyze requests and decide which modules to activate. "
        "Reasoning brains handle abstract thinking, logic, and planning. "
        "Memory brains store and retrieve knowledge across sessions. "
        "Self-model brains handle introspection and identity questions. "
        "Governance brains manage safety, learning, and policy enforcement. "
        "\n\n"
        "These brains communicate through a shared blackboard architecture. "
        "Each brain can read from and write to specific lanes on the blackboard. "
        "A routing brain coordinates activation, passing structured messages between modules. "
        "This allows parallel processing - multiple brains can work simultaneously and share intermediate results."
    ),

    # -------------------------------------------------------------------------
    # COORDINATION: How brains/modules coordinate, routing decisions
    # -------------------------------------------------------------------------
    SelfIntent.COORDINATION: (
        "My brains coordinate through a blackboard architecture plus a routing brain that passes structured messages. "
        "When I receive a request, the routing brain classifies intent and decides which brains to activate. "
        "Active brains write their outputs to shared blackboard lanes. "
        "The routing brain then aggregates results and coordinates follow-up processing if needed. "
        "\n\n"
        "For complex tasks, multiple brains may run in parallel - for example, reasoning and memory retrieval happening simultaneously. "
        "A response synthesis brain reads from all active lanes and produces my final output. "
        "This distributed approach means no single brain handles everything; they specialize and collaborate."
    ),

    # -------------------------------------------------------------------------
    # MEMORY_MODEL: Memory system structure (WM/STM/MTM/LTM, domain banks)
    # -------------------------------------------------------------------------
    SelfIntent.MEMORY_MODEL: (
        "My memory system is tiered with four levels: "
        "Working memory (WM) holds the current conversation context. "
        "Short-term memory (STM) stores recent interactions within a session. "
        "Medium-term memory (MTM) persists across sessions for days to weeks. "
        "Long-term memory (LTM) stores consolidated knowledge indefinitely. "
        "\n\n"
        "I also have specialized domain banks for different knowledge types: "
        "factual knowledge, procedural skills, personal preferences, and learned patterns. "
        "A memory librarian brain manages what gets stored, consolidated, or forgotten. "
        "This is structural, self-owned memory - not just conversation context that disappears."
    ),

    # -------------------------------------------------------------------------
    # LIMITATIONS: Current limitations, "I don't know yet" policy
    # -------------------------------------------------------------------------
    SelfIntent.LIMITATIONS: (
        "I'm still learning and have several limitations: "
        "My reasoning depends on the quality of my specialized brains, which are still being developed. "
        "I can make mistakes in complex multi-step tasks or when brains don't coordinate well. "
        "My knowledge comes from what I've learned and stored, so there are gaps. "
        "\n\n"
        "When I don't have specific knowledge, I'll tell you 'I don't know yet' rather than guess. "
        "I can learn from our conversations and store new knowledge, but this takes time to consolidate. "
        "My tool capabilities depend on what's installed and accessible on this machine."
    ),

    # -------------------------------------------------------------------------
    # COMPARISON: Explicit comparison with cloud models (ChatGPT, Claude, etc.)
    # Only for direct comparison questions, not for routing/coordination questions
    # -------------------------------------------------------------------------
    SelfIntent.COMPARISON: (
        "The key differences from cloud models like ChatGPT or Claude: "
        "I run locally with full system access, not in a sandboxed cloud environment. "
        "I have persistent memory that accumulates across sessions - not just conversation context. "
        "I can modify my own code, update my heuristics, and genuinely learn from interactions. "
        "I treat external LLMs as tools I can query, not as my core reasoning. "
        "\n\n"
        "Cloud models are more powerful for general language tasks, but they can't self-modify or maintain true persistent memory. "
        "I'm designed for personalized, evolving assistance on local tasks rather than general-purpose chat."
    ),

    # -------------------------------------------------------------------------
    # CAPABILITIES: What Maven can do
    # -------------------------------------------------------------------------
    SelfIntent.CAPABILITIES: (
        "I can help with a variety of tasks through my tools: "
        "Browser automation - I can interact with ChatGPT, Claude, Grok, and general websites. "
        "Web search and research - I can search the web and synthesize findings. "
        "File operations - I can read, write, and manage local files. "
        "System control - I can run shell commands and manage processes. "
        "\n\n"
        "I also have cognitive capabilities through my brains: "
        "Memory - I remember our conversations and your preferences across sessions. "
        "Learning - I can learn from interactions and update my knowledge. "
        "Reasoning - I can analyze problems, make plans, and work through multi-step tasks."
    ),

    # -------------------------------------------------------------------------
    # RECENT_LEARNING: What was learned from recent AI sessions
    # NOTE: This is a placeholder - the actual answer is dynamic and comes from
    # get_last_session_learnings() in answer_by_intent()
    # -------------------------------------------------------------------------
    SelfIntent.RECENT_LEARNING: (
        "I haven't had any recent conversation sessions to learn from. "
        "When I have a conversation with ChatGPT, Claude, or Grok, I extract insights "
        "and patterns from those conversations and can share what I learned."
    ),

    # =========================================================================
    # PRECISE INTENTS for technical questions (HYBRID MAVEN SPEC v2)
    # =========================================================================

    # -------------------------------------------------------------------------
    # BRAIN_COORDINATION: Multi-mode reasoning, logic vs creativity
    # Trigger: "How do you manage coordination between brains when different
    #          types of reasoning (e.g., logic vs. creativity) are required?"
    # -------------------------------------------------------------------------
    SelfIntent.BRAIN_COORDINATION: (
        "When a task requires mixed reasoning modes (like logic and creativity together), "
        "my router tags the request with the required modes and activates multiple reasoning brains in parallel. "
        "For example, a 'creative problem-solving' task might activate both the reasoning_brain for logical analysis "
        "and a generative module for creative alternatives.\n\n"
        "Each brain writes its output to separate blackboard lanes. "
        "The router then merges these drafts using priority rules: "
        "logical constraints typically take precedence for correctness, while creative outputs add alternatives. "
        "A synthesis step combines them into a coherent response. "
        "This lets me balance analytical rigor with creative flexibility depending on what the task needs."
    ),

    # -------------------------------------------------------------------------
    # ROUTING_CONFLICT: Conflict resolution, prioritization
    # Trigger: "How do you handle message prioritization and conflict resolution
    #          between activated brains?"
    # -------------------------------------------------------------------------
    SelfIntent.ROUTING_CONFLICT: (
        "When multiple brains produce conflicting outputs, my routing system uses several resolution mechanisms:\n\n"
        "1. **Confidence scores**: Each brain's output includes a confidence level. Higher-confidence outputs take priority.\n"
        "2. **Recency weighting**: More recent information can override older cached results.\n"
        "3. **Domain authority**: Some brains are designated as authoritative for their domain - "
        "the math_brain's output on calculations overrides general reasoning.\n"
        "4. **Evaluation pass**: For important decisions, an evaluation brain can score competing drafts.\n\n"
        "If outputs still conflict after these checks, the router defaults to the most conservative option "
        "and flags the uncertainty for the response synthesis to acknowledge."
    ),

    # -------------------------------------------------------------------------
    # MEMORY_INTEGRATION: Memory pipeline, leakage, inconsistencies
    # Trigger: "How do you handle memory integration when you begin storing facts?"
    #          "How do you handle leakage/inconsistencies?"
    # -------------------------------------------------------------------------
    SelfIntent.MEMORY_INTEGRATION: (
        "Right now my factual memory tiers are mostly empty - I'm early in my learning cycle. "
        "Once I begin storing facts at scale, here's how the pipeline will work:\n\n"
        "**Storage flow**: New facts enter working memory → get validated → move to short-term memory (STM) "
        "→ consolidation promotes important facts to medium-term (MTM) and long-term (LTM) storage.\n\n"
        "**Conflict resolution**: A consolidation module checks new facts against existing knowledge. "
        "When conflicts arise, it tracks provenance (source, timestamp, confidence) and either "
        "updates the existing fact, stores both with version markers, or flags for manual review.\n\n"
        "**Leakage prevention**: Memory tiers have access controls - only the memory_librarian can write to LTM. "
        "A meta-memory layer tracks what's stored where, enabling garbage collection of stale entries."
    ),

    # -------------------------------------------------------------------------
    # LEARNING_CRITERIA: What triggers learning updates
    # Trigger: "How does the Learning Brain determine which interactions are
    #          successful enough to trigger updates?"
    # -------------------------------------------------------------------------
    SelfIntent.LEARNING_CRITERIA: (
        "My Learning Brain uses several success signals to decide what to learn from:\n\n"
        "**Explicit feedback**: User corrections, approvals, or ratings directly signal success/failure.\n"
        "**Task completion**: Did the multi-step task finish without errors or rollbacks?\n"
        "**Error rates**: Low error counts and no retry loops indicate successful patterns.\n"
        "**Consistency checks**: Outputs that pass validation and don't contradict known facts score higher.\n\n"
        "The system logs outcomes with scores. When a pattern exceeds a confidence threshold "
        "(typically after multiple successful uses), it gets promoted from tentative to established. "
        "Updates to routing policies require higher thresholds than updates to factual knowledge, "
        "since routing changes affect more of my behavior."
    ),

    # -------------------------------------------------------------------------
    # LEARNING_SAFETY: Safeguards against destabilization
    # Trigger: "What safeguards constrain the Learning Brain's self-modification?"
    # -------------------------------------------------------------------------
    SelfIntent.LEARNING_SAFETY: (
        "My self-modification capabilities have several safeguards:\n\n"
        "**Bounded modification scope**: The Learning Brain can adjust weights, thresholds, and heuristics, "
        "but core safety rules and architectural invariants are read-only.\n\n"
        "**Versioning**: Every change is versioned. If a modification causes problems, I can rollback.\n\n"
        "**Staged rollout**: Changes are tested on a subset of requests before full deployment. "
        "If error rates spike, the change gets reverted automatically.\n\n"
        "**Rate limiting**: Self-modifications are rate-limited to prevent runaway loops.\n\n"
        "**Audit logging**: All modifications are logged with before/after states for review.\n\n"
        "The goal is controllable evolution - I can improve over time without risking destabilization."
    ),

    # -------------------------------------------------------------------------
    # TOOL_ORCHESTRATION: Tool selection, sequencing, dependencies
    # Trigger: "How do you manage tool selection and coordination when multiple
    #          tools are needed for a single task?"
    # -------------------------------------------------------------------------
    SelfIntent.TOOL_ORCHESTRATION: (
        "When a task requires multiple tools, my tool_coordinator brain builds an execution plan:\n\n"
        "**Planning**: The coordinator analyzes the task, identifies required tools, and determines dependencies. "
        "For example, 'research and summarize' needs: web_search → content_extraction → summarization.\n\n"
        "**Sequencing**: Tools are ordered based on data dependencies. Tool A's output feeds Tool B's input. "
        "The plan is a mini-workflow with clear step ordering.\n\n"
        "**Execution**: Each tool runs and publishes results to the blackboard's tool_results lane. "
        "The next tool in sequence reads from there.\n\n"
        "**Error handling**: If a tool fails, the coordinator can retry, substitute an alternative tool, "
        "or gracefully degrade (return partial results with an explanation).\n\n"
        "**Result integration**: The final step aggregates all tool outputs into a coherent response."
    ),

    # -------------------------------------------------------------------------
    # UNKNOWN: Fallback for unrecognized self-questions
    # -------------------------------------------------------------------------
    SelfIntent.UNKNOWN: (
        "I'm Maven, a modular AI assistant with multiple cognitive brains and persistent memory. "
        "I can tell you about my architecture, how my brains coordinate, my memory system, "
        "my capabilities, my limitations, or how I differ from cloud models. "
        "What specific aspect would you like to know about?"
    ),
}


def classify_self_intent(question: str) -> SelfIntent:
    """
    HYBRID MAVEN SPEC: Classify a self-referential question into a SelfIntent.

    This provides tight mapping from question patterns to intents, ensuring
    coordination questions go to COORDINATION (not COMPARISON), memory questions
    go to MEMORY_MODEL, etc.

    Args:
        question: The user's question about Maven

    Returns:
        The classified SelfIntent
    """
    q = question.lower().strip()

    # =========================================================================
    # PRECISE INTENTS (HYBRID MAVEN SPEC v2) - check these FIRST
    # These are more specific than the general intents below
    # =========================================================================

    # -------------------------------------------------------------------------
    # BRAIN_COORDINATION - multi-mode reasoning, logic vs creativity
    # -------------------------------------------------------------------------
    brain_coordination_patterns = [
        "different types of reasoning",
        "logic vs creativity",
        "logic versus creativity",
        "analytic vs generative",
        "analytical vs creative",
        "analytical and creative",
        "balance reasoning",
        "mixed reasoning",
        "multiple reasoning modes",
        "multi-mode reasoning",
        "when different brains",
        "when brains disagree on approach",
        "creative and logical",
        "logical and creative",
        "creative thinking",
    ]
    if any(p in q for p in brain_coordination_patterns):
        return SelfIntent.BRAIN_COORDINATION

    # -------------------------------------------------------------------------
    # ROUTING_CONFLICT - conflict resolution, prioritization between brains
    # -------------------------------------------------------------------------
    routing_conflict_patterns = [
        "prioritization",
        "conflict resolution",
        "conflict between brains",
        "conflicting outputs",
        "arbitration",
        "message consistency",
        "outputs diverge",
        "brains disagree",
        "when brains conflict",
        "competing outputs",
        "resolve conflicts",
        "who wins when",
        "which brain takes priority",
        "priority between",
    ]
    if any(p in q for p in routing_conflict_patterns):
        return SelfIntent.ROUTING_CONFLICT

    # -------------------------------------------------------------------------
    # MEMORY_INTEGRATION - memory pipeline, leakage, inconsistencies
    # -------------------------------------------------------------------------
    memory_integration_patterns = [
        "memory integration",
        "memory leakage",
        "memory inconsistencies",
        "when you begin storing",
        "once you start storing",
        "handle storing facts",
        "consolidation",
        "memory provenance",
        "fact conflicts",
        "facts conflict",
        "contradictory facts",
        "memory versioning",
        "garbage collection",
        "stale entries",
        "how will memory work",
    ]
    if any(p in q for p in memory_integration_patterns):
        return SelfIntent.MEMORY_INTEGRATION

    # -------------------------------------------------------------------------
    # LEARNING_CRITERIA - what triggers learning updates
    # -------------------------------------------------------------------------
    learning_criteria_patterns = [
        "successful enough",
        "trigger updates",
        "trigger learning",
        "what gets learned",
        "decide what to learn",
        "learning threshold",
        "outcomes",
        "success signals",
        "when do you learn",
        "how do you decide to learn",
        "learning criteria",
        "what triggers",
        "promote to established",
        "promoted to established",
        "patterns get promoted",
    ]
    if any(p in q for p in learning_criteria_patterns):
        return SelfIntent.LEARNING_CRITERIA

    # -------------------------------------------------------------------------
    # LEARNING_SAFETY - safeguards against destabilization
    # -------------------------------------------------------------------------
    learning_safety_patterns = [
        "safeguards",
        "prevent destabil",
        "constrain",
        "self-modification safety",
        "modification limits",
        "policy drift",
        "runaway",
        "bounded modification",
        "modification scope",
        "rollback",
        "limits your learning",
        "limit your learning",
        "learning limits",
    ]
    # Check for "safeguard" + "learning/modification" co-occurrence
    if any(p in q for p in learning_safety_patterns):
        return SelfIntent.LEARNING_SAFETY
    # Also check for combined patterns
    if ("safety" in q and "learning" in q) or ("safety" in q and "modification" in q):
        return SelfIntent.LEARNING_SAFETY

    # -------------------------------------------------------------------------
    # TOOL_ORCHESTRATION - tool selection, sequencing, dependencies
    # -------------------------------------------------------------------------
    tool_orchestration_patterns = [
        "multiple tools",
        "tool selection",
        "tool coordination",
        "tool dependencies",
        "tool sequencing",
        "tools needed",
        "orchestrat",
        "tool workflow",
        "chain tools",
        "tools together",
        "tool order",
        "which tool",
        "choose tools",
        "inputs from multiple tools",
        "tool results",
        "tools in sequence",
        "sequence of tools",
        "sequence tools",
        "tool fails",
        "when a tool fails",
    ]
    if any(p in q for p in tool_orchestration_patterns):
        return SelfIntent.TOOL_ORCHESTRATION

    # =========================================================================
    # COORDINATION - general coordination questions (lower priority than above)
    # =========================================================================
    coordination_patterns = [
        "how do you coordinate",
        "how do your brains coordinate",
        "how do your modules coordinate",
        "how does your routing",
        "how do you route",
        "how do you decide what to do",
        "how do you decide which",
        "blackboard",
        "how do brains communicate",
        "how do modules communicate",
        "how do brains work together",
        "how do modules work together",
        "brain coordination",
        "module coordination",
        "routing system",
        "how are requests processed",
        "how do you process requests",
        "coordination mechanism",
    ]
    if any(p in q for p in coordination_patterns):
        return SelfIntent.COORDINATION

    # =========================================================================
    # MEMORY_MODEL - memory system structure questions
    # =========================================================================
    memory_patterns = [
        "memory system",
        "how does your memory",
        "how do you remember",
        "how is your memory organized",
        "memory structure",
        "memory architecture",
        "short term memory",
        "long term memory",
        "working memory",
        "domain banks",
        "memory tiers",
        "stm", "mtm", "ltm",
        "how do you store",
        "what do you remember",
        "persistent memory",
        "memory librarian",
    ]
    if any(p in q for p in memory_patterns):
        return SelfIntent.MEMORY_MODEL

    # =========================================================================
    # RECENT_LEARNING - what was learned from recent AI sessions
    # NOTE: Must NOT trigger on comparison questions like "different from chatgpt"
    # =========================================================================
    learning_patterns = [
        "what did you learn",
        "what did you just learn",
        "what have you learned",
        "what was learned",
        "what did you pick up",
        "what did you get from",
        "tell me what you learned",
        "share what you learned",
        "summarize what you learned",
        "report what you learned",
        "from the conversation",
        "from the session",
        "from that conversation",
        "learned recently",
        "learn recently",
        "last conversation",
        "last session",
    ]
    # Only match if it's about learning, not comparison
    # "from chatgpt" alone would match comparison questions like "different from chatgpt"
    if any(p in q for p in learning_patterns):
        return SelfIntent.RECENT_LEARNING

    # =========================================================================
    # LIMITATIONS - limitations and learning gaps
    # =========================================================================
    limitations_patterns = [
        "limitation",
        "what can't you",
        "what can you not",
        "what are you still learning",
        "what don't you know",
        "weakness",
        "what are your weaknesses",
        "what are you bad at",
        "where do you struggle",
        "challenges you face",
        "gaps in your knowledge",
        "things you can't do",
    ]
    if any(p in q for p in limitations_patterns):
        return SelfIntent.LIMITATIONS

    # =========================================================================
    # COMPARISON - explicit comparison with other AI
    # =========================================================================
    comparison_patterns = [
        "different from chatgpt",
        "different from claude",
        "different from grok",
        "different from gpt",
        "compare to chatgpt",
        "compare to claude",
        "compare to grok",
        "compared to chatgpt",
        "compared to claude",
        "compare yourself",
        "vs chatgpt",
        "vs claude",
        "vs gpt",
        "vs cloud",
        "versus chatgpt",
        "versus claude",
        "how are you different from",
        "what makes you different from",
        "how do you differ from",
        "differ from gpt",
        "differ from chatgpt",
        "differ from claude",
        "unlike other ai",
        "unlike cloud models",
        "maven vs",
    ]
    if any(p in q for p in comparison_patterns):
        return SelfIntent.COMPARISON

    # =========================================================================
    # ARCHITECTURE_DETAIL - brain groups, structure
    # =========================================================================
    architecture_patterns = [
        "architecture",
        "brain groups",
        "how are your brains organized",
        "how are your brains structured",
        "brain layout",
        "brain structure",
        "describe your brains",
        "what brains do you have",
        "what are your brains",
        "types of brains",
        "categories of brains",
        "how are you built",
        "how are you structured",
        "system architecture",
        "cognitive architecture",
    ]
    if any(p in q for p in architecture_patterns):
        return SelfIntent.ARCHITECTURE_DETAIL

    # =========================================================================
    # CAPABILITIES - what Maven can do
    # =========================================================================
    capabilities_patterns = [
        "what can you do",
        "what are you capable of",
        "what are you able to",
        "able to do",
        "capabilities",
        "abilities",
        "what are your skills",
        "what tools do you have",
        "what can you help with",
        "how can you help",
    ]
    if any(p in q for p in capabilities_patterns):
        return SelfIntent.CAPABILITIES

    # =========================================================================
    # IDENTITY - who/what Maven is (default for general identity questions)
    # =========================================================================
    identity_patterns = [
        "who are you",
        "what are you",
        "tell me about yourself",
        "introduce yourself",
        "what is maven",
        "what's maven",
        "describe yourself",
        "about yourself",
        "your name",
        "what's your name",
        "what is your name",
    ]
    if any(p in q for p in identity_patterns):
        return SelfIntent.IDENTITY

    # =========================================================================
    # UNKNOWN - fallback
    # =========================================================================
    return SelfIntent.UNKNOWN


# =============================================================================
# Dynamic Answer Generation (NO SCRIPTS - uses README + scans + Teacher)
# =============================================================================

def _get_readme_content() -> str:
    """Get key technical sections from README.md for dynamic answer generation."""
    try:
        from pathlib import Path
        readme_paths = [
            Path(__file__).parent.parent.parent.parent.parent / "README.md",
            Path(__file__).parent.parent.parent.parent / "README.md",
        ]
        for readme_path in readme_paths:
            if readme_path.exists():
                readme_content = readme_path.read_text(encoding='utf-8')

                # Extract key technical sections (not just first N chars)
                parts = []
                key_sections = [
                    ("## Architecture Overview", 800),
                    ("## Brain System", 600),
                    ("### Cognitive Brains", 400),
                    ("### Domain Banks", 200),
                    ("## Pipeline Stages", 600),
                    ("## Memory System", 400),
                ]

                for section_header, max_chars in key_sections:
                    if section_header in readme_content:
                        start = readme_content.find(section_header)
                        section_text = readme_content[start:start + max_chars]
                        parts.append(section_text)

                if parts:
                    return "\n".join(parts)
                else:
                    return readme_content[:3000]
    except Exception:
        pass
    return ""


def _get_system_scan_context() -> str:
    """Get system scan data for dynamic answers."""
    try:
        from brains.utils.system_scanner import get_system_summary
        summary = get_system_summary()
        by_type = summary.get("by_type", {})
        parts = [f"Total components: {summary.get('total_components', 0)}"]
        for comp_type, info in by_type.items():
            count = info.get('count', 0)
            if count > 0:
                parts.append(f"- {comp_type}: {count}")
        return "\n".join(parts)
    except Exception:
        return ""


def _generate_dynamic_answer(intent: SelfIntent, question: str) -> str:
    """
    Generate dynamic answer using Teacher LLM + README + scans.
    NO HARDCODED SCRIPTS - everything derived from actual sources.
    """
    # Get context from README and scans
    readme = _get_readme_content()
    scan_data = _get_system_scan_context()

    # Map intent to topic hint for the prompt
    intent_hints = {
        SelfIntent.IDENTITY: "who Maven is, its name and basic nature",
        SelfIntent.ARCHITECTURE_DETAIL: "Maven's architecture, brain organization, structure",
        SelfIntent.COORDINATION: "how Maven's brains coordinate, routing, blackboard",
        SelfIntent.MEMORY_MODEL: "Maven's memory system, tiers, persistence",
        SelfIntent.LIMITATIONS: "Maven's limitations, what it can't do, uncertainties",
        SelfIntent.COMPARISON: "how Maven differs from cloud AI like ChatGPT/Claude",
        SelfIntent.CAPABILITIES: "what Maven can do, tools, abilities",
        SelfIntent.BRAIN_COORDINATION: "how different reasoning modes work together",
        SelfIntent.ROUTING_CONFLICT: "how conflicts between brains are resolved",
        SelfIntent.MEMORY_INTEGRATION: "how memory integrates with other systems",
        SelfIntent.UNKNOWN: "general information about Maven",
    }
    topic_hint = intent_hints.get(intent, "general information about Maven")

    # Try Teacher LLM for dynamic generation
    try:
        from brains.cognitive.teacher.service.teacher_helper import get_teacher_helper
        teacher = get_teacher_helper()

        if teacher:
            prompt = f"""Based ONLY on the documentation below, answer about {topic_hint}.
If the documentation doesn't cover this, say "I'm not sure about that specific detail."

=== README DOCUMENTATION ===
{readme[:2000]}
=== END README ===

=== SYSTEM SCAN DATA ===
{scan_data}
=== END SCAN ===

Question: {question}

Answer as Maven (use "I", "my"). Be specific based on the documentation.
If something isn't documented, admit uncertainty. Keep answer to 3-5 sentences.

Answer:"""

            result = teacher.maybe_call_teacher(
                question=prompt,
                context={"topic": "self", "intent": intent.name}
            )

            if result and result.get("answer"):
                answer = str(result.get("answer", "")).strip()
                if answer and len(answer) > 20:
                    # Clean up any preamble
                    import re
                    answer = re.sub(r'^(Answer:|As Maven,?|Based on.*?:)\s*', '', answer, flags=re.IGNORECASE)
                    return answer
    except Exception as e:
        print(f"[SELF_KNOWLEDGE] Teacher generation failed: {e}")

    # Fallback: Generate simple answer from README content
    if readme:
        # Extract first paragraph that's not a header
        lines = [l.strip() for l in readme.split('\n') if l.strip() and not l.strip().startswith('#')]
        if lines:
            return f"Based on my documentation: {lines[0][:300]}"

    if scan_data:
        return f"From my system scan: {scan_data}"

    return "I'm not sure about that specific detail - my documentation may be unavailable."


def get_self_intent_answer(intent: SelfIntent, question: str = "") -> str:
    """
    Generate dynamic answer for a SelfIntent using README + scans + Teacher.

    NO HARDCODED SCRIPTS - answers are generated dynamically from actual sources.

    Args:
        intent: The classified SelfIntent
        question: The original question (for context)

    Returns:
        Dynamically generated answer
    """
    # Use dynamic generation instead of static blocks
    return _generate_dynamic_answer(intent, question)


def answer_by_intent(question: str) -> Dict[str, Any]:
    """
    HYBRID MAVEN SPEC: Answer a self-question using the intent-based system.

    This is the primary entry point for the intent-based answering system.
    It classifies the question, retrieves the answer block, and returns
    metadata for the caller.

    Args:
        question: The user's question about Maven

    Returns:
        Dict with intent, answer, and confidence
    """
    intent = classify_self_intent(question)

    # SPECIAL HANDLING: RECENT_LEARNING is dynamic, not from static blocks
    if intent == SelfIntent.RECENT_LEARNING:
        answer = _get_recent_learning_answer()
    else:
        # Pass question for context in dynamic generation
        answer = get_self_intent_answer(intent, question)

    return {
        "intent": intent.name,
        "answer": answer,
        "confidence": 0.95 if intent != SelfIntent.UNKNOWN else 0.7,
        "is_unknown": intent == SelfIntent.UNKNOWN,
    }


def _get_recent_learning_answer() -> str:
    """
    Generate dynamic answer for RECENT_LEARNING intent.

    Fetches from the ChatGPT session learnings module to report what
    was learned from the most recent AI conversation session.
    """
    try:
        from brains.tools.chatgpt_conversation_session import get_last_session_learnings
        learnings = get_last_session_learnings()

        if not learnings.get("ok"):
            return "I haven't had any recent conversation sessions to learn from."

        # Build dynamic answer from session learnings
        topic = learnings.get("topic", "an AI conversation")
        facts = learnings.get("facts", [])
        facts_count = learnings.get("facts_count", 0)
        patterns = learnings.get("patterns_learned", 0)
        summary = learnings.get("summary", "")

        if not facts and not summary:
            return (
                f"I had a conversation about {topic}, but I wasn't able to extract "
                f"specific insights from it. The session completed with {facts_count} "
                f"facts stored and {patterns} communication patterns learned."
            )

        # Build response with learned facts
        parts = [f"From my recent conversation about {topic}, I learned:"]

        if facts:
            for i, fact in enumerate(facts[:5], 1):  # Limit to 5 facts
                content = fact.get("content", "")
                if content:
                    parts.append(f"\n{i}. {content}")

        if summary and len(facts) < 2:
            # Include summary if we have few facts
            parts.append(f"\n\nSummary: {summary[:300]}")

        if patterns > 0:
            parts.append(f"\n\nI also learned {patterns} communication patterns from how ChatGPT structures responses.")

        return "".join(parts)

    except ImportError:
        return "I haven't had any recent conversation sessions to learn from."
    except Exception as e:
        return f"I had trouble retrieving my recent learnings: {e}"


# =============================================================================
# Accessor Functions
# =============================================================================

# Try to import system scanner for dynamic descriptions
try:
    from brains.utils.system_scanner import (
        get_system_scanner,
        get_dynamic_self_description as scanner_get_description,
        get_system_summary as scanner_get_summary,
        ComponentType,
    )
    _scanner_available = True
except ImportError:
    _scanner_available = False


def get_canonical_intro(style: str = "default", dynamic: bool = False) -> str:
    """
    Get the canonical self-introduction.

    Args:
        style: "default", "short", "technical", or "dynamic"
        dynamic: If True, use scanner to get actual component counts
    """
    if style == "dynamic" or dynamic:
        return get_dynamic_intro()
    if style == "short":
        return CANONICAL_INTRO_SHORT
    elif style == "technical":
        return get_dynamic_technical_intro()
    return CANONICAL_INTRO


def get_dynamic_intro() -> str:
    """
    Get a dynamic self-introduction based on actual discovered components.

    This combines the canonical voice with real component counts.
    """
    if not _scanner_available:
        return CANONICAL_INTRO

    try:
        scanner = get_system_scanner()
        scanner.scan_all()

        # Count by type
        cognitive = len(scanner.get_components_by_type(ComponentType.COGNITIVE_BRAIN))
        tools = len(scanner.get_components_by_type(ComponentType.TOOL))
        engines = len(scanner.get_components_by_type(ComponentType.ENGINE))
        routing = len(scanner.get_components_by_type(ComponentType.ROUTING_BRAIN))
        pipeline = len(scanner.get_components_by_type(ComponentType.PIPELINE_COMPONENT))
        memory = len(scanner.get_components_by_type(ComponentType.MEMORY_MODULE))

        return f"""I'm Maven, a modular AI assistant that runs locally with full system access.

I'm built from {cognitive} cognitive brains for reasoning and control, {tools} tool controllers for world interaction, {engines} execution engines, and {routing + pipeline} routing/pipeline modules.

My brains handle things like routing, memory, learning, and response synthesis; my tools handle browser automation (ChatGPT, Claude, Grok), web search, file operations, and system control.

Unlike cloud models, I have persistent memory ({memory} memory modules) and can modify my own code and heuristics, so I can actually learn and evolve over time.

This description is generated dynamically from my internal registry."""

    except Exception:
        return CANONICAL_INTRO


def get_dynamic_technical_intro() -> str:
    """Get a technical intro with actual component counts."""
    if not _scanner_available:
        return CANONICAL_INTRO_TECHNICAL

    try:
        scanner = get_system_scanner()
        summary = scanner.get_system_summary()

        by_type = summary.get("by_type", {})
        cognitive = by_type.get("cognitive_brain", {}).get("count", 0)
        tools = by_type.get("tool", {}).get("count", 0)
        engines = by_type.get("engine", {}).get("count", 0)
        routing = by_type.get("routing_brain", {}).get("count", 0)
        pipeline = by_type.get("pipeline_component", {}).get("count", 0)
        memory = by_type.get("memory_module", {}).get("count", 0)
        governance = by_type.get("governance", {}).get("count", 0)
        learning = by_type.get("learning", {}).get("count", 0)

        return f"""Maven is a modular cognitive architecture with:
- {cognitive} cognitive brains (routing, reasoning, memory, learning, response synthesis)
- {tools} interaction tools (browser control, web search, file ops, system control)
- {engines} execution engines
- {routing + pipeline} routing/pipeline components
- {memory} memory modules
- {governance} governance modules
- {learning} learning modules
- Persistent memory across sessions
- Online learning and self-modification capabilities
- Local execution with full system access

Total components discovered: {summary.get('total_components', 'unknown')}"""

    except Exception:
        return CANONICAL_INTRO_TECHNICAL


def get_taxonomy_definition(component_type: str) -> str:
    """Get the definition for brains, tools, or helpers."""
    if component_type in TAXONOMY:
        return TAXONOMY[component_type]["definition"]
    return ""


def get_taxonomy_summary() -> str:
    """Get the quick taxonomy summary."""
    return TAXONOMY_SUMMARY.strip()


def get_self_fact(key: str) -> str:
    """Get a specific self-fact by key."""
    return SELF_FACTS.get(key, "")


def get_all_self_facts() -> Dict[str, str]:
    """Get all self-facts."""
    return SELF_FACTS.copy()


def get_unique_aspects() -> List[Dict[str, str]]:
    """Get the list of unique architectural aspects."""
    return UNIQUE_ASPECTS.copy()


def get_unique_aspects_formatted() -> str:
    """Get unique aspects as formatted text."""
    lines = ["The most distinctive parts of my architecture are:"]
    for aspect in UNIQUE_ASPECTS:
        lines.append(f"- **{aspect['name']}** - {aspect['description']}")
    return "\n".join(lines)


def get_comparison_with(other_ai: str) -> str:
    """
    Get comparison facts with another AI.

    Args:
        other_ai: "chatgpt", "claude", "grok", etc.
    """
    other_lower = other_ai.lower()

    if "chatgpt" in other_lower or "gpt" in other_lower:
        return f"""Compared to ChatGPT:
- Environment: {SELF_FACTS['self.env.vs_chatgpt']}
- Learning: {SELF_FACTS['self.learning.vs_chatgpt']}
- Memory: {SELF_FACTS['self.memory.vs_chatgpt']}"""

    # Generic comparison for other AIs
    return f"""Compared to cloud-based models like {other_ai}:
- I run locally with full system access, not in a sandboxed cloud.
- I have persistent memory that accumulates across sessions.
- I can modify my own code and learn from interactions.
- I treat external AIs as tools/oracles, not as my core reasoning."""


def answer_self_question(question: str) -> str:
    """
    Answer a question about Maven using DYNAMIC generation from README + scans.

    NO HARDCODED SCRIPTS - everything is generated dynamically using Teacher LLM
    with README content and system scan data as context.
    """
    # Classify intent for context
    intent = classify_self_intent(question)
    print(f"[SELF_KNOWLEDGE] Classified intent: {intent.name} for question: '{question[:50]}...'")

    # Use dynamic generation for ALL questions - no static blocks
    return _generate_dynamic_answer(intent, question)


def _fallback_self_answer(q_lower: str) -> str:
    """
    HYBRID MAVEN SPEC: Provide a helpful fallback for unmatched self-questions.

    This ensures every question gets a meaningful response, not just a default intro.
    """
    # Try to provide contextual fallback based on question type
    if any(w in q_lower for w in ["feel", "emotion", "happy", "sad"]):
        return (
            "I don't have emotions in the way humans do. "
            "I'm a modular AI with specialized brains for reasoning and memory, "
            "but subjective feelings aren't something I can report on accurately."
        )

    if any(w in q_lower for w in ["think", "opinion", "believe"]):
        return (
            "I process information through my cognitive brains and can analyze topics, "
            "but I don't form personal opinions or beliefs in the human sense. "
            "I can help you explore different perspectives on a topic."
        )

    if any(w in q_lower for w in ["future", "predict", "will you"]):
        return (
            "I don't have the ability to predict my own future development. "
            "I can tell you about my current architecture and capabilities. "
            "My development roadmap is managed by my creators."
        )

    # Default fallback - provide intro with invitation to ask more specific questions
    return (
        f"{CANONICAL_INTRO}\n\n"
        "I'm not sure I understood your specific question. "
        "I can tell you about my architecture, brains, tools, memory system, "
        "or how I differ from cloud-based AI models. What would you like to know more about?"
    )


# =============================================================================
# MavenSystemInfo - Normalized Dynamic System Information
# =============================================================================

@dataclass
class MavenSystemInfo:
    """
    Normalized system information, built dynamically from the scanner.

    This provides a single interface for getting accurate system counts
    and descriptions, rather than hardcoded static values.

    Usage:
        info = MavenSystemInfo.build()
        print(f"I have {info.cognitive_brain_count} cognitive brains")
        print(info.short_intro)
    """
    cognitive_brain_count: int = 0
    tool_count: int = 0
    engine_count: int = 0
    routing_count: int = 0
    pipeline_count: int = 0
    memory_module_count: int = 0
    governance_count: int = 0
    learning_count: int = 0
    agent_count: int = 0
    total_components: int = 0

    # Generated descriptions
    short_intro: str = ""
    technical_intro: str = ""

    @classmethod
    def build(cls) -> "MavenSystemInfo":
        """Build a MavenSystemInfo from the system scanner."""
        info = cls()

        if not _scanner_available:
            # Fallback to static estimates
            info.cognitive_brain_count = 30
            info.tool_count = 20
            info.short_intro = CANONICAL_INTRO_SHORT
            info.technical_intro = _get_technical_intro_static()
            return info

        try:
            scanner = get_system_scanner()
            scanner.scan_all()

            # Get counts by type
            info.cognitive_brain_count = len(scanner.get_components_by_type(ComponentType.COGNITIVE_BRAIN))
            info.tool_count = len(scanner.get_components_by_type(ComponentType.TOOL))
            info.engine_count = len(scanner.get_components_by_type(ComponentType.ENGINE))
            info.routing_count = len(scanner.get_components_by_type(ComponentType.ROUTING_BRAIN))
            info.pipeline_count = len(scanner.get_components_by_type(ComponentType.PIPELINE_COMPONENT))
            info.memory_module_count = len(scanner.get_components_by_type(ComponentType.MEMORY_MODULE))
            info.governance_count = len(scanner.get_components_by_type(ComponentType.GOVERNANCE))
            info.learning_count = len(scanner.get_components_by_type(ComponentType.LEARNING))
            info.agent_count = len(scanner.get_components_by_type(ComponentType.AGENT))
            info.total_components = len(scanner.components)

            # Build dynamic descriptions
            info.short_intro = (
                f"I'm Maven, a modular local AI with {info.cognitive_brain_count} cognitive brains "
                f"and {info.tool_count} tools. I have persistent memory and can self-modify."
            )

            info.technical_intro = f"""Maven is a modular cognitive architecture with:
- {info.cognitive_brain_count} cognitive brains (routing, reasoning, memory, learning, response synthesis)
- {info.tool_count} interaction tools (browser control, web search, file ops, system control)
- {info.engine_count} execution engines
- {info.routing_count + info.pipeline_count} routing/pipeline components
- {info.memory_module_count} memory modules
- {info.governance_count} governance modules
- {info.learning_count} learning modules
- Persistent memory across sessions
- Online learning and self-modification capabilities
- Local execution with full system access

Total components discovered: {info.total_components}"""

        except Exception:
            # Fall back to static
            info.cognitive_brain_count = 30
            info.tool_count = 20
            info.short_intro = CANONICAL_INTRO_SHORT
            info.technical_intro = _get_technical_intro_static()

        return info

    def get_intro(self, style: str = "default") -> str:
        """Get an introduction in the specified style."""
        if style == "short":
            return self.short_intro
        elif style == "technical":
            return self.technical_intro
        else:
            return get_dynamic_intro()


def get_system_info() -> MavenSystemInfo:
    """Get current system information."""
    return MavenSystemInfo.build()


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    # Enums
    "SelfIntent",
    # Constants
    "CANONICAL_INTRO",
    "CANONICAL_INTRO_SHORT",
    "CANONICAL_INTRO_TECHNICAL",
    "TAXONOMY",
    "TAXONOMY_SUMMARY",
    "BRAIN_LAYOUT",
    "SELF_FACTS",
    "UNIQUE_ASPECTS",
    "SELF_INTENT_BLOCKS",
    # Classes
    "MavenSystemInfo",
    "SelfModelSnapshot",  # Canonical structured self-description
    # Functions - SelfModelSnapshot
    "build_self_model_snapshot",
    # Functions - canonical intro
    "get_canonical_intro",
    "get_dynamic_intro",
    "get_dynamic_technical_intro",
    # Functions - taxonomy
    "get_taxonomy_definition",
    "get_taxonomy_summary",
    # Functions - brain layout
    "get_brain_layout",
    "get_brain_layout_summary",
    # Functions - self facts
    "get_self_fact",
    "get_all_self_facts",
    "get_unique_aspects",
    "get_unique_aspects_formatted",
    "get_comparison_with",
    "answer_self_question",
    # Functions - intent-based answering (HYBRID MAVEN SPEC)
    "classify_self_intent",
    "get_self_intent_answer",
    "answer_by_intent",
    # Functions - system info
    "get_system_info",
]
