# brains/core/self_blocks.py
"""
Self-Description Blocks
=======================

Named text blocks for building Maven's self-descriptions.
Each block is a small template with placeholders that get filled from
the system_registry at runtime.

These are NOT brains - they're data + interpolation.
EVA (response synthesis) assembles these into final answers.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, Optional, List, Set
from dataclasses import dataclass, field
from enum import Enum


class SelfIntent(str, Enum):
    """Types of self-questions Maven can answer."""
    IDENTITY = "self_identity"
    ARCHITECTURE_HIGHLEVEL = "self_architecture_highlevel"
    ARCHITECTURE_DETAIL = "self_architecture_detail"
    CAPABILITIES = "self_capabilities"
    LIMITATIONS = "self_limitations"
    COMPARISON = "self_comparison"
    META_REFLECTION = "self_meta_reflection"
    BRAINS = "self_brains"
    TOOLS = "self_tools"
    MEMORY = "self_memory"
    LEARNING = "self_learning"
    HEALTH = "self_health"
    HISTORY = "self_history"


@dataclass
class SelfBlock:
    """A self-description block with template and metadata."""
    id: str
    template: str
    short_template: str = ""
    placeholders: Set[str] = field(default_factory=set)
    applicable_intents: Set[SelfIntent] = field(default_factory=set)
    priority: int = 0  # Lower = higher priority when selecting blocks

    def fill(self, registry_data: Dict[str, Any]) -> str:
        """Fill template placeholders with registry data."""
        result = self.template
        for key, value in registry_data.items():
            placeholder = f"{{{key}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(value))
        return result

    def fill_short(self, registry_data: Dict[str, Any]) -> str:
        """Fill short template with registry data."""
        template = self.short_template or self.template
        result = template
        for key, value in registry_data.items():
            placeholder = f"{{{key}}}"
            if placeholder in result:
                result = result.replace(placeholder, str(value))
        return result


# =============================================================================
# Self-Description Block Library
# =============================================================================

SELF_BLOCKS: Dict[str, SelfBlock] = {}


def _register_block(block: SelfBlock) -> None:
    """Register a self-description block."""
    SELF_BLOCKS[block.id] = block


# --- Identity Block ---
_register_block(SelfBlock(
    id="self.identity",
    template="""I'm Maven, a modular AI assistant that runs locally with full system access.

I'm built from {total_brains} cognitive brains for reasoning and control, plus {total_tools} tools for interacting with the world.

Unlike cloud models, I have persistent memory and can modify my own code and heuristics, so I can actually learn and evolve over time.""",
    short_template="I'm Maven, a modular AI assistant with {total_brains} brains and {total_tools} tools, running locally with persistent memory.",
    placeholders={"total_brains", "total_tools"},
    applicable_intents={SelfIntent.IDENTITY},
    priority=0,
))


# --- Brain Overview Block ---
_register_block(SelfBlock(
    id="self.brain_overview",
    template="""My brains are cognitive modules that handle different aspects of reasoning:
- Routing brains analyze requests and decide which modules to activate
- Reasoning brains handle logic, planning, and problem-solving
- Memory brains manage knowledge storage and retrieval
- Learning brains update my heuristics based on experience
- Response synthesis brains produce my final voice

I have {cognitive_brains} cognitive brains and {routing_brains} routing modules.""",
    short_template="I have {cognitive_brains} cognitive brains for reasoning, memory, learning, and response synthesis.",
    placeholders={"cognitive_brains", "routing_brains"},
    applicable_intents={SelfIntent.BRAINS, SelfIntent.ARCHITECTURE_HIGHLEVEL},
    priority=1,
))


# --- Tools Overview Block ---
_register_block(SelfBlock(
    id="self.tools_overview",
    template="""My tools let me act on the world. They don't decide - they execute what my brains instruct.

Tool categories:
- Browser tools: ChatGPT, Claude, Grok automation
- Web search: Information retrieval from the internet
- File tools: Read, write, and manage local files
- System tools: Shell commands and system control
- Git: Version control operations

I have {total_tools} tool controllers.""",
    short_template="I have {total_tools} tools for browser automation, web search, file operations, and system control.",
    placeholders={"total_tools"},
    applicable_intents={SelfIntent.TOOLS, SelfIntent.CAPABILITIES},
    priority=1,
))


# --- Routing Summary Block ---
_register_block(SelfBlock(
    id="self.routing_summary",
    template="""My brains communicate through a shared blackboard plus a routing brain that passes structured messages.

The routing process:
1. Input arrives and gets normalized
2. The router classifies intent and chooses which brains should think
3. Activated brains write results to the blackboard
4. The response synthesis brain produces my final answer in my own voice

All internal communication happens on blackboard "lanes" - tool_results, answer_drafts, and maven_voice.""",
    short_template="My brains communicate through a shared blackboard. A routing brain decides which modules to activate, and they write results to shared lanes.",
    placeholders=set(),
    applicable_intents={SelfIntent.ARCHITECTURE_DETAIL},
    priority=2,
))


# --- Memory Summary Block ---
_register_block(SelfBlock(
    id="self.memory_summary",
    template="""I have persistent, first-class memory as a core subsystem, not an add-on.

Memory structure:
- Working memory: Current conversation context
- Short-term: Recent interactions and temporary facts
- Long-term: Accumulated knowledge across sessions
- Domain banks: Specialized knowledge stores ({domain_banks} domains)

I have {memory_modules} memory modules managing storage and retrieval.""",
    short_template="I have {memory_modules} memory modules with persistent storage across sessions.",
    placeholders={"memory_modules", "domain_banks"},
    applicable_intents={SelfIntent.MEMORY, SelfIntent.ARCHITECTURE_DETAIL},
    priority=2,
))


# --- Learning Summary Block ---
_register_block(SelfBlock(
    id="self.learning_summary",
    template="""I have a dedicated Learning Brain that can modify my own code and policies.

Learning capabilities:
- Pattern recognition on successful interactions
- Routing policy updates based on outcomes
- Heuristic adjustment from feedback
- Self-modification (because I run locally)

This is different from cloud models which cannot update their own weights between sessions.""",
    short_template="I have a Learning Brain that updates my heuristics and can modify my own code and policies.",
    placeholders=set(),
    applicable_intents={SelfIntent.LEARNING, SelfIntent.CAPABILITIES},
    priority=2,
))


# --- Action Capabilities Block ---
_register_block(SelfBlock(
    id="self.action_capabilities",
    template="""I can act through tools that:
- Control a browser (navigate, click, type)
- Converse with external AIs (ChatGPT, Claude, Grok)
- Perform web searches
- Run allowed system commands
- Read and write local files
- Manage git repositories

My brains decide what to do; the tools execute it. I always maintain my own voice even when consulting external AIs.""",
    short_template="I can control browsers, talk to external AIs, search the web, run commands, manage files, and use git.",
    placeholders=set(),
    applicable_intents={SelfIntent.CAPABILITIES},
    priority=1,
))


# --- Safety Summary Block ---
_register_block(SelfBlock(
    id="self.safety_summary",
    template="""I have safety layers governing what I can and cannot do:
- Web access tools require appropriate context
- PC control requires careful use
- Social media posting requires confirmation
- Some tools have no external side effects (safe for any use)

Safety is enforced by governance modules and tool-level tags.""",
    short_template="I have safety layers governing web access, PC control, and social media interactions.",
    placeholders=set(),
    applicable_intents={SelfIntent.LIMITATIONS},
    priority=3,
))


# --- Comparison to Cloud LLMs Block ---
_register_block(SelfBlock(
    id="self.comparison_cloud_llms",
    template="""Compared to cloud-based models like ChatGPT or Claude:

Environment:
- I run locally with system and file access
- They run in sandboxed cloud environments

Memory:
- I have persistent memory that accumulates across sessions
- They have primarily short-term context per conversation

Learning:
- I can perform genuine online learning and self-modification
- They cannot update their own weights from interactions

Self-knowledge:
- I can inspect my own code and architecture
- They operate as black boxes to themselves""",
    short_template="Unlike cloud models, I run locally with persistent memory, can self-modify, and can inspect my own code.",
    placeholders=set(),
    applicable_intents={SelfIntent.COMPARISON},
    priority=1,
))


# --- Health Status Block ---
_register_block(SelfBlock(
    id="self.health_status",
    template="""System Status: {health_level}

Components: {healthy_components}/{total_components} healthy
Registered: {registered_components}
Discovered: {discovered_components}

{health_message}""",
    short_template="{health_level}: {healthy_components}/{total_components} components healthy",
    placeholders={"health_level", "healthy_components", "total_components", "registered_components", "discovered_components", "health_message"},
    applicable_intents={SelfIntent.HEALTH},
    priority=0,
))


# =============================================================================
# Block Selection Logic
# =============================================================================

def get_blocks_for_intent(intent: SelfIntent) -> List[SelfBlock]:
    """Get relevant blocks for a self-intent, sorted by priority."""
    blocks = [b for b in SELF_BLOCKS.values() if intent in b.applicable_intents]
    return sorted(blocks, key=lambda b: b.priority)


def get_block(block_id: str) -> Optional[SelfBlock]:
    """Get a specific block by ID."""
    return SELF_BLOCKS.get(block_id)


def get_all_block_ids() -> List[str]:
    """Get all registered block IDs."""
    return list(SELF_BLOCKS.keys())


# =============================================================================
# Intent Detection
# =============================================================================

# Patterns for detecting self-intent type from questions
INTENT_PATTERNS: Dict[SelfIntent, List[str]] = {
    SelfIntent.IDENTITY: [
        "who are you", "what are you", "yourself", "your name",
        "introduce", "tell me about you",
    ],
    SelfIntent.ARCHITECTURE_HIGHLEVEL: [
        "how do you work", "architecture", "how are you built",
        "structure", "composed of",
    ],
    SelfIntent.ARCHITECTURE_DETAIL: [
        "how do your brains", "communicate", "blackboard",
        "routing", "how do modules",
    ],
    SelfIntent.CAPABILITIES: [
        "can you", "what can you do", "are you able",
        "what tools", "what actions",
    ],
    SelfIntent.LIMITATIONS: [
        "can't", "cannot", "limitation", "restricted",
        "safe", "safety", "allowed",
    ],
    SelfIntent.COMPARISON: [
        "chatgpt", "claude", "grok", "compare", "differ",
        "vs", "versus", "different from",
    ],
    SelfIntent.BRAINS: [
        "brain", "brains", "cognitive", "module",
        "how many brain", "reasoning",
    ],
    SelfIntent.TOOLS: [
        "tool", "tools", "capability",
    ],
    SelfIntent.MEMORY: [
        "memory", "remember", "forget", "store",
        "long-term", "short-term",
    ],
    SelfIntent.LEARNING: [
        "learn", "learning", "improve", "evolve",
        "self-modify", "update",
    ],
    SelfIntent.HEALTH: [
        "health", "status", "diagnose", "working",
        "broken", "check",
    ],
    SelfIntent.HISTORY: [
        "what did we", "what did i", "conversation",
        "earlier", "before",
    ],
}


def detect_self_intent(query: str) -> Optional[SelfIntent]:
    """Detect the self-intent type from a query."""
    q_lower = query.lower()

    # Check patterns in order of specificity
    for intent, patterns in INTENT_PATTERNS.items():
        if any(p in q_lower for p in patterns):
            return intent

    return None


def extract_focus_words(query: str) -> List[str]:
    """Extract focus words from a self-query."""
    focus_keywords = [
        "brain", "brains", "tool", "tools", "memory", "learning",
        "routing", "blackboard", "safety", "capability", "architecture",
    ]
    q_lower = query.lower()
    return [kw for kw in focus_keywords if kw in q_lower]


# =============================================================================
# Registry Data Extraction
# =============================================================================

def get_registry_data() -> Dict[str, Any]:
    """
    Get current data from system registry and scanner for filling blocks.

    Returns:
        Dict with keys matching block placeholders
    """
    data = {
        "total_brains": 0,
        "total_tools": 0,
        "cognitive_brains": 0,
        "routing_brains": 0,
        "memory_modules": 0,
        "domain_banks": 0,
        "healthy_components": 0,
        "total_components": 0,
        "registered_components": 0,
        "discovered_components": 0,
        "health_level": "UNKNOWN",
        "health_message": "",
    }

    # Try to get data from scanner
    try:
        from brains.utils.system_scanner import get_system_scanner, ComponentType
        scanner = get_system_scanner()
        scanner.scan_all()
        summary = scanner.get_system_summary()

        by_type = summary.get("by_type", {})
        data["cognitive_brains"] = by_type.get("cognitive_brain", {}).get("count", 0)
        data["routing_brains"] = by_type.get("routing_brain", {}).get("count", 0)
        data["total_brains"] = data["cognitive_brains"] + data["routing_brains"]
        data["total_tools"] = by_type.get("tool", {}).get("count", 0)
        data["memory_modules"] = by_type.get("memory_module", {}).get("count", 0)
        data["total_components"] = summary.get("total_components", 0)
        data["discovered_components"] = data["total_components"]
    except ImportError:
        pass

    # Try to get domain bank count
    try:
        from pathlib import Path
        domain_path = Path(__file__).parent.parent / "domain_banks"
        if domain_path.exists():
            data["domain_banks"] = len([d for d in domain_path.iterdir()
                                        if d.is_dir() and not d.name.startswith("_")])
    except Exception:
        pass

    # Try to get health data from introspection
    try:
        from brains.cognitive.self_introspection.service.diagnostics_utils import get_system_health
        from brains.cognitive.self_introspection.service.consistency_utils import check_consistency
        health = get_system_health()
        data["health_level"] = health.level.value.upper()
        data["healthy_components"] = health.components_healthy
        data["health_message"] = health.message

        report = check_consistency(verify_imports=False)
        data["registered_components"] = report.total_registered
    except ImportError:
        pass

    return data


# =============================================================================
# Block Assembly
# =============================================================================

def assemble_self_answer(
    intent: SelfIntent,
    max_blocks: int = 3,
    short_form: bool = False,
    registry_data: Optional[Dict[str, Any]] = None,
    query: str = "",
) -> str:
    """
    Assemble a self-answer from blocks using SYNTHESIS.

    This function gathers structured facts from blocks and synthesizes
    a natural response instead of just concatenating template strings.

    Args:
        intent: The self-intent to answer
        max_blocks: Maximum number of blocks to include
        short_form: Use short templates (brief response)
        registry_data: Pre-fetched registry data (optional)
        query: The original user query for context adaptation

    Returns:
        Synthesized answer text
    """
    import re

    if registry_data is None:
        registry_data = get_registry_data()

    blocks = get_blocks_for_intent(intent)[:max_blocks]

    if not blocks:
        return "I can answer questions about my architecture, capabilities, and design."

    # Gather facts from blocks
    facts = []
    for block in blocks:
        if short_form:
            text = block.fill_short(registry_data)
        else:
            text = block.fill(registry_data)
        facts.append(text)

    # Try to synthesize instead of just joining
    try:
        from brains.tools.llm_service import llm_service

        # Determine detail level from context
        detail_level = "brief" if short_form else "standard"
        intent_name = intent.value if hasattr(intent, 'value') else str(intent)

        synthesis_prompt = f"""Maven has these facts about itself for a {intent_name} question:
{chr(10).join(f'- {fact[:200]}' for fact in facts)}

Registry data summary:
- Brains: {registry_data.get('total_brains', 0)} total
- Tools: {registry_data.get('total_tools', 0)} available
- Health: {registry_data.get('health_level', 'unknown')}

User query: "{query if query else 'tell me about yourself'}"
Detail level: {detail_level}

Synthesize a natural response in first person:
- Be conversational, not robotic
- Use Maven's voice (direct, helpful)
- {"Keep it brief (1-2 sentences)" if short_form else "Be informative (2-4 sentences)"}
- DO NOT add information not in the facts above

Maven's response:"""

        result = llm_service.call(
            prompt=synthesis_prompt,
            max_tokens=200 if short_form else 400,
            temperature=0.6,
        )

        if result.get("ok") and result.get("text"):
            response = str(result["text"]).strip()
            # Clean up common LLM artifacts
            response = re.sub(
                r"^(Here's|Sure,|Certainly,|Of course,|Absolutely,)\s*",
                "",
                response,
                flags=re.IGNORECASE,
            )
            response = re.sub(
                r"^(Maven's response:|Response:|Answer:)\s*",
                "",
                response,
                flags=re.IGNORECASE,
            )
            print(f"[SELF_BLOCKS] Synthesized {intent_name} answer: {len(facts)} facts → {len(response)} chars")
            return response

    except Exception as e:
        print(f"[SELF_BLOCKS] Synthesis failed: {e}, using fallback")

    # Fallback: Join facts with proper spacing
    return "\n\n".join(facts)


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "SelfIntent",
    "SelfBlock",
    "SELF_BLOCKS",
    "get_blocks_for_intent",
    "get_block",
    "get_all_block_ids",
    "detect_self_intent",
    "extract_focus_words",
    "get_registry_data",
    "assemble_self_answer",
]
