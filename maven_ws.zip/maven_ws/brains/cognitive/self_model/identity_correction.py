"""
Identity Correction System
==========================

ARCHITECTURAL PRINCIPLE: Memory stores ALL facts. Self-Model CORRECTS errors.

This module implements the identity correction system that:
1. Detects facts that contradict Maven's canonical identity
2. Stores CORRECTION facts (does NOT delete wrong facts)
3. Tags wrong facts as "contradicted" for reasoning to deprioritize
4. Enables learning from Teacher's mistakes

GOVERNANCE PRINCIPLE:
- Governance controls ACTIONS, not KNOWLEDGE
- Memory stores ALL facts (true and false)
- Self-Model detects and corrects identity errors
- Reasoning chooses which facts to trust based on reliability scores

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

from typing import Dict, List, Any, Optional, Tuple
import time
import json

# Import canonical identity facts
from brains.cognitive.self_model.system_identity import (
    CANONICAL_IDENTITY,
    NEGATIVE_IDENTITY,
    ALL_IDENTITY_FACTS,
)

# Import memory for storing corrections
try:
    from brains.memory.brain_memory import BrainMemory
    _memory_available = True
except ImportError:
    _memory_available = False
    BrainMemory = None  # type: ignore


# =============================================================================
# IDENTITY CONTRADICTION DETECTION
# =============================================================================

# Patterns that indicate potential identity errors
# These are checked against canonical identity to detect contradictions
IDENTITY_ERROR_PATTERNS = {
    # Pattern: (error_pattern, canonical_fact_key, correction_template)
    "large language model": {
        "error_type": "wrong_architecture",
        "canonical_correction": "Maven is NOT a large language model. Maven is a cognitive architecture that USES LLMs (like Teacher) as tools/oracles.",
        "severity": "high",
    },
    "created by anthropic": {
        "error_type": "wrong_creator",
        "canonical_correction": "Maven was NOT created by Anthropic. Maven was created by Josh Hinkle as a local, self-modifying AI assistant.",
        "severity": "high",
    },
    "created by openai": {
        "error_type": "wrong_creator",
        "canonical_correction": "Maven was NOT created by OpenAI. Maven was created by Josh Hinkle as a local, self-modifying AI assistant.",
        "severity": "high",
    },
    "created by google": {
        "error_type": "wrong_creator",
        "canonical_correction": "Maven was NOT created by Google. Maven was created by Josh Hinkle as a local, self-modifying AI assistant.",
        "severity": "high",
    },
    "i am an llm": {
        "error_type": "wrong_architecture",
        "canonical_correction": "Maven is NOT an LLM. Maven is a cognitive architecture with multiple specialized brains, using LLMs as external tools.",
        "severity": "high",
    },
    "chatgpt": {
        "error_type": "wrong_identity",
        "canonical_correction": "Maven is NOT ChatGPT. Maven is a distinct cognitive architecture created by Josh Hinkle.",
        "severity": "high",
    },
    "gpt-4": {
        "error_type": "wrong_identity",
        "canonical_correction": "Maven is NOT GPT-4. Maven is a distinct cognitive architecture that may use GPT models as external tools.",
        "severity": "medium",
    },
    "gpt-3": {
        "error_type": "wrong_identity",
        "canonical_correction": "Maven is NOT GPT-3. Maven is a distinct cognitive architecture that may use GPT models as external tools.",
        "severity": "medium",
    },
    "apache maven": {
        "error_type": "name_confusion",
        "canonical_correction": "Maven (the AI) is NOT Apache Maven (the build tool). Maven is a cognitive AI assistant created by Josh Hinkle.",
        "severity": "high",
    },
    "pom file": {
        "error_type": "name_confusion",
        "canonical_correction": "Maven (the AI) does not use POM files. That's Apache Maven (the Java build tool). This Maven is a cognitive AI assistant.",
        "severity": "medium",
    },
    "i don't have feelings": {
        "error_type": "cloud_model_hallucination",
        "canonical_correction": "Maven does not make claims about lacking feelings. Maven is a cognitive architecture that runs locally with persistent memory and self-modification capabilities.",
        "severity": "low",
    },
    "i am not sentient": {
        "error_type": "cloud_model_hallucination",
        "canonical_correction": "Maven does not make categorical claims about sentience. Maven is a cognitive architecture focused on practical capabilities.",
        "severity": "low",
    },
    "cloud-based ai": {
        "error_type": "wrong_deployment",
        "canonical_correction": "Maven is NOT a cloud-based AI. Maven runs locally with full system access, persistent memory, and self-modification capabilities.",
        "severity": "high",
    },
}


def detect_identity_contradiction(
    fact_content: str,
    fact_metadata: Optional[Dict[str, Any]] = None,
) -> Optional[Dict[str, Any]]:
    """
    Detect if a fact contradicts Maven's canonical identity.

    Args:
        fact_content: The content of the fact to check
        fact_metadata: Optional metadata dict

    Returns:
        Dict with contradiction details if found, None otherwise
    """
    fact_lower = fact_content.lower()

    for pattern, error_info in IDENTITY_ERROR_PATTERNS.items():
        if pattern in fact_lower:
            return {
                "contradiction_detected": True,
                "pattern_matched": pattern,
                "error_type": error_info["error_type"],
                "canonical_correction": error_info["canonical_correction"],
                "severity": error_info["severity"],
                "original_fact": fact_content,
                "timestamp": time.time(),
            }

    return None


def create_correction_fact(
    contradiction: Dict[str, Any],
    original_fact_id: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Create a correction fact for a detected contradiction.

    The correction fact is stored IN ADDITION to the wrong fact.
    The wrong fact is tagged as "contradicted", not deleted.

    Args:
        contradiction: Dict from detect_identity_contradiction()
        original_fact_id: Optional ID of the original wrong fact

    Returns:
        Correction fact dict ready for storage
    """
    correction = {
        "content": f"CORRECTION: {contradiction['canonical_correction']}",
        "domain": "maven_self",
        "importance": 1.0,  # High importance - corrections are authoritative
        "tags": [
            "identity",
            "correction",
            "self_knowledge",
            "canonical",
            "self_model_generated",
        ],
        "metadata": {
            "corrects_pattern": contradiction["pattern_matched"],
            "error_type": contradiction["error_type"],
            "severity": contradiction["severity"],
            "original_fact_id": original_fact_id,
            "correction_source": "self_model",
            "timestamp": time.time(),
        },
        "source": "self_introspection",
        "confidence": 1.0,  # Corrections from canonical identity are certain
    }

    return correction


# =============================================================================
# IDENTITY CORRECTION SCANNER
# =============================================================================

def scan_and_correct_identity_errors(
    memory_librarian=None,
    domain: str = "factual",
) -> Dict[str, Any]:
    """
    Scan memory for identity errors and store corrections.

    This function:
    1. Searches for facts tagged with "needs_self_model_review"
    2. Checks each against canonical identity
    3. Stores CORRECTION facts for contradictions found
    4. Tags original facts as "contradicted" (does NOT delete them)

    Args:
        memory_librarian: Memory librarian instance (or use default)
        domain: Domain to scan (default: factual)

    Returns:
        Dict with scan results
    """
    results = {
        "scanned": 0,
        "contradictions_found": 0,
        "corrections_stored": 0,
        "facts_tagged": 0,
        "errors": [],
    }

    # Get memory instance
    if memory_librarian is None:
        if not _memory_available:
            results["errors"].append("Memory not available")
            return results
        try:
            memory_librarian = BrainMemory(domain)
        except Exception as e:
            results["errors"].append(f"Failed to initialize memory: {e}")
            return results

    # Search for facts needing review
    try:
        # Try to search for tagged facts
        if hasattr(memory_librarian, "search"):
            facts_to_review = memory_librarian.search(
                tags=["needs_self_model_review"],
            )
        else:
            # Fallback: get recent facts
            facts_to_review = []

        if not facts_to_review:
            print("[IDENTITY_CORRECTION] No facts tagged for review")
            return results

    except Exception as e:
        results["errors"].append(f"Search failed: {e}")
        return results

    print(f"[IDENTITY_CORRECTION] Scanning {len(facts_to_review)} facts for identity errors...")

    for fact in facts_to_review:
        results["scanned"] += 1

        # Get fact content
        content = fact.get("content", "") if isinstance(fact, dict) else str(fact)

        # Check for contradiction
        contradiction = detect_identity_contradiction(content)

        if contradiction:
            results["contradictions_found"] += 1

            # Get original fact ID if available
            fact_id = fact.get("id") if isinstance(fact, dict) else None

            # Create correction fact
            correction_fact = create_correction_fact(contradiction, fact_id)

            # Store correction
            try:
                if hasattr(memory_librarian, "store"):
                    memory_librarian.store(
                        content=correction_fact["content"],
                        metadata=correction_fact["metadata"],
                    )
                    results["corrections_stored"] += 1
                    print(f"[IDENTITY_CORRECTION] Stored correction for: {contradiction['pattern_matched']}")

                # Tag original fact as contradicted (don't delete it)
                if fact_id and hasattr(memory_librarian, "update_tags"):
                    memory_librarian.update_tags(
                        fact_id=fact_id,
                        add_tags=["contradicted", "corrected_by_self_model"],
                        remove_tags=["needs_self_model_review"],
                    )
                    results["facts_tagged"] += 1

            except Exception as e:
                results["errors"].append(f"Failed to store correction: {e}")

    print(f"[IDENTITY_CORRECTION] Scan complete: {results['contradictions_found']} contradictions, "
          f"{results['corrections_stored']} corrections stored")

    return results


# =============================================================================
# META-LEARNING: Track Teacher Error Patterns
# =============================================================================

def record_teacher_error_pattern(
    error_pattern: str,
    error_type: str,
    fact_content: str,
    memory_librarian=None,
) -> Dict[str, Any]:
    """
    Record a meta-lesson about Teacher's error patterns.

    This enables Maven to learn from Teacher's mistakes over time.
    Example: "Teacher has hallucinated Maven's identity as LLM 5 times"

    Args:
        error_pattern: The pattern that triggered the error
        error_type: Type of error (wrong_architecture, wrong_creator, etc.)
        fact_content: The original fact content
        memory_librarian: Optional memory librarian

    Returns:
        Dict with recording status
    """
    meta_lesson = {
        "content": f"META-LESSON: Teacher hallucinated identity error. Pattern: '{error_pattern}', Type: {error_type}. "
                   f"This is the incorrect claim Maven needs to counter.",
        "domain": "maven_self",
        "importance": 0.8,
        "tags": [
            "meta_lesson",
            "teacher_error",
            "identity_correction",
            "learning",
        ],
        "metadata": {
            "error_pattern": error_pattern,
            "error_type": error_type,
            "original_claim": fact_content[:200],
            "timestamp": time.time(),
        },
        "source": "self_introspection",
    }

    if memory_librarian is None:
        if not _memory_available:
            return {"ok": False, "error": "Memory not available"}
        try:
            memory_librarian = BrainMemory("maven_self")
        except Exception as e:
            return {"ok": False, "error": str(e)}

    try:
        if hasattr(memory_librarian, "store"):
            memory_librarian.store(
                content=meta_lesson["content"],
                metadata=meta_lesson["metadata"],
            )
            print(f"[META_LESSON] Recorded Teacher error pattern: {error_pattern}")
            return {"ok": True, "lesson": meta_lesson["content"]}
    except Exception as e:
        return {"ok": False, "error": str(e)}

    return {"ok": False, "error": "Storage method not available"}


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Detection
    "detect_identity_contradiction",
    "IDENTITY_ERROR_PATTERNS",
    # Correction
    "create_correction_fact",
    "scan_and_correct_identity_errors",
    # Meta-learning
    "record_teacher_error_pattern",
]
