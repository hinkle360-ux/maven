"""
Context Relevance Scoring
=========================

A helper module for context-aware dialogue memory. Provides functions to:
1. Score memory items by relevance to the current conversation turn
2. Rank and select top-k context items for the blackboard
3. Decide promotion/decay for memory tier management

This is NOT a brain - it's a pure function helper used by:
- memory_librarian (for context retrieval)
- integrator (for context selection before routing)
- language_brain (for response generation context)

The scoring combines:
- recency_score: Based on timestamp/turn distance
- topic_overlap_score: Keyword/semantic overlap with current query
- source_confidence: From dynamic_confidence module
- use_count: How often this memory was referenced recently
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import re
import math


# Configuration thresholds
PROMOTE_THRESHOLD = 0.75  # Score above this -> promote to higher tier
DECAY_THRESHOLD = 0.25    # Score below this -> decay/archive
RECENCY_HALF_LIFE_TURNS = 10  # Turn distance for 50% recency decay
RECENCY_HALF_LIFE_HOURS = 24  # Time distance for 50% recency decay


def _extract_keywords(text: str) -> set:
    """Extract meaningful keywords from text."""
    if not text:
        return set()

    # Lowercase and split
    text_lower = text.lower()

    # Remove punctuation
    text_clean = re.sub(r'[^\w\s]', ' ', text_lower)

    # Split into words
    words = text_clean.split()

    # Filter stopwords
    stopwords = {
        'the', 'a', 'an', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
        'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could',
        'should', 'may', 'might', 'must', 'shall', 'can', 'need', 'dare',
        'ought', 'used', 'to', 'of', 'in', 'for', 'on', 'with', 'at', 'by',
        'from', 'up', 'about', 'into', 'over', 'after', 'beneath', 'under',
        'above', 'and', 'but', 'or', 'nor', 'so', 'yet', 'both', 'either',
        'neither', 'not', 'only', 'own', 'same', 'than', 'too', 'very',
        'just', 'that', 'this', 'these', 'those', 'what', 'which', 'who',
        'whom', 'whose', 'when', 'where', 'why', 'how', 'all', 'each',
        'every', 'any', 'some', 'no', 'none', 'one', 'two', 'few', 'more',
        'most', 'other', 'such', 'much', 'many', 'i', 'me', 'my', 'myself',
        'we', 'our', 'ours', 'ourselves', 'you', 'your', 'yours', 'yourself',
        'he', 'him', 'his', 'himself', 'she', 'her', 'hers', 'herself',
        'it', 'its', 'itself', 'they', 'them', 'their', 'theirs', 'themselves',
    }

    return {w for w in words if len(w) > 2 and w not in stopwords}


def _compute_recency_score(
    item_timestamp: Optional[str],
    item_turn_index: Optional[int],
    current_turn_index: int = 0,
    current_time: Optional[datetime] = None
) -> float:
    """
    Compute recency score based on turn distance and time elapsed.

    Uses exponential decay with configurable half-life.
    Returns a score between 0.0 (very old) and 1.0 (very recent).
    """
    if current_time is None:
        current_time = datetime.utcnow()

    turn_score = 1.0
    time_score = 1.0

    # Turn-based recency
    if item_turn_index is not None and current_turn_index > 0:
        turn_distance = max(0, current_turn_index - item_turn_index)
        # Exponential decay: score = 0.5^(distance / half_life)
        turn_score = math.pow(0.5, turn_distance / RECENCY_HALF_LIFE_TURNS)

    # Time-based recency
    if item_timestamp:
        try:
            # Parse ISO format timestamp
            if item_timestamp.endswith('Z'):
                item_time = datetime.fromisoformat(item_timestamp[:-1])
            else:
                item_time = datetime.fromisoformat(item_timestamp.replace('Z', ''))

            time_diff = current_time - item_time
            hours_elapsed = time_diff.total_seconds() / 3600
            time_score = math.pow(0.5, hours_elapsed / RECENCY_HALF_LIFE_HOURS)
        except (ValueError, TypeError):
            pass

    # Combine with weight on turn-based (more important for dialogue)
    return 0.7 * turn_score + 0.3 * time_score


def _compute_topic_overlap_score(
    item_content: str,
    current_query: str,
    item_tags: Optional[List[str]] = None
) -> float:
    """
    Compute topic overlap between a memory item and current query.

    Uses keyword intersection as a simple proxy for semantic similarity.
    Returns a score between 0.0 (no overlap) and 1.0 (high overlap).
    """
    if not item_content or not current_query:
        return 0.0

    # Extract keywords from both
    item_keywords = _extract_keywords(item_content)
    query_keywords = _extract_keywords(current_query)

    # Add tags as keywords
    if item_tags:
        for tag in item_tags:
            item_keywords.update(_extract_keywords(tag))

    if not item_keywords or not query_keywords:
        return 0.0

    # Jaccard similarity
    intersection = len(item_keywords & query_keywords)
    union = len(item_keywords | query_keywords)

    if union == 0:
        return 0.0

    jaccard = intersection / union

    # Also check for exact phrase matches (boost score)
    query_lower = current_query.lower()
    item_lower = item_content.lower()

    phrase_boost = 0.0
    # Check if any 2-word or 3-word query phrases appear in item
    query_words = query_lower.split()
    for i in range(len(query_words) - 1):
        bigram = ' '.join(query_words[i:i+2])
        if len(bigram) > 5 and bigram in item_lower:
            phrase_boost = max(phrase_boost, 0.3)
        if i < len(query_words) - 2:
            trigram = ' '.join(query_words[i:i+3])
            if len(trigram) > 8 and trigram in item_lower:
                phrase_boost = max(phrase_boost, 0.5)

    return min(1.0, jaccard + phrase_boost)


def _get_source_confidence(item: Dict[str, Any]) -> float:
    """
    Get the source confidence from item metadata.

    Falls back to 0.5 if not available.
    """
    metadata = item.get("metadata", {}) or {}

    # Try various confidence fields
    confidence = metadata.get("confidence")
    if confidence is not None:
        try:
            return float(confidence)
        except (ValueError, TypeError):
            pass

    # Try truth_type based confidence
    truth_type = metadata.get("truth_type", "")
    if truth_type == "fact":
        return 0.9
    elif truth_type == "belief":
        return 0.7
    elif truth_type == "hypothesis":
        return 0.5
    elif truth_type == "opinion":
        return 0.4

    return 0.5  # Default


def _get_use_count(item: Dict[str, Any], recent_window: int = 10) -> int:
    """
    Get the use count from item metadata.

    Returns how many times this item was referenced in recent sessions.
    """
    metadata = item.get("metadata", {}) or {}
    return int(metadata.get("use_count", 0))


def context_relevance_score(
    item: Dict[str, Any],
    current_query: str,
    current_turn_index: int = 0,
    current_time: Optional[datetime] = None,
    weights: Optional[Dict[str, float]] = None
) -> float:
    """
    Compute the overall relevance score for a memory item.

    Args:
        item: Memory item dict with content, metadata, etc.
        current_query: The current user query text
        current_turn_index: Current conversation turn number
        current_time: Current time (defaults to now)
        weights: Optional custom weights for score components

    Returns:
        Float between 0.0 and 1.0 representing relevance
    """
    if weights is None:
        weights = {
            "recency": 0.25,
            "topic_overlap": 0.45,
            "source_confidence": 0.20,
            "use_count": 0.10
        }

    # Extract item data
    content = item.get("content", "")
    if isinstance(content, dict):
        content = str(content.get("text", content.get("value", str(content))))
    elif not isinstance(content, str):
        content = str(content)

    metadata = item.get("metadata", {}) or {}
    timestamp = metadata.get("timestamp") or item.get("timestamp")
    turn_index = metadata.get("turn_index")
    tags = metadata.get("tags", [])

    # Compute component scores
    recency = _compute_recency_score(
        timestamp, turn_index, current_turn_index, current_time
    )

    topic_overlap = _compute_topic_overlap_score(content, current_query, tags)

    source_conf = _get_source_confidence(item)

    use_count = _get_use_count(item)
    use_score = min(1.0, use_count / 10.0)  # Normalize to [0, 1]

    # Weighted combination
    score = (
        weights["recency"] * recency +
        weights["topic_overlap"] * topic_overlap +
        weights["source_confidence"] * source_conf +
        weights["use_count"] * use_score
    )

    return min(1.0, max(0.0, score))


def rank_context_for_turn(
    user_message: str,
    candidates: List[Dict[str, Any]],
    k: int = 10,
    current_turn_index: int = 0,
    min_score: float = 0.1
) -> List[Dict[str, Any]]:
    """
    Rank and select the top-k most relevant context items.

    Args:
        user_message: The current user query
        candidates: List of memory items to consider
        k: Maximum number of items to return
        current_turn_index: Current conversation turn
        min_score: Minimum relevance score to include

    Returns:
        List of top-k items with relevance scores attached
    """
    if not candidates:
        return []

    scored_items = []

    for item in candidates:
        score = context_relevance_score(
            item=item,
            current_query=user_message,
            current_turn_index=current_turn_index
        )

        if score >= min_score:
            # Add score to item
            item_with_score = dict(item)
            item_with_score["_relevance_score"] = score
            scored_items.append(item_with_score)

    # Sort by score descending
    scored_items.sort(key=lambda x: x.get("_relevance_score", 0), reverse=True)

    # Return top-k
    return scored_items[:k]


def decide_promotion_or_decay(
    item: Dict[str, Any],
    current_query: str = "",
    current_turn_index: int = 0
) -> Tuple[str, float]:
    """
    Decide whether an item should be promoted, decayed, or kept.

    Args:
        item: Memory item to evaluate
        current_query: Current query for relevance (optional)
        current_turn_index: Current turn number

    Returns:
        Tuple of (action, score) where action is:
        - "promote": Move to higher tier
        - "decay": Move to lower tier / archive
        - "keep": No change needed
    """
    score = context_relevance_score(
        item=item,
        current_query=current_query,
        current_turn_index=current_turn_index
    )

    if score >= PROMOTE_THRESHOLD:
        return ("promote", score)
    elif score <= DECAY_THRESHOLD:
        return ("decay", score)
    else:
        return ("keep", score)


def get_context_bundle(
    user_message: str,
    memory_tiers: Dict[str, List[Dict[str, Any]]],
    limits: Optional[Dict[str, int]] = None,
    current_turn_index: int = 0
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Build a context bundle from multiple memory tiers.

    Args:
        user_message: Current user query
        memory_tiers: Dict of tier_name -> list of items
        limits: Max items per tier (default: stm=10, mtm=10, ltm=5)
        current_turn_index: Current conversation turn

    Returns:
        Dict of tier_name -> ranked relevant items
    """
    if limits is None:
        limits = {
            "stm": 10,
            "mtm": 10,
            "ltm": 5,
            "episodic": 5,
            "vector": 5
        }

    bundle = {}

    for tier_name, items in memory_tiers.items():
        tier_limit = limits.get(tier_name, 5)
        ranked = rank_context_for_turn(
            user_message=user_message,
            candidates=items,
            k=tier_limit,
            current_turn_index=current_turn_index
        )
        bundle[tier_name] = ranked

    return bundle


# Service API for consistency with brain pattern
def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Service API entry point for context relevance operations.

    Operations:
        SCORE: Score a single item's relevance
        RANK: Rank and select top-k items
        DECIDE: Decide promote/decay for an item
        BUILD_BUNDLE: Build context bundle from tiers
    """
    op = (msg or {}).get("op", "").upper()
    payload = msg.get("payload", {})

    if op == "SCORE":
        item = payload.get("item", {})
        query = payload.get("query", "")
        turn_index = payload.get("turn_index", 0)

        score = context_relevance_score(
            item=item,
            current_query=query,
            current_turn_index=turn_index
        )
        return {"status": "ok", "payload": {"score": score}}

    elif op == "RANK":
        query = payload.get("query", "")
        candidates = payload.get("candidates", [])
        k = payload.get("k", 10)
        turn_index = payload.get("turn_index", 0)

        ranked = rank_context_for_turn(
            user_message=query,
            candidates=candidates,
            k=k,
            current_turn_index=turn_index
        )
        return {"status": "ok", "payload": {"ranked": ranked}}

    elif op == "DECIDE":
        item = payload.get("item", {})
        query = payload.get("query", "")
        turn_index = payload.get("turn_index", 0)

        action, score = decide_promotion_or_decay(
            item=item,
            current_query=query,
            current_turn_index=turn_index
        )
        return {"status": "ok", "payload": {"action": action, "score": score}}

    elif op == "BUILD_BUNDLE":
        query = payload.get("query", "")
        memory_tiers = payload.get("memory_tiers", {})
        limits = payload.get("limits")
        turn_index = payload.get("turn_index", 0)

        bundle = get_context_bundle(
            user_message=query,
            memory_tiers=memory_tiers,
            limits=limits,
            current_turn_index=turn_index
        )
        return {"status": "ok", "payload": {"bundle": bundle}}

    return {"status": "error", "error": f"Unknown operation: {op}"}


handle = service_api
