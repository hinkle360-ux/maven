"""
Fact Extractor - Extract Facts from Teacher Responses
=====================================================

FIX 3: This module extracts individual FACTS from Teacher/LLM responses
instead of storing the full formatted response as a "pattern".

Problem: Storing Teacher's full formatted answer as a pattern causes:
1. Markdown headers/bullets to appear in synthesis
2. Loss of individual fact granularity
3. Over-reliance on Teacher's exact phrasing

Solution: Extract individual facts from Teacher responses and store them
separately in the appropriate domain banks.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import re
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field


# =============================================================================
# FACT EXTRACTION PATTERNS
# =============================================================================

# Patterns that indicate a fact statement
FACT_INDICATORS = [
    r'^[-*]\s+(.+)$',                    # Bullet point
    r'^\d+\.\s+(.+)$',                   # Numbered list
    r'^(.+?):\s+(.+)$',                  # Key: Value pattern
    r'^(.+?)\s+is\s+(.+?)\.?$',          # X is Y
    r'^(.+?)\s+are\s+(.+?)\.?$',         # X are Y
    r'^(.+?)\s+has\s+(.+?)\.?$',         # X has Y
    r'^(.+?)\s+can\s+(.+?)\.?$',         # X can Y
    r'^(.+?)\s+means\s+(.+?)\.?$',       # X means Y
    r'^(.+?)\s+refers to\s+(.+?)\.?$',   # X refers to Y
]

# Patterns to skip (not facts)
SKIP_PATTERNS = [
    r'^#+\s*',                           # Markdown headers
    r'^```',                             # Code fence
    r'^\s*$',                            # Empty lines
    r'^---+$',                           # Horizontal rules
    r'^Here is',                         # Intro phrases
    r'^Here are',
    r'^In summary',
    r'^To summarize',
    r'^In conclusion',
    r'^Overall',
    r'^Note:',
    r'^Remember:',
    r'^Important:',
    r'^Let me explain',
    r'^I\'ll explain',
    r'^First,',                          # Transitional phrases
    r'^Second,',
    r'^Third,',
    r'^Finally,',
    r'^Additionally,',
    r'^Furthermore,',
    r'^Moreover,',
]


@dataclass
class ExtractedFact:
    """A fact extracted from Teacher response."""
    content: str
    importance: float = 0.7
    tags: List[str] = field(default_factory=list)
    domain: str = "factual"
    source: str = "teacher"
    is_code_example: bool = False


# =============================================================================
# MAIN EXTRACTION FUNCTIONS
# =============================================================================

def extract_facts_from_teacher_response(
    response: str,
    query: Optional[str] = None,
    domain_hint: Optional[str] = None,
) -> List[ExtractedFact]:
    """
    Extract individual facts from a Teacher/LLM response.

    This is the CORRECT way to store Teacher responses:
    - Extract individual facts
    - Store each fact separately
    - Don't store the full formatted response as a pattern

    Args:
        response: The full Teacher/LLM response
        query: Optional original query for context
        domain_hint: Optional domain to assign to facts

    Returns:
        List of ExtractedFact objects
    """
    if not response or not response.strip():
        return []

    facts: List[ExtractedFact] = []
    domain = domain_hint or infer_domain(query, response)

    # Split into sections
    sections = split_into_sections(response)

    for section in sections:
        section_facts = extract_facts_from_section(section, query, domain)
        facts.extend(section_facts)

    # Deduplicate and score
    facts = deduplicate_facts(facts)
    facts = score_facts(facts, query)

    return facts


def split_into_sections(text: str) -> List[str]:
    """Split text into logical sections."""
    sections = []

    # Split by headers
    header_pattern = r'^#+\s+.+$'
    parts = re.split(header_pattern, text, flags=re.MULTILINE)

    for part in parts:
        part = part.strip()
        if part:
            # Further split by double newlines
            subparts = re.split(r'\n\s*\n', part)
            sections.extend([s.strip() for s in subparts if s.strip()])

    return sections if sections else [text]


def extract_facts_from_section(
    section: str,
    query: Optional[str] = None,
    domain: str = "factual",
) -> List[ExtractedFact]:
    """Extract facts from a single section of text."""
    facts = []

    # Handle code blocks specially
    code_blocks = extract_code_blocks(section)
    if code_blocks:
        for code in code_blocks:
            facts.append(ExtractedFact(
                content=code.strip(),
                importance=0.8,
                tags=["code", "example"],
                domain=domain,
                source="teacher",
                is_code_example=True,
            ))

    # Split into lines
    lines = section.split('\n')

    current_fact = []
    in_code_block = False

    for line in lines:
        line = line.strip()

        # Skip code fences
        if line.startswith('```'):
            in_code_block = not in_code_block
            continue

        if in_code_block:
            continue

        # Skip non-fact patterns
        if should_skip_line(line):
            continue

        # Check if line is a bullet/numbered item
        bullet_match = re.match(r'^[-*]\s+(.+)$', line)
        number_match = re.match(r'^\d+\.\s+(.+)$', line)

        if bullet_match:
            fact_content = bullet_match.group(1).strip()
            if is_valid_fact(fact_content):
                facts.append(ExtractedFact(
                    content=fact_content,
                    importance=0.7,
                    tags=["extracted"],
                    domain=domain,
                    source="teacher",
                ))
        elif number_match:
            fact_content = number_match.group(1).strip()
            if is_valid_fact(fact_content):
                facts.append(ExtractedFact(
                    content=fact_content,
                    importance=0.7,
                    tags=["extracted", "ordered"],
                    domain=domain,
                    source="teacher",
                ))
        elif is_valid_fact(line):
            # Regular prose line - check if it's a complete sentence
            if line.endswith(('.', '!', '?')):
                facts.append(ExtractedFact(
                    content=line,
                    importance=0.6,
                    tags=["prose"],
                    domain=domain,
                    source="teacher",
                ))
            else:
                # Accumulate for multi-line facts
                current_fact.append(line)

    # Handle accumulated text
    if current_fact:
        combined = ' '.join(current_fact)
        if is_valid_fact(combined):
            facts.append(ExtractedFact(
                content=combined,
                importance=0.5,
                tags=["combined"],
                domain=domain,
                source="teacher",
            ))

    return facts


def extract_code_blocks(text: str) -> List[str]:
    """Extract code blocks from text."""
    code_blocks = []

    # Fenced code blocks
    fenced_pattern = r'```[\w]*\n?([\s\S]*?)```'
    matches = re.findall(fenced_pattern, text)
    code_blocks.extend(matches)

    return code_blocks


def should_skip_line(line: str) -> bool:
    """Check if a line should be skipped (not a fact)."""
    if not line or len(line) < 5:
        return True

    for pattern in SKIP_PATTERNS:
        if re.match(pattern, line, re.IGNORECASE):
            return True

    return False


def is_valid_fact(text: str) -> bool:
    """Check if text is a valid fact to store."""
    if not text or len(text) < 10:
        return False

    # Skip very long text (probably not a single fact)
    if len(text) > 500:
        return False

    # Skip if it looks like a question
    if text.endswith('?'):
        return False

    # Skip transitional phrases
    transitional = [
        "here is", "here are", "let me", "i'll",
        "first", "second", "third", "finally",
        "in summary", "to summarize", "in conclusion",
    ]
    text_lower = text.lower()
    if any(text_lower.startswith(t) for t in transitional):
        return False

    return True


def infer_domain(query: Optional[str], response: str) -> str:
    """Infer the appropriate domain for facts."""
    if not query:
        return "factual"

    query_lower = query.lower()

    # Personal facts
    if any(w in query_lower for w in ["my name", "my email", "my phone", "my address"]):
        return "personal"

    # Technical facts
    if any(w in query_lower for w in ["code", "program", "function", "class", "api"]):
        return "technical"

    # System facts
    if any(w in query_lower for w in ["maven", "brain", "tool", "memory", "pipeline"]):
        return "maven_self"

    # Default
    return "factual"


def deduplicate_facts(facts: List[ExtractedFact]) -> List[ExtractedFact]:
    """Remove duplicate facts."""
    seen = set()
    unique = []

    for fact in facts:
        # Normalize for comparison
        normalized = fact.content.lower().strip()
        normalized = re.sub(r'\s+', ' ', normalized)

        if normalized not in seen:
            seen.add(normalized)
            unique.append(fact)

    return unique


def score_facts(
    facts: List[ExtractedFact],
    query: Optional[str] = None,
) -> List[ExtractedFact]:
    """Score facts by relevance to query."""
    if not query:
        return facts

    query_lower = query.lower()
    query_words = set(query_lower.split())

    for fact in facts:
        fact_lower = fact.content.lower()
        fact_words = set(fact_lower.split())

        # Calculate overlap
        overlap = len(query_words & fact_words)
        relevance = overlap / max(len(query_words), 1)

        # Boost importance based on relevance
        fact.importance = min(1.0, fact.importance + (relevance * 0.2))

    # Sort by importance
    facts.sort(key=lambda f: f.importance, reverse=True)

    return facts


# =============================================================================
# STORAGE INTEGRATION
# =============================================================================

def store_extracted_facts(
    facts: List[ExtractedFact],
    memory_librarian,
    source_query: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Store extracted facts to memory.

    This is the CORRECT way to store Teacher knowledge:
    - Store individual facts
    - NOT the full formatted response

    Args:
        facts: List of ExtractedFact objects
        memory_librarian: Memory librarian service
        source_query: Optional source query for provenance

    Returns:
        Dict with status and counts
    """
    stored = 0
    skipped = 0
    errors = []

    for fact in facts:
        try:
            # Prepare storage payload
            payload = {
                "content": fact.content,
                "domain": fact.domain,
                "importance": fact.importance,
                "tags": fact.tags + (["code_example"] if fact.is_code_example else []),
                "source": "teacher_extraction",
                "source_query": source_query,
            }

            # Store via service API
            if hasattr(memory_librarian, "service_api"):
                result = memory_librarian.service_api({
                    "op": "STORE_FACT",
                    "payload": payload,
                })
                if result and result.get("ok"):
                    stored += 1
                else:
                    skipped += 1
            elif hasattr(memory_librarian, "store_fact"):
                result = memory_librarian.store_fact(**payload)
                if result:
                    stored += 1
                else:
                    skipped += 1
            else:
                errors.append("No valid storage method available")

        except Exception as e:
            errors.append(f"Error storing fact: {e}")

    return {
        "ok": len(errors) == 0,
        "stored": stored,
        "skipped": skipped,
        "total_facts": len(facts),
        "errors": errors,
    }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Data classes
    "ExtractedFact",
    # Main functions
    "extract_facts_from_teacher_response",
    "store_extracted_facts",
    # Helper functions
    "split_into_sections",
    "extract_code_blocks",
    "is_valid_fact",
    "infer_domain",
]
