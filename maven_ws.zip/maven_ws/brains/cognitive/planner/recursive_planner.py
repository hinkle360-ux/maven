"""
Recursive Planner
=================

N-level recursive task decomposition for AGI-level planning capabilities.

This module implements hierarchical task decomposition with:
1. Configurable maximum recursion depth
2. Complexity-based depth limits
3. Subtask dependency tracking
4. Execution feedback integration
5. Automatic complexity estimation

The recursive planner breaks down complex tasks into manageable subtasks,
continuing decomposition until tasks are atomic (simple enough to execute
directly) or the depth limit is reached.

Usage:
    from brains.cognitive.planner.recursive_planner import (
        decompose_recursive,
        estimate_complexity,
        RecursivePlan,
        PlanNode,
    )

    # Decompose a complex task
    plan = decompose_recursive(
        task="Build a web scraper that extracts news headlines",
        max_depth=5,
        complexity_threshold=0.3,
    )

    # Execute nodes in order
    for node in plan.execution_order():
        execute_node(node)
        node.mark_complete(success=True)

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations

import re
import time
import json
import hashlib
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from brains.memory.brain_memory import BrainMemory


# Recursive planning memory
_memory = BrainMemory("recursive_planner")


class TaskComplexity(Enum):
    """Task complexity levels."""
    ATOMIC = "atomic"       # Can be executed directly (complexity < 0.2)
    SIMPLE = "simple"       # 1-2 subtasks (0.2 <= complexity < 0.4)
    MODERATE = "moderate"   # 3-5 subtasks (0.4 <= complexity < 0.6)
    COMPLEX = "complex"     # 6-10 subtasks (0.6 <= complexity < 0.8)
    VERY_COMPLEX = "very_complex"  # 10+ subtasks (complexity >= 0.8)


class NodeStatus(Enum):
    """Execution status of a plan node."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    BLOCKED = "blocked"
    SKIPPED = "skipped"


@dataclass
class PlanNode:
    """A single node in the hierarchical plan tree."""
    id: str
    task: str
    description: str = ""
    depth: int = 0
    parent_id: Optional[str] = None
    children: List[str] = field(default_factory=list)
    dependencies: List[str] = field(default_factory=list)

    # Complexity and decomposition
    complexity: float = 0.0
    complexity_level: TaskComplexity = TaskComplexity.ATOMIC
    is_atomic: bool = True
    decomposition_strategy: str = ""

    # Execution state
    status: NodeStatus = NodeStatus.PENDING
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    execution_time_ms: Optional[int] = None

    # Metadata
    tags: List[str] = field(default_factory=list)
    tool_hint: Optional[str] = None
    brain_hint: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "task": self.task,
            "description": self.description,
            "depth": self.depth,
            "parent_id": self.parent_id,
            "children": self.children,
            "dependencies": self.dependencies,
            "complexity": self.complexity,
            "complexity_level": self.complexity_level.value,
            "is_atomic": self.is_atomic,
            "decomposition_strategy": self.decomposition_strategy,
            "status": self.status.value,
            "result": self.result,
            "error": self.error,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "execution_time_ms": self.execution_time_ms,
            "tags": self.tags,
            "tool_hint": self.tool_hint,
            "brain_hint": self.brain_hint,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PlanNode":
        node = cls(
            id=data["id"],
            task=data["task"],
            description=data.get("description", ""),
            depth=data.get("depth", 0),
            parent_id=data.get("parent_id"),
            children=data.get("children", []),
            dependencies=data.get("dependencies", []),
            complexity=data.get("complexity", 0.0),
            is_atomic=data.get("is_atomic", True),
            decomposition_strategy=data.get("decomposition_strategy", ""),
            tags=data.get("tags", []),
            tool_hint=data.get("tool_hint"),
            brain_hint=data.get("brain_hint"),
        )
        node.complexity_level = TaskComplexity(data.get("complexity_level", "atomic"))
        node.status = NodeStatus(data.get("status", "pending"))
        node.result = data.get("result")
        node.error = data.get("error")
        node.started_at = data.get("started_at")
        node.completed_at = data.get("completed_at")
        node.execution_time_ms = data.get("execution_time_ms")
        return node

    def mark_started(self) -> None:
        """Mark node as started."""
        self.status = NodeStatus.IN_PROGRESS
        self.started_at = time.time()

    def mark_complete(self, success: bool, result: Optional[Dict] = None, error: Optional[str] = None) -> None:
        """Mark node as completed or failed."""
        self.completed_at = time.time()
        if self.started_at:
            self.execution_time_ms = int((self.completed_at - self.started_at) * 1000)

        if success:
            self.status = NodeStatus.COMPLETED
            self.result = result
        else:
            self.status = NodeStatus.FAILED
            self.error = error


@dataclass
class RecursivePlan:
    """A complete hierarchical plan with recursive decomposition."""
    plan_id: str
    root_task: str
    nodes: Dict[str, PlanNode] = field(default_factory=dict)
    root_node_id: Optional[str] = None
    max_depth: int = 5
    complexity_threshold: float = 0.3

    # Statistics
    created_at: float = field(default_factory=time.time)
    total_nodes: int = 0
    max_achieved_depth: int = 0
    atomic_count: int = 0

    def add_node(self, node: PlanNode) -> None:
        """Add a node to the plan."""
        self.nodes[node.id] = node
        self.total_nodes = len(self.nodes)
        if node.depth > self.max_achieved_depth:
            self.max_achieved_depth = node.depth
        if node.is_atomic:
            self.atomic_count += 1

    def get_node(self, node_id: str) -> Optional[PlanNode]:
        """Get a node by ID."""
        return self.nodes.get(node_id)

    def get_children(self, node_id: str) -> List[PlanNode]:
        """Get all children of a node."""
        node = self.nodes.get(node_id)
        if not node:
            return []
        return [self.nodes[cid] for cid in node.children if cid in self.nodes]

    def execution_order(self) -> List[PlanNode]:
        """
        Get nodes in execution order (topological sort).

        Respects dependencies: a node is only returned after all its
        dependencies have been returned.
        """
        # Get all atomic nodes (leaf nodes that can be executed)
        atomic_nodes = [n for n in self.nodes.values() if n.is_atomic]

        # Topological sort based on dependencies
        visited: Set[str] = set()
        result: List[PlanNode] = []

        def visit(node: PlanNode) -> None:
            if node.id in visited:
                return
            visited.add(node.id)

            # Visit dependencies first
            for dep_id in node.dependencies:
                if dep_id in self.nodes:
                    visit(self.nodes[dep_id])

            result.append(node)

        for node in atomic_nodes:
            visit(node)

        return result

    def get_ready_nodes(self) -> List[PlanNode]:
        """Get nodes that are ready to execute (dependencies satisfied)."""
        ready = []
        for node in self.nodes.values():
            if node.status != NodeStatus.PENDING:
                continue
            if not node.is_atomic:
                continue

            # Check all dependencies are completed
            deps_satisfied = True
            for dep_id in node.dependencies:
                dep_node = self.nodes.get(dep_id)
                if dep_node and dep_node.status != NodeStatus.COMPLETED:
                    deps_satisfied = False
                    break

            if deps_satisfied:
                ready.append(node)

        return ready

    def to_dict(self) -> Dict[str, Any]:
        return {
            "plan_id": self.plan_id,
            "root_task": self.root_task,
            "nodes": {nid: n.to_dict() for nid, n in self.nodes.items()},
            "root_node_id": self.root_node_id,
            "max_depth": self.max_depth,
            "complexity_threshold": self.complexity_threshold,
            "created_at": self.created_at,
            "total_nodes": self.total_nodes,
            "max_achieved_depth": self.max_achieved_depth,
            "atomic_count": self.atomic_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "RecursivePlan":
        plan = cls(
            plan_id=data["plan_id"],
            root_task=data["root_task"],
            root_node_id=data.get("root_node_id"),
            max_depth=data.get("max_depth", 5),
            complexity_threshold=data.get("complexity_threshold", 0.3),
        )
        plan.created_at = data.get("created_at", time.time())
        plan.total_nodes = data.get("total_nodes", 0)
        plan.max_achieved_depth = data.get("max_achieved_depth", 0)
        plan.atomic_count = data.get("atomic_count", 0)

        for node_id, node_data in data.get("nodes", {}).items():
            plan.nodes[node_id] = PlanNode.from_dict(node_data)

        return plan


# Complexity estimation patterns
COMPLEXITY_INDICATORS: Dict[str, float] = {
    # High complexity indicators
    "system": 0.15, "architecture": 0.15, "framework": 0.12,
    "integrate": 0.12, "distributed": 0.15, "scalable": 0.12,
    "concurrent": 0.12, "parallel": 0.10, "optimize": 0.10,
    "security": 0.10, "authentication": 0.10, "authorization": 0.08,

    # Moderate complexity
    "implement": 0.08, "build": 0.08, "create": 0.07,
    "develop": 0.08, "design": 0.08, "refactor": 0.08,
    "database": 0.08, "api": 0.07, "interface": 0.06,
    "test": 0.06, "deploy": 0.07, "configure": 0.05,

    # Lower complexity
    "update": 0.04, "modify": 0.04, "fix": 0.04,
    "add": 0.03, "remove": 0.03, "change": 0.03,
    "read": 0.02, "write": 0.02, "list": 0.02,
    "check": 0.02, "validate": 0.03, "format": 0.02,
}

# Decomposition strategies
DECOMPOSITION_STRATEGIES: Dict[str, Dict[str, Any]] = {
    "implementation": {
        "pattern": r"(implement|build|create|develop|code|write)\s+(.+)",
        "subtasks": ["analyze_requirements", "design_solution", "implement_core", "add_tests", "integrate"],
        "tags": ["coding", "implementation"],
        "tool_hint": "python",
    },
    "research": {
        "pattern": r"(research|investigate|study|analyze|understand)\s+(.+)",
        "subtasks": ["gather_sources", "analyze_information", "synthesize_findings", "document_results"],
        "tags": ["research", "analysis"],
        "brain_hint": "research_manager",
    },
    "debugging": {
        "pattern": r"(debug|fix|troubleshoot|diagnose|resolve)\s+(.+)",
        "subtasks": ["reproduce_issue", "identify_cause", "develop_fix", "verify_fix"],
        "tags": ["debugging", "fix"],
        "tool_hint": "shell",
    },
    "configuration": {
        "pattern": r"(configure|setup|install|deploy)\s+(.+)",
        "subtasks": ["check_requirements", "prepare_environment", "apply_configuration", "verify_setup"],
        "tags": ["configuration", "setup"],
        "tool_hint": "shell",
    },
    "documentation": {
        "pattern": r"(document|write docs|create documentation)\s+(.+)",
        "subtasks": ["outline_structure", "write_content", "add_examples", "review_and_format"],
        "tags": ["documentation", "writing"],
        "brain_hint": "language",
    },
    "testing": {
        "pattern": r"(test|verify|validate|check)\s+(.+)",
        "subtasks": ["identify_test_cases", "write_tests", "run_tests", "analyze_results"],
        "tags": ["testing", "verification"],
        "tool_hint": "python",
    },
    "data_processing": {
        "pattern": r"(process|transform|convert|parse|extract)\s+(.+)",
        "subtasks": ["load_data", "transform_data", "validate_output", "save_results"],
        "tags": ["data", "processing"],
        "brain_hint": "reasoning",
    },
    "generic": {
        "pattern": r"(.+)",
        "subtasks": ["understand_task", "plan_approach", "execute_steps", "verify_result"],
        "tags": ["generic"],
        "brain_hint": "planner",
    },
}


def generate_node_id(task: str, depth: int) -> str:
    """Generate a unique node ID."""
    content = f"{task}:{depth}:{time.time()}"
    return hashlib.md5(content.encode()).hexdigest()[:12]


def estimate_complexity(task: str) -> Tuple[float, TaskComplexity]:
    """
    Estimate the complexity of a task.

    Args:
        task: Task description

    Returns:
        Tuple of (complexity score 0-1, complexity level)
    """
    task_lower = task.lower()

    # Base complexity from length
    word_count = len(task.split())
    length_complexity = min(0.3, word_count * 0.02)

    # Keyword complexity
    keyword_complexity = 0.0
    for keyword, weight in COMPLEXITY_INDICATORS.items():
        if keyword in task_lower:
            keyword_complexity += weight
    keyword_complexity = min(0.5, keyword_complexity)

    # Structural complexity (multiple clauses, conjunctions)
    structural_complexity = 0.0
    if " and " in task_lower:
        structural_complexity += 0.1
    if " or " in task_lower:
        structural_complexity += 0.05
    if " then " in task_lower:
        structural_complexity += 0.08
    if ":" in task:
        structural_complexity += 0.05
    structural_complexity = min(0.2, structural_complexity)

    # Total complexity
    total = length_complexity + keyword_complexity + structural_complexity
    total = min(1.0, max(0.0, total))

    # Determine level
    if total < 0.2:
        level = TaskComplexity.ATOMIC
    elif total < 0.4:
        level = TaskComplexity.SIMPLE
    elif total < 0.6:
        level = TaskComplexity.MODERATE
    elif total < 0.8:
        level = TaskComplexity.COMPLEX
    else:
        level = TaskComplexity.VERY_COMPLEX

    return total, level


def select_decomposition_strategy(task: str) -> Tuple[str, Dict[str, Any]]:
    """
    Select the best decomposition strategy for a task.

    Args:
        task: Task description

    Returns:
        Tuple of (strategy name, strategy definition)
    """
    task_lower = task.lower()

    for name, strategy in DECOMPOSITION_STRATEGIES.items():
        if name == "generic":
            continue
        pattern = strategy["pattern"]
        if re.search(pattern, task_lower, re.IGNORECASE):
            return name, strategy

    return "generic", DECOMPOSITION_STRATEGIES["generic"]


def decompose_task(
    task: str,
    depth: int,
    max_depth: int,
    complexity_threshold: float,
    parent_id: Optional[str] = None,
) -> PlanNode:
    """
    Decompose a single task into a node (possibly with children).

    Args:
        task: Task description
        depth: Current recursion depth
        max_depth: Maximum allowed depth
        complexity_threshold: Stop decomposing below this complexity
        parent_id: Parent node ID

    Returns:
        PlanNode with potential children
    """
    # Generate node
    node_id = generate_node_id(task, depth)
    complexity, complexity_level = estimate_complexity(task)

    node = PlanNode(
        id=node_id,
        task=task,
        depth=depth,
        parent_id=parent_id,
        complexity=complexity,
        complexity_level=complexity_level,
    )

    # Check if we should decompose further
    should_decompose = (
        depth < max_depth and
        complexity > complexity_threshold and
        complexity_level not in (TaskComplexity.ATOMIC, TaskComplexity.SIMPLE)
    )

    if not should_decompose:
        # This is an atomic node
        node.is_atomic = True
        node.description = f"Execute: {task}"

        # Try to determine tool/brain hint
        strategy_name, strategy = select_decomposition_strategy(task)
        node.tags = strategy.get("tags", [])
        node.tool_hint = strategy.get("tool_hint")
        node.brain_hint = strategy.get("brain_hint")

        return node

    # Decompose into subtasks
    node.is_atomic = False
    strategy_name, strategy = select_decomposition_strategy(task)
    node.decomposition_strategy = strategy_name
    node.description = f"Decomposed using {strategy_name} strategy"
    node.tags = strategy.get("tags", [])

    # Generate subtasks based on strategy
    subtask_templates = strategy.get("subtasks", ["execute"])

    for i, template in enumerate(subtask_templates):
        # Create subtask description
        subtask = f"{template.replace('_', ' ').title()}: {task}"

        # Recursively decompose subtask
        child_node = decompose_task(
            task=subtask,
            depth=depth + 1,
            max_depth=max_depth,
            complexity_threshold=complexity_threshold,
            parent_id=node_id,
        )

        node.children.append(child_node.id)

        # Add dependency on previous subtask (sequential execution)
        if i > 0 and node.children:
            prev_child_id = node.children[i - 1]
            child_node.dependencies.append(prev_child_id)

    return node


def decompose_recursive(
    task: str,
    max_depth: int = 5,
    complexity_threshold: float = 0.3,
) -> RecursivePlan:
    """
    Perform N-level recursive decomposition of a task.

    Args:
        task: Root task to decompose
        max_depth: Maximum recursion depth (default: 5)
        complexity_threshold: Stop decomposing below this complexity (default: 0.3)

    Returns:
        RecursivePlan with all nodes
    """
    plan_id = generate_node_id(task, 0)[:8]
    plan = RecursivePlan(
        plan_id=plan_id,
        root_task=task,
        max_depth=max_depth,
        complexity_threshold=complexity_threshold,
    )

    # Recursively decompose starting from root
    def add_nodes(node: PlanNode) -> None:
        plan.add_node(node)

        # Recursively add children
        for child_id in node.children:
            # Need to decompose child
            child_task = f"Subtask of: {node.task}"
            for template in DECOMPOSITION_STRATEGIES.get(node.decomposition_strategy, {}).get("subtasks", []):
                if template.replace("_", " ").lower() in child_id:
                    child_task = f"{template.replace('_', ' ').title()}: {node.task}"
                    break

    # Start decomposition
    root_node = decompose_task(
        task=task,
        depth=0,
        max_depth=max_depth,
        complexity_threshold=complexity_threshold,
    )
    plan.root_node_id = root_node.id

    # Collect all nodes (BFS)
    def collect_all_nodes(node: PlanNode, plan: RecursivePlan) -> None:
        plan.add_node(node)

        for child_id in node.children:
            # Child node was already created during decompose_task
            # but we need to recursively collect from it
            # The child nodes are created inline, so we need to pass them
            pass

    # Actually, decompose_task returns nested structure - we need to flatten
    def flatten_nodes(node: PlanNode, plan: RecursivePlan, all_nodes: Dict[str, PlanNode]) -> None:
        all_nodes[node.id] = node
        for child_id in node.children:
            if child_id in all_nodes:
                flatten_nodes(all_nodes[child_id], plan, all_nodes)

    # Better approach: modify decompose_task to collect nodes
    all_nodes: Dict[str, PlanNode] = {}

    def decompose_and_collect(
        task: str,
        depth: int,
        parent_id: Optional[str] = None,
    ) -> PlanNode:
        node_id = generate_node_id(task, depth)
        complexity, complexity_level = estimate_complexity(task)

        node = PlanNode(
            id=node_id,
            task=task,
            depth=depth,
            parent_id=parent_id,
            complexity=complexity,
            complexity_level=complexity_level,
        )

        should_decompose = (
            depth < max_depth and
            complexity > complexity_threshold and
            complexity_level not in (TaskComplexity.ATOMIC, TaskComplexity.SIMPLE)
        )

        if not should_decompose:
            node.is_atomic = True
            node.description = f"Execute: {task}"
            strategy_name, strategy = select_decomposition_strategy(task)
            node.tags = strategy.get("tags", [])
            node.tool_hint = strategy.get("tool_hint")
            node.brain_hint = strategy.get("brain_hint")
            all_nodes[node.id] = node
            return node

        node.is_atomic = False
        strategy_name, strategy = select_decomposition_strategy(task)
        node.decomposition_strategy = strategy_name
        node.description = f"Decomposed using {strategy_name} strategy"
        node.tags = strategy.get("tags", [])

        subtask_templates = strategy.get("subtasks", ["execute"])
        prev_child_id = None

        for template in subtask_templates:
            subtask = f"{template.replace('_', ' ').title()}: {task}"
            child_node = decompose_and_collect(subtask, depth + 1, node.id)
            node.children.append(child_node.id)

            if prev_child_id:
                child_node.dependencies.append(prev_child_id)
            prev_child_id = child_node.id

        all_nodes[node.id] = node
        return node

    root = decompose_and_collect(task, 0)
    plan.root_node_id = root.id
    plan.nodes = all_nodes
    plan.total_nodes = len(all_nodes)
    plan.atomic_count = sum(1 for n in all_nodes.values() if n.is_atomic)
    plan.max_achieved_depth = max(n.depth for n in all_nodes.values()) if all_nodes else 0

    # Store plan in memory
    try:
        _memory.store(
            content=plan.to_dict(),
            metadata={
                "kind": "recursive_plan",
                "plan_id": plan.plan_id,
                "root_task": task[:100],
                "total_nodes": plan.total_nodes,
                "max_depth": plan.max_achieved_depth,
            }
        )
    except Exception:
        pass

    print(f"[RECURSIVE_PLANNER] Created plan with {plan.total_nodes} nodes, "
          f"max depth {plan.max_achieved_depth}, {plan.atomic_count} atomic")

    return plan


def integrate_execution_feedback(
    plan: RecursivePlan,
    node_id: str,
    success: bool,
    result: Optional[Dict] = None,
    error: Optional[str] = None,
) -> None:
    """
    Integrate execution feedback into the plan.

    This updates the node status and stores feedback for learning.

    Args:
        plan: The plan being executed
        node_id: ID of the executed node
        success: Whether execution succeeded
        result: Optional execution result
        error: Optional error message
    """
    node = plan.get_node(node_id)
    if not node:
        return

    node.mark_complete(success, result, error)

    # Store feedback in memory for learning
    try:
        _memory.store(
            content={
                "node_id": node_id,
                "task": node.task,
                "success": success,
                "execution_time_ms": node.execution_time_ms,
                "complexity": node.complexity,
                "depth": node.depth,
                "error": error,
            },
            metadata={
                "kind": "execution_feedback",
                "plan_id": plan.plan_id,
                "success": success,
                "task_pattern": node.task[:50],
            }
        )
    except Exception:
        pass

    # If failed, consider replanning the subtree
    if not success:
        print(f"[RECURSIVE_PLANNER] Node {node_id} failed: {error}")
        # Future: implement replanning logic


def load_plan(plan_id: str) -> Optional[RecursivePlan]:
    """Load a plan from memory."""
    try:
        results = _memory.retrieve(
            query=f"plan_id:{plan_id}",
            limit=1,
            tiers=["stm", "mtm", "ltm"]
        )
        for result in results:
            if result.get("metadata", {}).get("plan_id") == plan_id:
                return RecursivePlan.from_dict(result.get("content", {}))
    except Exception:
        pass
    return None


# Public API
__all__ = [
    "TaskComplexity",
    "NodeStatus",
    "PlanNode",
    "RecursivePlan",
    "decompose_recursive",
    "estimate_complexity",
    "select_decomposition_strategy",
    "integrate_execution_feedback",
    "load_plan",
]
