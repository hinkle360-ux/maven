"""
Command Pre-Parser - Hard Grammar Layer
========================================

This module provides a deterministic pre-parser that routes explicit tool
commands BEFORE they reach sensorium/integrator. This is the "hard floor"
that guarantees correct routing when learned patterns are weak.

ROUTING PRECEDENCE:
1. Hard Grammar (this module) - Explicit tool syntax, never overridden
2. Router LLM - Dedicated routing decisions with confidence
3. Learned Patterns - routing_learning / pattern_store
4. Safe Default - language brain with clarification

GRAMMAR PATTERNS:
- `x grok <message>` → browser tool x, subcommand grok
- `x: grok <message>` → same as above
- `grok <message>` → browser tool x, subcommand grok
- `research: <topic>` → research_manager brain
- `research: "<topic>" web:N` → research with N web requests
- `browser_open: <url>` → browser_open tool
- `use <tool> tool: <args>` → explicit tool call
- `post to x: <message>` → x_post tool
- `search: <query>` → web_search tool

When this layer matches, it:
1. Bypasses sensorium + reasoning entirely
2. Builds a routing plan directly
3. Logs as "gold" routing for learning

Usage:
    from brains.cognitive.command_pre_parser import parse_command, is_explicit_command

    result = parse_command("x grok hello from maven")
    if result:
        # result.intent = "browser_tool"
        # result.tools = ["x"]
        # result.subcommand = "grok"
        # result.args = "hello from maven"
        # result.bypass_integrator = True
"""

from __future__ import annotations

import re
import urllib.parse
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple


@dataclass
class ParsedCommand:
    """Result of command pre-parsing."""

    intent: str  # e.g., "browser_tool", "research", "web_search", "explicit_tool"
    tools: List[str] = field(default_factory=list)  # Tools to invoke
    brains: List[str] = field(default_factory=list)  # Brains to route to
    subcommand: Optional[str] = None  # e.g., "grok", "post", "search"
    args: str = ""  # Remaining arguments
    raw_input: str = ""  # Original input
    matched_pattern: str = ""  # Which pattern matched
    bypass_integrator: bool = True  # Skip integrator routing?
    confidence: float = 1.0  # Always 1.0 for grammar matches
    metadata: Dict[str, Any] = field(default_factory=dict)


# =============================================================================
# GRAMMAR PATTERNS - Order matters! More specific patterns first.
# =============================================================================

# Pattern: x grok <message> or x: grok <message>
PATTERN_X_GROK = re.compile(
    r"^x\s*[:\s]+grok\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: grok <message> (standalone grok command)
PATTERN_GROK_STANDALONE = re.compile(
    r"^grok\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: x post <message> or post to x: <message>
PATTERN_X_POST = re.compile(
    r"^(?:x\s+post|post\s+(?:to\s+)?x)\s*[:\s]*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: research: <topic> or research: "<topic>" web:N
PATTERN_RESEARCH = re.compile(
    r'^research\s*:\s*(?:"([^"]+)"|(.+?))(?:\s+web\s*:\s*(\d+))?$',
    re.IGNORECASE | re.DOTALL
)

# Pattern: browser_open: <url> or open <url>
PATTERN_BROWSER_OPEN = re.compile(
    r"^(?:browser_open|open)\s*:\s*(https?://\S+)$",
    re.IGNORECASE
)

# Pattern: open <site> (domain name without URL)
PATTERN_OPEN_SITE = re.compile(
    r"^open\s+(\w+(?:\.\w+)?)\s*$",
    re.IGNORECASE
)

# Pattern: open <site> and search/find <query>
PATTERN_OPEN_AND_SEARCH = re.compile(
    r"^open\s+(\w+(?:\.\w+)?)\s+(?:and\s+)?(?:search|find|look\s+for)\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Common site domain mappings
SITE_DOMAIN_MAP = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "twitter": "https://twitter.com",
    "x": "https://x.com",
    "facebook": "https://www.facebook.com",
    "instagram": "https://www.instagram.com",
    "reddit": "https://www.reddit.com",
    "github": "https://github.com",
    "linkedin": "https://www.linkedin.com",
    "amazon": "https://www.amazon.com",
    "netflix": "https://www.netflix.com",
    "spotify": "https://www.spotify.com",
    "twitch": "https://www.twitch.tv",
    "discord": "https://discord.com",
    "wikipedia": "https://www.wikipedia.org",
    "bing": "https://www.bing.com",
    "yahoo": "https://www.yahoo.com",
    "tiktok": "https://www.tiktok.com",
    "pinterest": "https://www.pinterest.com",
    "ebay": "https://www.ebay.com",
}

# Site-specific search URL patterns
SITE_SEARCH_PATTERNS = {
    "youtube": "https://www.youtube.com/results?search_query={query}",
    "google": "https://www.google.com/search?q={query}",
    "twitter": "https://twitter.com/search?q={query}",
    "x": "https://x.com/search?q={query}",
    "reddit": "https://www.reddit.com/search/?q={query}",
    "github": "https://github.com/search?q={query}",
    "amazon": "https://www.amazon.com/s?k={query}",
    "wikipedia": "https://en.wikipedia.org/wiki/Special:Search?search={query}",
    "bing": "https://www.bing.com/search?q={query}",
    "ebay": "https://www.ebay.com/sch/i.html?_nkw={query}",
}

# Pattern: search: <query> or web search: <query>
PATTERN_WEB_SEARCH = re.compile(
    r"^(?:web\s+)?search\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: use <tool> tool: <args>
PATTERN_EXPLICIT_TOOL = re.compile(
    r"^use\s+(\w+)\s+tool\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: chatgpt <message> (standalone chatgpt command)
PATTERN_CHATGPT = re.compile(
    r"^chatgpt\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: x <subcommand> <args> (generic x command)
PATTERN_X_GENERIC = re.compile(
    r"^x\s*[:\s]+(\w+)\s*(.*)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: shell: <command> or run: <command>
PATTERN_SHELL = re.compile(
    r"^(?:shell|run)\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: python: <code>
PATTERN_PYTHON = re.compile(
    r"^python\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: code: <request>
PATTERN_CODE = re.compile(
    r"^code\s*:\s*(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: maven <action> (direct maven commands)
PATTERN_MAVEN_COMMAND = re.compile(
    r"^maven\s+(explain|introduce|whoami|scan|status)\s*(.*)$",
    re.IGNORECASE
)

# Pattern: time queries (guaranteed routing to time_now tool)
# These MUST be caught at the grammar level to prevent LLM hallucinating times
PATTERN_TIME_QUERY = re.compile(
    r"^(?:what\s+time\s+is\s+it|what\s+time|what's?\s+the\s+time|what\s+is\s+the\s+time|"
    r"current\s+time|time\s*(?:now|right\s+now)?|tell\s+me\s+the\s+time|check\s+(?:the\s+)?time|"
    r"wat\s+time(?:\s+is\s+it)?|wats\s+the\s+time|whats\s+the\s+time)(?:\s*\??)?$",
    re.IGNORECASE
)

PATTERN_DATE_QUERY = re.compile(
    r"^(?:what\s+day\s+is\s+(?:it|today)|what\s+(?:is\s+)?(?:the\s+)?(?:day|date)|"
    r"what's?\s+(?:today|the\s+(?:day|date))|whats\s+(?:today|the\s+(?:day|date))|"
    r"current\s+date|today(?:'s)?\s*date|which\s+day(?:\s+is\s+(?:it|today))?|"
    r"today|wat\s+day|wats\s+today|to\s*day|what\s+is\s+today)(?:\s*\??)?$",
    re.IGNORECASE
)

PATTERN_CALENDAR_QUERY = re.compile(
    r"^(?:what\s+(?:month|year|week)(?:\s+is\s+it)?|what's?\s+the\s+(?:month|year)|"
    r"current\s+(?:month|year|week)|this\s+(?:month|year|week)|"
    r"show\s+(?:me\s+)?(?:the\s+)?calendar)(?:\s*\??)?$",
    re.IGNORECASE
)

# Pattern: pc: <command> or pc <command> (PC control tool)
PATTERN_PC_CONTROL = re.compile(
    r"^pc\s*[:\s]+(.*)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: human: <command> or human <command> (desktop control tool)
PATTERN_HUMAN_CONTROL = re.compile(
    r"^human\s*[:\s]+(.*)$",
    re.IGNORECASE | re.DOTALL
)

# =============================================================================
# BROWSER ACTION PATTERNS - for interacting with active browser pages
# =============================================================================

# Pattern: click/tap/select/pick/choose on/the <target>
# Examples: "click on the search button", "pick the first video", "tap submit"
PATTERN_BROWSER_CLICK = re.compile(
    r"^(?:click|tap|press)\s+(?:on\s+)?(?:the\s+)?(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: pick/choose/select <target>
# Examples: "pick a video", "choose the first option", "select that one"
PATTERN_BROWSER_PICK = re.compile(
    r"^(?:pick|choose|select)\s+(?:the\s+|a\s+|an\s+|that\s+)?(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: play <target> (for videos/media)
# Examples: "play", "play the video", "play it", "play the first one"
# Note: Matches bare "play" as well as "play <something>"
PATTERN_BROWSER_PLAY = re.compile(
    r"^play(?:\s+(?:the\s+|a\s+|that\s+)?(?:video|it|this|first|second|third|one|song|track|movie|clip)?\s*(.*))?$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: open/view <target> on page (not URLs)
# Examples: "open the first result", "view that article"
PATTERN_BROWSER_VIEW = re.compile(
    r"^(?:open|view|show)\s+(?:the\s+|that\s+)?(?:first|second|third|top|next)?\s*(?:result|article|link|video|item|option|one)(.*)$",
    re.IGNORECASE | re.DOTALL
)

# Pattern: scroll up/down
PATTERN_BROWSER_SCROLL = re.compile(
    r"^scroll\s+(?:(up|down|left|right)(?:\s+(?:a\s+)?(?:bit|little|more|lot))?|to\s+(?:the\s+)?(top|bottom))$",
    re.IGNORECASE
)

# Pattern: go back / forward
PATTERN_BROWSER_NAV = re.compile(
    r"^(?:go\s+)?(back|forward|refresh|reload)(?:\s+(?:a\s+)?page)?$",
    re.IGNORECASE
)

# Pattern: type/enter/input <text> (into current focused element or search)
PATTERN_BROWSER_TYPE = re.compile(
    r"^(?:type|enter|input|search\s+for)\s+(.+)$",
    re.IGNORECASE | re.DOTALL
)

# Combined pattern for quick detection of browser action intent
BROWSER_ACTION_KEYWORDS = frozenset([
    "click", "tap", "press", "pick", "choose", "select", "play",
    "scroll", "back", "forward", "refresh", "reload", "type",
    "enter", "submit", "watch", "view",
])


def parse_command(
    text: str,
    context: Optional[Dict[str, Any]] = None,
) -> Optional[ParsedCommand]:
    """
    Parse user input against the hard grammar.

    Args:
        text: Raw user input text
        context: Optional context dict with keys like:
            - browser_active: bool - whether there's an active browser page
            - browser_page_id: str - the active page ID
            - current_url: str - the URL of the current page

    Returns:
        ParsedCommand if matched, None if no grammar match
    """
    if not text:
        return None

    # Normalize: strip, collapse whitespace
    text = text.strip()
    text_normalized = re.sub(r'\s+', ' ', text)

    # Check context for browser state
    browser_active = False
    browser_page_id = None
    if context:
        browser_active = context.get("browser_active", False)
        browser_page_id = context.get("browser_page_id")

    # Try each pattern in order (most specific first)

    # 0a. TIME QUERY (highest priority - LLM cannot provide real-time info)
    if PATTERN_TIME_QUERY.match(text_normalized):
        return ParsedCommand(
            intent="time_query",
            tools=["time_now"],
            brains=["language"],
            subcommand="GET_TIME",
            args="",
            raw_input=text,
            matched_pattern="time_query",
            metadata={"query_type": "time", "bypass_teacher": True}
        )

    # 0b. DATE QUERY (also high priority)
    if PATTERN_DATE_QUERY.match(text_normalized):
        return ParsedCommand(
            intent="time_query",
            tools=["time_now"],
            brains=["language"],
            subcommand="GET_DATE",
            args="",
            raw_input=text,
            matched_pattern="date_query",
            metadata={"query_type": "date", "bypass_teacher": True}
        )

    # 0c. CALENDAR QUERY
    if PATTERN_CALENDAR_QUERY.match(text_normalized):
        return ParsedCommand(
            intent="time_query",
            tools=["time_now"],
            brains=["language"],
            subcommand="GET_CALENDAR",
            args="",
            raw_input=text,
            matched_pattern="calendar_query",
            metadata={"query_type": "calendar", "bypass_teacher": True}
        )

    # 1. x grok <message>
    match = PATTERN_X_GROK.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand="grok",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="x_grok",
            metadata={"platform": "x", "action": "grok_chat"}
        )

    # 2. grok <message> (standalone)
    match = PATTERN_GROK_STANDALONE.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand="grok",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="grok_standalone",
            metadata={"platform": "x", "action": "grok_chat"}
        )

    # 3. x post / post to x
    match = PATTERN_X_POST.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand="post",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="x_post",
            metadata={"platform": "x", "action": "post"}
        )

    # 4. research: <topic>
    match = PATTERN_RESEARCH.match(text_normalized)
    if match:
        topic = match.group(1) or match.group(2)
        web_limit = int(match.group(3)) if match.group(3) else 10
        return ParsedCommand(
            intent="research",
            tools=["web_search", "web_fetch"],
            brains=["research_manager", "reasoning"],
            args=topic.strip() if topic else "",
            raw_input=text,
            matched_pattern="research",
            metadata={"web_limit": web_limit, "mode": "deep_research"}
        )

    # 5. browser_open: <url>
    match = PATTERN_BROWSER_OPEN.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_open",
            tools=["browser_open"],
            brains=["language"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="browser_open",
            metadata={"url": match.group(1).strip()}
        )

    # 5b. open <site> and search <query> (compound command)
    match = PATTERN_OPEN_AND_SEARCH.match(text_normalized)
    if match:
        site = match.group(1).lower()
        search_query = match.group(2).strip()

        # Get site-specific search URL or fall back to google
        if site in SITE_SEARCH_PATTERNS:
            search_url = SITE_SEARCH_PATTERNS[site].format(
                query=urllib.parse.quote_plus(search_query)
            )
        elif site in SITE_DOMAIN_MAP:
            # Site doesn't have search pattern, just open it
            search_url = SITE_DOMAIN_MAP[site]
        else:
            # Unknown site, try adding .com
            search_url = f"https://www.{site}.com"

        return ParsedCommand(
            intent="browser_open_and_search",
            tools=["browser_open"],
            brains=["language"],
            args=search_url,
            raw_input=text,
            matched_pattern="open_and_search",
            metadata={
                "url": search_url,
                "site": site,
                "search_query": search_query,
                "compound_action": True,
            }
        )

    # 5c. open <site> (just domain name)
    match = PATTERN_OPEN_SITE.match(text_normalized)
    if match:
        site = match.group(1).lower()

        # Expand to full URL
        if site in SITE_DOMAIN_MAP:
            url = SITE_DOMAIN_MAP[site]
        elif "." in site:
            # Has TLD, use as-is
            url = f"https://www.{site}"
        else:
            # No TLD, add .com
            url = f"https://www.{site}.com"

        return ParsedCommand(
            intent="browser_open",
            tools=["browser_open"],
            brains=["language"],
            args=url,
            raw_input=text,
            matched_pattern="open_site",
            metadata={"url": url, "site": site}
        )

    # 6. search: <query>
    match = PATTERN_WEB_SEARCH.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="web_search",
            tools=["web_search"],
            brains=["research_manager"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="web_search",
            metadata={"query": match.group(1).strip()}
        )

    # 7. use <tool> tool: <args>
    match = PATTERN_EXPLICIT_TOOL.match(text_normalized)
    if match:
        tool_name = match.group(1).lower()
        return ParsedCommand(
            intent="explicit_tool",
            tools=[tool_name],
            brains=["language"],
            args=match.group(2).strip(),
            raw_input=text,
            matched_pattern="explicit_tool",
            metadata={"explicit_tool": tool_name}
        )

    # 8. chatgpt <message>
    match = PATTERN_CHATGPT.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="browser_tool",
            tools=["chatgpt"],
            brains=["language"],
            subcommand="chat",
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="chatgpt",
            metadata={"platform": "chatgpt", "action": "chat"}
        )

    # 9. x <subcommand> <args> (generic)
    match = PATTERN_X_GENERIC.match(text_normalized)
    if match:
        subcommand = match.group(1).lower()
        args = match.group(2).strip() if match.group(2) else ""
        return ParsedCommand(
            intent="browser_tool",
            tools=["x"],
            brains=["language"],
            subcommand=subcommand,
            args=args,
            raw_input=text,
            matched_pattern="x_generic",
            metadata={"platform": "x", "action": subcommand}
        )

    # 10. shell: <command>
    match = PATTERN_SHELL.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="shell_execution",
            tools=["shell"],
            brains=["coder"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="shell",
            metadata={"command": match.group(1).strip()}
        )

    # 11. python: <code>
    match = PATTERN_PYTHON.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="python_execution",
            tools=["python_sandbox"],
            brains=["coder"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="python",
            metadata={"code": match.group(1).strip()}
        )

    # 12. code: <request>
    match = PATTERN_CODE.match(text_normalized)
    if match:
        return ParsedCommand(
            intent="coding",
            tools=[],
            brains=["coder", "reasoning"],
            args=match.group(1).strip(),
            raw_input=text,
            matched_pattern="code",
            metadata={"request": match.group(1).strip()}
        )

    # 13. maven <action>
    match = PATTERN_MAVEN_COMMAND.match(text_normalized)
    if match:
        action = match.group(1).lower()
        extra = match.group(2).strip() if match.group(2) else ""

        if action in ("explain", "introduce", "whoami"):
            return ParsedCommand(
                intent="self_introduction",
                tools=[],
                brains=["self_model"],
                subcommand="introduction",
                args=extra,
                raw_input=text,
                matched_pattern="maven_command",
                metadata={"action": action}
            )
        elif action == "scan":
            return ParsedCommand(
                intent="self_scan",
                tools=[],
                brains=["self_model"],
                subcommand="scan",
                args=extra or "self",
                raw_input=text,
                matched_pattern="maven_command",
                metadata={"action": "scan", "target": extra or "self"}
            )
        elif action == "status":
            return ParsedCommand(
                intent="status",
                tools=[],
                brains=["self_model"],
                subcommand="status",
                args="",
                raw_input=text,
                matched_pattern="maven_command",
                metadata={"action": "status"}
            )

    # 14. pc: <command> (PC control - system monitoring, cleanup, security)
    match = PATTERN_PC_CONTROL.match(text_normalized)
    if match:
        pc_command = match.group(1).strip() if match.group(1) else "status"
        return ParsedCommand(
            intent="browser_tool",
            tools=["pc"],
            brains=["language"],
            subcommand=pc_command.split()[0] if pc_command else "status",
            args=pc_command,
            raw_input=text,
            matched_pattern="pc_control",
            metadata={"tool": "pc", "command": pc_command}
        )

    # 15. human: <command> (desktop control - mouse, keyboard, screenshots)
    match = PATTERN_HUMAN_CONTROL.match(text_normalized)
    if match:
        human_command = match.group(1).strip() if match.group(1) else ""
        return ParsedCommand(
            intent="browser_tool",
            tools=["human"],
            brains=["language"],
            subcommand=human_command.split()[0] if human_command else "help",
            args=human_command,
            raw_input=text,
            matched_pattern="human_control",
            metadata={"tool": "human", "command": human_command}
        )

    # =========================================================================
    # BROWSER ACTION PATTERNS - Only match if browser is active
    # =========================================================================
    # These patterns are for interacting with an already-open browser page.
    # They only match when context indicates an active browser session.

    if browser_active:
        # 16a. click/tap/press <target>
        match = PATTERN_BROWSER_CLICK.match(text_normalized)
        if match:
            target = match.group(1).strip()
            return ParsedCommand(
                intent="browser_action",
                tools=["browser_click"],
                brains=["language"],
                subcommand="click",
                args=target,
                raw_input=text,
                matched_pattern="browser_click",
                metadata={
                    "action": "click",
                    "target": target,
                    "page_id": browser_page_id,
                }
            )

        # 16b. pick/choose/select <target>
        match = PATTERN_BROWSER_PICK.match(text_normalized)
        if match:
            target = match.group(1).strip()
            return ParsedCommand(
                intent="browser_action",
                tools=["browser_click"],
                brains=["language"],
                subcommand="pick",
                args=target,
                raw_input=text,
                matched_pattern="browser_pick",
                metadata={
                    "action": "pick",
                    "target": target,
                    "page_id": browser_page_id,
                }
            )

        # 16c. play <target> (video/media)
        match = PATTERN_BROWSER_PLAY.match(text_normalized)
        if match:
            target = match.group(1).strip() if match.group(1) else "video"
            return ParsedCommand(
                intent="browser_action",
                tools=["browser_click"],
                brains=["language"],
                subcommand="play",
                args=target,
                raw_input=text,
                matched_pattern="browser_play",
                metadata={
                    "action": "play",
                    "target": target,
                    "page_id": browser_page_id,
                }
            )

        # 16d. open/view result/link on page
        match = PATTERN_BROWSER_VIEW.match(text_normalized)
        if match:
            extra = match.group(1).strip() if match.group(1) else ""
            return ParsedCommand(
                intent="browser_action",
                tools=["browser_click"],
                brains=["language"],
                subcommand="view",
                args=extra,
                raw_input=text,
                matched_pattern="browser_view",
                metadata={
                    "action": "view",
                    "target": extra,
                    "page_id": browser_page_id,
                }
            )

        # 16e. scroll up/down/to top/bottom
        match = PATTERN_BROWSER_SCROLL.match(text_normalized)
        if match:
            direction = match.group(1) or match.group(2) or "down"
            return ParsedCommand(
                intent="browser_action",
                tools=["browser_scroll"],
                brains=["language"],
                subcommand="scroll",
                args=direction.lower(),
                raw_input=text,
                matched_pattern="browser_scroll",
                metadata={
                    "action": "scroll",
                    "direction": direction.lower(),
                    "page_id": browser_page_id,
                }
            )

        # 16f. go back/forward/refresh
        match = PATTERN_BROWSER_NAV.match(text_normalized)
        if match:
            nav_action = match.group(1).lower()
            return ParsedCommand(
                intent="browser_action",
                tools=["browser_navigate"],
                brains=["language"],
                subcommand=nav_action,
                args="",
                raw_input=text,
                matched_pattern="browser_nav",
                metadata={
                    "action": nav_action,
                    "page_id": browser_page_id,
                }
            )

        # 16g. type/enter/search for <text>
        match = PATTERN_BROWSER_TYPE.match(text_normalized)
        if match:
            text_to_type = match.group(1).strip()
            return ParsedCommand(
                intent="browser_action",
                tools=["browser_type"],
                brains=["language"],
                subcommand="type",
                args=text_to_type,
                raw_input=text,
                matched_pattern="browser_type",
                metadata={
                    "action": "type",
                    "text": text_to_type,
                    "page_id": browser_page_id,
                }
            )

    # No grammar match
    return None


def is_explicit_command(text: str) -> bool:
    """
    Quick check if text is an explicit command that should bypass integrator.

    Args:
        text: User input text

    Returns:
        True if this is an explicit tool command
    """
    return parse_command(text) is not None


def is_browser_action_intent(text: str) -> bool:
    """
    Check if text looks like a browser action command.

    This checks the patterns WITHOUT requiring browser context,
    so it can be used to determine if we should check for active browser.

    Args:
        text: User input text

    Returns:
        True if this looks like a browser action command
    """
    if not text:
        return False

    text = text.strip()
    text_normalized = re.sub(r'\s+', ' ', text).lower()

    # Quick keyword check first
    first_word = text_normalized.split()[0] if text_normalized else ""
    if first_word not in BROWSER_ACTION_KEYWORDS:
        return False

    # Check specific patterns
    if PATTERN_BROWSER_CLICK.match(text_normalized):
        return True
    if PATTERN_BROWSER_PICK.match(text_normalized):
        return True
    if PATTERN_BROWSER_PLAY.match(text_normalized):
        return True
    if PATTERN_BROWSER_VIEW.match(text_normalized):
        return True
    if PATTERN_BROWSER_SCROLL.match(text_normalized):
        return True
    if PATTERN_BROWSER_NAV.match(text_normalized):
        return True
    if PATTERN_BROWSER_TYPE.match(text_normalized):
        return True

    return False


def get_routing_plan(parsed: ParsedCommand) -> Dict[str, Any]:
    """
    Convert a ParsedCommand to a routing plan for integrator.

    Args:
        parsed: The parsed command result

    Returns:
        Routing plan dictionary compatible with integrator
    """
    return {
        "brains": parsed.brains,
        "tools": parsed.tools,
        "source": f"grammar:{parsed.matched_pattern}",
        "confidence": parsed.confidence,
        "bypass_learned": True,  # Don't let learned patterns override
        "bypass_llm_router": True,  # Don't need LLM router
        "intent": parsed.intent,
        "subcommand": parsed.subcommand,
        "args": parsed.args,
        "metadata": parsed.metadata,
    }


def log_gold_routing(parsed: ParsedCommand) -> Dict[str, Any]:
    """
    Create a gold routing example for learning.

    These examples can be used to train the routing patterns and
    provide few-shot examples to the router LLM.

    Args:
        parsed: The parsed command

    Returns:
        Gold routing example for storage
    """
    return {
        "input": parsed.raw_input,
        "normalized": re.sub(r'\s+', ' ', parsed.raw_input.strip()),
        "intent": parsed.intent,
        "tools": parsed.tools,
        "brains": parsed.brains,
        "subcommand": parsed.subcommand,
        "pattern": parsed.matched_pattern,
        "confidence": 1.0,
        "source": "grammar",
        "is_gold": True,
    }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "ParsedCommand",
    "parse_command",
    "is_explicit_command",
    "is_browser_action_intent",
    "get_routing_plan",
    "log_gold_routing",
    "BROWSER_ACTION_KEYWORDS",
]
