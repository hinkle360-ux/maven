"""
Brain Migration Compatibility Layer
====================================

Provides backward-compatible base classes for gradual migration
from old brain contracts to the new ContextAwareBrain architecture.

Migration Strategy:
1. ContextCompatibleBrain - works with both old and new patterns
2. LegacyBrainAdapter - wraps old brains for context system
3. Migration helpers for incremental transition

Usage:
    # Old brain (still works):
    class MyOldBrain:
        def handle(self, context):
            return {"status": "ok", "payload": result}

    # Migration step 1 - inherit from ContextCompatibleBrain:
    class MyBrain(ContextCompatibleBrain):
        brain_name = "my_brain"
        actor = "reasoning"

        def handle(self, context):
            # Old logic still works
            return {"status": "ok", "payload": result}

    # Migration step 2 - implement _process_with_context:
    class MyBrain(ContextCompatibleBrain):
        brain_name = "my_brain"
        actor = "reasoning"

        def _process_with_context(self, context, bundle):
            # New logic with context
            return {"status": "ok", "payload": result}
"""

from __future__ import annotations
from abc import ABC
from typing import Dict, Any, Optional, List, Callable
from dataclasses import dataclass
import time
import logging

from brains.base.context_aware_brain import (
    ContextAwareBrain,
    ContextRequirement,
    ContextUsageReport,
    get_context_manager,
    AnswerCandidate,
    get_answer_candidate,
    has_answer_candidate,
    get_critical_context,
    format_context_for_prompt,
)

logger = logging.getLogger(__name__)


# =============================================================================
# COMPATIBILITY BASE CLASS
# =============================================================================

class ContextCompatibleBrain(ABC):
    """
    Backward-compatible brain base class for gradual migration.

    Supports both patterns:
    - OLD: Override handle() directly
    - NEW: Override _process_with_context() for context-aware processing

    The class automatically detects which pattern is being used and
    routes accordingly.
    """

    # Subclasses should override these
    brain_name: str = "unknown"
    actor: str = "unknown"

    # Context requirement (can be overridden)
    _context_requirement: Optional[ContextRequirement] = None

    def __init__(self):
        """Initialize with optional context requirement."""
        self._use_context = self._has_context_implementation()

    def _has_context_implementation(self) -> bool:
        """Check if subclass implements _process_with_context."""
        # Check if _process_with_context is overridden
        return (
            hasattr(self, '_process_with_context') and
            self._process_with_context.__func__ is not ContextCompatibleBrain._process_with_context.__func__
        )

    def get_context_requirement(self) -> ContextRequirement:
        """Return context requirements. Override for custom requirements."""
        if self._context_requirement:
            return self._context_requirement
        return ContextRequirement(min_items=0)  # Default: no minimum

    def _infer_task_type(self, context: Dict[str, Any]) -> str:
        """Infer task type from context."""
        op = context.get("op", "").upper()
        payload = context.get("payload", {})
        text = payload.get("text", payload.get("query", "")).lower()

        # Check for personal queries
        personal_patterns = [
            "what is my", "what are my", "who am i",
            "my name", "my location", "my preference"
        ]
        if any(p in text for p in personal_patterns):
            return "personal_query"

        # Map ops to task types
        op_to_task = {
            "EVALUATE_FACT": "research_question",
            "EVALUATE_CODE": "code_fix",
            "GENERATE_CODE": "code_generation",
            "PLAN": "routing",
            "ROUTE": "routing",
            "VALIDATE": "safety_decision",
        }

        if op in op_to_task:
            return op_to_task[op]

        # Check text for hints
        if any(word in text for word in ["code", "function", "class", "bug", "error"]):
            return "code_fix"
        if any(word in text for word in ["math", "calculate", "compute", "+", "-", "*", "/"]):
            return "math_question"

        return "unknown"

    def _infer_stage(self, context: Dict[str, Any]) -> str:
        """Infer pipeline stage from context."""
        op = context.get("op", "").upper()

        stage_map = {
            "ROUTE": "routing_decision",
            "PLAN": "plan_generation",
            "GENERATE_CODE": "code_edit",
            "EVALUATE": "validation",
            "EVALUATE_FACT": "query_answer",
            "GENERATE": "generation",
        }

        return stage_map.get(op, "query_answer")

    def handle(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Main entry point - routes to appropriate implementation.

        If _process_with_context is implemented, fetches context first.
        Otherwise, calls _legacy_handle for backward compatibility.
        """
        if self._use_context:
            return self._handle_with_context(context)
        else:
            return self._legacy_handle(context)

    def _handle_with_context(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle with automatic context injection."""
        start_time = time.time()

        # Get context manager
        ctx_manager = get_context_manager()

        # Build context event parameters
        payload = context.get("payload", {})
        input_text = payload.get("text", payload.get("query", str(payload)))
        task_type = self._infer_task_type(context)
        stage = self._infer_stage(context)

        # Fetch context bundle
        bundle = ctx_manager.build_bundle(
            actor=self.actor,
            stage=stage,
            task_type=task_type,
            input_text=input_text,
            constraints=payload.get("constraints", {})
        )

        # Check context requirement
        requirement = self.get_context_requirement()
        top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else getattr(bundle, "top_context", [])

        if len(top_context) < requirement.min_items:
            logger.warning(
                f"{self.brain_name}: Got {len(top_context)} context items, "
                f"need {requirement.min_items}. Proceeding with available context."
            )

        # Process with context
        try:
            result = self._process_with_context(context, bundle)
        except Exception as e:
            logger.error(f"{self.brain_name} processing error: {e}")
            result = {"status": "error", "error": str(e)}

        # Report usage
        processing_time = (time.time() - start_time) * 1000
        items_used = result.get("_context_items_used", [])

        report = ContextUsageReport(
            brain_name=self.brain_name,
            context_items_provided=len(top_context),
            context_items_used=len(items_used),
            items_used_ids=items_used,
            processing_time_ms=processing_time,
            context_was_helpful=result.get("_context_was_helpful", True),
            notes=result.get("_context_notes", "")
        )

        try:
            ctx_manager.report_usage(report)
        except Exception as e:
            logger.debug(f"Failed to report context usage: {e}")

        # Clean up internal tracking keys
        result.pop("_context_items_used", None)
        result.pop("_context_was_helpful", None)
        result.pop("_context_notes", None)

        return result

    def _legacy_handle(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fallback for brains that don't implement _process_with_context.

        Subclasses can override this to provide legacy behavior.
        """
        raise NotImplementedError(
            f"{self.brain_name} must implement either _process_with_context() "
            f"or override _legacy_handle()"
        )

    def _process_with_context(
        self,
        context: Dict[str, Any],
        bundle: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Process request with context bundle.

        Override this in subclasses for context-aware processing.
        """
        raise NotImplementedError("Subclass must implement _process_with_context")

    # Alias for compatibility
    def service_api(self, msg: Dict[str, Any]) -> Dict[str, Any]:
        """Alias for handle() to match brain contract."""
        return self.handle(msg)


# =============================================================================
# LEGACY BRAIN ADAPTER
# =============================================================================

class LegacyBrainAdapter:
    """
    Wraps an old-style brain function for the context system.

    Usage:
        # Wrap a legacy brain function
        adapted = LegacyBrainAdapter(
            legacy_func=old_brain.service_api,
            brain_name="old_brain",
            actor="reasoning"
        )

        # Use with context
        result = adapted.handle(context)
    """

    def __init__(
        self,
        legacy_func: Callable[[Dict], Dict],
        brain_name: str,
        actor: str,
        inject_context: bool = True
    ):
        """
        Initialize adapter.

        Args:
            legacy_func: The old service_api or handle function
            brain_name: Name for logging and reporting
            actor: Actor type for context queries
            inject_context: Whether to inject context into payload
        """
        self.legacy_func = legacy_func
        self.brain_name = brain_name
        self.actor = actor
        self.inject_context = inject_context

    def handle(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Handle with optional context injection."""
        if self.inject_context:
            return self._handle_with_injection(context)
        else:
            return self.legacy_func(context)

    def _handle_with_injection(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """Inject context into payload before calling legacy function."""
        start_time = time.time()

        # Get context
        ctx_manager = get_context_manager()
        payload = context.get("payload", {})
        input_text = payload.get("text", payload.get("query", str(payload)))

        bundle = ctx_manager.build_bundle(
            actor=self.actor,
            stage="query_answer",
            task_type="unknown",
            input_text=input_text,
        )

        # Inject into payload
        enriched_context = context.copy()
        enriched_payload = payload.copy()
        enriched_payload["_context_bundle"] = bundle
        enriched_payload["_context_formatted"] = format_context_for_prompt(bundle)
        enriched_context["payload"] = enriched_payload

        # Call legacy function
        result = self.legacy_func(enriched_context)

        # Report usage
        processing_time = (time.time() - start_time) * 1000
        top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else []

        report = ContextUsageReport(
            brain_name=self.brain_name,
            context_items_provided=len(top_context),
            context_items_used=0,  # Unknown for legacy
            items_used_ids=[],
            processing_time_ms=processing_time,
            context_was_helpful=True,  # Assume helpful
        )

        try:
            ctx_manager.report_usage(report)
        except Exception:
            pass

        return result

    def service_api(self, msg: Dict[str, Any]) -> Dict[str, Any]:
        """Alias for handle()."""
        return self.handle(msg)


# =============================================================================
# MIGRATION HELPERS
# =============================================================================

def migrate_brain_to_context_aware(
    brain_module,
    brain_name: str,
    actor: str
) -> LegacyBrainAdapter:
    """
    Quick migration: wrap a brain module for context system.

    Args:
        brain_module: Module with service_api or handle function
        brain_name: Name for the brain
        actor: Actor type

    Returns:
        LegacyBrainAdapter wrapping the brain
    """
    # Find the entry point
    if hasattr(brain_module, 'service_api'):
        func = brain_module.service_api
    elif hasattr(brain_module, 'handle'):
        func = brain_module.handle
    else:
        raise ValueError(f"Brain module {brain_name} has no service_api or handle function")

    return LegacyBrainAdapter(
        legacy_func=func,
        brain_name=brain_name,
        actor=actor,
        inject_context=True
    )


def check_brain_migration_status(brain_class) -> Dict[str, Any]:
    """
    Check migration status of a brain class.

    Returns:
        Dict with migration status info
    """
    status = {
        "class_name": brain_class.__name__,
        "is_context_compatible": False,
        "is_context_aware": False,
        "has_process_with_context": False,
        "has_legacy_handle": False,
        "migration_stage": "not_started",
    }

    # Check inheritance
    if issubclass(brain_class, ContextAwareBrain):
        status["is_context_aware"] = True
        status["is_context_compatible"] = True
        status["migration_stage"] = "complete"
    elif issubclass(brain_class, ContextCompatibleBrain):
        status["is_context_compatible"] = True
        status["migration_stage"] = "in_progress"

    # Check method implementations
    if hasattr(brain_class, '_process_with_context'):
        method = getattr(brain_class, '_process_with_context')
        if hasattr(method, '__func__'):
            if issubclass(brain_class, ContextCompatibleBrain):
                if method.__func__ is not ContextCompatibleBrain._process_with_context.__func__:
                    status["has_process_with_context"] = True
                    status["migration_stage"] = "context_enabled"
            elif issubclass(brain_class, ContextAwareBrain):
                if method.__func__ is not ContextAwareBrain._process_with_context.__func__:
                    status["has_process_with_context"] = True

    if hasattr(brain_class, '_legacy_handle'):
        method = getattr(brain_class, '_legacy_handle')
        if hasattr(method, '__func__'):
            if issubclass(brain_class, ContextCompatibleBrain):
                if method.__func__ is not ContextCompatibleBrain._legacy_handle.__func__:
                    status["has_legacy_handle"] = True

    return status


# =============================================================================
# CONTEXT PROTOCOL INITIALIZATION
# =============================================================================

def initialize_context_protocol_for_migration() -> None:
    """
    Initialize context protocol with NullContextManager if not set.

    Call this at startup to ensure context system is available,
    even if full context manager isn't configured.
    """
    from brains.base.context_aware_brain import (
        get_context_manager,
        set_context_manager,
        NullContextManager
    )

    # Check if already initialized
    try:
        manager = get_context_manager()
        if not isinstance(manager, NullContextManager):
            logger.info("Context protocol already initialized with real manager")
            return
    except Exception:
        pass

    # Try to initialize real context manager
    try:
        from brains.cognitive.context_management.service.context_manager import (
            get_maven_context_manager,
            initialize_context_protocol
        )

        initialize_context_protocol()
        logger.info("Context protocol initialized with MavenContextManager")

    except ImportError as e:
        logger.warning(f"Could not import context manager: {e}")
        logger.info("Using NullContextManager for graceful degradation")
    except Exception as e:
        logger.warning(f"Failed to initialize context manager: {e}")
        logger.info("Using NullContextManager for graceful degradation")


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    "ContextCompatibleBrain",
    "LegacyBrainAdapter",
    "migrate_brain_to_context_aware",
    "check_brain_migration_status",
    "initialize_context_protocol_for_migration",
]
