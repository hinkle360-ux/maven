"""
Context-Aware Brain Base Class
==============================

Base class for all brains that MUST use context.
Enforces mandatory context protocol across Maven's cognitive architecture.

Design principles:
- Brains CANNOT skip context lookup - it's built into the base class
- Context is automatically fetched and injected before handle() runs
- Subclasses implement _process_with_context() instead of handle()
- This ensures consistent context usage across all cognitive brains
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, TYPE_CHECKING, Union
from dataclasses import dataclass
import time
import logging

# Use forward reference to avoid circular imports
if TYPE_CHECKING:
    from brains.cognitive.context_management.context_bundle import (
        ContextBundle, ContextEvent, Actor, Stage, TaskType
    )

logger = logging.getLogger(__name__)


# =============================================================================
# CONTEXT PROTOCOL TYPES
# =============================================================================

@dataclass
class ContextItem:
    """
    Individual context item from memory/domain banks.

    This represents a single piece of context that may be used
    in reasoning, planning, or code generation.
    """
    source: str  # e.g., "domain_bank.math", "personal_bank", "episodic_memory"
    payload: Any  # The actual content
    score: float  # Relevance score (0.0 to 1.0)
    tags: List[str]  # e.g., ["rule", "math_rule"], ["personal_fact"]
    why: str  # Explanation of why this item is relevant
    timestamp: float = 0.0  # When this was stored/retrieved

    def is_critical(self) -> bool:
        """Check if this item is critical (must be used)."""
        critical_tags = ["personal_fact", "user_correction", "rule", "math_rule"]
        return any(tag in self.tags for tag in critical_tags) and self.score > 0.7

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "source": self.source,
            "payload": self.payload,
            "score": self.score,
            "tags": self.tags,
            "why": self.why,
            "timestamp": self.timestamp,
        }


@dataclass
class AnswerCandidate:
    """
    Explicit answer hypothesis from context system.

    For tasks with a clear answer (math, personal queries, fact lookups),
    the context system nominates its best guess BEFORE reasoning runs.
    This prevents LLM hallucination by providing a pre-validated answer.
    """
    value: Any  # The actual answer (e.g., "4", "Alice", "addition rule")
    confidence: float  # 0.0 to 1.0
    source: str  # Where it came from (e.g., "domain_bank.math", "personal_bank")
    source_item: Optional["ContextItem"]  # Full item that generated this candidate
    why: str  # Explanation: "highest scoring math rule"
    extraction_method: str  # How value was extracted: "key_value_parse", "rule_extraction"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "value": self.value,
            "confidence": self.confidence,
            "source": self.source,
            "why": self.why,
            "extraction_method": self.extraction_method,
        }


@dataclass
class ContextRequirement:
    """Declares what context a brain needs."""
    min_items: int = 1
    required_sources: List[str] = None  # Must have items from these sources
    preferred_sources: List[str] = None  # Prefer items from these sources
    task_types: List[str] = None  # Relevant task types
    max_age_seconds: float = 3600.0  # Maximum age for context items

    def __post_init__(self):
        self.required_sources = self.required_sources or []
        self.preferred_sources = self.preferred_sources or []
        self.task_types = self.task_types or []


@dataclass
class ContextUsageReport:
    """Records how context was used in processing."""
    brain_name: str
    context_items_provided: int
    context_items_used: int
    items_used_ids: List[str]
    processing_time_ms: float
    context_was_helpful: bool
    notes: str = ""


# =============================================================================
# CONTEXT MANAGER INTERFACE
# =============================================================================

class ContextManagerInterface(ABC):
    """Interface for the context management system."""

    @abstractmethod
    def build_bundle(
        self,
        actor: str,
        stage: str,
        task_type: str,
        input_text: str,
        constraints: Dict[str, Any] = None
    ) -> "ContextBundle":
        """Build a context bundle for the given event."""
        pass

    @abstractmethod
    def report_usage(self, report: ContextUsageReport) -> None:
        """Report how context was used (for learning)."""
        pass


# =============================================================================
# NULL CONTEXT MANAGER (for graceful degradation)
# =============================================================================

class NullContextManager(ContextManagerInterface):
    """Fallback context manager when real one isn't available."""

    def build_bundle(
        self,
        actor: str,
        stage: str,
        task_type: str,
        input_text: str,
        constraints: Dict[str, Any] = None
    ) -> Dict[str, Any]:
        """Return empty bundle structure."""
        return {
            "bundle_id": f"null-{time.time()}",
            "top_context": [],
            "supporting_context": [],
            "query_plan": {"sources": []},
            "is_null_bundle": True,
        }

    def report_usage(self, report: ContextUsageReport) -> None:
        """No-op for null manager."""
        pass


# Global context manager reference
_context_manager: Optional[ContextManagerInterface] = None


def set_context_manager(manager: ContextManagerInterface) -> None:
    """Set the global context manager instance."""
    global _context_manager
    _context_manager = manager


def get_context_manager() -> ContextManagerInterface:
    """Get the context manager, falling back to null manager."""
    global _context_manager
    if _context_manager is None:
        logger.warning("No context manager set, using NullContextManager")
        return NullContextManager()
    return _context_manager


# =============================================================================
# CONTEXT-AWARE BRAIN BASE CLASS
# =============================================================================

class ContextAwareBrain(ABC):
    """
    Base class for brains that MUST use context.

    Subclasses MUST implement:
    - _process_with_context(): Main processing logic with context
    - get_context_requirement(): Declare what context is needed
    - brain_name: Property returning brain identifier
    - actor: Property returning Actor enum value

    The base class handles:
    - Automatic context fetching before processing
    - Context injection into the processing method
    - Usage reporting after processing
    - Graceful degradation if context unavailable
    """

    @property
    @abstractmethod
    def brain_name(self) -> str:
        """Return the brain's identifier."""
        pass

    @property
    @abstractmethod
    def actor(self) -> str:
        """Return the actor type (from Actor enum)."""
        pass

    @abstractmethod
    def get_context_requirement(self) -> ContextRequirement:
        """Declare what context this brain needs."""
        pass

    @abstractmethod
    def _process_with_context(
        self,
        context: Dict[str, Any],
        bundle: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Process the request WITH context.

        Args:
            context: The incoming context dict with op, payload, etc.
            bundle: The context bundle with top_context, supporting_context, etc.

        Returns:
            Result dict with status and payload
        """
        pass

    def _infer_task_type(self, context: Dict[str, Any]) -> str:
        """Infer task type from context. Can be overridden by subclasses."""
        op = context.get("op", "").upper()
        payload = context.get("payload", {})
        text = payload.get("text", payload.get("query", "")).lower()

        # Check for personal queries first
        personal_patterns = [
            "what is my", "what are my", "who am i",
            "my name", "my location", "my preference"
        ]
        if any(p in text for p in personal_patterns):
            return "personal_query"

        # Map ops to task types
        op_to_task = {
            "EVALUATE_FACT": "research_question",
            "EVALUATE_CODE": "code_fix",
            "GENERATE_CODE": "code_generation",
            "PLAN": "routing",
            "ROUTE": "routing",
            "VALIDATE": "safety_decision",
        }

        if op in op_to_task:
            return op_to_task[op]

        # Check text for hints
        if any(word in text for word in ["code", "function", "class", "bug", "error"]):
            return "code_fix"
        if any(word in text for word in ["math", "calculate", "compute", "+", "-", "*", "/"]):
            return "math_question"

        return "unknown"

    def _infer_stage(self, context: Dict[str, Any]) -> str:
        """Infer pipeline stage from context. Can be overridden by subclasses."""
        op = context.get("op", "").upper()

        stage_map = {
            "ROUTE": "routing_decision",
            "PLAN": "plan_generation",
            "GENERATE_CODE": "code_edit",
            "EVALUATE": "validation",
            "EVALUATE_FACT": "query_answer",
            "GENERATE": "generation",
        }

        return stage_map.get(op, "query_answer")

    def handle(self, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        Main entry point - ALWAYS fetches context first.

        This is the canonical entry point that enforces context usage.
        Subclasses should NOT override this - override _process_with_context instead.
        """
        start_time = time.time()

        # Get the context manager
        ctx_manager = get_context_manager()

        # Build context event parameters
        payload = context.get("payload", {})
        input_text = payload.get("text", payload.get("query", str(payload)))
        task_type = self._infer_task_type(context)
        stage = self._infer_stage(context)

        # Fetch context bundle
        bundle = ctx_manager.build_bundle(
            actor=self.actor,
            stage=stage,
            task_type=task_type,
            input_text=input_text,
            constraints=payload.get("constraints", {})
        )

        # Check if we have minimum required context
        requirement = self.get_context_requirement()
        top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else getattr(bundle, "top_context", [])

        if len(top_context) < requirement.min_items:
            logger.warning(
                f"{self.brain_name}: Got {len(top_context)} context items, "
                f"need {requirement.min_items}. Proceeding with available context."
            )

        # Process with context
        try:
            result = self._process_with_context(context, bundle)
        except Exception as e:
            logger.error(f"{self.brain_name} processing error: {e}")
            result = {"status": "error", "error": str(e)}

        # Report usage
        processing_time = (time.time() - start_time) * 1000
        items_used = result.get("_context_items_used", [])

        report = ContextUsageReport(
            brain_name=self.brain_name,
            context_items_provided=len(top_context),
            context_items_used=len(items_used),
            items_used_ids=items_used,
            processing_time_ms=processing_time,
            context_was_helpful=result.get("_context_was_helpful", True),
            notes=result.get("_context_notes", "")
        )

        try:
            ctx_manager.report_usage(report)
        except Exception as e:
            logger.debug(f"Failed to report context usage: {e}")

        # Clean up internal tracking keys
        result.pop("_context_items_used", None)
        result.pop("_context_was_helpful", None)
        result.pop("_context_notes", None)

        return result

    # Alias for compatibility with existing brain contract
    def service_api(self, msg: Dict[str, Any]) -> Dict[str, Any]:
        """Alias for handle() to match brain contract."""
        return self.handle(msg)


# =============================================================================
# HELPER FUNCTIONS FOR CONTEXT EXTRACTION
# =============================================================================

def extract_text_from_context(bundle: Dict[str, Any], max_items: int = 5) -> str:
    """Extract text content from context bundle items."""
    top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else getattr(bundle, "top_context", [])

    texts = []
    for i, item in enumerate(top_context[:max_items]):
        if isinstance(item, dict):
            text = item.get("text", item.get("content", str(item)))
        else:
            text = str(item)
        texts.append(f"[{i+1}] {text}")

    return "\n".join(texts)


def get_context_by_role(bundle: Dict[str, Any], role: str) -> List[Dict[str, Any]]:
    """Get context items with a specific role."""
    top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else getattr(bundle, "top_context", [])

    return [
        item for item in top_context
        if isinstance(item, dict) and item.get("role") == role
    ]


def get_context_by_source(bundle: Dict[str, Any], source: str) -> List[Dict[str, Any]]:
    """Get context items from a specific source."""
    top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else getattr(bundle, "top_context", [])

    return [
        item for item in top_context
        if isinstance(item, dict) and source in item.get("source", "")
    ]


def has_personal_context(bundle: Dict[str, Any]) -> bool:
    """Check if bundle contains personal context items."""
    personal_sources = ["personal_bank", "session_context", "domain_bank.personal"]
    top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else getattr(bundle, "top_context", [])

    for item in top_context:
        if isinstance(item, dict):
            source = item.get("source", "")
            if any(ps in source for ps in personal_sources):
                return True
            if item.get("role") == "personal_fact":
                return True
    return False


# =============================================================================
# ANSWER CANDIDATE HELPERS
# =============================================================================

def get_answer_candidate(bundle: Dict[str, Any]) -> Optional[AnswerCandidate]:
    """
    Extract answer candidate from bundle if present.

    Returns None if no answer candidate is available.
    """
    if isinstance(bundle, dict):
        candidate_dict = bundle.get("answer_candidate")
        if candidate_dict and isinstance(candidate_dict, dict):
            return AnswerCandidate(
                value=candidate_dict.get("value"),
                confidence=candidate_dict.get("confidence", 0.0),
                source=candidate_dict.get("source", "unknown"),
                source_item=None,  # Not preserved in dict form
                why=candidate_dict.get("why", ""),
                extraction_method=candidate_dict.get("extraction_method", "unknown"),
            )
    return None


def has_answer_candidate(bundle: Dict[str, Any]) -> bool:
    """Check if bundle contains an answer candidate."""
    if isinstance(bundle, dict):
        return bundle.get("answer_candidate") is not None
    return hasattr(bundle, "answer_candidate") and bundle.answer_candidate is not None


def get_critical_context(bundle: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Extract critical context items that MUST be used in reasoning.

    Critical items are:
    - Personal facts (score > 0.7)
    - User corrections (any score)
    - Math/domain rules (score > 0.7)
    """
    top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else getattr(bundle, "top_context", [])

    critical = []
    for item in top_context:
        if isinstance(item, dict):
            tags = item.get("tags", [])
            score = item.get("score", 0.0)

            # Personal facts are always critical
            if "personal_fact" in tags:
                critical.append(item)
            # User corrections are critical regardless of score
            elif "user_correction" in tags:
                critical.append(item)
            # Rules are critical if high score
            elif any(t in tags for t in ["rule", "math_rule"]) and score > 0.7:
                critical.append(item)

    return critical


def format_context_for_prompt(
    bundle: Dict[str, Any],
    max_critical: int = 5,
    max_supporting: int = 3
) -> str:
    """
    Format context bundle for LLM prompt injection.

    Produces a structured string with critical context prominently displayed,
    and answer candidate highlighted if present.
    """
    lines = []

    # Answer candidate section (if present)
    if has_answer_candidate(bundle):
        candidate = get_answer_candidate(bundle)
        if candidate:
            lines.append("ANSWER CANDIDATE (from context analysis):")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            lines.append(f"Value: {candidate.value}")
            lines.append(f"Confidence: {candidate.confidence:.2f}")
            lines.append(f"Source: {candidate.source}")
            lines.append(f"Why: {candidate.why}")
            lines.append("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            lines.append("")

    # Critical context section
    critical = get_critical_context(bundle)
    if critical:
        lines.append("CRITICAL CONTEXT (must use):")
        for i, item in enumerate(critical[:max_critical], 1):
            content = item.get("content", item.get("payload", str(item)))
            source = item.get("source", "unknown")
            lines.append(f"  [{i}] [{source}] {content}")
        lines.append("")

    # Supporting context section
    top_context = bundle.get("top_context", []) if isinstance(bundle, dict) else []
    supporting = [item for item in top_context if item not in critical]
    if supporting:
        lines.append("SUPPORTING CONTEXT:")
        for i, item in enumerate(supporting[:max_supporting], 1):
            content = item.get("content", item.get("payload", str(item)))
            lines.append(f"  [{i}] {content[:100]}...")
        lines.append("")

    return "\n".join(lines)
