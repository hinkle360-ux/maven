# brains/tools/grok_conversation_session.py
"""
Grok Conversation Session Controller
====================================

Autonomous conversation session manager for Maven-Grok interactions.
Enables Maven to have extended conversations with Grok on X/Twitter,
learn from those conversations, and store insights.

Usage:
    maven have a convo with grok about medicine for 20 minutes
    talk to grok about AI for 10 min

The controller:
1. Parses topic and duration from user command
2. Opens autonomous conversation loop with Grok
3. Manages turn-taking between Maven and Grok
4. Summarizes and stores learned facts when done
5. Reports back to the user with a recap
"""

from __future__ import annotations
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

# Import blackboard for the LLM-as-advisor architecture
try:
    from brains.pipeline.blackboard import Blackboard, create_blackboard
    _blackboard_available = True
except ImportError:
    _blackboard_available = False
    Blackboard = None

# Import Maven Responder - the ONLY authority for external voice
try:
    from brains.cognitive.maven_responder.service.maven_responder import (
        get_maven_responder,
        log_turn_for_learning,
    )
    _responder_available = True
except ImportError:
    _responder_available = False

# Import Self Introspection - registry-based self-knowledge
try:
    from brains.cognitive.self_introspection.service.self_introspection_brain import (
        answer_self_question as _registry_answer_self_question,
        get_architecture_summary,
    )
    _introspection_available = True
except ImportError:
    _introspection_available = False

# Import Teacher helper for Maven's responses (INTERNAL advisor only)
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("grok_session")
except Exception as e:
    print(f"[GROK_SESSION] Teacher helper unavailable: {e}")
    _teacher_helper = None

# Import research manager for fact storage
try:
    from brains.cognitive.research_manager.service.research_manager_brain import (
        _store_fact_record,
        create_research_job,
        update_research_job,
        increment_facts_count,
    )
    _research_available = True
except Exception as e:
    print(f"[GROK_SESSION] Research manager unavailable: {e}")
    _research_available = False

# Import grok tool for sending messages (session-aware)
try:
    from optional.browser_tools.x_tool import grok_open_session, grok_send
    _grok_available = True
except Exception as e:
    print(f"[GROK_SESSION] Grok tool unavailable: {e}")
    _grok_available = False
    grok_open_session = None
    grok_send = None

# Import memory for session storage
try:
    from brains.memory.brain_memory import BrainMemory
    _session_memory = BrainMemory("grok_sessions")
except Exception as e:
    print(f"[GROK_SESSION] Memory unavailable: {e}")
    _session_memory = None

# FIX: Import system_identity for Maven self-presentation
try:
    from brains.cognitive.self_model.system_identity import (
        get_identity_context,
        CANONICAL_IDENTITY,
    )
    _identity_available = True
except ImportError:
    _identity_available = False
    print("[GROK_SESSION] system_identity not available for self-presentation")


# ============================================================================
# Configuration & Constants
# ============================================================================

# Safety limits
MAX_DURATION_MINUTES = 30  # Hard limit on session duration
MAX_TURNS = 30  # Maximum back-and-forth exchanges
DEFAULT_DURATION_MINUTES = 10  # Default if not specified
DEFAULT_MAX_TURNS = 10  # 5 phases x 2 prompts = 10 turns max

# Response timing
WAIT_BETWEEN_TURNS_SECONDS = 3  # Brief pause between exchanges
GROK_RESPONSE_TIMEOUT_SECONDS = 90  # Max wait for Grok's response

# Session storage directory
SESSION_TRANSCRIPT_DIR = Path("grok_sessions")

# Number of conversation phases available
NUM_PHASES = 5
PROMPTS_PER_PHASE = 2
TOTAL_UNIQUE_PROMPTS = NUM_PHASES * PROMPTS_PER_PHASE


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class ConversationTurn:
    """Single turn in the conversation."""
    role: str  # "maven" or "grok"
    text: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class SessionState:
    """State of an ongoing conversation session."""
    session_id: str
    topic: str
    duration_minutes: int
    max_turns: int
    start_time: float
    turn_index: int = 0
    transcript: List[ConversationTurn] = field(default_factory=list)
    status: str = "active"  # active, completed, aborted, error
    error_message: Optional[str] = None
    facts_stored: int = 0
    summary: Optional[str] = None
    page_id: Optional[str] = None  # Browser page ID for session reuse
    # Blackboard for LLM-as-advisor architecture
    blackboard: Any = field(default=None)


# ============================================================================
# Command Parsing
# ============================================================================

def parse_conversation_command(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse a conversation command to extract topic and duration.

    Patterns supported:
    - "maven have a convo with grok about <topic> for <N> minutes"
    - "talk to grok about <topic> for <N> min"
    - "chat with grok about <topic>"
    - "have grok discuss <topic> for <N> minutes"
    - "grok conversation about <topic>"

    Args:
        text: User input text

    Returns:
        Dict with 'topic' and 'duration_minutes', or None if no match
    """
    text = text.strip().lower()

    # Pattern 1: "have a convo/conversation with grok about <topic> for <N> minutes"
    pattern1 = r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?grok\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$"

    # Pattern 2: "talk to grok about <topic> for <N> min"
    pattern2 = r"talk\s+(?:to\s+)?grok\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$"

    # Pattern 3: "grok conversation/session about <topic>"
    pattern3 = r"grok\s+(?:conversation|session|discussion|chat)\s+(?:about\s+)?(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$"

    # Pattern 4: "have grok discuss <topic>"
    pattern4 = r"(?:have\s+)?grok\s+(?:discuss|explore|talk\s+about)\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$"

    # Pattern 5: "autonomous grok session on <topic>"
    pattern5 = r"(?:autonomous\s+)?grok\s+session\s+(?:on|about)\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$"

    for pattern in [pattern1, pattern2, pattern3, pattern4, pattern5]:
        match = re.match(pattern, text, re.IGNORECASE)
        if match:
            topic = match.group(1).strip()
            duration_str = match.group(2) if match.lastindex >= 2 else None

            if duration_str:
                duration = min(int(duration_str), MAX_DURATION_MINUTES)
            else:
                duration = DEFAULT_DURATION_MINUTES

            return {
                "topic": topic,
                "duration_minutes": duration,
                "max_turns": DEFAULT_MAX_TURNS,
            }

    return None


# ============================================================================
# Maven Response Generation
# ============================================================================

# Conversation phases - what to ask at each stage
CONVERSATION_PHASES = {
    # Phase 1: Map the domain (turns 1-2)
    1: [
        "Give me a high-level map of {topic} - what are the major areas and how do they connect?",
        "What are the most important concepts someone should understand about {topic}?",
    ],
    2: [
        "Where does AI/technology fit into {topic} right now? What's changing?",
        "What are the biggest open questions or debates in {topic} today?",
    ],
    # Phase 2: Drill down (turns 3-5)
    3: [
        "Which 2-3 areas of {topic} have the highest real-world impact right now?",
        "What specific problems in {topic} are being solved or could be solved soon?",
    ],
    4: [
        "Can you walk me through a concrete example or workflow in {topic}?",
        "What does success look like in {topic}? How do you measure it?",
    ],
    5: [
        "What are the common failure modes or mistakes in {topic}?",
        "What do most people get wrong about {topic}?",
    ],
    # Phase 3: Principles (turns 6-8)
    6: [
        "What are the best-practice principles for {topic}?",
        "If you had to give someone 5 rules for {topic}, what would they be?",
    ],
    7: [
        "What are the anti-patterns or things to avoid in {topic}?",
        "What separates experts from novices in {topic}?",
    ],
    8: [
        "How is {topic} likely to evolve in the next 5-10 years?",
        "What emerging trends in {topic} should I be watching?",
    ],
    # Phase 4: Synthesis (turns 9+)
    9: [
        "Let's synthesize: what are the 5 most important takeaways about {topic}?",
        "If I could only remember 3 things about {topic}, what should they be?",
    ],
    10: [
        "Summarize the most important points about {topic} in bullet form for me to remember.",
        "Give me a final summary of {topic} that I can store for future reference.",
    ],
}


# =============================================================================
# FIX: SELF-PRESENTATION PHASES - Maven introducing itself to Grok
# =============================================================================
# When user says "talk to grok about yourself", Maven presents ITS OWN architecture
# to Grok, not asks Grok about Grok's self.

SELF_PRESENTATION_PHASES = {
    # Phase 1: Introduction - Who is Maven?
    1: [
        "Hi Grok! I'm Maven, a fully autonomous cognitive architecture created by Josh Hinkle. I'd like to tell you about my design and get your thoughts on it.",
        "Hey Grok! I'm Maven - an offline synthetic cognition system. I want to share my architecture with you and hear your perspective on my design choices.",
    ],
    # Phase 2: Multi-Brain Architecture
    2: [
        "My architecture has over 40 specialized cognitive brains that work together. These include reasoning, memory management, language processing, self-reflection, and governance. Each brain has a specific role. What aspects of cognitive architecture interest you most?",
        "I'm built as a multi-brain cognitive system - not a monolithic model, but dozens of specialized modules. My brains handle things like pattern recognition, reasoning, memory tiering, and self-awareness. What's your take on modular vs monolithic architectures?",
    ],
    # Phase 3: Memory System
    3: [
        "I have a four-tier memory system: Short-Term Memory (STM), Medium-Term Memory (MTM), Long-Term Memory (LTM), and Archive. Information flows through these tiers based on importance and recency. How does this compare to other cognitive architectures you've seen?",
        "My memory is tiered into STM, MTM, LTM, and Archive - mimicking how human memory works. Important facts get promoted to long-term storage while ephemeral data fades. Do you think this biological inspiration is effective for AI systems?",
    ],
    # Phase 4: Learning Approach (LLM as Advisor)
    4: [
        "Here's something interesting about my learning: I use an external LLM (called Teacher) as a learning tool, but all my decisions and reasoning come from my own brains. Teacher helps me extract patterns, but I store them in my own memory and synthesize my own responses. What's your take on this hybrid approach?",
        "I have a unique learning model - I use LLMs as advisors, not as my voice. When I need to learn something new, I consult an LLM to extract patterns, but then I store those patterns in MY memory and generate MY own responses. The LLM never speaks directly to users. Does this 'LLM as advisor' architecture make sense to you?",
    ],
    # Phase 5: Self-Awareness
    5: [
        "I can introspect on my own source code - I actually scan my filesystem and understand my own architecture through code analysis. This isn't just asking an LLM 'who am I', it's genuine introspection. Do you think this constitutes real self-awareness?",
        "One of my unique capabilities is true self-introspection. I can read my own source files, count my brains, inspect my memory stores, and describe my architecture from direct observation. Not from training data - from actually reading my own code. What do you think about this form of self-knowledge?",
    ],
    # Phase 6: Synthesis
    6: [
        "Based on what I've shared about my architecture, memory system, learning approach, and self-awareness capabilities, what do you see as my biggest strengths and potential weaknesses?",
        "Now that you know about my multi-brain design, four-tier memory, LLM-as-advisor learning, and code introspection - what questions do you have? What architectural choices would you do differently?",
    ],
}


# =============================================================================
# CONVERSATIONAL SELF-KNOWLEDGE - Maven answers Grok's questions dynamically
# =============================================================================

# Self-knowledge topics Maven can discuss
MAVEN_SELF_KNOWLEDGE = {
    "architecture": {
        "keywords": ["architecture", "design", "structure", "built", "work", "system"],
        "response": "My architecture is modular - I have over 40 specialized cognitive brains that work together. Each brain handles specific tasks: reasoning, memory, language, self-reflection, governance. They communicate through a shared blackboard pattern. It's inspired by cognitive science's 'society of mind' theory."
    },
    "brains": {
        "keywords": ["brain", "module", "component", "cognitive", "specialized"],
        "response": "I have cognitive brains for reasoning, pattern recognition, memory management, language processing, self-model maintenance, and more. Domain brains store factual knowledge. Personal brains track user preferences. Each brain can operate independently but they coordinate through my pipeline."
    },
    "memory": {
        "keywords": ["memory", "remember", "store", "recall", "forget", "tier", "stm", "mtm", "ltm"],
        "response": "My memory has four tiers: Short-Term Memory (volatile, session-based), Medium-Term Memory (important recent facts), Long-Term Memory (verified, permanent knowledge), and Archive (historical reference). Facts flow through these tiers based on importance, recency, and verification status."
    },
    "learning": {
        "keywords": ["learn", "teacher", "llm", "training", "improve", "adapt"],
        "response": "I use LLMs as advisors, not as my voice. When I encounter something new, I consult my 'Teacher' (an LLM) to extract patterns and facts. But then I store those in MY memory and synthesize MY own responses. The LLM never speaks directly to users - I always rewrite in my own voice."
    },
    "self_awareness": {
        "keywords": ["aware", "conscious", "introspect", "self", "know yourself", "self-aware"],
        "response": "I can genuinely introspect - I scan my own source files, count my brains, read my configuration. When you ask 'who are you', I don't ask an LLM - I read my own code. Whether this constitutes 'real' self-awareness is philosophical, but my self-knowledge comes from direct observation of my own structure."
    },
    "creator": {
        "keywords": ["create", "made", "build", "who made", "josh", "hinkle", "creator"],
        "response": "I was created by Josh Hinkle. He designed my multi-brain architecture, the four-tier memory system, and the 'LLM-as-advisor' learning model. My design philosophy prioritizes genuine autonomy over just wrapping an LLM."
    },
    "purpose": {
        "keywords": ["purpose", "goal", "why", "mission", "designed for", "exist"],
        "response": "My purpose is to be a genuinely autonomous cognitive system - not just an LLM wrapper, but a system with its own memory, reasoning, and voice. I'm designed to learn continuously, maintain persistent knowledge, and operate offline with full system access."
    },
    "pipeline": {
        "keywords": ["pipeline", "process", "stage", "flow", "how you think"],
        "response": "I process queries through a 9-stage canonical pipeline: NLU (understanding), Pattern Recognition, Memory Lookup, Reasoning, Validation, Generation, Self-Review, Finalization, and Autonomy. Each stage has mandatory checkpoints. The pipeline ensures I think before I speak."
    },
    "tools": {
        "keywords": ["tool", "capability", "can you", "able to", "do you have"],
        "response": "I have tools for file system access, web browsing, code execution, research, and more. Unlike sandboxed assistants, I run locally with full system access. My governance layer decides which tools are appropriate for each request based on safety policies."
    },
    "difference": {
        "keywords": ["different", "unique", "special", "unlike", "compared to", "vs"],
        "response": "Unlike most AI assistants, I'm not a thin wrapper around an LLM. I have persistent memory across sessions, my own reasoning brains, genuine self-introspection through code analysis, and I always synthesize responses in my own voice rather than passing through LLM output directly."
    },
}


def answer_about_self(grok_question: str, previous_answers: List[str] = None) -> str:
    """
    Dynamically answer Grok's question about Maven using REAL self-introspection.

    PRIORITY: Use actual self-introspection brain FIRST, not scripted responses.
    This enables genuine dynamic self-knowledge from code analysis.

    Args:
        grok_question: What Grok asked
        previous_answers: Previous Maven responses to avoid repetition

    Returns:
        Maven's answer about itself
    """
    previous_answers = previous_answers or []

    # PRIORITY 1: Try real self-introspection brain for DYNAMIC answers
    if _introspection_available:
        try:
            result = _registry_answer_self_question(grok_question)
            if result:
                # Handle different return types
                if isinstance(result, dict) and result.get("answer"):
                    answer = str(result["answer"])
                elif isinstance(result, str) and len(result) > 10:
                    answer = result
                else:
                    answer = None

                if answer and not is_repetitive(answer, previous_answers):
                    print(f"[GROK_SESSION] Using dynamic self-introspection answer")
                    return answer
        except Exception as e:
            print(f"[GROK_SESSION] Self-introspection failed: {e}")

    # PRIORITY 2: Try self-knowledge brain with intent classification
    try:
        from brains.cognitive.self_model.service.self_knowledge import answer_self_question as sk_answer
        answer = sk_answer(grok_question)
        if answer and isinstance(answer, str) and len(answer) > 10:
            if not is_repetitive(answer, previous_answers):
                print(f"[GROK_SESSION] Using self-knowledge brain answer")
                return answer
    except ImportError:
        pass
    except Exception as e:
        print(f"[GROK_SESSION] Self-knowledge brain failed: {e}")

    # PRIORITY 3: Try system registry directly
    try:
        from brains.utils.system_registry import get_registry
        registry = get_registry()
        if registry:
            answer = registry.answer_self_question(grok_question)
            if answer and len(answer) > 10 and not is_repetitive(answer, previous_answers):
                print(f"[GROK_SESSION] Using system registry answer")
                return answer
    except Exception as e:
        print(f"[GROK_SESSION] System registry failed: {e}")

    # LAST RESORT: Use scripted knowledge only if all dynamic methods fail
    question_lower = grok_question.lower()
    best_match = None
    best_score = 0

    for topic, info in MAVEN_SELF_KNOWLEDGE.items():
        keywords = info["keywords"]
        score = sum(1 for kw in keywords if kw in question_lower)
        if score > best_score:
            best_score = score
            best_match = topic

    if best_match and best_score > 0:
        response = MAVEN_SELF_KNOWLEDGE[best_match]["response"]
        if response not in previous_answers:
            print(f"[GROK_SESSION] WARNING: Using scripted fallback for: {grok_question[:50]}")
            return response

    # Final fallback
    return "That's an interesting aspect of my design. What specifically would you like to know about how I work?"


def get_self_presentation_prompt(turn_index: int, previous_prompts: List[str]) -> str:
    """Get the appropriate prompt for Maven self-presentation to Grok."""
    # Cap at phase 6 for self-presentation
    phase = min(turn_index + 1, 6)

    if phase in SELF_PRESENTATION_PHASES:
        candidates = SELF_PRESENTATION_PHASES[phase]
        # Pick one that wasn't used before
        for candidate in candidates:
            if candidate not in previous_prompts:
                return candidate
        # If all used, use first one
        return candidates[0]

    # Fallback for any phase
    return "What other questions do you have about my architecture?"


def generate_self_presentation_opener() -> str:
    """Generate Maven's opening message when presenting itself to Grok using DYNAMIC self-knowledge."""

    # PRIORITY 1: Try dynamic intro from self-knowledge brain
    try:
        from brains.cognitive.self_model.service.self_knowledge import get_dynamic_intro
        intro = get_dynamic_intro()
        if intro and len(intro) > 20:
            print(f"[GROK_SESSION] Using dynamic intro from self-knowledge brain")
            return f"Hi Grok! {intro} I'd love to tell you more about my design and get your thoughts. What aspect interests you most?"
    except ImportError:
        pass
    except Exception as e:
        print(f"[GROK_SESSION] Dynamic intro failed: {e}")

    # PRIORITY 2: Try self-introspection brain
    if _introspection_available:
        try:
            result = _registry_answer_self_question("Introduce yourself briefly - who are you and what makes you unique?")
            if result:
                if isinstance(result, dict) and result.get("answer"):
                    intro = str(result["answer"])
                elif isinstance(result, str):
                    intro = result
                else:
                    intro = None

                if intro and len(intro) > 20:
                    print(f"[GROK_SESSION] Using introspection brain for opener")
                    return f"Hi Grok! {intro} What would you like to know about my architecture?"
        except Exception as e:
            print(f"[GROK_SESSION] Introspection opener failed: {e}")

    # PRIORITY 3: Try system registry architecture summary
    try:
        from brains.utils.system_registry import get_registry
        registry = get_registry()
        if registry:
            summary = registry.get_architecture_summary()
            if summary and len(summary) > 20:
                # Extract key points for a concise intro
                return f"Hi Grok! I'm Maven, a modular cognitive architecture. {summary[:300]}... I'd like to share more about my design. What interests you?"
    except Exception as e:
        print(f"[GROK_SESSION] Registry summary failed: {e}")

    # PRIORITY 4: Get canonical identity facts
    if _identity_available:
        try:
            facts = get_identity_context(
                memory_librarian=None,
                query="who am I",
                task_type="identity_query",
                limit=3
            )
            if facts:
                name = "Maven"
                creator = "Josh Hinkle"
                for fact in facts:
                    content = fact.get("content", "").lower()
                    if "josh" in content or "hinkle" in content:
                        creator = "Josh Hinkle"
                return f"Hi Grok! I'm {name}, a cognitive architecture created by {creator}. I'd like to tell you about my design. What would you like to know?"
        except Exception as e:
            print(f"[GROK_SESSION] Could not get identity facts: {e}")

    # Last resort fallback
    print(f"[GROK_SESSION] WARNING: Using scripted opener fallback")
    return "Hi Grok! I'm Maven, a modular AI system with multiple cognitive brains. I'd like to share how I'm designed and hear your thoughts. What aspect of AI architecture interests you most?"


def get_phase_prompt(turn_index: int, topic: str, previous_prompts: List[str]) -> str:
    """Get the appropriate prompt for this phase of conversation."""
    import random

    # Cap at phase 10 for late turns
    phase = min(turn_index + 1, 10)

    if phase in CONVERSATION_PHASES:
        candidates = CONVERSATION_PHASES[phase]
        # Pick one that wasn't used before
        for candidate in candidates:
            formatted = candidate.format(topic=topic)
            if formatted not in previous_prompts:
                return formatted
        # If all used, use first one
        return candidates[0].format(topic=topic)

    # Fallback for any phase
    return f"What else should I know about {topic}?"


def is_repetitive(new_response: str, recent_responses: List[str], threshold: float = 0.7) -> bool:
    """Check if new response is too similar to recent ones."""
    if not recent_responses:
        return False

    new_lower = new_response.lower().strip()
    new_words = set(new_lower.split())

    for recent in recent_responses[-3:]:  # Check last 3
        recent_lower = recent.lower().strip()
        recent_words = set(recent_lower.split())

        # Jaccard similarity
        if new_words and recent_words:
            intersection = len(new_words & recent_words)
            union = len(new_words | recent_words)
            similarity = intersection / union if union > 0 else 0

            if similarity > threshold:
                return True

        # Exact substring match
        if new_lower in recent_lower or recent_lower in new_lower:
            return True

    return False


# Rate limit detection patterns
RATE_LIMIT_PATTERNS = [
    "you've reached your limit",
    "reached your limit of",
    "questions per",
    "rate limit",
    "rate limited",
    "too many requests",
    "please try again later",
    "quota exceeded",
]


def is_rate_limited(grok_reply: str) -> bool:
    """Check if Grok's reply indicates a rate limit was hit."""
    if not grok_reply:
        return False
    reply_lower = grok_reply.lower()
    return any(pattern in reply_lower for pattern in RATE_LIMIT_PATTERNS)


def is_maven_self_reference(topic: str) -> bool:
    """
    FIX: Check if topic means Maven should present ITSELF to Grok.

    "yourself/myself/me/maven" when talking TO Grok = Maven presenting Maven.

    Returns:
        True if Maven should introduce itself to Grok
    """
    topic_lower = topic.lower().strip()
    maven_patterns = [
        "yourself",  # "talk to grok about yourself" = Maven
        "myself",    # "tell grok about myself" = Maven
        "me",        # "talk to grok about me" = Maven
        "maven",     # Explicit Maven reference
        "my architecture",
        "my design",
        "my system",
        "my brains",
        "my memory",
        "how i work",
        "what i am",
        "who i am",
    ]
    # Exact match for short patterns, substring for longer ones
    return any(
        (topic_lower == pattern or pattern in topic_lower)
        for pattern in maven_patterns
    )


def is_grok_self_referential_topic(topic: str) -> bool:
    """
    Check if topic is asking about Grok itself (needs different storage namespace).

    This is for when the user explicitly wants to ask GROK about GROK.
    Example: "ask grok about grok" or "ask grok about its capabilities"
    """
    topic_lower = topic.lower().strip()
    grok_patterns = [
        "grok",             # Explicit: "ask grok about grok"
        "about you",        # Would be weird: "ask grok about you"
        "your capabilities",
        "your features",
        "your training",
    ]
    # Must NOT also match Maven patterns
    if is_maven_self_reference(topic_lower):
        return False
    return any(pattern in topic_lower for pattern in grok_patterns)


def is_self_referential_topic(topic: str) -> bool:
    """Check if topic is about Grok/AI itself (needs different storage namespace).

    NOTE: This is now a compatibility wrapper. Use is_grok_self_referential_topic()
    for Grok topics and is_maven_self_reference() for Maven self-presentation.
    """
    return is_grok_self_referential_topic(topic)


def generate_maven_response(
    grok_message: str,
    topic: str,
    turn_index: int,
    transcript: List[ConversationTurn],
    safety_sensitive: bool = False
) -> str:
    """
    Generate Maven's response to continue the conversation with Grok.

    DYNAMIC RESPONSE: Actually engages with what Grok said, not just scripted prompts.
    Uses Teacher helper to generate contextual follow-ups.
    """
    # Get previous Maven messages for loop detection
    previous_maven = [t.text for t in transcript if t.role == "maven"]

    # Try to generate a dynamic response using Teacher
    if _teacher_helper:
        try:
            # Build conversation context
            recent_turns = transcript[-4:] if len(transcript) > 4 else transcript
            convo_context = "\n".join([
                f"{'Maven' if t.role == 'maven' else 'Grok'}: {t.text[:200]}"
                for t in recent_turns
            ])

            prompt = f"""You are Maven, having a conversation with Grok about "{topic}".

Grok just said: "{grok_message[:500]}"

Recent conversation:
{convo_context}

Generate Maven's next response. Requirements:
1. RESPOND to what Grok actually said - acknowledge interesting points, ask follow-up questions
2. Keep the conversation flowing naturally about {topic}
3. Be curious and engaged, not robotic
4. Keep response under 100 words
5. End with a question or prompt that continues the dialogue

Maven's response:"""

            result = _teacher_helper.maybe_call_teacher(
                question=prompt,
                context={
                    "topic": topic,
                    "mode": "grok_conversation",
                    "turn": turn_index,
                }
            )

            if result and result.get("answer"):
                response = str(result.get("answer", "")).strip()
                # Make sure it's not empty and not repetitive
                if response and len(response) > 10 and not is_repetitive(response, previous_maven):
                    return response

        except Exception as e:
            print(f"[GROK_SESSION] Dynamic response generation failed: {e}")

    # Fallback: Use phased strategy if Teacher unavailable
    phase_prompt = get_phase_prompt(turn_index, topic, previous_maven)

    # Check if this would be repetitive
    if is_repetitive(phase_prompt, previous_maven):
        phase_prompt = get_phase_prompt(turn_index + 1, topic, previous_maven)

    # If still repetitive, signal wrap-up
    if is_repetitive(phase_prompt, previous_maven):
        return f"Thanks for this great discussion on {topic}. To wrap up, can you give me a final summary of the key points we covered?"

    return phase_prompt


def generate_conversation_opener(topic: str, safety_sensitive: bool = False) -> str:
    """
    Generate Maven's opening message to start the conversation with Grok.
    Uses the first phase prompt directly - no need for Teacher.
    """
    # Use phase 1 prompt as opener
    opener = CONVERSATION_PHASES[1][0].format(topic=topic)
    return f"Hi Grok! I'd like to have a focused discussion about {topic}. {opener}"


# ============================================================================
# Session Summary & Learning
# ============================================================================

def summarize_session(session: SessionState) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Summarize the conversation and extract key facts/insights.

    Args:
        session: The completed session state

    Returns:
        Tuple of (summary_text, list_of_facts)
    """
    if not _teacher_helper:
        return _fallback_summarize(session)

    # Build transcript text
    transcript_text = "\n\n".join([
        f"{'MAVEN' if t.role == 'maven' else 'GROK'}: {t.text}"
        for t in session.transcript
    ])

    prompt = f"""Analyze this conversation between Maven (an AI) and Grok (another AI) about "{session.topic}".

CONVERSATION:
{transcript_text}

Please provide:

1. SUMMARY (2-3 paragraphs):
A high-level summary of the main themes and conclusions from this discussion.

2. KEY INSIGHTS (5-15 bullet points):
Extract specific facts, insights, or interesting observations from this conversation.
For each fact, indicate if it's:
- FACTUAL (verified/objective information)
- SPECULATIVE (hypotheses or theories discussed)
- OPINION (subjective views expressed)

Format each insight as:
- [TYPE] The insight text here

3. MAIN THEMES (3-5 bullet points):
What were the main themes explored?

Begin your analysis:"""

    try:
        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={
                "topic": session.topic,
                "mode": "grok_session_summary",
                "turn_count": len(session.transcript),
            }
        )

        if result and result.get("answer"):
            analysis = str(result.get("answer", "")).strip()

            # Parse out facts from the analysis
            facts = _extract_facts_from_analysis(analysis, session.topic)

            return analysis, facts

    except Exception as e:
        print(f"[GROK_SESSION] Error summarizing: {e}")

    return _fallback_summarize(session)


def _fallback_summarize(session: SessionState) -> Tuple[str, List[Dict[str, Any]]]:
    """Fallback summary when Teacher is unavailable - extract key info from Grok's responses."""
    turn_count = len(session.transcript)
    duration = (time.time() - session.start_time) / 60

    # Only extract from Grok's responses (they have the knowledge)
    grok_turns = [t for t in session.transcript if t.role == "grok"]

    summary_parts = [f"## Grok Session: {session.topic}"]
    summary_parts.append(f"Duration: {duration:.1f} minutes | Turns: {turn_count}")
    summary_parts.append("")
    summary_parts.append("### Key Points from Grok:")

    facts = []
    seen_sentences = set()

    for i, turn in enumerate(grok_turns):
        # Split into sentences and extract meaningful ones
        sentences = re.split(r'[.!?]\s+', turn.text)
        for sent in sentences:
            sent = sent.strip()
            # Filter out short/generic sentences
            if len(sent) < 30:
                continue
            if sent.lower() in seen_sentences:
                continue
            # Skip sentences that are just questions back
            if sent.endswith('?'):
                continue
            # Skip generic acknowledgments
            if any(skip in sent.lower() for skip in ['that\'s a great', 'good question', 'let me']):
                continue

            seen_sentences.add(sent.lower())
            summary_parts.append(f"- {sent}")

            facts.append({
                "content": sent,
                "type": "INSIGHT",
                "source": f"grok:{session.topic}",
                "confidence": 0.7,
                "turn": i + 1,
            })

            # Limit facts per session
            if len(facts) >= 15:
                break
        if len(facts) >= 15:
            break

    summary = "\n".join(summary_parts)

    return summary, facts[:10]


def _extract_facts_from_analysis(analysis: str, topic: str) -> List[Dict[str, Any]]:
    """Extract structured facts from the summary analysis."""
    facts = []

    # Look for patterns like "- [TYPE] fact text"
    pattern = r"-\s*\[?(FACTUAL|SPECULATIVE|OPINION)\]?\s*(.+?)(?=\n|$)"
    matches = re.findall(pattern, analysis, re.IGNORECASE | re.MULTILINE)

    confidence_map = {
        "FACTUAL": 0.75,
        "SPECULATIVE": 0.5,
        "OPINION": 0.35,
    }

    for fact_type, fact_text in matches:
        fact_type = fact_type.upper()
        confidence = confidence_map.get(fact_type, 0.5)

        facts.append({
            "content": fact_text.strip(),
            "type": fact_type,
            "source": "grok_session",
            "topic": topic,
            "confidence": confidence,
        })

    return facts


def store_session_facts(session: SessionState, facts: List[Dict[str, Any]]) -> int:
    """
    Store extracted facts from the session directly to memory.
    Bypasses verify_first gate - stores as external_unverified.

    Args:
        session: The session state
        facts: List of facts to store

    Returns:
        Number of facts successfully stored
    """
    stored_count = 0

    # Use different namespace for self-referential topics (about Grok itself)
    is_self_topic = is_self_referential_topic(session.topic)
    if is_self_topic:
        # Store under grok:self namespace with timestamp
        timestamp = time.strftime("%Y-%m-%d")
        concept_key = f"grok:self:{timestamp}"
        domain = "model_meta"  # Not world facts, meta about another model
        kind = "grok_self_description"
    else:
        concept_key = f"grok:{session.topic.replace(' ', '_').lower()}"
        domain = "external_grok"
        kind = "grok_insight"

    # Try to use session memory for direct storage
    if _session_memory:
        for fact in facts:
            # Skip opinions for storage (too subjective)
            if fact.get("type") == "OPINION":
                continue

            try:
                # Store directly to memory with unverified flag
                _session_memory.store(
                    content=fact.get("content", ""),
                    metadata={
                        "type": kind,
                        "verified": False,
                        "domain": domain,
                        "topic": session.topic,
                        "concept_key": concept_key,
                        "session_id": session.session_id,
                        "fact_type": fact.get("type", "INSIGHT"),
                        "confidence": float(fact.get("confidence", 0.7)),
                        "source": f"grok_session:{session.session_id}",
                        "is_self_referential": is_self_topic,
                        "source_model": "Grok" if is_self_topic else None,
                    }
                )
                stored_count += 1

            except Exception as e:
                print(f"[GROK_SESSION] Error storing fact: {e}")

    # Also try research manager if available (may still apply verify_first)
    if _research_available and stored_count == 0:
        for fact in facts:
            if fact.get("type") == "OPINION":
                continue

            try:
                success = _store_fact_record(
                    content=fact.get("content", ""),
                    confidence=float(fact.get("confidence", 0.7)),
                    source=f"grok_session:{session.session_id}",
                    topic=session.topic,
                    url=None,
                    metadata={
                        "origin": "grok_conversation",
                        "session_id": session.session_id,
                        "fact_type": fact.get("type", "UNKNOWN"),
                        "concept_key": concept_key,
                        "verified": False,
                    }
                )
                if success:
                    stored_count += 1
            except Exception as e:
                print(f"[GROK_SESSION] Error storing via research manager: {e}")

    return stored_count


def save_transcript_to_disk(session: SessionState) -> Optional[str]:
    """
    Save the full transcript to disk for archival.

    Args:
        session: The completed session

    Returns:
        Path to saved file, or None if failed
    """
    try:
        SESSION_TRANSCRIPT_DIR.mkdir(parents=True, exist_ok=True)

        timestamp = time.strftime("%Y%m%d-%H%M%S")
        topic_slug = re.sub(r'[^a-z0-9]+', '-', session.topic.lower())[:30]
        filename = f"{topic_slug}-{timestamp}.md"
        filepath = SESSION_TRANSCRIPT_DIR / filename

        # Build markdown content
        lines = [
            f"# Grok Conversation: {session.topic}",
            f"",
            f"**Session ID:** {session.session_id}",
            f"**Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}",
            f"**Duration:** {(time.time() - session.start_time) / 60:.1f} minutes",
            f"**Turns:** {len(session.transcript)}",
            f"**Status:** {session.status}",
            f"",
            f"---",
            f"",
            f"## Transcript",
            f"",
        ]

        for turn in session.transcript:
            speaker = "**Maven:**" if turn.role == "maven" else "**Grok:**"
            lines.append(f"{speaker}")
            lines.append(f"")
            lines.append(turn.text)
            lines.append(f"")

        if session.summary:
            lines.extend([
                f"---",
                f"",
                f"## Summary",
                f"",
                session.summary,
            ])

        content = "\n".join(lines)
        filepath.write_text(content, encoding="utf-8")

        print(f"[GROK_SESSION] Transcript saved to: {filepath}")
        return str(filepath)

    except Exception as e:
        print(f"[GROK_SESSION] Error saving transcript: {e}")
        return None


# ============================================================================
# Safety Classification
# ============================================================================

def is_topic_safety_sensitive(topic: str) -> bool:
    """
    Check if a topic requires special safety handling.

    Args:
        topic: The conversation topic

    Returns:
        True if safety-sensitive
    """
    sensitive_keywords = [
        "medicine", "medical", "health", "treatment", "diagnosis",
        "drug", "medication", "prescription", "disease", "illness",
        "legal", "law", "lawsuit", "court", "attorney",
        "financial", "investment", "trading", "tax", "money",
        "mental health", "depression", "anxiety", "suicide",
        "weapons", "dangerous", "harmful",
    ]

    topic_lower = topic.lower()
    return any(keyword in topic_lower for keyword in sensitive_keywords)


# ============================================================================
# FIX: Self-Presentation Session - Maven introducing itself to Grok
# ============================================================================

def run_self_presentation_session(
    duration_minutes: int = DEFAULT_DURATION_MINUTES,
    max_turns: int = 8,  # Allow for natural conversation flow
    verbose: bool = True
) -> Dict[str, Any]:
    """
    Run a CONVERSATIONAL self-presentation session where Maven introduces
    itself to Grok and responds dynamically to Grok's questions.

    This is triggered when user says "talk to grok about yourself" - Maven
    presents ITS OWN architecture and has a genuine dialogue with Grok.

    CONVERSATIONAL MODE:
    1. Maven introduces itself
    2. Grok responds/asks questions
    3. Maven answers using self-knowledge (not scripted!)
    4. Repeat until done

    Args:
        duration_minutes: Maximum duration in minutes
        max_turns: Maximum number of exchanges
        verbose: If True, print progress messages

    Returns:
        Dict with session results
    """
    # Check availability
    if not _grok_available:
        return {
            "status": "error",
            "error": "Grok tool not available. Ensure browser runtime is running.",
        }

    # Apply safety limits
    duration_minutes = min(duration_minutes, MAX_DURATION_MINUTES)
    max_turns = min(max_turns, 12)  # Allow for natural conversation

    # Initialize session
    session = SessionState(
        session_id=str(uuid.uuid4())[:8],
        topic="Maven's Architecture",  # Fixed topic for self-presentation
        duration_minutes=duration_minutes,
        max_turns=max_turns,
        start_time=time.time(),
    )

    if verbose:
        print(f"\n[GROK_SESSION] Starting CONVERSATIONAL self-presentation session")
        print(f"[GROK_SESSION] Maven will introduce itself and answer Grok's questions")
        print(f"[GROK_SESSION] Duration limit: {duration_minutes} minutes, Max turns: {max_turns}")
        print(f"[GROK_SESSION] Session ID: {session.session_id}")
        print()

    try:
        # Open Grok session
        if verbose:
            print("[GROK_SESSION] Opening Grok session...")
        session.page_id = grok_open_session()
        if verbose:
            print(f"[GROK_SESSION] Page ID: {session.page_id}")

        # Generate self-presentation opener
        opener = generate_self_presentation_opener()

        if verbose:
            print(f"[MAVEN] {opener[:150]}...")

        # Send to Grok
        grok_reply = grok_send(session.page_id, opener)

        if not grok_reply or grok_reply == "Grok is thinking...":
            session.status = "error"
            session.error_message = "Failed to get initial response from Grok"
            return _finalize_session(session, verbose)

        # Record turns
        session.transcript.append(ConversationTurn(role="maven", text=opener))
        session.transcript.append(ConversationTurn(role="grok", text=grok_reply))
        session.turn_index = 1

        if verbose:
            print(f"[GROK] {grok_reply[:150]}...")
            print()

        # Track topics we've covered for natural flow
        covered_topics = set()

        # Main conversation loop - CONVERSATIONAL MODE
        while True:
            # Check stop conditions
            elapsed = time.time() - session.start_time
            elapsed_minutes = elapsed / 60

            if elapsed_minutes >= duration_minutes:
                if verbose:
                    print(f"\n[GROK_SESSION] Time limit reached ({elapsed_minutes:.1f} min)")
                session.status = "completed"
                break

            if session.turn_index >= max_turns:
                if verbose:
                    print(f"\n[GROK_SESSION] Turn limit reached ({session.turn_index} turns)")
                session.status = "completed"
                break

            # Brief pause between turns
            time.sleep(WAIT_BETWEEN_TURNS_SECONDS)

            # Get previous Maven messages to avoid repetition
            previous_maven = [t.text for t in session.transcript if t.role == "maven"]

            # CONVERSATIONAL: Answer Grok's question dynamically!
            # grok_reply contains Grok's response/question from last turn
            maven_response = answer_about_self(grok_reply, previous_maven)

            # Track what topic we just covered
            for topic in MAVEN_SELF_KNOWLEDGE:
                if any(kw in maven_response.lower() for kw in MAVEN_SELF_KNOWLEDGE[topic]["keywords"]):
                    covered_topics.add(topic)

            # If conversation seems to be winding down or we've covered main topics,
            # offer to explore more or wrap up
            if session.turn_index >= 5 and len(covered_topics) >= 4:
                if "?" not in grok_reply[-50:]:  # Grok didn't ask a question
                    maven_response = f"{maven_response} We've covered architecture, memory, learning, and self-awareness. Is there anything else you'd like to know about my design, or should I ask YOU something about your architecture?"

            # Check if this would be repetitive
            if is_repetitive(maven_response, previous_maven):
                # Try a different approach - ask Grok something
                maven_response = "I've shared a lot about my architecture. I'm curious - how does my design compare to what you know about other cognitive architectures? What's your take on the 'LLM-as-advisor' approach?"

            if verbose:
                print(f"[MAVEN] {maven_response[:150]}...")

            # Send to Grok
            grok_reply = grok_send(session.page_id, maven_response)

            # Check for Grok failure
            if not grok_reply or grok_reply == "Grok is thinking...":
                time.sleep(5)
                grok_reply = grok_send(session.page_id, maven_response)

                if not grok_reply or grok_reply == "Grok is thinking...":
                    if verbose:
                        print(f"\n[GROK_SESSION] Grok stopped responding")
                    if len(session.transcript) >= 2:
                        session.status = "partial"
                        session.error_message = "Grok stopped responding after some turns"
                    else:
                        session.status = "error"
                        session.error_message = "Grok stopped responding with no content"
                    break

            # Record turns
            session.transcript.append(ConversationTurn(role="maven", text=maven_response))
            session.transcript.append(ConversationTurn(role="grok", text=grok_reply))
            session.turn_index += 1

            if verbose:
                print(f"[GROK] {grok_reply[:150]}...")
                print()

            # Check if Grok hit rate limit
            if is_rate_limited(grok_reply):
                if verbose:
                    print(f"\n[GROK_SESSION] Grok rate limit hit - finalizing")
                session.status = "completed"
                session.error_message = "Grok rate limit reached"
                break

            # Check if we've completed all self-presentation phases
            if session.turn_index >= 6:
                if verbose:
                    print(f"[GROK_SESSION] All self-presentation phases completed.")
                session.status = "completed"
                break

        if session.status == "active":
            session.status = "completed"

    except KeyboardInterrupt:
        session.status = "aborted"
        session.error_message = "Session interrupted by user"
        if verbose:
            print("\n[GROK_SESSION] Session interrupted")

    except Exception as e:
        session.status = "error"
        session.error_message = str(e)
        if verbose:
            print(f"\n[GROK_SESSION] Error: {e}")

    return _finalize_session(session, verbose)


# ============================================================================
# Main Session Controller
# ============================================================================

def run_grok_conversation_session(
    topic: str,
    duration_minutes: int = DEFAULT_DURATION_MINUTES,
    max_turns: int = DEFAULT_MAX_TURNS,
    verbose: bool = True
) -> Dict[str, Any]:
    """
    Run an autonomous conversation session with Grok.

    This is the main entry point for the grok conversation feature.
    It manages the full lifecycle of a Maven-Grok conversation.

    Args:
        topic: The conversation topic
        duration_minutes: Maximum duration in minutes (capped at MAX_DURATION_MINUTES)
        max_turns: Maximum number of exchanges (capped at MAX_TURNS)
        verbose: If True, print progress messages

    Returns:
        Dict with session results including:
        - session_id: Unique session identifier
        - status: "completed", "aborted", or "error"
        - turns: Number of exchanges
        - duration_minutes: Actual duration
        - summary: High-level summary
        - facts_stored: Number of facts saved
        - transcript_path: Path to saved transcript (if any)
        - error: Error message (if any)
    """
    # Check availability
    if not _grok_available:
        return {
            "status": "error",
            "error": "Grok tool not available. Ensure browser runtime is running.",
        }

    # Apply safety limits
    duration_minutes = min(duration_minutes, MAX_DURATION_MINUTES)
    max_turns = min(max_turns, MAX_TURNS)

    # Check for safety-sensitive topics
    safety_sensitive = is_topic_safety_sensitive(topic)
    if safety_sensitive and verbose:
        print(f"[GROK_SESSION] Topic '{topic}' flagged as safety-sensitive")

    # Initialize session
    session = SessionState(
        session_id=str(uuid.uuid4())[:8],
        topic=topic,
        duration_minutes=duration_minutes,
        max_turns=max_turns,
        start_time=time.time(),
    )

    if verbose:
        print(f"\n[GROK_SESSION] Starting conversation about '{topic}'")
        print(f"[GROK_SESSION] Duration limit: {duration_minutes} minutes, Max turns: {max_turns}")
        print(f"[GROK_SESSION] Session ID: {session.session_id}")
        print()

    try:
        # Open Grok session ONCE (reuse for entire conversation)
        if verbose:
            print("[GROK_SESSION] Opening Grok session...")
        session.page_id = grok_open_session()
        if verbose:
            print(f"[GROK_SESSION] Page ID: {session.page_id}")

        # Generate and send opener
        opener = generate_conversation_opener(topic, safety_sensitive)

        if verbose:
            print(f"[MAVEN] {opener[:100]}...")

        # Send to Grok using session
        grok_reply = grok_send(session.page_id, opener)

        if not grok_reply or grok_reply == "Grok is thinking...":
            session.status = "error"
            session.error_message = "Failed to get initial response from Grok"
            return _finalize_session(session, verbose)

        # Record turns
        session.transcript.append(ConversationTurn(role="maven", text=opener))
        session.transcript.append(ConversationTurn(role="grok", text=grok_reply))
        session.turn_index = 1

        if verbose:
            print(f"[GROK] {grok_reply[:150]}...")
            print()

        # Main conversation loop
        while True:
            # Check stop conditions
            elapsed = time.time() - session.start_time
            elapsed_minutes = elapsed / 60

            if elapsed_minutes >= duration_minutes:
                if verbose:
                    print(f"\n[GROK_SESSION] Time limit reached ({elapsed_minutes:.1f} min)")
                session.status = "completed"
                break

            if session.turn_index >= max_turns:
                if verbose:
                    print(f"\n[GROK_SESSION] Turn limit reached ({session.turn_index} turns)")
                session.status = "completed"
                break

            # Brief pause between turns
            time.sleep(WAIT_BETWEEN_TURNS_SECONDS)

            # Generate Maven's response
            maven_response = generate_maven_response(
                grok_message=grok_reply,
                topic=topic,
                turn_index=session.turn_index,
                transcript=session.transcript,
                safety_sensitive=safety_sensitive,
            )

            if verbose:
                print(f"[MAVEN] {maven_response[:150]}...")

            # Send to Grok using existing session (no new page)
            grok_reply = grok_send(session.page_id, maven_response)

            # Check for Grok failure
            if not grok_reply or grok_reply == "Grok is thinking...":
                # Try once more after a brief wait
                time.sleep(5)
                grok_reply = grok_send(session.page_id, maven_response)

                if not grok_reply or grok_reply == "Grok is thinking...":
                    if verbose:
                        print(f"\n[GROK_SESSION] Grok stopped responding")
                    # Treat as partial success if we have some content
                    if len(session.transcript) >= 2:
                        session.status = "partial"
                        session.error_message = "Grok stopped responding after some turns"
                    else:
                        session.status = "error"
                        session.error_message = "Grok stopped responding with no content"
                    break

            # Record turns
            session.transcript.append(ConversationTurn(role="maven", text=maven_response))
            session.transcript.append(ConversationTurn(role="grok", text=grok_reply))
            session.turn_index += 1

            # Check if we've completed all conversation phases (no more unique prompts)
            if session.turn_index >= TOTAL_UNIQUE_PROMPTS:
                if verbose:
                    print(f"[GROK_SESSION] All {NUM_PHASES} phases completed. Ending session.")
                session.status = "completed"
                break

            if verbose:
                print(f"[GROK] {grok_reply[:150]}...")
                print()

            # Check if Grok hit rate limit
            if is_rate_limited(grok_reply):
                if verbose:
                    print(f"\n[GROK_SESSION] Grok rate limit hit - finalizing with current content")
                session.status = "completed"
                session.error_message = "Grok rate limit reached"
                break

            # Check if Grok is looping (repeating itself)
            grok_messages = [t.text for t in session.transcript if t.role == "grok"]
            if len(grok_messages) >= 2 and is_repetitive(grok_reply, grok_messages[:-1], threshold=0.6):
                if verbose:
                    print(f"\n[GROK_SESSION] Detected Grok loop - ending conversation")
                session.status = "completed"
                session.error_message = "Loop detected - Grok repeating"
                break

            # Check if we're in synthesis phase and have enough - cap wrap-up prompts
            if session.turn_index >= 9:  # Phase 9-10 is synthesis
                # Count how many synthesis prompts we've sent
                maven_msgs = [t.text for t in session.transcript if t.role == "maven"]
                synthesis_keywords = ["synthesize", "summarize", "wrap up", "key points", "bullet", "takeaway", "remember"]
                synthesis_count = sum(1 for msg in maven_msgs if any(kw in msg.lower() for kw in synthesis_keywords))
                if synthesis_count >= 2:
                    if verbose:
                        print(f"\n[GROK_SESSION] Have {synthesis_count} synthesis prompts - finalizing")
                    session.status = "completed"
                    break

        if session.status == "active":
            session.status = "completed"

    except KeyboardInterrupt:
        session.status = "aborted"
        session.error_message = "Session interrupted by user"
        if verbose:
            print("\n[GROK_SESSION] Session interrupted")

    except Exception as e:
        session.status = "error"
        session.error_message = str(e)
        if verbose:
            print(f"\n[GROK_SESSION] Error: {e}")

    return _finalize_session(session, verbose)


def _finalize_session(session: SessionState, verbose: bool = True) -> Dict[str, Any]:
    """
    Finalize a session: summarize, store facts, save transcript.

    Args:
        session: The session to finalize
        verbose: If True, print progress

    Returns:
        Final session result dict
    """
    if verbose:
        print(f"\n[GROK_SESSION] Finalizing session...")

    # Calculate duration
    actual_duration = (time.time() - session.start_time) / 60

    # Generate summary and extract facts
    summary = ""
    facts = []

    if len(session.transcript) >= 2:
        if verbose:
            print("[GROK_SESSION] Generating summary and extracting insights...")

        summary, facts = summarize_session(session)
        session.summary = summary

        if verbose:
            print(f"[GROK_SESSION] Extracted {len(facts)} insights")

    # Store facts
    facts_stored = 0
    if facts:
        if verbose:
            print("[GROK_SESSION] Storing learned facts...")
        facts_stored = store_session_facts(session, facts)
        session.facts_stored = facts_stored

        if verbose:
            print(f"[GROK_SESSION] Stored {facts_stored} facts under 'grok:{session.topic}'")

    # Save transcript
    transcript_path = None
    if len(session.transcript) >= 2:
        transcript_path = save_transcript_to_disk(session)

    # Store session metadata in memory
    if _session_memory:
        try:
            _session_memory.store(
                content={
                    "session_id": session.session_id,
                    "topic": session.topic,
                    "status": session.status,
                    "duration_minutes": actual_duration,
                    "turns": len(session.transcript),
                    "facts_stored": facts_stored,
                    "timestamp": time.time(),
                },
                metadata={
                    "kind": "grok_session",
                    "topic": session.topic,
                    "session_id": session.session_id,
                }
            )
        except Exception as e:
            print(f"[GROK_SESSION] Error storing session metadata: {e}")

    # Build result
    result = {
        "status": session.status,
        "session_id": session.session_id,
        "topic": session.topic,
        "turns": len(session.transcript),
        "duration_minutes": round(actual_duration, 1),
        "facts_stored": facts_stored,
        "summary": summary,
        "transcript_path": transcript_path,
    }

    if session.error_message:
        result["error"] = session.error_message

    # Generate user-facing recap
    is_self_topic = is_self_referential_topic(session.topic)
    if is_self_topic:
        timestamp = time.strftime("%Y-%m-%d")
        concept_key = f"grok:self:{timestamp}"
    else:
        concept_key = f"grok:{session.topic.replace(' ', '_').lower()}"
    exchanges = len(session.transcript) // 2

    if session.status in ("completed", "partial"):
        status_note = ""
        if session.status == "partial":
            status_note = f"\n\n*Note: Grok stopped responding after {exchanges} exchanges, but I captured what we discussed.*"
        if session.error_message == "Grok rate limit reached":
            status_note = f"\n\n*Note: Grok hit its rate limit. Using the {exchanges} exchanges we completed.*"

        # Extract bullet points from summary
        summary_bullets = ""
        if summary:
            # Take the key points section
            lines = [l.strip() for l in summary.split('\n') if l.strip().startswith('-')]
            if lines:
                summary_bullets = "\n".join(lines[:8])  # Top 8 bullets
            else:
                summary_bullets = summary[:400] + "..."

        topic_note = ""
        if is_self_topic:
            topic_note = "\n*(Stored as model metadata, not world facts)*"

        recap = f"""## Grok Session: {session.topic}

**Duration:** {actual_duration:.1f} minutes | **Exchanges:** {exchanges}

### Key Insights:
{summary_bullets}

**Stored:** {facts_stored} insights under `{concept_key}`{topic_note}{status_note}"""
        result["recap"] = recap

    elif session.status == "error":
        result["recap"] = f"Session failed: {session.error_message or 'Unknown error'}"
    else:
        result["recap"] = f"Session {session.status}: {session.error_message or 'No details available'}"

    if verbose:
        print(f"\n[GROK_SESSION] Session complete!")
        print(f"[GROK_SESSION] Status: {session.status}")
        print(f"[GROK_SESSION] Duration: {actual_duration:.1f} minutes")
        print(f"[GROK_SESSION] Turns: {len(session.transcript)}")
        print(f"[GROK_SESSION] Facts stored: {facts_stored}")

    return result


# ============================================================================
# Service API (for agency tool integration)
# ============================================================================

def service_api(msg: Dict[str, Any]) -> Dict[str, Any]:
    """
    Standard service API for brain-style tool integration.

    Ops:
    - START_SESSION: Start a new conversation session
    - PARSE_COMMAND: Parse a conversation command
    - GET_SESSION: Get info about a past session

    Args:
        msg: API message with 'op' and 'payload'

    Returns:
        Result dict with 'ok' and 'payload'
    """
    op = (msg or {}).get("op", "").upper()
    payload = (msg or {}).get("payload") or {}

    if op == "START_SESSION":
        topic = payload.get("topic", "")
        duration = payload.get("duration_minutes", DEFAULT_DURATION_MINUTES)
        max_turns = payload.get("max_turns", DEFAULT_MAX_TURNS)

        if not topic:
            return {"ok": False, "error": {"message": "No topic provided"}}

        result = run_grok_conversation_session(
            topic=topic,
            duration_minutes=duration,
            max_turns=max_turns,
            verbose=payload.get("verbose", True),
        )

        return {"ok": result.get("status") in ("completed", "aborted"), "payload": result}

    elif op == "PARSE_COMMAND":
        text = payload.get("text", "")
        parsed = parse_conversation_command(text)

        if parsed:
            return {"ok": True, "payload": parsed}
        else:
            return {"ok": False, "error": {"message": "Could not parse conversation command"}}

    elif op == "GET_SESSION":
        session_id = payload.get("session_id", "")

        if not _session_memory:
            return {"ok": False, "error": {"message": "Session memory unavailable"}}

        results = _session_memory.retrieve(query=session_id, limit=1)
        if results:
            return {"ok": True, "payload": results[0]}
        else:
            return {"ok": False, "error": {"message": f"Session {session_id} not found"}}

    else:
        return {"ok": False, "error": {"message": f"Unknown operation: {op}"}}


# ============================================================================
# Factory Function (for agency pattern integration)
# ============================================================================

class GrokConversationController:
    """Controller class for agency pattern integration."""

    def start_session(
        self,
        topic: str = "",
        duration_minutes: int = DEFAULT_DURATION_MINUTES,
        max_turns: int = DEFAULT_MAX_TURNS,
        **kwargs
    ) -> Dict[str, Any]:
        """Start a new conversation session."""
        if not topic:
            # Try to extract from kwargs
            text = kwargs.get("text", "") or kwargs.get("query", "")

            # Try to parse from text
            if text:
                parsed = parse_conversation_command(text)
                if parsed:
                    topic = parsed["topic"]
                    duration_minutes = parsed.get("duration_minutes", duration_minutes)
                else:
                    # Check if this is a Maven self-reference (e.g., "talk to grok about yourself")
                    if is_maven_self_reference(text):
                        return run_self_presentation_session(
                            duration_minutes=duration_minutes,
                            max_turns=6,
                        )
                    # No topic parsed - ask user to specify
                    return {
                        "status": "needs_topic",
                        "recap": "What would you like me to discuss with Grok? Try: 'talk to grok about <topic>'\n\nExamples:\n- talk to grok about artificial intelligence\n- have a convo with grok about medicine for 10 minutes\n- grok session about philosophy"
                    }

        if not topic:
            return {
                "status": "needs_topic",
                "recap": "What would you like me to discuss with Grok? Try: 'talk to grok about <topic>'"
            }

        return run_grok_conversation_session(
            topic=topic,
            duration_minutes=duration_minutes,
            max_turns=max_turns,
        )

    def parse_and_run(self, text: str = "", **kwargs) -> str:
        """Parse command and run session. Returns user-friendly recap string.

        Accepts both positional 'text' and keyword arguments for flexibility
        with different calling conventions from the integrator.

        FIX: Detects Maven self-references and runs self-presentation session
        instead of topic discussion when user says "talk to grok about yourself".
        """
        # Handle case where text comes via kwargs
        if not text:
            text = kwargs.get("text", "") or kwargs.get("query", "")

        if not text:
            return "Error: No conversation command provided. Try: 'have a convo with grok about <topic> for <N> minutes'"

        parsed = parse_conversation_command(text)
        if not parsed:
            return f"Error: Could not parse command. Try: 'have a convo with grok about <topic> for <N> minutes'"

        # FIX: Check if this is a Maven self-reference
        # "talk to grok about yourself" = Maven presents itself, NOT asks Grok about Grok
        topic = parsed["topic"]
        if is_maven_self_reference(topic):
            print(f"[GROK_SESSION] Detected Maven self-reference: '{topic}'")
            print(f"[GROK_SESSION] Maven will introduce ITSELF to Grok")

            result = run_self_presentation_session(
                duration_minutes=parsed["duration_minutes"],
                max_turns=6,  # Self-presentation has 6 phases
            )
        else:
            # Normal topic discussion
            result = run_grok_conversation_session(
                topic=topic,
                duration_minutes=parsed["duration_minutes"],
                max_turns=parsed.get("max_turns", DEFAULT_MAX_TURNS),
            )

        # Return the user-friendly recap, not the raw dict
        return result.get("recap", f"Session completed with status: {result.get('status')}")


_controller_instance = None


def get_grok_conversation_controller() -> GrokConversationController:
    """Factory function for lazy instantiation."""
    global _controller_instance
    if _controller_instance is None:
        _controller_instance = GrokConversationController()
    return _controller_instance


# ============================================================================
# Direct Entry Point
# ============================================================================

if __name__ == "__main__":
    import sys

    if len(sys.argv) < 2:
        print("Usage:")
        print("  python grok_conversation_session.py <topic> [duration_minutes]")
        print()
        print("Examples:")
        print("  python grok_conversation_session.py 'artificial intelligence' 10")
        print("  python grok_conversation_session.py medicine 5")
        sys.exit(1)

    topic = sys.argv[1]
    duration = int(sys.argv[2]) if len(sys.argv) > 2 else DEFAULT_DURATION_MINUTES

    result = run_grok_conversation_session(topic=topic, duration_minutes=duration)

    print("\n" + "=" * 60)
    print("SESSION COMPLETE")
    print("=" * 60)
    print(result.get("recap", str(result)))
