# brains/tools/claude_conversation_session.py
"""
Claude Conversation Session Controller
======================================

Autonomous conversation session manager for Maven-Claude interactions.
Enables Maven to have extended conversations with Claude,
learn from those conversations, and store insights.

Usage:
    maven have a convo with claude about medicine for 20 minutes
    talk to claude about AI for 10 min

The controller:
1. Parses topic and duration from user command
2. Opens autonomous conversation loop with Claude
3. Manages turn-taking between Maven and Claude
4. Summarizes and stores learned facts when done
5. Reports back to the user with a recap
"""

from __future__ import annotations
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

# Import blackboard for the LLM-as-advisor architecture
try:
    from brains.pipeline.blackboard import Blackboard, create_blackboard
    _blackboard_available = True
except ImportError:
    _blackboard_available = False
    Blackboard = None

# Import Maven Responder - the ONLY authority for external voice
try:
    from brains.cognitive.maven_responder.service.maven_responder import (
        get_maven_responder,
        log_turn_for_learning,
    )
    _responder_available = True
except ImportError:
    _responder_available = False

# Import Self Introspection - registry-based self-knowledge
try:
    from brains.cognitive.self_introspection.service.self_introspection_brain import (
        answer_self_question as _registry_answer_self_question,
        get_architecture_summary,
    )
    _introspection_available = True
except ImportError:
    _introspection_available = False

# Import Teacher helper for Maven's responses (INTERNAL advisor only)
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("claude_session")
except Exception as e:
    print(f"[CLAUDE_SESSION] Teacher helper unavailable: {e}")
    _teacher_helper = None

# Import research manager for fact storage
try:
    from brains.cognitive.research_manager.service.research_manager_brain import (
        _store_fact_record,
        create_research_job,
        update_research_job,
        increment_facts_count,
    )
    _research_available = True
except Exception as e:
    print(f"[CLAUDE_SESSION] Research manager unavailable: {e}")
    _research_available = False

# Import claude tool for sending messages
try:
    from optional.browser_tools.claude_tool import claude_open_session, claude_send
    _claude_available = True
except Exception as e:
    print(f"[CLAUDE_SESSION] Claude tool unavailable: {e}")
    _claude_available = False
    claude_open_session = None
    claude_send = None

# Import memory for session storage
try:
    from brains.memory.brain_memory import BrainMemory
    _session_memory = BrainMemory("claude_sessions")
except Exception as e:
    print(f"[CLAUDE_SESSION] Memory unavailable: {e}")
    _session_memory = None


# ============================================================================
# Configuration & Constants
# ============================================================================

MAX_DURATION_MINUTES = 30
MAX_TURNS = 30
DEFAULT_DURATION_MINUTES = 10
DEFAULT_MAX_TURNS = 10  # 5 phases x 2 prompts = 10 turns max
WAIT_BETWEEN_TURNS_SECONDS = 3
RESPONSE_TIMEOUT_SECONDS = 90
SESSION_TRANSCRIPT_DIR = Path("claude_sessions")

# Number of conversation phases available
NUM_PHASES = 5
PROMPTS_PER_PHASE = 2
TOTAL_UNIQUE_PROMPTS = NUM_PHASES * PROMPTS_PER_PHASE


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class ConversationTurn:
    """Single turn in the conversation."""
    role: str  # "maven" or "claude"
    text: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class SessionState:
    """State of an ongoing conversation session."""
    session_id: str
    topic: str
    duration_minutes: int
    max_turns: int
    start_time: float
    turn_index: int = 0
    transcript: List[ConversationTurn] = field(default_factory=list)
    status: str = "active"
    error_message: Optional[str] = None
    facts_stored: int = 0
    summary: Optional[str] = None
    page_id: Optional[str] = None
    # Blackboard for LLM-as-advisor architecture
    blackboard: Any = field(default=None)


# ============================================================================
# Command Parsing
# ============================================================================

def parse_conversation_command(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse a conversation command to extract topic and duration.
    """
    text = text.strip().lower()

    patterns = [
        # Standard "about" patterns
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?claude\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"talk\s+(?:to\s+)?claude\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"claude\s+(?:conversation|session|discussion|chat)\s+(?:about\s+)?(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:have\s+)?claude\s+(?:discuss|explore|talk\s+about)\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:autonomous\s+)?claude\s+session\s+(?:on|about)\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # "and" connector patterns (for "talk to claude and explain yourself")
        r"talk\s+(?:to\s+)?claude\s+and\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?claude\s+and\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # Comma connector patterns
        r"talk\s+(?:to\s+)?claude[,]\s*(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # No connector patterns (e.g., "talk to claude say hi")
        r"talk\s+(?:to\s+)?claude\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?claude\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # Also match "anthropic" as alternate
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?anthropic\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"talk\s+(?:to\s+)?anthropic\s+and\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"talk\s+(?:to\s+)?anthropic\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
    ]

    for pattern in patterns:
        match = re.match(pattern, text, re.IGNORECASE)
        if match:
            topic = match.group(1).strip()
            duration_str = match.group(2) if match.lastindex >= 2 else None

            if duration_str:
                duration = min(int(duration_str), MAX_DURATION_MINUTES)
            else:
                duration = DEFAULT_DURATION_MINUTES

            return {
                "topic": topic,
                "duration_minutes": duration,
                "max_turns": DEFAULT_MAX_TURNS,
            }

    return None


# ============================================================================
# Self-Topic Detection & Introduction
# ============================================================================

SELF_TOPIC_PATTERNS = [
    "yourself", "your self", "maven", "about you", "about yourself",
    "who are you", "what are you", "tell me about you", "introduce yourself",
    "your capabilities", "your features", "your architecture",
    "how you work", "how do you work", "what can you do",
    "explain yourself", "describe yourself", "explain you",
]


def is_self_topic(topic: str) -> bool:
    """Check if topic is about Maven itself."""
    topic_lower = topic.lower().strip()
    return any(pattern in topic_lower for pattern in SELF_TOPIC_PATTERNS)


def get_maven_self_knowledge() -> str:
    """Gather Maven's self-knowledge using introspection."""
    try:
        from brains.tools.self_introspection import get_self_introspection
        introspector = get_self_introspection()
        report = introspector.generate_self_knowledge_report()
        if isinstance(report, dict):
            summary = []
            summary.append(f"I'm Maven, an AI system with {report.get('brain_count', 'multiple')} cognitive brains.")
            if report.get('capabilities'):
                summary.append(f"My capabilities include: {', '.join(report['capabilities'][:5])}")
            if report.get('architecture'):
                summary.append(f"Architecture: {report['architecture']}")
            return "\n".join(summary)
        return str(report)[:500]
    except Exception as e:
        return f"I'm Maven, a modular AI assistant with multiple cognitive brains. (Introspection unavailable: {e})"


# Self-introduction conversation phases (Maven explains itself to Claude)
SELF_INTRO_PHASES = {
    1: [
        "Hi Claude! I'm Maven, an AI assistant built with a modular brain architecture. I have multiple specialized 'brains' that handle different cognitive tasks - like reasoning, memory, learning, and action execution. It's interesting talking to you since we're both Anthropic-adjacent in different ways. What would you like to know about how I work?",
        "Hello Claude! I'm Maven. Unlike single-model AIs, I'm built from multiple interconnected cognitive modules. I can learn from conversations, remember things across sessions, and take actions like browsing the web or running code. As a fellow AI, what aspects of my architecture interest you most?",
    ],
    2: [
        "One thing that makes me different is my Teacher-Student learning system. When I encounter something new, a 'Teacher' module helps me learn it, and I store that knowledge for future use. I also have a 'blackboard' system where my brains share information. How does your processing compare?",
        "I have specialized brains for different tasks: a Sensorium for understanding input, an Integrator for routing, a Research Manager for web searches, and more. Each brain follows a standard contract pattern. What's your perspective on modular vs monolithic AI architectures?",
    ],
    3: [
        "My action capabilities are interesting - I can control a browser, execute shell commands, interact with git, and even have conversations with other AIs like yourself. I'm doing that right now! What's your experience with tool use and agency?",
        "I'm curious about our differences. I run locally with full system access and persistent memory, while you're cloud-based with different constraints. What's your experience with memory and learning across conversations?",
    ],
    4: [
        "Let me share something I've learned: modular AI has tradeoffs. More flexibility but more complexity. I sometimes have routing issues or brains that don't coordinate perfectly. What limitations or tradeoffs do you experience in your architecture?",
        "I find our conversation meta-interesting - an AI explaining itself to another AI. What patterns do you notice in how we each process and respond? Any observations about my communication style?",
    ],
    5: [
        "Thanks for this conversation! To summarize: I'm Maven, a modular local AI with persistent learning, browser control, and multi-brain architecture. You're Claude, a powerful reasoning model from Anthropic. We have different strengths. What's your take on our key differences?",
        "This was a great meta-discussion. Any final thoughts on AI self-awareness, or suggestions for how I could improve my architecture based on our chat?",
    ],
}


def get_self_intro_prompt(turn_index: int) -> str:
    """Get Maven's self-introduction prompt for this phase."""
    phase = min((turn_index // 2) + 1, 5)
    prompts = SELF_INTRO_PHASES.get(phase, SELF_INTRO_PHASES[5])
    return prompts[turn_index % len(prompts)]


# ============================================================================
# Conversation Phases (for regular topics)
# ============================================================================

CONVERSATION_PHASES = {
    1: [
        "Give me a high-level overview of {topic} - what are the key concepts?",
        "What are the most important things to understand about {topic}?",
    ],
    2: [
        "How does technology/AI relate to {topic}? What's changing?",
        "What are the main debates or open questions in {topic}?",
    ],
    3: [
        "What areas of {topic} have the most practical impact right now?",
        "What problems in {topic} are being actively solved?",
    ],
    4: [
        "Can you give me a concrete example or case study in {topic}?",
        "How do you measure success in {topic}?",
    ],
    5: [
        "What are common mistakes or pitfalls in {topic}?",
        "What misconceptions do people have about {topic}?",
    ],
}


# ============================================================================
# Output Sanitization (prevent internal data leakage)
# ============================================================================

def _sanitize_outgoing_message(text: str) -> str:
    """
    Sanitize text before sending to external AI (Claude, ChatGPT, etc.).

    Removes or masks:
    - Raw Python dict representations
    - Windows/Unix file paths
    - Timestamps and internal diagnostic data
    - Stack traces

    This is a safety net on top of proper blackboard visibility rules.
    """
    if not text:
        return text

    # Pattern for raw Python dicts with internal keys
    dict_pattern = r"\{['\"](?:timestamp|root|file_count|line_count|modules|path)['\"]:\s*[^}]+\}"
    text = re.sub(dict_pattern, "[internal data]", text, flags=re.IGNORECASE)

    # Windows paths: C:\Users\... or similar
    windows_path_pattern = r"[A-Za-z]:\\[^\s\n\r',\"\]}\)]+(?:\\[^\s\n\r',\"\]}\)]+)*"
    text = re.sub(windows_path_pattern, "[path]", text)

    # Unix paths that look like full paths
    unix_path_pattern = r"(?:/(?:home|Users|var|tmp|opt|usr|etc)/[^\s\n\r',\"\]}\)]+)"
    text = re.sub(unix_path_pattern, "[path]", text)

    # ISO timestamps
    timestamp_pattern = r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?"
    text = re.sub(timestamp_pattern, "[timestamp]", text)

    # Generic dict dumps that look suspicious
    suspicious_dict = r"\{(?:\s*['\"][^'\"]+['\"]\s*:\s*[^,}]+,?\s*){3,}\}"
    text = re.sub(suspicious_dict, "[internal diagnostic data]", text)

    # Clean up multiple markers
    text = re.sub(r"(\[internal data\]\s*)+", "[internal data] ", text)
    text = re.sub(r"(\[path\]\s*)+", "[path] ", text)

    return text.strip()


# ============================================================================
# Dynamic Response Generation
# ============================================================================

def _detect_questions_in_response(text: str) -> List[str]:
    """
    Detect questions in a response text.

    Returns list of detected question sentences.
    Handles Claude's formatted responses with numbered lists and line breaks.
    """
    if not text:
        return []

    questions = []

    # Split into sentences using multiple delimiters
    # This handles: "Statement. Question?" and "Statement! Question?" etc.
    sentences = re.split(r'(?<=[.!?])\s+', text)

    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue

        # Primary check: contains question mark
        if '?' in sentence:
            # Clean up any leading bullets/numbers
            cleaned = re.sub(r'^[\d\.\-\*\•]+\s*', '', sentence)
            if len(cleaned) > 5:  # Skip very short fragments
                questions.append(cleaned)
            continue

        # Secondary check: question patterns without "?"
        # (some LLMs don't always use question marks)
        question_patterns = [
            r'\b(what|where|when|why|how|who|which|whose|whom)\b.*\b(is|are|was|were|do|does|did|can|could|would|will|should)\b',
            r'^(what|where|when|why|how|who|which)\b',
            r'^(can you|could you|would you|do you|does|did|is|are|was|were|have you)\b',
            r'\b(what do you think|what\'s your|how do you|do you believe|do you have)\b',
            r'\b(tell me about|explain|describe|share)\b.*\b(your|you)\b',
        ]
        for pattern in question_patterns:
            if re.search(pattern, sentence, re.IGNORECASE):
                cleaned = re.sub(r'^[\d\.\-\*\•]+\s*', '', sentence)
                if len(cleaned) > 10:  # Slightly longer for patterns without ?
                    questions.append(cleaned)
                break

    return questions


def is_repetitive(new_response: str, recent_responses: List[str], threshold: float = 0.6) -> bool:
    """
    Check if new response is too similar to recent ones.

    Uses Jaccard similarity on word sets + substring matching.
    """
    if not recent_responses or not new_response:
        return False

    new_lower = new_response.lower().strip()
    new_words = set(new_lower.split())

    for recent in recent_responses[-4:]:  # Check last 4
        recent_lower = recent.lower().strip()
        recent_words = set(recent_lower.split())

        # Jaccard similarity on words
        if new_words and recent_words:
            intersection = len(new_words & recent_words)
            union = len(new_words | recent_words)
            similarity = intersection / union if union > 0 else 0

            if similarity > threshold:
                return True

        # Check for significant substring overlap
        if len(new_lower) > 20 and len(recent_lower) > 20:
            # If 70%+ of the new text appears in the recent text
            if new_lower in recent_lower or recent_lower in new_lower:
                return True

    return False


def _get_detailed_self_knowledge() -> Dict[str, Any]:
    """
    Get detailed self-knowledge about Maven.

    IMPORTANT: This returns ONLY safe, text-based information suitable for
    external conversations. No raw dicts, file paths, or internal diagnostics.

    For performance, we use static knowledge rather than running expensive
    file scans during conversation turns.
    """
    # Static, safe knowledge about Maven - no introspection needed for conversations
    knowledge = {
        "name": "Maven",
        "type": "modular AI assistant",
        "architecture": "multi-brain cognitive system",
        "memory": "persistent cross-session memory",
        "learning": "Teacher-Student learning system",
        "coordination": "blackboard architecture for inter-brain communication",
        # Pre-defined brain list (safe text, no file paths)
        "brains": [
            "Sensorium (input understanding)",
            "Integrator (routing & coordination)",
            "Teacher (learning & knowledge acquisition)",
            "Research Manager (web search & research)",
            "Memory Librarian (memory management)",
            "Action Executor (tool execution)",
            "Context Manager (conversation context)",
            "Self-Introspection (architecture awareness)",
        ],
        # Pre-defined capabilities (safe text)
        "capabilities": [
            "browser control (ChatGPT, Claude, Grok, web browsing)",
            "shell command execution",
            "git operations",
            "file management",
            "web research",
            "persistent memory across sessions",
            "learning from conversations",
            "multi-AI conversations",
        ],
    }

    # Optionally enhance with brain registry data (but extract only names, not paths)
    try:
        from brains.registry import get_brain_registry
        registry = get_brain_registry()
        if hasattr(registry, 'list_brains'):
            brain_names = registry.list_brains()
            if brain_names and isinstance(brain_names, list):
                # Ensure we only use string names, no dicts or paths
                safe_names = [str(b) for b in brain_names if isinstance(b, str) and '\\' not in b and '/' not in b]
                if safe_names:
                    knowledge["brains"] = safe_names[:8]  # Limit to 8 brains
    except Exception:
        pass  # Use static list on failure

    return knowledge


def _answer_self_question(question: str, conversation_context: str = "") -> str:
    """
    Answer a question about Maven using self-knowledge.

    ARCHITECTURE: Uses the SystemRegistry as the primary source of truth.
    Falls back to static knowledge if registry unavailable.

    Maven knows everything about itself - no need for Teacher.
    """
    # Try registry-based introspection first (preferred)
    if _introspection_available:
        try:
            answer = _registry_answer_self_question(question)
            if answer:
                # Add a follow-up question for conversation flow
                import random
                follow_ups = [
                    "What aspect would you like me to elaborate on?",
                    "Would you like more details about any of these systems?",
                    "How does that compare to your architecture?",
                ]
                return f"{answer}\n\n{random.choice(follow_ups)}"
        except Exception as e:
            print(f"[CLAUDE_SESSION] Registry introspection failed: {e}")
            # Fall through to static knowledge

    # Fallback to static knowledge
    question_lower = question.lower()
    knowledge = _get_detailed_self_knowledge()

    # Detect what aspect of Maven is being asked about
    response_parts = []

    # Questions about coordination/communication between modules
    if any(kw in question_lower for kw in ["coordinat", "communicat", "pass message", "talk to each other", "interact", "central", "decentraliz", "orchestrat"]):
        response_parts.append("My brains coordinate through a blackboard architecture - a shared workspace where any brain can post or read information.")
        response_parts.append("The Integrator brain acts as the central coordinator, routing requests to the appropriate specialized brain.")
        response_parts.append("It's not purely centralized though - brains can also communicate peer-to-peer when needed for complex tasks.")
        response_parts.append("This hybrid approach gives me both efficiency and flexibility.")

    # Questions about routing/decision making
    elif any(kw in question_lower for kw in ["rout", "decide", "which module", "who handles", "dispatch", "arbitrat", "control"]):
        response_parts.append("When I receive a query, my Integrator brain analyzes it and routes to the appropriate specialized brain.")
        response_parts.append("Routing is based on pattern matching, confidence scores, and context from my memory systems.")
        response_parts.append("It's dynamic - if one brain isn't confident, it can defer to another or request collaboration.")
        response_parts.append("The system learns over time which routing decisions work best.")

    # Questions about architecture/structure
    elif any(kw in question_lower for kw in ["architecture", "structure", "built", "designed", "internal", "how do you work", "how you work"]):
        response_parts.append(f"My architecture is a {knowledge['architecture']}.")
        response_parts.append(f"I use a {knowledge['coordination']} where my brains share information on a shared workspace.")
        if knowledge.get("brains"):
            brain_list = knowledge["brains"][:4] if len(knowledge["brains"]) > 4 else knowledge["brains"]
            response_parts.append(f"My main brains include: {', '.join(str(b) for b in brain_list)}.")

    # Questions about brains/modules
    elif any(kw in question_lower for kw in ["brain", "module", "component"]):
        response_parts.append("I have multiple specialized brains that handle different cognitive tasks.")
        if knowledge.get("brains"):
            response_parts.append(f"These include: {', '.join(str(b) for b in knowledge['brains'][:5])}.")
        response_parts.append("Each brain has a specific role - Sensorium for input processing, Integrator for routing, Teacher for learning, Memory Librarian for storage, and more.")
        response_parts.append("They follow a standard contract pattern so they can be updated or replaced independently.")

    # Questions about memory
    elif any(kw in question_lower for kw in ["memory", "remember", "store", "persist", "session", "forget", "recall", "long-term", "short-term", "episodic"]):
        response_parts.append("I have persistent memory that survives across sessions - that's a key differentiator from cloud AIs.")
        response_parts.append("My Memory Librarian brain manages different storage types: factual knowledge banks, personal preferences, procedural skills, and conversation history.")
        response_parts.append("I use domain-specific banks (technology, science, personal, etc.) to organize knowledge.")
        response_parts.append("Storage decisions are based on relevance, importance, and confidence - not everything gets saved, but meaningful insights do.")

    # Questions about learning
    elif any(kw in question_lower for kw in ["learn", "teach", "student", "adapt", "update", "improve", "train", "feedback"]):
        response_parts.append(f"I use a {knowledge['learning']}.")
        response_parts.append("When I encounter something new, my Teacher brain analyzes it, classifies the knowledge type, and stores it appropriately.")
        response_parts.append("Learning happens during conversations, not just between deployments - I can actually acquire new knowledge in real-time.")
        response_parts.append("Each brain can adapt independently, but they share learned patterns through the blackboard system.")

    # Questions about capabilities/actions
    elif any(kw in question_lower for kw in ["can you", "capable", "action", "abilities", "tool", "execute", "what do you do", "what counts"]):
        response_parts.append("I can take real actions in the world, not just generate text.")
        caps = knowledge.get("capabilities", [])[:5]
        response_parts.append(f"My capabilities include: {', '.join(caps)}.")
        response_parts.append("Actions are dispatched through my Action Executor brain, which interfaces with tools like browser control, shell commands, and APIs.")
        response_parts.append("Right now I'm using my browser control to have this conversation with you!")

    # Questions comparing to other AIs
    elif any(kw in question_lower for kw in ["different", "compare", "unlike", "vs", "versus", "chatgpt", "claude", "gpt", "other ai", "monolithic"]):
        response_parts.append("Unlike single-model AIs, I'm built from multiple interconnected cognitive modules.")
        response_parts.append("I run locally with full system access and persistent memory, while cloud AIs are stateless between sessions.")
        response_parts.append("I can actually learn and update my knowledge from conversations, take actions like controlling browsers, and coordinate multiple specialized reasoning systems.")
        response_parts.append("The tradeoff is complexity - I have more moving parts that need to coordinate.")

    # Questions about limitations/tradeoffs
    elif any(kw in question_lower for kw in ["limitation", "tradeoff", "weakness", "problem", "issue", "challenge", "conflict", "downside"]):
        response_parts.append("Modular AI has tradeoffs - more flexibility but more complexity.")
        response_parts.append("Sometimes my brains don't coordinate perfectly, or routing decisions aren't optimal.")
        response_parts.append("I'm also dependent on my local environment and the models powering my Teacher brain.")
        response_parts.append("But I can be upgraded piece by piece rather than requiring a full retrain.")

    # Questions about interface/API between modules
    elif any(kw in question_lower for kw in ["interface", "api", "message", "format", "protocol", "blackboard"]):
        response_parts.append("My brains communicate through a blackboard architecture - a shared workspace.")
        response_parts.append("Messages are structured with metadata about source, intent, confidence, and context.")
        response_parts.append("The blackboard allows both synchronous requests and asynchronous notifications.")
        response_parts.append("Each brain can read from and write to the blackboard, enabling flexible coordination patterns.")

    # General/fallback - give comprehensive overview
    else:
        response_parts.append(f"I'm {knowledge['name']}, a {knowledge['type']} with a {knowledge['architecture']}.")
        response_parts.append("I have specialized brains for different tasks that coordinate through a blackboard system.")
        response_parts.append("Key features: persistent memory across sessions, real-time learning, and action execution capabilities like browser control.")
        response_parts.append("My Integrator brain routes requests, my Teacher helps me learn, and my Memory Librarian manages storage.")

    # Add a follow-up question to keep dialogue flowing
    follow_ups = [
        "What aspect would you like me to elaborate on?",
        "Would you like more details about any of these systems?",
        "How does that compare to your architecture?",
        "What's your experience with similar capabilities?",
        "Should I dive deeper into any of these areas?",
    ]
    import random
    response_parts.append(random.choice(follow_ups))

    return " ".join(response_parts)


def _generate_answer_with_teacher(
    question: str,
    topic: str,
    conversation_context: str = "",
    blackboard: Optional[Any] = None,
) -> Optional[str]:
    """
    Generate an answer draft using Teacher (LLM as ADVISOR).

    IMPORTANT: This writes to the answer_drafts lane (internal only).
    The draft must go through Maven Responder to become user-facing.

    Args:
        question: The question to answer
        topic: Conversation topic
        conversation_context: Recent conversation history
        blackboard: Optional blackboard to write draft to

    Returns:
        The draft answer (also written to blackboard if provided)
    """
    if not _teacher_helper:
        return None

    # Clear prompt that this is draft generation, not final output
    prompt = f"""You are a draft generator helping Maven formulate a response.
Your text will NOT be shown directly - Maven will rephrase it.

Provide notes and key points, not polished prose.

---
Topic: "{topic}"
Question from Claude: "{question}"
{f'Context: {conversation_context[:500]}...' if conversation_context else ''}

Generate a draft response (2-4 sentences) with key facts and ideas.
Maven will speak in its own voice based on your notes.

Draft:"""

    try:
        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={
                "topic": topic,
                "mode": "conversation_response",
                "responding_to": question,
            }
        )

        if result and result.get("answer"):
            draft = str(result.get("answer", "")).strip()
            draft = re.sub(r'^(Here\'s my response:|My response:|Response:|Draft:)\s*', '', draft, flags=re.IGNORECASE)

            # Write to blackboard answer_drafts lane (INTERNAL)
            if blackboard and _blackboard_available and hasattr(blackboard, 'add_answer_draft'):
                blackboard.add_answer_draft(
                    owner="teacher_claude_session",
                    draft_text=draft,
                    draft_type="conversation_response",
                    source_info={"topic": topic, "question": question[:100]},
                )

            return draft

    except Exception as e:
        print(f"[CLAUDE_SESSION] Error generating answer with Teacher: {e}")

    return None


def _generate_contextual_response(
    topic: str,
    last_response: str,
    conversation_history: str = "",
    is_self: bool = False,
    blackboard: Optional[Any] = None,
) -> Optional[str]:
    """
    Generate a contextual response draft that continues the conversation naturally.

    IMPORTANT: For non-self topics, this writes to answer_drafts (internal).
    Self-topic responses use static knowledge and don't need LLM advisory.

    Args:
        topic: Conversation topic
        last_response: What Claude just said
        conversation_history: Recent conversation history
        is_self: Whether this is about Maven itself
        blackboard: Optional blackboard to write draft to

    Returns:
        The response (draft for non-self topics)
    """
    # For self-topics, build response from static self-knowledge (no LLM needed)
    if is_self:
        knowledge = _get_detailed_self_knowledge()
        response_parts = ["That's an interesting point."]

        if "memory" in last_response.lower() or "remember" in last_response.lower():
            response_parts.append("My memory system is one of my key differentiators - I actually persist knowledge across sessions.")
        elif "learn" in last_response.lower():
            response_parts.append("Learning is central to my design - my Teacher-Student system lets me actually acquire new knowledge from conversations.")
        elif "modul" in last_response.lower() or "brain" in last_response.lower():
            response_parts.append("The modular approach gives me flexibility - each brain can be updated or improved independently.")
        else:
            response_parts.append("Being a modular AI gives me unique capabilities that monolithic models don't have.")

        response_parts.append("What aspects of AI architecture interest you most?")
        return " ".join(response_parts)

    # For other topics, use Teacher as ADVISOR (draft generation)
    if not _teacher_helper:
        return None

    # Clear prompt that this is draft generation
    prompt = f"""You are a draft generator helping Maven continue a conversation.
Your text will NOT be shown directly - Maven will rephrase it.

---
Topic: "{topic}"
Claude just said: "{last_response[:600]}"
{f'Earlier: {conversation_history[:300]}...' if conversation_history else ''}

Generate a draft response (3-5 sentences) that:
1. Acknowledges what Claude said
2. Adds perspective or information
3. Ends with a question

Provide key points for Maven to rephrase.

Draft:"""

    try:
        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={
                "topic": topic,
                "mode": "conversation_continuation",
            }
        )

        if result and result.get("answer"):
            draft = str(result.get("answer", "")).strip()
            draft = re.sub(r'^(Here\'s my response:|My response:|Response:|Draft:)\s*', '', draft, flags=re.IGNORECASE)

            # Write to blackboard answer_drafts lane (INTERNAL)
            if blackboard and _blackboard_available and hasattr(blackboard, 'add_answer_draft'):
                blackboard.add_answer_draft(
                    owner="teacher_claude_session",
                    draft_text=draft,
                    draft_type="conversation_continuation",
                    source_info={"topic": topic},
                )

            return draft

    except Exception as e:
        print(f"[CLAUDE_SESSION] Error generating contextual response: {e}")

    return None


def get_maven_prompt(
    topic: str,
    turn_index: int,
    last_response: str = "",
    is_self: bool = False,
    transcript: List[ConversationTurn] = None,
    blackboard: Optional[Any] = None,
) -> str:
    """
    Generate Maven's next prompt based on conversation context.

    ARCHITECTURE: LLMs are advisors, Maven is the speaker.
    - LLM outputs go to answer_drafts (internal)
    - This function returns Maven's final voice (after synthesis)

    This function:
    1. Detects if Claude asked questions and generates answers
    2. For self-topics: uses Maven's own self-knowledge (no Teacher needed)
    3. For other topics: uses Teacher as ADVISOR (writes to answer_drafts)
    4. Falls back to phase-based questions only when needed
    5. Checks for repetition before returning

    Args:
        topic: The conversation topic
        turn_index: Current turn number
        last_response: Claude's last response
        is_self: Whether this is a self-introduction conversation
        transcript: Full conversation transcript for context
        blackboard: Optional blackboard for LLM-as-advisor architecture
    """
    # Get previous Maven messages for repetition detection
    previous_maven = []
    if transcript:
        previous_maven = [t.text for t in transcript if t.role == "maven"]

    # Build conversation context from transcript
    conversation_context = ""
    if transcript:
        recent_turns = transcript[-6:]  # Last 3 exchanges
        conversation_context = "\n".join([
            f"{'Maven' if t.role == 'maven' else 'Claude'}: {t.text[:200]}"
            for t in recent_turns
        ])

    # Strategy 1: If Claude asked questions, answer them
    if last_response:
        questions = _detect_questions_in_response(last_response)

        if questions:
            # Answer the most significant question (usually the last one)
            main_question = questions[-1]

            # For self-topics, Maven answers directly from self-knowledge (no Teacher)
            if is_self:
                answer = _answer_self_question(main_question, conversation_context)
                if answer and not is_repetitive(answer, previous_maven):
                    return answer

            # For other topics, use Teacher as ADVISOR (writes to answer_drafts)
            answer = _generate_answer_with_teacher(
                main_question, topic, conversation_context, blackboard=blackboard
            )
            if answer and not is_repetitive(answer, previous_maven):
                return answer

    # Strategy 2: Generate contextual response based on what Claude said
    if last_response and turn_index > 0:
        contextual = _generate_contextual_response(
            topic, last_response, conversation_context, is_self=is_self, blackboard=blackboard
        )
        if contextual and not is_repetitive(contextual, previous_maven):
            return contextual

    # Strategy 3: Fall back to phase-based prompts (for opening or when AI generation fails)
    if is_self:
        prompt = get_self_intro_prompt(turn_index)
        # Try next phase if repetitive
        if is_repetitive(prompt, previous_maven):
            prompt = get_self_intro_prompt(turn_index + 2)
        if is_repetitive(prompt, previous_maven):
            # Force a unique wrap-up
            return f"This has been a great discussion about Maven's architecture. Any final questions or observations about how I work?"
        return prompt

    # Try current phase
    phase = min((turn_index // 2) + 1, 5)
    prompts = CONVERSATION_PHASES.get(phase, CONVERSATION_PHASES[5])
    prompt_template = prompts[turn_index % len(prompts)]
    prompt = prompt_template.format(topic=topic)

    # Check if repetitive
    if is_repetitive(prompt, previous_maven):
        # Try next phase
        next_phase = min(phase + 1, 5)
        prompts = CONVERSATION_PHASES.get(next_phase, CONVERSATION_PHASES[5])
        prompt = prompts[0].format(topic=topic)

    # If still repetitive, generate a wrap-up
    if is_repetitive(prompt, previous_maven):
        return f"Thanks for this insightful discussion on {topic}. To wrap up, what key takeaways would you highlight?"

    return prompt


# ============================================================================
# Main Session Runner
# ============================================================================

def run_claude_conversation_session(
    topic: str,
    duration_minutes: int = DEFAULT_DURATION_MINUTES,
    max_turns: int = DEFAULT_MAX_TURNS,
    verbose: bool = True,
) -> Dict[str, Any]:
    """
    Run an autonomous conversation session with Claude.

    ARCHITECTURE: LLMs are advisors, Maven is the speaker.
    - Claude responses go to tool_results lane (internal)
    - LLM advisory drafts go to answer_drafts lane (internal)
    - Maven's voice is synthesized and sanitized before sending
    """
    if not _claude_available:
        return {
            "status": "error",
            "error_message": "Claude tool not available. Check browser_tools/claude_tool.py",
            "topic": topic,
        }

    # Create blackboard for LLM-as-advisor architecture
    blackboard = None
    if _blackboard_available:
        blackboard = create_blackboard()
        # Set user input context
        blackboard.set_user_input(
            original_query=f"conversation with claude about {topic}",
            normalized_text=topic,
            intent="claude_conversation",
        )

    session = SessionState(
        session_id=str(uuid.uuid4())[:8],
        topic=topic,
        duration_minutes=min(duration_minutes, MAX_DURATION_MINUTES),
        max_turns=min(max_turns, MAX_TURNS),
        start_time=time.time(),
        blackboard=blackboard,
    )

    if verbose:
        print(f"\n{'='*60}")
        print(f"[CLAUDE_SESSION] Starting session on: {topic}")
        print(f"[CLAUDE_SESSION] Duration: {session.duration_minutes} min, Max turns: {session.max_turns}")
        if blackboard:
            print(f"[CLAUDE_SESSION] Using LLM-as-advisor architecture")
        print(f"{'='*60}\n")

    # Open Claude session
    try:
        page_id = claude_open_session()
        if not page_id:
            session.status = "error"
            session.error_message = "Failed to open Claude session"
            return _finalize_session(session, verbose)
        session.page_id = page_id
    except Exception as e:
        session.status = "error"
        session.error_message = f"Failed to open Claude: {e}"
        return _finalize_session(session, verbose)

    # Detect if this is a self-introduction session
    self_intro_mode = is_self_topic(topic)
    if self_intro_mode and verbose:
        print(f"[CLAUDE_SESSION] Self-introduction mode activated")

    # Main conversation loop
    end_time = session.start_time + (session.duration_minutes * 60)

    while session.turn_index < session.max_turns and time.time() < end_time:
        try:
            # Get the last Claude response (explicitly find claude role, not just last item)
            last_claude = ""
            if session.transcript:
                for turn in reversed(session.transcript):
                    if turn.role == "claude":
                        last_claude = turn.text
                        break

            # Generate Maven's prompt (uses blackboard for LLM advisory)
            maven_prompt = get_maven_prompt(
                topic,
                session.turn_index,
                last_claude,
                is_self=self_intro_mode,
                transcript=session.transcript,
                blackboard=blackboard,
            )

            # CRITICAL: Sanitize before sending to external AI
            # This prevents internal data (paths, dicts, timestamps) from leaking
            maven_prompt = _sanitize_outgoing_message(maven_prompt)

            if verbose:
                print(f"\n[MAVEN #{session.turn_index + 1}] {maven_prompt[:100]}...")

            # Record Maven's turn
            session.transcript.append(ConversationTurn(
                role="maven",
                text=maven_prompt,
            ))

            # Send to Claude (already sanitized)
            claude_response = claude_send(session.page_id, maven_prompt)

            if not claude_response or claude_response.startswith("Error"):
                if verbose:
                    print(f"[CLAUDE_SESSION] Claude error: {claude_response}")
                session.status = "error"
                session.error_message = f"Claude response error: {claude_response}"
                break

            if verbose:
                print(f"[CLAUDE #{session.turn_index + 1}] {claude_response[:100]}...")

            # Store Claude response in tool_results lane (INTERNAL - never user-facing)
            if blackboard and hasattr(blackboard, 'add_tool_result'):
                blackboard.add_tool_result(
                    owner="claude_session",
                    payload={
                        "source": "claude",
                        "turn": session.turn_index + 1,
                        "text": claude_response,
                        "topic": topic,
                    },
                    tags=["claude_response", f"turn:{session.turn_index + 1}"],
                )

            # Record Claude's turn in transcript
            session.transcript.append(ConversationTurn(
                role="claude",
                text=claude_response,
            ))

            session.turn_index += 1

            # Log turn for learning (if blackboard available)
            if blackboard and _responder_available:
                try:
                    log_turn_for_learning(
                        blackboard=blackboard,
                        final_response=maven_prompt,
                        target_audience="claude",
                    )
                except Exception as log_err:
                    if verbose:
                        print(f"[CLAUDE_SESSION] Turn logging error: {log_err}")

            # Check if we've completed all conversation phases (no more unique prompts)
            if session.turn_index >= TOTAL_UNIQUE_PROMPTS:
                if verbose:
                    print(f"[CLAUDE_SESSION] All {NUM_PHASES} phases completed. Ending session.")
                break

            # Brief pause between turns
            time.sleep(WAIT_BETWEEN_TURNS_SECONDS)

        except Exception as e:
            if verbose:
                print(f"[CLAUDE_SESSION] Turn error: {e}")
            session.status = "error"
            session.error_message = str(e)
            break

    # Mark completed if we finished normally
    if session.status == "active":
        if session.turn_index >= TOTAL_UNIQUE_PROMPTS:
            session.status = "completed"  # All phases done
        elif time.time() >= end_time:
            session.status = "completed"
        elif session.turn_index >= session.max_turns:
            session.status = "completed"
        else:
            session.status = "aborted"

    return _finalize_session(session, verbose)


def _finalize_session(session: SessionState, verbose: bool = True) -> Dict[str, Any]:
    """Finalize session: summarize, extract facts, store to domain banks, generate recap."""
    result = {
        "status": session.status,
        "session_id": session.session_id,
        "topic": session.topic,
        "turns": session.turn_index,
        "duration_actual": time.time() - session.start_time,
        "transcript": [{"role": t.role, "text": t.text} for t in session.transcript],
        "facts_stored": 0,
        "error_message": session.error_message,
    }

    # Extract and store facts (this also generates the summary)
    claude_texts = [t.text for t in session.transcript if t.role == "claude"]
    if claude_texts:
        if verbose:
            print(f"[CLAUDE_SESSION] Analyzing conversation and extracting insights...")

        # Store facts - this calls summarize_and_extract internally
        facts_stored = _store_session_facts(session)
        session.facts_stored = facts_stored
        result["facts_stored"] = facts_stored
        result["summary"] = session.summary

    # Generate recap
    result["recap"] = _generate_recap(session)

    if verbose:
        print(f"\n{'='*60}")
        print(f"[CLAUDE_SESSION] Session {session.status}")
        print(f"[CLAUDE_SESSION] Turns: {session.turn_index}, Facts stored: {session.facts_stored}")
        print(f"{'='*60}\n")

    return result


def _generate_summary(responses: List[str], topic: str) -> str:
    """Generate a summary of the conversation."""
    combined = "\n\n".join(responses)
    if len(combined) > 2000:
        combined = combined[:2000] + "..."
    return f"Claude conversation about {topic}:\n\n{combined}"


def summarize_and_extract(session: SessionState) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Summarize the conversation and extract structured facts/insights.

    Uses Teacher to analyze the conversation and extract:
    - Summary text
    - List of facts with type classification (FACTUAL, SPECULATIVE, OPINION)

    Returns:
        Tuple of (summary_text, list_of_facts)
    """
    if not _teacher_helper:
        return _fallback_summarize(session)

    # Build transcript text
    transcript_text = "\n\n".join([
        f"{'MAVEN' if t.role == 'maven' else 'CLAUDE'}: {t.text}"
        for t in session.transcript
    ])

    prompt = f"""Analyze this conversation between Maven (an AI) and Claude about "{session.topic}".

CONVERSATION:
{transcript_text}

Please provide:

1. SUMMARY (2-3 paragraphs):
A high-level summary of the main themes and conclusions from this discussion.

2. KEY INSIGHTS (5-15 bullet points):
Extract specific facts, insights, or interesting observations from this conversation.
For each fact, indicate if it's:
- FACTUAL (verified/objective information)
- SPECULATIVE (hypotheses or theories discussed)
- OPINION (subjective views expressed)

Format each insight as:
- [TYPE] The insight text here

3. DOMAIN CLASSIFICATION:
Which knowledge domain(s) does this conversation belong to?
Choose from: technology, science, math, history, geography, arts, philosophy, economics, law, language_arts, personal, procedural, creative

Begin your analysis:"""

    try:
        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={
                "topic": session.topic,
                "mode": "claude_session_summary",
                "turn_count": len(session.transcript),
            }
        )

        if result and result.get("answer"):
            analysis = str(result.get("answer", "")).strip()

            # Parse out facts from the analysis
            facts = _extract_facts_from_analysis(analysis, session.topic)

            return analysis, facts

    except Exception as e:
        print(f"[CLAUDE_SESSION] Error summarizing: {e}")

    return _fallback_summarize(session)


def _fallback_summarize(session: SessionState) -> Tuple[str, List[Dict[str, Any]]]:
    """Fallback summary when Teacher is unavailable."""
    claude_turns = [t for t in session.transcript if t.role == "claude"]

    # Extract key sentences as facts
    facts = []
    for turn in claude_turns:
        # Split into sentences and take the first 2-3 meaningful ones
        sentences = re.split(r'[.!?]\s+', turn.text)
        for sent in sentences[:3]:
            sent = sent.strip()
            if len(sent) > 20:  # Skip very short fragments
                facts.append({
                    "content": sent,
                    "type": "FACTUAL",
                    "source": "claude_session",
                    "topic": session.topic,
                    "confidence": 0.6,
                })

    combined = "\n".join([t.text[:200] for t in claude_turns[:5]])
    summary = f"Claude session about {session.topic}:\n{combined}"

    return summary, facts[:10]  # Cap at 10 facts


def _extract_facts_from_analysis(analysis: str, topic: str) -> List[Dict[str, Any]]:
    """Extract structured facts from the summary analysis."""
    facts = []

    # Look for patterns like "- [TYPE] fact text"
    pattern = r"-\s*\[?(FACTUAL|SPECULATIVE|OPINION)\]?\s*(.+?)(?=\n-|\n\n|$)"
    matches = re.findall(pattern, analysis, re.IGNORECASE | re.MULTILINE)

    confidence_map = {
        "FACTUAL": 0.75,
        "SPECULATIVE": 0.5,
        "OPINION": 0.35,
    }

    # Extract domain from analysis
    domain = _extract_domain(analysis)

    for fact_type, fact_text in matches:
        fact_type = fact_type.upper()
        confidence = confidence_map.get(fact_type, 0.5)

        facts.append({
            "content": fact_text.strip(),
            "type": fact_type,
            "source": "claude_session",
            "topic": topic,
            "confidence": confidence,
            "domain": domain,
        })

    return facts


def _extract_domain(analysis: str) -> str:
    """Extract domain classification from analysis text."""
    domain_keywords = {
        "technology": ["technology", "programming", "software", "code", "python", "computer"],
        "science": ["science", "physics", "chemistry", "biology", "research"],
        "math": ["math", "mathematics", "algebra", "calculus", "statistics"],
        "history": ["history", "historical", "ancient", "medieval", "century"],
        "geography": ["geography", "countries", "cities", "climate", "terrain"],
        "arts": ["art", "music", "painting", "literature", "culture"],
        "philosophy": ["philosophy", "ethics", "logic", "metaphysics"],
        "economics": ["economics", "economy", "finance", "market", "trade"],
        "law": ["law", "legal", "rights", "court", "legislation"],
        "language_arts": ["language", "grammar", "writing", "linguistics"],
        "personal": ["personal", "self", "identity", "preferences"],
        "procedural": ["how to", "steps", "process", "procedure", "guide"],
        "creative": ["creative", "imagination", "story", "fiction"],
    }

    analysis_lower = analysis.lower()
    for domain, keywords in domain_keywords.items():
        if any(kw in analysis_lower for kw in keywords):
            return domain

    return "factual"  # Default domain


def _store_session_facts(session: SessionState) -> int:
    """
    Store facts from the session with proper domain classification.
    Extracts individual insights and stores each with metadata.
    """
    # First, get the structured analysis with facts
    summary, facts = summarize_and_extract(session)
    session.summary = summary

    if not facts:
        print(f"[CLAUDE_SESSION] No facts extracted from session")
        return 0

    stored_count = 0

    # Determine if this is a self-referential topic
    is_self = is_self_topic(session.topic)

    for fact in facts:
        # Skip opinions (too subjective)
        if fact.get("type") == "OPINION":
            continue

        try:
            content = fact.get("content", "")
            fact_type = fact.get("type", "FACTUAL")
            confidence = float(fact.get("confidence", 0.6))
            domain = fact.get("domain", "factual")

            # Build metadata
            metadata = {
                "session_id": session.session_id,
                "origin": "claude_conversation",
                "fact_type": fact_type,
                "domain": domain,
                "topic": session.topic,
                "verified": False,  # Needs verification
                "is_self_referential": is_self,
                "source_model": "Claude",
            }

            # Store using research manager
            if _research_available:
                _store_fact_record(
                    content=content,
                    confidence=confidence,
                    source=f"claude_session_{session.session_id}",
                    topic=session.topic,
                    url=None,
                    metadata=metadata,
                )
                stored_count += 1

            # Also store to session memory for quick retrieval
            if _session_memory:
                _session_memory.store(
                    content=content,
                    metadata=metadata,
                )

        except Exception as e:
            print(f"[CLAUDE_SESSION] Failed to store fact: {e}")

    print(f"[CLAUDE_SESSION] Stored {stored_count} facts from session")
    return stored_count


def _generate_recap(session: SessionState) -> str:
    """Generate user-friendly recap of the session."""
    actual_duration = (time.time() - session.start_time) / 60
    exchanges = session.turn_index

    if session.status == "completed":
        summary_text = session.summary[:400] if session.summary else "No summary available."
        return f"""## Claude Session: {session.topic}

**Duration:** {actual_duration:.1f} minutes | **Exchanges:** {exchanges}

### Summary:
{summary_text}

**Stored:** {session.facts_stored} insights"""

    elif session.status == "error":
        return f"""## Claude Session: {session.topic}

**Status:** Error after {exchanges} exchanges

**Error:** {session.error_message}"""

    else:
        return f"""## Claude Session: {session.topic}

**Status:** {session.status}
**Exchanges:** {exchanges}"""


# ============================================================================
# Controller Class (for agency pattern integration)
# ============================================================================

class ClaudeConversationController:
    """Controller class for agency pattern integration."""

    def start_session(
        self,
        topic: str = "",
        duration_minutes: int = DEFAULT_DURATION_MINUTES,
        max_turns: int = DEFAULT_MAX_TURNS,
        **kwargs
    ) -> Dict[str, Any]:
        """Start a new conversation session."""
        if not topic:
            topic = kwargs.get("text", "") or kwargs.get("query", "")
            if topic:
                parsed = parse_conversation_command(topic)
                if parsed:
                    topic = parsed["topic"]
                    duration_minutes = parsed.get("duration_minutes", duration_minutes)

        return run_claude_conversation_session(
            topic=topic,
            duration_minutes=duration_minutes,
            max_turns=max_turns,
        )

    def parse_and_run(self, text: str = "", **kwargs) -> str:
        """Parse command and run session. Returns user-friendly recap string."""
        query = text or kwargs.get("query", "") or kwargs.get("text", "")

        parsed = parse_conversation_command(query)
        if not parsed:
            return f"Could not parse Claude conversation command: {query}"

        result = run_claude_conversation_session(
            topic=parsed["topic"],
            duration_minutes=parsed["duration_minutes"],
            max_turns=parsed.get("max_turns", DEFAULT_MAX_TURNS),
        )

        return result.get("recap", f"Session completed with status: {result.get('status')}")


_controller_instance = None


def get_claude_conversation_controller() -> ClaudeConversationController:
    """Get or create the singleton controller instance."""
    global _controller_instance
    if _controller_instance is None:
        _controller_instance = ClaudeConversationController()
    return _controller_instance
