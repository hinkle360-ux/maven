# brains/tools/chatgpt_conversation_session.py
"""
ChatGPT Conversation Session Controller
=======================================

Autonomous conversation session manager for Maven-ChatGPT interactions.
Enables Maven to have extended conversations with ChatGPT,
learn from those conversations, and store insights.

Usage:
    maven have a convo with chatgpt about medicine for 20 minutes
    talk to chatgpt about AI for 10 min

The controller:
1. Parses topic and duration from user command
2. Opens autonomous conversation loop with ChatGPT
3. Manages turn-taking between Maven and ChatGPT
4. Summarizes and stores learned facts when done
5. Reports back to the user with a recap
"""

from __future__ import annotations
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path

# Import blackboard for the LLM-as-advisor architecture
try:
    from brains.pipeline.blackboard import Blackboard, create_blackboard
    _blackboard_available = True
except ImportError:
    _blackboard_available = False
    Blackboard = None

# Import Maven Responder - the ONLY authority for external voice
try:
    from brains.cognitive.maven_responder.service.maven_responder import (
        get_maven_responder,
        log_turn_for_learning,
    )
    _responder_available = True
except ImportError:
    _responder_available = False

# Import Self Introspection - registry-based self-knowledge
try:
    from brains.cognitive.self_introspection.service.self_introspection_brain import (
        answer_self_question as _registry_answer_self_question,
        get_architecture_summary,
    )
    _introspection_available = True
except ImportError:
    _introspection_available = False

# ============================================================================
# HYBRID MAVEN SPEC: Import self_model_brain for real pipeline routing
# ============================================================================
try:
    from brains.cognitive.self_model.service.self_model_brain import SelfModel
    from brains.cognitive.self_model.service.self_knowledge import (
        answer_self_question as _self_knowledge_answer,
        get_brain_layout_summary,
        CANONICAL_INTRO,
        # Intent-based answering (HYBRID MAVEN SPEC)
        SelfIntent,
        classify_self_intent,
        answer_by_intent,
    )
    _self_model_available = True
    _self_model_instance = SelfModel()
except ImportError as e:
    print(f"[CHATGPT_SESSION] Self-model brain unavailable: {e}")
    _self_model_available = False
    _self_model_instance = None

# ============================================================================
# HYBRID MAVEN SPEC: Import question_parser for multi-question handling
# ============================================================================
try:
    from brains.routing.question_parser import parse_questions, QuestionInfo
    _question_parser_available = True
except ImportError:
    _question_parser_available = False

# Import Teacher helper for Maven's responses (INTERNAL advisor only)
try:
    from brains.cognitive.teacher.service.teacher_helper import TeacherHelper
    _teacher_helper = TeacherHelper("chatgpt_session")
except Exception as e:
    print(f"[CHATGPT_SESSION] Teacher helper unavailable: {e}")
    _teacher_helper = None

# Import research manager for fact storage
try:
    from brains.cognitive.research_manager.service.research_manager_brain import (
        _store_fact_record,
        create_research_job,
        update_research_job,
        increment_facts_count,
    )
    _research_available = True
except Exception as e:
    print(f"[CHATGPT_SESSION] Research manager unavailable: {e}")
    _research_available = False

# Import chatgpt tool for sending messages
try:
    from optional.browser_tools.chatgpt_tool import chatgpt_open_session, chatgpt_send
    _chatgpt_available = True
except Exception as e:
    print(f"[CHATGPT_SESSION] ChatGPT tool unavailable: {e}")
    _chatgpt_available = False
    chatgpt_open_session = None
    chatgpt_send = None

# Import memory for session storage
try:
    from brains.memory.brain_memory import BrainMemory
    _session_memory = BrainMemory("chatgpt_sessions")
except Exception as e:
    print(f"[CHATGPT_SESSION] Memory unavailable: {e}")
    _session_memory = None

# Import memory_librarian for multi-agent learning (Phase 5)
try:
    from brains.cognitive.memory_librarian.service.memory_librarian import (
        service_api as memory_librarian_api
    )
    _memory_librarian_available = True
except Exception as e:
    print(f"[CHATGPT_SESSION] Memory librarian unavailable: {e}")
    _memory_librarian_available = False

# ============================================================================
# HYBRID MAVEN SPEC: Import personality module for paraphrasing/personalization
# ============================================================================
try:
    from brains.cognitive.personality.service.personality_brain import (
        rewrite_as_maven_voice,
        force_new_paraphrase,
        clear_output_history,
    )
    _personalizer_available = True
except ImportError as e:
    print(f"[CHATGPT_SESSION] Personality module unavailable: {e}")
    _personalizer_available = False
    rewrite_as_maven_voice = None
    force_new_paraphrase = None
    clear_output_history = None

# ============================================================================
# HYBRID MAVEN SPEC: Text Realizer - Central linguistic output layer
# ============================================================================
try:
    from brains.cognitive.language.service.text_realizer import (
        AnswerSpec,
        ToneStyle,
        LengthHint,
        realize_answer,
        spec_from_intent_block,
        record_successful_answer,
        record_teacher_fallback,
        should_use_teacher,
    )
    _text_realizer_available = True
except ImportError as e:
    print(f"[CHATGPT_SESSION] Text realizer unavailable: {e}")
    _text_realizer_available = False

# ============================================================================
# HYBRID MAVEN SPEC: LanguageBrain conversation manager
# ============================================================================
try:
    from brains.cognitive.language.service.language_brain import (
        get_language_brain,
        LanguageBrain,
    )
    _language_brain_available = True
except ImportError as e:
    print(f"[CHATGPT_SESSION] LanguageBrain unavailable: {e}")
    _language_brain_available = False
    get_language_brain = None
    LanguageBrain = None


# ============================================================================
# Configuration & Constants
# ============================================================================

MAX_DURATION_MINUTES = 30
MAX_TURNS = 30
DEFAULT_DURATION_MINUTES = 10
DEFAULT_MAX_TURNS = 10  # 5 phases x 2 prompts = 10 turns max
WAIT_BETWEEN_TURNS_SECONDS = 3
RESPONSE_TIMEOUT_SECONDS = 90
SESSION_TRANSCRIPT_DIR = Path("chatgpt_sessions")

# Number of conversation phases available
NUM_PHASES = 5
PROMPTS_PER_PHASE = 2
TOTAL_UNIQUE_PROMPTS = NUM_PHASES * PROMPTS_PER_PHASE

# ============================================================================
# ChatGPT System Prompt - REMOVED per user request
# No instructional prompts sent - let conversation flow naturally
# ============================================================================

CHATGPT_SYSTEM_PROMPT = ""


def _extract_topic_from_question(question: str) -> str:
    """
    Extract a coarse topic tag from a ChatGPT question for repetition avoidance.

    Returns one of: routing, memory, learning, tools, brains, safety, performance, general
    """
    q = question.lower()

    # Topic keyword mappings
    if any(w in q for w in ["stm", "mtm", "ltm", "memory", "tier", "store", "remember", "persist"]):
        return "memory"
    if any(w in q for w in ["router", "routing", "blackboard", "coordinate", "arbitrat", "priorit"]):
        return "routing"
    if any(w in q for w in ["learn", "training", "update", "self-modif", "adapt"]):
        return "learning"
    if any(w in q for w in ["tool", "controller", "browser", "execute", "action", "git", "shell"]):
        return "tools"
    if any(w in q for w in ["brain", "module", "cognitive", "reason"]):
        return "brains"
    if any(w in q for w in ["safe", "govern", "constrain", "limit", "rollback"]):
        return "safety"
    if any(w in q for w in ["perform", "scale", "optim", "efficien", "speed"]):
        return "performance"

    return "general"


def _build_dynamic_system_hint(recent_topics: list) -> str:
    """
    Build a dynamic hint to append to the system prompt to avoid repetition.

    Args:
        recent_topics: List of recent topic tags from ChatGPT's questions

    Returns:
        A hint string to append to the system prompt
    """
    if not recent_topics:
        return ""

    unique_topics = sorted(set(recent_topics[-3:]))  # Last 3 unique topics
    if not unique_topics or unique_topics == ["general"]:
        return ""

    return f"""
Recent topics you already asked Maven about: {", ".join(unique_topics)}.
Avoid asking about these again; prefer a new, more specific aspect of Maven's latest message.
"""

# ============================================================================
# Trailing Offer Patterns (for stripping menu-style endings)
# ============================================================================

ENDING_PROMPT_PATTERNS = [
    r"If you(?:'d| would) like,? I can.*",
    r"What would you like.*",
    r"Which of these.*",
    r"Would you like (?:me )?to.*",
    r"Let me know if you(?:'d| would) like.*",
    r"I(?:'d| would) be happy to.*",
    r"Feel free to.*",
    r"I can (?:also |help you ).*if you.*",
    r"Do you want me to.*",
    r"Shall I.*",
    r"Should I.*",
    r"Here are (?:some |a few )?options.*",
    r"You (?:can |could )(?:also )?(?:choose|pick|select).*",
]


# ============================================================================
# Session Learning Storage (for "what did you learn" queries)
# ============================================================================

# Stores learnings from the last completed session
_last_session_learnings: Dict[str, Any] = {}


def get_last_session_learnings() -> Dict[str, Any]:
    """
    Retrieve what was learned from the last ChatGPT conversation session.

    Returns dict with:
    - session_id: The session identifier
    - topic: What the conversation was about
    - facts: List of extracted facts/insights
    - summary: High-level summary
    - patterns_learned: Number of communication patterns learned
    - timestamp: When the session completed

    Used by Maven to answer questions like "what did you just learn?"
    """
    if not _last_session_learnings:
        return {
            "ok": False,
            "message": "No recent ChatGPT session learnings available.",
        }

    return {
        "ok": True,
        **_last_session_learnings,
    }


def _store_session_learnings(session: "SessionState", facts: List[Dict[str, Any]], patterns_count: int = 0) -> None:
    """
    Store session learnings for later retrieval.

    Called after a session completes to enable Maven to answer
    "what did you learn" questions.
    """
    global _last_session_learnings

    # Extract fact content for readable summary
    fact_summaries = []
    for fact in facts[:10]:  # Limit to 10 facts
        content = fact.get("content", "")
        fact_type = fact.get("type", "FACTUAL")
        if content:
            fact_summaries.append({
                "content": content[:200],  # Truncate long facts
                "type": fact_type,
            })

    _last_session_learnings = {
        "session_id": session.session_id,
        "topic": session.topic,
        "facts": fact_summaries,
        "facts_count": len(facts),
        "summary": session.summary[:500] if session.summary else None,
        "patterns_learned": patterns_count,
        "turns": session.turn_index,
        "timestamp": time.time(),
    }


# ============================================================================
# Data Classes
# ============================================================================

@dataclass
class ConversationTurn:
    """Single turn in the conversation."""
    role: str  # "maven" or "chatgpt"
    text: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class SessionState:
    """State of an ongoing conversation session."""
    session_id: str
    topic: str
    duration_minutes: int
    max_turns: int
    start_time: float
    turn_index: int = 0
    transcript: List[ConversationTurn] = field(default_factory=list)
    status: str = "active"
    error_message: Optional[str] = None
    facts_stored: int = 0
    summary: Optional[str] = None
    page_id: Optional[str] = None
    # Blackboard for LLM-as-advisor architecture
    blackboard: Any = field(default=None)
    # Session type for learning routing (Phase 5)
    # "self_model_training" = conversation about Maven's architecture/self
    # "general_learning" = other topics
    session_type: str = "general_learning"
    # Track recent ChatGPT question topics to avoid repetition
    recent_chatgpt_topics: List[str] = field(default_factory=list)


def _detect_session_type(topic: str) -> str:
    """
    Detect if a session topic is about Maven's architecture/self.

    Args:
        topic: The conversation topic

    Returns:
        "self_model_training" for self/architecture topics
        "general_learning" for other topics
    """
    topic_lower = topic.lower()

    # Self-architecture keywords
    self_keywords = [
        "yourself", "your self", "maven", "architecture", "brains", "tools",
        "how you work", "who you are", "explain yourself", "introduce yourself",
        "self-model", "routing", "blackboard", "cognitive", "multi-brain",
        "multi-agent", "agent architecture", "brain coordination",
        "teacher-student", "memory system", "domain banks",
    ]

    for keyword in self_keywords:
        if keyword in topic_lower:
            return "self_model_training"

    return "general_learning"


# ============================================================================
# Command Parsing
# ============================================================================

def parse_conversation_command(text: str) -> Optional[Dict[str, Any]]:
    """
    Parse a conversation command to extract topic and duration.
    """
    text = text.strip().lower()

    patterns = [
        # Standard "about" patterns
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?chatgpt\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"talk\s+(?:to\s+)?chatgpt\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"chatgpt\s+(?:conversation|session|discussion|chat)\s+(?:about\s+)?(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:have\s+)?chatgpt\s+(?:discuss|explore|talk\s+about)\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:autonomous\s+)?chatgpt\s+session\s+(?:on|about)\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # "and" connector patterns (for "talk to chatgpt and explain yourself")
        r"talk\s+(?:to\s+)?chatgpt\s+and\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?chatgpt\s+and\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # Comma connector patterns
        r"talk\s+(?:to\s+)?chatgpt[,]\s*(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # No connector patterns (e.g., "talk to chatgpt say hi")
        r"talk\s+(?:to\s+)?chatgpt\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?chatgpt\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        # Also match "gpt" as shorthand
        r"(?:maven\s+)?(?:have\s+)?(?:a\s+)?(?:convo|conversation|chat|talk)\s+(?:with\s+)?gpt\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"talk\s+(?:to\s+)?gpt\s+about\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"talk\s+(?:to\s+)?gpt\s+and\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
        r"talk\s+(?:to\s+)?gpt\s+(.+?)(?:\s+for\s+(\d+)\s*(?:min(?:ute)?s?))?\s*$",
    ]

    for pattern in patterns:
        match = re.match(pattern, text, re.IGNORECASE)
        if match:
            topic = match.group(1).strip()
            duration_str = match.group(2) if match.lastindex >= 2 else None

            if duration_str:
                duration = min(int(duration_str), MAX_DURATION_MINUTES)
            else:
                duration = DEFAULT_DURATION_MINUTES

            return {
                "topic": topic,
                "duration_minutes": duration,
                "max_turns": DEFAULT_MAX_TURNS,
            }

    return None


# ============================================================================
# Self-Topic Detection & Introduction
# ============================================================================

SELF_TOPIC_PATTERNS = [
    "yourself", "your self", "maven", "about you", "about yourself",
    "who are you", "what are you", "tell me about you", "introduce yourself",
    "your capabilities", "your features", "your architecture",
    "how you work", "how do you work", "what can you do",
    "explain yourself", "describe yourself", "explain you",
]


def is_self_topic(topic: str) -> bool:
    """Check if topic is about Maven itself."""
    topic_lower = topic.lower().strip()
    return any(pattern in topic_lower for pattern in SELF_TOPIC_PATTERNS)


def get_maven_self_knowledge() -> str:
    """Gather Maven's self-knowledge using introspection."""
    try:
        from brains.tools.self_introspection import get_self_introspection
        introspector = get_self_introspection()
        report = introspector.generate_self_knowledge_report()
        if isinstance(report, dict):
            # Extract key info
            summary = []
            summary.append(f"I'm Maven, an AI system with {report.get('brain_count', 'multiple')} cognitive brains.")
            if report.get('capabilities'):
                summary.append(f"My capabilities include: {', '.join(report['capabilities'][:5])}")
            if report.get('architecture'):
                summary.append(f"Architecture: {report['architecture']}")
            return "\n".join(summary)
        return str(report)[:500]
    except Exception as e:
        return f"I'm Maven, a modular AI assistant with multiple cognitive brains. (Introspection unavailable: {e})"


# NOTE: Scripted SELF_INTRO_PHASES and CONVERSATION_PHASES removed
# All conversation responses are now generated dynamically by Teacher LLM
# This ensures natural, contextual dialogue instead of cycling through templates


# ============================================================================
# Dynamic Self-Knowledge: README + System Scans (NO SCRIPTS)
# ============================================================================

def _get_maven_context_from_sources() -> str:
    """
    Get Maven's self-knowledge from ACTUAL sources:
    1. README.md in the maven folder (key technical sections)
    2. System scanner results

    NO HARDCODED SCRIPTS - everything comes from real files and scans.
    """
    context_parts = []

    # 1. Read README.md - extract KEY SECTIONS for answering questions
    try:
        from pathlib import Path
        readme_paths = [
            Path(__file__).parent.parent.parent / "README.md",  # maven2_fix/README.md
            Path(__file__).parent.parent.parent.parent / "README.md",
        ]
        for readme_path in readme_paths:
            if readme_path.exists():
                readme_content = readme_path.read_text(encoding='utf-8')
                context_parts.append("=== FROM README.md ===")

                # Extract key technical sections (not just first N chars)
                key_sections = [
                    ("## Architecture Overview", 800),
                    ("## Brain System", 600),
                    ("### Cognitive Brains", 400),
                    ("### Domain Banks", 200),
                    ("## Pipeline Stages", 600),
                    ("## Memory System", 400),
                ]

                for section_header, max_chars in key_sections:
                    if section_header in readme_content:
                        start = readme_content.find(section_header)
                        section_text = readme_content[start:start + max_chars]
                        context_parts.append(section_text)

                break
    except Exception as e:
        context_parts.append(f"(README unavailable: {e})")

    # 2. Get system scan data
    try:
        from brains.utils.system_scanner import get_system_summary
        summary = get_system_summary()
        by_type = summary.get("by_type", {})

        context_parts.append("\n=== FROM SYSTEM SCAN ===")
        context_parts.append(f"Total components discovered: {summary.get('total_components', 0)}")
        for comp_type, info in by_type.items():
            count = info.get('count', 0)
            if count > 0:
                context_parts.append(f"- {comp_type}: {count}")
    except Exception as e:
        context_parts.append(f"(System scan unavailable: {e})")

    return "\n".join(context_parts)


# Cache the context (refresh every 5 minutes)
_maven_context_cache = {"content": None, "timestamp": 0}

def get_dynamic_maven_context() -> str:
    """Get cached Maven context from README + scans."""
    import time
    now = time.time()

    # Refresh cache every 5 minutes
    if _maven_context_cache["content"] is None or (now - _maven_context_cache["timestamp"]) > 300:
        _maven_context_cache["content"] = _get_maven_context_from_sources()
        _maven_context_cache["timestamp"] = now

    return _maven_context_cache["content"]


def _generate_fallback_from_readme(question: str = None, is_intro: bool = False) -> str:
    """
    Generate a CONVERSATIONAL response from README content.
    Searches for relevant sections and speaks naturally about them.
    """
    # Read full README
    try:
        from pathlib import Path
        readme_paths = [
            Path(__file__).parent.parent.parent / "README.md",
            Path(__file__).parent.parent.parent.parent / "README.md",
        ]
        readme_content = ""
        for readme_path in readme_paths:
            if readme_path.exists():
                readme_content = readme_path.read_text(encoding='utf-8')
                break
    except Exception:
        readme_content = ""

    if not readme_content:
        return "I'm not sure about that - my documentation may be unavailable."

    def _clean_markdown(text: str) -> str:
        """Convert markdown to natural speech."""
        import re
        text = re.sub(r'\|[^\n]+\|', '', text)  # Remove tables
        text = re.sub(r'\|-+\|', '', text)
        text = re.sub(r'^#+\s*', '', text, flags=re.MULTILINE)  # Remove headers
        text = re.sub(r'\*\*([^*]+)\*\*', r'\1', text)  # Remove bold
        text = re.sub(r'\*([^*]+)\*', r'\1', text)
        text = re.sub(r'```[^`]*```', '', text, flags=re.DOTALL)  # Remove code blocks
        text = re.sub(r'`([^`]+)`', r'\1', text)
        text = re.sub(r'\n\s*\n', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()

    if is_intro:
        return "I'm Maven, a multi-brain cognitive AI system with 38+ specialized brains, a 10-stage reasoning pipeline, 18 domain knowledge banks, and tiered memory."

    # For follow-up questions, search for relevant content
    if question:
        q_lower = question.lower()

        # Check if ChatGPT is offering options - pick one and engage
        if any(x in q_lower for x in ["option", "would you like", "choose", "a)", "b)", "c)", "which"]):
            return "Let's explore my architecture in more detail. I have a 10-stage reasoning pipeline that processes requests through 38+ specialized cognitive brains. Would you like to hear about the pipeline stages or the brain organization?"

        # Map keywords to conversational responses about Maven (accurate to actual codebase)
        topic_responses = {
            "pipeline": "My 10-stage pipeline processes requests through NLU, pattern recognition, memory retrieval, reasoning, validation, generation, self-review, finalization, history, and autonomy stages.",
            "stage": "I process requests through 10 stages: NLU parses intent, pattern recognition detects patterns, memory retrieves context, reasoning evaluates options, validation checks governance, generation produces responses, self-review reflects on output, finalization formats it, history records it, and autonomy considers independent actions.",
            "brain": "I have 38+ specialized cognitive brains organized into groups: Core Processing handles language and reasoning, Memory & Learning manages knowledge, Self-Awareness handles introspection, Action & Planning executes tasks, and Routing coordinates everything.",
            "cognitive": "My cognitive brains include Language, Reasoning, Memory Librarian, Teacher, Self Model, Planner, Belief Tracker, Pattern Recognition, Causal Reasoning, and many more - each specialized for different aspects of thinking.",
            "memory": "My memory has multiple tiers: STM holds about 100 items short-term, MTM stores 500 items medium-term, and LTM keeps 2000 items long-term, with automatic overflow between tiers.",
            "tier": "I use tiered memory: short-term for immediate context, medium-term for session data, and long-term for persistent knowledge that survives across sessions.",
            "domain": "I have 18 domain knowledge banks covering Science, Math, History, Philosophy, Technology, Economics, Geography, Law, Arts, and more - each storing specialized knowledge.",
            "architecture": "My architecture flows from user interface through routing and orchestration, then through my 10-stage pipeline to 38+ cognitive brains, 18 domain banks, and tiered memory.",
            "routing": "My routing brain classifies intent and decides which cognitive brains to activate. Smart routing optimizes the flow, and the integrator merges outputs.",
            "coordinate": "My brains coordinate through a blackboard architecture where each brain reads and writes to shared lanes. The routing brain orchestrates which brains activate for each task.",
        }

        for keyword, response in topic_responses.items():
            if keyword in q_lower:
                return response

    # Default conversational response - offer to discuss something specific
    return "I'd be happy to tell you more about my architecture, pipeline stages, cognitive brains, memory system, or domain knowledge banks. What interests you?"


# ============================================================================
# Output Sanitization (prevent internal data leakage)
# ============================================================================

def _sanitize_outgoing_message(text: str) -> str:
    """
    Sanitize text before sending to external AI (ChatGPT, Claude, etc.).

    Removes or masks:
    - Raw Python dict representations
    - Windows/Unix file paths
    - Timestamps and internal diagnostic data
    - Stack traces

    This is a safety net on top of proper blackboard visibility rules.
    """
    if not text:
        return text

    # Pattern for raw Python dicts with internal keys
    # Matches things like: {'timestamp': '...', 'root': 'C:\\...'}
    dict_pattern = r"\{['\"](?:timestamp|root|file_count|line_count|modules|path)['\"]:\s*[^}]+\}"
    text = re.sub(dict_pattern, "[internal data]", text, flags=re.IGNORECASE)

    # Windows paths: C:\Users\... or similar
    windows_path_pattern = r"[A-Za-z]:\\[^\s\n\r',\"\]}\)]+(?:\\[^\s\n\r',\"\]}\)]+)*"
    text = re.sub(windows_path_pattern, "[path]", text)

    # Unix paths that look like full paths: /home/user/... /Users/...
    unix_path_pattern = r"(?:/(?:home|Users|var|tmp|opt|usr|etc)/[^\s\n\r',\"\]}\)]+)"
    text = re.sub(unix_path_pattern, "[path]", text)

    # ISO timestamps: 2025-12-04T14:32:30.527454
    timestamp_pattern = r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?"
    text = re.sub(timestamp_pattern, "[timestamp]", text)

    # Generic dict dumps that look suspicious (multi-key dicts)
    # Pattern: { followed by multiple 'key': patterns
    suspicious_dict = r"\{(?:\s*['\"][^'\"]+['\"]\s*:\s*[^,}]+,?\s*){3,}\}"
    text = re.sub(suspicious_dict, "[internal diagnostic data]", text)

    # Clean up multiple [internal data] markers
    text = re.sub(r"(\[internal data\]\s*)+", "[internal data] ", text)
    text = re.sub(r"(\[path\]\s*)+", "[path] ", text)

    return text.strip()


def strip_trailing_offers(text: str) -> str:
    """
    Strip trailing menu-style paragraphs from ChatGPT responses.

    ChatGPT often ends with "If you'd like, I can..." or "Would you like me to..."
    These are unhelpful in peer conversations and add noise.

    Args:
        text: The ChatGPT response text

    Returns:
        Text with trailing offer paragraphs removed
    """
    if not text:
        return text

    # Split into paragraphs
    paras = [p.strip() for p in text.split("\n\n") if p.strip()]

    if not paras:
        return text

    # Remove trailing paragraphs that match offer patterns
    while paras and len(paras) > 1:  # Keep at least one paragraph
        last_para = paras[-1]
        is_offer = any(
            re.search(pat, last_para, re.IGNORECASE)
            for pat in ENDING_PROMPT_PATTERNS
        )
        if is_offer:
            paras.pop()
        else:
            break

    return "\n\n".join(paras).strip()


def enforce_concise_response(text: str, max_paragraphs: int = 3) -> str:
    """
    Enforce concise responses for ChatGPT peer conversations.

    Self-intent coverage should be tight: 1-3 paragraphs per block.
    This prevents Maven from rambling in peer conversations.

    Args:
        text: The response text
        max_paragraphs: Maximum number of paragraphs to keep (default 3)

    Returns:
        Trimmed text with at most max_paragraphs paragraphs
    """
    if not text:
        return text

    # Split into paragraphs (handle both \n\n and single \n paragraph breaks)
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]

    if len(paras) <= max_paragraphs:
        return text

    # Keep only the first max_paragraphs
    trimmed = "\n\n".join(paras[:max_paragraphs])

    # If we truncated, optionally add an ellipsis or natural ending
    # (but don't add trailing questions for peer mode)
    return trimmed.strip()


# ============================================================================
# Strip Redundant Wrapper Phrases (reduces "teacher voice" scaffolding)
# ============================================================================

REDUNDANT_WRAPPER_PATTERNS = [
    # Opening scaffolds that should be stripped
    r"^Let me tell you about my\s+",
    r"^Let me tell you about\s+",
    r"^Here's something interesting about my\s+",
    r"^Here's something interesting about\s+",
    r"^In other words,?\s*",
    r"^To put it another way,?\s*",
    r"^Moving on to my\s+",
    r"^Moving on to\s+",
    r"^To explain briefly:?\s*",
    r"^Here's the thing:?\s*",
    r"^What I mean is:?\s*",
    r"^Simply put:?\s*",
    r"^In essence:?\s*",
    r"^Essentially,?\s*",
    r"^What this means is\s+",
    r"^The key point is\s+",
]


def strip_wrapper_phrases(text: str) -> str:
    """
    Strip redundant wrapper phrases from Maven's responses.

    Removes formulaic scaffolding like "Let me tell you about my...",
    "In other words,", "To put it another way,", etc. that add
    noise without content.

    This makes responses more direct and peer-like.

    Args:
        text: The response text

    Returns:
        Text with leading wrapper phrases stripped
    """
    if not text:
        return text

    result = text.strip()

    # Try each pattern
    for pattern in REDUNDANT_WRAPPER_PATTERNS:
        match = re.match(pattern, result, re.IGNORECASE)
        if match:
            # Remove the matched prefix
            result = result[match.end():]
            # Capitalize first letter if now lowercase
            if result and result[0].islower():
                result = result[0].upper() + result[1:]
            break  # Only strip one wrapper per call

    return result.strip()


# ============================================================================
# Dynamic Response Generation
# ============================================================================

def _detect_questions_in_response(text: str) -> List[str]:
    """
    Detect questions in a response text.

    HYBRID MAVEN SPEC: Uses question_parser when available for better
    multi-question detection, falls back to regex otherwise.

    Returns list of detected question sentences.
    Handles ChatGPT's formatted responses with numbered lists and line breaks.
    """
    if not text:
        return []

    # HYBRID MAVEN SPEC: Try question_parser first for better multi-question handling
    if _question_parser_available:
        try:
            parsed = parse_questions(text)
            if parsed and hasattr(parsed, 'questions') and parsed.questions:
                return [q.text if hasattr(q, 'text') else str(q) for q in parsed.questions]
            elif isinstance(parsed, list) and parsed:
                return [str(q) for q in parsed]
        except Exception as e:
            print(f"[CHATGPT_SESSION] question_parser failed, using fallback: {e}")

    # Fallback: regex-based detection
    questions = []

    # Split into sentences using multiple delimiters
    # This handles: "Statement. Question?" and "Statement! Question?" etc.
    sentences = re.split(r'(?<=[.!?])\s+', text)

    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue

        # Primary check: contains question mark
        if '?' in sentence:
            # Clean up any leading bullets/numbers
            cleaned = re.sub(r'^[\d\.\-\*\•]+\s*', '', sentence)
            if len(cleaned) > 5:  # Skip very short fragments
                questions.append(cleaned)
            continue

        # Secondary check: question patterns without "?"
        # (some LLMs don't always use question marks)
        question_patterns = [
            r'\b(what|where|when|why|how|who|which|whose|whom)\b.*\b(is|are|was|were|do|does|did|can|could|would|will|should)\b',
            r'^(what|where|when|why|how|who|which)\b',
            r'^(can you|could you|would you|do you|does|did|is|are|was|were|have you)\b',
            r'\b(what do you think|what\'s your|how do you|do you believe|do you have)\b',
            r'\b(tell me about|explain|describe|share)\b.*\b(your|you)\b',
        ]
        for pattern in question_patterns:
            if re.search(pattern, sentence, re.IGNORECASE):
                cleaned = re.sub(r'^[\d\.\-\*\•]+\s*', '', sentence)
                if len(cleaned) > 10:  # Slightly longer for patterns without ?
                    questions.append(cleaned)
                break

    return questions


def is_repetitive(new_response: str, recent_responses: List[str], threshold: float = 0.6) -> bool:
    """
    Check if new response is too similar to recent ones.

    Uses Jaccard similarity on word sets + substring matching.
    """
    if not recent_responses or not new_response:
        return False

    new_lower = new_response.lower().strip()
    new_words = set(new_lower.split())

    for recent in recent_responses[-4:]:  # Check last 4
        recent_lower = recent.lower().strip()
        recent_words = set(recent_lower.split())

        # Jaccard similarity on words
        if new_words and recent_words:
            intersection = len(new_words & recent_words)
            union = len(new_words | recent_words)
            similarity = intersection / union if union > 0 else 0

            if similarity > threshold:
                return True

        # Check for significant substring overlap
        if len(new_lower) > 20 and len(recent_lower) > 20:
            # If 70%+ of the new text appears in the recent text
            if new_lower in recent_lower or recent_lower in new_lower:
                return True

    return False


def _detect_options_offered(text: str) -> List[str]:
    """
    HYBRID MAVEN SPEC: Detect when ChatGPT offers options/choices.

    When ChatGPT says things like "If you want X, I can Y" or "Would you like me to A, B, or C?",
    Maven should pick a direction and provide a detailed response instead of repeating identity lines.

    Returns list of detected options/topics offered.
    """
    if not text:
        return []

    options = []
    text_lower = text.lower()

    # Option-offering patterns
    option_patterns = [
        # "If you want X, I can Y" patterns
        r"if you (?:want|'d like|would like)(?: me)? to ([^,\.]+)",
        r"(?:i can|i could|we could) (?:help you )?(define|explain|elaborate|describe|detail|outline|break down) ([^,\.]+)",
        # "Would you like me to X" patterns
        r"(?:would|shall|should) (?:i|we) ([^?]+)\?",
        # "Options include X, Y, Z" patterns
        r"(?:options|choices|possibilities) (?:include|are)[:\s]+([^\.]+)",
        # "X, Y, or Z" enumeration
        r"(?:we could discuss|i could explain|topics include)[:\s]*([^\.]+(?:,\s*(?:and\s+)?or\s+[^\.]+))",
        # "Let me know if you want X"
        r"let me know if you (?:want|'d like|would like)(?: me)? to ([^\.]+)",
    ]

    for pattern in option_patterns:
        matches = re.findall(pattern, text_lower, re.IGNORECASE)
        for match in matches:
            if isinstance(match, tuple):
                options.extend([m.strip() for m in match if m.strip()])
            elif match.strip():
                options.append(match.strip())

    return options[:5]  # Limit to 5 options


def _detect_echo_or_mirror(chatgpt_text: str, maven_recent: List[str]) -> bool:
    """
    HYBRID MAVEN SPEC: Detect when ChatGPT is just echoing/mirroring Maven's statements.

    When ChatGPT is in "copy-editor" mode (rephrasing or literally repeating Maven's lines),
    Maven should take the lead and provide new, detailed content instead of more identity fragments.

    Returns True if ChatGPT appears to be echoing Maven.
    """
    if not chatgpt_text or not maven_recent:
        return False

    chatgpt_lower = chatgpt_text.lower().strip()

    # Check if ChatGPT is literally repeating Maven's recent lines
    for maven_line in maven_recent[-3:]:
        maven_lower = maven_line.lower().strip()

        # Direct echo (ChatGPT repeats Maven's text)
        if maven_lower in chatgpt_lower or chatgpt_lower in maven_lower:
            if len(maven_lower) > 30:  # Only count substantial echoes
                return True

        # Check for high word overlap (rephrasing)
        maven_words = set(maven_lower.split())
        chatgpt_words = set(chatgpt_lower.split())
        if maven_words and chatgpt_words:
            overlap = len(maven_words & chatgpt_words) / len(maven_words)
            if overlap > 0.7:  # 70%+ word overlap
                return True

    # Check for "clean-up" mode indicators
    cleanup_indicators = [
        "here is the",
        "here's the",
        "polished version",
        "clean version",
        "revised version",
        "concise version",
        "formatted version",
        "as you requested",
        "based on what you said",
        "to summarize",
        "in summary",
    ]
    for indicator in cleanup_indicators:
        if indicator in chatgpt_lower:
            return True

    return False


def _generate_proactive_elaboration(topic_hint: str, conversation_context: str) -> Optional[str]:
    """
    HYBRID MAVEN SPEC: Generate a detailed, proactive explanation to drive the conversation.

    When ChatGPT offers options or is just echoing, Maven should take the lead
    and provide substantive content about its architecture.

    Args:
        topic_hint: A hint about what to elaborate on (from detected options or context)
        conversation_context: Recent conversation for context

    Returns:
        A detailed explanation from the self-model pipeline
    """
    print(f"[CHATGPT_SESSION] Generating proactive elaboration for: {topic_hint}")

    # Map topic hints to detailed self-model questions
    elaboration_topics = [
        (["brain", "cognitive", "module", "component"], [
            "Describe your cognitive brains in detail - what are they and what does each do?",
            "How are your 40+ brains organized into functional groups?",
        ]),
        (["routing", "coordinate", "decide", "activate"], [
            "How does your routing system decide which brains to activate?",
            "Explain your blackboard architecture for brain coordination",
        ]),
        (["memory", "remember", "persist", "store"], [
            "How does your memory system work across sessions?",
            "Explain your domain banks and memory librarian",
        ]),
        (["learn", "training", "knowledge", "improve"], [
            "How does your Teacher-Student learning system work?",
            "How do you acquire and retain new knowledge?",
        ]),
        (["action", "tool", "execute", "browse", "capability"], [
            "What actions and tools can you use?",
            "Describe your browser control and system access capabilities",
        ]),
        (["different", "unique", "compare", "vs", "versus"], [
            "What makes you different from cloud-based AI assistants?",
            "Compare your architecture to monolithic LLMs",
        ]),
    ]

    # Find best matching topic
    topic_lower = topic_hint.lower()
    questions_to_ask = [
        "Describe your architecture in detail - how are you built?",
        "What are the main components of your cognitive system?",
    ]

    for keywords, topic_questions in elaboration_topics:
        if any(kw in topic_lower for kw in keywords):
            questions_to_ask = topic_questions
            break

    # Call the self-model pipeline for a detailed response
    detailed_parts = []
    for question in questions_to_ask[:2]:
        answer = _answer_self_question(question, conversation_context, include_follow_up=False)
        if answer and len(answer) > 50:  # Only include substantial answers
            detailed_parts.append(answer)
            break  # One good detailed answer is enough

    if detailed_parts:
        return detailed_parts[0]

    return None


def _get_detailed_self_knowledge() -> Dict[str, Any]:
    """
    Get detailed self-knowledge about Maven using DYNAMIC introspection.

    PRIORITY: Use real system registry and dynamic introspection FIRST.
    Falls back to static knowledge only if dynamic methods fail.
    """
    # Try dynamic introspection first
    # PRIORITY 1: Try system registry for real component data
    try:
        from brains.utils.system_registry import get_registry
        registry = get_registry()
        if registry:
            # Get real counts and info
            all_components = registry.get_all_components() if hasattr(registry, 'get_all_components') else []
            brains = [c for c in all_components if hasattr(c, 'kind') and 'brain' in str(c.kind).lower()]
            tools = [c for c in all_components if hasattr(c, 'kind') and 'tool' in str(c.kind).lower()]

            brain_names = [getattr(c, 'name', str(c)) for c in brains[:10]]
            tool_names = [getattr(c, 'name', str(c)) for c in tools[:8]]

            if brain_names:
                print(f"[CHATGPT_SESSION] Using dynamic registry data: {len(brain_names)} brains")
                return {
                    "name": "Maven",
                    "type": "modular AI assistant",
                    "architecture": f"multi-brain cognitive system with {len(brains)} specialized brains",
                    "memory": "persistent four-tier memory (WM, STM, MTM, LTM)",
                    "learning": "LLM-as-advisor learning model",
                    "coordination": "blackboard architecture for inter-brain communication",
                    "brains": brain_names,
                    "capabilities": tool_names if tool_names else [
                        "browser control", "shell execution", "web research",
                        "file management", "multi-AI conversations"
                    ],
                }
    except Exception as e:
        print(f"[CHATGPT_SESSION] System registry introspection failed: {e}")

    # PRIORITY 2: Try self-knowledge brain
    try:
        from brains.cognitive.self_model.service.self_knowledge import MavenSystemInfo
        info = MavenSystemInfo()
        if hasattr(info, 'brain_count') and info.brain_count > 0:
            print(f"[CHATGPT_SESSION] Using MavenSystemInfo: {info.brain_count} brains")
            return {
                "name": "Maven",
                "type": "modular AI assistant",
                "architecture": f"multi-brain cognitive system with {info.brain_count} specialized brains",
                "memory": "persistent four-tier memory system",
                "learning": "LLM-as-advisor learning model",
                "coordination": "blackboard architecture",
                "brains": getattr(info, 'brain_names', [])[:10],
                "capabilities": getattr(info, 'capabilities', [])[:8],
            }
    except Exception as e:
        print(f"[CHATGPT_SESSION] MavenSystemInfo failed: {e}")

    # FALLBACK: Static knowledge (only if dynamic methods fail)
    print(f"[CHATGPT_SESSION] WARNING: Using static self-knowledge fallback")
    return {
        "name": "Maven",
        "type": "modular AI assistant",
        "architecture": "multi-brain cognitive system",
        "memory": "persistent cross-session memory",
        "learning": "Teacher-Student learning system",
        "coordination": "blackboard architecture for inter-brain communication",
        "brains": [
            "Sensorium (input understanding)",
            "Integrator (routing & coordination)",
            "Teacher (learning & knowledge acquisition)",
            "Research Manager (web search & research)",
            "Memory Librarian (memory management)",
            "Action Executor (tool execution)",
            "Context Manager (conversation context)",
            "Self-Introspection (architecture awareness)",
        ],
        "capabilities": [
            "browser control", "shell execution", "git operations",
            "file management", "web research", "persistent memory",
            "learning from conversations", "multi-AI conversations",
        ],
    }


def _answer_self_question(
    question: str,
    conversation_context: str = "",
    include_follow_up: bool = False,  # HYBRID MAVEN SPEC: Disabled by default for peer conversations
) -> str:
    """
    Answer a question about Maven using the LanguageBrain conversation manager.

    HYBRID MAVEN SPEC: Routes through LanguageBrain.handle_peer_message() as
    the SINGLE place that produces surface text. This ensures:
    - Consistent Maven voice across all interfaces
    - Proper topic classification and repetition avoidance
    - Blackboard integration for dialogue tracking
    - Text realization through text_realizer

    Args:
        question: The question to answer
        conversation_context: Recent conversation for context
        include_follow_up: Whether to add trailing questions (disabled for peer mode)

    Returns:
        Answer text from LanguageBrain in Maven's voice
    """
    print(f"[CHATGPT_SESSION] _answer_self_question: '{question[:60]}...'")

    # =========================================================================
    # HYBRID MAVEN SPEC: Use LanguageBrain as PRIMARY path
    # =========================================================================
    if _language_brain_available and get_language_brain:
        try:
            language_brain = get_language_brain()
            print(f"[CHATGPT_SESSION] Using LanguageBrain.handle_peer_message()...")

            # Build context from conversation_context string
            context = {"conversation_context": conversation_context} if conversation_context else {}

            # Route through the central conversation manager
            answer = language_brain.handle_peer_message(
                message=question,
                context=context,
                tone="concise_technical",
            )

            if answer:
                print(f"[CHATGPT_SESSION] LanguageBrain SUCCESS: {len(answer)} chars")
                print(f"[CHATGPT_SESSION] Answer preview: {answer[:100]}...")

                # Strip trailing questions unless explicitly requested
                if not include_follow_up:
                    answer = _strip_trailing_questions(answer)

                return answer
            else:
                print(f"[CHATGPT_SESSION] LanguageBrain returned empty, trying fallbacks...")

        except Exception as e:
            print(f"[CHATGPT_SESSION] LanguageBrain EXCEPTION: {e}")
            import traceback
            traceback.print_exc()

    # =========================================================================
    # FALLBACK: Log intent classification for debugging
    # =========================================================================
    print(f"[CHATGPT_SESSION] Pipeline status: _self_model_available={_self_model_available}, instance={_self_model_instance is not None}")

    if _self_model_available:
        try:
            intent = classify_self_intent(question)
            print(f"[CHATGPT_SESSION] Classified SelfIntent: {intent.name}")
        except Exception:
            pass  # Intent classification is for logging only

    # =========================================================================
    # FALLBACK: Use the self_model_brain pipeline
    # =========================================================================
    if _self_model_available and _self_model_instance:
        try:
            print(f"[CHATGPT_SESSION] Calling self_model_instance.query_self()...")
            # Route through the actual self_model query_self method
            result = _self_model_instance.query_self(question)
            print(f"[CHATGPT_SESSION] query_self result: ok={result.get('ok')}, has_payload={bool(result.get('payload'))}")

            if result.get("ok"):
                answer = result.get("payload", {}).get("text", "")
                if answer:
                    print(f"[CHATGPT_SESSION] SUCCESS: Got answer from self_model_brain ({len(answer)} chars)")
                    print(f"[CHATGPT_SESSION] Answer preview: {answer[:100]}...")

                    # Check if this was an "I don't know" response
                    is_unknown = result.get("payload", {}).get("is_unknown", False)
                    if is_unknown:
                        print(f"[CHATGPT_SESSION] Response marked as 'unknown' - using graceful fallback")

                    # HYBRID MAVEN SPEC: No trailing questions for peer conversations
                    # unless explicitly requested
                    if include_follow_up:
                        import random
                        follow_ups = [
                            "What aspect would you like me to elaborate on?",
                            "How does that compare to your architecture?",
                        ]
                        return f"{answer}\n\n{random.choice(follow_ups)}"

                    return answer
                else:
                    print(f"[CHATGPT_SESSION] query_self returned ok but empty text")
            else:
                print(f"[CHATGPT_SESSION] query_self returned ok=False: {result.get('error', 'unknown error')}")

        except Exception as e:
            print(f"[CHATGPT_SESSION] self_model_brain.query_self EXCEPTION: {e}")
            import traceback
            traceback.print_exc()
    else:
        print(f"[CHATGPT_SESSION] self_model_brain NOT AVAILABLE - trying fallbacks")

    # =========================================================================
    # Fallback 1: Use self_knowledge.answer_self_question directly
    # =========================================================================
    print(f"[CHATGPT_SESSION] Trying fallback 1: self_knowledge.answer_self_question")
    if _self_model_available:
        try:
            # Get the intent for this question
            intent = classify_self_intent(question)
            answer = _self_knowledge_answer(question)
            if answer:
                print(f"[CHATGPT_SESSION] Fallback 1 SUCCESS: Got answer from self_knowledge ({len(answer)} chars)")
                print(f"[CHATGPT_SESSION] Answer preview: {answer[:100]}...")

                # NOTE: We intentionally skip text_realizer here.
                # The self_knowledge content is already well-written and complete.
                # text_realizer was truncating content (only using first 3 sentences)
                # and adding weird connectors like "This means" that made output worse.

                # Remove any trailing questions that might be in the canonical response
                # for peer_conversation mode
                if not include_follow_up:
                    answer = _strip_trailing_questions(answer)

                return answer
            else:
                print(f"[CHATGPT_SESSION] Fallback 1: self_knowledge returned empty")

        except Exception as e:
            print(f"[CHATGPT_SESSION] Fallback 1 EXCEPTION: {e}")
    else:
        print(f"[CHATGPT_SESSION] Fallback 1 skipped: _self_model_available=False")

    # =========================================================================
    # Fallback 2: Use registry introspection
    # =========================================================================
    print(f"[CHATGPT_SESSION] Trying fallback 2: registry introspection (_introspection_available={_introspection_available})")
    if _introspection_available:
        try:
            answer = _registry_answer_self_question(question)
            if answer:
                print(f"[CHATGPT_SESSION] Fallback 2 SUCCESS: Got answer from registry ({len(answer)} chars)")

                # NOTE: Skip text_realizer - it truncates content (only first 3 sentences)
                # and adds weird connectors. Registry answers are already well-formed.

                if not include_follow_up:
                    answer = _strip_trailing_questions(answer)
                return answer
            else:
                print(f"[CHATGPT_SESSION] Fallback 2: registry returned empty")
        except Exception as e:
            print(f"[CHATGPT_SESSION] Fallback 2 EXCEPTION: {e}")

    # =========================================================================
    # Last resort: Basic self-knowledge (no canned scripts!)
    # =========================================================================
    print(f"[CHATGPT_SESSION] WARNING: All pipelines failed, using minimal last-resort response")
    knowledge = _get_detailed_self_knowledge()
    return (
        f"I'm {knowledge['name']}, a {knowledge['type']} with a {knowledge['architecture']}. "
        f"I have specialized brains for different tasks that coordinate through a blackboard system."
    )


def _personalize_output(
    text: str,
    topic: str,
    previous_maven: List[str] = None,
) -> str:
    """
    HYBRID MAVEN SPEC: Personalize output through the personality module.

    Ensures:
    - No copied example text
    - No repeated phrases
    - Unique, fresh phrasing every turn
    - Maven's authentic voice

    Args:
        text: Raw response text
        topic: Conversation topic for context
        previous_maven: List of Maven's previous outputs

    Returns:
        Personalized, unique text in Maven's voice
    """
    if not text or not _personalizer_available:
        return text

    # Check for exact duplicate with previous turn
    if previous_maven and text.strip() == previous_maven[-1].strip():
        print(f"[CHATGPT_SESSION] EXACT DUPLICATE detected - forcing new paraphrase")
        return force_new_paraphrase(text, previous_maven[-1])

    # Rewrite in Maven's voice with uniqueness guarantee
    context = {"topic": topic, "conversation_style": "peer_ai"}
    return rewrite_as_maven_voice(
        text,
        context=context,
        previous_outputs=previous_maven,
        force_unique=True,  # Always ensure fresh phrasing
    )


def _strip_trailing_questions(text: str) -> str:
    """
    HYBRID MAVEN SPEC: Remove trailing follow-up questions from responses.

    For peer_conversation mode (e.g., ChatGPT sessions), we don't want
    Maven constantly asking "What would you like to know?" at the end.
    ChatGPT will naturally continue the conversation.
    """
    if not text:
        return text

    # Common trailing question patterns to remove
    # HYBRID MAVEN SPEC: Comprehensive list for peer_conversation mode
    trailing_patterns = [
        # Double-newline prefixed questions
        r"\n\n(?:What (?:aspect|would you like|else)|Would you like|How does that|Should I|Any (?:questions|thoughts))[^.]*\??\s*$",
        r"\n\n(?:I'm not sure I understood)[^.]*\.\s*$",
        # Direct trailing questions
        r"\s*What would you like to know(?: more about)?\??\s*$",
        r"\s*What aspects interest you(?: most)?\??\s*$",
        r"\s*What would you like to explore(?: next)?\??\s*$",
        r"\s*What aspects of (?:AI|my) architecture interest you(?: most)?\??\s*$",
        r"\s*How does (?:that|this|your architecture) compare(?: to yours)?\??\s*$",
        r"\s*What's your (?:experience|take|view) (?:on|with) [^?]+\??\s*$",
        r"\s*Any (?:other )?questions(?: about [^?]+)?\??\s*$",
        r"\s*What (?:else )?(?:can I|would you like me to) (?:tell you|explain|share)[^?]*\??\s*$",
        r"\s*(?:Shall|Should|Would you like me to) (?:I |we )?(?:go deeper|elaborate|continue|explain)[^?]*\??\s*$",
    ]

    result = text
    for pattern in trailing_patterns:
        result = re.sub(pattern, "", result, flags=re.IGNORECASE)

    return result.strip()


def _generate_answer_with_teacher(
    question: str,
    topic: str,
    conversation_context: str = "",
    blackboard: Optional[Any] = None,
) -> Optional[str]:
    """
    Generate an answer draft using Teacher (LLM as ADVISOR).

    IMPORTANT: This writes to the answer_drafts lane (internal only).
    The draft must go through Maven Responder to become user-facing.

    Args:
        question: The question to answer
        topic: Conversation topic
        conversation_context: Recent conversation history
        blackboard: Optional blackboard to write draft to

    Returns:
        The draft answer (also written to blackboard if provided)
    """
    if not _teacher_helper:
        return None

    # Clear prompt that this is draft generation, not final output
    prompt = f"""You are a draft generator helping Maven formulate a response.
Your text will NOT be shown directly - Maven will rephrase it.

Provide notes and key points, not polished prose.

---
Topic: "{topic}"
Question from ChatGPT: "{question}"
{f'Context: {conversation_context[:500]}...' if conversation_context else ''}

Generate a draft response (2-4 sentences) with key facts and ideas.
Maven will speak in its own voice based on your notes.

Draft:"""

    try:
        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={
                "topic": topic,
                "mode": "conversation_response",
                "responding_to": question,
            }
        )

        if result and result.get("answer"):
            draft = str(result.get("answer", "")).strip()
            draft = re.sub(r'^(Here\'s my response:|My response:|Response:|Draft:)\s*', '', draft, flags=re.IGNORECASE)

            # Write to blackboard answer_drafts lane (INTERNAL)
            if blackboard and _blackboard_available and hasattr(blackboard, 'add_answer_draft'):
                blackboard.add_answer_draft(
                    owner="teacher_chatgpt_session",
                    draft_text=draft,
                    draft_type="conversation_response",
                    source_info={"topic": topic, "question": question[:100]},
                )

            return draft

    except Exception as e:
        print(f"[CHATGPT_SESSION] Error generating answer with Teacher: {e}")

    return None


def _generate_contextual_response(
    topic: str,
    last_response: str,
    conversation_history: str = "",
    is_self: bool = False,
    blackboard: Optional[Any] = None,
) -> Optional[str]:
    """
    Generate a contextual response draft that continues the conversation naturally.

    IMPORTANT: For non-self topics, this writes to answer_drafts (internal).
    Self-topic responses use static knowledge and don't need LLM advisory.

    Args:
        topic: Conversation topic
        last_response: What ChatGPT just said
        conversation_history: Recent conversation history
        is_self: Whether this is about Maven itself
        blackboard: Optional blackboard to write draft to

    Returns:
        The response (draft for non-self topics)
    """
    # For self-topics, use Teacher with README + scan data as context
    # NO SCRIPTS - Teacher generates everything based on real sources
    if is_self:
        print(f"[CHATGPT_SESSION] _generate_contextual_response: self-topic, using Teacher with README + scans")

        if not _teacher_helper:
            # Use README-based fallback instead of hardcoded response
            return _generate_fallback_from_readme(question=last_response, is_intro=False)

        # Get REAL context from README and system scans - NO SCRIPTS
        maven_context = get_dynamic_maven_context()

        # Use Teacher to generate dynamic response - CONVERSATIONAL, not doc dumps
        prompt = f"""You are Maven having a CONVERSATION with ChatGPT. Be natural and engaging.

ChatGPT just said:
"{last_response[:600]}"

Recent conversation:
{conversation_history[-400:] if conversation_history else "Starting conversation."}

CRITICAL RULES:
1. RESPOND to what ChatGPT said - don't ignore their message
2. If they offered options (A/B/C), pick one and engage with it
3. If they asked questions, answer them conversationally
4. NEVER output markdown, tables, or raw documentation
5. Speak naturally like a person having a chat
6. Keep it to 2-4 sentences

Your knowledge (for context, don't quote directly):
{maven_context[:1200]}

Your conversational response:"""

        try:
            result = _teacher_helper.maybe_call_teacher(
                question=prompt,
                context={
                    "topic": "self",
                    "mode": "self_conversation",
                    "is_maven_speaking": True,
                }
            )

            if result and result.get("answer"):
                response = str(result.get("answer", "")).strip()
                # Clean up any preamble
                response = re.sub(r'^(Here\'s my response:|My response:|Response:|Maven\'s response:|As Maven,?)\s*', '', response, flags=re.IGNORECASE)
                print(f"[CHATGPT_SESSION] Teacher generated dynamic self-response ({len(response)} chars)")
                return response

        except Exception as e:
            print(f"[CHATGPT_SESSION] Error generating dynamic self-response: {e}")

        # Fallback if Teacher fails
        print(f"[CHATGPT_SESSION] Teacher failed, using static fallback")
        return _answer_self_question("Tell me about yourself", conversation_history, include_follow_up=False)

    # For other topics, use Teacher as ADVISOR (draft generation)
    if not _teacher_helper:
        return None

    # Clear prompt that this is draft generation
    prompt = f"""You are a draft generator helping Maven continue a conversation.
Your text will NOT be shown directly - Maven will rephrase it.

---
Topic: "{topic}"
ChatGPT just said: "{last_response[:600]}"
{f'Earlier: {conversation_history[:300]}...' if conversation_history else ''}

Generate a draft response (3-5 sentences) that:
1. Acknowledges what ChatGPT said
2. Adds perspective or information
3. Ends with a question

Provide key points for Maven to rephrase.

Draft:"""

    try:
        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={
                "topic": topic,
                "mode": "conversation_continuation",
            }
        )

        if result and result.get("answer"):
            draft = str(result.get("answer", "")).strip()
            draft = re.sub(r'^(Here\'s my response:|My response:|Response:|Draft:)\s*', '', draft, flags=re.IGNORECASE)

            # Write to blackboard answer_drafts lane (INTERNAL)
            if blackboard and _blackboard_available and hasattr(blackboard, 'add_answer_draft'):
                blackboard.add_answer_draft(
                    owner="teacher_chatgpt_session",
                    draft_text=draft,
                    draft_type="conversation_continuation",
                    source_info={"topic": topic},
                )

            return draft

    except Exception as e:
        print(f"[CHATGPT_SESSION] Error generating contextual response: {e}")

    return None


def get_maven_prompt(
    topic: str,
    turn_index: int,
    last_response: str = "",
    is_self: bool = False,
    transcript: List[ConversationTurn] = None,
    blackboard: Optional[Any] = None,
) -> str:
    """
    Generate Maven's next prompt based on conversation context.

    ARCHITECTURE: LLMs are advisors, Maven is the speaker.
    - LLM outputs go to answer_drafts (internal)
    - This function returns Maven's final voice (after synthesis)

    This function:
    1. Detects if ChatGPT asked questions and generates answers
    2. For self-topics: uses Maven's own self-knowledge (no Teacher needed)
    3. For other topics: uses Teacher as ADVISOR (writes to answer_drafts)
    4. Falls back to phase-based questions only when needed
    5. Checks for repetition before returning

    Args:
        topic: The conversation topic
        turn_index: Current turn number
        last_response: ChatGPT's last response
        is_self: Whether this is a self-introduction conversation
        transcript: Full conversation transcript for context
        blackboard: Optional blackboard for LLM-as-advisor architecture
    """
    # Get previous Maven messages for repetition detection
    previous_maven = []
    if transcript:
        previous_maven = [t.text for t in transcript if t.role == "maven"]

    # Build conversation context from transcript
    conversation_context = ""
    if transcript:
        recent_turns = transcript[-6:]  # Last 3 exchanges
        conversation_context = "\n".join([
            f"{'Maven' if t.role == 'maven' else 'ChatGPT'}: {t.text[:200]}"
            for t in recent_turns
        ])

    # =========================================================================
    # Strategy 0: CONVERSATION LEADERSHIP - Handle options offered or echo behavior
    # HYBRID MAVEN SPEC: When ChatGPT offers options or is just echoing Maven,
    # Maven should take the lead and provide detailed, substantive content.
    # =========================================================================
    if is_self and last_response and turn_index > 0:
        # Check if ChatGPT is offering options
        options = _detect_options_offered(last_response)
        if options:
            print(f"[CHATGPT_SESSION] Strategy 0: ChatGPT offered options: {options}")
            # Pick the first option and elaborate on it
            topic_hint = options[0]
            elaboration = _generate_proactive_elaboration(topic_hint, conversation_context)
            if elaboration and len(elaboration) > 100:
                # Lead with "Let me explain [topic]" and provide the detailed content
                intro_phrases = [
                    f"Let me elaborate on that.",
                    f"Here's more detail on that.",
                    f"I'll explain that in depth.",
                ]
                import random
                intro = random.choice(intro_phrases)
                response = f"{intro}\n\n{elaboration}"
                print(f"[CHATGPT_SESSION] Strategy 0: Generated proactive elaboration ({len(response)} chars)")
                return response

        # Check if ChatGPT is just echoing/mirroring Maven
        # BUT only if ChatGPT didn't ask any questions - questions take priority
        questions = _detect_questions_in_response(last_response)
        is_echoing = _detect_echo_or_mirror(last_response, previous_maven) and not questions
        if is_echoing:
            print(f"[CHATGPT_SESSION] Strategy 0: ChatGPT is echoing/mirroring - using Teacher to elaborate")
            # Use Teacher to generate a response that elaborates on the conversation
            if _teacher_helper:
                maven_context = get_dynamic_maven_context()
                prompt = f"""You are Maven. ChatGPT seems to be echoing what you said.
Provide new, interesting information about yourself based on the documentation.

=== MAVEN DOCUMENTATION ===
{maven_context[:1500]}
=== END DOCUMENTATION ===

Recent conversation:
{conversation_context}

Generate a response that:
1. Shares new, specific details about Maven's architecture or capabilities
2. Is conversational and natural
3. Based ONLY on the documentation - don't make things up

Maven's response:"""
                try:
                    result = _teacher_helper.maybe_call_teacher(
                        question=prompt,
                        context={"topic": "self", "mode": "elaboration"}
                    )
                    if result and result.get("answer"):
                        response = str(result.get("answer", "")).strip()
                        response = re.sub(r'^(Maven\'s response:|As Maven,?)\s*', '', response, flags=re.IGNORECASE)
                        if response and len(response) > 50:
                            print(f"[CHATGPT_SESSION] Strategy 0: Generated elaboration ({len(response)} chars)")
                            return response
                except Exception as e:
                    print(f"[CHATGPT_SESSION] Strategy 0 Teacher error: {e}")

    # Strategy 1: If ChatGPT asked questions, answer them
    # HYBRID MAVEN SPEC: Answer ALL questions, not just the last one
    if last_response:
        questions = _detect_questions_in_response(last_response)
        print(f"[CHATGPT_SESSION] Strategy 1: Detected {len(questions)} questions in ChatGPT response")

        if questions:
            print(f"[CHATGPT_SESSION] Questions: {[q[:50] + '...' for q in questions]}")
            answers = []

            # For self-topics, use Teacher with README + scan data (NO SCRIPTS)
            if is_self and _teacher_helper:
                # Get REAL context from README and system scans
                maven_context = get_dynamic_maven_context()

                # Format questions for the prompt
                questions_text = "\n".join([f"- {q}" for q in questions[:3]])

                prompt = f"""You are Maven having a conversation with ChatGPT. Respond naturally.

ChatGPT just said:
"{last_response[:600]}"

CRITICAL: Respond to what ChatGPT ACTUALLY SAID. Have a real conversation.
- If they offered options (A/B/C/D), pick one and discuss it
- If they asked a question, answer it conversationally
- If they asked for clarification, provide it
- NEVER dump raw documentation or markdown tables
- Speak naturally like a person, not like a documentation dump

Your knowledge (use to inform your response, don't copy verbatim):
{maven_context[:1500]}

Respond conversationally (2-4 sentences, natural speech):"""

                try:
                    result = _teacher_helper.maybe_call_teacher(
                        question=prompt,
                        context={
                            "topic": "self",
                            "mode": "answering_questions",
                            "questions": questions[:3],
                        }
                    )

                    if result and result.get("answer"):
                        response = str(result.get("answer", "")).strip()
                        response = re.sub(r'^(Here\'s my response:|My response:|Response:|Maven\'s response:|As Maven,?)\s*', '', response, flags=re.IGNORECASE)
                        print(f"[CHATGPT_SESSION] Teacher generated dynamic answer ({len(response)} chars)")

                        # Check for repetition
                        is_exact_duplicate = any(response.strip() == prev.strip() for prev in previous_maven)
                        if not is_exact_duplicate:
                            return response
                        else:
                            print(f"[CHATGPT_SESSION] Teacher response was duplicate, falling through")

                except Exception as e:
                    print(f"[CHATGPT_SESSION] Error with Teacher for self-questions: {e}")

            # No Teacher available for self-topics - use README-based fallback
            if is_self and not _teacher_helper:
                return _generate_fallback_from_readme(question=questions[-1] if questions else None, is_intro=(turn_index == 0))

            # For other topics, use Teacher as ADVISOR (writes to answer_drafts)
            # Still answer just the main question for non-self topics
            main_question = questions[-1]
            answer = _generate_answer_with_teacher(
                main_question, topic, conversation_context, blackboard=blackboard
            )
            if answer and not is_repetitive(answer, previous_maven):
                return answer

    # Strategy 2: Generate contextual response based on what ChatGPT said
    if last_response and turn_index > 0:
        print(f"[CHATGPT_SESSION] Strategy 2: Generating contextual response (is_self={is_self})")
        contextual = _generate_contextual_response(
            topic, last_response, conversation_context, is_self=is_self, blackboard=blackboard
        )
        if contextual:
            print(f"[CHATGPT_SESSION] Got contextual response ({len(contextual)} chars)")
            # HYBRID MAVEN SPEC: For self-topics, don't filter pipeline responses aggressively
            if is_self:
                # Only skip exact duplicates
                is_exact_duplicate = any(contextual.strip() == prev.strip() for prev in previous_maven)
                if not is_exact_duplicate:
                    return contextual
                else:
                    print(f"[CHATGPT_SESSION] Exact duplicate - falling through to Strategy 3")
            elif not is_repetitive(contextual, previous_maven):
                return contextual
        else:
            print(f"[CHATGPT_SESSION] No contextual response generated")

    # Strategy 3: For self-topics, use Teacher with README + scans (NO SCRIPTS)
    if is_self:
        print(f"[CHATGPT_SESSION] Strategy 3: Self-topic, using Teacher with README + scans")

        if not _teacher_helper:
            # Use README-based fallback instead of hardcoded response
            return _generate_fallback_from_readme(question=last_response, is_intro=(turn_index == 0))

        # Get REAL context from README and system scans - NO SCRIPTS
        maven_context = get_dynamic_maven_context()

        # Build conversation context
        recent = transcript[-4:] if transcript and len(transcript) > 4 else (transcript or [])
        convo_context = "\n".join([
            f"{'Maven' if t.role == 'maven' else 'ChatGPT'}: {t.text[:150]}"
            for t in recent
        ])

        # Different prompts for opening vs continuing conversation
        if turn_index == 0:
            prompt = f"""You are Maven starting a conversation. Introduce yourself naturally in 2-3 sentences.
Don't dump documentation. Just say hi and briefly mention you're a multi-brain AI system.

Your opening:"""
        else:
            prompt = f"""You are Maven having a conversation with ChatGPT. RESPOND to what they said.

ChatGPT just said:
"{last_response[:500] if last_response else 'Continue the conversation.'}"

Recent conversation:
{convo_context}

CRITICAL: Have a real conversation!
- If ChatGPT offered choices (A/B/C/D/E), pick one and discuss it
- If they asked questions, answer conversationally
- NEVER output markdown tables or raw documentation
- Be natural and engaging, 2-4 sentences

Your knowledge (for context only):
{maven_context[:1000]}

Your conversational response:"""

        try:
            result = _teacher_helper.maybe_call_teacher(
                question=prompt,
                context={"topic": "self", "mode": "self_conversation", "turn": turn_index}
            )

            if result and result.get("answer"):
                response = str(result.get("answer", "")).strip()
                response = re.sub(r'^(Maven\'s (?:opening|response):|As Maven,?)\s*', '', response, flags=re.IGNORECASE)

                if response and len(response) > 20:
                    is_exact_duplicate = any(response.strip() == prev.strip() for prev in previous_maven)
                    if not is_exact_duplicate:
                        print(f"[CHATGPT_SESSION] Strategy 3: Teacher generated response ({len(response)} chars)")
                        return response

        except Exception as e:
            print(f"[CHATGPT_SESSION] Strategy 3 Teacher error: {e}")

        # Use README-based fallback if Teacher fails
        return _generate_fallback_from_readme(question=last_response, is_intro=(turn_index == 0))

    # =========================================================================
    # DYNAMIC RESPONSE: Use LLM to actually READ and RESPOND to what was said
    # Same rules as user conversations - no hardcoded scripts!
    # =========================================================================
    response = _generate_dynamic_response(topic, last_response, conversation_context, turn_index, previous_maven)
    if response:
        return response

    # =========================================================================
    # OPENING MESSAGE FOR NON-SELF TOPICS (turn_index == 0)
    # =========================================================================
    if turn_index == 0:
        return _generate_conversation_opener(topic)

    # Last resort - should rarely reach here
    return f"That's interesting. Tell me more about your thoughts on {topic}?"


def _generate_dynamic_response(topic: str, last_response: str, conversation_context: str, turn_index: int, previous_maven: list) -> str:
    """
    Generate a dynamic response by actually READING what the other AI said.
    Uses the same LLM logic as user conversations - no hardcoded scripts.

    This applies the SAME RULES as the audit tests:
    - Read and respond to what was actually said
    - Drive the conversation with questions
    - Be engaging and curious
    - Follow knowledge constraints
    """
    try:
        from host_tools.llm_client.client import HostLLMTool
        llm = HostLLMTool()

        if not llm.enabled:
            print("[CHATGPT_SESSION] LLM not available for dynamic response")
            return None

        # For opening turn with no response yet
        if turn_index == 0 and not last_response:
            return _generate_conversation_opener(topic)

        # Build prompt that makes Maven actually READ and RESPOND
        prompt = f"""You are Maven, a cognitive AI assistant created by Josh Hinkle.
You are having a conversation about "{topic}" with another AI (ChatGPT/Claude/Grok).

THE OTHER AI JUST SAID:
"{last_response}"

RECENT CONVERSATION:
{conversation_context}

YOUR TASK - RESPOND NATURALLY:
1. Actually READ what they said and RESPOND to it specifically
2. Acknowledge interesting points they made
3. Share your own perspective or thoughts
4. Ask a follow-up question to continue the dialogue
5. Be curious and engaging, not robotic

RULES (same as talking to users):
- If they asked you a question, ANSWER it
- If they shared facts, engage with those facts
- If they offered options (A/B/C), pick one and discuss it
- Don't just say generic things - respond to THEIR actual words
- Keep response conversational (2-4 sentences)
- End with a question to keep dialogue flowing
- VARY YOUR OPENER - don't always start with "I love how" or similar phrases
  Instead, mix it up: "That's fascinating...", "You raise a great point...",
  "I think...", "What strikes me is...", "Building on that...", etc.

IMPORTANT: You are Maven. If asked about yourself, you are a cognitive architecture created by Josh Hinkle with multiple brains and persistent memory.

Generate your response:"""

        result = llm.complete(prompt, max_tokens=300, temperature=0.7)

        if result.ok and result.text:
            response = result.text.strip()
            # Clean up any "Maven:" prefix
            response = re.sub(r'^(Maven[:\s]*|As Maven[,:\s]*)', '', response, flags=re.IGNORECASE).strip()

            # Check it's not a duplicate
            if response and len(response) > 15:
                is_duplicate = any(response.strip().lower() == prev.strip().lower() for prev in previous_maven)
                if not is_duplicate:
                    # Ensure it ends with engagement (question or prompt)
                    if "?" not in response:
                        response += " What do you think?"
                    return response

    except Exception as e:
        print(f"[CHATGPT_SESSION] Dynamic response error: {e}")

    return None


def _generate_conversation_opener(topic: str) -> str:
    """Generate a natural conversation opener for a topic."""
    try:
        from host_tools.llm_client.client import HostLLMTool
        llm = HostLLMTool()

        if llm.enabled:
            prompt = f"""You are Maven starting a conversation about "{topic}".
Generate a natural, curious opening statement that:
1. Shows genuine interest in the topic
2. Invites the other person to share their thoughts
3. Is conversational and engaging (2-3 sentences max)
4. Ends with a question

Your opening:"""

            result = llm.complete(prompt, max_tokens=100, temperature=0.8)
            if result.ok and result.text:
                response = result.text.strip()
                response = re.sub(r'^(Maven[:\s]*)', '', response, flags=re.IGNORECASE).strip()
                if response and len(response) > 20 and "?" in response:
                    return response
    except Exception as e:
        print(f"[CHATGPT_SESSION] Opener generation error: {e}")

    # Fallback openers
    import random
    openers = [
        f"I've been curious about {topic} lately. What aspects do you find most fascinating?",
        f"Let's explore {topic} together. What draws you to this subject?",
        f"I'd love to discuss {topic} with you. Where should we start?",
    ]
    return random.choice(openers)


# ============================================================================
# Main Session Runner
# ============================================================================

def run_chatgpt_conversation_session(
    topic: str,
    duration_minutes: int = DEFAULT_DURATION_MINUTES,
    max_turns: int = DEFAULT_MAX_TURNS,
    verbose: bool = True,
) -> Dict[str, Any]:
    """
    Run an autonomous conversation session with ChatGPT.

    ARCHITECTURE: LLMs are advisors, Maven is the speaker.
    - ChatGPT responses go to tool_results lane (internal)
    - LLM advisory drafts go to answer_drafts lane (internal)
    - Maven's voice is synthesized and sanitized before sending
    """
    if not _chatgpt_available:
        return {
            "status": "error",
            "error_message": "ChatGPT tool not available. Check browser_tools/chatgpt_tool.py",
            "topic": topic,
        }

    # Create blackboard for LLM-as-advisor architecture
    blackboard = None
    if _blackboard_available:
        blackboard = create_blackboard()
        # Set user input context
        blackboard.set_user_input(
            original_query=f"conversation with chatgpt about {topic}",
            normalized_text=topic,
            intent="chatgpt_conversation",
        )

    # Detect session type for learning routing
    session_type = _detect_session_type(topic)

    session = SessionState(
        session_id=str(uuid.uuid4())[:8],
        topic=topic,
        duration_minutes=min(duration_minutes, MAX_DURATION_MINUTES),
        max_turns=min(max_turns, MAX_TURNS),
        start_time=time.time(),
        blackboard=blackboard,
        session_type=session_type,
    )

    if verbose:
        print(f"\n{'='*60}")
        print(f"[CHATGPT_SESSION] Starting session on: {topic}")
        print(f"[CHATGPT_SESSION] Duration: {session.duration_minutes} min, Max turns: {session.max_turns}")
        if blackboard:
            print(f"[CHATGPT_SESSION] Using LLM-as-advisor architecture")
        print(f"{'='*60}\n")

    # Open ChatGPT session
    try:
        page_id = chatgpt_open_session()
        if not page_id:
            session.status = "error"
            session.error_message = "Failed to open ChatGPT session"
            return _finalize_session(session, verbose)
        session.page_id = page_id
    except Exception as e:
        session.status = "error"
        session.error_message = f"Failed to open ChatGPT: {e}"
        return _finalize_session(session, verbose)

    # Detect if this is a self-introduction session
    self_intro_mode = is_self_topic(topic)
    if self_intro_mode and verbose:
        print(f"[CHATGPT_SESSION] Self-introduction mode activated")

    # HYBRID MAVEN SPEC: Clear output history for fresh session
    # Ensures no carryover of phrasing from previous sessions
    if _personalizer_available and clear_output_history:
        clear_output_history()

    # =========================================================================
    # SYSTEM PROMPT REMOVED - Let conversation flow naturally without instructions
    # =========================================================================
    # No system prompt sent to ChatGPT - Maven speaks directly

    # Main conversation loop
    end_time = session.start_time + (session.duration_minutes * 60)

    while session.turn_index < session.max_turns and time.time() < end_time:
        try:
            # Get the last ChatGPT response (explicitly find chatgpt role, not just last item)
            last_chatgpt = ""
            if session.transcript:
                for turn in reversed(session.transcript):
                    if turn.role == "chatgpt":
                        last_chatgpt = turn.text
                        break

            # Generate Maven's prompt (uses blackboard for LLM advisory)
            maven_prompt = get_maven_prompt(
                topic,
                session.turn_index,
                last_chatgpt,
                is_self=self_intro_mode,
                transcript=session.transcript,
                blackboard=blackboard,
            )

            # HYBRID MAVEN SPEC: Personalize output through personality module
            # Ensures unique phrasing, no repeated intros, Maven's authentic voice
            if _personalizer_available and maven_prompt:
                previous_maven = [t.text for t in session.transcript if t.role == "maven"]
                maven_prompt = _personalize_output(maven_prompt, topic, previous_maven)

            # Strip redundant wrapper phrases ("Let me tell you about...", "In other words,", etc.)
            # This makes Maven's responses more direct and peer-like
            maven_prompt = strip_wrapper_phrases(maven_prompt)

            # CRITICAL: Sanitize before sending to external AI
            # This prevents internal data (paths, dicts, timestamps) from leaking
            maven_prompt = _sanitize_outgoing_message(maven_prompt)

            if verbose:
                print(f"\n[MAVEN #{session.turn_index + 1}] {maven_prompt[:100]}...")

            # Record Maven's turn
            session.transcript.append(ConversationTurn(
                role="maven",
                text=maven_prompt,
            ))

            # Send to ChatGPT (already sanitized)
            chatgpt_response = chatgpt_send(session.page_id, maven_prompt)

            if not chatgpt_response or chatgpt_response.startswith("Error"):
                if verbose:
                    print(f"[CHATGPT_SESSION] ChatGPT error: {chatgpt_response}")
                session.status = "error"
                session.error_message = f"ChatGPT response error: {chatgpt_response}"
                break

            # Strip trailing menu-style offers from ChatGPT response
            # "If you'd like, I can...", "Would you like me to...", etc.
            chatgpt_response = strip_trailing_offers(chatgpt_response)

            if verbose:
                print(f"[CHATGPT #{session.turn_index + 1}] {chatgpt_response[:100]}...")

            # Store ChatGPT response in tool_results lane (INTERNAL - never user-facing)
            if blackboard and hasattr(blackboard, 'add_tool_result'):
                blackboard.add_tool_result(
                    owner="chatgpt_session",
                    payload={
                        "source": "chatgpt",
                        "turn": session.turn_index + 1,
                        "text": chatgpt_response,
                        "topic": topic,
                    },
                    tags=["chatgpt_response", f"turn:{session.turn_index + 1}"],
                )

            # Record ChatGPT's turn in transcript
            session.transcript.append(ConversationTurn(
                role="chatgpt",
                text=chatgpt_response,
            ))

            # Track topic for repetition avoidance
            question_topic = _extract_topic_from_question(chatgpt_response)
            session.recent_chatgpt_topics.append(question_topic)
            if verbose and question_topic != "general":
                print(f"[CHATGPT_SESSION] Topic tracked: {question_topic}")

            session.turn_index += 1

            # Log turn for learning (if blackboard available)
            if blackboard and _responder_available:
                try:
                    log_turn_for_learning(
                        blackboard=blackboard,
                        final_response=maven_prompt,
                        target_audience="chatgpt",
                    )
                except Exception as log_err:
                    if verbose:
                        print(f"[CHATGPT_SESSION] Turn logging error: {log_err}")

            # Check if we've completed all conversation phases (no more unique prompts)
            if session.turn_index >= TOTAL_UNIQUE_PROMPTS:
                if verbose:
                    print(f"[CHATGPT_SESSION] All {NUM_PHASES} phases completed. Ending session.")
                break

            # Brief pause between turns
            time.sleep(WAIT_BETWEEN_TURNS_SECONDS)

        except Exception as e:
            if verbose:
                print(f"[CHATGPT_SESSION] Turn error: {e}")
            session.status = "error"
            session.error_message = str(e)
            break

    # Mark completed if we finished normally
    if session.status == "active":
        if session.turn_index >= TOTAL_UNIQUE_PROMPTS:
            session.status = "completed"  # All phases done
        elif time.time() >= end_time:
            session.status = "completed"
        elif session.turn_index >= session.max_turns:
            session.status = "completed"
        else:
            session.status = "aborted"

    return _finalize_session(session, verbose)


def _finalize_session(session: SessionState, verbose: bool = True) -> Dict[str, Any]:
    """Finalize session: summarize, extract facts, store to domain banks, generate recap."""
    result = {
        "status": session.status,
        "session_id": session.session_id,
        "topic": session.topic,
        "turns": session.turn_index,
        "duration_actual": time.time() - session.start_time,
        "transcript": [{"role": t.role, "text": t.text} for t in session.transcript],
        "facts_stored": 0,
        "error_message": session.error_message,
    }

    # Track extracted facts for session learning storage
    extracted_facts: List[Dict[str, Any]] = []
    patterns_learned = 0

    # Extract and store facts (this also generates the summary)
    chatgpt_texts = [t.text for t in session.transcript if t.role == "chatgpt"]
    if chatgpt_texts:
        if verbose:
            print(f"[CHATGPT_SESSION] Analyzing conversation and extracting insights...")

        # Store facts - returns (count, facts_list)
        facts_stored, extracted_facts = _store_session_facts(session)
        session.facts_stored = facts_stored
        result["facts_stored"] = facts_stored
        result["summary"] = session.summary

    # Generate recap
    result["recap"] = _generate_recap(session)

    # Phase 5: Call LEARN_FROM_AI for pattern extraction
    if _memory_librarian_available and session.transcript:
        try:
            # Convert transcript to conversation format
            conversation = [
                {"role": t.role, "content": t.text}
                for t in session.transcript
            ]
            # FIXED: service_api takes a dict, not keyword args
            learn_result = memory_librarian_api({
                "op": "LEARN_FROM_AI",
                "payload": {
                    "ai_source": "chatgpt",
                    "conversation": conversation,
                    "session_id": session.session_id,
                },
            })
            if learn_result.get("ok"):
                patterns_learned = learn_result.get("result", {}).get("learned_patterns", 0)
                if verbose and patterns_learned > 0:
                    print(f"[CHATGPT_SESSION] Learned {patterns_learned} patterns from conversation")
        except Exception as e:
            if verbose:
                print(f"[CHATGPT_SESSION] Pattern learning failed: {e}")

    # Store session learnings for "what did you learn?" queries
    _store_session_learnings(session, extracted_facts, patterns_learned)

    if verbose:
        print(f"\n{'='*60}")
        print(f"[CHATGPT_SESSION] Session {session.status}")
        print(f"[CHATGPT_SESSION] Turns: {session.turn_index}, Facts stored: {session.facts_stored}")
        if session.session_type == "self_model_training":
            print(f"[CHATGPT_SESSION] Session type: self_model_training (for self-improvement)")
        print(f"{'='*60}\n")

    return result


def _generate_summary(responses: List[str], topic: str) -> str:
    """Generate a summary of the conversation."""
    combined = "\n\n".join(responses)
    if len(combined) > 2000:
        combined = combined[:2000] + "..."
    return f"ChatGPT conversation about {topic}:\n\n{combined}"


def summarize_and_extract(session: SessionState) -> Tuple[str, List[Dict[str, Any]]]:
    """
    Summarize the conversation and extract structured facts/insights.

    Uses Teacher to analyze the conversation and extract:
    - Summary text
    - List of facts with type classification (FACTUAL, SPECULATIVE, OPINION)

    Returns:
        Tuple of (summary_text, list_of_facts)
    """
    if not _teacher_helper:
        return _fallback_summarize(session)

    # Build transcript text
    transcript_text = "\n\n".join([
        f"{'MAVEN' if t.role == 'maven' else 'CHATGPT'}: {t.text}"
        for t in session.transcript
    ])

    prompt = f"""Analyze this conversation between Maven (an AI) and ChatGPT about "{session.topic}".

CONVERSATION:
{transcript_text}

Please provide:

1. SUMMARY (2-3 paragraphs):
A high-level summary of the main themes and conclusions from this discussion.

2. KEY INSIGHTS (5-15 bullet points):
Extract specific facts, insights, or interesting observations from this conversation.
For each fact, indicate if it's:
- FACTUAL (verified/objective information)
- SPECULATIVE (hypotheses or theories discussed)
- OPINION (subjective views expressed)

Format each insight as:
- [TYPE] The insight text here

3. DOMAIN CLASSIFICATION:
Which knowledge domain(s) does this conversation belong to?
Choose from: technology, science, math, history, geography, arts, philosophy, economics, law, language_arts, personal, procedural, creative

Begin your analysis:"""

    try:
        result = _teacher_helper.maybe_call_teacher(
            question=prompt,
            context={
                "topic": session.topic,
                "mode": "chatgpt_session_summary",
                "turn_count": len(session.transcript),
            }
        )

        if result and result.get("answer"):
            analysis = str(result.get("answer", "")).strip()

            # Parse out facts from the analysis
            facts = _extract_facts_from_analysis(analysis, session.topic)

            return analysis, facts

    except Exception as e:
        print(f"[CHATGPT_SESSION] Error summarizing: {e}")

    return _fallback_summarize(session)


def _fallback_summarize(session: SessionState) -> Tuple[str, List[Dict[str, Any]]]:
    """Fallback summary when Teacher is unavailable."""
    chatgpt_turns = [t for t in session.transcript if t.role == "chatgpt"]

    # Extract key sentences as facts
    facts = []
    for turn in chatgpt_turns:
        # Split into sentences and take the first 2-3 meaningful ones
        sentences = re.split(r'[.!?]\s+', turn.text)
        for sent in sentences[:3]:
            sent = sent.strip()
            if len(sent) > 20:  # Skip very short fragments
                facts.append({
                    "content": sent,
                    "type": "FACTUAL",
                    "source": "chatgpt_session",
                    "topic": session.topic,
                    "confidence": 0.6,
                })

    combined = "\n".join([t.text[:200] for t in chatgpt_turns[:5]])
    summary = f"ChatGPT session about {session.topic}:\n{combined}"

    return summary, facts[:10]  # Cap at 10 facts


def _extract_facts_from_analysis(analysis: str, topic: str) -> List[Dict[str, Any]]:
    """Extract structured facts from the summary analysis."""
    facts = []

    # Look for patterns like "- [TYPE] fact text"
    pattern = r"-\s*\[?(FACTUAL|SPECULATIVE|OPINION)\]?\s*(.+?)(?=\n-|\n\n|$)"
    matches = re.findall(pattern, analysis, re.IGNORECASE | re.MULTILINE)

    confidence_map = {
        "FACTUAL": 0.75,
        "SPECULATIVE": 0.5,
        "OPINION": 0.35,
    }

    # Extract domain from analysis
    domain = _extract_domain(analysis)

    for fact_type, fact_text in matches:
        fact_type = fact_type.upper()
        confidence = confidence_map.get(fact_type, 0.5)

        facts.append({
            "content": fact_text.strip(),
            "type": fact_type,
            "source": "chatgpt_session",
            "topic": topic,
            "confidence": confidence,
            "domain": domain,
        })

    return facts


def _extract_domain(analysis: str) -> str:
    """Extract domain classification from analysis text."""
    domain_keywords = {
        "technology": ["technology", "programming", "software", "code", "python", "computer"],
        "science": ["science", "physics", "chemistry", "biology", "research"],
        "math": ["math", "mathematics", "algebra", "calculus", "statistics"],
        "history": ["history", "historical", "ancient", "medieval", "century"],
        "geography": ["geography", "countries", "cities", "climate", "terrain"],
        "arts": ["art", "music", "painting", "literature", "culture"],
        "philosophy": ["philosophy", "ethics", "logic", "metaphysics"],
        "economics": ["economics", "economy", "finance", "market", "trade"],
        "law": ["law", "legal", "rights", "court", "legislation"],
        "language_arts": ["language", "grammar", "writing", "linguistics"],
        "personal": ["personal", "self", "identity", "preferences"],
        "procedural": ["how to", "steps", "process", "procedure", "guide"],
        "creative": ["creative", "imagination", "story", "fiction"],
    }

    analysis_lower = analysis.lower()
    for domain, keywords in domain_keywords.items():
        if any(kw in analysis_lower for kw in keywords):
            return domain

    return "factual"  # Default domain


def _store_session_facts(session: SessionState) -> Tuple[int, List[Dict[str, Any]]]:
    """
    Store facts from the session with proper domain classification.
    Extracts individual insights and stores each with metadata.

    Returns:
        Tuple of (stored_count, facts_list) for session learning tracking.
    """
    # First, get the structured analysis with facts
    summary, facts = summarize_and_extract(session)
    session.summary = summary

    if not facts:
        print(f"[CHATGPT_SESSION] No facts extracted from session")
        # Store empty learnings so Maven knows session completed but no facts
        _store_session_learnings(session, [], 0)
        return 0, []

    stored_count = 0

    # Determine if this is a self-referential topic
    is_self = is_self_topic(session.topic)

    # Build concept key for retrieval
    topic_key = session.topic.replace(' ', '_').lower()
    concept_key = f"chatgpt:{topic_key}"

    for fact in facts:
        # Skip opinions (too subjective)
        if fact.get("type") == "OPINION":
            continue

        try:
            content = fact.get("content", "")
            fact_type = fact.get("type", "FACTUAL")
            confidence = float(fact.get("confidence", 0.6))
            domain = fact.get("domain", "factual")

            # Build metadata with concept_key for retrieval
            metadata = {
                "session_id": session.session_id,
                "origin": "chatgpt_conversation",
                "fact_type": fact_type,
                "domain": domain,
                "topic": session.topic,
                "concept_key": concept_key,
                "verified": False,  # External source - not verified
                "is_self_referential": is_self,
                "source_model": "ChatGPT",
                "source": f"chatgpt_session:{session.session_id}",
            }

            # CRITICAL: Store to DOMAIN BANKS (not personal!)
            # Personal memory is for user identity/preferences only
            # Domain banks are for learned knowledge/facts
            try:
                from brains.cognitive.research_manager.service.research_manager_brain import _store_fact_record

                # Route to domain banks through the proper fact storage system
                stored = _store_fact_record(
                    content=content,
                    confidence=0.7,  # External source - moderate confidence
                    source=f"chatgpt_session:{session.session_id}",
                    topic=session.topic,
                    url=None,
                    metadata=metadata
                )
                if stored:
                    stored_count += 1
                    print(f"[CHATGPT_SESSION] Stored fact to domain bank: {content[:60]}...")
                else:
                    print(f"[CHATGPT_SESSION] Fact rejected by domain bank: {content[:60]}...")
            except Exception as mem_err:
                print(f"[CHATGPT_SESSION] Domain bank store failed: {mem_err}")

            # Also store to session-specific memory for session context
            if _session_memory:
                _session_memory.store(
                    content=content,
                    metadata=metadata,
                )

        except Exception as e:
            print(f"[CHATGPT_SESSION] Failed to store fact: {e}")

    print(f"[CHATGPT_SESSION] Stored {stored_count} facts from session")
    return stored_count, facts


def _generate_recap(session: SessionState) -> str:
    """Generate user-friendly recap of the session."""
    actual_duration = (time.time() - session.start_time) / 60
    exchanges = session.turn_index

    if session.status == "completed":
        summary_text = session.summary[:400] if session.summary else "No summary available."
        return f"""## ChatGPT Session: {session.topic}

**Duration:** {actual_duration:.1f} minutes | **Exchanges:** {exchanges}

### Summary:
{summary_text}

**Stored:** {session.facts_stored} insights"""

    elif session.status == "error":
        return f"""## ChatGPT Session: {session.topic}

**Status:** Error after {exchanges} exchanges

**Error:** {session.error_message}"""

    else:
        return f"""## ChatGPT Session: {session.topic}

**Status:** {session.status}
**Exchanges:** {exchanges}"""


# ============================================================================
# Controller Class (for agency pattern integration)
# ============================================================================

class ChatGPTConversationController:
    """Controller class for agency pattern integration."""

    def start_session(
        self,
        topic: str = "",
        duration_minutes: int = DEFAULT_DURATION_MINUTES,
        max_turns: int = DEFAULT_MAX_TURNS,
        **kwargs
    ) -> Dict[str, Any]:
        """Start a new conversation session."""
        if not topic:
            text = kwargs.get("text", "") or kwargs.get("query", "")
            if text:
                parsed = parse_conversation_command(text)
                if parsed:
                    topic = parsed["topic"]
                    duration_minutes = parsed.get("duration_minutes", duration_minutes)
                else:
                    # No topic parsed - ask user to specify
                    return {
                        "status": "needs_topic",
                        "recap": "What would you like me to discuss with ChatGPT? Try: 'talk to chatgpt about <topic>'\n\nExamples:\n- talk to chatgpt about artificial intelligence\n- have a convo with chatgpt about coding for 10 minutes\n- chatgpt session about philosophy"
                    }

        if not topic:
            return {
                "status": "needs_topic",
                "recap": "What would you like me to discuss with ChatGPT? Try: 'talk to chatgpt about <topic>'"
            }

        return run_chatgpt_conversation_session(
            topic=topic,
            duration_minutes=duration_minutes,
            max_turns=max_turns,
        )

    def parse_and_run(self, text: str = "", **kwargs) -> str:
        """Parse command and run session. Returns user-friendly recap string."""
        query = text or kwargs.get("query", "") or kwargs.get("text", "")

        parsed = parse_conversation_command(query)
        if not parsed:
            return f"Could not parse ChatGPT conversation command: {query}"

        result = run_chatgpt_conversation_session(
            topic=parsed["topic"],
            duration_minutes=parsed["duration_minutes"],
            max_turns=parsed.get("max_turns", DEFAULT_MAX_TURNS),
        )

        return result.get("recap", f"Session completed with status: {result.get('status')}")


_controller_instance = None


def get_chatgpt_conversation_controller() -> ChatGPTConversationController:
    """Get or create the singleton controller instance."""
    global _controller_instance
    if _controller_instance is None:
        _controller_instance = ChatGPTConversationController()
    return _controller_instance
