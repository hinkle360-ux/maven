"""
Upgrade Engine - Maven Governance Brain
--------------------------------------

This brain lives in the governance layer and is responsible for
identifying, proposing and (upon authorization) applying upgrades to
the Maven system.  It communicates with other brains exclusively via
the Memory Librarian bus and never forms direct peer connections.

Supported operations:

* **SCAN** – perform a non‑destructive analysis of available system
  metadata and return a summary of potential upgrade opportunities.
  No authorization is required for this operation.

* **PROPOSE** – accept a candidate upgrade description and return a
  structured proposal.  This operation does not apply the upgrade; it
  simply packages the information for later review.  No authorization
  is required.

* **SUBMIT_PROPOSAL** – submit an upgrade proposal for validation with
  external consensus (ChatGPT, Grok, Claude). All three must approve
  before the proposal is queued for human review. This implements
  Maven's self-upgrade capability with multi-model safety checks.

* **APPLY** – apply an approved upgrade to the system.  Because this
  modifies code or configuration, a valid governance authorization
  token is required in the payload.

* **GET_PENDING** – retrieve list of pending upgrade proposals awaiting
  human review.

* **GET_CONSENSUS** – retrieve consensus results for a specific proposal.

Any unsupported operation will return an error.

Note: This implementation provides scaffolding for an upgrade engine
with external consensus validation. The SUBMIT_PROPOSAL operation
coordinates multi-model consensus before queuing upgrades for human review.
"""

from __future__ import annotations
from typing import Any, Dict, List, Optional
import time, json
from pathlib import Path
from datetime import datetime

"""
This module implements a very primitive Upgrade Engine for Maven.  In order to
support agent‑mode workflows, it now writes proposals and logs to private
directories under the engine's own folder.  These directories are created
automatically at import time and are never shared with other brains.  No
external code is executed and no hidden libraries are imported; only the
standard library is used to persist files and manage timestamps.

Directories:

```
upgrade_engine/
  service/
    upgrade_engine.py          # this file
  packs/                       # final approved upgrade bundles
  staging/                     # drafted proposals awaiting approval
  logs/                        # application logs and history
```

The ``packs`` and ``staging`` folders are intentionally separated: ``staging``
holds JSON descriptions of proposed upgrades, while ``packs`` will contain
approved bundles (e.g. archives or collected files) once the system learns
how to assemble them.  ``logs`` records when scans, proposals and applies
occur so that Governance and Self‑Default can inspect the history without
parsing memory files directly.

All file writes are guarded so that failures will not crash the engine; any
exceptions in file I/O are swallowed and only affect logging.
"""

# Determine root paths relative to this file.  ``ENGINE_ROOT`` points to
# the ``upgrade_engine`` directory, which is one level up from this file
# (``service/upgrade_engine.py``).  The three work directories live at
# ``ENGINE_ROOT / "packs"``, ``staging`` and ``logs``.
ENGINE_ROOT = Path(__file__).resolve().parents[1]
PACKS_DIR = ENGINE_ROOT / "packs"
STAGING_DIR = ENGINE_ROOT / "staging"
LOGS_DIR = ENGINE_ROOT / "logs"

for _dir in (PACKS_DIR, STAGING_DIR, LOGS_DIR):
    try:
        _dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

# Additional directories for consensus-based upgrades
PENDING_DIR = ENGINE_ROOT / "pending"  # Approved proposals awaiting human review
CONSENSUS_DIR = ENGINE_ROOT / "consensus"  # Consensus results storage

for _dir in (PENDING_DIR, CONSENSUS_DIR):
    try:
        _dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass

# =============================================================================
# External Integrations (Lazy-loaded)
# =============================================================================

# Consensus validator for multi-model approval
_consensus_validator = None

def _get_consensus_validator():
    """Lazy-load the consensus validator."""
    global _consensus_validator
    if _consensus_validator is None:
        try:
            from brains.governance.upgrade_engine.consensus_validator import (
                get_consensus_validator
            )
            _consensus_validator = get_consensus_validator()
        except ImportError as e:
            print(f"[UPGRADE_ENGINE] Consensus validator not available: {e}")
    return _consensus_validator

# Repair engine for patch generation
_repair_engine = None

def _get_repair_engine():
    """Lazy-load the repair engine."""
    global _repair_engine
    if _repair_engine is None:
        try:
            from brains.governance.repair_engine.service.repair_engine import (
                service_api as repair_api
            )
            _repair_engine = repair_api
        except ImportError as e:
            print(f"[UPGRADE_ENGINE] Repair engine not available: {e}")
    return _repair_engine

# Policy engine for approval
_policy_engine = None

def _get_policy_engine():
    """Lazy-load the policy engine."""
    global _policy_engine
    if _policy_engine is None:
        try:
            from brains.governance.policy_engine.service.policy_engine import (
                service_api as policy_api
            )
            _policy_engine = policy_api
        except ImportError as e:
            print(f"[UPGRADE_ENGINE] Policy engine not available: {e}")
    return _policy_engine

# Memory librarian for storage
_memory = None

def _get_memory():
    """Lazy-load memory interface."""
    global _memory
    if _memory is None:
        try:
            from brains.memory.brain_memory import BrainMemory
            _memory = BrainMemory("upgrade_engine")
        except ImportError as e:
            print(f"[UPGRADE_ENGINE] Memory not available: {e}")
    return _memory


def _now_ms() -> int:
    return int(time.time() * 1000)


def _auth_ok(auth: Dict[str, Any]) -> bool:
    """Validate a governance authorization block.

    An auth block must be a dict with the following keys:
    - ``issuer``: must equal ``"governance"``.
    - ``valid``: boolean flag that must be True.
    - ``ts``: timestamp when the token was issued (ms).
    - ``ttl_ms``: time to live in milliseconds.
    - ``token``: a string starting with ``"GOV-"`` of at least length 8.

    Returns True if all conditions are satisfied and the token has not expired.
    """
    if not isinstance(auth, dict):
        return False
    if auth.get("issuer") != "governance":
        return False
    if not auth.get("valid", False):
        return False
    ts = auth.get("ts")
    ttl = auth.get("ttl_ms", 0)
    if not isinstance(ts, int) or not isinstance(ttl, int):
        return False
    if _now_ms() > ts + ttl:
        return False
    tok = auth.get("token", "")
    return isinstance(tok, str) and tok.startswith("GOV-") and len(tok) >= 8


def _scan_impl(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Placeholder implementation for scan.

    In a real implementation, this function would inspect system history,
    performance metrics and role charters to identify opportunities for
    improvement.  Here we simply echo back a list of brains to suggest
    scanning order and return an empty list of suggested upgrades.
    """
    brains = payload.get("brains", [
        "sensorium", "planner", "language", "pattern_recognition",
        "memory", "reasoning", "affect_priority", "personality",
        "system_history", "self_dmn"
    ])
    result = {
        "ok": True,
        "brains_scanned": brains,
        "suggested_upgrades": []
    }
    # Record the scan event in the engine's log directory.  This creates a small
    # JSON file with the event type, timestamp and payload.  If logging fails
    # (e.g. due to file permissions), we ignore the error and proceed.
    try:
        fname = LOGS_DIR / f"{_now_ms()}_scan.json"
        with open(fname, "w", encoding="utf-8") as f:
            json.dump({"event": "scan", "timestamp": _now_ms(), "data": result}, f, indent=2)
    except Exception:
        pass
    return result


def _propose_impl(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Accept an upgrade description and package it as a proposal.

    The ``payload`` should contain a ``description`` key describing the
    change and an optional ``target`` identifying which part of the
    system is affected.  The function returns a proposal object with
    a unique id and a timestamp.
    """
    description = (payload or {}).get("description", "")
    target = (payload or {}).get("target", "unspecified")
    proposal_id = f"UPG-{_now_ms()}"
    # Build the proposal object
    proposal = {
        "id": proposal_id,
        "description": description,
        "target": target,
        "timestamp": _now_ms(),
        "status": "pending"
    }
    resp = {"ok": True, "proposal": proposal}
    # Persist the proposal into the staging directory.  Each proposal is stored
    # as a separate JSON file named after its id.  Logging is best effort; if
    # writing fails, we still return success to the caller.
    try:
        pfile = STAGING_DIR / f"{proposal_id}.json"
        with open(pfile, "w", encoding="utf-8") as f:
            json.dump(proposal, f, indent=2)
    except Exception:
        pass
    # Log the proposal event
    try:
        logf = LOGS_DIR / f"{_now_ms()}_propose.json"
        with open(logf, "w", encoding="utf-8") as f:
            json.dump({"event": "propose", "timestamp": _now_ms(), "data": proposal}, f, indent=2)
    except Exception:
        pass
    return resp


def _apply_impl(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Apply a previously approved upgrade.

    In this placeholder implementation, we do not modify any files.  We
    simply return a result indicating that the upgrade would be applied.
    Real code should perform the necessary patching here, guarded by
    compliance checks.
    """
    proposal_id = (payload or {}).get("proposal_id", "")
    # Attempt to locate the proposal in the staging directory and move it to packs
    success = False
    staging_path = STAGING_DIR / f"{proposal_id}.json"
    packs_path = PACKS_DIR / f"{proposal_id}.json"
    try:
        if staging_path.exists():
            # Copy to packs (rename for atomicity) and remove the staging file
            staging_path.replace(packs_path)
        success = True
    except Exception:
        success = False
    # Log the apply event regardless of outcome
    try:
        logf = LOGS_DIR / f"{_now_ms()}_apply.json"
        with open(logf, "w", encoding="utf-8") as f:
            json.dump({"event": "apply", "timestamp": _now_ms(), "proposal_id": proposal_id, "moved": success}, f, indent=2)
    except Exception:
        pass
    return {
        "ok": True,
        "applied": success,
        "proposal_id": proposal_id,
        "notes": "Upgrade applied (placeholder)"
    }


# =============================================================================
# Consensus-Based Upgrade System
# =============================================================================

def _submit_proposal_impl(payload: Dict[str, Any]) -> Dict[str, Any]:
    """
    Submit an upgrade proposal for external consensus validation.

    Flow:
    1. Validate and store the proposal
    2. Get external consensus (ChatGPT, Grok, Claude)
    3. Check policy engine
    4. If approved, queue for human review
    5. Return result with status

    Args:
        payload: Proposal dict containing:
            - id: Optional proposal ID (auto-generated if not provided)
            - source: Which brain/component originated the proposal
            - trigger: What triggered the proposal
            - motivation: Why the upgrade is needed
            - evidence: Evidence supporting the need
            - suggested_fix: Type of fix suggested
            - scope: What parts of the system are affected

    Returns:
        Result dict with status and details
    """
    # Generate proposal ID if not provided
    proposal_id = payload.get("id") or f"UPG-{_now_ms()}"
    proposal = {
        "id": proposal_id,
        "source": payload.get("source", "unknown"),
        "trigger": payload.get("trigger", "manual"),
        "motivation": payload.get("motivation", ""),
        "evidence": payload.get("evidence", []),
        "suggested_fix": payload.get("suggested_fix", "unknown"),
        "scope": payload.get("scope", "unknown"),
        "timestamp": _now_ms(),
        "status": "submitted"
    }

    print(f"[UPGRADE_ENGINE] New proposal: {proposal_id}")

    # Step 1: Store the proposal
    try:
        proposal_file = STAGING_DIR / f"{proposal_id}.json"
        with open(proposal_file, "w", encoding="utf-8") as f:
            json.dump(proposal, f, indent=2)
    except Exception as e:
        return {"ok": False, "error": f"Failed to store proposal: {e}"}

    # Step 2: Get external consensus
    consensus_validator = _get_consensus_validator()
    if consensus_validator is None:
        # No consensus validator - return for manual review
        print("[UPGRADE_ENGINE] Consensus validator unavailable, queuing for manual review")
        return {
            "ok": True,
            "proposal_id": proposal_id,
            "status": "NEED_MANUAL_REVIEW",
            "message": "Consensus validator unavailable - proposal requires manual review",
            "consensus": None
        }

    print("[UPGRADE_ENGINE] Requesting external consensus...")
    try:
        consensus = consensus_validator.validate_proposal(proposal)
    except Exception as e:
        print(f"[UPGRADE_ENGINE] Consensus validation failed: {e}")
        return {
            "ok": True,
            "proposal_id": proposal_id,
            "status": "CONSENSUS_ERROR",
            "message": f"Consensus validation error: {e}",
            "consensus": None
        }

    # Store consensus results
    _store_consensus_result(proposal_id, consensus)

    # Log individual verdicts
    individual = consensus.get("individual_verdicts", {})
    for model, verdict in individual.items():
        print(f"[CONSENSUS] {model}: {verdict.get('verdict', 'unknown')}")
    print(f"[CONSENSUS] Decision: {consensus.get('decision', 'unknown')}")

    # Step 3: Process based on consensus decision
    decision = consensus.get("decision", "NEED_HUMAN_REVIEW")

    if decision == "APPROVED":
        # Step 3a: Check policy engine
        policy_approved = _check_policy_approval(proposal, consensus)

        if policy_approved:
            # Step 3b: Queue for human review
            result = _queue_for_human_review(proposal, consensus)
            return {
                "ok": True,
                "proposal_id": proposal_id,
                "status": "APPROVED_AWAITING_HUMAN",
                "message": "Consensus approved - queued for human review",
                "consensus": consensus,
                "pending_path": result.get("pending_path")
            }
        else:
            return {
                "ok": True,
                "proposal_id": proposal_id,
                "status": "REJECTED_BY_POLICY",
                "message": "Consensus approved but policy engine rejected",
                "consensus": consensus
            }

    elif decision == "REJECTED":
        return {
            "ok": True,
            "proposal_id": proposal_id,
            "status": "REJECTED_BY_CONSENSUS",
            "message": "External models rejected the proposal",
            "consensus": consensus
        }

    else:
        return {
            "ok": True,
            "proposal_id": proposal_id,
            "status": "NEED_HUMAN_REVIEW",
            "message": "Consensus uncertain - requires human review",
            "consensus": consensus
        }


def _store_consensus_result(proposal_id: str, consensus: Dict[str, Any]) -> None:
    """Store consensus results for auditing."""
    try:
        consensus_file = CONSENSUS_DIR / f"{proposal_id}_consensus.json"
        with open(consensus_file, "w", encoding="utf-8") as f:
            json.dump(consensus, f, indent=2)

        # Also log to memory if available
        memory = _get_memory()
        if memory:
            memory.store(
                content=f"Consensus for {proposal_id}: {consensus.get('decision', 'unknown')}",
                metadata={
                    "kind": "consensus_result",
                    "proposal_id": proposal_id,
                    "decision": consensus.get("decision"),
                    "vote_breakdown": consensus.get("vote_breakdown"),
                    "confidence": 0.9
                }
            )
    except Exception as e:
        print(f"[UPGRADE_ENGINE] Failed to store consensus: {e}")


def _check_policy_approval(proposal: Dict[str, Any], consensus: Dict[str, Any]) -> bool:
    """Check policy engine for upgrade approval."""
    policy_engine = _get_policy_engine()
    if policy_engine is None:
        # No policy engine - default to approved
        return True

    try:
        result = policy_engine({
            "op": "APPROVE_UPGRADE_PROPOSAL",
            "payload": {
                "proposal": proposal,
                "consensus": consensus
            }
        })
        return result.get("allowed", True)
    except Exception as e:
        print(f"[UPGRADE_ENGINE] Policy check failed: {e}")
        # Default to approved on error (conservative for self-improvement)
        return True


def _queue_for_human_review(proposal: Dict[str, Any], consensus: Dict[str, Any]) -> Dict[str, Any]:
    """Queue an approved upgrade proposal for human review."""
    proposal_id = proposal.get("id", "unknown")

    # Create readable summary
    summary = _format_upgrade_summary(proposal, consensus)

    # Save to pending directory
    summary_path = PENDING_DIR / f"{proposal_id}_summary.md"
    try:
        with open(summary_path, "w", encoding="utf-8") as f:
            f.write(summary)
    except Exception as e:
        print(f"[UPGRADE_ENGINE] Failed to save summary: {e}")
        return {"error": str(e)}

    # Update proposal status
    try:
        proposal_file = STAGING_DIR / f"{proposal_id}.json"
        if proposal_file.exists():
            proposal["status"] = "pending_human_review"
            with open(proposal_file, "w", encoding="utf-8") as f:
                json.dump(proposal, f, indent=2)
    except Exception:
        pass

    # Log the event
    try:
        logf = LOGS_DIR / f"{_now_ms()}_queued.json"
        with open(logf, "w", encoding="utf-8") as f:
            json.dump({
                "event": "queued_for_review",
                "timestamp": _now_ms(),
                "proposal_id": proposal_id,
                "consensus_decision": consensus.get("decision")
            }, f, indent=2)
    except Exception:
        pass

    # Store notification in memory
    memory = _get_memory()
    if memory:
        try:
            memory.store(
                content=f"Upgrade proposal {proposal_id} approved and ready for review",
                metadata={
                    "kind": "notification",
                    "type": "upgrade_ready",
                    "proposal_id": proposal_id,
                    "summary_path": str(summary_path),
                    "importance": 1.0
                }
            )
        except Exception:
            pass

    print(f"[UPGRADE_ENGINE] Saved to {summary_path}")

    return {
        "ok": True,
        "pending_path": str(summary_path)
    }


def _format_upgrade_summary(proposal: Dict[str, Any], consensus: Dict[str, Any]) -> str:
    """Format upgrade summary for human review."""
    individual = consensus.get("individual_verdicts", {})
    vote = consensus.get("vote_breakdown", {})
    concerns = consensus.get("aggregated_concerns", [])
    suggestions = consensus.get("aggregated_suggestions", [])

    def _format_verdict(model: str, verdict: Dict) -> str:
        return f"""### {model.upper()}
- Verdict: {verdict.get('verdict', 'unknown')}
- Risk: {verdict.get('risk_assessment', 'unknown')}
- Reasoning: {verdict.get('reasoning', 'N/A')[:500]}"""

    verdicts_text = "\n\n".join(
        _format_verdict(model, v) for model, v in individual.items()
    )

    concerns_text = "\n".join(f"- {c}" for c in concerns) if concerns else "None"
    suggestions_text = "\n".join(f"- {s}" for s in suggestions) if suggestions else "None"

    return f"""# Maven Self-Upgrade Proposal

**ID:** {proposal.get('id', 'unknown')}
**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
**Source:** {proposal.get('source', 'unknown')}
**Trigger:** {proposal.get('trigger', 'unknown')}

---

## Motivation

{proposal.get('motivation', 'No motivation provided')}

---

## Evidence

```json
{json.dumps(proposal.get('evidence', []), indent=2)}
```

---

## External Consensus

**Decision:** {consensus.get('decision', 'unknown')}
**Vote:** {vote.get('approve', 0)}/3 approve, {vote.get('reject', 0)}/3 reject, {vote.get('uncertain', 0)}/3 uncertain

{verdicts_text}

---

## Concerns Raised

{concerns_text}

---

## Suggestions

{suggestions_text}

---

## Governance Validation

- External consensus: {consensus.get('decision', 'unknown')}
- Consensus reached: {'Yes' if consensus.get('consensus_reached') else 'No'}

---

## Next Steps

1. Review this proposal
2. If approved, run the upgrade engine with APPLY operation
3. If rejected, archive this proposal

---

*Generated by Maven Upgrade Engine*
"""


def _get_pending_impl(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get list of pending upgrade proposals."""
    pending = []

    try:
        for summary_file in PENDING_DIR.glob("*_summary.md"):
            proposal_id = summary_file.stem.replace("_summary", "")
            pending.append({
                "id": proposal_id,
                "summary_path": str(summary_file),
                "modified": summary_file.stat().st_mtime
            })
    except Exception as e:
        return {"ok": False, "error": str(e)}

    # Sort by modification time (newest first)
    pending.sort(key=lambda x: x.get("modified", 0), reverse=True)

    return {
        "ok": True,
        "count": len(pending),
        "pending": pending
    }


def _get_consensus_impl(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Get consensus results for a specific proposal."""
    proposal_id = payload.get("proposal_id", "")

    if not proposal_id:
        return {"ok": False, "error": "proposal_id required"}

    consensus_file = CONSENSUS_DIR / f"{proposal_id}_consensus.json"

    if not consensus_file.exists():
        return {"ok": False, "error": f"No consensus found for {proposal_id}"}

    try:
        with open(consensus_file, "r", encoding="utf-8") as f:
            consensus = json.load(f)
        return {"ok": True, "consensus": consensus}
    except Exception as e:
        return {"ok": False, "error": str(e)}


def _handle_impl(msg: Dict[str, Any]) -> Dict[str, Any]:
    """Main entry point for the Upgrade Engine.

    Dispatches operations based on the ``op`` field of the incoming
    message.  Non‑destructive operations (SCAN, PROPOSE, GET_*) do not
    require authorization, whereas APPLY does.  SUBMIT_PROPOSAL uses
    external consensus validation before queuing for human review.

    Returns a standard response dict with ``ok``, ``op``, ``mid`` and
    ``payload`` keys.
    """
    op = (msg or {}).get("op", "").upper()
    payload = (msg or {}).get("payload", {}) or {}
    mid = msg.get("mid") or f"mid-{_now_ms()}"

    # Non‑destructive operations
    if op == "SCAN":
        res = _scan_impl(payload)
        return {"ok": True, "op": op, "mid": mid, "payload": res}

    if op == "PROPOSE":
        res = _propose_impl(payload)
        return {"ok": True, "op": op, "mid": mid, "payload": res}

    # Consensus-based upgrade submission (no auth required - consensus validates)
    if op == "SUBMIT_PROPOSAL":
        res = _submit_proposal_impl(payload)
        return {"ok": res.get("ok", True), "op": op, "mid": mid, "payload": res}

    # Query operations
    if op == "GET_PENDING":
        res = _get_pending_impl(payload)
        return {"ok": res.get("ok", True), "op": op, "mid": mid, "payload": res}

    if op == "GET_CONSENSUS":
        res = _get_consensus_impl(payload)
        return {"ok": res.get("ok", True), "op": op, "mid": mid, "payload": res}

    # Destructive operations require governance authorization
    if op == "APPLY":
        auth = payload.get("auth", {})
        if not _auth_ok(auth):
            return {
                "ok": False,
                "op": op,
                "mid": mid,
                "error": "UPGRADE_UNAUTHORIZED",
                "message": "Upgrade operation requires valid Governance authorization token",
                "payload": {"authorized": False}
            }
        res = _apply_impl(payload)
        return {"ok": True, "op": op, "mid": mid, "payload": {"authorized": True, **res}}

    # Unsupported op
    return {
        "ok": False,
        "op": op,
        "mid": mid,
        "error": "UNSUPPORTED_OP",
        "message": op
    }


def handle(context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Brain contract entry point.

    Args:
        context: Standard brain context dict

    Returns:
        Result dict
    """
    return _handle_impl(context)


# Brain contract alias
service_api = handle