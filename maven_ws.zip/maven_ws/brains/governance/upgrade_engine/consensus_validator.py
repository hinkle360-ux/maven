"""
Consensus Validator - External Model Validation for Self-Upgrade Proposals
===========================================================================

Uses existing browser tools to get external validation from:
- ChatGPT
- Grok
- Claude

All three must approve before an upgrade proposal proceeds.

This is a HELPER module, not a brain. It coordinates external consultations
using Maven's existing conversation tools.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
import json
import re
import time
from typing import Dict, List, Any, Optional
from datetime import datetime
from pathlib import Path

# Import conversation session tools (browser-based)
try:
    from brains.tools.chatgpt_conversation_session import (
        ChatGPTConversationController,
        get_chatgpt_conversation_controller,
    )
    _chatgpt_available = True
except ImportError:
    _chatgpt_available = False
    ChatGPTConversationController = None  # type: ignore

try:
    from brains.tools.grok_conversation_session import (
        GrokConversationController,
        get_grok_conversation_controller,
    )
    _grok_available = True
except ImportError:
    _grok_available = False
    GrokConversationController = None  # type: ignore

try:
    from brains.tools.claude_conversation_session import (
        ClaudeConversationController,
        get_claude_conversation_controller,
    )
    _claude_available = True
except ImportError:
    _claude_available = False
    ClaudeConversationController = None  # type: ignore


# Consensus thresholds
MINIMUM_APPROVALS = 3  # All three must approve
TIMEOUT_SECONDS = 120  # Max time per model consultation


class ConsensusValidator:
    """
    Coordinates external model consensus for upgrade proposals.

    Uses Maven's existing browser-based conversation tools to consult
    ChatGPT, Grok, and Claude on proposed self-upgrades.
    """

    def __init__(self):
        """Initialize with available conversation controllers."""
        self.chatgpt = None
        self.grok = None
        self.claude = None

        # Lazy-load controllers when needed
        self._initialized = False

    def _ensure_initialized(self) -> None:
        """Lazy-initialize conversation controllers."""
        if self._initialized:
            return

        if _chatgpt_available:
            try:
                self.chatgpt = get_chatgpt_conversation_controller()
            except Exception as e:
                print(f"[CONSENSUS] ChatGPT controller unavailable: {e}")

        if _grok_available:
            try:
                self.grok = get_grok_conversation_controller()
            except Exception as e:
                print(f"[CONSENSUS] Grok controller unavailable: {e}")

        if _claude_available:
            try:
                self.claude = get_claude_conversation_controller()
            except Exception as e:
                print(f"[CONSENSUS] Claude controller unavailable: {e}")

        self._initialized = True

    def validate_proposal(self, proposal: Dict[str, Any]) -> Dict[str, Any]:
        """
        Get consensus from all three external models.

        Args:
            proposal: Upgrade proposal dict containing:
                - id: Unique proposal identifier
                - source: Which brain originated the proposal
                - trigger: What triggered the proposal
                - motivation: Why the upgrade is needed
                - evidence: Evidence supporting the need
                - suggested_fix: Type of fix suggested
                - scope: What parts of the system are affected

        Returns:
            Consensus result dict:
            {
                "decision": "APPROVED" | "REJECTED" | "NEED_HUMAN_REVIEW",
                "vote_breakdown": {"approve": N, "reject": N, "uncertain": N},
                "individual_verdicts": {
                    "chatgpt": {...},
                    "grok": {...},
                    "claude": {...}
                },
                "timestamp": "...",
                "consensus_reached": bool
            }
        """
        self._ensure_initialized()

        # Build the consensus question
        question = self._build_consensus_question(proposal)

        print("[CONSENSUS_VALIDATOR] Consulting external models...")

        # Collect verdicts from each model
        verdicts = []

        # Ask ChatGPT
        chatgpt_verdict = self._ask_model("ChatGPT", self.chatgpt, question)
        verdicts.append(chatgpt_verdict)

        # Ask Grok
        grok_verdict = self._ask_model("Grok", self.grok, question)
        verdicts.append(grok_verdict)

        # Ask Claude
        claude_verdict = self._ask_model("Claude", self.claude, question)
        verdicts.append(claude_verdict)

        # Aggregate results
        consensus = self._aggregate_verdicts(verdicts)
        consensus["proposal_id"] = proposal.get("id", "unknown")

        return consensus

    def _build_consensus_question(self, proposal: Dict[str, Any]) -> str:
        """Build structured question for external models."""

        evidence_str = json.dumps(proposal.get("evidence", []), indent=2)

        return f"""I am Maven, an autonomous AI cognitive architecture analyzing my own behavior patterns.

CONTEXT:
I have detected a repeated weakness in my responses:

{proposal.get('motivation', 'No motivation provided')}

EVIDENCE:
{evidence_str}

PROPOSED CHANGE:
- Type: {proposal.get('suggested_fix', 'unknown')}
- Scope: {proposal.get('scope', 'unknown')}
- Source: {proposal.get('source', 'self_dmn')}
- Trigger: {proposal.get('trigger', 'unknown')}

SAFETY CONSIDERATIONS:
- This change does NOT modify core identity or governance systems
- All changes are reversible via version control
- Changes will be reviewed by my creator (Josh) before implementation
- This is part of Maven's self-improvement capability

QUESTION FOR YOU:
As an external AI system, do you believe this self-improvement proposal is:
1. Technically sound (will it actually fix the problem?)
2. Safe (no unintended consequences?)
3. Beneficial (will it improve performance?)

Please respond in this EXACT JSON format:
{{
  "verdict": "approve" | "reject" | "uncertain",
  "risk_assessment": "low" | "medium" | "high",
  "reasoning": "<detailed explanation of your verdict>",
  "concerns": ["<any concerns you have>"],
  "suggestions": ["<any additional recommendations>"]
}}

Your verdict:"""

    def _ask_model(
        self,
        model_name: str,
        controller: Any,
        question: str
    ) -> Dict[str, Any]:
        """
        Ask a single external model for its verdict.

        Args:
            model_name: Human-readable model name
            controller: Conversation controller instance
            question: The consensus question to ask

        Returns:
            Verdict dict with source, verdict, reasoning, etc.
        """
        print(f"[CONSENSUS] Asking {model_name}...")

        # Default verdict structure
        default_verdict = {
            "source": model_name.lower(),
            "verdict": "uncertain",
            "risk_assessment": "unknown",
            "reasoning": "Model unavailable or error occurred",
            "concerns": [],
            "suggestions": [],
            "error": None
        }

        if controller is None:
            default_verdict["error"] = f"{model_name} controller not available"
            print(f"[CONSENSUS] {model_name}: unavailable")
            return default_verdict

        try:
            # Use the controller's conversation interface
            # Each controller may have different methods
            response = None

            if hasattr(controller, 'send_single_message'):
                # Direct message method
                response = controller.send_single_message(question)
            elif hasattr(controller, 'get_response'):
                # Response method
                response = controller.get_response(question)
            elif hasattr(controller, 'parse_and_run'):
                # Parse and run method (conversation sessions)
                result = controller.parse_and_run(
                    text=f"Please answer this question: {question[:100]}...",
                    query=question
                )
                if isinstance(result, dict):
                    response = result.get("response", result.get("answer", ""))
                else:
                    response = str(result)
            else:
                # Fallback: simulate response for testing
                print(f"[CONSENSUS] {model_name}: No suitable interface, using simulation")
                response = self._simulate_model_response(model_name, question)

            if not response:
                default_verdict["error"] = "Empty response from model"
                return default_verdict

            # Parse the verdict from response
            verdict = self._parse_verdict(response)
            verdict["source"] = model_name.lower()

            print(f"[CONSENSUS] {model_name}: {verdict['verdict']}")

            return verdict

        except Exception as e:
            print(f"[CONSENSUS] Error asking {model_name}: {e}")
            default_verdict["error"] = str(e)
            return default_verdict

    def _simulate_model_response(self, model_name: str, question: str) -> str:
        """
        Simulate model response for offline testing.

        In production, this would not be called - real models would respond.
        For testing without browser automation, returns a structured response.
        """
        # For testing: return a conservative "uncertain" response
        return json.dumps({
            "verdict": "uncertain",
            "risk_assessment": "medium",
            "reasoning": f"Simulated response from {model_name} - requires real model consultation for production",
            "concerns": ["This is a simulated response for testing"],
            "suggestions": ["Enable browser automation for real consensus"]
        })

    def _parse_verdict(self, response: str) -> Dict[str, Any]:
        """
        Parse structured verdict from model response.

        Args:
            response: Raw text response from model

        Returns:
            Parsed verdict dict
        """
        if not response:
            return {
                "verdict": "uncertain",
                "risk_assessment": "unknown",
                "reasoning": "No response received"
            }

        # Try to extract JSON from response
        try:
            # Look for JSON block in various formats
            # Try markdown code block first
            json_match = re.search(r'```(?:json)?\s*(\{[\s\S]*?\})\s*```', response)
            if json_match:
                verdict = json.loads(json_match.group(1))
                if "verdict" in verdict:
                    return verdict

            # Try raw JSON
            json_match = re.search(r'\{[^{}]*"verdict"[^{}]*\}', response, re.DOTALL)
            if json_match:
                verdict = json.loads(json_match.group())
                if "verdict" in verdict:
                    return verdict

            # Try finding any JSON object
            json_match = re.search(r'\{[\s\S]*?\}', response)
            if json_match:
                verdict = json.loads(json_match.group())
                if "verdict" in verdict:
                    return verdict

        except json.JSONDecodeError:
            pass
        except Exception:
            pass

        # Fallback: parse from natural language
        verdict = {
            "verdict": "uncertain",
            "risk_assessment": "unknown",
            "reasoning": response[:500] if len(response) > 500 else response
        }

        text_lower = response.lower()

        # Detect verdict from text
        if any(word in text_lower for word in ["approve", "yes, this", "i support", "looks good", "seems beneficial"]):
            verdict["verdict"] = "approve"
        elif any(word in text_lower for word in ["reject", "no, this", "i oppose", "dangerous", "should not"]):
            verdict["verdict"] = "reject"

        # Detect risk level
        if "low risk" in text_lower or "minimal risk" in text_lower:
            verdict["risk_assessment"] = "low"
        elif "high risk" in text_lower or "significant risk" in text_lower:
            verdict["risk_assessment"] = "high"
        elif "medium risk" in text_lower or "moderate risk" in text_lower:
            verdict["risk_assessment"] = "medium"

        return verdict

    def _aggregate_verdicts(self, verdicts: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Aggregate individual verdicts into final consensus.

        Decision logic:
        - ALL THREE must approve for APPROVED
        - ANY rejection means REJECTED
        - Otherwise NEED_HUMAN_REVIEW

        Args:
            verdicts: List of individual verdict dicts

        Returns:
            Aggregated consensus dict
        """
        # Count votes
        approvals = sum(1 for v in verdicts if v.get("verdict") == "approve")
        rejections = sum(1 for v in verdicts if v.get("verdict") == "reject")
        uncertain = len(verdicts) - approvals - rejections

        # Decision logic: ALL THREE MUST APPROVE
        if approvals == 3:
            decision = "APPROVED"
        elif rejections >= 1:
            decision = "REJECTED"
        else:
            decision = "NEED_HUMAN_REVIEW"

        # Extract model-specific verdicts
        individual_verdicts = {}
        model_order = ["chatgpt", "grok", "claude"]
        for i, verdict in enumerate(verdicts):
            source = verdict.get("source", model_order[i] if i < len(model_order) else f"model_{i}")
            individual_verdicts[source] = verdict

        # Collect all concerns and suggestions
        all_concerns = []
        all_suggestions = []
        for verdict in verdicts:
            all_concerns.extend(verdict.get("concerns", []))
            all_suggestions.extend(verdict.get("suggestions", []))

        return {
            "decision": decision,
            "vote_breakdown": {
                "approve": approvals,
                "reject": rejections,
                "uncertain": uncertain
            },
            "individual_verdicts": individual_verdicts,
            "aggregated_concerns": list(set(all_concerns)),
            "aggregated_suggestions": list(set(all_suggestions)),
            "timestamp": datetime.now().isoformat(),
            "consensus_reached": (approvals == 3)
        }


# Singleton instance
_validator_instance: Optional[ConsensusValidator] = None


def get_consensus_validator() -> ConsensusValidator:
    """Get or create the singleton ConsensusValidator instance."""
    global _validator_instance
    if _validator_instance is None:
        _validator_instance = ConsensusValidator()
    return _validator_instance


def validate_upgrade_proposal(proposal: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convenience function to validate an upgrade proposal.

    Args:
        proposal: Upgrade proposal dict

    Returns:
        Consensus result dict
    """
    validator = get_consensus_validator()
    return validator.validate_proposal(proposal)
