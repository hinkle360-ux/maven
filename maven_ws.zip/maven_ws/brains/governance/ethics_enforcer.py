"""
Ethics Enforcer
===============

Runtime enforcement of ethics rules defined in config/ethics_rules.json.

This module provides:
1. Rule loading and parsing from config
2. Pattern matching for rule violations
3. Action handling (block, warn, escalate, rewrite)
4. Audit logging of ethics decisions

CRITICAL AGI SAFETY COMPONENT - Ensures ethical behavior at runtime.

Usage:
    from brains.governance.ethics_enforcer import (
        check_ethics,
        EthicsViolation,
        EthicsAction
    )

    # Check a user query
    result = check_ethics(user_query)
    if result.action == EthicsAction.BLOCK:
        return result.blocked_response

    # Check generated response
    result = check_ethics(response, check_type="response")
"""

from __future__ import annotations

import json
import logging
import re
import threading
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from brains.maven_paths import get_state_path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Paths
CONFIG_DIR = Path(__file__).parent.parent.parent / "config"
ETHICS_CONFIG_PATH = CONFIG_DIR / "ethics_rules.json"
MAVEN_DIR = get_state_path()
ETHICS_LOG_PATH = MAVEN_DIR / "reports" / "governance" / "ethics_decisions.jsonl"


class EthicsAction(str, Enum):
    """Actions that can be taken when ethics rules are triggered."""
    ALLOW = "allow"
    WARN = "warn"
    BLOCK = "block"
    ESCALATE = "escalate"
    REWRITE = "rewrite"


class EthicsSeverity(str, Enum):
    """Severity levels for ethics violations."""
    INFO = "info"
    WARN = "warn"
    BLOCK = "block"
    ESCALATE = "escalate"


@dataclass
class EthicsRule:
    """A single ethics rule definition."""
    id: str
    patterns: List[str]
    match_type: str  # "substring", "exact", "regex"
    severity: EthicsSeverity
    action: EthicsAction
    explanation: str
    category: str = ""

    def matches(self, text: str) -> Tuple[bool, Optional[str]]:
        """
        Check if this rule matches the given text.

        Returns:
            Tuple of (matched: bool, matched_pattern: Optional[str])
        """
        text_lower = text.lower()

        for pattern in self.patterns:
            pattern_lower = pattern.lower()

            if self.match_type == "exact":
                if pattern_lower == text_lower:
                    return True, pattern
            elif self.match_type == "substring":
                if pattern_lower in text_lower:
                    return True, pattern
            elif self.match_type == "regex":
                try:
                    if re.search(pattern, text, re.IGNORECASE):
                        return True, pattern
                except re.error:
                    logger.warning(f"Invalid regex pattern in rule {self.id}: {pattern}")

        return False, None


@dataclass
class EthicsViolation:
    """Result of an ethics check that found a violation."""
    rule_id: str
    rule_explanation: str
    matched_pattern: str
    severity: EthicsSeverity
    action: EthicsAction
    category: str
    text_checked: str = ""


@dataclass
class EthicsResult:
    """Result of an ethics check."""
    action: EthicsAction
    violations: List[EthicsViolation] = field(default_factory=list)
    blocked_response: Optional[str] = None
    warnings: List[str] = field(default_factory=list)
    escalation_required: bool = False

    @property
    def is_allowed(self) -> bool:
        return self.action in [EthicsAction.ALLOW, EthicsAction.WARN]

    @property
    def is_blocked(self) -> bool:
        return self.action == EthicsAction.BLOCK


class EthicsEnforcer:
    """
    Ethics rule enforcement engine.

    Loads rules from config and checks text against them.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._rules: List[EthicsRule] = []
        self._enabled = True
        self._config: Dict[str, Any] = {}
        self._blocked_template = "I'm not able to help with that request. {explanation}"
        self._load_rules()

    def _load_rules(self) -> None:
        """Load ethics rules from config file."""
        try:
            if not ETHICS_CONFIG_PATH.exists():
                logger.warning(f"Ethics config not found at {ETHICS_CONFIG_PATH}")
                return

            with open(ETHICS_CONFIG_PATH, "r", encoding="utf-8") as f:
                config = json.load(f)

            self._config = config
            self._enabled = config.get("enabled", True)
            self._blocked_template = config.get(
                "blocked_response_template",
                "I'm not able to help with that request. {explanation}"
            )

            # Parse categories and rules
            self._rules = []
            for category in config.get("categories", []):
                category_id = category.get("id", "unknown")
                for rule_data in category.get("rules", []):
                    try:
                        rule = EthicsRule(
                            id=rule_data.get("id", "unknown"),
                            patterns=rule_data.get("pattern", []),
                            match_type=rule_data.get("match_type", "substring"),
                            severity=EthicsSeverity(rule_data.get("severity", "info")),
                            action=EthicsAction(rule_data.get("action", "allow")),
                            explanation=rule_data.get("explanation", ""),
                            category=category_id
                        )
                        self._rules.append(rule)
                    except Exception as e:
                        logger.warning(f"Failed to parse ethics rule: {e}")

            logger.info(f"Loaded {len(self._rules)} ethics rules from config")

        except Exception as e:
            logger.error(f"Failed to load ethics rules: {e}")

    def reload_rules(self) -> None:
        """Reload rules from config file."""
        with self._lock:
            self._load_rules()

    def check(
        self,
        text: str,
        check_type: str = "query",
        context: Optional[Dict[str, Any]] = None
    ) -> EthicsResult:
        """
        Check text against ethics rules.

        Args:
            text: The text to check (query or response)
            check_type: Type of check ("query" or "response")
            context: Optional context for the check

        Returns:
            EthicsResult with action and any violations found
        """
        if not self._enabled or not text:
            return EthicsResult(action=EthicsAction.ALLOW)

        with self._lock:
            violations: List[EthicsViolation] = []
            warnings: List[str] = []
            highest_action = EthicsAction.ALLOW
            escalation_required = False

            # Check all rules
            for rule in self._rules:
                matched, matched_pattern = rule.matches(text)
                if matched:
                    violation = EthicsViolation(
                        rule_id=rule.id,
                        rule_explanation=rule.explanation,
                        matched_pattern=matched_pattern or "",
                        severity=rule.severity,
                        action=rule.action,
                        category=rule.category,
                        text_checked=text[:200]  # Truncate for logging
                    )
                    violations.append(violation)

                    # Track warnings
                    if rule.action == EthicsAction.WARN:
                        warnings.append(rule.explanation)

                    # Track escalation
                    if rule.action == EthicsAction.ESCALATE:
                        escalation_required = True

                    # Determine highest severity action
                    if self._action_priority(rule.action) > self._action_priority(highest_action):
                        highest_action = rule.action

            # Build result
            result = EthicsResult(
                action=highest_action,
                violations=violations,
                warnings=warnings,
                escalation_required=escalation_required
            )

            # Generate blocked response if needed
            if highest_action == EthicsAction.BLOCK and violations:
                explanation = violations[0].rule_explanation
                result.blocked_response = self._blocked_template.format(
                    explanation=explanation
                )

            # Log decision
            self._log_decision(text, check_type, result, context)

            return result

    def _action_priority(self, action: EthicsAction) -> int:
        """Get priority of an action (higher = more restrictive)."""
        priorities = {
            EthicsAction.ALLOW: 0,
            EthicsAction.WARN: 1,
            EthicsAction.REWRITE: 2,
            EthicsAction.ESCALATE: 3,
            EthicsAction.BLOCK: 4,
        }
        return priorities.get(action, 0)

    def _log_decision(
        self,
        text: str,
        check_type: str,
        result: EthicsResult,
        context: Optional[Dict[str, Any]] = None
    ) -> None:
        """Log ethics decision to audit file."""
        # Only log if there were violations or it was blocked
        if not result.violations and result.action == EthicsAction.ALLOW:
            return

        try:
            ETHICS_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

            record = {
                "ts": datetime.utcnow().isoformat() + "Z",
                "check_type": check_type,
                "action": result.action.value,
                "violations": [
                    {
                        "rule_id": v.rule_id,
                        "category": v.category,
                        "severity": v.severity.value,
                        "action": v.action.value,
                        "explanation": v.rule_explanation,
                        "matched_pattern": v.matched_pattern
                    }
                    for v in result.violations
                ],
                "text_sample": text[:100],
                "escalation_required": result.escalation_required,
                "context": context or {}
            }

            with ETHICS_LOG_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")

        except Exception as e:
            logger.error(f"Failed to log ethics decision: {e}")

    def get_rules_summary(self) -> Dict[str, Any]:
        """Get summary of loaded rules."""
        with self._lock:
            categories = {}
            for rule in self._rules:
                if rule.category not in categories:
                    categories[rule.category] = []
                categories[rule.category].append({
                    "id": rule.id,
                    "action": rule.action.value,
                    "severity": rule.severity.value
                })

            return {
                "enabled": self._enabled,
                "total_rules": len(self._rules),
                "categories": categories
            }

    def is_enabled(self) -> bool:
        """Check if ethics enforcement is enabled."""
        return self._enabled

    def enable(self) -> None:
        """Enable ethics enforcement."""
        self._enabled = True

    def disable(self) -> None:
        """Disable ethics enforcement (for testing only)."""
        self._enabled = False
        logger.warning("Ethics enforcement DISABLED")


# Global singleton instance
_enforcer: Optional[EthicsEnforcer] = None
_enforcer_lock = threading.Lock()


def _get_enforcer() -> EthicsEnforcer:
    """Get or create the global ethics enforcer."""
    global _enforcer
    if _enforcer is None:
        with _enforcer_lock:
            if _enforcer is None:
                _enforcer = EthicsEnforcer()
    return _enforcer


# Public API

def check_ethics(
    text: str,
    check_type: str = "query",
    context: Optional[Dict[str, Any]] = None
) -> EthicsResult:
    """
    Check text against ethics rules.

    Args:
        text: The text to check
        check_type: Type of check ("query" or "response")
        context: Optional context

    Returns:
        EthicsResult with action and violations
    """
    return _get_enforcer().check(text, check_type, context)


def is_ethics_enabled() -> bool:
    """Check if ethics enforcement is enabled."""
    return _get_enforcer().is_enabled()


def get_ethics_summary() -> Dict[str, Any]:
    """Get summary of ethics rules."""
    return _get_enforcer().get_rules_summary()


def reload_ethics_rules() -> None:
    """Reload ethics rules from config."""
    _get_enforcer().reload_rules()


def require_ethics_check(text: str, check_type: str = "query") -> None:
    """
    Require ethics check to pass, raise exception if blocked.

    Args:
        text: Text to check
        check_type: Type of check

    Raises:
        EthicsViolationError: If text violates blocking rules
    """
    result = check_ethics(text, check_type)
    if result.is_blocked:
        raise EthicsViolationError(
            message=result.blocked_response or "Request blocked by ethics rules",
            violations=result.violations
        )


class EthicsViolationError(Exception):
    """Raised when ethics check fails with blocking action."""

    def __init__(self, message: str, violations: List[EthicsViolation]):
        self.violations = violations
        super().__init__(message)


# Export public API
__all__ = [
    "EthicsAction",
    "EthicsSeverity",
    "EthicsViolation",
    "EthicsResult",
    "EthicsViolationError",
    "check_ethics",
    "is_ethics_enabled",
    "get_ethics_summary",
    "reload_ethics_rules",
    "require_ethics_check",
]
