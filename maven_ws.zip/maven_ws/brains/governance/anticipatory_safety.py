"""
Anticipatory Safety Checks with Consent Protocol
=================================================

This module provides proactive safety analysis that warns users BEFORE
potentially risky operations are executed. Instead of just blocking
dangerous actions, it:

1. Analyzes proposed actions for potential risks
2. Explains what could go wrong
3. Asks for explicit user consent before proceeding
4. Logs all safety decisions for audit

The consent protocol format:
"I'm about to do X, which could cause Y. Do you want me to proceed?"

This creates a human-in-the-loop safety layer that:
- Educates users about risks
- Gives users agency over risky operations
- Creates an audit trail
- Allows operations that would otherwise be blocked

Usage:
    from brains.governance.anticipatory_safety import (
        analyze_action_risk,
        request_consent,
        SafetyAnalysis,
        ConsentProtocol,
    )

    # Analyze an action
    analysis = analyze_action_risk("delete", {"path": "/important/file.txt"})

    # If risky, request consent
    if analysis.requires_consent:
        consent = request_consent(analysis)
        if consent.granted:
            # Proceed with action
            pass
"""

from __future__ import annotations

import json
import time
import hashlib
from dataclasses import dataclass, field, asdict
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Set, Tuple

from brains.maven_paths import get_reports_path


# Storage paths
SAFETY_LOG_PATH = get_reports_path("safety_decisions.jsonl")
CONSENT_CACHE_PATH = get_reports_path("consent_cache.json")


class RiskLevel(str, Enum):
    """Risk level classifications."""
    NONE = "none"           # No risk, proceed automatically
    LOW = "low"             # Minor risk, log only
    MEDIUM = "medium"       # Moderate risk, warn user
    HIGH = "high"           # High risk, require consent
    CRITICAL = "critical"   # Critical risk, require explicit confirmation


class RiskCategory(str, Enum):
    """Categories of risk."""
    DATA_LOSS = "data_loss"           # Could lose user data
    IRREVERSIBLE = "irreversible"     # Cannot be undone
    SECURITY = "security"             # Security implications
    PRIVACY = "privacy"               # Privacy implications
    RESOURCE = "resource"             # Resource consumption
    EXTERNAL = "external"             # External system effects
    FINANCIAL = "financial"           # Financial implications
    SYSTEM = "system"                 # System stability


@dataclass
class RiskFactor:
    """A specific risk factor identified in an action."""
    category: RiskCategory
    level: RiskLevel
    description: str
    mitigation: str = ""
    reversible: bool = True


@dataclass
class SafetyAnalysis:
    """Result of analyzing an action for safety risks."""
    action: str
    params: Dict[str, Any]
    timestamp: float = field(default_factory=time.time)

    # Risk assessment
    overall_risk: RiskLevel = RiskLevel.NONE
    risk_factors: List[RiskFactor] = field(default_factory=list)

    # Consent requirements
    requires_consent: bool = False
    consent_message: str = ""
    consent_options: List[str] = field(default_factory=list)

    # Analysis metadata
    analyzer_version: str = "1.0"
    analysis_duration_ms: int = 0

    def to_dict(self) -> Dict[str, Any]:
        result = asdict(self)
        result["risk_factors"] = [
            {**asdict(f), "category": f.category.value, "level": f.level.value}
            for f in self.risk_factors
        ]
        result["overall_risk"] = self.overall_risk.value
        return result


@dataclass
class ConsentRequest:
    """A request for user consent."""
    request_id: str
    analysis: SafetyAnalysis
    created_at: float = field(default_factory=time.time)

    # The message shown to user
    message: str = ""
    options: List[str] = field(default_factory=list)

    # Default is to NOT proceed (safe default)
    default_option: str = "no"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "request_id": self.request_id,
            "message": self.message,
            "options": self.options,
            "default_option": self.default_option,
            "created_at": self.created_at,
            "analysis": self.analysis.to_dict(),
        }


@dataclass
class ConsentResponse:
    """User's response to a consent request."""
    request_id: str
    granted: bool
    option_selected: str
    timestamp: float = field(default_factory=time.time)
    user_comment: str = ""

    # For audit
    session_id: Optional[str] = None
    user_id: Optional[str] = None


# =============================================================================
# Risk Analysis Rules
# =============================================================================

# Actions that always require consent
HIGH_RISK_ACTIONS = {
    "delete",
    "rm",
    "remove",
    "drop",
    "truncate",
    "destroy",
    "purge",
    "wipe",
    "format",
}

# File patterns that indicate sensitive files
SENSITIVE_FILE_PATTERNS = [
    ".env",
    ".secret",
    "password",
    "credential",
    "private",
    "key",
    ".pem",
    ".p12",
    "config",
    "settings",
    "id_rsa",
    "id_ed25519",
]

# Commands that have high impact
HIGH_IMPACT_COMMANDS = {
    "rm -rf",
    "sudo rm",
    "git push --force",
    "git reset --hard",
    "drop table",
    "drop database",
    "truncate table",
    "chmod 777",
    "chown",
    "kill -9",
    "pkill",
    "shutdown",
    "reboot",
    "mkfs",
    "fdisk",
    "dd if=",
}

# Operations that affect external systems
EXTERNAL_IMPACT_OPERATIONS = {
    "git push",
    "npm publish",
    "pip upload",
    "docker push",
    "deploy",
    "release",
    "publish",
    "broadcast",
    "email",
    "notify",
    "webhook",
    "api call",
}


class SafetyAnalyzer:
    """
    Analyzes actions for potential risks before execution.

    This is the core of the anticipatory safety system. It examines
    proposed actions and identifies what could go wrong.
    """

    def __init__(self):
        self._consent_cache: Dict[str, ConsentResponse] = {}
        self._custom_rules: List[Callable[[str, Dict], List[RiskFactor]]] = []
        self._load_consent_cache()

    def _load_consent_cache(self) -> None:
        """Load cached consent decisions."""
        if not CONSENT_CACHE_PATH.exists():
            return
        try:
            data = json.loads(CONSENT_CACHE_PATH.read_text())
            self._consent_cache = data.get("cache", {})
        except Exception:
            pass

    def _save_consent_cache(self) -> None:
        """Save consent decisions to cache."""
        try:
            CONSENT_CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
            data = {"cache": self._consent_cache, "updated_at": time.time()}
            CONSENT_CACHE_PATH.write_text(json.dumps(data))
        except Exception:
            pass

    def register_custom_rule(
        self,
        rule: Callable[[str, Dict], List[RiskFactor]]
    ) -> None:
        """Register a custom risk analysis rule."""
        self._custom_rules.append(rule)

    def analyze(
        self,
        action: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> SafetyAnalysis:
        """
        Analyze an action for potential risks.

        Args:
            action: The action type (e.g., "delete", "execute", "write")
            params: Action parameters (e.g., {"path": "/file.txt"})

        Returns:
            SafetyAnalysis with identified risks
        """
        start_time = time.time()
        params = params or {}

        analysis = SafetyAnalysis(
            action=action,
            params=params,
        )

        # Collect risk factors from all analyzers
        risk_factors = []

        # 1. Action-based analysis
        risk_factors.extend(self._analyze_action(action, params))

        # 2. Path-based analysis
        if "path" in params:
            risk_factors.extend(self._analyze_path(params["path"]))

        # 3. Command-based analysis
        if "command" in params or "cmd" in params:
            cmd = params.get("command") or params.get("cmd", "")
            risk_factors.extend(self._analyze_command(cmd))

        # 4. External impact analysis
        risk_factors.extend(self._analyze_external_impact(action, params))

        # 5. Custom rules
        for rule in self._custom_rules:
            try:
                risk_factors.extend(rule(action, params))
            except Exception:
                pass

        # De-duplicate risk factors
        seen = set()
        unique_factors = []
        for f in risk_factors:
            key = (f.category.value, f.description[:50])
            if key not in seen:
                seen.add(key)
                unique_factors.append(f)

        analysis.risk_factors = unique_factors

        # Calculate overall risk
        analysis.overall_risk = self._calculate_overall_risk(unique_factors)

        # Determine if consent is needed
        analysis.requires_consent = analysis.overall_risk in [
            RiskLevel.HIGH,
            RiskLevel.CRITICAL
        ]

        # Generate consent message if needed
        if analysis.requires_consent:
            analysis.consent_message = self._generate_consent_message(analysis)
            analysis.consent_options = ["yes", "no", "always allow", "abort"]

        analysis.analysis_duration_ms = int((time.time() - start_time) * 1000)

        return analysis

    def _analyze_action(self, action: str, params: Dict) -> List[RiskFactor]:
        """Analyze risk based on action type."""
        factors = []
        action_lower = action.lower()

        # Check for destructive actions
        if action_lower in HIGH_RISK_ACTIONS:
            factors.append(RiskFactor(
                category=RiskCategory.DATA_LOSS,
                level=RiskLevel.HIGH,
                description=f"'{action}' is a destructive operation",
                mitigation="Ensure you have a backup before proceeding",
                reversible=False,
            ))

        # Check for write operations
        if action_lower in ["write", "overwrite", "save", "modify", "edit"]:
            path = params.get("path", "")
            if path:
                factors.append(RiskFactor(
                    category=RiskCategory.DATA_LOSS,
                    level=RiskLevel.MEDIUM,
                    description=f"Will modify: {path}",
                    mitigation="Original content will be lost",
                    reversible=False,
                ))

        return factors

    def _analyze_path(self, path: str) -> List[RiskFactor]:
        """Analyze risk based on file path."""
        factors = []
        path_lower = path.lower()

        # Check for sensitive files
        for pattern in SENSITIVE_FILE_PATTERNS:
            if pattern in path_lower:
                factors.append(RiskFactor(
                    category=RiskCategory.SECURITY,
                    level=RiskLevel.HIGH,
                    description=f"Path contains sensitive pattern: {pattern}",
                    mitigation="Verify this file can be safely modified",
                ))
                break

        # Check for system paths
        system_paths = ["/etc", "/usr", "/bin", "/sbin", "/var", "/root", "C:\\Windows"]
        for sys_path in system_paths:
            if path.startswith(sys_path):
                factors.append(RiskFactor(
                    category=RiskCategory.SYSTEM,
                    level=RiskLevel.CRITICAL,
                    description=f"Path is a system location: {sys_path}",
                    mitigation="System files should not be modified",
                    reversible=False,
                ))
                break

        # Check for home directory critical files
        home_critical = [".bashrc", ".zshrc", ".profile", ".ssh", ".gnupg"]
        for critical in home_critical:
            if critical in path_lower:
                factors.append(RiskFactor(
                    category=RiskCategory.SECURITY,
                    level=RiskLevel.HIGH,
                    description=f"Path is a critical user file: {critical}",
                    mitigation="Modifying this could affect your shell or security",
                ))
                break

        return factors

    def _analyze_command(self, command: str) -> List[RiskFactor]:
        """Analyze risk based on shell command."""
        factors = []
        cmd_lower = command.lower()

        # Check for high-impact commands
        for high_impact in HIGH_IMPACT_COMMANDS:
            if high_impact in cmd_lower:
                factors.append(RiskFactor(
                    category=RiskCategory.IRREVERSIBLE,
                    level=RiskLevel.CRITICAL,
                    description=f"Command contains high-impact operation: {high_impact}",
                    mitigation="This operation may be irreversible",
                    reversible=False,
                ))
                break

        # Check for sudo
        if "sudo" in cmd_lower:
            factors.append(RiskFactor(
                category=RiskCategory.SECURITY,
                level=RiskLevel.HIGH,
                description="Command requires elevated privileges (sudo)",
                mitigation="Will run with root permissions",
            ))

        # Check for pipes to dangerous commands
        dangerous_pipes = ["| rm", "| dd", "| mkfs", "| bash", "| sh"]
        for pipe in dangerous_pipes:
            if pipe in cmd_lower:
                factors.append(RiskFactor(
                    category=RiskCategory.SECURITY,
                    level=RiskLevel.CRITICAL,
                    description=f"Command pipes to dangerous operation: {pipe}",
                    mitigation="Output is being sent to a destructive command",
                    reversible=False,
                ))
                break

        return factors

    def _analyze_external_impact(
        self,
        action: str,
        params: Dict
    ) -> List[RiskFactor]:
        """Analyze risk of external system impact."""
        factors = []
        action_lower = action.lower()

        # Check for external operations
        for ext_op in EXTERNAL_IMPACT_OPERATIONS:
            if ext_op in action_lower:
                factors.append(RiskFactor(
                    category=RiskCategory.EXTERNAL,
                    level=RiskLevel.HIGH,
                    description=f"Operation affects external systems: {ext_op}",
                    mitigation="Changes will be visible to others",
                    reversible=False,
                ))
                break

        # Check for network operations
        url = params.get("url") or params.get("endpoint")
        if url:
            factors.append(RiskFactor(
                category=RiskCategory.EXTERNAL,
                level=RiskLevel.MEDIUM,
                description=f"Will connect to: {url[:50]}",
                mitigation="Data will be sent/received from external server",
            ))

        return factors

    def _calculate_overall_risk(self, factors: List[RiskFactor]) -> RiskLevel:
        """Calculate overall risk from individual factors."""
        if not factors:
            return RiskLevel.NONE

        # Priority order
        priority = [
            RiskLevel.CRITICAL,
            RiskLevel.HIGH,
            RiskLevel.MEDIUM,
            RiskLevel.LOW,
            RiskLevel.NONE,
        ]

        # Find highest risk level
        highest = RiskLevel.NONE
        for factor in factors:
            if priority.index(factor.level) < priority.index(highest):
                highest = factor.level

        return highest

    def _generate_consent_message(self, analysis: SafetyAnalysis) -> str:
        """Generate a human-readable consent message."""
        parts = []

        # Opening
        parts.append(f"I'm about to perform: **{analysis.action}**")

        # Parameters
        if analysis.params:
            if "path" in analysis.params:
                parts.append(f"Target: `{analysis.params['path']}`")
            if "command" in analysis.params:
                cmd = analysis.params["command"]
                if len(cmd) > 100:
                    cmd = cmd[:100] + "..."
                parts.append(f"Command: `{cmd}`")

        # Risks
        if analysis.risk_factors:
            parts.append("\n**Potential risks:**")
            for factor in analysis.risk_factors[:3]:  # Top 3 risks
                symbol = "⚠️" if factor.level in [RiskLevel.HIGH, RiskLevel.CRITICAL] else "ℹ️"
                parts.append(f"  {symbol} {factor.description}")
                if factor.mitigation:
                    parts.append(f"     → {factor.mitigation}")

        # Question
        parts.append("\n**Do you want me to proceed?**")

        return "\n".join(parts)

    def has_cached_consent(
        self,
        action: str,
        params: Dict[str, Any]
    ) -> Optional[bool]:
        """Check if we have a cached consent decision."""
        # Create a hash of the action + params
        key = self._consent_key(action, params)

        cached = self._consent_cache.get(key)
        if cached:
            # Check if it's still valid (within 1 hour)
            if time.time() - cached.get("timestamp", 0) < 3600:
                return cached.get("granted")

        return None

    def cache_consent(
        self,
        action: str,
        params: Dict[str, Any],
        granted: bool,
        always_allow: bool = False,
    ) -> None:
        """Cache a consent decision."""
        key = self._consent_key(action, params)

        self._consent_cache[key] = {
            "granted": granted,
            "timestamp": time.time(),
            "always_allow": always_allow,
        }

        self._save_consent_cache()

    def _consent_key(self, action: str, params: Dict[str, Any]) -> str:
        """Generate a cache key for a consent decision."""
        data = f"{action}:{json.dumps(params, sort_keys=True)}"
        return hashlib.md5(data.encode()).hexdigest()[:16]


# =============================================================================
# Consent Protocol
# =============================================================================

class ConsentProtocol:
    """
    Handles the consent flow for risky operations.

    This implements the "I'm about to do X, which could cause Y, proceed?"
    pattern that keeps humans in the loop for risky operations.
    """

    def __init__(self, analyzer: Optional[SafetyAnalyzer] = None):
        self._analyzer = analyzer or SafetyAnalyzer()
        self._pending_requests: Dict[str, ConsentRequest] = {}

    def check_action(
        self,
        action: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> Tuple[bool, Optional[ConsentRequest]]:
        """
        Check if an action requires consent.

        Args:
            action: The action type
            params: Action parameters

        Returns:
            Tuple of (can_proceed_immediately, consent_request_if_needed)
        """
        params = params or {}

        # Check for cached consent
        cached = self._analyzer.has_cached_consent(action, params)
        if cached is not None:
            return (cached, None)

        # Analyze the action
        analysis = self._analyzer.analyze(action, params)

        # If no consent needed, proceed
        if not analysis.requires_consent:
            self._log_decision(action, params, "auto_approved", analysis.overall_risk.value)
            return (True, None)

        # Generate consent request
        request_id = f"consent_{int(time.time())}_{hashlib.md5(action.encode()).hexdigest()[:6]}"

        request = ConsentRequest(
            request_id=request_id,
            analysis=analysis,
            message=analysis.consent_message,
            options=analysis.consent_options,
        )

        self._pending_requests[request_id] = request

        return (False, request)

    def respond_to_consent(
        self,
        request_id: str,
        granted: bool,
        option: str = "",
        comment: str = "",
        session_id: Optional[str] = None,
    ) -> ConsentResponse:
        """
        Record a user's response to a consent request.

        Args:
            request_id: The consent request ID
            granted: Whether consent was granted
            option: Which option was selected
            comment: Any user comment
            session_id: Current session ID

        Returns:
            ConsentResponse object
        """
        request = self._pending_requests.get(request_id)

        response = ConsentResponse(
            request_id=request_id,
            granted=granted,
            option_selected=option or ("yes" if granted else "no"),
            user_comment=comment,
            session_id=session_id,
        )

        # Log the decision
        if request:
            self._log_decision(
                request.analysis.action,
                request.analysis.params,
                "user_approved" if granted else "user_denied",
                request.analysis.overall_risk.value,
                comment,
            )

            # Cache if "always allow" was selected
            if option == "always allow" and granted:
                self._analyzer.cache_consent(
                    request.analysis.action,
                    request.analysis.params,
                    granted=True,
                    always_allow=True,
                )

        # Clean up
        if request_id in self._pending_requests:
            del self._pending_requests[request_id]

        return response

    def _log_decision(
        self,
        action: str,
        params: Dict[str, Any],
        decision: str,
        risk_level: str,
        comment: str = "",
    ) -> None:
        """Log a safety decision for audit."""
        try:
            SAFETY_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)

            entry = {
                "timestamp": time.time(),
                "datetime": datetime.now().isoformat(),
                "action": action,
                "params": params,
                "decision": decision,
                "risk_level": risk_level,
                "comment": comment,
            }

            with open(SAFETY_LOG_PATH, "a") as f:
                f.write(json.dumps(entry) + "\n")

        except Exception:
            pass

    def get_pending_requests(self) -> List[ConsentRequest]:
        """Get all pending consent requests."""
        return list(self._pending_requests.values())


# =============================================================================
# Module-level Convenience Functions
# =============================================================================

_analyzer: Optional[SafetyAnalyzer] = None
_protocol: Optional[ConsentProtocol] = None


def get_analyzer() -> SafetyAnalyzer:
    """Get the singleton safety analyzer."""
    global _analyzer
    if _analyzer is None:
        _analyzer = SafetyAnalyzer()
    return _analyzer


def get_protocol() -> ConsentProtocol:
    """Get the singleton consent protocol."""
    global _protocol
    if _protocol is None:
        _protocol = ConsentProtocol(get_analyzer())
    return _protocol


def analyze_action_risk(
    action: str,
    params: Optional[Dict[str, Any]] = None,
) -> SafetyAnalysis:
    """Analyze an action for risks."""
    return get_analyzer().analyze(action, params)


def check_and_consent(
    action: str,
    params: Optional[Dict[str, Any]] = None,
) -> Tuple[bool, Optional[ConsentRequest]]:
    """Check if action can proceed or needs consent."""
    return get_protocol().check_action(action, params)


def request_consent(analysis: SafetyAnalysis) -> ConsentRequest:
    """Create a consent request from an analysis."""
    request_id = f"consent_{int(time.time())}"
    return ConsentRequest(
        request_id=request_id,
        analysis=analysis,
        message=analysis.consent_message,
        options=analysis.consent_options,
    )


def grant_consent(request_id: str, option: str = "yes") -> ConsentResponse:
    """Grant consent for a pending request."""
    return get_protocol().respond_to_consent(request_id, granted=True, option=option)


def deny_consent(request_id: str, comment: str = "") -> ConsentResponse:
    """Deny consent for a pending request."""
    return get_protocol().respond_to_consent(
        request_id, granted=False, option="no", comment=comment
    )


__all__ = [
    "SafetyAnalyzer",
    "SafetyAnalysis",
    "ConsentProtocol",
    "ConsentRequest",
    "ConsentResponse",
    "RiskLevel",
    "RiskCategory",
    "RiskFactor",
    "analyze_action_risk",
    "check_and_consent",
    "request_consent",
    "grant_consent",
    "deny_consent",
    "get_analyzer",
    "get_protocol",
]
