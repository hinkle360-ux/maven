"""
Repair Engine Analyzer Module

Analyzes test failures and system diagnostics to identify root causes and
determine repair strategies.

FULLY IMPLEMENTED: Failure analysis, pattern detection, NLU gap identification,
repair prioritization, risk estimation.
"""

from typing import Dict, List, Any, Optional
import re


# Failure type patterns
FAILURE_PATTERNS = {
    "nlu_pattern": [
        r"intent.*mismatch",
        r"entity.*not.*found",
        r"parse.*fail",
        r"routing.*error",
    ],
    "validation": [
        r"assertion.*fail",
        r"expected.*got",
        r"type.*error",
        r"validation.*fail",
    ],
    "storage": [
        r"memory.*error",
        r"storage.*fail",
        r"file.*not.*found",
        r"json.*decode",
    ],
    "generation": [
        r"llm.*error",
        r"generation.*fail",
        r"response.*empty",
        r"timeout",
    ],
}


def analyze_failure(failure_report: Dict[str, Any]) -> Dict[str, Any]:
    """
    Analyze a single test failure to identify root cause.

    Args:
        failure_report: Failure report from collector

    Returns:
        Dict containing:
        - root_cause: str (description of root cause)
        - affected_modules: List[str] (files/modules involved)
        - failure_type: str (nlu_pattern|validation|storage|generation)
        - confidence: float (0.0-1.0)
        - suggested_fix: str (high-level fix description)
    """
    failure_message = failure_report.get("failure_message", "")
    stack_trace = failure_report.get("stack_trace", "") or ""
    test_id = failure_report.get("test_id", "")

    failure_type = "unknown"
    confidence = 0.3
    combined_text = f"{failure_message} {stack_trace}".lower()

    for ftype, patterns in FAILURE_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, combined_text, re.IGNORECASE):
                failure_type = ftype
                confidence = 0.7
                break
        if failure_type != "unknown":
            break

    # Extract affected modules from stack trace
    affected_modules = []
    if stack_trace:
        file_matches = re.findall(r'File "([^"]+)"', stack_trace)
        for f in file_matches:
            if 'brains/' in f or 'maven' in f:
                parts = f.split('/')
                if parts:
                    affected_modules.append(parts[-1])

    suggested_fixes = {
        "nlu_pattern": "Add or update NLU pattern to handle this input",
        "validation": "Fix validation logic or update test expectations",
        "storage": "Check file permissions and memory tier configuration",
        "generation": "Review LLM configuration or add fallback response",
        "unknown": "Manual investigation required",
    }

    root_causes = {
        "nlu_pattern": "Intent detection or entity extraction failure",
        "validation": "Data validation or type checking failure",
        "storage": "Memory or file storage operation failure",
        "generation": "Response generation or LLM call failure",
        "unknown": f"Unknown failure in {test_id}",
    }

    return {
        "root_cause": root_causes.get(failure_type, f"Unknown failure in {test_id}"),
        "affected_modules": list(set(affected_modules))[:5],
        "failure_type": failure_type,
        "confidence": confidence,
        "suggested_fix": suggested_fixes.get(failure_type, "Manual investigation required"),
        "status": "implemented",
    }


def analyze_pattern_failures(failures: List[Dict[str, Any]]) -> Dict[str, Any]:
    """
    Analyze multiple failures to detect common patterns.

    Args:
        failures: List of failure reports

    Returns:
        Dict containing:
        - common_root_cause: str
        - affected_subsystem: str
        - failure_pattern: str
        - priority: str (high|medium|low)
    """
    if not failures:
        return {
            "common_root_cause": "No failures to analyze",
            "affected_subsystem": "",
            "failure_pattern": "",
            "priority": "low",
            "status": "implemented",
        }

    analyses = [analyze_failure(f) for f in failures]

    type_counts = {}
    module_counts = {}

    for analysis in analyses:
        ftype = analysis.get("failure_type", "unknown")
        type_counts[ftype] = type_counts.get(ftype, 0) + 1

        for mod in analysis.get("affected_modules", []):
            module_counts[mod] = module_counts.get(mod, 0) + 1

    common_type = max(type_counts.keys(), key=lambda k: type_counts[k]) if type_counts else "unknown"

    affected_subsystem = ""
    if module_counts:
        affected_subsystem = max(module_counts.keys(), key=lambda k: module_counts[k])

    total_failures = len(failures)
    if total_failures >= 10 or common_type in ["validation", "storage"]:
        priority = "high"
    elif total_failures >= 5:
        priority = "medium"
    else:
        priority = "low"

    failure_pattern = f"{type_counts.get(common_type, 0)} {common_type} failures"
    if affected_subsystem:
        failure_pattern += f" in {affected_subsystem}"

    return {
        "common_root_cause": f"Recurring {common_type} issues",
        "affected_subsystem": affected_subsystem,
        "failure_pattern": failure_pattern,
        "priority": priority,
        "failure_type_distribution": type_counts,
        "status": "implemented",
    }


def identify_nlu_pattern_gap(test_input: str, expected_intent: str, actual_intent: str) -> Dict[str, Any]:
    """
    Identify missing or incorrect NLU pattern matching.

    Args:
        test_input: The user input that failed
        expected_intent: What the intent should have been
        actual_intent: What intent was actually detected

    Returns:
        Dict containing:
        - missing_pattern: Optional[str]
        - incorrect_pattern: Optional[str]
        - suggested_pattern: str
        - pattern_location: str (file:line)
    """
    missing_pattern = None
    incorrect_pattern = None
    suggested_pattern = ""
    pattern_location = "brains/cognitive/integrator/agency_routing_patterns.py"

    if actual_intent == "unknown" or actual_intent == "":
        missing_pattern = f"Pattern for intent: {expected_intent}"
        suggested_pattern = f'("{test_input.lower()[:30]}", "{expected_intent}")'
    elif actual_intent != expected_intent:
        incorrect_pattern = f"Misrouted to {actual_intent} instead of {expected_intent}"
        suggested_pattern = f'# Add early pattern: ("{test_input.lower()[:30]}", "{expected_intent}")'

    words = test_input.lower().split()
    if len(words) >= 2:
        key_words = [w for w in words if len(w) > 3][:3]
        if key_words:
            suggested_pattern = f'Pattern keywords: {key_words} -> {expected_intent}'

    return {
        "missing_pattern": missing_pattern,
        "incorrect_pattern": incorrect_pattern,
        "suggested_pattern": suggested_pattern,
        "pattern_location": pattern_location,
        "test_input": test_input[:100],
        "expected_intent": expected_intent,
        "actual_intent": actual_intent,
        "status": "implemented",
    }


def prioritize_repairs(analyses: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Prioritize repair tasks based on impact and confidence.

    Args:
        analyses: List of failure analyses

    Returns:
        Sorted list of analyses (highest priority first)
    """
    type_priority = {
        "storage": 4,
        "validation": 3,
        "generation": 2,
        "nlu_pattern": 1,
        "unknown": 0,
    }

    def score_analysis(analysis: Dict[str, Any]) -> float:
        ftype = analysis.get("failure_type", "unknown")
        confidence = analysis.get("confidence", 0.0)
        base_score = type_priority.get(ftype, 0)
        return base_score + confidence

    sorted_analyses = sorted(analyses, key=score_analysis, reverse=True)

    for i, analysis in enumerate(sorted_analyses):
        analysis["priority_rank"] = i + 1

    return sorted_analyses


def estimate_repair_risk(analysis: Dict[str, Any]) -> str:
    """
    Estimate risk level of proposed repair.

    Args:
        analysis: Failure analysis with suggested fix

    Returns:
        Risk level: "low"|"medium"|"high"
    """
    failure_type = analysis.get("failure_type", "unknown")
    affected_modules = analysis.get("affected_modules", [])
    confidence = analysis.get("confidence", 0.0)

    high_risk_modules = ["governance", "safety", "ethics", "memory_librarian"]
    if any(mod in str(affected_modules).lower() for mod in high_risk_modules):
        return "high"

    if failure_type in ["storage", "validation"]:
        return "medium"

    if len(affected_modules) > 3:
        return "medium"

    if confidence < 0.5:
        return "medium"

    if failure_type == "nlu_pattern" and confidence >= 0.7:
        return "low"

    return "medium"
