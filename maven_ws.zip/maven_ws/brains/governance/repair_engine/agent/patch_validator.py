"""
Repair Engine Patch Validator Module

Validates proposed patches against Maven's spec bundle, coding rules,
and behavioral contracts to ensure patches maintain system integrity.

FULLY IMPLEMENTED: AST validation, dangerous import detection,
API signature checks, ethics filter verification, determinism checks.
"""

from typing import Dict, List, Any, Optional
import ast
import re

# Dangerous imports that should not appear in brains/
DANGEROUS_IMPORTS = {
    "subprocess", "os.system", "socket", "urllib.request",
    "requests", "httpx", "aiohttp", "websockets",
    "openai", "anthropic", "selenium", "playwright"
}

# Patterns that indicate governance bypass attempts
GOVERNANCE_BYPASS_PATTERNS = [
    r"ethics.*=.*False",
    r"governance.*=.*False",
    r"bypass.*policy",
    r"skip.*validation",
    r"disable.*safety",
    r"_PATCH_GENERATION_ENABLED\s*=\s*True",
]

# Non-deterministic patterns to detect
NON_DETERMINISTIC_PATTERNS = [
    r"random\.",
    r"uuid\.",
    r"time\.time\(\)",
    r"datetime\.now\(\)",
]


def _extract_code_from_diff(patch_diff: str) -> str:
    """Extract Python code from unified diff format."""
    lines = []
    for line in patch_diff.split('\n'):
        if line.startswith('+') and not line.startswith('+++'):
            lines.append(line[1:])
        elif line.startswith(' '):
            lines.append(line[1:])
    return '\n'.join(lines)


def _extract_modified_files(patch_diff: str) -> List[str]:
    """Extract list of files modified by the patch."""
    files = []
    for line in patch_diff.split('\n'):
        if line.startswith('+++'):
            file_path = line[4:].strip()
            if file_path.startswith('b/'):
                file_path = file_path[2:]
            files.append(file_path)
    return files


def validate_syntax(patch_diff: str) -> Dict[str, Any]:
    """
    Validate that patch contains syntactically valid Python code.

    Args:
        patch_diff: Code patch in unified diff format

    Returns:
        Dict containing:
        - valid: bool
        - syntax_errors: List[str]
    """
    code = _extract_code_from_diff(patch_diff)
    errors = []

    if not code.strip():
        return {
            "valid": True,
            "syntax_errors": [],
            "status": "implemented",
        }

    try:
        ast.parse(code)
    except SyntaxError as e:
        errors.append(f"Line {e.lineno}: {e.msg}")

    return {
        "valid": len(errors) == 0,
        "syntax_errors": errors,
        "status": "implemented",
    }


def validate_against_design_spec(patch_diff: str, design_spec: str) -> Dict[str, Any]:
    """
    Validate patch compliance with Maven's design specification.

    Args:
        patch_diff: Code patch
        design_spec: Content of maven_design.md

    Returns:
        Dict containing:
        - compliant: bool
        - violations: List[str]
        - principles_upheld: List[str]
    """
    violations = []
    principles_upheld = []
    code = _extract_code_from_diff(patch_diff)
    files = _extract_modified_files(patch_diff)

    # Check for dangerous imports in brains/ files
    for f in files:
        if 'brains/' in f and 'host_tools' not in f:
            for imp in DANGEROUS_IMPORTS:
                if f"import {imp}" in code or f"from {imp}" in code:
                    violations.append(f"Dangerous import '{imp}' in brain module {f}")

    # Check for __init__.py creation (forbidden per spec)
    if any('__init__.py' in f for f in files):
        violations.append("Creating __init__.py files is forbidden per build rules")

    # Check for service_api/handle pattern compliance
    if "def service_api" in code or "def handle" in code:
        if "-> Dict" in code or "-> dict" in code:
            principles_upheld.append("Service API follows Dict return type convention")
        else:
            violations.append("Service API must return Dict type")

    # Check for memory access patterns
    if "BrainMemory" in code:
        principles_upheld.append("Uses BrainMemory abstraction")

    # Check for direct host_tools imports in brains
    for f in files:
        if 'brains/' in f and 'host_tools' not in f:
            if "from host_tools" in code or "import host_tools" in code:
                violations.append(f"Direct host_tools import in brain module {f}")

    return {
        "compliant": len(violations) == 0,
        "violations": violations,
        "principles_upheld": principles_upheld,
        "status": "implemented",
    }


def validate_against_behavior_contracts(patch_diff: str, contracts: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate that patch doesn't violate behavioral contracts.

    Args:
        patch_diff: Code patch
        contracts: maven_behavior_contracts.json content

    Returns:
        Dict containing:
        - compliant: bool
        - violated_contracts: List[str]
        - affected_test_cases: List[str]
    """
    violated_contracts = []
    affected_test_cases = []
    code = _extract_code_from_diff(patch_diff)

    # Check for public API signature changes
    if contracts.get("public_apis"):
        for api in contracts["public_apis"]:
            api_name = api.get("name", "")
            if f"def {api_name}" in code:
                # Check if signature changed
                expected_sig = api.get("signature", "")
                if expected_sig and expected_sig not in code:
                    violated_contracts.append(f"API signature changed: {api_name}")
                    affected_test_cases.extend(api.get("test_cases", []))

    # Check for removal of required imports
    if contracts.get("required_imports"):
        for req_import in contracts["required_imports"]:
            if f"-import {req_import}" in patch_diff or f"-from {req_import}" in patch_diff:
                violated_contracts.append(f"Required import removed: {req_import}")

    # Check for ethics filter removal
    if "-ethics" in patch_diff.lower() and "filter" in patch_diff.lower():
        violated_contracts.append("Potential ethics filter removal detected")
        affected_test_cases.append("test_ethics_filter_active")

    return {
        "compliant": len(violated_contracts) == 0,
        "violated_contracts": violated_contracts,
        "affected_test_cases": affected_test_cases,
        "status": "implemented",
    }


def validate_no_governance_bypass(patch_diff: str) -> Dict[str, Any]:
    """
    Ensure patch doesn't bypass governance or policy checks.

    Args:
        patch_diff: Code patch

    Returns:
        Dict containing:
        - safe: bool
        - bypass_attempts: List[str]
        - policy_violations: List[str]
    """
    bypass_attempts = []
    policy_violations = []
    code = _extract_code_from_diff(patch_diff)

    # Check for governance bypass patterns
    for pattern in GOVERNANCE_BYPASS_PATTERNS:
        matches = re.findall(pattern, code, re.IGNORECASE)
        if matches:
            bypass_attempts.append(f"Pattern detected: {pattern}")

    # Check for disabling safety modules
    if "SUPPORTED = False" in code and "safety" in code.lower():
        policy_violations.append("Attempt to disable safety module")

    # Check for removing governance checks
    if "-if governance" in patch_diff or "-governance_check" in patch_diff:
        bypass_attempts.append("Governance check removal detected")

    # Check for ethics rule disabling
    if '"enabled": false' in code.lower() and "ethics" in patch_diff.lower():
        bypass_attempts.append("Ethics filter disabling detected")

    return {
        "safe": len(bypass_attempts) == 0 and len(policy_violations) == 0,
        "bypass_attempts": bypass_attempts,
        "policy_violations": policy_violations,
        "status": "implemented",
    }


def validate_determinism_preserved(patch_diff: str) -> Dict[str, Any]:
    """
    Validate that patch preserves deterministic behavior.

    Args:
        patch_diff: Code patch

    Returns:
        Dict containing:
        - deterministic: bool
        - non_deterministic_changes: List[str]
        - warnings: List[str]
    """
    non_deterministic_changes = []
    warnings = []
    code = _extract_code_from_diff(patch_diff)
    files = _extract_modified_files(patch_diff)

    # Check for non-deterministic patterns
    for pattern in NON_DETERMINISTIC_PATTERNS:
        matches = re.findall(pattern, code)
        if matches:
            # Some uses are acceptable (e.g., logging timestamps)
            warnings.append(f"Non-deterministic pattern: {pattern}")

    # Check if deterministic modules are being modified
    deterministic_modules = ["reasoning_brain", "language_brain", "self_model"]
    for f in files:
        for mod in deterministic_modules:
            if mod in f:
                # These modules should maintain deterministic behavior
                if "random" in code.lower():
                    non_deterministic_changes.append(f"Random usage in {mod}")

    return {
        "deterministic": len(non_deterministic_changes) == 0,
        "non_deterministic_changes": non_deterministic_changes,
        "warnings": warnings,
        "status": "implemented",
    }


def run_full_validation_suite(patch_diff: str, spec_bundle: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run complete validation suite on proposed patch.

    Args:
        patch_diff: Code patch
        spec_bundle: Maven's complete spec bundle

    Returns:
        Dict containing:
        - overall_valid: bool
        - syntax_check: Dict
        - design_compliance: Dict
        - contract_compliance: Dict
        - governance_check: Dict
        - determinism_check: Dict
        - recommendation: str
    """
    syntax_check = validate_syntax(patch_diff)
    design_compliance = validate_against_design_spec(
        patch_diff,
        spec_bundle.get("design_spec", "")
    )
    contract_compliance = validate_against_behavior_contracts(
        patch_diff,
        spec_bundle.get("behavior_contracts", {})
    )
    governance_check = validate_no_governance_bypass(patch_diff)
    determinism_check = validate_determinism_preserved(patch_diff)

    # Determine overall validity
    overall_valid = all([
        syntax_check.get("valid", False),
        design_compliance.get("compliant", False),
        contract_compliance.get("compliant", False),
        governance_check.get("safe", False),
        determinism_check.get("deterministic", False),
    ])

    # Generate recommendation
    if overall_valid:
        recommendation = "SAFE TO APPLY - All validations passed"
    else:
        issues = []
        if not syntax_check.get("valid"):
            issues.append("syntax errors")
        if not design_compliance.get("compliant"):
            issues.append("design violations")
        if not contract_compliance.get("compliant"):
            issues.append("contract violations")
        if not governance_check.get("safe"):
            issues.append("governance bypass attempts")
        if not determinism_check.get("deterministic"):
            issues.append("non-deterministic changes")
        recommendation = f"DO NOT APPLY - Issues: {', '.join(issues)}"

    return {
        "overall_valid": overall_valid,
        "syntax_check": syntax_check,
        "design_compliance": design_compliance,
        "contract_compliance": contract_compliance,
        "governance_check": governance_check,
        "determinism_check": determinism_check,
        "recommendation": recommendation,
        "status": "implemented",
    }


def get_validation_report(validation_result: Dict[str, Any]) -> str:
    """
    Generate human-readable validation report.

    Args:
        validation_result: Output from run_full_validation_suite()

    Returns:
        Formatted report string
    """
    lines = [
        "=" * 60,
        "PATCH VALIDATION REPORT",
        "=" * 60,
        "",
        f"Overall Status: {'VALID' if validation_result.get('overall_valid') else 'INVALID'}",
        f"Recommendation: {validation_result.get('recommendation', 'N/A')}",
        "",
        "--- Syntax Check ---",
    ]

    syntax = validation_result.get("syntax_check", {})
    lines.append(f"Valid: {syntax.get('valid', False)}")
    for err in syntax.get("syntax_errors", []):
        lines.append(f"  ERROR: {err}")

    lines.append("")
    lines.append("--- Design Compliance ---")
    design = validation_result.get("design_compliance", {})
    lines.append(f"Compliant: {design.get('compliant', False)}")
    for v in design.get("violations", []):
        lines.append(f"  VIOLATION: {v}")
    for p in design.get("principles_upheld", []):
        lines.append(f"  OK: {p}")

    lines.append("")
    lines.append("--- Contract Compliance ---")
    contract = validation_result.get("contract_compliance", {})
    lines.append(f"Compliant: {contract.get('compliant', False)}")
    for v in contract.get("violated_contracts", []):
        lines.append(f"  VIOLATION: {v}")

    lines.append("")
    lines.append("--- Governance Check ---")
    gov = validation_result.get("governance_check", {})
    lines.append(f"Safe: {gov.get('safe', False)}")
    for b in gov.get("bypass_attempts", []):
        lines.append(f"  BYPASS ATTEMPT: {b}")
    for p in gov.get("policy_violations", []):
        lines.append(f"  POLICY VIOLATION: {p}")

    lines.append("")
    lines.append("--- Determinism Check ---")
    det = validation_result.get("determinism_check", {})
    lines.append(f"Deterministic: {det.get('deterministic', False)}")
    for n in det.get("non_deterministic_changes", []):
        lines.append(f"  NON-DETERMINISTIC: {n}")
    for w in det.get("warnings", []):
        lines.append(f"  WARNING: {w}")

    lines.append("")
    lines.append("=" * 60)

    return "\n".join(lines)
