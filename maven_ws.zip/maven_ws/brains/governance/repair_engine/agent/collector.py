"""
Repair Engine Collector Module

Responsible for gathering failure reports, test results, and system diagnostics
to feed into the repair analysis pipeline.

FULLY IMPLEMENTED: Failure collection, test results gathering, system diagnostics,
spec bundle loading, recent changes tracking.
"""

from typing import Dict, List, Any, Optional
from pathlib import Path
import json
import time
import subprocess

from brains.maven_paths import get_maven_root, get_brains_path, get_reports_path


def collect_failure_report(test_id: str) -> Dict[str, Any]:
    """
    Collect detailed failure report for a specific test.

    Args:
        test_id: Unique identifier for the failed test

    Returns:
        Dict containing:
        - test_id: str
        - failure_message: str
        - expected_behavior: str
        - actual_behavior: str
        - stack_trace: Optional[str]
        - context: Dict[str, Any]
    """
    reports_path = get_reports_path()

    failure_report = {
        "test_id": test_id,
        "failure_message": "",
        "expected_behavior": "",
        "actual_behavior": "",
        "stack_trace": None,
        "context": {},
        "status": "implemented",
    }

    # Check for pytest failure report
    report_file = reports_path / "runs" / f"{test_id}_failure.json"
    if report_file.exists():
        try:
            with open(report_file, 'r') as f:
                data = json.load(f)
                failure_report.update(data)
        except Exception:
            pass

    # Also check generic test results
    results_file = reports_path / "runs" / "last_test_run.json"
    if results_file.exists():
        try:
            with open(results_file, 'r') as f:
                results = json.load(f)
                for test in results.get("tests", []):
                    if test.get("id") == test_id or test.get("name") == test_id:
                        failure_report["failure_message"] = test.get("message", "")
                        failure_report["stack_trace"] = test.get("traceback", "")
                        break
        except Exception:
            pass

    return failure_report


def collect_test_results(suite_name: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    Collect all test results from regression test harness.

    Args:
        suite_name: Optional filter for specific test suite

    Returns:
        List of test result dictionaries
    """
    results = []
    reports_path = get_reports_path()
    runs_path = reports_path / "runs"

    if not runs_path.exists():
        runs_path.mkdir(parents=True, exist_ok=True)
        return results

    # Look for existing result files
    for result_file in runs_path.glob("*.json"):
        try:
            with open(result_file, 'r') as f:
                data = json.load(f)
                if isinstance(data, dict) and "tests" in data:
                    for test in data["tests"]:
                        if suite_name is None or suite_name in str(test.get("name", "")):
                            results.append(test)
                elif isinstance(data, list):
                    results.extend(data)
        except Exception:
            continue

    return results


def collect_system_diagnostics() -> Dict[str, Any]:
    """
    Collect system-wide diagnostic information.

    Returns:
        Dict containing:
        - brain_health: Dict[str, Any]
        - memory_stats: Dict[str, Any]
        - pipeline_metrics: Dict[str, Any]
        - error_logs: List[str]
    """
    reports_path = get_reports_path()
    brains_path = get_brains_path()

    diagnostics = {
        "brain_health": {},
        "memory_stats": {},
        "pipeline_metrics": {},
        "error_logs": [],
        "timestamp": time.time(),
        "status": "implemented",
    }

    # Collect brain health
    cognitive_path = brains_path / "cognitive"
    if cognitive_path.exists():
        brain_dirs = [d for d in cognitive_path.iterdir() if d.is_dir()]
        diagnostics["brain_health"]["total_brains"] = len(brain_dirs)
        diagnostics["brain_health"]["brain_names"] = [d.name for d in brain_dirs[:20]]

    # Collect memory stats
    memory_files = {
        "qa_memory.jsonl": 0,
        "knowledge_graph.json": 0,
        "context_snapshot.json": 0,
    }

    for filename in memory_files:
        filepath = reports_path / filename
        if filepath.exists():
            if filename.endswith('.jsonl'):
                try:
                    with open(filepath, 'r') as f:
                        memory_files[filename] = sum(1 for _ in f)
                except Exception:
                    pass
            else:
                memory_files[filename] = filepath.stat().st_size

    diagnostics["memory_stats"] = memory_files

    # Collect error logs
    error_log = reports_path / "errors.log"
    if error_log.exists():
        try:
            with open(error_log, 'r') as f:
                lines = f.readlines()
                diagnostics["error_logs"] = [l.strip() for l in lines[-50:]]
        except Exception:
            pass

    # Collect governance logs
    gov_log = reports_path / "governance" / "log.jsonl"
    if gov_log.exists():
        try:
            with open(gov_log, 'r') as f:
                lines = list(f)
                diagnostics["pipeline_metrics"]["governance_events"] = len(lines)
        except Exception:
            pass

    return diagnostics


def collect_spec_bundle() -> Dict[str, Any]:
    """
    Collect Maven's specification bundle (design, contracts, rules).

    Returns:
        Dict containing:
        - design_spec: str (maven_design.md content)
        - behavior_contracts: Dict (maven_behavior_contracts.json)
        - coding_rules: Dict
    """
    spec_bundle = {
        "design_spec": "",
        "behavior_contracts": {},
        "coding_rules": {},
        "status": "implemented",
    }

    brains_path = get_brains_path()
    maven_root = get_maven_root()

    # Load design spec
    design_spec_paths = [
        brains_path / "domain_banks" / "specs" / "maven_design.md",
        maven_root / "BUILD_RULES.md",
        maven_root / "CLAUDE.md",
    ]

    for spec_path in design_spec_paths:
        if spec_path.exists():
            try:
                with open(spec_path, 'r') as f:
                    spec_bundle["design_spec"] += f"\n\n--- {spec_path.name} ---\n"
                    spec_bundle["design_spec"] += f.read()
            except Exception:
                pass

    # Load behavior contracts
    contracts_path = brains_path / "domain_banks" / "specs" / "maven_behavior_contracts.json"
    if contracts_path.exists():
        try:
            with open(contracts_path, 'r') as f:
                spec_bundle["behavior_contracts"] = json.load(f)
        except Exception:
            pass

    # Load ethics rules
    ethics_path = maven_root / "config" / "ethics_rules.json"
    if ethics_path.exists():
        try:
            with open(ethics_path, 'r') as f:
                spec_bundle["ethics_rules"] = json.load(f)
        except Exception:
            pass

    return spec_bundle


def collect_recent_changes(days: int = 7) -> List[Dict[str, Any]]:
    """
    Collect recent code changes that might correlate with failures.

    Args:
        days: Number of days back to check git history

    Returns:
        List of change records
    """
    changes = []
    maven_root = get_maven_root()

    try:
        result = subprocess.run(
            ["git", "log", f"--since={days} days ago", "--pretty=format:%H|%an|%s|%ad", "--date=short"],
            cwd=str(maven_root),
            capture_output=True,
            text=True,
            timeout=30
        )

        if result.returncode == 0:
            for line in result.stdout.strip().split('\n'):
                if line and '|' in line:
                    parts = line.split('|')
                    if len(parts) >= 4:
                        changes.append({
                            "commit": parts[0][:8],
                            "author": parts[1],
                            "message": parts[2],
                            "date": parts[3],
                        })

        # Get list of changed files
        if changes:
            result = subprocess.run(
                ["git", "diff", "--name-only", f"HEAD~{min(len(changes), 10)}"],
                cwd=str(maven_root),
                capture_output=True,
                text=True,
                timeout=30
            )

            if result.returncode == 0:
                changed_files = result.stdout.strip().split('\n')
                if changes:
                    changes[0]["changed_files"] = changed_files[:20]

    except Exception:
        pass

    return changes[:50]
