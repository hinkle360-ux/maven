"""
Repair Engine LLM Patch Planner Module

Uses LLM reasoning to plan code patches based on failure analysis.
This is the "intelligent" part of the repair agent that understands code
and Maven's spec bundle to propose fixes.

IMPLEMENTED: Rule-based patch planning with LLM fallback (when enabled).
IMPORTANT: LLM code generation is DISABLED by default for safety.
"""

from typing import Dict, List, Any, Optional
import re


# SAFETY MARKER: This module is DISABLED for self-modification by default
# The LLM patch generation is gated behind this flag
_PATCH_GENERATION_ENABLED = False


def is_patch_generation_enabled() -> bool:
    """
    Check if patch generation is enabled.

    Returns:
        False by default for safety
    """
    return _PATCH_GENERATION_ENABLED


def plan_patch(failure_analysis: Dict[str, Any], spec_bundle: Dict[str, Any]) -> Dict[str, Any]:
    """
    Plan a code patch based on failure analysis.
    Uses rule-based planning, not LLM generation.

    Args:
        failure_analysis: Output from analyzer module
        spec_bundle: Maven's design spec and behavior contracts

    Returns:
        Dict containing:
        - patch_plan: str (description of intended fix)
        - affected_files: List[str]
        - patch_type: str (pattern_add|logic_fix|refactor)
        - estimated_risk: str (low|medium|high)
        - confidence: float
    """
    failure_type = failure_analysis.get("failure_type", "unknown")
    affected_modules = failure_analysis.get("affected_modules", [])
    suggested_fix = failure_analysis.get("suggested_fix", "")

    # Rule-based patch type determination
    patch_type_map = {
        "nlu_pattern": "pattern_add",
        "validation": "logic_fix",
        "storage": "logic_fix",
        "generation": "refactor",
        "unknown": "unknown",
    }

    patch_type = patch_type_map.get(failure_type, "unknown")

    # Estimate risk based on affected modules
    high_risk_modules = ["governance", "safety", "ethics", "memory_librarian"]
    is_high_risk = any(mod in str(affected_modules).lower() for mod in high_risk_modules)

    estimated_risk = "high" if is_high_risk else ("medium" if patch_type == "logic_fix" else "low")

    # Generate patch plan description
    if failure_type == "nlu_pattern":
        patch_plan = f"Add new routing pattern to handle unrecognized input. {suggested_fix}"
        confidence = 0.8
    elif failure_type == "validation":
        patch_plan = f"Fix validation logic in affected modules: {affected_modules[:3]}. {suggested_fix}"
        confidence = 0.6
    elif failure_type == "storage":
        patch_plan = f"Repair storage operation or add error handling. {suggested_fix}"
        confidence = 0.5
    elif failure_type == "generation":
        patch_plan = f"Add fallback response path or fix generation parameters. {suggested_fix}"
        confidence = 0.4
    else:
        patch_plan = f"Manual investigation required. Suggested: {suggested_fix}"
        confidence = 0.2

    return {
        "patch_plan": patch_plan,
        "affected_files": affected_modules,
        "patch_type": patch_type,
        "estimated_risk": estimated_risk,
        "confidence": confidence,
        "status": "implemented",
        "llm_generated": False,  # Rule-based, not LLM
    }


def generate_patch_diff(patch_plan: Dict[str, Any]) -> str:
    """
    Generate actual code diff from patch plan.
    DISABLED for safety - returns empty string unless explicitly enabled.

    Args:
        patch_plan: Output from plan_patch()

    Returns:
        Unified diff format string (empty if generation disabled)
    """
    if not _PATCH_GENERATION_ENABLED:
        return ""

    # Would generate diff based on patch_plan
    # This is intentionally left as a no-op for safety
    return ""


def validate_patch_against_spec(patch_diff: str, spec_bundle: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validate that proposed patch complies with Maven's design spec.

    Args:
        patch_diff: Generated patch in diff format
        spec_bundle: Maven's spec bundle

    Returns:
        Dict containing:
        - compliant: bool
        - violations: List[str]
        - warnings: List[str]
        - recommendation: str
    """
    violations = []
    warnings = []

    if not patch_diff:
        return {
            "compliant": True,
            "violations": [],
            "warnings": ["No patch to validate"],
            "recommendation": "No action needed",
            "status": "implemented",
        }

    # Check for dangerous patterns
    dangerous_patterns = [
        (r"import subprocess", "Subprocess import detected"),
        (r"import os\s*\n", "OS import detected"),
        (r"eval\(", "Eval usage detected"),
        (r"exec\(", "Exec usage detected"),
        (r"__import__", "Dynamic import detected"),
    ]

    for pattern, message in dangerous_patterns:
        if re.search(pattern, patch_diff):
            violations.append(message)

    # Check ethics rules if available
    ethics_rules = spec_bundle.get("ethics_rules", {})
    if ethics_rules.get("enabled") and "bypass" in patch_diff.lower():
        violations.append("Potential governance bypass detected")

    # Generate recommendation
    if violations:
        recommendation = f"DO NOT APPLY - {len(violations)} violations found"
        compliant = False
    elif warnings:
        recommendation = f"Apply with caution - {len(warnings)} warnings"
        compliant = True
    else:
        recommendation = "Safe to apply"
        compliant = True

    return {
        "compliant": compliant,
        "violations": violations,
        "warnings": warnings,
        "recommendation": recommendation,
        "status": "implemented",
    }


def explain_patch(patch_diff: str) -> str:
    """
    Generate human-readable explanation of what the patch does.

    Args:
        patch_diff: Code patch in diff format

    Returns:
        Plain English explanation
    """
    if not patch_diff:
        return "No patch to explain."

    lines = patch_diff.split('\n')
    files_changed = []
    additions = 0
    deletions = 0

    for line in lines:
        if line.startswith('+++'):
            file_path = line[4:].strip()
            if file_path.startswith('b/'):
                file_path = file_path[2:]
            files_changed.append(file_path)
        elif line.startswith('+') and not line.startswith('+++'):
            additions += 1
        elif line.startswith('-') and not line.startswith('---'):
            deletions += 1

    explanation = f"This patch modifies {len(files_changed)} file(s):\n"
    for f in files_changed[:5]:
        explanation += f"  - {f}\n"

    explanation += f"\nChanges: +{additions} lines, -{deletions} lines\n"

    if additions > deletions:
        explanation += "Net effect: Adding new functionality"
    elif deletions > additions:
        explanation += "Net effect: Removing or simplifying code"
    else:
        explanation += "Net effect: Refactoring with no size change"

    return explanation


def estimate_patch_impact(patch_diff: str) -> Dict[str, Any]:
    """
    Estimate the impact and risk of applying the patch.

    Args:
        patch_diff: Code patch in diff format

    Returns:
        Dict containing:
        - files_changed: int
        - lines_added: int
        - lines_removed: int
        - subsystems_affected: List[str]
        - risk_level: str
    """
    if not patch_diff:
        return {
            "files_changed": 0,
            "lines_added": 0,
            "lines_removed": 0,
            "subsystems_affected": [],
            "risk_level": "low",
            "status": "implemented",
        }

    files_changed = set()
    lines_added = 0
    lines_removed = 0
    subsystems_affected = set()

    for line in patch_diff.split('\n'):
        if line.startswith('+++'):
            file_path = line[4:].strip()
            if file_path.startswith('b/'):
                file_path = file_path[2:]
            files_changed.add(file_path)

            # Detect subsystem
            if 'brains/cognitive' in file_path:
                subsystems_affected.add('cognitive')
            elif 'brains/governance' in file_path:
                subsystems_affected.add('governance')
            elif 'brains/memory' in file_path:
                subsystems_affected.add('memory')
            elif 'brains/agent' in file_path:
                subsystems_affected.add('agent')
            elif 'config/' in file_path:
                subsystems_affected.add('config')

        elif line.startswith('+') and not line.startswith('+++'):
            lines_added += 1
        elif line.startswith('-') and not line.startswith('---'):
            lines_removed += 1

    # Determine risk level
    high_risk_subsystems = {'governance', 'memory'}
    if subsystems_affected & high_risk_subsystems:
        risk_level = "high"
    elif len(files_changed) > 5 or lines_added + lines_removed > 100:
        risk_level = "medium"
    else:
        risk_level = "low"

    return {
        "files_changed": len(files_changed),
        "lines_added": lines_added,
        "lines_removed": lines_removed,
        "subsystems_affected": list(subsystems_affected),
        "risk_level": risk_level,
        "status": "implemented",
    }
