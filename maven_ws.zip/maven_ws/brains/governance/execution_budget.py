"""
Execution Budget Tracker
========================

Global execution budget and recursive depth tracking for AGI safety.

This module provides:
1. Global step counter across pipeline runs (prevents infinite operations)
2. Recursive depth tracking (prevents infinite recursion)
3. Session-based budget enforcement
4. Configurable limits with hard stops

CRITICAL SAFETY COMPONENT - This prevents runaway autonomous operations.

Usage:
    from brains.governance.execution_budget import (
        check_budget,
        increment_step,
        push_depth,
        pop_depth,
        reset_session,
        BudgetExceededError
    )

    # Before any operation
    check_budget()  # Raises BudgetExceededError if limits exceeded

    # Track recursive calls
    with depth_context("planner"):
        plan_result = planner.decompose(task)

    # Track steps
    increment_step("tool_execution")
"""

from __future__ import annotations

import json
import logging
import threading
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from brains.maven_paths import get_state_path
from typing import Any, Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# Paths
MAVEN_DIR = get_state_path()
BUDGET_LOG_PATH = MAVEN_DIR / "reports" / "budget_audit.jsonl"
BUDGET_CONFIG_PATH = MAVEN_DIR / "config" / "budget_limits.json"


class BudgetExceededError(Exception):
    """Raised when execution budget is exceeded."""

    def __init__(self, budget_type: str, current: int, limit: int, message: str = ""):
        self.budget_type = budget_type
        self.current = current
        self.limit = limit
        self.message = message or f"{budget_type} budget exceeded: {current}/{limit}"
        super().__init__(self.message)


class RecursionDepthExceededError(BudgetExceededError):
    """Raised when recursive depth limit is exceeded."""

    def __init__(self, current: int, limit: int, stack: List[str]):
        self.stack = stack
        super().__init__(
            budget_type="recursion_depth",
            current=current,
            limit=limit,
            message=f"Recursion depth exceeded: {current}/{limit}. Stack: {' -> '.join(stack[-5:])}"
        )


@dataclass
class BudgetLimits:
    """Configurable budget limits."""
    max_steps_per_session: int = 1000
    max_steps_per_minute: int = 100
    max_recursion_depth: int = 25
    max_brain_calls_per_query: int = 50
    max_tool_calls_per_query: int = 20
    max_loop_iterations: int = 100
    warning_threshold_percent: float = 0.8

    @classmethod
    def load(cls) -> "BudgetLimits":
        """Load limits from config file or return defaults."""
        try:
            if BUDGET_CONFIG_PATH.exists():
                data = json.loads(BUDGET_CONFIG_PATH.read_text(encoding="utf-8"))
                return cls(
                    max_steps_per_session=data.get("max_steps_per_session", 1000),
                    max_steps_per_minute=data.get("max_steps_per_minute", 100),
                    max_recursion_depth=data.get("max_recursion_depth", 25),
                    max_brain_calls_per_query=data.get("max_brain_calls_per_query", 50),
                    max_tool_calls_per_query=data.get("max_tool_calls_per_query", 20),
                    max_loop_iterations=data.get("max_loop_iterations", 100),
                    warning_threshold_percent=data.get("warning_threshold_percent", 0.8),
                )
        except Exception as e:
            logger.warning(f"Failed to load budget config: {e}")
        return cls()

    def save(self) -> None:
        """Save current limits to config file."""
        try:
            BUDGET_CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
            BUDGET_CONFIG_PATH.write_text(
                json.dumps({
                    "max_steps_per_session": self.max_steps_per_session,
                    "max_steps_per_minute": self.max_steps_per_minute,
                    "max_recursion_depth": self.max_recursion_depth,
                    "max_brain_calls_per_query": self.max_brain_calls_per_query,
                    "max_tool_calls_per_query": self.max_tool_calls_per_query,
                    "max_loop_iterations": self.max_loop_iterations,
                    "warning_threshold_percent": self.warning_threshold_percent,
                }, indent=2),
                encoding="utf-8"
            )
        except Exception as e:
            logger.error(f"Failed to save budget config: {e}")


@dataclass
class BudgetState:
    """Current budget state for tracking."""
    session_id: str = ""
    session_start: float = 0.0

    # Global counters
    total_steps: int = 0
    steps_this_minute: int = 0
    minute_start: float = 0.0

    # Per-query counters (reset on new query)
    query_id: str = ""
    brain_calls_this_query: int = 0
    tool_calls_this_query: int = 0

    # Recursion tracking
    recursion_depth: int = 0
    recursion_stack: List[str] = field(default_factory=list)

    # Loop tracking
    loop_counters: Dict[str, int] = field(default_factory=dict)

    # Warnings issued
    warnings_issued: List[str] = field(default_factory=list)


class ExecutionBudgetTracker:
    """
    Thread-safe execution budget tracker.

    Tracks:
    - Total steps per session
    - Steps per minute (rate limiting)
    - Recursive call depth
    - Brain/tool calls per query
    - Named loop iterations
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._limits = BudgetLimits.load()
        self._state = BudgetState(
            session_id=f"session_{int(time.time())}",
            session_start=time.time(),
            minute_start=time.time(),
        )
        self._enabled = True

    def reset_session(self, session_id: Optional[str] = None) -> None:
        """Reset all counters for a new session."""
        with self._lock:
            now = time.time()
            self._state = BudgetState(
                session_id=session_id or f"session_{int(now)}",
                session_start=now,
                minute_start=now,
            )
            self._log_event("session_reset", {"session_id": self._state.session_id})

    def reset_query(self, query_id: str) -> None:
        """Reset per-query counters for a new query."""
        with self._lock:
            self._state.query_id = query_id
            self._state.brain_calls_this_query = 0
            self._state.tool_calls_this_query = 0
            self._state.recursion_depth = 0
            self._state.recursion_stack.clear()
            self._state.loop_counters.clear()

    def enable(self) -> None:
        """Enable budget enforcement."""
        self._enabled = True

    def disable(self) -> None:
        """Disable budget enforcement (for testing only)."""
        self._enabled = False
        logger.warning("Execution budget enforcement DISABLED")

    def check_budget(self) -> Tuple[bool, str]:
        """
        Check if execution is within budget.

        Returns:
            Tuple of (allowed: bool, reason: str)
        """
        if not self._enabled:
            return True, "budget_enforcement_disabled"

        with self._lock:
            # Update minute counter
            now = time.time()
            if now - self._state.minute_start >= 60:
                self._state.minute_start = now
                self._state.steps_this_minute = 0

            # Check session limit
            if self._state.total_steps >= self._limits.max_steps_per_session:
                return False, f"session_step_limit_exceeded:{self._state.total_steps}/{self._limits.max_steps_per_session}"

            # Check rate limit
            if self._state.steps_this_minute >= self._limits.max_steps_per_minute:
                return False, f"rate_limit_exceeded:{self._state.steps_this_minute}/{self._limits.max_steps_per_minute}"

            # Check recursion depth
            if self._state.recursion_depth >= self._limits.max_recursion_depth:
                return False, f"recursion_depth_exceeded:{self._state.recursion_depth}/{self._limits.max_recursion_depth}"

            # Check brain calls per query
            if self._state.brain_calls_this_query >= self._limits.max_brain_calls_per_query:
                return False, f"brain_calls_exceeded:{self._state.brain_calls_this_query}/{self._limits.max_brain_calls_per_query}"

            # Check tool calls per query
            if self._state.tool_calls_this_query >= self._limits.max_tool_calls_per_query:
                return False, f"tool_calls_exceeded:{self._state.tool_calls_this_query}/{self._limits.max_tool_calls_per_query}"

            # Issue warnings at threshold
            self._check_warnings()

            return True, "within_budget"

    def require_budget(self) -> None:
        """Raise BudgetExceededError if budget exceeded."""
        ok, reason = self.check_budget()
        if not ok:
            self._log_event("budget_exceeded", {"reason": reason})
            raise BudgetExceededError(
                budget_type=reason.split(":")[0],
                current=self._state.total_steps,
                limit=self._limits.max_steps_per_session,
                message=f"Execution budget exceeded: {reason}"
            )

    def increment_step(self, step_type: str = "generic") -> int:
        """
        Increment step counter and return new count.

        Args:
            step_type: Type of step (generic, brain_call, tool_call)

        Returns:
            New total step count
        """
        with self._lock:
            self._state.total_steps += 1
            self._state.steps_this_minute += 1

            if step_type == "brain_call":
                self._state.brain_calls_this_query += 1
            elif step_type == "tool_call":
                self._state.tool_calls_this_query += 1

            return self._state.total_steps

    def push_depth(self, context: str) -> int:
        """
        Push onto recursion stack and return new depth.

        Args:
            context: Name/description of the recursive context

        Returns:
            New recursion depth

        Raises:
            RecursionDepthExceededError: If depth limit exceeded
        """
        with self._lock:
            self._state.recursion_depth += 1
            self._state.recursion_stack.append(context)

            if self._state.recursion_depth > self._limits.max_recursion_depth:
                self._log_event("recursion_exceeded", {
                    "depth": self._state.recursion_depth,
                    "limit": self._limits.max_recursion_depth,
                    "stack": self._state.recursion_stack[-10:]
                })
                raise RecursionDepthExceededError(
                    current=self._state.recursion_depth,
                    limit=self._limits.max_recursion_depth,
                    stack=self._state.recursion_stack.copy()
                )

            return self._state.recursion_depth

    def pop_depth(self) -> int:
        """
        Pop from recursion stack and return new depth.

        Returns:
            New recursion depth
        """
        with self._lock:
            if self._state.recursion_depth > 0:
                self._state.recursion_depth -= 1
            if self._state.recursion_stack:
                self._state.recursion_stack.pop()
            return self._state.recursion_depth

    def increment_loop(self, loop_name: str) -> int:
        """
        Increment a named loop counter and return new count.

        Args:
            loop_name: Identifier for the loop

        Returns:
            New iteration count for this loop

        Raises:
            BudgetExceededError: If loop iteration limit exceeded
        """
        with self._lock:
            current = self._state.loop_counters.get(loop_name, 0) + 1
            self._state.loop_counters[loop_name] = current

            if current > self._limits.max_loop_iterations:
                self._log_event("loop_exceeded", {
                    "loop": loop_name,
                    "iterations": current,
                    "limit": self._limits.max_loop_iterations
                })
                raise BudgetExceededError(
                    budget_type="loop_iterations",
                    current=current,
                    limit=self._limits.max_loop_iterations,
                    message=f"Loop '{loop_name}' exceeded iteration limit: {current}/{self._limits.max_loop_iterations}"
                )

            return current

    def reset_loop(self, loop_name: str) -> None:
        """Reset a named loop counter."""
        with self._lock:
            self._state.loop_counters.pop(loop_name, None)

    def get_state(self) -> Dict[str, Any]:
        """Get current budget state as a dictionary."""
        with self._lock:
            return {
                "session_id": self._state.session_id,
                "total_steps": self._state.total_steps,
                "steps_this_minute": self._state.steps_this_minute,
                "brain_calls_this_query": self._state.brain_calls_this_query,
                "tool_calls_this_query": self._state.tool_calls_this_query,
                "recursion_depth": self._state.recursion_depth,
                "recursion_stack": self._state.recursion_stack.copy(),
                "loop_counters": self._state.loop_counters.copy(),
                "limits": {
                    "max_steps_per_session": self._limits.max_steps_per_session,
                    "max_recursion_depth": self._limits.max_recursion_depth,
                    "max_brain_calls_per_query": self._limits.max_brain_calls_per_query,
                    "max_tool_calls_per_query": self._limits.max_tool_calls_per_query,
                },
                "enabled": self._enabled,
            }

    def get_remaining(self) -> Dict[str, int]:
        """Get remaining budget for each limit type."""
        with self._lock:
            return {
                "steps_session": max(0, self._limits.max_steps_per_session - self._state.total_steps),
                "steps_minute": max(0, self._limits.max_steps_per_minute - self._state.steps_this_minute),
                "recursion_depth": max(0, self._limits.max_recursion_depth - self._state.recursion_depth),
                "brain_calls": max(0, self._limits.max_brain_calls_per_query - self._state.brain_calls_this_query),
                "tool_calls": max(0, self._limits.max_tool_calls_per_query - self._state.tool_calls_this_query),
            }

    def _check_warnings(self) -> None:
        """Issue warnings when approaching limits."""
        threshold = self._limits.warning_threshold_percent

        # Session steps warning
        if (self._state.total_steps >= self._limits.max_steps_per_session * threshold
                and "session_steps" not in self._state.warnings_issued):
            self._state.warnings_issued.append("session_steps")
            logger.warning(
                f"Approaching session step limit: {self._state.total_steps}/{self._limits.max_steps_per_session}"
            )

        # Recursion depth warning
        if (self._state.recursion_depth >= self._limits.max_recursion_depth * threshold
                and "recursion_depth" not in self._state.warnings_issued):
            self._state.warnings_issued.append("recursion_depth")
            logger.warning(
                f"Approaching recursion limit: {self._state.recursion_depth}/{self._limits.max_recursion_depth}"
            )

    def _log_event(self, event_type: str, details: Dict[str, Any]) -> None:
        """Log budget event to audit file."""
        try:
            BUDGET_LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            record = {
                "ts": datetime.utcnow().isoformat() + "Z",
                "event": event_type,
                "session_id": self._state.session_id,
                "query_id": self._state.query_id,
                **details
            }
            with BUDGET_LOG_PATH.open("a", encoding="utf-8") as f:
                f.write(json.dumps(record) + "\n")
        except Exception as e:
            logger.error(f"Failed to log budget event: {e}")


# Global singleton instance
_tracker: Optional[ExecutionBudgetTracker] = None
_tracker_lock = threading.Lock()


def _get_tracker() -> ExecutionBudgetTracker:
    """Get or create the global budget tracker."""
    global _tracker
    if _tracker is None:
        with _tracker_lock:
            if _tracker is None:
                _tracker = ExecutionBudgetTracker()
    return _tracker


# Public API

def check_budget() -> Tuple[bool, str]:
    """Check if execution is within budget."""
    return _get_tracker().check_budget()


def require_budget() -> None:
    """Require execution to be within budget or raise BudgetExceededError."""
    _get_tracker().require_budget()


def increment_step(step_type: str = "generic") -> int:
    """Increment step counter and return new count."""
    return _get_tracker().increment_step(step_type)


def push_depth(context: str) -> int:
    """Push onto recursion stack and return new depth."""
    return _get_tracker().push_depth(context)


def pop_depth() -> int:
    """Pop from recursion stack and return new depth."""
    return _get_tracker().pop_depth()


def increment_loop(loop_name: str) -> int:
    """Increment a named loop counter."""
    return _get_tracker().increment_loop(loop_name)


def reset_loop(loop_name: str) -> None:
    """Reset a named loop counter."""
    _get_tracker().reset_loop(loop_name)


def reset_session(session_id: Optional[str] = None) -> None:
    """Reset all counters for a new session."""
    _get_tracker().reset_session(session_id)


def reset_query(query_id: str) -> None:
    """Reset per-query counters for a new query."""
    _get_tracker().reset_query(query_id)


def get_budget_state() -> Dict[str, Any]:
    """Get current budget state."""
    return _get_tracker().get_state()


def get_remaining_budget() -> Dict[str, int]:
    """Get remaining budget for each limit type."""
    return _get_tracker().get_remaining()


def enable_budget_enforcement() -> None:
    """Enable budget enforcement."""
    _get_tracker().enable()


def disable_budget_enforcement() -> None:
    """Disable budget enforcement (for testing only)."""
    _get_tracker().disable()


@contextmanager
def depth_context(context_name: str):
    """
    Context manager for tracking recursive depth.

    Usage:
        with depth_context("planner"):
            result = planner.decompose(task)
    """
    push_depth(context_name)
    try:
        yield
    finally:
        pop_depth()


@contextmanager
def loop_context(loop_name: str):
    """
    Context manager for tracking loop iterations.

    Usage:
        for item in items:
            with loop_context("process_items"):
                process(item)
    """
    increment_loop(loop_name)
    try:
        yield
    finally:
        pass  # Counter persists until explicit reset


# Export public API
__all__ = [
    "BudgetExceededError",
    "RecursionDepthExceededError",
    "check_budget",
    "require_budget",
    "increment_step",
    "push_depth",
    "pop_depth",
    "increment_loop",
    "reset_loop",
    "reset_session",
    "reset_query",
    "get_budget_state",
    "get_remaining_budget",
    "enable_budget_enforcement",
    "disable_budget_enforcement",
    "depth_context",
    "loop_context",
]
