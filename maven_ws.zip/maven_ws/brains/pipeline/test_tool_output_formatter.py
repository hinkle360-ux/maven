"""
test_tool_output_formatter.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Tests for the tool output formatter module.

Run with: python -m unittest brains.pipeline.test_tool_output_formatter -v
"""

import unittest

from brains.pipeline.tool_output_formatter import (
    format_tool_output,
    format_grok_session_output,
    format_time_tool_output,
    format_shell_tool_output,
    validate_user_facing_content,
    ensure_string_output,
    register_formatter,
    get_formatter,
)


class TestFormatToolOutput(unittest.TestCase):
    """Tests for generic format_tool_output function."""

    def test_string_output_passed_through(self):
        result = format_tool_output("test_tool", "Hello world")
        self.assertEqual(result, "Hello world")

    def test_empty_string_returns_task_completed(self):
        result = format_tool_output("test_tool", "")
        self.assertEqual(result, "Task completed.")

    def test_dict_with_recap_extracts_recap(self):
        output = {"status": "completed", "recap": "Session completed successfully."}
        result = format_tool_output("grok", output)
        self.assertEqual(result, "Session completed successfully.")

    def test_dict_with_text_extracts_text(self):
        output = {"status": "success", "text": "Here is the answer."}
        result = format_tool_output("some_tool", output)
        self.assertEqual(result, "Here is the answer.")

    def test_dict_with_answer_extracts_answer(self):
        output = {"answer": "42 is the answer."}
        result = format_tool_output("reasoning", output)
        self.assertEqual(result, "42 is the answer.")

    def test_dict_success_status_no_message(self):
        output = {"status": "success"}
        result = format_tool_output("tool", output)
        self.assertEqual(result, "Task completed successfully.")

    def test_dict_error_status(self):
        output = {"status": "error", "error": "Something went wrong"}
        result = format_tool_output("tool", output)
        self.assertEqual(result, "Error: Something went wrong")

    def test_dict_not_implemented(self):
        output = {"status": "not_implemented", "output": "Feature coming soon."}
        result = format_tool_output("tool", output)
        self.assertEqual(result, "Feature coming soon.")

    def test_list_of_strings(self):
        output = ["item1", "item2", "item3"]
        result = format_tool_output("tool", output)
        self.assertIn("item1", result)
        self.assertIn("item2", result)

    def test_empty_list(self):
        result = format_tool_output("tool", [])
        self.assertEqual(result, "No results found.")


class TestRawDictDetection(unittest.TestCase):
    """Tests for detecting leaked raw dict output."""

    def test_python_dict_literal_detected(self):
        raw = "{'status': 'completed', 'session_id': 'abc123'}"
        result = format_tool_output("tool", raw)
        self.assertEqual(result, "Task completed successfully.")

    def test_json_dict_detected(self):
        raw = '{"status": "success", "ok": true}'
        result = format_tool_output("tool", raw)
        self.assertEqual(result, "Task completed successfully.")

    def test_internal_field_pattern_detected(self):
        raw = "Result: 'session_id': 12345"
        result = format_tool_output("tool", raw)
        self.assertEqual(result, "Task completed successfully.")


class TestGrokSessionFormatter(unittest.TestCase):
    """Tests for Grok session output formatting."""

    def test_string_input_passed_through(self):
        result = format_grok_session_output("Session completed with insights.")
        self.assertEqual(result, "Session completed with insights.")

    def test_dict_with_recap(self):
        output = {
            "status": "completed",
            "topic": "AI",
            "recap": "## Grok Session\n\nGreat discussion!"
        }
        result = format_grok_session_output(output)
        self.assertEqual(result, "## Grok Session\n\nGreat discussion!")

    def test_dict_completed_without_recap(self):
        output = {
            "status": "completed",
            "topic": "medicine",
            "facts_stored": 5
        }
        result = format_grok_session_output(output)
        self.assertIn("medicine", result)
        self.assertIn("5", result)

    def test_dict_aborted(self):
        output = {
            "status": "aborted",
            "topic": "physics",
            "facts_stored": 2
        }
        result = format_grok_session_output(output)
        self.assertIn("physics", result)
        self.assertIn("ended early", result)

    def test_dict_error(self):
        output = {
            "status": "error",
            "error_message": "Connection timeout"
        }
        result = format_grok_session_output(output)
        self.assertIn("error", result.lower())
        self.assertIn("Connection timeout", result)


class TestTimeToolFormatter(unittest.TestCase):
    """Tests for time tool output formatting."""

    def test_formatted_response(self):
        output = {
            "status": "success",
            "formatted_response": "The time is 3:45 PM."
        }
        result = format_time_tool_output(output)
        self.assertEqual(result, "The time is 3:45 PM.")

    def test_payload_with_formatted(self):
        output = {
            "status": "success",
            "output": {"formatted": "It's 3:45 PM"}
        }
        result = format_time_tool_output(output)
        self.assertEqual(result, "It's 3:45 PM")


class TestShellToolFormatter(unittest.TestCase):
    """Tests for shell tool output formatting."""

    def test_success_with_stdout(self):
        output = {
            "status": "success",
            "output": "file1.txt\nfile2.txt\n"
        }
        result = format_shell_tool_output(output)
        self.assertIn("file1.txt", result)

    def test_success_no_output(self):
        output = {
            "status": "success",
            "output": ""
        }
        result = format_shell_tool_output(output)
        self.assertEqual(result, "Command executed successfully.")

    def test_error_with_message(self):
        output = {
            "status": "error",
            "error": "Command not found"
        }
        result = format_shell_tool_output(output)
        self.assertIn("Error:", result)
        self.assertIn("Command not found", result)


class TestValidateUserFacingContent(unittest.TestCase):
    """Tests for content validation."""

    def test_valid_content_passes(self):
        is_valid, result = validate_user_facing_content("Hello, this is a valid response.")
        self.assertTrue(is_valid)
        self.assertEqual(result, "Hello, this is a valid response.")

    def test_empty_content_fails(self):
        is_valid, result = validate_user_facing_content("")
        self.assertFalse(is_valid)

    def test_raw_dict_fails(self):
        is_valid, result = validate_user_facing_content("{'status': 'ok'}")
        self.assertFalse(is_valid)

    def test_traceback_fails(self):
        is_valid, result = validate_user_facing_content("Traceback (most recent call last):\n  File...")
        self.assertFalse(is_valid)


class TestEnsureStringOutput(unittest.TestCase):
    """Tests for ensure_string_output main entry point."""

    def test_valid_string_returned(self):
        result = ensure_string_output("This is a valid answer.", "tool")
        self.assertEqual(result, "This is a valid answer.")

    def test_dict_formatted(self):
        result = ensure_string_output({"recap": "Session done."}, "grok")
        self.assertEqual(result, "Session done.")

    def test_invalid_content_returns_fallback(self):
        result = ensure_string_output("{'raw': 'dict'}", "tool")
        self.assertEqual(result, "Task completed successfully.")


class TestFormatterRegistry(unittest.TestCase):
    """Tests for formatter registration."""

    def test_register_and_get_formatter(self):
        def custom_formatter(output):
            return f"Custom: {output}"

        register_formatter("custom_tool", custom_formatter)
        formatter = get_formatter("custom_tool")

        self.assertIsNotNone(formatter)
        self.assertEqual(formatter("test"), "Custom: test")

    def test_get_unknown_formatter_returns_none(self):
        formatter = get_formatter("nonexistent_tool")
        self.assertIsNone(formatter)

    def test_custom_formatter_used_in_format_tool_output(self):
        def my_formatter(output):
            return f"Formatted: {output}"

        register_formatter("my_tool", my_formatter)
        result = format_tool_output("my_tool", "data")
        self.assertEqual(result, "Formatted: data")


if __name__ == "__main__":
    unittest.main()
