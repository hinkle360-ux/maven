"""
test_blackboard.py
~~~~~~~~~~~~~~~~~~

Tests for the lane-based Blackboard abstraction.

Run with: python -m pytest brains/pipeline/test_blackboard.py -v
"""

import unittest
from datetime import datetime

from brains.pipeline.blackboard import (
    Blackboard,
    BlackboardEntry,
    STANDARD_LANES,
    create_blackboard,
    create_blackboard_from_context,
)


class TestBlackboardEntry(unittest.TestCase):
    """Tests for BlackboardEntry dataclass."""

    def test_entry_creation(self):
        """Test creating a blackboard entry."""
        entry = BlackboardEntry(
            id="test-1",
            owner="test_owner",
            lane="tool_results",
            visibility="internal",
            payload={"data": "value"},
            seq_id=1,
        )
        self.assertEqual(entry.id, "test-1")
        self.assertEqual(entry.owner, "test_owner")
        self.assertEqual(entry.lane, "tool_results")
        self.assertEqual(entry.visibility, "internal")
        self.assertEqual(entry.payload, {"data": "value"})
        self.assertEqual(entry.seq_id, 1)

    def test_entry_is_user_facing(self):
        """Test visibility checks."""
        internal = BlackboardEntry(
            id="1", owner="x", lane="tool_results",
            visibility="internal", payload=None, seq_id=1
        )
        user_facing = BlackboardEntry(
            id="2", owner="x", lane="answer_candidates",
            visibility="user_facing", payload=None, seq_id=2
        )

        self.assertFalse(internal.is_user_facing())
        self.assertTrue(internal.is_internal())
        self.assertTrue(user_facing.is_user_facing())
        self.assertFalse(user_facing.is_internal())

    def test_entry_to_dict(self):
        """Test serialization to dict."""
        entry = BlackboardEntry(
            id="test-1",
            owner="test",
            lane="telemetry",
            visibility="internal",
            payload="data",
            seq_id=1,
            tags=("tag1", "tag2"),
        )
        d = entry.to_dict()
        self.assertEqual(d["id"], "test-1")
        self.assertEqual(d["tags"], ["tag1", "tag2"])
        self.assertIn("timestamp", d)


class TestBlackboard(unittest.TestCase):
    """Tests for Blackboard class."""

    def setUp(self):
        """Create fresh blackboard for each test."""
        self.bb = Blackboard()

    def test_standard_lanes_exist(self):
        """Test that all standard lanes are initialized."""
        for lane in STANDARD_LANES:
            entries = self.bb.get_lane(lane)
            self.assertIsInstance(entries, list)
            self.assertEqual(len(entries), 0)

    def test_add_entry_to_valid_lane(self):
        """Test adding entry to a valid lane."""
        entry = self.bb.add_entry(
            owner="test",
            lane="tool_results",
            visibility="internal",
            payload={"key": "value"},
        )
        self.assertIsNotNone(entry.id)
        self.assertEqual(entry.owner, "test")
        self.assertEqual(entry.lane, "tool_results")

    def test_add_entry_to_invalid_lane_raises(self):
        """Test that adding to invalid lane raises ValueError."""
        with self.assertRaises(ValueError) as ctx:
            self.bb.add_entry(
                owner="test",
                lane="invalid_lane",
                visibility="internal",
                payload=None,
            )
        self.assertIn("invalid_lane", str(ctx.exception))

    def test_sequence_numbers_increment(self):
        """Test that sequence numbers increment correctly."""
        e1 = self.bb.add_entry("a", "telemetry", "internal", "1")
        e2 = self.bb.add_entry("b", "telemetry", "internal", "2")
        e3 = self.bb.add_entry("c", "telemetry", "internal", "3")

        self.assertEqual(e1.seq_id, 1)
        self.assertEqual(e2.seq_id, 2)
        self.assertEqual(e3.seq_id, 3)

    def test_get_entries_by_lane(self):
        """Test filtering entries by lane."""
        self.bb.add_entry("a", "tool_results", "internal", "tool1")
        self.bb.add_entry("b", "answer_candidates", "user_facing", "answer1")
        self.bb.add_entry("c", "tool_results", "internal", "tool2")

        tool_entries = self.bb.get_entries(lane="tool_results")
        self.assertEqual(len(tool_entries), 2)

        answer_entries = self.bb.get_entries(lane="answer_candidates")
        self.assertEqual(len(answer_entries), 1)

    def test_get_entries_by_visibility(self):
        """Test filtering entries by visibility."""
        self.bb.add_entry("a", "tool_results", "internal", "internal1")
        self.bb.add_entry("b", "answer_candidates", "user_facing", "uf1")
        self.bb.add_entry("c", "telemetry", "internal", "internal2")

        internal = self.bb.get_internal()
        self.assertEqual(len(internal), 2)

        user_facing = self.bb.get_user_facing()
        self.assertEqual(len(user_facing), 1)

    def test_get_entries_by_owner(self):
        """Test filtering entries by owner."""
        self.bb.add_entry("grok_tool", "tool_results", "internal", "1")
        self.bb.add_entry("time_tool", "tool_results", "internal", "2")
        self.bb.add_entry("grok_tool", "answer_candidates", "user_facing", "3")

        grok_entries = self.bb.get_entries(owner="grok_tool")
        self.assertEqual(len(grok_entries), 2)

    def test_get_latest(self):
        """Test getting the latest entry."""
        self.bb.add_entry("a", "tool_results", "internal", "first")
        self.bb.add_entry("b", "tool_results", "internal", "second")
        self.bb.add_entry("c", "tool_results", "internal", "third")

        latest = self.bb.get_latest(lane="tool_results")
        self.assertEqual(latest.payload, "third")

    def test_get_user_facing_answer_string(self):
        """Test getting user-facing answer when payload is string."""
        self.bb.add_entry(
            owner="compositor",
            lane="answer_candidates",
            visibility="user_facing",
            payload="This is the answer.",
        )

        answer = self.bb.get_user_facing_answer()
        self.assertEqual(answer, "This is the answer.")

    def test_get_user_facing_answer_dict_extracts_text(self):
        """Test that dict payloads are handled safely."""
        self.bb.add_entry(
            owner="test",
            lane="answer_candidates",
            visibility="user_facing",
            payload={"text": "Extracted text", "confidence": 0.9},
        )

        answer = self.bb.get_user_facing_answer()
        self.assertEqual(answer, "Extracted text")

    def test_get_user_facing_answer_none_when_empty(self):
        """Test that None is returned when no answer exists."""
        answer = self.bb.get_user_facing_answer()
        self.assertIsNone(answer)


class TestBlackboardHelpers(unittest.TestCase):
    """Tests for helper methods."""

    def setUp(self):
        self.bb = Blackboard()

    def test_add_tool_result(self):
        """Test the tool result helper."""
        entry = self.bb.add_tool_result(
            owner="grok_tool",
            payload={"status": "success", "data": "raw"},
        )

        self.assertEqual(entry.lane, "tool_results")
        self.assertEqual(entry.visibility, "internal")
        self.assertEqual(entry.owner, "grok_tool")

    def test_add_answer_candidate(self):
        """Test the answer candidate helper."""
        entry = self.bb.add_answer_candidate(
            owner="compositor",
            text="Formatted answer here.",
            confidence=0.95,
        )

        self.assertEqual(entry.lane, "answer_candidates")
        self.assertEqual(entry.visibility, "user_facing")
        self.assertEqual(entry.payload, "Formatted answer here.")

    def test_add_answer_candidate_rejects_non_string(self):
        """Test that answer candidate rejects non-string text."""
        with self.assertRaises(TypeError) as ctx:
            self.bb.add_answer_candidate(
                owner="test",
                text={"this": "is a dict"},  # Should fail
            )
        self.assertIn("string", str(ctx.exception))

    def test_set_user_input(self):
        """Test setting user input."""
        entry = self.bb.set_user_input(
            original_query="What time is it?",
            normalized_text="what time is it",
            intent="time_query",
        )

        self.assertEqual(entry.lane, "user_input")
        self.assertEqual(entry.payload["original_query"], "What time is it?")
        self.assertEqual(entry.payload["intent"], "time_query")

    def test_get_user_input(self):
        """Test retrieving user input."""
        self.bb.set_user_input("Hello world")
        ui = self.bb.get_user_input()

        self.assertEqual(ui["original_query"], "Hello world")

    def test_add_planning_decision(self):
        """Test recording planning decisions."""
        entry = self.bb.add_planning_decision(
            owner="integrator",
            decision_type="agency_routing",
            decision={"tool": "grok_tool", "method": "run"},
            reason="Matched Grok pattern",
        )

        self.assertEqual(entry.lane, "planning")
        self.assertEqual(entry.visibility, "internal")


class TestBlackboardMigration(unittest.TestCase):
    """Tests for migrating from legacy context."""

    def test_create_from_empty_context(self):
        """Test creating blackboard from empty context."""
        bb = create_blackboard_from_context({})
        self.assertIsInstance(bb, Blackboard)

    def test_create_from_context_with_query(self):
        """Test migrating user query from context."""
        ctx = {
            "original_query": "What is the weather?",
            "normalized_text": "what is the weather",
        }
        bb = create_blackboard_from_context(ctx)

        ui = bb.get_user_input()
        self.assertEqual(ui["original_query"], "What is the weather?")

    def test_create_from_context_with_agency(self):
        """Test migrating agency routing from context."""
        ctx = {
            "agency_tool": "grok_tool",
            "agency_method": "run",
            "agency_args": {"topic": "AI"},
            "bypass_teacher": True,
        }
        bb = create_blackboard_from_context(ctx)

        planning = bb.get_entries(lane="planning")
        self.assertEqual(len(planning), 1)
        self.assertEqual(planning[0].payload["decision"]["tool"], "grok_tool")


class TestBlackboardSerialization(unittest.TestCase):
    """Tests for blackboard serialization."""

    def test_to_dict(self):
        """Test serializing entire blackboard."""
        bb = Blackboard()
        bb.add_entry("a", "tool_results", "internal", "data1")
        bb.add_entry("b", "answer_candidates", "user_facing", "answer")

        d = bb.to_dict()
        self.assertIn("lanes", d)
        self.assertIn("seq_counter", d)
        self.assertEqual(d["seq_counter"], 2)

    def test_get_summary(self):
        """Test getting entry count summary."""
        bb = Blackboard()
        bb.add_entry("a", "tool_results", "internal", "1")
        bb.add_entry("b", "tool_results", "internal", "2")
        bb.add_entry("c", "telemetry", "internal", "3")

        summary = bb.get_summary()
        self.assertEqual(summary["tool_results"], 2)
        self.assertEqual(summary["telemetry"], 1)
        self.assertEqual(summary["answer_candidates"], 0)


if __name__ == "__main__":
    unittest.main()
