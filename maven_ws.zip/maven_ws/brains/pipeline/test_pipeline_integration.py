"""
test_pipeline_integration.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Tests for the pipeline integration module.

Run with: python -m unittest brains.pipeline.test_pipeline_integration -v
"""

import unittest

from brains.pipeline.pipeline_integration import (
    PipelineContext,
    create_pipeline_context,
    get_current_pipeline_context,
    set_current_pipeline_context,
    extract_final_answer,
    cleanup_pipeline_context,
)


class TestPipelineContext(unittest.TestCase):
    """Tests for PipelineContext class."""

    def test_create_initializes_blackboard(self):
        ctx = PipelineContext.create("What time is it?")

        self.assertEqual(ctx.original_query, "What time is it?")
        self.assertIsNotNone(ctx.blackboard)

        # Check blackboard has user input
        user_input = ctx.blackboard.get_user_input()
        self.assertEqual(user_input["original_query"], "What time is it?")

    def test_create_with_normalized(self):
        ctx = PipelineContext.create(
            query="What time is it?",
            normalized="what time is it",
            intent="time_query",
        )

        self.assertEqual(ctx.normalized_query, "what time is it")
        self.assertEqual(ctx.intent, "time_query")

    def test_set_routing(self):
        ctx = PipelineContext.create("test")
        ctx.set_routing(
            route="action_engine",
            agency_tool="time_now",
            bypass_teacher=True,
        )

        self.assertEqual(ctx.routed_to, "action_engine")
        self.assertEqual(ctx.agency_tool, "time_now")
        self.assertTrue(ctx.bypass_teacher)

        # Check planning entry in blackboard
        planning = ctx.blackboard.get_entries(lane="planning")
        self.assertEqual(len(planning), 1)
        self.assertEqual(planning[0].payload["decision"]["route"], "action_engine")

    def test_record_stage(self):
        ctx = PipelineContext.create("test")
        ctx.record_stage("stage_5", {"routing": "action_engine"})
        ctx.record_stage("stage_6", {"tool_executed": True})

        self.assertEqual(ctx.current_stage, "stage_6")
        self.assertEqual(ctx.completed_stages, ["stage_5", "stage_6"])

        # Check telemetry entries
        telemetry = ctx.blackboard.get_entries(lane="telemetry")
        self.assertEqual(len(telemetry), 2)

    def test_add_answer_candidate(self):
        ctx = PipelineContext.create("test")
        ctx.add_answer_candidate("This is the answer.", owner="test", confidence=0.95)

        # Check answer in blackboard
        answers = ctx.blackboard.get_entries(lane="answer_candidates")
        self.assertEqual(len(answers), 1)
        self.assertEqual(answers[0].payload, "This is the answer.")
        self.assertEqual(answers[0].visibility, "user_facing")

    def test_get_final_answer(self):
        ctx = PipelineContext.create("test")
        ctx.add_answer_candidate("The final answer here.")

        answer = ctx.get_final_answer()
        self.assertEqual(answer, "The final answer here.")

    def test_get_final_answer_fallback(self):
        ctx = PipelineContext.create("test")
        # No answer added

        answer = ctx.get_final_answer()
        # Should return fallback
        self.assertTrue(len(answer) > 0)

    def test_to_legacy_context(self):
        ctx = PipelineContext.create(
            query="What time?",
            normalized="what time",
            intent="time",
        )
        ctx.set_routing(route="action_engine", agency_tool="time_now")

        legacy = ctx.to_legacy_context()

        self.assertEqual(legacy["original_query"], "What time?")
        self.assertEqual(legacy["normalized_text"], "what time")
        self.assertEqual(legacy["agency_tool"], "time_now")
        self.assertIs(legacy["_pipeline_context"], ctx)

    def test_from_legacy_context_embedded(self):
        ctx1 = PipelineContext.create("test")
        legacy = ctx1.to_legacy_context()

        ctx2 = PipelineContext.from_legacy_context(legacy)
        self.assertIs(ctx1, ctx2)

    def test_from_legacy_context_dict(self):
        legacy = {
            "original_query": "Hello",
            "normalized_text": "hello",
            "intent": "greeting",
            "agency_tool": "greeting_tool",
            "agency_method": "greet",
            "routed_to": "language",
        }

        ctx = PipelineContext.from_legacy_context(legacy)

        self.assertEqual(ctx.original_query, "Hello")
        self.assertEqual(ctx.agency_tool, "greeting_tool")
        self.assertEqual(ctx.routed_to, "language")


class TestGlobalContext(unittest.TestCase):
    """Tests for global context management."""

    def setUp(self):
        cleanup_pipeline_context()

    def tearDown(self):
        cleanup_pipeline_context()

    def test_create_sets_current(self):
        ctx = create_pipeline_context("test query")

        current = get_current_pipeline_context()
        self.assertIs(current, ctx)

    def test_cleanup_clears_current(self):
        create_pipeline_context("test")
        cleanup_pipeline_context()

        current = get_current_pipeline_context()
        self.assertIsNone(current)

    def test_set_current_context(self):
        ctx = PipelineContext.create("test")
        set_current_pipeline_context(ctx)

        current = get_current_pipeline_context()
        self.assertIs(current, ctx)

    def test_extract_final_answer_uses_current(self):
        ctx = create_pipeline_context("test")
        ctx.add_answer_candidate("Answer from current context.")

        answer = extract_final_answer()
        self.assertEqual(answer, "Answer from current context.")

    def test_extract_final_answer_with_explicit_context(self):
        ctx1 = create_pipeline_context("test1")
        ctx1.add_answer_candidate("Answer 1")

        ctx2 = PipelineContext.create("test2")
        ctx2.add_answer_candidate("Answer 2")

        # Should use explicit context, not current
        answer = extract_final_answer(ctx2)
        self.assertEqual(answer, "Answer 2")


class TestPipelineIntegration(unittest.TestCase):
    """Integration tests for the full pipeline flow."""

    def test_full_pipeline_flow(self):
        # Create context
        ctx = create_pipeline_context(
            query="What time is it?",
            normalized="what time is it",
            intent="time_query",
        )

        # Set routing
        ctx.set_routing(
            route="action_engine",
            agency_tool="time_now",
            bypass_teacher=True,
        )

        # Record stages
        ctx.record_stage("stage_5", {"routed": True})
        ctx.record_stage("stage_6", {"tool_executed": True})

        # Add answer (normally done by tool execution)
        ctx.add_answer_candidate("It's 3:45 PM.")

        # Record final stage
        ctx.record_stage("stage_10", {"final": True}, is_final=True)

        # Get final answer
        answer = ctx.get_final_answer()

        self.assertEqual(answer, "It's 3:45 PM.")
        self.assertEqual(len(ctx.completed_stages), 3)

    def test_blackboard_visibility_enforced(self):
        ctx = create_pipeline_context("test")

        # Add internal tool result (via blackboard directly)
        ctx.blackboard.add_tool_result(
            owner="test_tool",
            payload={"internal": "data", "session_id": "abc123"},
        )

        # Add user-facing answer
        ctx.add_answer_candidate("Clean answer for user.")

        # Final answer should only include user-facing
        answer = ctx.get_final_answer()
        self.assertEqual(answer, "Clean answer for user.")

        # Internal data should not leak
        self.assertNotIn("session_id", answer)
        self.assertNotIn("abc123", answer)


if __name__ == "__main__":
    unittest.main()
