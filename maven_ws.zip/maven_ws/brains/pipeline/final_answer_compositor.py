"""
final_answer_compositor.py
~~~~~~~~~~~~~~~~~~~~~~~~~~

Composes the final user-facing answer from blackboard entries.

This module is the single authority for extracting the final answer
to show users. It:
1. Reads from maven_voice lane FIRST (user_facing only)
2. Falls back to answer_candidates for backward compatibility
3. Applies multi-pass sanity checking
4. Tracks answer sources for attribution
5. Provides fallback generation when no answer is available

ARCHITECTURE: LLMs are advisors, Maven is the speaker.
- Only maven_voice lane should contain user-facing answers
- Only approved voice brains (maven_responder, etc.) can write there
- This compositor enforces that boundary

CRITICAL: The final answer MUST come through this compositor.
Direct access to tool_results or answer_drafts is prohibited for user-facing content.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, Optional, List, Tuple, TYPE_CHECKING
from dataclasses import dataclass, field
from datetime import datetime
import re
import uuid
import time

if TYPE_CHECKING:
    from brains.pipeline.blackboard import Blackboard, BlackboardEntry

# Import AnswerProvenance for provenance tracking
from brains.pipeline.blackboard import AnswerProvenance, create_answer_provenance


# -----------------------------------------------------------------------------
# Answer Source Tracking
# -----------------------------------------------------------------------------

@dataclass
class AnswerSource:
    """Tracks where an answer came from."""
    entry_id: str
    owner: str
    source_type: str  # "tool", "reasoning", "memory", "fallback"
    confidence: float = 1.0
    timestamp: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "entry_id": self.entry_id,
            "owner": self.owner,
            "source_type": self.source_type,
            "confidence": self.confidence,
            "timestamp": self.timestamp.isoformat(),
        }


@dataclass
class ComposedAnswer:
    """The result of composing a final answer."""
    text: str
    sources: List[AnswerSource]
    confidence: float
    passed_sanity: bool
    sanity_issues: List[str] = field(default_factory=list)
    is_fallback: bool = False
    provenance: Optional[AnswerProvenance] = None  # Added for provenance tracking

    def to_dict(self) -> Dict[str, Any]:
        result = {
            "text": self.text,
            "sources": [s.to_dict() for s in self.sources],
            "confidence": self.confidence,
            "passed_sanity": self.passed_sanity,
            "sanity_issues": self.sanity_issues,
            "is_fallback": self.is_fallback,
        }
        if self.provenance:
            result["provenance"] = self.provenance.to_dict()
        return result


# -----------------------------------------------------------------------------
# Sanity Check Functions
# -----------------------------------------------------------------------------

def check_raw_dict_leak(text: str) -> Tuple[bool, Optional[str]]:
    """
    Check if text contains leaked raw dict content.

    Returns:
        Tuple of (passed, issue_description)
    """
    if not text:
        return True, None

    # Patterns that indicate raw dict output
    suspicious_starts = ["{'", '{"', "OrderedDict(", "defaultdict("]

    for pattern in suspicious_starts:
        if text.strip().startswith(pattern):
            return False, f"Starts with dict literal: {pattern}"

    # Internal field patterns
    internal_patterns = [
        (r"'session_id'\s*:", "Contains internal field 'session_id'"),
        (r"'facts_stored'\s*:", "Contains internal field 'facts_stored'"),
        (r"'page_id'\s*:", "Contains internal field 'page_id'"),
        (r"'transcript_path'\s*:", "Contains internal field 'transcript_path'"),
        (r'"ok"\s*:\s*(true|false)', "Contains JSON 'ok' field"),
        (r"'status'\s*:\s*'(success|error|completed)'", "Contains raw status field"),
    ]

    for pattern, description in internal_patterns:
        if re.search(pattern, text[:500]):
            return False, description

    return True, None


def check_traceback_leak(text: str) -> Tuple[bool, Optional[str]]:
    """Check if text contains Python traceback."""
    if "Traceback (most recent call last)" in text:
        return False, "Contains Python traceback"
    if "  File \"" in text and "line " in text:
        return False, "Contains stack trace pattern"
    return True, None


def check_empty_or_minimal(text: str) -> Tuple[bool, Optional[str]]:
    """Check if text is empty or too minimal."""
    if not text:
        return False, "Empty response"
    if len(text.strip()) < 5:
        return False, f"Response too short ({len(text.strip())} chars)"
    return True, None


def check_repetitive_content(text: str) -> Tuple[bool, Optional[str]]:
    """Check for obvious repetitive/looped content."""
    if not text or len(text) < 100:
        return True, None

    # Check for repeated phrases
    words = text.split()
    if len(words) >= 10:
        # Check if same 5-word phrase repeats
        for i in range(len(words) - 9):
            phrase = " ".join(words[i:i+5])
            count = text.count(phrase)
            if count > 3:
                return False, f"Phrase repeated {count} times: '{phrase[:30]}...'"

    return True, None


def check_internal_data_leak(text: str) -> Tuple[bool, Optional[str]]:
    """
    Check if text contains leaked internal data.

    Catches:
    - Windows/Unix file paths
    - ISO timestamps
    - Raw dicts with internal keys
    - Internal diagnostic markers

    This is a guardrail for the LLM-as-advisor architecture.
    """
    if not text:
        return True, None

    # Windows paths: C:\Users\...
    if re.search(r'[A-Za-z]:\\[^\s\n\r\'"]+(?:\\[^\s\n\r\'"]+)+', text):
        return False, "Contains Windows file path"

    # Unix paths: /home/user/...
    if re.search(r'/(?:home|Users|var|tmp|opt)/[^\s\n\r\'"]+', text):
        return False, "Contains Unix file path"

    # ISO timestamps: 2025-12-04T14:32:30.527454
    if re.search(r'\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?', text):
        return False, "Contains ISO timestamp"

    # Raw dicts with internal keys
    internal_key_patterns = [
        (r"\{['\"]timestamp['\"]:", "Contains raw 'timestamp' dict"),
        (r"\{['\"]root['\"]:", "Contains raw 'root' dict"),
        (r"\{['\"]file_count['\"]:", "Contains raw 'file_count' dict"),
        (r"\{['\"]modules['\"]:", "Contains raw 'modules' dict"),
    ]

    for pattern, description in internal_key_patterns:
        if re.search(pattern, text):
            return False, description

    return True, None


def check_raw_fact_leak(text: str) -> Tuple[bool, Optional[str]]:
    """
    Check if text contains raw fact patterns (unsynthesized database output).

    This is a critical check for the synthesis system - Maven should NEVER
    output raw facts like "name: Alice" - only synthesized prose.

    Catches patterns like:
    - "name: Alice" (key:value at start)
    - Multiple "key: value" lines
    - Database-like output patterns

    Returns:
        Tuple of (passed, issue_description)
    """
    if not text:
        return True, None

    text_stripped = text.strip()

    # Pattern 1: "key: value" at start of text (classic raw fact)
    # But allow natural prose that happens to have colons (e.g., "Note: this is important")
    raw_kv_start = re.match(r'^([a-z_]+):\s*(.+)$', text_stripped, re.IGNORECASE)
    if raw_kv_start:
        key = raw_kv_start.group(1).lower()
        # These keys are almost always raw facts
        raw_fact_keys = {
            "name", "location", "email", "phone", "preference", "value",
            "answer", "result", "status", "type", "id", "user_id",
            "fact", "data", "content", "payload", "output",
        }
        if key in raw_fact_keys:
            return False, f"Starts with raw fact pattern: '{key}:'"

    # Pattern 2: Multiple "key: value" lines (database dump)
    kv_pattern = r'\b[a-z_]+:\s*[^\n:]+(?:\n|$)'
    kv_matches = re.findall(kv_pattern, text_stripped, re.IGNORECASE)
    if len(kv_matches) >= 3 and len(text_stripped) < 300:
        return False, f"Contains {len(kv_matches)} raw key:value patterns"

    # Pattern 3: Looks like JSON field output
    if re.search(r'\[[\'"][a-z_]+[\'"]\]\s*=', text_stripped, re.IGNORECASE):
        return False, "Contains array field access pattern"

    # Pattern 4: Raw tuple/list output
    if re.match(r'^\([\'"]\w+[\'"],\s*[\'"]\w+[\'"]\)', text_stripped):
        return False, "Starts with raw tuple pattern"

    return True, None


def run_sanity_checks(text: str) -> Tuple[bool, List[str]]:
    """
    Run all sanity checks on answer text.

    Includes checks for:
    - Raw dict leaks
    - Tracebacks
    - Empty/minimal responses
    - Repetitive content
    - Internal data leaks (paths, timestamps, etc.)
    - Raw fact leaks (synthesis guardrail)

    Returns:
        Tuple of (all_passed, list_of_issues)
    """
    checks = [
        check_raw_dict_leak,
        check_traceback_leak,
        check_empty_or_minimal,
        check_repetitive_content,
        check_internal_data_leak,  # LLM-as-advisor guardrail
        check_raw_fact_leak,       # Synthesis system guardrail
    ]

    issues = []
    for check in checks:
        passed, issue = check(text)
        if not passed and issue:
            issues.append(issue)

    return len(issues) == 0, issues


# -----------------------------------------------------------------------------
# Final Answer Compositor
# -----------------------------------------------------------------------------

class FinalAnswerCompositor:
    """
    Composes the final answer from blackboard entries.

    This class is the single authority for extracting user-facing answers.
    It ensures all content passes sanity checks before presentation.

    Usage:
        compositor = FinalAnswerCompositor(blackboard)
        result = compositor.compose()

        if result.passed_sanity:
            show_to_user(result.text)
        else:
            handle_failed_sanity(result.sanity_issues)
    """

    # Default fallback messages
    FALLBACK_MESSAGES = [
        "I've completed the task. Let me know if you need anything else.",
        "Task completed successfully.",
        "I've processed your request.",
    ]

    def __init__(self, blackboard: "Blackboard"):
        """
        Initialize the compositor.

        Args:
            blackboard: Blackboard instance to read from
        """
        self.blackboard = blackboard
        self._fallback_index = 0

    # Approved voice brains that can write to maven_voice lane
    APPROVED_VOICE_BRAINS = {
        "maven_responder",
        "maven_voice",
        "response_synthesis",
        "compositor",  # Legacy
        "pipeline",    # Legacy
    }

    def compose(
        self,
        prefer_tool_answers: bool = True,
        allow_fallback: bool = True,
        prefer_maven_voice: bool = True,
    ) -> ComposedAnswer:
        """
        Compose the final answer from blackboard entries.

        ARCHITECTURE: LLMs are advisors, Maven is the speaker.
        - First checks maven_voice lane (preferred)
        - Falls back to answer_candidates for backward compatibility
        - Validates that entries come from approved voice brains

        Args:
            prefer_tool_answers: Prefer answers from tools over reasoning
            allow_fallback: Allow fallback generation if no answer found
            prefer_maven_voice: Check maven_voice lane first (default True)

        Returns:
            ComposedAnswer with text, sources, and sanity status
        """
        candidates = []

        # STEP 1: Check maven_voice lane first (LLM-as-advisor architecture)
        if prefer_maven_voice:
            maven_voice_entries = self.blackboard.get_entries(
                lane="maven_voice",
                visibility="user_facing",
            )

            # Filter to only approved voice brains
            approved_entries = [
                e for e in maven_voice_entries
                if e.owner in self.APPROVED_VOICE_BRAINS
            ]

            if approved_entries:
                candidates.extend(approved_entries)

        # STEP 2: Fall back to answer_candidates for backward compatibility
        if not candidates:
            legacy_candidates = self.blackboard.get_entries(
                lane="answer_candidates",
                visibility="user_facing",
            )
            candidates.extend(legacy_candidates)

        if not candidates:
            if allow_fallback:
                return self._generate_fallback("No answer candidates found")
            return ComposedAnswer(
                text="",
                sources=[],
                confidence=0.0,
                passed_sanity=False,
                sanity_issues=["No answer candidates available"],
            )

        # Sort by preference (maven_voice entries first, then tools)
        candidates = self._sort_by_preference_v2(candidates)

        # Try each candidate until one passes sanity
        for candidate in candidates:
            text = self._extract_text(candidate)
            passed, issues = run_sanity_checks(text)

            if passed:
                sources = [self._create_source(candidate)]
                confidence = self._estimate_confidence(candidate)
                provenance = self._create_provenance(sources, confidence)

                return ComposedAnswer(
                    text=text,
                    sources=sources,
                    confidence=confidence,
                    passed_sanity=True,
                    provenance=provenance,
                )

            # If raw fact detected, try auto-synthesis
            raw_fact_issues = [i for i in issues if "raw" in i.lower() or "key:value" in i.lower()]
            if raw_fact_issues:
                synthesized = self._auto_synthesize(text)
                if synthesized:
                    # Re-check synthesized text
                    synth_passed, synth_issues = run_sanity_checks(synthesized)
                    if synth_passed:
                        sources = [self._create_source(candidate)]
                        sources[0].source_type = "synthesized"
                        confidence = self._estimate_confidence(candidate) * 0.9  # Slight penalty

                        provenance = create_answer_provenance(
                            brains_involved=["compositor", candidate.owner],
                            source="local",
                            self_origin=True,
                            confidence=confidence,
                            reasoning_kind="auto_synthesis",
                        )

                        return ComposedAnswer(
                            text=synthesized,
                            sources=sources,
                            confidence=confidence,
                            passed_sanity=True,
                            provenance=provenance,
                        )

        # No candidate passed - try to salvage with auto-synthesis
        best_candidate = candidates[-1]  # Latest
        text = self._extract_text(best_candidate)
        passed, issues = run_sanity_checks(text)

        # Last resort: try auto-synthesis on best candidate
        if not passed:
            synthesized = self._auto_synthesize(text)
            if synthesized:
                synth_passed, synth_issues = run_sanity_checks(synthesized)
                if synth_passed:
                    sources = [self._create_source(best_candidate)]
                    provenance = create_answer_provenance(
                        brains_involved=["compositor"],
                        source="local",
                        self_origin=True,
                        confidence=0.7,
                        reasoning_kind="salvage_synthesis",
                    )

                    return ComposedAnswer(
                        text=synthesized,
                        sources=sources,
                        confidence=0.7,
                        passed_sanity=True,
                        sanity_issues=["Auto-synthesized from raw facts"],
                        provenance=provenance,
                    )

        if not passed and allow_fallback:
            return self._generate_fallback(f"All candidates failed: {issues[0]}")

        sources = [self._create_source(best_candidate)]
        provenance = self._create_provenance(sources, 0.5)

        return ComposedAnswer(
            text=text,
            sources=sources,
            confidence=0.5,
            passed_sanity=passed,
            sanity_issues=issues,
            provenance=provenance,
        )

    def _sort_by_preference(
        self,
        candidates: List["BlackboardEntry"],
    ) -> List["BlackboardEntry"]:
        """Sort candidates by preference (tools first, then by seq_id)."""
        def sort_key(entry: "BlackboardEntry") -> tuple:
            is_tool = any("tool:" in tag for tag in entry.tags)
            return (not is_tool, -entry.seq_id)

        return sorted(candidates, key=sort_key)

    def _sort_by_preference_v2(
        self,
        candidates: List["BlackboardEntry"],
    ) -> List["BlackboardEntry"]:
        """
        Sort candidates by preference for LLM-as-advisor architecture.

        Priority:
        1. maven_voice lane from approved brains (highest)
        2. answer_candidates from tools
        3. answer_candidates from other sources
        4. Older entries (lower seq_id) last
        """
        def sort_key(entry: "BlackboardEntry") -> tuple:
            # First priority: maven_voice from approved brains
            is_maven_voice = entry.lane == "maven_voice"
            is_approved = entry.owner in self.APPROVED_VOICE_BRAINS

            # Second priority: tools
            is_tool = any("tool:" in tag for tag in entry.tags)

            # Return tuple for sorting (lower = higher priority)
            return (
                not (is_maven_voice and is_approved),  # Maven voice first
                not is_tool,                            # Then tools
                -entry.seq_id,                          # Then by recency
            )

        return sorted(candidates, key=sort_key)

    def _extract_text(self, entry: "BlackboardEntry") -> str:
        """Extract text from an entry payload."""
        payload = entry.payload

        if isinstance(payload, str):
            return payload

        if isinstance(payload, dict):
            # Try common text keys
            for key in ["text", "answer", "recap", "response", "output"]:
                if key in payload and isinstance(payload[key], str):
                    return payload[key]
            # Fallback to str representation (will likely fail sanity)
            return str(payload)

        return str(payload)

    def _create_source(self, entry: "BlackboardEntry") -> AnswerSource:
        """Create source attribution from entry."""
        # Determine source type from tags
        source_type = "unknown"
        for tag in entry.tags:
            if tag.startswith("tool:"):
                source_type = "tool"
                break
            if "reasoning" in tag:
                source_type = "reasoning"
                break
            if "memory" in tag:
                source_type = "memory"
                break

        return AnswerSource(
            entry_id=entry.id,
            owner=entry.owner,
            source_type=source_type,
            timestamp=entry.timestamp,
        )

    def _estimate_confidence(self, entry: "BlackboardEntry") -> float:
        """Estimate confidence from entry metadata."""
        payload = entry.payload

        if isinstance(payload, dict):
            if "confidence" in payload:
                return float(payload["confidence"])

        # Default high confidence for tool outputs
        if any("tool:" in tag for tag in entry.tags):
            return 0.95

        return 0.8

    def _generate_fallback(self, reason: str) -> ComposedAnswer:
        """Generate a fallback answer."""
        fallback_text = self.FALLBACK_MESSAGES[
            self._fallback_index % len(self.FALLBACK_MESSAGES)
        ]
        self._fallback_index += 1

        provenance = create_answer_provenance(
            brains_involved=["compositor"],
            source="local",
            self_origin=True,
            confidence=0.5,
            reasoning_kind="fallback",
        )

        return ComposedAnswer(
            text=fallback_text,
            sources=[AnswerSource(
                entry_id="fallback",
                owner="compositor",
                source_type="fallback",
                confidence=0.5,
            )],
            confidence=0.5,
            passed_sanity=True,
            is_fallback=True,
            sanity_issues=[f"Fallback used: {reason}"],
            provenance=provenance,
        )

    def _auto_synthesize(
        self,
        raw_text: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """
        Auto-synthesize raw facts into natural prose.

        This is the defensive layer - catches any raw facts that slip through
        the primary synthesis layer in reasoning brain.

        Args:
            raw_text: Text that failed raw fact check
            context: Optional context for synthesis

        Returns:
            Synthesized text, or None if synthesis fails
        """
        context = context or {}

        # Try text_realizer for sophisticated synthesis
        try:
            from brains.cognitive.language.service.text_realizer import (
                synthesize_from_facts,
            )
            synthesized = synthesize_from_facts(raw_text, context)
            if synthesized and len(synthesized) > 5:
                print(f"[COMPOSITOR] Auto-synthesized via text_realizer: '{raw_text[:30]}...' → '{synthesized[:30]}...'")
                return synthesized
        except ImportError:
            print("[COMPOSITOR] text_realizer.synthesize_from_facts not available")
        except Exception as e:
            print(f"[COMPOSITOR] text_realizer synthesis failed: {e}")

        # Fall back to simple pattern-based synthesis
        simple_result = self._simple_synthesis(raw_text, context)
        if simple_result and simple_result != raw_text:
            print(f"[COMPOSITOR] Auto-synthesized via simple: '{raw_text[:30]}...' → '{simple_result[:30]}...'")
            return simple_result

        return None

    def _simple_synthesis(
        self,
        raw_text: str,
        context: Optional[Dict[str, Any]] = None,
    ) -> Optional[str]:
        """
        Simple pattern-based synthesis fallback.

        Handles common raw fact patterns when text_realizer unavailable.

        Args:
            raw_text: Raw text to synthesize
            context: Optional context

        Returns:
            Synthesized text, or original if no pattern matches
        """
        if not raw_text:
            return None

        raw_stripped = raw_text.strip()
        context = context or {}

        # Pattern 1: "key: value" format
        kv_match = re.match(r'^(\w+):\s*(.+)$', raw_stripped, re.IGNORECASE)
        if kv_match:
            key = kv_match.group(1).lower()
            value = kv_match.group(2).strip()

            # Personal fact patterns
            if key == "name":
                return f"Your name is {value}."
            if key == "location":
                return f"Your location is {value}."
            if key == "email":
                return f"Your email is {value}."
            if key == "phone":
                return f"Your phone number is {value}."
            if key in ("preference", "pref"):
                return f"You prefer {value}."

            # Answer patterns
            if key in ("answer", "result"):
                return value  # Just the value
            if key == "status":
                return f"The status is: {value}."

            # Generic pattern
            readable_key = key.replace("_", " ")
            return f"The {readable_key} is {value}."

        # Pattern 2: Multiple key:value lines - synthesize as list
        lines = raw_stripped.split("\n")
        kv_lines = []
        for line in lines:
            kv_match = re.match(r'^(\w+):\s*(.+)$', line.strip(), re.IGNORECASE)
            if kv_match:
                key = kv_match.group(1).replace("_", " ")
                value = kv_match.group(2).strip()
                kv_lines.append(f"{key}: {value}")

        if len(kv_lines) >= 2:
            return "Here's what I found: " + "; ".join(kv_lines[:3]) + "."

        # No pattern matched - return original
        return raw_stripped

    def _create_provenance(
        self,
        sources: List[AnswerSource],
        confidence: float,
        context: Optional[Dict[str, Any]] = None,
    ) -> AnswerProvenance:
        """
        Create AnswerProvenance from answer sources and context.

        This is the canonical place where provenance is created for every answer.
        The provenance can then be used by handle_meta_provenance() to explain
        where the answer came from.

        Args:
            sources: List of AnswerSource from the composition
            confidence: Confidence score for the answer
            context: Optional pipeline context with additional metadata

        Returns:
            AnswerProvenance instance
        """
        context = context or {}

        # Extract brains from sources
        brains_involved = list(set(s.owner for s in sources))

        # Extract tools from sources
        tools_used = [
            s.owner for s in sources
            if s.source_type == "tool"
        ]

        # Determine source type
        source_types = set(s.source_type for s in sources)
        if "teacher" in source_types or context.get("teacher_used"):
            source = "teacher"
            self_origin = False
        elif all(st in ("reasoning", "memory", "self") for st in source_types):
            source = "local"
            self_origin = True
        else:
            source = "mixed"
            self_origin = False

        # Get teacher call count from context
        teacher_calls = context.get("teacher_calls", 0)

        # Get reasoning kind from context
        reasoning_kind = context.get("reasoning_kind") or context.get("intent")

        return create_answer_provenance(
            brains_involved=brains_involved,
            tools_used=tools_used,
            source=source,
            self_origin=self_origin,
            confidence=confidence,
            reasoning_kind=reasoning_kind,
            teacher_calls=teacher_calls,
        )


# -----------------------------------------------------------------------------
# Convenience Functions
# -----------------------------------------------------------------------------

def compose_final_answer(blackboard: "Blackboard") -> str:
    """
    Convenience function to get the final answer text.

    Args:
        blackboard: Blackboard instance

    Returns:
        Final answer string (with fallback if needed)
    """
    compositor = FinalAnswerCompositor(blackboard)
    result = compositor.compose()
    return result.text


def compose_final_answer_with_metadata(
    blackboard: "Blackboard",
) -> Dict[str, Any]:
    """
    Get final answer with full metadata.

    Args:
        blackboard: Blackboard instance

    Returns:
        Dict with text, sources, confidence, etc.
    """
    compositor = FinalAnswerCompositor(blackboard)
    result = compositor.compose()
    return result.to_dict()


def compose_and_store_provenance(
    blackboard: "Blackboard",
    context: Optional[Dict[str, Any]] = None,
) -> Tuple[str, Optional[AnswerProvenance]]:
    """
    Compose final answer AND store provenance in context for later retrieval.

    This is the preferred function for pipeline integration - it ensures
    provenance is always created and stored for "where did that answer come from?"
    questions.

    Args:
        blackboard: Blackboard instance
        context: Optional context dict to store provenance in

    Returns:
        Tuple of (answer_text, provenance)
    """
    compositor = FinalAnswerCompositor(blackboard)
    result = compositor.compose()

    # Store provenance in context if provided
    if context is not None and result.provenance:
        context["last_answer_provenance"] = result.provenance.to_dict()
        context["last_answer_text"] = result.text

    return result.text, result.provenance


# -----------------------------------------------------------------------------
# Exports
# -----------------------------------------------------------------------------

__all__ = [
    "AnswerSource",
    "ComposedAnswer",
    "FinalAnswerCompositor",
    "run_sanity_checks",
    "check_raw_dict_leak",
    "check_traceback_leak",
    "check_internal_data_leak",
    "compose_final_answer",
    "compose_final_answer_with_metadata",
    "compose_and_store_provenance",
]
