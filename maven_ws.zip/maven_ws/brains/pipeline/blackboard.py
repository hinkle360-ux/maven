"""
blackboard.py
~~~~~~~~~~~~~

Lane-based Blackboard abstraction for Maven's cognition pipeline.

This module provides a structured shared state with:
- Named lanes for different data categories
- Visibility metadata (internal/summary/user_facing)
- Immutable entry records with timestamps
- Query methods for filtering by lane, owner, visibility

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Literal, Iterator
from dataclasses import dataclass, field, asdict
from datetime import datetime
import uuid
import time


# =============================================================================
# AnswerProvenance - Canonical metadata for every final answer
# =============================================================================

@dataclass
class AnswerProvenance:
    """
    Canonical metadata written with every final answer.

    This is the SINGLE SOURCE OF TRUTH for "where did that answer come from?"
    questions. Every final answer writes this to the blackboard.

    Usage:
        prov = AnswerProvenance(
            answer_id=str(uuid.uuid4()),
            timestamp=time.time(),
            brains_involved=["reasoning", "memory_librarian"],
            tools_used=["web_search"],
            ...
        )
        blackboard.set("last_answer_provenance", prov.to_dict())
    """
    answer_id: str
    timestamp: float
    brains_involved: List[str] = field(default_factory=list)
    tools_used: List[str] = field(default_factory=list)
    mode: str = "unknown"  # "short", "medium", "long"
    source: str = "unknown"  # "teacher", "local", "mixed"
    self_origin: bool = False  # True if composed by Maven from internal data
    confidence: float = 0.0
    reasoning_kind: Optional[str] = None  # "factual_query", "planning", etc.
    teacher_calls: int = 0
    teacher_raw_ids: List[str] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for blackboard storage."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AnswerProvenance":
        """Reconstruct from dictionary."""
        return cls(
            answer_id=data.get("answer_id", str(uuid.uuid4())),
            timestamp=data.get("timestamp", time.time()),
            brains_involved=data.get("brains_involved", []),
            tools_used=data.get("tools_used", []),
            mode=data.get("mode", "unknown"),
            source=data.get("source", "unknown"),
            self_origin=data.get("self_origin", False),
            confidence=data.get("confidence", 0.0),
            reasoning_kind=data.get("reasoning_kind"),
            teacher_calls=data.get("teacher_calls", 0),
            teacher_raw_ids=data.get("teacher_raw_ids", []),
        )


def create_answer_provenance(
    brains_involved: Optional[List[str]] = None,
    tools_used: Optional[List[str]] = None,
    source: str = "unknown",
    self_origin: bool = False,
    confidence: float = 0.0,
    reasoning_kind: Optional[str] = None,
    teacher_calls: int = 0,
    mode: str = "unknown",
) -> AnswerProvenance:
    """
    Factory function to create AnswerProvenance with defaults.

    Args:
        brains_involved: List of brains that contributed to the answer
        tools_used: List of tools used
        source: "teacher", "local", or "mixed"
        self_origin: True if Maven composed from internal data
        confidence: Confidence score (0.0 to 1.0)
        reasoning_kind: Type of reasoning used
        teacher_calls: Number of teacher/LLM calls made
        mode: Response mode ("short", "medium", "long")

    Returns:
        AnswerProvenance instance
    """
    return AnswerProvenance(
        answer_id=str(uuid.uuid4()),
        timestamp=time.time(),
        brains_involved=brains_involved or [],
        tools_used=tools_used or [],
        mode=mode,
        source=source,
        self_origin=self_origin,
        confidence=confidence,
        reasoning_kind=reasoning_kind,
        teacher_calls=teacher_calls,
        teacher_raw_ids=[],
    )


# -----------------------------------------------------------------------------
# Type Definitions
# -----------------------------------------------------------------------------

Visibility = Literal["internal", "summary", "user_facing"]

# Standard lane names - enforced for consistency
STANDARD_LANES = frozenset({
    "user_input",        # Raw query, normalized text, intent
    "context",           # ContextState, conversation state
    "planning",          # Routing decisions, brain selection
    "tool_results",      # Raw tool outputs (NEVER user-facing)
    "answer_drafts",     # LLM/tool suggested responses (INTERNAL - advisor notes)
    "maven_voice",       # Final answers in Maven's voice (USER-FACING)
    "answer_candidates", # Formatted answers for user presentation (deprecated, use maven_voice)
    "telemetry",         # Debug logs, metrics
})

# Lanes that are allowed to contain user-facing content
# ONLY maven_voice should have user-facing answers (enforced by add_final_answer)
USER_FACING_LANES = frozenset({"maven_voice", "answer_candidates"})

# Lanes where LLMs/tools write advisory content (always internal)
ADVISORY_LANES = frozenset({"tool_results", "answer_drafts"})


# -----------------------------------------------------------------------------
# Entry Dataclass
# -----------------------------------------------------------------------------

@dataclass(frozen=True)
class BlackboardEntry:
    """
    Immutable record representing a single entry on the blackboard.

    Attributes:
        id: Unique identifier for this entry
        owner: Component that created this entry (e.g., "stage_6", "grok_tool")
        lane: Which lane this entry belongs to
        visibility: Access level - "internal", "summary", or "user_facing"
        payload: The actual data (can be any type)
        seq_id: Monotonic sequence number for ordering
        timestamp: When this entry was created
        tags: Optional tags for filtering/grouping
    """
    id: str
    owner: str
    lane: str
    visibility: Visibility
    payload: Any
    seq_id: int
    timestamp: datetime = field(default_factory=datetime.now)
    tags: tuple = field(default_factory=tuple)

    def is_user_facing(self) -> bool:
        """Check if this entry can be shown to users."""
        return self.visibility == "user_facing"

    def is_internal(self) -> bool:
        """Check if this entry is internal only."""
        return self.visibility == "internal"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "owner": self.owner,
            "lane": self.lane,
            "visibility": self.visibility,
            "payload": self.payload,
            "seq_id": self.seq_id,
            "timestamp": self.timestamp.isoformat(),
            "tags": list(self.tags),
        }


# -----------------------------------------------------------------------------
# Blackboard Class
# -----------------------------------------------------------------------------

class Blackboard:
    """
    Lane-based shared state for the cognition pipeline.

    The blackboard organizes data into lanes, where each lane contains
    entries with visibility metadata. This allows:

    1. Tool results to be marked as "internal" and never leak to users
    2. Answer candidates to be marked as "user_facing" for presentation
    3. Telemetry to be captured without polluting user responses

    Example:
        bb = Blackboard()

        # Tool writes internal result
        bb.add_entry(
            owner="grok_tool",
            lane="tool_results",
            visibility="internal",
            payload={"raw_dict": {...}}
        )

        # Compositor writes user-facing answer
        bb.add_entry(
            owner="compositor",
            lane="answer_candidates",
            visibility="user_facing",
            payload="Here's what Grok said..."
        )

        # Final answer only sees user_facing content
        answer = bb.get_user_facing_answer()
    """

    def __init__(self):
        """Initialize an empty blackboard with standard lanes."""
        self._lanes: Dict[str, List[BlackboardEntry]] = {
            lane: [] for lane in STANDARD_LANES
        }
        self._seq_counter: int = 0
        self._all_entries: List[BlackboardEntry] = []

    def _next_seq(self) -> int:
        """Get next sequence number."""
        self._seq_counter += 1
        return self._seq_counter

    def add_entry(
        self,
        owner: str,
        lane: str,
        visibility: Visibility,
        payload: Any,
        tags: Optional[List[str]] = None,
        entry_id: Optional[str] = None,
    ) -> BlackboardEntry:
        """
        Add an entry to the blackboard.

        Args:
            owner: Component creating this entry
            lane: Target lane (must be a standard lane)
            visibility: Access level for this entry
            payload: The data to store
            tags: Optional tags for filtering
            entry_id: Optional custom ID (auto-generated if not provided)

        Returns:
            The created BlackboardEntry

        Raises:
            ValueError: If lane is not a standard lane
        """
        if lane not in STANDARD_LANES:
            raise ValueError(
                f"Unknown lane '{lane}'. Must be one of: {sorted(STANDARD_LANES)}"
            )

        entry = BlackboardEntry(
            id=entry_id or str(uuid.uuid4()),
            owner=owner,
            lane=lane,
            visibility=visibility,
            payload=payload,
            seq_id=self._next_seq(),
            tags=tuple(tags) if tags else (),
        )

        self._lanes[lane].append(entry)
        self._all_entries.append(entry)

        return entry

    # -------------------------------------------------------------------------
    # Query Methods
    # -------------------------------------------------------------------------

    def get_entries(
        self,
        lane: Optional[str] = None,
        owner: Optional[str] = None,
        visibility: Optional[Visibility] = None,
        tag: Optional[str] = None,
    ) -> List[BlackboardEntry]:
        """
        Query entries with optional filters.

        Args:
            lane: Filter by lane name
            owner: Filter by owner
            visibility: Filter by visibility level
            tag: Filter by tag

        Returns:
            List of matching entries, ordered by seq_id
        """
        if lane and lane not in STANDARD_LANES:
            return []

        entries = self._lanes[lane] if lane else self._all_entries

        result = []
        for entry in entries:
            if owner and entry.owner != owner:
                continue
            if visibility and entry.visibility != visibility:
                continue
            if tag and tag not in entry.tags:
                continue
            result.append(entry)

        return sorted(result, key=lambda e: e.seq_id)

    def get_lane(self, lane: str) -> List[BlackboardEntry]:
        """Get all entries in a specific lane."""
        return self.get_entries(lane=lane)

    def get_user_facing(self) -> List[BlackboardEntry]:
        """Get all entries that can be shown to users."""
        return self.get_entries(visibility="user_facing")

    def get_internal(self) -> List[BlackboardEntry]:
        """Get all internal entries."""
        return self.get_entries(visibility="internal")

    def get_latest(
        self,
        lane: Optional[str] = None,
        visibility: Optional[Visibility] = None,
    ) -> Optional[BlackboardEntry]:
        """Get the most recent entry matching the filters."""
        entries = self.get_entries(lane=lane, visibility=visibility)
        return entries[-1] if entries else None

    def get_user_facing_answer(self) -> Optional[str]:
        """
        Get the final user-facing answer.

        This is the primary method for extracting the response to show users.
        It looks for user_facing entries in the answer_candidates lane.

        Returns:
            The payload of the latest user_facing answer, or None
        """
        entry = self.get_latest(lane="answer_candidates", visibility="user_facing")
        if entry:
            payload = entry.payload
            # Ensure we return a string, not a dict
            if isinstance(payload, str):
                return payload
            elif isinstance(payload, dict):
                # Defensive: if somehow a dict got marked user_facing, extract text
                return payload.get("text", payload.get("answer", str(payload)))
            else:
                return str(payload)
        return None

    # -------------------------------------------------------------------------
    # Tool Result Helpers
    # -------------------------------------------------------------------------

    def add_tool_result(
        self,
        owner: str,
        payload: Any,
        tags: Optional[List[str]] = None,
    ) -> BlackboardEntry:
        """
        Add a tool result (always internal visibility).

        Tool results should NEVER be user-facing directly.
        Use add_answer_candidate() for user-facing content.

        Args:
            owner: The tool that generated this result
            payload: The raw tool output
            tags: Optional tags

        Returns:
            The created entry
        """
        return self.add_entry(
            owner=owner,
            lane="tool_results",
            visibility="internal",
            payload=payload,
            tags=tags,
        )

    def add_answer_candidate(
        self,
        owner: str,
        text: str,
        confidence: float = 1.0,
        source_entry_id: Optional[str] = None,
        tags: Optional[List[str]] = None,
    ) -> BlackboardEntry:
        """
        Add a user-facing answer candidate.

        DEPRECATED: Use add_final_answer() for Maven's voice.
        This is kept for backward compatibility.

        Args:
            owner: Component creating this answer
            text: The formatted answer text (must be a string)
            confidence: Confidence score (0.0 to 1.0)
            source_entry_id: ID of the tool_result this was derived from
            tags: Optional tags

        Returns:
            The created entry

        Raises:
            TypeError: If text is not a string
        """
        if not isinstance(text, str):
            raise TypeError(
                f"Answer candidate text must be a string, got {type(text).__name__}. "
                "Use add_tool_result() for raw dict outputs."
            )

        payload = {
            "text": text,
            "confidence": confidence,
            "source_entry_id": source_entry_id,
        }

        return self.add_entry(
            owner=owner,
            lane="answer_candidates",
            visibility="user_facing",
            payload=text,  # Store just the text for easy access
            tags=tags,
        )

    # -------------------------------------------------------------------------
    # Maven Voice System (LLM-as-advisor architecture)
    # -------------------------------------------------------------------------

    def add_answer_draft(
        self,
        owner: str,
        draft_text: str,
        draft_type: str = "suggestion",
        source_info: Optional[Dict[str, Any]] = None,
        tags: Optional[List[str]] = None,
    ) -> BlackboardEntry:
        """
        Add an advisory draft from an LLM or tool.

        These drafts are ALWAYS internal and will NEVER be shown to users directly.
        They serve as notes/suggestions for Maven's response synthesis.

        Args:
            owner: The LLM/tool generating this draft (e.g., "teacher", "grok_session")
            draft_text: The suggested text/analysis
            draft_type: Type of draft - "suggestion", "analysis", "summary", "notes"
            source_info: Optional metadata about the source (e.g., {"model": "grok-2"})
            tags: Optional tags for filtering

        Returns:
            The created entry (always visibility="internal")
        """
        payload = {
            "draft_text": draft_text,
            "draft_type": draft_type,
            "source_info": source_info or {},
        }

        return self.add_entry(
            owner=owner,
            lane="answer_drafts",
            visibility="internal",  # ALWAYS internal - this is the key constraint
            payload=payload,
            tags=tags or [f"draft_type:{draft_type}"],
        )

    def add_final_answer(
        self,
        owner: str,
        text: str,
        confidence: float = 1.0,
        source_drafts: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> BlackboardEntry:
        """
        Add Maven's final answer in its own voice.

        This is the ONLY method that should write user-facing content.
        Only maven_responder (or approved voice brains) should call this.

        Args:
            owner: Must be "maven_responder" or an approved voice brain
            text: The final answer text in Maven's voice
            confidence: Confidence score (0.0 to 1.0)
            source_drafts: IDs of answer_drafts used to compose this
            tags: Optional tags

        Returns:
            The created entry (visibility="user_facing")

        Raises:
            TypeError: If text is not a string
            PermissionError: If owner is not an approved voice brain
        """
        # Approved voice brains - only these can write user-facing content
        APPROVED_VOICE_BRAINS = {
            "maven_responder",
            "maven_voice",
            "response_synthesis",
            "compositor",  # Legacy compatibility
            "pipeline",    # Legacy compatibility
        }

        if owner not in APPROVED_VOICE_BRAINS:
            raise PermissionError(
                f"Only approved voice brains can write to maven_voice lane. "
                f"Got owner='{owner}', expected one of: {sorted(APPROVED_VOICE_BRAINS)}. "
                f"Use add_answer_draft() to write advisory content instead."
            )

        if not isinstance(text, str):
            raise TypeError(
                f"Final answer must be a string, got {type(text).__name__}."
            )

        return self.add_entry(
            owner=owner,
            lane="maven_voice",
            visibility="user_facing",
            payload=text,
            tags=tags or ["final_answer"],
        )

    def get_drafts(
        self,
        owner: Optional[str] = None,
        draft_type: Optional[str] = None,
    ) -> List[BlackboardEntry]:
        """
        Get advisory drafts from LLMs/tools.

        Args:
            owner: Filter by specific owner (e.g., "teacher", "grok_session")
            draft_type: Filter by draft type (e.g., "suggestion", "analysis")

        Returns:
            List of draft entries, ordered by seq_id
        """
        tag = f"draft_type:{draft_type}" if draft_type else None
        return self.get_entries(
            lane="answer_drafts",
            owner=owner,
            tag=tag,
        )

    def get_maven_voice_answer(self) -> Optional[str]:
        """
        Get the final answer from Maven's voice lane.

        This is the primary method for extracting the response to show users.
        Falls back to answer_candidates for backward compatibility.

        Returns:
            The final answer text, or None
        """
        # Prefer maven_voice lane
        entry = self.get_latest(lane="maven_voice", visibility="user_facing")
        if entry:
            payload = entry.payload
            if isinstance(payload, str):
                return payload
            elif isinstance(payload, dict):
                return payload.get("text", str(payload))
            return str(payload)

        # Fall back to answer_candidates for backward compatibility
        return self.get_user_facing_answer()

    # -------------------------------------------------------------------------
    # Context Helpers
    # -------------------------------------------------------------------------

    def set_user_input(
        self,
        original_query: str,
        normalized_text: Optional[str] = None,
        intent: Optional[str] = None,
    ) -> BlackboardEntry:
        """
        Set the user input context.

        Args:
            original_query: Raw user query
            normalized_text: Cleaned/normalized version
            intent: Detected intent

        Returns:
            The created entry
        """
        return self.add_entry(
            owner="sensorium",
            lane="user_input",
            visibility="internal",
            payload={
                "original_query": original_query,
                "normalized_text": normalized_text or original_query,
                "intent": intent,
            },
        )

    def get_user_input(self) -> Optional[Dict[str, Any]]:
        """Get the current user input context."""
        entry = self.get_latest(lane="user_input")
        return entry.payload if entry else None

    def add_planning_decision(
        self,
        owner: str,
        decision_type: str,
        decision: Any,
        reason: Optional[str] = None,
    ) -> BlackboardEntry:
        """
        Record a planning/routing decision.

        Args:
            owner: Component making the decision
            decision_type: Type of decision (e.g., "route", "brain_selection")
            decision: The decision value
            reason: Optional explanation

        Returns:
            The created entry
        """
        return self.add_entry(
            owner=owner,
            lane="planning",
            visibility="internal",
            payload={
                "type": decision_type,
                "decision": decision,
                "reason": reason,
            },
        )

    def add_telemetry(
        self,
        owner: str,
        event_type: str,
        data: Any,
    ) -> BlackboardEntry:
        """
        Add telemetry/debug data.

        Args:
            owner: Component generating telemetry
            event_type: Type of event
            data: Event data

        Returns:
            The created entry
        """
        return self.add_entry(
            owner=owner,
            lane="telemetry",
            visibility="internal",
            payload={
                "event_type": event_type,
                "data": data,
            },
        )

    # -------------------------------------------------------------------------
    # Serialization
    # -------------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Convert entire blackboard to dictionary."""
        return {
            "lanes": {
                lane: [e.to_dict() for e in entries]
                for lane, entries in self._lanes.items()
            },
            "seq_counter": self._seq_counter,
        }

    def get_summary(self) -> Dict[str, int]:
        """Get entry counts per lane."""
        return {
            lane: len(entries)
            for lane, entries in self._lanes.items()
        }

    def __repr__(self) -> str:
        counts = self.get_summary()
        return f"Blackboard({counts})"


# -----------------------------------------------------------------------------
# Factory Functions
# -----------------------------------------------------------------------------

def create_blackboard() -> Blackboard:
    """Create a new empty blackboard."""
    return Blackboard()


def create_blackboard_from_context(ctx: Dict[str, Any]) -> Blackboard:
    """
    Create a blackboard pre-populated from existing pipeline context.

    This adapter function helps bridge from the old dict-based context
    to the new lane-based blackboard.

    Args:
        ctx: Existing pipeline context dict

    Returns:
        New Blackboard with entries migrated from ctx
    """
    bb = Blackboard()

    # Migrate user input
    if "original_query" in ctx:
        bb.set_user_input(
            original_query=ctx.get("original_query", ""),
            normalized_text=ctx.get("normalized_text"),
            intent=ctx.get("intent"),
        )

    # Migrate agency tool info to planning
    if "agency_tool" in ctx:
        bb.add_planning_decision(
            owner="integrator",
            decision_type="agency_routing",
            decision={
                "tool": ctx.get("agency_tool"),
                "method": ctx.get("agency_method"),
                "args": ctx.get("agency_args", {}),
                "bypass_teacher": ctx.get("bypass_teacher", False),
            },
        )

    # Migrate stage outputs as telemetry
    for key in ctx:
        if key.startswith("stage_"):
            bb.add_telemetry(
                owner="migration",
                event_type="legacy_stage_output",
                data={key: ctx[key]},
            )

    return bb


# -----------------------------------------------------------------------------
# ContextState Integration (Phase 2)
# -----------------------------------------------------------------------------

def store_context_state(bb: "Blackboard", context_state: Any) -> BlackboardEntry:
    """
    Store a ContextState in the blackboard's context lane.

    Args:
        bb: Blackboard instance
        context_state: ContextState instance (or any object with to_dict())

    Returns:
        The created entry
    """
    payload = context_state.to_dict() if hasattr(context_state, "to_dict") else context_state

    return bb.add_entry(
        owner="context_manager",
        lane="context",
        visibility="internal",
        payload=payload,
        tags=["context_state"],
    )


def get_context_state(bb: "Blackboard") -> Optional[Dict[str, Any]]:
    """
    Get the latest ContextState from the blackboard.

    Args:
        bb: Blackboard instance

    Returns:
        The context state dict, or None
    """
    entry = bb.get_latest(lane="context")
    if entry and "context_state" in entry.tags:
        return entry.payload
    return entry.payload if entry else None


# -----------------------------------------------------------------------------
# Exports
# -----------------------------------------------------------------------------

__all__ = [
    # AnswerProvenance (new)
    "AnswerProvenance",
    "create_answer_provenance",
    # Types
    "Visibility",
    "STANDARD_LANES",
    "USER_FACING_LANES",
    "ADVISORY_LANES",
    "BlackboardEntry",
    "Blackboard",
    "create_blackboard",
    "create_blackboard_from_context",
    "store_context_state",
    "get_context_state",
]
