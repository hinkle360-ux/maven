"""
tool_output_formatter.py
~~~~~~~~~~~~~~~~~~~~~~~~

Formats tool outputs for user presentation.

This module ensures that raw tool outputs (dicts, error objects, etc.)
are converted to user-friendly strings before being marked as user_facing
in the blackboard.

The key principle: tool results stay internal, formatted text becomes user-facing.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, Optional, List, Callable, Union
from dataclasses import dataclass


# -----------------------------------------------------------------------------
# Output Formatter Registry
# -----------------------------------------------------------------------------

# Maps tool names to their custom formatters
_FORMATTERS: Dict[str, Callable[[Any], str]] = {}


def register_formatter(tool_name: str, formatter: Callable[[Any], str]) -> None:
    """
    Register a custom formatter for a tool.

    Args:
        tool_name: Name of the tool (e.g., "grok_conversation_session")
        formatter: Function that takes raw output and returns formatted string
    """
    _FORMATTERS[tool_name] = formatter


def get_formatter(tool_name: str) -> Optional[Callable[[Any], str]]:
    """Get the registered formatter for a tool, or None."""
    return _FORMATTERS.get(tool_name)


# -----------------------------------------------------------------------------
# Generic Formatting Functions
# -----------------------------------------------------------------------------

def format_tool_output(
    tool_name: str,
    raw_output: Any,
    query: str = "",
) -> str:
    """
    Format a tool's raw output into a user-friendly string.

    Args:
        tool_name: Name of the tool
        raw_output: Raw output from the tool
        query: Original user query for context

    Returns:
        Formatted string safe for user presentation
    """
    # Check for registered custom formatter
    formatter = _FORMATTERS.get(tool_name)
    if formatter:
        try:
            return formatter(raw_output)
        except Exception as e:
            return f"Tool completed. (Formatting error: {e})"

    # Handle string output directly
    if isinstance(raw_output, str):
        return _clean_string_output(raw_output)

    # Handle dict output
    if isinstance(raw_output, dict):
        return _format_dict_output(raw_output, tool_name)

    # Handle list output
    if isinstance(raw_output, list):
        return _format_list_output(raw_output, tool_name)

    # Fallback
    return f"Task completed. ({tool_name})"


def _clean_string_output(text: str) -> str:
    """Clean a string output for presentation."""
    if not text:
        return "Task completed."

    # Check if it looks like a raw dict/JSON (leaked internal data)
    if _looks_like_raw_dict(text):
        return "Task completed successfully."

    return text.strip()


def _looks_like_raw_dict(text: str) -> bool:
    """Check if text appears to be a raw dict representation."""
    text_start = text[:200].strip()

    # Python dict literal
    if text_start.startswith("{'") or text_start.startswith('{"'):
        return True

    # Common internal field patterns
    internal_patterns = [
        "'status':",
        '"status":',
        "'session_id':",
        "'facts_stored':",
        "'transcript_path':",
        "'page_id':",
        '"ok":',
    ]

    for pattern in internal_patterns:
        if pattern in text_start:
            return True

    return False


def _format_dict_output(data: Dict[str, Any], tool_name: str) -> str:
    """Format a dictionary output."""
    # Try known keys that contain user-friendly content
    friendly_keys = ["recap", "text", "answer", "response", "summary", "output", "message"]

    for key in friendly_keys:
        if key in data and isinstance(data[key], str) and data[key].strip():
            return _clean_string_output(data[key])

    # Check for status + message pattern
    if "status" in data:
        status = data["status"]
        if status == "success":
            if "message" in data:
                return data["message"]
            return "Task completed successfully."
        elif status == "error":
            error = data.get("error", data.get("message", "Unknown error"))
            return f"Error: {error}"
        elif status == "not_implemented":
            return data.get("output", "This feature is not implemented yet.")

    # For complex dicts, give a summary
    if len(data) > 0:
        # Try to extract meaningful info
        if "topic" in data:
            return f"Processed topic: {data['topic']}"
        if "query" in data:
            return f"Processed query: {data['query']}"

    return f"Task completed. ({tool_name})"


def _format_list_output(items: List[Any], tool_name: str) -> str:
    """Format a list output."""
    if not items:
        return "No results found."

    # If list of strings
    if all(isinstance(i, str) for i in items):
        if len(items) <= 5:
            return "\n".join(f"- {item}" for item in items)
        else:
            shown = "\n".join(f"- {item}" for item in items[:5])
            return f"{shown}\n... and {len(items) - 5} more"

    # If list of dicts with 'name' or 'title'
    if all(isinstance(i, dict) for i in items):
        names = []
        for item in items[:10]:
            name = item.get("name") or item.get("title") or str(item)
            names.append(name)
        result = "\n".join(f"- {n}" for n in names)
        if len(items) > 10:
            result += f"\n... and {len(items) - 10} more"
        return result

    return f"Found {len(items)} results."


# -----------------------------------------------------------------------------
# Tool-Specific Formatters
# -----------------------------------------------------------------------------

def format_grok_session_output(output: Any) -> str:
    """Format output from grok_conversation_session tool."""
    if isinstance(output, str):
        return output

    if isinstance(output, dict):
        # Prefer recap if available
        if "recap" in output:
            return output["recap"]

        # Build summary from available fields
        status = output.get("status", "unknown")
        topic = output.get("topic", "")
        facts = output.get("facts_stored", 0)

        if status == "completed":
            return f"Grok session on '{topic}' completed. Stored {facts} insights."
        elif status == "aborted":
            return f"Grok session on '{topic}' ended early. Stored {facts} insights."
        elif status == "error":
            error = output.get("error_message", "Unknown error")
            return f"Grok session error: {error}"

        return f"Grok session completed (status: {status})"

    return "Grok session completed."


def format_time_tool_output(output: Any) -> str:
    """Format output from time_now tool."""
    if isinstance(output, dict):
        # Check for formatted_response first
        if "formatted_response" in output:
            return output["formatted_response"]

        # Build from payload
        if "output" in output and isinstance(output["output"], dict):
            payload = output["output"]
            if "formatted" in payload:
                return payload["formatted"]
            if "date" in payload:
                return f"Today is {payload['date']}."
            if "time" in payload:
                return f"The time is {payload['time']}."

        if output.get("status") == "success":
            return "Time information retrieved successfully."

    if isinstance(output, str):
        return output

    return "Time information retrieved."


def format_shell_tool_output(output: Any) -> str:
    """Format output from shell_tool."""
    if isinstance(output, dict):
        # Check for formatted_response
        if "formatted_response" in output:
            return output["formatted_response"]

        status = output.get("status")
        stdout = output.get("output", "")
        stderr = output.get("stderr", "")
        error = output.get("error", "")

        if status == "success":
            if stdout:
                # Truncate long output
                if len(stdout) > 2000:
                    return stdout[:2000] + "\n... (output truncated)"
                return stdout
            return "Command executed successfully."
        else:
            if error:
                return f"Error: {error}"
            if stderr:
                return f"Error: {stderr}"
            return "Command failed."

    if isinstance(output, str):
        return output

    return "Command executed."


def format_browser_tool_output(output: Any) -> str:
    """Format output from browser_runtime tool."""
    if isinstance(output, dict):
        if "formatted_response" in output:
            return output["formatted_response"]

        status = output.get("status")
        if status == "success":
            return "Browser action completed."
        elif status == "error":
            return f"Browser error: {output.get('error', 'Unknown error')}"

    if isinstance(output, str):
        return output

    return "Browser action completed."


def format_self_introspection_output(output: Any) -> str:
    """Format output from self_introspection tool."""
    if isinstance(output, dict):
        # Check for text/formatted content
        for key in ["text", "analysis", "report", "output"]:
            if key in output and isinstance(output[key], str):
                return output[key]

    if isinstance(output, str):
        return output

    return "Introspection completed."


def format_chatgpt_session_output(output: Any) -> str:
    """Format output from chatgpt_conversation_session tool."""
    if isinstance(output, str):
        return output

    if isinstance(output, dict):
        # Prefer recap if available
        if "recap" in output:
            return output["recap"]

        # Build summary from available fields
        status = output.get("status", "unknown")
        topic = output.get("topic", "")
        facts = output.get("facts_stored", 0)

        if status == "completed":
            return f"ChatGPT session on '{topic}' completed. Stored {facts} insights."
        elif status == "aborted":
            return f"ChatGPT session on '{topic}' ended early. Stored {facts} insights."
        elif status == "error":
            error = output.get("error_message", "Unknown error")
            return f"ChatGPT session error: {error}"

        return f"ChatGPT session completed (status: {status})"

    return "ChatGPT session completed."


def format_claude_session_output(output: Any) -> str:
    """Format output from claude_conversation_session tool."""
    if isinstance(output, str):
        return output

    if isinstance(output, dict):
        # Prefer recap if available
        if "recap" in output:
            return output["recap"]

        # Build summary from available fields
        status = output.get("status", "unknown")
        topic = output.get("topic", "")
        facts = output.get("facts_stored", 0)

        if status == "completed":
            return f"Claude session on '{topic}' completed. Stored {facts} insights."
        elif status == "aborted":
            return f"Claude session on '{topic}' ended early. Stored {facts} insights."
        elif status == "error":
            error = output.get("error_message", "Unknown error")
            return f"Claude session error: {error}"

        return f"Claude session completed (status: {status})"

    return "Claude session completed."


# -----------------------------------------------------------------------------
# Register Default Formatters
# -----------------------------------------------------------------------------

# Register tool-specific formatters
register_formatter("grok_conversation_session", format_grok_session_output)
register_formatter("get_grok_conversation_controller", format_grok_session_output)

# ChatGPT session formatters
register_formatter("chatgpt_conversation_session", format_chatgpt_session_output)
register_formatter("get_chatgpt_conversation_controller", format_chatgpt_session_output)

# Claude session formatters
register_formatter("claude_conversation_session", format_claude_session_output)
register_formatter("get_claude_conversation_controller", format_claude_session_output)
register_formatter("time_now", format_time_tool_output)
register_formatter("shell_tool", format_shell_tool_output)
register_formatter("browser_runtime", format_browser_tool_output)
register_formatter("browser_action", format_browser_tool_output)
register_formatter("self_introspection", format_self_introspection_output)
register_formatter("get_self_introspection", format_self_introspection_output)


# -----------------------------------------------------------------------------
# Validation Functions
# -----------------------------------------------------------------------------

def validate_user_facing_content(text: str) -> tuple[bool, str]:
    """
    Validate that content is safe for user presentation.

    Args:
        text: Text to validate

    Returns:
        Tuple of (is_valid, cleaned_text_or_error_message)
    """
    if not text:
        return False, "Empty content"

    if _looks_like_raw_dict(text):
        return False, "Content appears to be raw internal data"

    # Check for other problematic patterns
    if "Traceback (most recent call last)" in text:
        return False, "Content contains Python traceback"

    if text.startswith("Error:") and len(text) < 20:
        return False, "Content is bare error without details"

    return True, text.strip()


def ensure_string_output(output: Any, tool_name: str = "unknown") -> str:
    """
    Ensure output is a string suitable for user presentation.

    This is the primary entry point for converting tool outputs.

    Args:
        output: Any tool output
        tool_name: Name of the tool for context

    Returns:
        User-friendly string
    """
    formatted = format_tool_output(tool_name, output)
    is_valid, result = validate_user_facing_content(formatted)

    if is_valid:
        return result
    else:
        # Log the issue
        print(f"[TOOL_FORMATTER] Invalid content from {tool_name}: {result}")
        return "Task completed successfully."


# -----------------------------------------------------------------------------
# Exports
# -----------------------------------------------------------------------------

__all__ = [
    "register_formatter",
    "get_formatter",
    "format_tool_output",
    "format_grok_session_output",
    "format_time_tool_output",
    "format_shell_tool_output",
    "format_browser_tool_output",
    "validate_user_facing_content",
    "ensure_string_output",
]
