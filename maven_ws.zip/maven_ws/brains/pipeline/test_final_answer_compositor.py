"""
test_final_answer_compositor.py
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Tests for the FinalAnswerCompositor.

Run with: python -m unittest brains.pipeline.test_final_answer_compositor -v
"""

import unittest

from brains.pipeline.blackboard import Blackboard
from brains.pipeline.final_answer_compositor import (
    FinalAnswerCompositor,
    ComposedAnswer,
    AnswerSource,
    run_sanity_checks,
    check_raw_dict_leak,
    check_traceback_leak,
    check_empty_or_minimal,
    check_repetitive_content,
    compose_final_answer,
)


class TestSanityChecks(unittest.TestCase):
    """Tests for individual sanity check functions."""

    def test_raw_dict_leak_python_dict(self):
        passed, issue = check_raw_dict_leak("{'status': 'ok'}")
        self.assertFalse(passed)
        self.assertIn("dict literal", issue)

    def test_raw_dict_leak_json(self):
        passed, issue = check_raw_dict_leak('{"ok": true}')
        self.assertFalse(passed)

    def test_raw_dict_leak_internal_field(self):
        passed, issue = check_raw_dict_leak("Result: 'session_id': abc123")
        self.assertFalse(passed)
        self.assertIn("session_id", issue)

    def test_raw_dict_leak_clean_text(self):
        passed, issue = check_raw_dict_leak("This is a clean response.")
        self.assertTrue(passed)
        self.assertIsNone(issue)

    def test_traceback_leak_detected(self):
        text = "Traceback (most recent call last):\n  File \"test.py\", line 1"
        passed, issue = check_traceback_leak(text)
        self.assertFalse(passed)

    def test_traceback_clean_text(self):
        passed, issue = check_traceback_leak("Normal error message")
        self.assertTrue(passed)

    def test_empty_response_fails(self):
        passed, issue = check_empty_or_minimal("")
        self.assertFalse(passed)
        self.assertIn("Empty", issue)

    def test_short_response_fails(self):
        passed, issue = check_empty_or_minimal("Ok")
        self.assertFalse(passed)
        self.assertIn("short", issue)

    def test_adequate_response_passes(self):
        passed, issue = check_empty_or_minimal("This is a complete response.")
        self.assertTrue(passed)

    def test_repetitive_content_detected(self):
        text = "hello world " * 50  # Highly repetitive
        passed, issue = check_repetitive_content(text)
        self.assertFalse(passed)
        self.assertIn("repeated", issue)

    def test_normal_content_passes(self):
        text = "This is a normal response with varied content and different words."
        passed, issue = check_repetitive_content(text)
        self.assertTrue(passed)


class TestRunSanityChecks(unittest.TestCase):
    """Tests for the combined sanity check runner."""

    def test_clean_text_passes_all(self):
        text = "Here is a complete and proper response to your query."
        passed, issues = run_sanity_checks(text)
        self.assertTrue(passed)
        self.assertEqual(issues, [])

    def test_dict_leak_caught(self):
        text = "{'status': 'completed'}"
        passed, issues = run_sanity_checks(text)
        self.assertFalse(passed)
        self.assertTrue(len(issues) > 0)

    def test_multiple_issues_caught(self):
        text = ""  # Empty - fails minimal check
        passed, issues = run_sanity_checks(text)
        self.assertFalse(passed)


class TestFinalAnswerCompositor(unittest.TestCase):
    """Tests for the FinalAnswerCompositor class."""

    def setUp(self):
        self.bb = Blackboard()

    def test_compose_with_valid_answer(self):
        self.bb.add_entry(
            owner="grok_tool",
            lane="answer_candidates",
            visibility="user_facing",
            payload="This is a great answer from Grok.",
            tags=["tool:grok"],
        )

        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose()

        self.assertEqual(result.text, "This is a great answer from Grok.")
        self.assertTrue(result.passed_sanity)
        self.assertFalse(result.is_fallback)
        self.assertEqual(len(result.sources), 1)
        self.assertEqual(result.sources[0].source_type, "tool")

    def test_compose_returns_fallback_when_empty(self):
        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose(allow_fallback=True)

        self.assertTrue(result.is_fallback)
        self.assertTrue(result.passed_sanity)
        self.assertIn("completed", result.text.lower())

    def test_compose_no_fallback_returns_empty(self):
        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose(allow_fallback=False)

        self.assertFalse(result.passed_sanity)
        self.assertEqual(result.text, "")

    def test_compose_skips_bad_candidates(self):
        # Add a bad candidate first
        self.bb.add_entry(
            owner="bad_tool",
            lane="answer_candidates",
            visibility="user_facing",
            payload="{'raw': 'dict'}",  # Will fail sanity
            tags=["tool:bad"],
        )
        # Add a good candidate
        self.bb.add_entry(
            owner="good_tool",
            lane="answer_candidates",
            visibility="user_facing",
            payload="This is a proper answer.",
            tags=["tool:good"],
        )

        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose()

        self.assertEqual(result.text, "This is a proper answer.")
        self.assertTrue(result.passed_sanity)

    def test_compose_prefers_tool_answers(self):
        # Add reasoning answer first
        self.bb.add_entry(
            owner="reasoning",
            lane="answer_candidates",
            visibility="user_facing",
            payload="Answer from reasoning.",
            tags=["reasoning"],
        )
        # Add tool answer second
        self.bb.add_entry(
            owner="grok",
            lane="answer_candidates",
            visibility="user_facing",
            payload="Answer from tool.",
            tags=["tool:grok"],
        )

        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose(prefer_tool_answers=True)

        self.assertEqual(result.text, "Answer from tool.")
        self.assertEqual(result.sources[0].source_type, "tool")

    def test_compose_extracts_text_from_dict(self):
        self.bb.add_entry(
            owner="tool",
            lane="answer_candidates",
            visibility="user_facing",
            payload={"text": "Extracted text content.", "confidence": 0.9},
            tags=["tool:test"],
        )

        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose()

        self.assertEqual(result.text, "Extracted text content.")

    def test_compose_extracts_recap_from_dict(self):
        self.bb.add_entry(
            owner="grok",
            lane="answer_candidates",
            visibility="user_facing",
            payload={"recap": "Session recap here.", "status": "completed"},
            tags=["tool:grok"],
        )

        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose()

        self.assertEqual(result.text, "Session recap here.")

    def test_compose_only_reads_user_facing(self):
        # Add internal entry (should be ignored)
        self.bb.add_entry(
            owner="tool",
            lane="tool_results",
            visibility="internal",
            payload="Internal data",
        )

        compositor = FinalAnswerCompositor(self.bb)
        result = compositor.compose(allow_fallback=True)

        # Should use fallback since no user_facing entries
        self.assertTrue(result.is_fallback)


class TestComposedAnswer(unittest.TestCase):
    """Tests for ComposedAnswer dataclass."""

    def test_to_dict(self):
        source = AnswerSource(
            entry_id="abc",
            owner="tool",
            source_type="tool",
            confidence=0.9,
        )
        answer = ComposedAnswer(
            text="Test answer",
            sources=[source],
            confidence=0.9,
            passed_sanity=True,
        )

        d = answer.to_dict()
        self.assertEqual(d["text"], "Test answer")
        self.assertEqual(len(d["sources"]), 1)
        self.assertEqual(d["confidence"], 0.9)


class TestConvenienceFunctions(unittest.TestCase):
    """Tests for convenience functions."""

    def test_compose_final_answer(self):
        bb = Blackboard()
        bb.add_entry(
            owner="tool",
            lane="answer_candidates",
            visibility="user_facing",
            payload="Quick answer.",
        )

        text = compose_final_answer(bb)
        self.assertEqual(text, "Quick answer.")

    def test_compose_final_answer_empty_blackboard(self):
        bb = Blackboard()
        text = compose_final_answer(bb)

        # Should return fallback
        self.assertTrue(len(text) > 0)


if __name__ == "__main__":
    unittest.main()
