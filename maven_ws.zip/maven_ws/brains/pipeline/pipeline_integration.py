"""
pipeline_integration.py
~~~~~~~~~~~~~~~~~~~~~~~

Integrates the Blackboard system into Maven's processing pipeline.

This module provides:
1. Pipeline context that includes a Blackboard instance
2. Hooks for each stage to read/write the blackboard
3. Final answer extraction using the compositor

Usage:
    # At pipeline start
    pipeline_ctx = create_pipeline_context(user_query)

    # During tool execution
    execute_tool_with_context(pipeline_ctx, tool_path, method, args)

    # At pipeline end
    final_answer = extract_final_answer(pipeline_ctx)

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, Optional, TYPE_CHECKING
from dataclasses import dataclass, field
from datetime import datetime
import uuid

# Import blackboard components
from brains.pipeline.blackboard import (
    Blackboard,
    create_blackboard,
    store_context_state,
    get_context_state,
)

# Import context state
try:
    from brains.cognitive.context_management.context_state import (
        ContextState,
        get_or_create_context,
    )
    _context_state_available = True
except ImportError:
    _context_state_available = False
    ContextState = None
    get_or_create_context = None

# Import compositor
try:
    from brains.pipeline.final_answer_compositor import (
        FinalAnswerCompositor,
        compose_final_answer,
    )
    _compositor_available = True
except ImportError:
    _compositor_available = False
    FinalAnswerCompositor = None
    compose_final_answer = None

# Import agency executor with blackboard support
try:
    from brains.cognitive.integrator.agency_executor import (
        execute_agency_tool_with_blackboard,
        execute_agency_tool,
        format_agency_response,
    )
    _agency_executor_available = True
except ImportError:
    _agency_executor_available = False


# -----------------------------------------------------------------------------
# Pipeline Context
# -----------------------------------------------------------------------------

@dataclass
class PipelineContext:
    """
    Context for a single pipeline execution.

    This bundles together:
    - The blackboard for structured state
    - The context state for conversation tracking
    - Original query and metadata

    Usage:
        ctx = PipelineContext.create("What time is it?")
        ctx.record_stage("stage_5", {"routing": "action_engine"})
        answer = ctx.get_final_answer()
    """

    # Identity
    pipeline_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    created_at: datetime = field(default_factory=datetime.now)

    # Core state
    blackboard: Blackboard = field(default_factory=create_blackboard)
    context_state: Optional[Any] = None  # ContextState if available

    # Original request
    original_query: str = ""
    normalized_query: str = ""
    intent: str = ""

    # Stage tracking
    current_stage: str = ""
    completed_stages: list = field(default_factory=list)

    # Routing info
    routed_to: str = ""
    agency_tool: Optional[str] = None
    agency_method: Optional[str] = None
    bypass_teacher: bool = False

    @classmethod
    def create(
        cls,
        query: str,
        normalized: Optional[str] = None,
        intent: Optional[str] = None,
        conversation_id: Optional[str] = None,
    ) -> "PipelineContext":
        """
        Create a new pipeline context for a query.

        Args:
            query: Original user query
            normalized: Normalized version of query
            intent: Detected intent
            conversation_id: Optional conversation ID for continuity

        Returns:
            Initialized PipelineContext
        """
        ctx = cls(
            original_query=query,
            normalized_query=normalized or query,
            intent=intent or "",
        )

        # Initialize blackboard with user input
        ctx.blackboard.set_user_input(
            original_query=query,
            normalized_text=normalized,
            intent=intent,
        )

        # Initialize context state if available
        if _context_state_available and get_or_create_context:
            ctx.context_state = get_or_create_context(conversation_id)

        return ctx

    def record_stage(
        self,
        stage_name: str,
        stage_output: Dict[str, Any],
        is_final: bool = False,
    ) -> None:
        """
        Record stage completion.

        Args:
            stage_name: Name of the stage (e.g., "stage_5", "stage_6")
            stage_output: Output from the stage
            is_final: Whether this is the final stage
        """
        self.current_stage = stage_name
        self.completed_stages.append(stage_name)

        # Record to blackboard telemetry
        self.blackboard.add_telemetry(
            owner=stage_name,
            event_type="stage_completed",
            data={
                "stage": stage_name,
                "output_keys": list(stage_output.keys()) if stage_output else [],
                "is_final": is_final,
            },
        )

    def set_routing(
        self,
        route: str,
        agency_tool: Optional[str] = None,
        agency_method: Optional[str] = None,
        agency_args: Optional[Dict[str, Any]] = None,
        bypass_teacher: bool = False,
    ) -> None:
        """
        Record routing decision.

        Args:
            route: The route selected (e.g., "action_engine", "language")
            agency_tool: Tool path if agency routing
            agency_method: Method to call
            agency_args: Arguments to pass
            bypass_teacher: Whether to bypass teacher
        """
        self.routed_to = route
        self.agency_tool = agency_tool
        self.agency_method = agency_method
        self.bypass_teacher = bypass_teacher

        # Record to blackboard planning lane
        self.blackboard.add_planning_decision(
            owner="router",
            decision_type="route_selection",
            decision={
                "route": route,
                "agency_tool": agency_tool,
                "agency_method": agency_method,
                "agency_args": agency_args,
                "bypass_teacher": bypass_teacher,
            },
            reason=f"Routed query to {route}",
        )

    def execute_agency_tool(
        self,
        tool_path: Optional[str] = None,
        method: Optional[str] = None,
        args: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Execute an agency tool and record results.

        Args:
            tool_path: Tool path (uses stored if not provided)
            method: Method name (uses stored if not provided)
            args: Arguments (uses stored if not provided)

        Returns:
            Formatted answer string
        """
        tool = tool_path or self.agency_tool
        method = method or self.agency_method

        if not tool:
            return "No tool specified for execution."

        if _agency_executor_available:
            # Use blackboard-aware executor
            return execute_agency_tool_with_blackboard(
                tool_path=tool,
                method_name=method,
                args=args or {},
                blackboard=self.blackboard,
                query=self.original_query,
            )
        else:
            # Fallback to basic executor
            result = execute_agency_tool(tool, method, args)
            return format_agency_response(self.original_query, result)

    def add_answer_candidate(
        self,
        text: str,
        owner: str = "pipeline",
        confidence: float = 0.9,
    ) -> None:
        """
        Add an answer candidate to the blackboard.

        Args:
            text: Answer text
            owner: Component adding the answer
            confidence: Confidence score
        """
        self.blackboard.add_answer_candidate(
            owner=owner,
            text=text,
            confidence=confidence,
        )

    def get_final_answer(self) -> str:
        """
        Extract the final answer from the blackboard.

        Returns:
            Final answer string
        """
        if _compositor_available and compose_final_answer:
            return compose_final_answer(self.blackboard)

        # Fallback to direct blackboard access
        answer = self.blackboard.get_user_facing_answer()
        return answer or "I've completed the task."

    def record_conversation_turn(
        self,
        response: str,
        topic: str = "",
    ) -> None:
        """
        Record this turn in conversation history.

        Args:
            response: The final response
            topic: Extracted topic
        """
        if self.context_state and hasattr(self.context_state, "record_turn"):
            self.context_state.record_turn(
                query=self.original_query,
                response=response,
                topic=topic or self.intent,
            )

            # Store updated context in blackboard
            store_context_state(self.blackboard, self.context_state)

    def to_legacy_context(self) -> Dict[str, Any]:
        """
        Convert to legacy context dict for backwards compatibility.

        Returns:
            Dict compatible with existing stage functions
        """
        return {
            "original_query": self.original_query,
            "normalized_text": self.normalized_query,
            "intent": self.intent,
            "routed_to": self.routed_to,
            "agency_tool": self.agency_tool,
            "agency_method": self.agency_method,
            "bypass_teacher": self.bypass_teacher,
            "_pipeline_context": self,  # Embed for access
            "_blackboard": self.blackboard,  # Direct blackboard access
        }

    @classmethod
    def from_legacy_context(cls, ctx: Dict[str, Any]) -> "PipelineContext":
        """
        Create from legacy context dict.

        Args:
            ctx: Legacy context dict

        Returns:
            PipelineContext
        """
        # Check if already embedded
        if "_pipeline_context" in ctx:
            return ctx["_pipeline_context"]

        # Create new from dict
        pipeline_ctx = cls.create(
            query=ctx.get("original_query", ""),
            normalized=ctx.get("normalized_text"),
            intent=ctx.get("intent"),
        )

        # Migrate routing info
        if ctx.get("agency_tool"):
            pipeline_ctx.set_routing(
                route=ctx.get("routed_to", "action_engine"),
                agency_tool=ctx.get("agency_tool"),
                agency_method=ctx.get("agency_method"),
                agency_args=ctx.get("agency_args"),
                bypass_teacher=ctx.get("bypass_teacher", False),
            )

        return pipeline_ctx


# -----------------------------------------------------------------------------
# Pipeline Hooks
# -----------------------------------------------------------------------------

# Global current context (for legacy compatibility)
_current_pipeline_context: Optional[PipelineContext] = None


def get_current_pipeline_context() -> Optional[PipelineContext]:
    """Get the current pipeline context, if any."""
    return _current_pipeline_context


def set_current_pipeline_context(ctx: Optional[PipelineContext]) -> None:
    """Set the current pipeline context."""
    global _current_pipeline_context
    _current_pipeline_context = ctx


def create_pipeline_context(
    query: str,
    **kwargs,
) -> PipelineContext:
    """
    Create and set the current pipeline context.

    Args:
        query: User query
        **kwargs: Additional arguments for PipelineContext.create()

    Returns:
        The created context
    """
    ctx = PipelineContext.create(query, **kwargs)
    set_current_pipeline_context(ctx)
    return ctx


def extract_final_answer(ctx: Optional[PipelineContext] = None) -> str:
    """
    Extract the final answer from the pipeline.

    Args:
        ctx: Pipeline context (uses current if not provided)

    Returns:
        Final answer string
    """
    ctx = ctx or _current_pipeline_context
    if ctx:
        return ctx.get_final_answer()
    return "I've completed the task."


def cleanup_pipeline_context() -> None:
    """Clean up the current pipeline context."""
    global _current_pipeline_context
    _current_pipeline_context = None


# -----------------------------------------------------------------------------
# Stage Integration Helpers
# -----------------------------------------------------------------------------

def with_pipeline_context(stage_func):
    """
    Decorator to inject pipeline context into stage functions.

    Usage:
        @with_pipeline_context
        def stage_6_candidates(ctx, pipeline_ctx=None):
            # Use pipeline_ctx.blackboard
            pass
    """
    from functools import wraps

    @wraps(stage_func)
    def wrapper(ctx, *args, **kwargs):
        # Get or create pipeline context
        pipeline_ctx = kwargs.get("pipeline_ctx")
        if not pipeline_ctx:
            pipeline_ctx = _current_pipeline_context
            if not pipeline_ctx and isinstance(ctx, dict):
                pipeline_ctx = PipelineContext.from_legacy_context(ctx)
            kwargs["pipeline_ctx"] = pipeline_ctx

        return stage_func(ctx, *args, **kwargs)

    return wrapper


# -----------------------------------------------------------------------------
# Exports
# -----------------------------------------------------------------------------

__all__ = [
    "PipelineContext",
    "create_pipeline_context",
    "get_current_pipeline_context",
    "set_current_pipeline_context",
    "extract_final_answer",
    "cleanup_pipeline_context",
    "with_pipeline_context",
]
