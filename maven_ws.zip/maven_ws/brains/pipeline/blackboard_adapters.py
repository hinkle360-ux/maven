"""
blackboard_adapters.py
~~~~~~~~~~~~~~~~~~~~~~

Adapters to bridge existing Maven code to the new lane-based Blackboard.

These adapters allow gradual migration from:
- Dict-based ctx passing between stages
- Module-level globals in memory_librarian
- The simple PipelineBlackboard

to the new lane-based Blackboard with visibility controls.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, Optional, Callable
from functools import wraps

from brains.pipeline.blackboard import (
    Blackboard,
    BlackboardEntry,
    Visibility,
    create_blackboard,
)


# -----------------------------------------------------------------------------
# Stage Adapter: Wraps stage functions to use Blackboard
# -----------------------------------------------------------------------------

class StageAdapter:
    """
    Adapter that wraps a pipeline stage to use the new Blackboard.

    This allows existing stages that work with dict contexts to
    transparently use the lane-based Blackboard.

    Example:
        # Old stage function signature
        def stage_6_candidates(ctx: Dict[str, Any]) -> Dict[str, Any]:
            ...

        # Wrapped with adapter
        adapter = StageAdapter("stage_6", stage_6_candidates)
        result = adapter.execute(blackboard)
    """

    def __init__(
        self,
        stage_name: str,
        stage_func: Callable[[Dict[str, Any]], Dict[str, Any]],
        output_lane: str = "telemetry",
        output_visibility: Visibility = "internal",
    ):
        """
        Initialize the adapter.

        Args:
            stage_name: Name of this stage (e.g., "stage_6")
            stage_func: The original stage function
            output_lane: Lane to write stage output to
            output_visibility: Visibility of stage output
        """
        self.stage_name = stage_name
        self.stage_func = stage_func
        self.output_lane = output_lane
        self.output_visibility = output_visibility

    def execute(self, bb: Blackboard) -> Dict[str, Any]:
        """
        Execute the stage with blackboard context.

        Args:
            bb: The blackboard

        Returns:
            Stage output dict
        """
        # Build ctx dict from blackboard for backwards compatibility
        ctx = self._blackboard_to_ctx(bb)

        # Execute stage
        result = self.stage_func(ctx)

        # Write result back to blackboard
        if result:
            self._result_to_blackboard(result, bb)

        return result

    def _blackboard_to_ctx(self, bb: Blackboard) -> Dict[str, Any]:
        """Convert blackboard entries to legacy ctx dict."""
        ctx = {}

        # Extract user input
        user_input = bb.get_user_input()
        if user_input:
            ctx["original_query"] = user_input.get("original_query", "")
            ctx["normalized_text"] = user_input.get("normalized_text", "")
            ctx["intent"] = user_input.get("intent")

        # Extract planning decisions (for agency routing)
        planning_entries = bb.get_entries(lane="planning")
        for entry in planning_entries:
            if entry.payload.get("type") == "agency_routing":
                decision = entry.payload.get("decision", {})
                ctx["agency_tool"] = decision.get("tool")
                ctx["agency_method"] = decision.get("method")
                ctx["agency_args"] = decision.get("args", {})
                ctx["bypass_teacher"] = decision.get("bypass_teacher", False)

        # Extract latest tool result for stage processing
        tool_result = bb.get_latest(lane="tool_results")
        if tool_result:
            ctx["_tool_result_entry"] = tool_result
            ctx["_tool_result_payload"] = tool_result.payload

        # Extract latest answer candidate
        answer = bb.get_latest(lane="answer_candidates", visibility="user_facing")
        if answer:
            ctx["final_answer"] = answer.payload

        return ctx

    def _result_to_blackboard(self, result: Dict[str, Any], bb: Blackboard) -> None:
        """Write stage result back to blackboard."""
        # Record the stage output
        bb.add_entry(
            owner=self.stage_name,
            lane=self.output_lane,
            visibility=self.output_visibility,
            payload=result,
            tags=[f"stage:{self.stage_name}"],
        )

        # Handle special keys in result
        if "blackboard_updates" in result:
            # Legacy: stages can request blackboard updates
            for key, value in result["blackboard_updates"].items():
                bb.add_entry(
                    owner=self.stage_name,
                    lane="telemetry",
                    visibility="internal",
                    payload={key: value},
                    tags=["blackboard_update"],
                )


# -----------------------------------------------------------------------------
# Tool Output Adapter: Ensures tool results never leak to users
# -----------------------------------------------------------------------------

class ToolOutputAdapter:
    """
    Adapter that wraps tool execution to ensure proper visibility.

    This adapter:
    1. Captures raw tool output as internal
    2. Extracts/formats user-facing content
    3. Writes user-facing answer candidate

    Example:
        adapter = ToolOutputAdapter("grok_tool")
        adapter.capture_result(bb, raw_output)
        adapter.publish_answer(bb, formatted_text)
    """

    def __init__(self, tool_name: str):
        """
        Initialize the adapter.

        Args:
            tool_name: Name of the tool (e.g., "grok_tool")
        """
        self.tool_name = tool_name
        self._last_result_id: Optional[str] = None

    def capture_result(
        self,
        bb: Blackboard,
        raw_output: Any,
        tags: Optional[list] = None,
    ) -> BlackboardEntry:
        """
        Capture raw tool output as internal.

        Args:
            bb: The blackboard
            raw_output: Raw output from the tool (dict, string, etc.)
            tags: Optional tags

        Returns:
            The created entry
        """
        entry = bb.add_tool_result(
            owner=self.tool_name,
            payload=raw_output,
            tags=tags or [f"tool:{self.tool_name}"],
        )
        self._last_result_id = entry.id
        return entry

    def publish_answer(
        self,
        bb: Blackboard,
        text: str,
        confidence: float = 0.99,
    ) -> BlackboardEntry:
        """
        Publish a user-facing answer derived from tool output.

        Args:
            bb: The blackboard
            text: Formatted answer text
            confidence: Confidence score

        Returns:
            The created entry
        """
        return bb.add_answer_candidate(
            owner=self.tool_name,
            text=text,
            confidence=confidence,
            source_entry_id=self._last_result_id,
            tags=[f"tool:{self.tool_name}", "tool_answer"],
        )

    def capture_and_publish(
        self,
        bb: Blackboard,
        raw_output: Any,
        formatter: Optional[Callable[[Any], str]] = None,
    ) -> str:
        """
        Capture raw output and publish formatted answer in one call.

        Args:
            bb: The blackboard
            raw_output: Raw tool output
            formatter: Optional function to format output as string

        Returns:
            The formatted answer text
        """
        # Capture raw
        self.capture_result(bb, raw_output)

        # Format for user
        if formatter:
            text = formatter(raw_output)
        elif isinstance(raw_output, str):
            text = raw_output
        elif isinstance(raw_output, dict):
            # Default formatting for dicts
            text = self._default_dict_formatter(raw_output)
        else:
            text = str(raw_output)

        # Publish
        self.publish_answer(bb, text)

        return text

    def _default_dict_formatter(self, d: Dict[str, Any]) -> str:
        """Default formatter for dict outputs."""
        # Try common keys that might contain the answer
        for key in ["recap", "text", "answer", "response", "output", "summary"]:
            if key in d and isinstance(d[key], str):
                return d[key]

        # If dict has a status and message
        if "status" in d and "message" in d:
            return f"{d.get('status', 'Done')}: {d.get('message', '')}"

        # Last resort: summarize the dict
        return f"Tool completed with {len(d)} result fields."


# -----------------------------------------------------------------------------
# Agency Executor Adapter
# -----------------------------------------------------------------------------

def wrap_agency_executor(
    execute_func: Callable[..., Dict[str, Any]],
    bb: Blackboard,
) -> Callable[..., str]:
    """
    Wrap the agency executor to use blackboard for output handling.

    Args:
        execute_func: The original execute_agency_tool function
        bb: The blackboard

    Returns:
        Wrapped function that returns user-facing string
    """
    @wraps(execute_func)
    def wrapped(tool_path: str, method: str, args: dict) -> str:
        # Execute the tool
        result = execute_func(tool_path, method, args)

        # Extract tool name from path
        tool_name = tool_path.split(".")[-1] if "." in tool_path else tool_path

        # Create adapter for this tool
        adapter = ToolOutputAdapter(tool_name)

        # Capture and format
        answer = adapter.capture_and_publish(bb, result)

        return answer

    return wrapped


# -----------------------------------------------------------------------------
# Final Answer Extractor
# -----------------------------------------------------------------------------

def extract_final_answer(bb: Blackboard) -> Optional[str]:
    """
    Extract the final user-facing answer from the blackboard.

    This is the canonical way to get the answer to show users.
    It ONLY looks at user_facing entries in answer_candidates.

    Args:
        bb: The blackboard

    Returns:
        The final answer string, or None
    """
    return bb.get_user_facing_answer()


def sanity_check_answer(answer: Optional[str]) -> Optional[str]:
    """
    Sanity check the final answer before showing to user.

    Args:
        answer: The answer to check

    Returns:
        The answer if valid, None if suspicious
    """
    if not answer:
        return None

    # Check for dict-like content that shouldn't be user-facing
    suspicious_patterns = [
        "{'",        # Dict literal
        '{"',        # JSON dict
        "status': ", # Common dict key
        '"ok":',     # JSON response marker
        "session_id", # Internal field
    ]

    for pattern in suspicious_patterns:
        if pattern in answer:
            # Log warning but don't expose to user
            return None

    return answer


# -----------------------------------------------------------------------------
# Exports
# -----------------------------------------------------------------------------

__all__ = [
    "StageAdapter",
    "ToolOutputAdapter",
    "wrap_agency_executor",
    "extract_final_answer",
    "sanity_check_answer",
]
