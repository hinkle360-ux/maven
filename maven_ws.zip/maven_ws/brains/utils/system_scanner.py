# brains/core/system_scanner.py
"""
Dynamic System Scanner
======================

Scans Maven's filesystem to discover all brains, tools, engines, and modules.
This replaces static registration with dynamic discovery.

The scanner:
1. Walks the filesystem looking for components
2. Reads metadata from docstrings, class definitions, annotations
3. Classifies components by type (brain, tool, engine, helper, etc.)
4. Builds a runtime registry of all discovered components
5. Generates dynamic self-descriptions

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
import os
import re
import ast
from pathlib import Path
from typing import Dict, List, Any, Optional, Set, Tuple
from dataclasses import dataclass, field
from enum import Enum
import json


# =============================================================================
# Component Classification
# =============================================================================

class ComponentType(str, Enum):
    """Types of Maven components."""
    COGNITIVE_BRAIN = "cognitive_brain"
    ROUTING_BRAIN = "routing_brain"
    PIPELINE_COMPONENT = "pipeline_component"
    TOOL = "tool"
    ENGINE = "engine"
    MEMORY_MODULE = "memory_module"
    SAFETY_LAYER = "safety_layer"
    HELPER = "helper"
    GOVERNANCE = "governance"
    LEARNING = "learning"
    AGENT = "agent"
    UNKNOWN = "unknown"


@dataclass
class DiscoveredComponent:
    """A component discovered by the scanner."""
    id: str
    name: str
    component_type: ComponentType
    path: str
    description: str = ""
    module_path: str = ""
    classes: List[str] = field(default_factory=list)
    functions: List[str] = field(default_factory=list)
    capabilities: Set[str] = field(default_factory=set)
    dependencies: List[str] = field(default_factory=list)
    has_service: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "type": self.component_type.value,
            "path": self.path,
            "description": self.description,
            "module_path": self.module_path,
            "classes": self.classes,
            "functions": self.functions,
            "capabilities": list(self.capabilities),
            "has_service": self.has_service,
        }


# =============================================================================
# System Scanner
# =============================================================================

class SystemScanner:
    """
    Scans Maven's filesystem to discover all components.

    Usage:
        scanner = SystemScanner("/path/to/maven")
        components = scanner.scan_all()
        summary = scanner.get_system_summary()
    """

    def __init__(self, base_path: str = None):
        if base_path is None:
            # Find the maven2_fix directory
            current = Path(__file__).resolve()
            while current.name != "maven2_fix" and current.parent != current:
                current = current.parent
            base_path = str(current)

        self.base_path = Path(base_path)
        self.components: Dict[str, DiscoveredComponent] = {}
        self._scanned = False

    def scan_all(self) -> Dict[str, DiscoveredComponent]:
        """Scan all Maven directories and discover components."""
        if self._scanned:
            return self.components

        # Scan cognitive brains
        self._scan_cognitive_brains()

        # Scan tools
        self._scan_tools()

        # Scan routing
        self._scan_routing()

        # Scan engines
        self._scan_engines()

        # Scan governance
        self._scan_governance()

        # Scan memory
        self._scan_memory()

        # Scan agents
        self._scan_agents()

        # Scan pipeline
        self._scan_pipeline()

        # Scan learning
        self._scan_learning()

        self._scanned = True
        return self.components

    # -------------------------------------------------------------------------
    # Scanning Methods
    # -------------------------------------------------------------------------

    def _scan_cognitive_brains(self):
        """Scan the cognitive brains directory."""
        cognitive_path = self.base_path / "brains" / "cognitive"
        if not cognitive_path.exists():
            return

        for brain_dir in cognitive_path.iterdir():
            if not brain_dir.is_dir() or brain_dir.name.startswith("_"):
                continue

            brain_id = brain_dir.name
            service_dir = brain_dir / "service"
            has_service = service_dir.exists()

            # Find the main brain file
            brain_file = None
            description = ""
            classes = []
            functions = []

            if has_service:
                for py_file in service_dir.glob("*_brain.py"):
                    brain_file = py_file
                    break
                if not brain_file:
                    for py_file in service_dir.glob("*.py"):
                        if py_file.name != "__init__.py":
                            brain_file = py_file
                            break
            else:
                for py_file in brain_dir.glob("*_brain.py"):
                    brain_file = py_file
                    break

            if brain_file and brain_file.exists():
                description, classes, functions = self._parse_python_file(brain_file)

            # Create component
            name = self._id_to_name(brain_id)
            component = DiscoveredComponent(
                id=brain_id,
                name=name,
                component_type=ComponentType.COGNITIVE_BRAIN,
                path=str(brain_dir.relative_to(self.base_path)),
                description=description or f"Cognitive brain: {name}",
                module_path=f"brains.cognitive.{brain_id}",
                classes=classes,
                functions=functions,
                has_service=has_service,
            )

            # Infer capabilities from name
            component.capabilities = self._infer_capabilities(brain_id, description)

            self.components[brain_id] = component

    def _scan_tools(self):
        """Scan the tools directory."""
        tools_path = self.base_path / "brains" / "tools"
        if not tools_path.exists():
            return

        for py_file in tools_path.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            tool_id = py_file.stem
            description, classes, functions = self._parse_python_file(py_file)

            # Determine tool type
            if "session" in tool_id:
                comp_type = ComponentType.TOOL
                capabilities = {"conversation", "external_ai"}
            elif "tool" in tool_id:
                comp_type = ComponentType.TOOL
                capabilities = self._infer_capabilities(tool_id, description)
            else:
                comp_type = ComponentType.HELPER
                capabilities = set()

            component = DiscoveredComponent(
                id=tool_id,
                name=self._id_to_name(tool_id),
                component_type=comp_type,
                path=str(py_file.relative_to(self.base_path)),
                description=description or f"Tool: {tool_id}",
                module_path=f"brains.tools.{tool_id}",
                classes=classes,
                functions=functions,
                capabilities=capabilities,
            )

            self.components[f"tool_{tool_id}"] = component

    def _scan_routing(self):
        """Scan the routing directory."""
        routing_path = self.base_path / "brains" / "routing"
        if not routing_path.exists():
            return

        for py_file in routing_path.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            mod_id = py_file.stem
            description, classes, functions = self._parse_python_file(py_file)

            component = DiscoveredComponent(
                id=f"routing_{mod_id}",
                name=self._id_to_name(mod_id),
                component_type=ComponentType.ROUTING_BRAIN,
                path=str(py_file.relative_to(self.base_path)),
                description=description or f"Routing: {mod_id}",
                module_path=f"brains.routing.{mod_id}",
                classes=classes,
                functions=functions,
                capabilities={"routing", "dispatch"},
            )

            self.components[f"routing_{mod_id}"] = component

    def _scan_engines(self):
        """Scan for engine modules."""
        # Action engine
        action_engine_path = self.base_path / "brains" / "cognitive" / "action_engine"
        if action_engine_path.exists():
            self._scan_engine_dir(action_engine_path, "action_engine", ComponentType.ENGINE)

        # Governance engines
        gov_path = self.base_path / "brains" / "governance"
        if gov_path.exists():
            for engine_dir in gov_path.iterdir():
                if engine_dir.is_dir() and "engine" in engine_dir.name:
                    self._scan_engine_dir(engine_dir, engine_dir.name, ComponentType.ENGINE)

    def _scan_engine_dir(self, engine_dir: Path, engine_id: str, comp_type: ComponentType):
        """Scan an engine directory."""
        service_dir = engine_dir / "service"
        if service_dir.exists():
            for py_file in service_dir.glob("*.py"):
                if py_file.name != "__init__.py":
                    description, classes, functions = self._parse_python_file(py_file)
                    break
            else:
                description, classes, functions = "", [], []
        else:
            description, classes, functions = "", [], []

        component = DiscoveredComponent(
            id=engine_id,
            name=self._id_to_name(engine_id),
            component_type=comp_type,
            path=str(engine_dir.relative_to(self.base_path)),
            description=description or f"Engine: {engine_id}",
            module_path=f"brains.{engine_dir.relative_to(self.base_path / 'brains')}".replace("/", ".").replace("\\", "."),
            classes=classes,
            functions=functions,
            capabilities={"execution", "engine"},
            has_service=service_dir.exists(),
        )

        self.components[engine_id] = component

    def _scan_governance(self):
        """Scan governance modules."""
        gov_path = self.base_path / "brains" / "governance"
        if not gov_path.exists():
            return

        for mod_dir in gov_path.iterdir():
            if not mod_dir.is_dir() or mod_dir.name.startswith("_"):
                continue
            if mod_dir.name in self.components:  # Skip already scanned engines
                continue

            mod_id = mod_dir.name
            service_dir = mod_dir / "service"
            has_service = service_dir.exists()

            description = ""
            classes = []
            functions = []

            if has_service:
                for py_file in service_dir.glob("*.py"):
                    if py_file.name != "__init__.py":
                        description, classes, functions = self._parse_python_file(py_file)
                        break

            component = DiscoveredComponent(
                id=f"gov_{mod_id}",
                name=self._id_to_name(mod_id),
                component_type=ComponentType.GOVERNANCE,
                path=str(mod_dir.relative_to(self.base_path)),
                description=description or f"Governance: {mod_id}",
                module_path=f"brains.governance.{mod_id}",
                classes=classes,
                functions=functions,
                capabilities={"governance", "policy"},
                has_service=has_service,
            )

            self.components[f"gov_{mod_id}"] = component

    def _scan_memory(self):
        """Scan memory modules."""
        memory_path = self.base_path / "brains" / "memory"
        if not memory_path.exists():
            return

        for py_file in memory_path.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            mod_id = py_file.stem
            description, classes, functions = self._parse_python_file(py_file)

            component = DiscoveredComponent(
                id=f"memory_{mod_id}",
                name=self._id_to_name(mod_id),
                component_type=ComponentType.MEMORY_MODULE,
                path=str(py_file.relative_to(self.base_path)),
                description=description or f"Memory: {mod_id}",
                module_path=f"brains.memory.{mod_id}",
                classes=classes,
                functions=functions,
                capabilities={"memory", "storage", "retrieval"},
            )

            self.components[f"memory_{mod_id}"] = component

    def _scan_agents(self):
        """Scan agent modules."""
        agent_path = self.base_path / "brains" / "agent"
        if not agent_path.exists():
            return

        for subdir in agent_path.rglob("*"):
            if subdir.is_file() and subdir.suffix == ".py" and not subdir.name.startswith("_"):
                mod_id = subdir.stem
                description, classes, functions = self._parse_python_file(subdir)

                component = DiscoveredComponent(
                    id=f"agent_{mod_id}",
                    name=self._id_to_name(mod_id),
                    component_type=ComponentType.AGENT,
                    path=str(subdir.relative_to(self.base_path)),
                    description=description or f"Agent: {mod_id}",
                    module_path=str(subdir.relative_to(self.base_path / "brains")).replace("/", ".").replace("\\", ".").replace(".py", ""),
                    classes=classes,
                    functions=functions,
                    capabilities={"agent", "autonomous"},
                )

                self.components[f"agent_{mod_id}"] = component

    def _scan_pipeline(self):
        """Scan pipeline modules."""
        pipeline_path = self.base_path / "brains" / "pipeline"
        if not pipeline_path.exists():
            return

        for py_file in pipeline_path.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            mod_id = py_file.stem
            description, classes, functions = self._parse_python_file(py_file)

            component = DiscoveredComponent(
                id=f"pipeline_{mod_id}",
                name=self._id_to_name(mod_id),
                component_type=ComponentType.PIPELINE_COMPONENT,
                path=str(py_file.relative_to(self.base_path)),
                description=description or f"Pipeline: {mod_id}",
                module_path=f"brains.pipeline.{mod_id}",
                classes=classes,
                functions=functions,
                capabilities={"pipeline", "processing"},
            )

            self.components[f"pipeline_{mod_id}"] = component

    def _scan_learning(self):
        """Scan learning modules."""
        learning_path = self.base_path / "brains" / "learning"
        if not learning_path.exists():
            return

        for py_file in learning_path.glob("*.py"):
            if py_file.name.startswith("_"):
                continue

            mod_id = py_file.stem
            description, classes, functions = self._parse_python_file(py_file)

            component = DiscoveredComponent(
                id=f"learning_{mod_id}",
                name=self._id_to_name(mod_id),
                component_type=ComponentType.LEARNING,
                path=str(py_file.relative_to(self.base_path)),
                description=description or f"Learning: {mod_id}",
                module_path=f"brains.learning.{mod_id}",
                classes=classes,
                functions=functions,
                capabilities={"learning", "adaptation"},
            )

            self.components[f"learning_{mod_id}"] = component

    # -------------------------------------------------------------------------
    # Parsing Helpers
    # -------------------------------------------------------------------------

    def _parse_python_file(self, file_path: Path) -> Tuple[str, List[str], List[str]]:
        """Parse a Python file to extract docstring, classes, and functions."""
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                source = f.read()

            tree = ast.parse(source)

            # Get module docstring
            docstring = ast.get_docstring(tree) or ""
            # Take first paragraph
            if docstring:
                docstring = docstring.split("\n\n")[0].strip()
                # Limit length
                if len(docstring) > 200:
                    docstring = docstring[:200] + "..."

            # Get class names
            classes = [node.name for node in ast.walk(tree) if isinstance(node, ast.ClassDef)]

            # Get top-level function names
            functions = [node.name for node in tree.body if isinstance(node, ast.FunctionDef)]

            return docstring, classes, functions

        except Exception:
            return "", [], []

    def _id_to_name(self, component_id: str) -> str:
        """Convert a component ID to a human-readable name."""
        # Remove common prefixes/suffixes
        name = component_id
        for suffix in ["_brain", "_tool", "_engine", "_service", "_module"]:
            name = name.replace(suffix, "")

        # Convert snake_case to Title Case
        words = name.split("_")
        return " ".join(word.capitalize() for word in words if word)

    def _infer_capabilities(self, component_id: str, description: str) -> Set[str]:
        """Infer capabilities from component ID and description."""
        capabilities = set()
        text = f"{component_id} {description}".lower()

        # Capability keywords
        keyword_map = {
            "memory": {"memory", "storage", "retrieval"},
            "learn": {"learning", "adaptation"},
            "reason": {"reasoning", "logic"},
            "plan": {"planning", "strategy"},
            "search": {"web_search", "search"},
            "browser": {"browser_control", "web"},
            "file": {"file_read", "file_write", "filesystem"},
            "shell": {"shell_execution", "system"},
            "code": {"coding", "programming"},
            "chat": {"conversation", "dialogue"},
            "gpt": {"external_ai", "chatgpt"},
            "claude": {"external_ai", "claude"},
            "grok": {"external_ai", "grok"},
            "route": {"routing", "dispatch"},
            "context": {"context", "state"},
            "attention": {"attention", "focus"},
            "affect": {"affect", "priority"},
            "safety": {"safety", "guard"},
            "research": {"research", "synthesis"},
            "personality": {"personality", "voice"},
        }

        for keyword, caps in keyword_map.items():
            if keyword in text:
                capabilities.update(caps)

        return capabilities

    # -------------------------------------------------------------------------
    # Summary Methods
    # -------------------------------------------------------------------------

    def get_system_summary(self) -> Dict[str, Any]:
        """Get a summary of the discovered system."""
        if not self._scanned:
            self.scan_all()

        # Group by type
        by_type: Dict[str, List[DiscoveredComponent]] = {}
        for comp in self.components.values():
            type_name = comp.component_type.value
            if type_name not in by_type:
                by_type[type_name] = []
            by_type[type_name].append(comp)

        return {
            "total_components": len(self.components),
            "by_type": {
                type_name: {
                    "count": len(comps),
                    "components": [c.id for c in comps],
                }
                for type_name, comps in by_type.items()
            },
        }

    def get_dynamic_self_description(self) -> str:
        """Generate a dynamic self-description based on discovered components."""
        if not self._scanned:
            self.scan_all()

        # Count by type
        cognitive = [c for c in self.components.values() if c.component_type == ComponentType.COGNITIVE_BRAIN]
        tools = [c for c in self.components.values() if c.component_type == ComponentType.TOOL]
        engines = [c for c in self.components.values() if c.component_type == ComponentType.ENGINE]
        routing = [c for c in self.components.values() if c.component_type == ComponentType.ROUTING_BRAIN]
        pipeline = [c for c in self.components.values() if c.component_type == ComponentType.PIPELINE_COMPONENT]
        memory = [c for c in self.components.values() if c.component_type == ComponentType.MEMORY_MODULE]
        governance = [c for c in self.components.values() if c.component_type == ComponentType.GOVERNANCE]
        learning = [c for c in self.components.values() if c.component_type == ComponentType.LEARNING]
        agents = [c for c in self.components.values() if c.component_type == ComponentType.AGENT]
        helpers = [c for c in self.components.values() if c.component_type == ComponentType.HELPER]

        lines = [
            f"I am Maven, a modular AI system composed of {len(cognitive)} cognitive brains,",
            f"{len(tools)} tool controllers, {len(engines)} engines, and {len(routing) + len(pipeline)} routing/pipeline modules.",
            "",
            "**Cognitive Brains:**",
        ]

        # List top cognitive brains
        for brain in sorted(cognitive, key=lambda x: x.name)[:15]:
            lines.append(f"- {brain.name}")
        if len(cognitive) > 15:
            lines.append(f"- ... and {len(cognitive) - 15} more")

        lines.append("")
        lines.append("**Action Tools:**")
        for tool in sorted(tools, key=lambda x: x.name)[:10]:
            lines.append(f"- {tool.name}")
        if len(tools) > 10:
            lines.append(f"- ... and {len(tools) - 10} more")

        if engines:
            lines.append("")
            lines.append("**Engines:**")
            for engine in engines:
                lines.append(f"- {engine.name}")

        if memory:
            lines.append("")
            lines.append("**Memory Modules:**")
            for mem in memory:
                lines.append(f"- {mem.name}")

        if governance:
            lines.append("")
            lines.append("**Governance Modules:**")
            for gov in governance:
                lines.append(f"- {gov.name}")

        lines.append("")
        lines.append("This description is generated dynamically from my internal registry.")

        return "\n".join(lines)

    def get_components_by_type(self, comp_type: ComponentType) -> List[DiscoveredComponent]:
        """Get all components of a specific type."""
        if not self._scanned:
            self.scan_all()
        return [c for c in self.components.values() if c.component_type == comp_type]

    def get_component(self, component_id: str) -> Optional[DiscoveredComponent]:
        """Get a specific component by ID."""
        if not self._scanned:
            self.scan_all()
        return self.components.get(component_id)

    def to_json(self) -> str:
        """Export the discovered components as JSON."""
        if not self._scanned:
            self.scan_all()
        return json.dumps(
            {cid: comp.to_dict() for cid, comp in self.components.items()},
            indent=2,
        )


# =============================================================================
# Singleton and Convenience Functions
# =============================================================================

_scanner_instance: Optional[SystemScanner] = None


def get_system_scanner() -> SystemScanner:
    """Get or create the singleton SystemScanner instance."""
    global _scanner_instance
    if _scanner_instance is None:
        _scanner_instance = SystemScanner()
    return _scanner_instance


def scan_system() -> Dict[str, DiscoveredComponent]:
    """Scan the system and return all discovered components."""
    return get_system_scanner().scan_all()


def get_dynamic_self_description() -> str:
    """Get a dynamic self-description based on discovered components."""
    return get_system_scanner().get_dynamic_self_description()


def get_system_summary() -> Dict[str, Any]:
    """Get a summary of the discovered system."""
    return get_system_scanner().get_system_summary()


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "ComponentType",
    "DiscoveredComponent",
    "SystemScanner",
    "get_system_scanner",
    "scan_system",
    "get_dynamic_self_description",
    "get_system_summary",
]
