# brains/utils/component_manifest.py
"""
Component Manifest - Registration of All Maven Components
=========================================================

This module registers all known Maven components into the SystemRegistry.
Import this module at startup to populate the registry with component metadata.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from brains.utils.system_registry import (
    ComponentKind,
    Visibility,
    SafetyTag,
    ComponentMetadata,
    get_system_registry,
)


def register_all_components() -> None:
    """Register all Maven components in the system registry."""
    registry = get_system_registry()

    # =========================================================================
    # BRAINS - Cognitive Modules
    # =========================================================================

    # --- Core Routing & Integration ---

    _register(registry, ComponentMetadata(
        id="integrator",
        kind=ComponentKind.BRAIN,
        name="Integrator",
        description="Central routing brain that analyzes queries and dispatches to appropriate tools and brains.",
        owner_module="brains.cognitive.integrator",
        inputs=["user_input", "context"],
        outputs=["planning", "tool_results"],
        capabilities={"routing", "intent_classification", "tool_dispatch"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Route user queries to the correct brain or tool",
            "Classify intent and determine best handler",
        ],
        dependencies=["sensorium", "memory_librarian"],
    ))

    _register(registry, ComponentMetadata(
        id="maven_responder",
        kind=ComponentKind.BRAIN,
        name="Maven Responder",
        description="Single authority for Maven's external voice. Synthesizes final answers from drafts.",
        owner_module="brains.cognitive.maven_responder",
        inputs=["answer_drafts", "tool_results", "context"],
        outputs=["maven_voice"],
        capabilities={"response_synthesis", "voice_generation"},
        visibility=Visibility.USER_FACING,
        usage_examples=[
            "Generate final user-facing responses",
            "Synthesize answers from LLM drafts",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="sensorium",
        kind=ComponentKind.BRAIN,
        name="Sensorium",
        description="Input processing brain that normalizes and preprocesses user queries.",
        owner_module="brains.cognitive.sensorium",
        inputs=["user_input"],
        outputs=["user_input"],
        capabilities={"input_processing", "normalization", "intent_detection"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Preprocess and normalize user input",
            "Detect query intent and modality",
        ],
    ))

    # --- Memory & Context ---

    _register(registry, ComponentMetadata(
        id="memory_librarian",
        kind=ComponentKind.BRAIN,
        name="Memory Librarian",
        description="Long-term memory management brain. Stores, retrieves, and organizes knowledge.",
        owner_module="brains.cognitive.memory_librarian",
        inputs=["user_input", "tool_results"],
        outputs=["context", "answer_drafts"],
        capabilities={"memory_storage", "memory_retrieval", "knowledge_organization"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Store facts and knowledge from conversations",
            "Retrieve relevant context for queries",
            "Manage domain-specific knowledge banks",
        ],
        dependencies=["domain_banks"],
    ))

    _register(registry, ComponentMetadata(
        id="context_manager",
        kind=ComponentKind.BRAIN,
        name="Context Manager",
        description="Manages conversation context and state across turns.",
        owner_module="brains.cognitive.context_management",
        inputs=["user_input", "context"],
        outputs=["context"],
        capabilities={"context_management", "state_tracking", "conversation_history"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Track conversation state across turns",
            "Manage context windows and relevance",
        ],
    ))

    # --- Learning & Reasoning ---

    _register(registry, ComponentMetadata(
        id="learning_brain",
        kind=ComponentKind.BRAIN,
        name="Learning Brain",
        description="Manages learning loops, pattern recognition, and knowledge acquisition.",
        owner_module="brains.cognitive.learning",
        inputs=["tool_results", "telemetry"],
        outputs=["planning"],
        capabilities={"learning", "pattern_recognition", "knowledge_acquisition"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Learn from successful interactions",
            "Update routing patterns based on outcomes",
        ],
        dependencies=["teacher"],
    ))

    _register(registry, ComponentMetadata(
        id="reasoning_brain",
        kind=ComponentKind.BRAIN,
        name="Reasoning Brain",
        description="Logical reasoning and inference for complex queries.",
        owner_module="brains.cognitive.reasoning",
        inputs=["user_input", "context"],
        outputs=["answer_drafts"],
        capabilities={"reasoning", "inference", "logic"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Perform logical reasoning on complex questions",
            "Chain multiple inferences together",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="planner",
        kind=ComponentKind.BRAIN,
        name="Planner",
        description="Plans multi-step tasks and coordinates complex operations.",
        owner_module="brains.cognitive.planner",
        inputs=["user_input", "context"],
        outputs=["planning"],
        capabilities={"planning", "task_decomposition", "coordination"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Break down complex tasks into steps",
            "Coordinate multi-tool operations",
        ],
    ))

    # --- Self-Knowledge & Review ---

    _register(registry, ComponentMetadata(
        id="self_model",
        kind=ComponentKind.BRAIN,
        name="Self Model",
        description="Maven's model of itself - capabilities, limitations, and architecture.",
        owner_module="brains.cognitive.self_model",
        inputs=["user_input"],
        outputs=["answer_drafts"],
        capabilities={"self_explanation", "introspection", "capability_awareness"},
        visibility=Visibility.MAY_INFLUENCE_USER,
        usage_examples=[
            "Answer questions about Maven's architecture",
            "Explain what Maven can and cannot do",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="self_review",
        kind=ComponentKind.BRAIN,
        name="Self Review",
        description="Reviews and critiques Maven's own responses before delivery.",
        owner_module="brains.cognitive.self_review",
        inputs=["answer_drafts"],
        outputs=["answer_drafts"],
        capabilities={"self_review", "quality_check", "critique"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Review generated responses for quality",
            "Catch errors before user sees them",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="self_introspection",
        kind=ComponentKind.BRAIN,
        name="Self Introspection",
        description="Answers questions about Maven's architecture using the SystemRegistry.",
        owner_module="brains.cognitive.self_introspection",
        inputs=["user_input"],
        outputs=["answer_drafts"],
        capabilities={"self_explanation", "introspection", "architecture_query"},
        visibility=Visibility.MAY_INFLUENCE_USER,
        usage_examples=[
            "What are your brains?",
            "What tools do you have?",
            "How do you work?",
            "Tell me about yourself",
        ],
        dependencies=["system_registry"],
    ))

    # --- Research & Analysis ---

    _register(registry, ComponentMetadata(
        id="research_manager",
        kind=ComponentKind.BRAIN,
        name="Research Manager",
        description="Coordinates research tasks and synthesizes findings from multiple sources.",
        owner_module="brains.cognitive.research_manager",
        inputs=["user_input", "tool_results"],
        outputs=["answer_drafts"],
        capabilities={"research", "synthesis", "fact_checking"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB},
        visibility=Visibility.MAY_INFLUENCE_USER,
        usage_examples=[
            "Research topics using multiple sources",
            "Synthesize information from web searches",
        ],
        dependencies=["web_search"],
    ))

    _register(registry, ComponentMetadata(
        id="coder",
        kind=ComponentKind.BRAIN,
        name="Coder",
        description="Code generation, review, and programming assistance.",
        owner_module="brains.cognitive.coder",
        inputs=["user_input", "context"],
        outputs=["answer_drafts"],
        capabilities={"coding", "code_review", "programming"},
        safety_tags={SafetyTag.CAN_TOUCH_FILESYSTEM},
        visibility=Visibility.MAY_INFLUENCE_USER,
        usage_examples=[
            "Write code based on requirements",
            "Review and improve existing code",
        ],
    ))

    # =========================================================================
    # TEACHERS - Learning/Supervision Modules
    # =========================================================================

    _register(registry, ComponentMetadata(
        id="teacher",
        kind=ComponentKind.TEACHER,
        name="Teacher",
        description="LLM-based advisor that generates drafts and suggestions. NOT for final answers.",
        owner_module="brains.cognitive.teacher",
        inputs=["user_input", "context"],
        outputs=["answer_drafts"],
        capabilities={"draft_generation", "suggestion", "advisory"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Generate draft responses for Maven to rephrase",
            "Provide advisory notes on complex topics",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="self_critique",
        kind=ComponentKind.TEACHER,
        name="Self Critique",
        description="Evaluates and scores response quality for learning.",
        owner_module="brains.cognitive.self_dmn",
        inputs=["answer_drafts", "tool_results"],
        outputs=["telemetry"],
        capabilities={"quality_scoring", "feedback", "supervision"},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Score response quality for learning",
            "Provide feedback on routing decisions",
        ],
    ))

    # =========================================================================
    # TOOLS - External Capabilities
    # =========================================================================

    # --- Browser / External AI ---

    _register(registry, ComponentMetadata(
        id="chatgpt_session",
        kind=ComponentKind.TOOL,
        name="ChatGPT Session",
        description="Browser-based tool for conversing with ChatGPT.",
        owner_module="brains.tools.chatgpt_conversation_session",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"chatgpt_conversation", "external_ai", "browser_control"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB, SafetyTag.CAN_TALK_TO_EXTERNAL_AI},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "talk to chatgpt about <topic>",
            "have a conversation with chatgpt",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="claude_session",
        kind=ComponentKind.TOOL,
        name="Claude Session",
        description="Browser-based tool for conversing with Claude.",
        owner_module="brains.tools.claude_conversation_session",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"claude_conversation", "external_ai", "browser_control"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB, SafetyTag.CAN_TALK_TO_EXTERNAL_AI},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "talk to claude about <topic>",
            "have a conversation with claude",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="grok_session",
        kind=ComponentKind.TOOL,
        name="Grok Session",
        description="Browser-based tool for conversing with Grok via X.",
        owner_module="brains.tools.grok_conversation_session",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"grok_conversation", "external_ai", "browser_control"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB, SafetyTag.CAN_TALK_TO_EXTERNAL_AI},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "talk to grok about <topic>",
            "ask grok about business",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="browser_tool",
        kind=ComponentKind.TOOL,
        name="Browser Tool",
        description="General browser automation for web navigation and interaction.",
        owner_module="optional.browser_tools.browser_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"browser_control", "web_navigation", "web_scraping"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "Open a webpage",
            "Navigate to URL",
            "Extract content from web page",
        ],
    ))

    # --- Web & Search ---

    _register(registry, ComponentMetadata(
        id="web_search",
        kind=ComponentKind.TOOL,
        name="Web Search",
        description="Searches the web for information.",
        owner_module="brains.agent.tools.web_search_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"web_search", "information_retrieval"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "search for <topic>",
            "find information about <subject>",
        ],
    ))

    # --- System & Files ---

    _register(registry, ComponentMetadata(
        id="shell_tool",
        kind=ComponentKind.TOOL,
        name="Shell Tool",
        description="Executes shell commands on the local system.",
        owner_module="brains.agent.tools.shell_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"shell_execution", "system_control"},
        safety_tags={SafetyTag.CAN_CONTROL_PC, SafetyTag.CAN_TOUCH_FILESYSTEM},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "run command <cmd>",
            "execute shell command",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="fs_tool",
        kind=ComponentKind.TOOL,
        name="Filesystem Tool",
        description="File system operations - read, write, list directories.",
        owner_module="brains.agent.tools.fs_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"file_read", "file_write", "directory_listing"},
        safety_tags={SafetyTag.CAN_TOUCH_FILESYSTEM},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "read file <path>",
            "list directory <path>",
            "write to file <path>",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="pc_control",
        kind=ComponentKind.TOOL,
        name="PC Control",
        description="Controls PC - keyboard, mouse, window management.",
        owner_module="optional.browser_tools.pc_control_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"pc_control", "keyboard", "mouse", "window_management"},
        safety_tags={SafetyTag.CAN_CONTROL_PC, SafetyTag.REQUIRES_USER_CONFIRMATION},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "click on <element>",
            "type <text>",
            "press <key>",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="human_tool",
        kind=ComponentKind.TOOL,
        name="Human Tool",
        description="Interface for human-in-the-loop interactions.",
        owner_module="optional.browser_tools.human_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"human_interaction", "confirmation"},
        safety_tags={SafetyTag.REQUIRES_USER_CONFIRMATION},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "ask human for confirmation",
            "request human input",
        ],
    ))

    # --- Social ---

    _register(registry, ComponentMetadata(
        id="x_tool",
        kind=ComponentKind.TOOL,
        name="X (Twitter) Tool",
        description="Interacts with X/Twitter - posting, reading, searching.",
        owner_module="optional.browser_tools.x_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"social_media", "x_interaction", "posting"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB, SafetyTag.CAN_POST_TO_SOCIAL},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "post to X",
            "search X for <topic>",
        ],
    ))

    # --- Utilities ---

    _register(registry, ComponentMetadata(
        id="math_tool",
        kind=ComponentKind.TOOL,
        name="Math Tool",
        description="Mathematical calculations and symbolic computation.",
        owner_module="brains.agent.tools.math_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"math", "calculation"},
        safety_tags={SafetyTag.NO_EXTERNAL_SIDE_EFFECTS},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "calculate <expression>",
            "solve <equation>",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="logic_tool",
        kind=ComponentKind.TOOL,
        name="Logic Tool",
        description="Logical operations and symbolic reasoning.",
        owner_module="brains.agent.tools.logic_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"logic", "symbolic_reasoning"},
        safety_tags={SafetyTag.NO_EXTERNAL_SIDE_EFFECTS},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "evaluate logical expression",
            "check validity of argument",
        ],
    ))

    _register(registry, ComponentMetadata(
        id="git_tool",
        kind=ComponentKind.TOOL,
        name="Git Tool",
        description="Git version control operations.",
        owner_module="brains.tools.git_tool",
        inputs=["user_input"],
        outputs=["tool_results"],
        capabilities={"git", "version_control"},
        safety_tags={SafetyTag.CAN_TOUCH_FILESYSTEM},
        visibility=Visibility.INTERNAL_ONLY,
        usage_examples=[
            "git status",
            "git commit",
            "git push",
        ],
    ))

    # =========================================================================
    # HELPERS - Support Libraries
    # =========================================================================

    _register(registry, ComponentMetadata(
        id="teacher_helper",
        kind=ComponentKind.HELPER,
        name="Teacher Helper",
        description="Helper for calling Teacher LLM with proper prompting.",
        owner_module="brains.cognitive.teacher.service.teacher_helper",
        inputs=[],
        outputs=[],
        capabilities={"llm_calling"},
        safety_tags={SafetyTag.NO_EXTERNAL_SIDE_EFFECTS},
        visibility=Visibility.INTERNAL_ONLY,
    ))

    _register(registry, ComponentMetadata(
        id="blackboard",
        kind=ComponentKind.HELPER,
        name="Blackboard",
        description="Lane-based shared state for the cognition pipeline.",
        owner_module="brains.pipeline.blackboard",
        inputs=[],
        outputs=[],
        capabilities={"state_management"},
        safety_tags={SafetyTag.NO_EXTERNAL_SIDE_EFFECTS},
        visibility=Visibility.INTERNAL_ONLY,
    ))

    _register(registry, ComponentMetadata(
        id="compositor",
        kind=ComponentKind.HELPER,
        name="Final Answer Compositor",
        description="Extracts and validates final answers from blackboard.",
        owner_module="brains.pipeline.final_answer_compositor",
        inputs=["answer_candidates", "maven_voice"],
        outputs=[],
        capabilities={"answer_extraction", "sanity_checking"},
        safety_tags={SafetyTag.NO_EXTERNAL_SIDE_EFFECTS},
        visibility=Visibility.INTERNAL_ONLY,
    ))

    _register(registry, ComponentMetadata(
        id="llm_service",
        kind=ComponentKind.HELPER,
        name="LLM Service",
        description="Interface for calling external LLM APIs.",
        owner_module="brains.tools.llm_service",
        inputs=[],
        outputs=[],
        capabilities={"llm_calling"},
        safety_tags={SafetyTag.CAN_TOUCH_WEB},
        visibility=Visibility.INTERNAL_ONLY,
    ))

    _register(registry, ComponentMetadata(
        id="tool_output_formatter",
        kind=ComponentKind.HELPER,
        name="Tool Output Formatter",
        description="Formats raw tool outputs into user-readable text.",
        owner_module="brains.pipeline.tool_output_formatter",
        inputs=["tool_results"],
        outputs=["answer_candidates"],
        capabilities={"formatting"},
        safety_tags={SafetyTag.NO_EXTERNAL_SIDE_EFFECTS},
        visibility=Visibility.INTERNAL_ONLY,
    ))

    # =========================================================================
    # DOMAIN BANKS - Knowledge Storage
    # =========================================================================

    domain_banks = [
        ("technology_bank", "Technology Bank", "Technology and computing knowledge"),
        ("science_bank", "Science Bank", "Scientific knowledge and concepts"),
        ("personal_bank", "Personal Bank", "Personal information and preferences"),
        ("history_bank", "History Bank", "Historical knowledge"),
        ("geography_bank", "Geography Bank", "Geographic information"),
        ("arts_bank", "Arts Bank", "Art and culture knowledge"),
        ("economics_bank", "Economics Bank", "Economic and financial knowledge"),
        ("math_bank", "Math Bank", "Mathematical knowledge"),
        ("philosophy_bank", "Philosophy Bank", "Philosophical concepts"),
        ("law_bank", "Law Bank", "Legal knowledge"),
        ("creative_bank", "Creative Bank", "Creative writing and ideas"),
        ("factual_bank", "Factual Bank", "General factual knowledge"),
        ("procedural_bank", "Procedural Bank", "How-to and process knowledge"),
        ("research_reports_bank", "Research Reports Bank", "Stored research findings"),
    ]

    for bank_id, name, desc in domain_banks:
        _register(registry, ComponentMetadata(
            id=bank_id,
            kind=ComponentKind.HELPER,
            name=name,
            description=f"Domain knowledge bank: {desc}",
            owner_module=f"brains.domain_banks.{bank_id.replace('_bank', '')}",
            inputs=["tool_results"],
            outputs=["context"],
            capabilities={"knowledge_storage", "domain_knowledge"},
            safety_tags={SafetyTag.NO_EXTERNAL_SIDE_EFFECTS},
            visibility=Visibility.INTERNAL_ONLY,
        ))


def _register(registry, component: ComponentMetadata) -> None:
    """Register a component, ignoring duplicates."""
    try:
        registry.register(component)
    except ValueError:
        pass  # Already registered


def initialize_registry() -> None:
    """Initialize the system registry with all components."""
    register_all_components()


# Auto-initialize when imported
initialize_registry()


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "register_all_components",
    "initialize_registry",
]
