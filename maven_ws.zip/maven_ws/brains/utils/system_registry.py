# brains/core/system_registry.py
"""
System Registry - Single Source of Truth for Maven's Components
===============================================================

This module provides a structured registry of all Maven components with:
- Clear taxonomy: Brain, Tool, Helper, Teacher
- Metadata about capabilities, inputs, outputs, safety
- Runtime registration and validation
- Query interface for routing and introspection

DESIGN: Maven's self-knowledge comes from this registry, NOT from file scanning.

STDLIB ONLY, OFFLINE, WINDOWS 10 COMPATIBLE
"""

from __future__ import annotations
from typing import Dict, Any, List, Optional, Set, Literal, Callable
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime
import json


# =============================================================================
# Component Taxonomy
# =============================================================================

class ComponentKind(str, Enum):
    """
    The four types of components in Maven's architecture.

    This is a HARD taxonomy - every component must be exactly one of these.
    """
    BRAIN = "brain"
    """
    Long-running cognitive module that operates on blackboard state.
    Responsibilities: Reasoning, planning, routing, synthesis.
    Never directly calls external services (except specialized ones).
    Examples: router, learning, memory_librarian, maven_responder.
    """

    TOOL = "tool"
    """
    Concrete capability that talks to the outside world or runs heavy ops.
    Responsibilities: "Do stuff", fetch data, interact with OS/web/other AIs.
    Never decides on its own when to run; always called by a brain.
    Examples: web_search, grok_session, chatgpt_session, browser_open, pc.
    """

    HELPER = "helper"
    """
    Small library/adapter that supports brains or tools.
    No agency; no routing; no direct user-facing behavior.
    Examples: log formatter, similarity matcher, prompt templater.
    """

    TEACHER = "teacher"
    """
    Special brain subclass for supervision and learning.
    Used for: length planning, self-review, pattern learning.
    Produces supervision signals and patterns, NOT final user answers.
    """


class Visibility(str, Enum):
    """How a component's outputs can be used."""
    INTERNAL_ONLY = "internal_only"
    """Output stays on blackboard, never shown to users."""

    MAY_INFLUENCE_USER = "may_influence_user"
    """Output may be used as input to user-facing responses."""

    USER_FACING = "user_facing"
    """Output can be shown to users (only via Maven's voice)."""


class SafetyTag(str, Enum):
    """Safety properties of components."""
    CAN_TOUCH_WEB = "can_touch_web"
    CAN_TOUCH_FILESYSTEM = "can_touch_filesystem"
    CAN_CONTROL_PC = "can_control_pc"
    CAN_TALK_TO_EXTERNAL_AI = "can_talk_to_external_ai"
    CAN_POST_TO_SOCIAL = "can_post_to_social"
    NO_EXTERNAL_SIDE_EFFECTS = "no_external_side_effects"
    REQUIRES_USER_CONFIRMATION = "requires_user_confirmation"


# =============================================================================
# Component Metadata
# =============================================================================

@dataclass
class ComponentMetadata:
    """
    Complete metadata for a Maven component.

    This is the structured knowledge Maven has about each of its parts.
    """
    # Identity
    id: str
    """Unique identifier (e.g., 'maven_responder', 'grok_session')."""

    kind: ComponentKind
    """What type of component this is."""

    name: str
    """Human-readable name."""

    description: str
    """What this component does (1-2 sentences)."""

    # Code location
    owner_module: str
    """Python module path (e.g., 'brains.cognitive.maven_responder')."""

    # I/O
    inputs: List[str] = field(default_factory=list)
    """What it reads: blackboard lanes, user text, tool outputs, etc."""

    outputs: List[str] = field(default_factory=list)
    """What it writes: blackboard lanes, logs, etc."""

    # Capabilities
    capabilities: Set[str] = field(default_factory=set)
    """
    Capability tags describing what this component can do.
    Examples: 'routing', 'summarization', 'web_research', 'grok_conversation',
              'chatgpt_conversation', 'context_management', 'learning',
              'memory_storage', 'self_explanation', 'browser_control'.
    """

    # Safety
    safety_tags: Set[SafetyTag] = field(default_factory=set)
    """Safety properties (what external systems it can touch)."""

    visibility: Visibility = Visibility.INTERNAL_ONLY
    """How outputs can be used."""

    # Usage
    usage_examples: List[str] = field(default_factory=list)
    """Example queries/contexts where this component should be used."""

    # Dependencies
    dependencies: List[str] = field(default_factory=list)
    """Other component IDs this normally calls."""

    # Runtime stats (updated by learning)
    usage_count: int = 0
    """How many times this component has been invoked."""

    success_rate: float = 1.0
    """Estimated success rate (0.0 to 1.0)."""

    last_used: Optional[datetime] = None
    """When this component was last used."""

    # Status
    is_enabled: bool = True
    """Whether this component is currently available."""

    is_deprecated: bool = False
    """Whether this component is being phased out."""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "id": self.id,
            "kind": self.kind.value,
            "name": self.name,
            "description": self.description,
            "owner_module": self.owner_module,
            "inputs": self.inputs,
            "outputs": self.outputs,
            "capabilities": list(self.capabilities),
            "safety_tags": [t.value for t in self.safety_tags],
            "visibility": self.visibility.value,
            "usage_examples": self.usage_examples,
            "dependencies": self.dependencies,
            "usage_count": self.usage_count,
            "success_rate": self.success_rate,
            "last_used": self.last_used.isoformat() if self.last_used else None,
            "is_enabled": self.is_enabled,
            "is_deprecated": self.is_deprecated,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ComponentMetadata":
        """Create from dictionary."""
        return cls(
            id=data["id"],
            kind=ComponentKind(data["kind"]),
            name=data["name"],
            description=data["description"],
            owner_module=data["owner_module"],
            inputs=data.get("inputs", []),
            outputs=data.get("outputs", []),
            capabilities=set(data.get("capabilities", [])),
            safety_tags={SafetyTag(t) for t in data.get("safety_tags", [])},
            visibility=Visibility(data.get("visibility", "internal_only")),
            usage_examples=data.get("usage_examples", []),
            dependencies=data.get("dependencies", []),
            usage_count=data.get("usage_count", 0),
            success_rate=data.get("success_rate", 1.0),
            last_used=datetime.fromisoformat(data["last_used"]) if data.get("last_used") else None,
            is_enabled=data.get("is_enabled", True),
            is_deprecated=data.get("is_deprecated", False),
        )

    def matches_capabilities(self, required: Set[str]) -> bool:
        """Check if this component has all required capabilities."""
        return required.issubset(self.capabilities)

    def has_safety_tag(self, tag: SafetyTag) -> bool:
        """Check if component has a specific safety tag."""
        return tag in self.safety_tags

    def get_summary(self) -> str:
        """Get a brief summary suitable for self-explanation."""
        return f"{self.name} ({self.kind.value}): {self.description}"


# =============================================================================
# System Registry
# =============================================================================

class SystemRegistry:
    """
    Central registry of all Maven components.

    This is the SINGLE SOURCE OF TRUTH for Maven's self-knowledge.
    All self-introspection and routing should query this registry.

    Usage:
        registry = get_system_registry()

        # Query by kind
        brains = registry.get_by_kind(ComponentKind.BRAIN)

        # Query by capability
        web_tools = registry.get_by_capability("web_research")

        # Get specific component
        grok = registry.get("grok_session")

        # Self-explanation
        summary = registry.get_architecture_summary()
    """

    def __init__(self):
        self._components: Dict[str, ComponentMetadata] = {}
        self._by_kind: Dict[ComponentKind, List[str]] = {k: [] for k in ComponentKind}
        self._by_capability: Dict[str, List[str]] = {}
        self._initialized = False

    # -------------------------------------------------------------------------
    # Registration
    # -------------------------------------------------------------------------

    def register(self, component: ComponentMetadata) -> None:
        """
        Register a component in the registry.

        Args:
            component: The component metadata to register

        Raises:
            ValueError: If component ID is already registered
        """
        if component.id in self._components:
            raise ValueError(f"Component '{component.id}' is already registered")

        self._components[component.id] = component
        self._by_kind[component.kind].append(component.id)

        for cap in component.capabilities:
            if cap not in self._by_capability:
                self._by_capability[cap] = []
            self._by_capability[cap].append(component.id)

    def unregister(self, component_id: str) -> bool:
        """Remove a component from the registry."""
        if component_id not in self._components:
            return False

        component = self._components[component_id]

        # Remove from kind index
        if component_id in self._by_kind[component.kind]:
            self._by_kind[component.kind].remove(component_id)

        # Remove from capability index
        for cap in component.capabilities:
            if cap in self._by_capability and component_id in self._by_capability[cap]:
                self._by_capability[cap].remove(component_id)

        del self._components[component_id]
        return True

    # -------------------------------------------------------------------------
    # Query Methods
    # -------------------------------------------------------------------------

    def get(self, component_id: str) -> Optional[ComponentMetadata]:
        """Get a specific component by ID."""
        return self._components.get(component_id)

    def get_all(self) -> List[ComponentMetadata]:
        """Get all registered components."""
        return list(self._components.values())

    def get_by_kind(self, kind: ComponentKind) -> List[ComponentMetadata]:
        """Get all components of a specific kind."""
        return [self._components[cid] for cid in self._by_kind[kind]]

    def get_by_capability(self, capability: str) -> List[ComponentMetadata]:
        """Get all components with a specific capability."""
        if capability not in self._by_capability:
            return []
        return [self._components[cid] for cid in self._by_capability[capability]]

    def get_by_capabilities(
        self,
        required: Set[str],
        kind: Optional[ComponentKind] = None,
    ) -> List[ComponentMetadata]:
        """
        Get components that have ALL required capabilities.

        Args:
            required: Set of capability tags that must all be present
            kind: Optionally filter by component kind
        """
        result = []
        for component in self._components.values():
            if kind and component.kind != kind:
                continue
            if component.matches_capabilities(required):
                result.append(component)
        return result

    def get_safe_for(
        self,
        allowed_tags: Set[SafetyTag],
        kind: Optional[ComponentKind] = None,
    ) -> List[ComponentMetadata]:
        """
        Get components whose safety tags are within the allowed set.

        Used for filtering dangerous operations when not appropriate.
        """
        result = []
        for component in self._components.values():
            if kind and component.kind != kind:
                continue
            # Component is safe if all its safety tags are in allowed set
            if component.safety_tags.issubset(allowed_tags):
                result.append(component)
        return result

    def get_brains(self) -> List[ComponentMetadata]:
        """Get all brains."""
        return self.get_by_kind(ComponentKind.BRAIN)

    def get_tools(self) -> List[ComponentMetadata]:
        """Get all tools."""
        return self.get_by_kind(ComponentKind.TOOL)

    def get_helpers(self) -> List[ComponentMetadata]:
        """Get all helpers."""
        return self.get_by_kind(ComponentKind.HELPER)

    def get_teachers(self) -> List[ComponentMetadata]:
        """Get all teachers."""
        return self.get_by_kind(ComponentKind.TEACHER)

    def get_enabled(self, kind: Optional[ComponentKind] = None) -> List[ComponentMetadata]:
        """Get all enabled (non-deprecated) components."""
        result = []
        for component in self._components.values():
            if kind and component.kind != kind:
                continue
            if component.is_enabled and not component.is_deprecated:
                result.append(component)
        return result

    # -------------------------------------------------------------------------
    # Self-Explanation Methods
    # -------------------------------------------------------------------------

    def get_architecture_summary(self) -> str:
        """
        Get a human-readable summary of Maven's architecture.

        Used for self-introduction to users and other AIs.
        """
        brains = self.get_brains()
        tools = self.get_tools()
        helpers = self.get_helpers()
        teachers = self.get_teachers()

        lines = [
            "Maven Architecture Summary",
            "=" * 30,
            "",
            f"**Brains** ({len(brains)} cognitive modules):",
        ]

        for b in brains:
            if b.is_enabled and not b.is_deprecated:
                lines.append(f"  - {b.name}: {b.description}")

        lines.extend([
            "",
            f"**Tools** ({len(tools)} capabilities):",
        ])

        for t in tools:
            if t.is_enabled and not t.is_deprecated:
                lines.append(f"  - {t.name}: {t.description}")

        lines.extend([
            "",
            f"**Teachers** ({len(teachers)} learning/supervision modules):",
        ])

        for t in teachers:
            if t.is_enabled and not t.is_deprecated:
                lines.append(f"  - {t.name}: {t.description}")

        lines.extend([
            "",
            f"**Helpers** ({len(helpers)} support libraries):",
        ])

        for h in helpers:
            if h.is_enabled and not h.is_deprecated:
                lines.append(f"  - {h.name}: {h.description}")

        return "\n".join(lines)

    def get_capabilities_summary(self) -> Dict[str, List[str]]:
        """
        Get a summary of all capabilities and which components provide them.
        """
        result = {}
        for cap, component_ids in self._by_capability.items():
            result[cap] = [
                self._components[cid].name
                for cid in component_ids
                if self._components[cid].is_enabled
            ]
        return result

    def explain_component(self, component_id: str) -> Optional[str]:
        """Get detailed explanation of a specific component."""
        component = self.get(component_id)
        if not component:
            return None

        lines = [
            f"**{component.name}** ({component.kind.value})",
            "",
            component.description,
            "",
            f"Module: {component.owner_module}",
            f"Status: {'Enabled' if component.is_enabled else 'Disabled'}"
                    f"{' (deprecated)' if component.is_deprecated else ''}",
            "",
        ]

        if component.capabilities:
            lines.append("Capabilities:")
            for cap in sorted(component.capabilities):
                lines.append(f"  - {cap}")
            lines.append("")

        if component.safety_tags:
            lines.append("Safety properties:")
            for tag in component.safety_tags:
                lines.append(f"  - {tag.value}")
            lines.append("")

        if component.usage_examples:
            lines.append("Example uses:")
            for ex in component.usage_examples[:3]:
                lines.append(f"  - {ex}")
            lines.append("")

        if component.dependencies:
            lines.append("Dependencies:")
            for dep in component.dependencies:
                dep_comp = self.get(dep)
                if dep_comp:
                    lines.append(f"  - {dep_comp.name}")
                else:
                    lines.append(f"  - {dep}")

        return "\n".join(lines)

    def answer_self_question(self, question: str) -> str:
        """
        Answer a question about Maven's architecture using the registry.

        This is the proper way for Maven to answer "what can you do?" etc.
        """
        q_lower = question.lower()

        # What are your brains?
        if any(kw in q_lower for kw in ["brain", "cognitive", "module"]):
            brains = self.get_enabled(ComponentKind.BRAIN)
            if "list" in q_lower or "what" in q_lower or "how many" in q_lower:
                return self._format_component_list(brains, "brains")

        # What tools do you have?
        if any(kw in q_lower for kw in ["tool", "capability", "can you"]):
            tools = self.get_enabled(ComponentKind.TOOL)
            if "list" in q_lower or "what" in q_lower:
                return self._format_component_list(tools, "tools")

        # Grok/ChatGPT specific
        if "grok" in q_lower:
            grok_components = [c for c in self.get_all() if "grok" in c.id.lower()]
            if grok_components:
                return self._format_component_list(grok_components, "Grok-related components")

        if "chatgpt" in q_lower:
            chatgpt_components = [c for c in self.get_all() if "chatgpt" in c.id.lower()]
            if chatgpt_components:
                return self._format_component_list(chatgpt_components, "ChatGPT-related components")

        # Architecture overview
        if any(kw in q_lower for kw in ["architecture", "how do you work", "structure"]):
            return self.get_architecture_summary()

        # Specific capability
        for cap in self._by_capability:
            if cap.replace("_", " ") in q_lower or cap in q_lower:
                components = self.get_by_capability(cap)
                return self._format_component_list(
                    [c for c in components if c.is_enabled],
                    f"components with '{cap}' capability"
                )

        # Default: brief overview
        return self._get_brief_overview()

    def _format_component_list(
        self,
        components: List[ComponentMetadata],
        label: str,
    ) -> str:
        """Format a list of components for display."""
        if not components:
            return f"I don't have any {label} registered."

        lines = [f"I have {len(components)} {label}:"]
        for c in components:
            lines.append(f"  - {c.name}: {c.description}")
        return "\n".join(lines)

    def _get_brief_overview(self) -> str:
        """Get a brief overview of Maven's capabilities."""
        brains = len(self.get_enabled(ComponentKind.BRAIN))
        tools = len(self.get_enabled(ComponentKind.TOOL))

        return (
            f"I'm Maven, a modular AI assistant. I have {brains} cognitive brains "
            f"for reasoning and {tools} tools for interacting with the world. "
            f"My brains include routing, memory, learning, and response synthesis. "
            f"My tools include browser control (for ChatGPT, Claude, Grok), "
            f"web search, file operations, and system control."
        )

    # -------------------------------------------------------------------------
    # Runtime Updates
    # -------------------------------------------------------------------------

    def record_usage(
        self,
        component_id: str,
        success: bool = True,
    ) -> None:
        """Record that a component was used."""
        component = self.get(component_id)
        if not component:
            return

        component.usage_count += 1
        component.last_used = datetime.now()

        # Update success rate with exponential moving average
        alpha = 0.1  # Learning rate
        component.success_rate = (
            alpha * (1.0 if success else 0.0) +
            (1 - alpha) * component.success_rate
        )

    def enable(self, component_id: str) -> bool:
        """Enable a component."""
        component = self.get(component_id)
        if component:
            component.is_enabled = True
            return True
        return False

    def disable(self, component_id: str) -> bool:
        """Disable a component."""
        component = self.get(component_id)
        if component:
            component.is_enabled = False
            return True
        return False

    # -------------------------------------------------------------------------
    # Serialization
    # -------------------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialize the entire registry."""
        return {
            "components": {
                cid: c.to_dict() for cid, c in self._components.items()
            },
            "version": "1.0",
        }

    def save_to_file(self, path: str) -> None:
        """Save registry to a JSON file."""
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load_from_file(cls, path: str) -> "SystemRegistry":
        """Load registry from a JSON file."""
        registry = cls()
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        for component_data in data.get("components", {}).values():
            component = ComponentMetadata.from_dict(component_data)
            registry.register(component)

        return registry

    # -------------------------------------------------------------------------
    # Validation
    # -------------------------------------------------------------------------

    def validate(self) -> List[str]:
        """
        Validate the registry for consistency.

        Returns list of warning messages.
        """
        warnings = []

        for cid, component in self._components.items():
            # Check dependencies exist
            for dep in component.dependencies:
                if dep not in self._components:
                    warnings.append(
                        f"Component '{cid}' depends on '{dep}' which is not registered"
                    )

            # Check brains don't have dangerous safety tags without good reason
            if component.kind == ComponentKind.BRAIN:
                dangerous = {SafetyTag.CAN_TOUCH_WEB, SafetyTag.CAN_CONTROL_PC}
                if component.safety_tags & dangerous:
                    warnings.append(
                        f"Brain '{cid}' has dangerous safety tags: {component.safety_tags & dangerous}"
                    )

        return warnings

    def __len__(self) -> int:
        return len(self._components)

    def __contains__(self, component_id: str) -> bool:
        return component_id in self._components

    def __repr__(self) -> str:
        return (
            f"SystemRegistry("
            f"brains={len(self.get_brains())}, "
            f"tools={len(self.get_tools())}, "
            f"helpers={len(self.get_helpers())}, "
            f"teachers={len(self.get_teachers())})"
        )


# =============================================================================
# Singleton Instance
# =============================================================================

_registry_instance: Optional[SystemRegistry] = None


def get_system_registry() -> SystemRegistry:
    """Get or create the singleton SystemRegistry instance."""
    global _registry_instance
    if _registry_instance is None:
        _registry_instance = SystemRegistry()
    return _registry_instance


def reset_registry() -> None:
    """Reset the singleton registry (for testing)."""
    global _registry_instance
    _registry_instance = None


# =============================================================================
# Registration Decorator
# =============================================================================

def register_component(
    id: str,
    kind: ComponentKind,
    name: str,
    description: str,
    owner_module: str,
    inputs: Optional[List[str]] = None,
    outputs: Optional[List[str]] = None,
    capabilities: Optional[Set[str]] = None,
    safety_tags: Optional[Set[SafetyTag]] = None,
    visibility: Visibility = Visibility.INTERNAL_ONLY,
    usage_examples: Optional[List[str]] = None,
    dependencies: Optional[List[str]] = None,
) -> Callable:
    """
    Decorator to register a component at import time.

    Usage:
        @register_component(
            id="my_brain",
            kind=ComponentKind.BRAIN,
            name="My Brain",
            description="Does smart things",
            owner_module="brains.cognitive.my_brain",
            capabilities={"reasoning", "planning"},
        )
        class MyBrain:
            ...
    """
    def decorator(cls):
        registry = get_system_registry()

        component = ComponentMetadata(
            id=id,
            kind=kind,
            name=name,
            description=description,
            owner_module=owner_module,
            inputs=inputs or [],
            outputs=outputs or [],
            capabilities=capabilities or set(),
            safety_tags=safety_tags or set(),
            visibility=visibility,
            usage_examples=usage_examples or [],
            dependencies=dependencies or [],
        )

        try:
            registry.register(component)
        except ValueError:
            # Already registered (e.g., module imported twice)
            pass

        return cls

    return decorator


# =============================================================================
# Exports
# =============================================================================

__all__ = [
    "ComponentKind",
    "Visibility",
    "SafetyTag",
    "ComponentMetadata",
    "SystemRegistry",
    "get_system_registry",
    "reset_registry",
    "register_component",
]
