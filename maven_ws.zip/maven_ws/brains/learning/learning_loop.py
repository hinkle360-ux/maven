"""
Learning Loop Orchestrator
===========================

Central coordinator for Maven's learning loop architecture.
Every user message flows through this loop, even when Teacher fast-path is used.

The Learning Loop:
1. Route + Teacher Answer (fast path)
2. Quality Check (gate for user)
3. Shadow Maven Answer (learning-only, background)
4. Store ConversationTurn (anchor record)
5. Fact Extraction
6. Style Pattern Learning
7. Teacher vs Maven Comparison (shadow evaluation)

This module provides:
- Domain classification for queries
- Shadow answer generation coordination
- Answer comparison (Teacher vs Maven)
- Learning signal generation
- Takeover decision integration

STDLIB ONLY, OFFLINE-CAPABLE
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Any, Optional, List, Callable
import time
import re

# Import learning loop data models
from brains.cognitive.learning_contract.episode_storage import (
    ConversationTurn,
    StylePattern,
    MetaSignal,
    QualityCheck,
    RouteUsed,
    DomainGuess,
    SignalType,
    store_conversation_turn,
    learn_style_from_answer,
    record_meta_signal,
    get_turn_store,
    get_style_store,
    get_signal_store,
)

# Import domain tracking
from brains.cognitive.learning_contract.skill_tracker import (
    get_domain_tracker,
    record_domain_outcome,
    can_maven_answer_for_domain,
)

# Import task types for classification
from brains.cognitive.learning_contract.task_types import (
    TaskType,
    classify_task_type,
)


# =============================================================================
# DOMAIN CLASSIFICATION
# =============================================================================

# Domain detection patterns
DOMAIN_PATTERNS: Dict[DomainGuess, List[str]] = {
    DomainGuess.MAVEN_SELF: [
        r"\bwho\s+are\s+you\b",
        r"\bwhat\s+are\s+you\b",
        r"\byour\s+name\b",
        r"\babout\s+yourself\b",
        r"\bmaven\b",
        r"\byour\s+capabilities\b",
        r"\bwhat\s+can\s+you\s+do\b",
        r"\bcan\s+you\s+.*\?",
        r"\bare\s+you\s+.*\?",
    ],
    DomainGuess.PROJECT_MAVEN: [
        r"\bmaven\s+(code|codebase|project|repo)\b",
        r"\b(brain|cognitive|memory)\s+system\b",
        r"\bteacher\s+(helper|brain)\b",
        r"\blearning\s+(loop|contract)\b",
        r"\bthis\s+project\b",
        r"\byour\s+(code|implementation)\b",
    ],
    DomainGuess.PYTHON_HELP: [
        r"\bpython\b",
        r"\bdef\s+\w+",
        r"\bclass\s+\w+",
        r"\bimport\s+\w+",
        r"\b(list|dict|tuple|set)\b",
        r"\bpip\s+install\b",
        r"\b__\w+__\b",
    ],
    DomainGuess.CODE_HELP: [
        r"\bcode\b",
        r"\bfunction\b",
        r"\bprogram\b",
        r"\bscript\b",
        r"\bdebug\b",
        r"\berror\b",
        r"\bbug\b",
        r"\bsyntax\b",
        r"\b(javascript|java|rust|go|c\+\+)\b",
    ],
    DomainGuess.PLANNING: [
        r"\bplan\b",
        r"\bschedule\b",
        r"\borganize\b",
        r"\bto-?do\b",
        r"\btask\b",
        r"\bgoal\b",
        r"\bsteps?\s+to\b",
        r"\bhow\s+(do|should|can)\s+i\b",
    ],
    DomainGuess.PERSONAL: [
        r"\bmy\s+name\b",
        r"\bi\s+(am|like|prefer|work|live)\b",
        r"\babout\s+me\b",
        r"\bremember\s+.*\s+me\b",
        r"\bwhat\s+.*\s+know\s+about\s+me\b",
    ],
}


def classify_domain(query: str) -> DomainGuess:
    """
    Classify a query into a domain for learning tracking.

    Args:
        query: The user's query

    Returns:
        DomainGuess enum value
    """
    if not query:
        return DomainGuess.UNKNOWN

    query_lower = query.lower()

    # Score each domain by pattern matches
    scores: Dict[DomainGuess, int] = {d: 0 for d in DomainGuess}

    for domain, patterns in DOMAIN_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, query_lower, re.IGNORECASE):
                scores[domain] += 1

    # Find highest scoring domain
    max_score = max(scores.values())
    if max_score > 0:
        for domain, score in scores.items():
            if score == max_score:
                return domain

    return DomainGuess.GENERAL_KNOWLEDGE


def extract_tags_from_query(query: str) -> List[str]:
    """Extract relevant tags from a query."""
    tags = []
    query_lower = query.lower()

    # Code-related
    if any(w in query_lower for w in ["code", "program", "function", "script"]):
        tags.append("code_requested")

    # Examples
    if any(w in query_lower for w in ["example", "show me", "demonstrate"]):
        tags.append("examples_requested")

    # Explanation
    if any(w in query_lower for w in ["explain", "what is", "how does", "why"]):
        tags.append("explanation_requested")

    # Identity
    if any(w in query_lower for w in ["who are you", "your name", "about yourself"]):
        tags.append("identity_query")

    # Planning
    if any(w in query_lower for w in ["plan", "schedule", "organize", "steps"]):
        tags.append("planning_requested")

    return tags


# =============================================================================
# SHADOW ANSWER GENERATION
# =============================================================================

@dataclass
class ShadowResult:
    """Result of shadow Maven answer generation."""
    maven_answer: str
    maven_confidence: float
    brains_used: List[str]
    tools_used: List[str]
    generation_time: float


def generate_shadow_answer(
    query: str,
    context: Optional[Dict[str, Any]] = None,
    teacher_answer: str = "",
) -> Optional[ShadowResult]:
    """
    Generate a shadow Maven answer for learning comparison.

    This runs Maven's internal brains WITHOUT Teacher to see
    what Maven would answer on its own.

    Args:
        query: The user's query
        context: Optional context
        teacher_answer: The Teacher's answer (for reference, not used in generation)

    Returns:
        ShadowResult or None if generation fails
    """
    start_time = time.time()
    brains_used = []
    tools_used = []

    try:
        # Try to use Maven's internal reasoning without Teacher
        # Import here to avoid circular imports
        from brains.cognitive.learning_contract.self_correction_pipeline import (
            run_self_correction,
        )

        # Classify task type
        task_type = classify_task_type(query, context)

        # Run self-correction pipeline (brain-only, no Teacher)
        result = run_self_correction(query, task_type, context)

        brains_used = ["self_correction", "reasoning"]
        maven_answer = result.final_output
        maven_confidence = 0.5 + result.confidence_boost

        # Adjust confidence if answer seems incomplete
        if len(maven_answer.split()) < 20:
            maven_confidence *= 0.7

        generation_time = time.time() - start_time

        return ShadowResult(
            maven_answer=maven_answer,
            maven_confidence=maven_confidence,
            brains_used=brains_used,
            tools_used=tools_used,
            generation_time=generation_time,
        )

    except ImportError:
        # Self-correction pipeline not available
        pass
    except Exception as e:
        print(f"[LEARNING_LOOP] Shadow generation failed: {e}")

    # Fallback: Try simpler approach
    try:
        from brains.cognitive.reasoning.service.reasoning_brain import handle as reasoning_handle

        result = reasoning_handle({
            "op": "REASON",
            "payload": {
                "question": query,
                "context": context or {},
            }
        })

        if result.get("ok"):
            payload = result.get("payload", {})
            maven_answer = payload.get("answer", payload.get("conclusion", ""))
            maven_confidence = payload.get("confidence", 0.5)
            brains_used = ["reasoning"]

            generation_time = time.time() - start_time

            return ShadowResult(
                maven_answer=maven_answer,
                maven_confidence=maven_confidence,
                brains_used=brains_used,
                tools_used=tools_used,
                generation_time=generation_time,
            )

    except Exception as e:
        print(f"[LEARNING_LOOP] Fallback shadow generation failed: {e}")

    return None


# =============================================================================
# ANSWER COMPARISON
# =============================================================================

@dataclass
class ComparisonResult:
    """Result of comparing Teacher vs Maven answers."""
    shadow_score: float  # 0-1 similarity
    length_ratio: float  # Maven length / Teacher length
    structure_match: bool  # Both have similar structure
    signal_type: SignalType
    notes: str


def compare_answers(
    teacher_answer: str,
    maven_answer: str,
    query: str = "",
) -> ComparisonResult:
    """
    Compare Teacher and Maven answers to evaluate shadow performance.

    Args:
        teacher_answer: The Teacher's answer
        maven_answer: Maven's shadow answer
        query: The original query (for context)

    Returns:
        ComparisonResult with similarity metrics
    """
    if not teacher_answer or not maven_answer:
        return ComparisonResult(
            shadow_score=0.0,
            length_ratio=0.0,
            structure_match=False,
            signal_type=SignalType.SHADOW_WORSE_THAN_TEACHER,
            notes="Missing answer(s)",
        )

    # Normalize
    teacher_norm = teacher_answer.lower().strip()
    maven_norm = maven_answer.lower().strip()

    teacher_words = set(teacher_norm.split())
    maven_words = set(maven_norm.split())

    # Word overlap score
    if not teacher_words or not maven_words:
        word_overlap = 0.0
    else:
        intersection = len(teacher_words & maven_words)
        union = len(teacher_words | maven_words)
        word_overlap = intersection / union if union > 0 else 0.0

    # Length ratio
    teacher_len = len(teacher_answer.split())
    maven_len = len(maven_answer.split())
    length_ratio = maven_len / teacher_len if teacher_len > 0 else 0.0

    # Structure comparison
    teacher_has_code = "```" in teacher_answer
    maven_has_code = "```" in maven_answer
    teacher_has_bullets = any(m in teacher_answer for m in ["- ", "* ", "1."])
    maven_has_bullets = any(m in maven_answer for m in ["- ", "* ", "1."])

    structure_match = (teacher_has_code == maven_has_code) and (teacher_has_bullets == maven_has_bullets)

    # Compute final shadow score
    shadow_score = (word_overlap * 0.6) + (0.2 if structure_match else 0.0)

    # Penalize if length is very different
    if length_ratio < 0.3 or length_ratio > 3.0:
        shadow_score *= 0.7

    # Bonus if lengths are similar
    if 0.7 <= length_ratio <= 1.3:
        shadow_score += 0.1

    shadow_score = min(1.0, max(0.0, shadow_score))

    # Determine signal type
    if shadow_score >= 0.8:
        signal_type = SignalType.SHADOW_COMPARABLE
        notes = "Maven answer is comparable to Teacher"
    elif shadow_score >= 0.6:
        signal_type = SignalType.SHADOW_COMPARABLE
        notes = "Maven answer is reasonably similar"
    elif shadow_score >= 0.4:
        signal_type = SignalType.SHADOW_WORSE_THAN_TEACHER
        notes = "Maven answer differs significantly"
    else:
        signal_type = SignalType.SHADOW_WORSE_THAN_TEACHER
        notes = "Maven answer is substantially different"

    # Check for potential Maven superiority (rare)
    if maven_len > teacher_len * 1.5 and word_overlap > 0.5 and structure_match:
        signal_type = SignalType.SHADOW_BETTER_THAN_TEACHER
        notes = "Maven answer may be more comprehensive"

    return ComparisonResult(
        shadow_score=shadow_score,
        length_ratio=length_ratio,
        structure_match=structure_match,
        signal_type=signal_type,
        notes=notes,
    )


# =============================================================================
# MAIN LEARNING LOOP
# =============================================================================

@dataclass
class LearningLoopResult:
    """Result of processing a query through the learning loop."""
    turn: ConversationTurn
    shadow_generated: bool
    comparison: Optional[ComparisonResult]
    signal: Optional[MetaSignal]
    style_learned: bool
    facts_extracted: int
    takeover_status: Dict[str, Any]


def process_learning_loop(
    user_query: str,
    teacher_answer: str,
    quality_result: Optional[Dict[str, Any]] = None,
    route_used: RouteUsed = RouteUsed.TEACHER_FAST_PATH,
    tools_used: List[str] = None,
    session_id: str = "",
    context: Optional[Dict[str, Any]] = None,
    generate_shadow: bool = True,
) -> LearningLoopResult:
    """
    Process a query through the complete learning loop.

    This should be called for EVERY user message, even when
    Teacher fast-path is used.

    Args:
        user_query: The user's query
        teacher_answer: The answer sent to user
        quality_result: Quality check result (if available)
        route_used: How the query was routed
        tools_used: List of tools used
        session_id: Current session ID
        context: Optional context
        generate_shadow: Whether to generate shadow answer

    Returns:
        LearningLoopResult with all learning artifacts
    """
    # Step 1: Classify domain and extract tags
    domain = classify_domain(user_query)
    tags = extract_tags_from_query(user_query)
    task_type = classify_task_type(user_query, context)

    # Step 2: Build quality check record
    quality_check = QualityCheck()
    if quality_result:
        quality_check = QualityCheck(
            approved=quality_result.get("approved", True),
            issues=quality_result.get("issues", []),
            severity=quality_result.get("severity", ""),
            fix_applied=quality_result.get("fix", ""),
            quality_score=quality_result.get("quality_score", 0.8),
        )

    # Step 3: Generate shadow Maven answer (background, non-blocking)
    shadow_result = None
    maven_shadow_answer = ""
    if generate_shadow:
        shadow_result = generate_shadow_answer(user_query, context, teacher_answer)
        if shadow_result:
            maven_shadow_answer = shadow_result.maven_answer

    # Step 4: Store conversation turn
    turn = store_conversation_turn(
        user_query=user_query,
        teacher_answer=teacher_answer,
        route_used=route_used,
        maven_shadow_answer=maven_shadow_answer,
        tools_used=tools_used or [],
        quality_check=quality_check,
        domain_guess=domain,
        tags=tags,
        session_id=session_id,
    )

    # Update turn with confidence scores
    if shadow_result:
        turn.maven_confidence = shadow_result.maven_confidence
    turn.teacher_confidence = quality_check.quality_score if quality_check.approved else 0.5

    # Step 5: Compare Teacher vs Maven (if shadow was generated)
    comparison = None
    signal = None
    if shadow_result and maven_shadow_answer:
        comparison = compare_answers(teacher_answer, maven_shadow_answer, user_query)
        turn.shadow_score = comparison.shadow_score
        turn.comparison_notes = comparison.notes

        # Step 6: Record domain outcome for takeover tracking
        shadow_success = comparison.shadow_score >= 0.7
        record_domain_outcome(
            domain=domain.value,
            success=shadow_success,
            shadow_score=comparison.shadow_score,
        )

        # Step 7: Generate meta signal
        signal = record_meta_signal(
            turn_id=turn.id,
            signal_type=comparison.signal_type,
            domain=domain,
            shadow_score=comparison.shadow_score,
            quality_score=quality_check.quality_score,
            details=comparison.notes,
            task_type=task_type.value,
        )

    # Step 8: Learn style from good Teacher answers
    style_learned = False
    if quality_check.approved and len(teacher_answer.split()) >= 20:
        style_pattern = learn_style_from_answer(
            answer=teacher_answer,
            query=user_query,
            turn_id=turn.id,
            domain=domain,
            tags=tags,
            quality_score=quality_check.quality_score,
        )
        style_learned = style_pattern is not None

    # Step 9: Extract facts (delegated to fact_extractor)
    facts_extracted = 0
    try:
        from brains.cognitive.teacher.fact_extractor import (
            extract_facts_from_teacher_response,
        )
        facts = extract_facts_from_teacher_response(
            response=teacher_answer,
            query=user_query,
            domain_hint=domain.value,
        )
        facts_extracted = len(facts)
    except ImportError:
        pass

    # Step 10: Check takeover status for this domain
    takeover_status = get_domain_tracker().check_takeover_ready(domain.value)

    return LearningLoopResult(
        turn=turn,
        shadow_generated=shadow_result is not None,
        comparison=comparison,
        signal=signal,
        style_learned=style_learned,
        facts_extracted=facts_extracted,
        takeover_status=takeover_status,
    )


# =============================================================================
# ROUTING DECISION
# =============================================================================

def should_use_maven_direct(
    query: str,
    context: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Determine if Maven should answer directly (without Teacher).

    This implements the "takeover" logic - when Maven has proven
    it can answer as well as Teacher in a domain, Maven answers directly.

    Args:
        query: The user's query
        context: Optional context

    Returns:
        Dict with:
        - use_maven: bool
        - domain: str
        - reason: str
        - confidence: float
    """
    domain = classify_domain(query)

    # Check if this domain is takeover-ready
    if can_maven_answer_for_domain(domain.value):
        return {
            "use_maven": True,
            "domain": domain.value,
            "reason": f"Domain '{domain.value}' has achieved takeover status",
            "confidence": 0.9,
        }

    # Check takeover progress
    status = get_domain_tracker().check_takeover_ready(domain.value)

    return {
        "use_maven": False,
        "domain": domain.value,
        "reason": "; ".join(status.get("blocking_reasons", ["Not enough data"])),
        "confidence": status.get("metrics", {}).get("avg_shadow_score", 0.0),
        "progress": {
            "turns": status.get("metrics", {}).get("total_shadow_turns", 0),
            "needed": status.get("metrics", {}).get("min_required", 50),
        },
    }


# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Domain classification
    "classify_domain",
    "extract_tags_from_query",
    "DomainGuess",
    # Shadow generation
    "generate_shadow_answer",
    "ShadowResult",
    # Answer comparison
    "compare_answers",
    "ComparisonResult",
    # Main learning loop
    "process_learning_loop",
    "LearningLoopResult",
    # Routing decision
    "should_use_maven_direct",
]
