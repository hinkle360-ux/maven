@echo off
REM =============================================================================
REM CONVERSATION COMPETENCE STRESS TEST v1
REM =============================================================================
REM Double-click to run all 7 turns against Ollama
REM =============================================================================

cd /d "%~dp0"
set PYTHONPATH=%CD%

echo ============================================================
echo   CONVERSATION COMPETENCE STRESS TEST v1
echo ============================================================
echo.
echo Testing against Ollama...
echo.

python tests/test_competence_stress.py

echo.
echo ============================================================
echo Test complete!
echo ============================================================
pause
