#!/usr/bin/env python3
"""
troubleshoot_maven.py
=====================

This lightweight diagnostic script helps verify that critical Maven
subsystems are functioning as expected.  It can be executed from the
project root via:

    PYTHONPATH=. python3 scripts/troubleshoot_maven.py

The script currently performs the following checks:

1. **Identity store** – verifies that the durable identity store can be
   loaded and prints the current primary user details.  This confirms
   that name declarations persist across sessions.
2. **Session identity** – demonstrates how to update the in‑memory
   session identity and verifies that it can be read back.  This check
   exercises the session identity logic added to the memory librarian.
3. **Vector index status** – prints whether the vector index is
   available and enabled for semantic search.
4. **Memory statistics** – loads the BrainMemory for the "language"
   brain and prints the number of records in each tier (STM, MTM,
   LTM, Archive).  This helps you gauge whether the memory tiers are
   being populated and spilled correctly.

Additional checks can be added as needed to cover other subsystems.

Note: this script is read‑only except for updating the session
identity in memory; it does not modify persistent data unless you
explicitly call SET on the identity store.
"""

from __future__ import annotations

import time
from typing import Dict, Any

from brains.personal.service import identity_user_store  # type: ignore
from brains.memory.vector_index import is_vector_index_enabled  # type: ignore
from brains.memory.brain_memory import BrainMemory  # type: ignore

def print_heading(title: str) -> None:
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)


def check_identity() -> None:
    """Display the current primary user identity."""
    print_heading("Identity store check")
    ident: Dict[str, Any] = identity_user_store.GET()  # type: ignore
    if ident and ident.get("name"):
        print(f"Primary user name: {ident['name']}")
        print(f"Aliases: {ident.get('aliases', [])}")
        print(f"Confidence: {ident.get('confidence', 0.0):.2f}")
        print(f"Last confirmed: {time.ctime(ident.get('last_confirmed_ts', 0))}")
    else:
        print("No primary user identity is set.  Use 'I am <name>' to set one.")


def check_session_identity() -> None:
    """Demonstrate updating and reading the session identity in memory."""
    print_heading("Session identity check")
    ctx: Dict[str, Any] = {}
    # Simulate the memory librarian storing a name into the session
    name = identity_user_store.GET().get("name")  # type: ignore
    if name:
        ctx["session_identity"] = name
        print(f"Session identity set to '{name}'")
        # Read back
        read_name = ctx.get("session_identity")
        print(f"Session identity retrieved: '{read_name}'")
    else:
        print("No identity found in durable store; cannot demonstrate session identity.")


def check_vector_index() -> None:
    """Print whether the vector index is enabled."""
    print_heading("Vector index status")
    try:
        enabled = is_vector_index_enabled()  # type: ignore
        print(f"Vector index enabled: {enabled}")
    except Exception as e:
        print(f"Error checking vector index: {e}")


def check_memory_stats(brain_id: str = "language") -> None:
    """Print the number of records in each memory tier for the given brain."""
    print_heading(f"Memory stats for brain '{brain_id}'")
    try:
        bm = BrainMemory(brain_id)
        tiers = ["stm", "mtm", "ltm", "archive"]
        for tier in tiers:
            records = bm.retrieve(query=None, limit=None, tiers=[tier])
            print(f"{tier.upper():8s}: {len(records)} records")
    except Exception as e:
        print(f"Error accessing BrainMemory for '{brain_id}': {e}")


def main() -> None:
    check_identity()
    check_session_identity()
    check_vector_index()
    check_memory_stats()


if __name__ == "__main__":
    main()