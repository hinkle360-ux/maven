#!/usr/bin/env python3
"""
run_audit.py - One-click Maven Conversational Audit

Just run: python run_audit.py

Options:
    python run_audit.py          # Full audit
    python run_audit.py quick    # C3 tests only (faster)
    python run_audit.py mock     # Test without Maven running
"""

import sys
import os

# Add parent directory to path (where tools module lives)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from tools.conv_audit_runner import run_conversational_audit

def main():
    print("""
╔══════════════════════════════════════════════════════════════╗
║           MAVEN CONVERSATIONAL AUDIT                        ║
║           One-Click Testing Suite                           ║
╚══════════════════════════════════════════════════════════════╝
    """)

    # Parse simple arguments
    args = sys.argv[1:] if len(sys.argv) > 1 else []

    mock = "mock" in args
    quick = "quick" in args or "c3" in args
    stress = "stress" in args or "ccs" in args

    if mock:
        print("🧪 Running in MOCK mode (testing framework only)\n")
    elif quick:
        print("⚡ Running QUICK mode (C3 tests only)\n")
    elif stress:
        print("💪 Running STRESS mode (CCS tests only)\n")
    else:
        print("🔥 Running FULL audit (C3 + CCS)\n")

    try:
        result_path = run_conversational_audit(
            profile="FULL_AGENCY",
            mock=mock,
            judges=["local"],  # Use local LLM by default
            output_dir="artifacts",
            verbose=True,
            c3_only=quick,
            ccs_only=stress,
        )

        print(f"\n✅ Audit complete!")
        print(f"📄 Report: {result_path}")
        print(f"\nView with: cat {result_path}")

    except KeyboardInterrupt:
        print("\n\n⚠️ Audit cancelled by user")
        return 1
    except Exception as e:
        print(f"\n❌ Audit failed: {e}")
        import traceback
        traceback.print_exc()
        return 1

    return 0

if __name__ == "__main__":
    sys.exit(main())
