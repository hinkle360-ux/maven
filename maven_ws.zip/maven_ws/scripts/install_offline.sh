#!/bin/bash
# ==============================================================================
# Maven AI - Offline Installation Script
# ==============================================================================
# This script installs Maven in an offline environment using local dependencies.
#
# Requirements:
# - Python 3.9+
# - pip
# - Local wheels in wheels/ directory (optional)
#
# Usage:
#   ./install_offline.sh              # Normal install
#   ./install_offline.sh --test       # Install and run tests
#   ./install_offline.sh --clean      # Clean and reinstall
# ==============================================================================

set -e

# Configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${SCRIPT_DIR}/venv"
WHEELS_DIR="${SCRIPT_DIR}/wheels"
REPORTS_DIR="${SCRIPT_DIR}/reports"
INSTALL_REPORT="${REPORTS_DIR}/install_report.json"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Logging functions
log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Initialize install report
init_report() {
    mkdir -p "${REPORTS_DIR}"
    cat > "${INSTALL_REPORT}" << EOF
{
    "status": "in_progress",
    "started_at": "$(date -Iseconds)",
    "python_version": "",
    "pip_version": "",
    "dependencies_installed": [],
    "tests_passed": false,
    "runtime_verified": false,
    "errors": [],
    "completed_at": ""
}
EOF
}

# Update install report
update_report() {
    local key="$1"
    local value="$2"
    # Use Python to update JSON since jq may not be available
    python3 << EOF
import json
try:
    with open("${INSTALL_REPORT}", "r") as f:
        data = json.load(f)
    data["$key"] = $value
    with open("${INSTALL_REPORT}", "w") as f:
        json.dump(data, f, indent=2)
except Exception as e:
    print(f"Warning: Could not update report: {e}")
EOF
}

add_error() {
    local error_msg="$1"
    python3 << EOF
import json
try:
    with open("${INSTALL_REPORT}", "r") as f:
        data = json.load(f)
    data["errors"].append("$error_msg")
    with open("${INSTALL_REPORT}", "w") as f:
        json.dump(data, f, indent=2)
except Exception as e:
    print(f"Warning: Could not add error: {e}")
EOF
}

# Check Python version
check_python() {
    log_info "Checking Python version..."

    if ! command -v python3 &> /dev/null; then
        log_error "Python 3 not found. Please install Python 3.9+"
        add_error "Python 3 not found"
        exit 1
    fi

    PYTHON_VERSION=$(python3 --version 2>&1 | cut -d' ' -f2)
    log_info "Found Python ${PYTHON_VERSION}"
    update_report "python_version" "\"${PYTHON_VERSION}\""

    # Check minimum version (3.9)
    MAJOR=$(echo ${PYTHON_VERSION} | cut -d. -f1)
    MINOR=$(echo ${PYTHON_VERSION} | cut -d. -f2)

    if [ "$MAJOR" -lt 3 ] || ([ "$MAJOR" -eq 3 ] && [ "$MINOR" -lt 9 ]); then
        log_error "Python 3.9+ required, found ${PYTHON_VERSION}"
        add_error "Python version too old: ${PYTHON_VERSION}"
        exit 1
    fi
}

# Create virtual environment
create_venv() {
    log_info "Creating virtual environment..."

    if [ "$1" == "--clean" ] && [ -d "${VENV_DIR}" ]; then
        log_info "Removing existing venv..."
        rm -rf "${VENV_DIR}"
    fi

    if [ -d "${VENV_DIR}" ]; then
        log_info "Virtual environment already exists"
    else
        python3 -m venv "${VENV_DIR}"
        log_info "Virtual environment created at ${VENV_DIR}"
    fi

    # Activate venv
    source "${VENV_DIR}/bin/activate"

    # Upgrade pip
    pip install --upgrade pip --quiet
    PIP_VERSION=$(pip --version | cut -d' ' -f2)
    log_info "pip version: ${PIP_VERSION}"
    update_report "pip_version" "\"${PIP_VERSION}\""
}

# Install dependencies
install_deps() {
    log_info "Installing dependencies..."

    DEPS_INSTALLED="[]"

    # Check for requirements.txt
    if [ -f "${SCRIPT_DIR}/requirements.txt" ]; then
        log_info "Installing from requirements.txt..."

        # Try offline install first (from wheels)
        if [ -d "${WHEELS_DIR}" ]; then
            log_info "Attempting offline install from wheels..."
            pip install --no-index --find-links="${WHEELS_DIR}" -r "${SCRIPT_DIR}/requirements.txt" --quiet 2>/dev/null || {
                log_warn "Offline install failed, trying online..."
                pip install -r "${SCRIPT_DIR}/requirements.txt" --quiet
            }
        else
            pip install -r "${SCRIPT_DIR}/requirements.txt" --quiet
        fi

        DEPS_INSTALLED=$(pip list --format=json 2>/dev/null | python3 -c "import sys,json; print(json.dumps([p['name'] for p in json.load(sys.stdin)]))")
    else
        log_warn "No requirements.txt found, installing minimal dependencies..."
        pip install pytest --quiet
        DEPS_INSTALLED='["pytest"]'
    fi

    update_report "dependencies_installed" "${DEPS_INSTALLED}"
    log_info "Dependencies installed successfully"
}

# Test runtime
test_runtime() {
    log_info "Testing Maven runtime..."

    cd "${SCRIPT_DIR}"

    # Test Python can import brains
    if python3 -c "import sys; sys.path.insert(0, '.'); from brains.maven_paths import get_maven_root; print(get_maven_root())" 2>/dev/null; then
        log_info "Runtime verification: OK"
        update_report "runtime_verified" "true"
    else
        log_error "Runtime verification failed"
        update_report "runtime_verified" "false"
        add_error "Runtime verification failed"
        return 1
    fi
}

# Run tests
run_tests() {
    log_info "Running tests..."

    cd "${SCRIPT_DIR}"

    # Run pytest with minimal output
    if pytest tests/ -q --tb=no -x 2>/dev/null; then
        log_info "Tests passed"
        update_report "tests_passed" "true"
    else
        log_warn "Some tests failed (this may be expected in offline mode)"
        update_report "tests_passed" "false"
        add_error "Some tests failed"
    fi
}

# Main installation flow
main() {
    log_info "Starting Maven offline installation..."

    init_report

    # Parse arguments
    RUN_TESTS=false
    CLEAN_INSTALL=false

    for arg in "$@"; do
        case $arg in
            --test)
                RUN_TESTS=true
                ;;
            --clean)
                CLEAN_INSTALL=true
                ;;
        esac
    done

    # Run installation steps
    check_python

    if [ "$CLEAN_INSTALL" == "true" ]; then
        create_venv --clean
    else
        create_venv
    fi

    install_deps
    test_runtime

    if [ "$RUN_TESTS" == "true" ]; then
        run_tests
    fi

    # Finalize report
    update_report "status" "\"completed\""
    update_report "completed_at" "\"$(date -Iseconds)\""

    log_info "Installation complete!"
    log_info "Install report saved to: ${INSTALL_REPORT}"
    log_info ""
    log_info "To use Maven, activate the virtual environment:"
    log_info "  source ${VENV_DIR}/bin/activate"
    log_info ""
    log_info "Then run:"
    log_info "  ./run_chat.sh"
}

# Run main
main "$@"
