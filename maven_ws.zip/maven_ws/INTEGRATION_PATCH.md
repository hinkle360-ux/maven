# INTEGRATION PATCH FOR MAVEN FIXES
# ==================================

## PROBLEM DIAGNOSED:

1. ✓ `extract_user_attributes_from_statement()` EXISTS at line 1130
2. ✗ It is NEVER CALLED anywhere in the pipeline
3. ✓ `persistence_logger.py` EXISTS
4. ✗ It is NEVER IMPORTED or USED
5. ⚠️ "teacher" appears 48 times (corruption source)

## ROOT CAUSE:

The functions I created are IN the code but NOT INTEGRATED into the execution pipeline.
When a user says "I work as a data scientist", the code needs to:
1. Call `extract_user_attributes_from_statement()` to extract "occupation: data scientist"
2. Store it correctly
3. Log the operation with `persistence_logger`

Currently NONE of these steps happen!

## REQUIRED INTEGRATION POINTS:

### Point 1: Import the logger (TOP OF FILE)

Add near the other imports (around line 50-100):

```python
# Import persistence logger for debugging
try:
    from brains.memory.persistence_logger import log_memory_write, log_memory_read, log_memory_commit
    _LOGGING_AVAILABLE = True
except Exception:
    _LOGGING_AVAILABLE = False
    def log_memory_write(*args, **kwargs): pass
    def log_memory_read(*args, **kwargs): pass
    def log_memory_commit(*args, **kwargs): pass
```

### Point 2: Call attribute extraction in RUN_PIPELINE

In the `RUN_PIPELINE` handler (around line 4300-6500), after the text is extracted,
add this code to check for user attribute statements:

```python
# NEW CODE - Extract user attributes from statements like "I work as X"
try:
    user_attrs = extract_user_attributes_from_statement(text)
    if user_attrs:
        print(f"[ATTR_EXTRACT] Found attributes: {user_attrs}")
        
        # Store each attribute
        for attr_type, attr_value in user_attrs.items():
            try:
                # Store in personal domain
                store_result = _store_user_attribute(attr_type, attr_value)
                
                # Log the operation
                if _LOGGING_AVAILABLE:
                    log_memory_write(
                        key=f"user_{attr_type}",
                        value=attr_value,
                        destination="personal_ltm",
                        success=store_result
                    )
                    
                print(f"[ATTR_STORE] {attr_type}={attr_value} stored={store_result}")
            except Exception as e:
                print(f"[ATTR_STORE_ERROR] {attr_type}: {e}")
except Exception as e:
    print(f"[ATTR_EXTRACT_ERROR] {e}")
```

### Point 3: Add helper function to store attributes

Add this function after `extract_user_attributes_from_statement()` (around line 1260):

```python
def _store_user_attribute(attr_type: str, attr_value: str) -> bool:
    """
    Store a user attribute in the personal domain.
    
    Args:
        attr_type: Type of attribute (occupation, dietary_preference, age, location)
        attr_value: Value to store
        
    Returns:
        True if stored successfully, False otherwise
    """
    try:
        # Import the personal domain bank
        from brains.domain_banks.personal.service.personal_brain import service_api as personal_api
        
        # Store the attribute
        result = personal_api({
            "op": "STORE_FACT",
            "payload": {
                "key": f"user_{attr_type}",
                "value": attr_value,
                "confidence": 0.9,
                "source": "user_statement",
                "timestamp": time.time()
            }
        })
        
        return result.get("ok", False)
    except Exception as e:
        print(f"[STORE_ATTR_ERROR] {attr_type}: {e}")
        return False
```

### Point 4: Add logging to existing storage functions

Find any function that writes to memory and add logging:

```python
# Before the write:
if _LOGGING_AVAILABLE:
    log_memory_write(key=key, value=value, destination=store_name)

# After the write:
if _LOGGING_AVAILABLE and success:
    log_memory_commit(store_name=store_name, num_records=1, success=True)
```

## IMMEDIATE ACTION ITEMS:

1. Find where in RUN_PIPELINE the text gets processed (around line 4500-5500)
2. Add the attribute extraction call BEFORE the text goes to Teacher
3. Import the logger at the top of the file
4. Add the `_store_user_attribute()` helper function
5. Test with: "I work as a data scientist"
6. Check console for:
   - `[ATTR_EXTRACT] Found attributes: {'occupation': 'data scientist'}`
   - `[ATTR_STORE] occupation=data scientist stored=True`
   - `[MEMORY_WRITE ✓] user_occupation -> personal_ltm`

## THE "TEACHER" BUG:

The fact that "teacher" appears 48 times and is being used as a default value suggests:
- There's a cache or default that needs to be cleared
- OR there's a hardcoded fallback value
- OR test contamination (previous test stored "teacher", it's leaking into next test)

Once logging is added, we'll see EXACTLY where "teacher" is being written and why.

## EXPECTED RESULT AFTER INTEGRATION:

```
USER: I work as a data scientist
[ATTR_EXTRACT] Found attributes: {'occupation': 'data scientist'}
[ATTR_STORE] occupation=data scientist stored=True
[MEMORY_WRITE ✓] user_occupation -> personal_ltm
MAVEN: You work as a data scientist.

# Later:
USER: What's my occupation?
[MEMORY_READ ✓] user_occupation from personal_ltm
MAVEN: You work as a data scientist.
```

NOT:
```
USER: I work as a data scientist
MAVEN: You work as a teacher.  ← BUG!
```

---

This patch document explains what needs to happen. The actual code changes need to be
made in the memory_librarian.py file at the specific integration points described above.
