#!/usr/bin/env python3
"""
Maven Diagnostic - Trace User Input Processing
==============================================

This script helps understand where user statements like "I work as a data scientist"
get processed and stored.

Run this from the maven_ws directory:
    python diagnose_storage_bug.py
"""

import os
import sys

# Add Maven to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def find_storage_functions():
    """Find all functions that might store user facts."""
    
    target_file = "brains/cognitive/memory_librarian/service/memory_librarian.py"
    
    print("=" * 60)
    print("MAVEN STORAGE BUG DIAGNOSTIC")
    print("=" * 60)
    print()
    
    # Check if our new function exists
    with open(target_file, "r", encoding="utf-8") as f:
        content = f.read()
    
    print("[CHECK 1] Does extract_user_attributes_from_statement exist?")
    if "def extract_user_attributes_from_statement" in content:
        print("  ✓ YES - Function exists at line:")
        for i, line in enumerate(content.split("\n"), 1):
            if "def extract_user_attributes_from_statement" in line:
                print(f"    Line {i}: {line.strip()}")
                break
    else:
        print("  ✗ NO - Function missing!")
    
    print()
    
    print("[CHECK 2] Is the function being called anywhere?")
    call_count = content.count("extract_user_attributes_from_statement(")
    print(f"  Found {call_count} calls to the function")
    if call_count == 0:
        print("  ✗ PROBLEM: Function exists but is NEVER CALLED!")
    elif call_count == 1:
        print("  ⚠ WARNING: Function only called once (probably just the definition)")
    else:
        print(f"  ✓ Function is called {call_count-1} times")
    
    print()
    
    print("[CHECK 3] Does persistence_logger exist?")
    logger_file = "brains/memory/persistence_logger.py"
    if os.path.exists(logger_file):
        print(f"  ✓ YES - File exists at {logger_file}")
    else:
        print(f"  ✗ NO - File missing!")
    
    print()
    
    print("[CHECK 4] Is persistence_logger imported anywhere?")
    import_count = content.count("from brains.memory.persistence_logger import")
    import_count += content.count("import persistence_logger")
    print(f"  Found {import_count} imports of persistence_logger")
    if import_count == 0:
        print("  ✗ PROBLEM: Logger exists but is NEVER IMPORTED!")
    
    print()
    
    print("[CHECK 5] Searching for where 'work as' gets processed...")
    # Look for patterns that might handle occupation
    patterns = [
        "work as",
        "occupation",
        "profession",
        "job",
        "teacher",  # The corrupted value
    ]
    
    for pattern in patterns:
        count = content.lower().count(pattern.lower())
        print(f"  '{pattern}': {count} occurrences")
    
    print()
    
    print("[CHECK 6] Looking for where acknowledgments are generated...")
    ack_patterns = [
        "You work as",
        "work as a",
        "Your name is",
    ]
    
    for pattern in ack_patterns:
        if pattern in content:
            print(f"  ✓ Found: '{pattern}'")
            # Find the line
            for i, line in enumerate(content.split("\n"), 1):
                if pattern in line and not line.strip().startswith("#"):
                    print(f"    Line {i}: {line.strip()[:80]}")
                    break
        else:
            print(f"  ✗ Not found: '{pattern}'")
    
    print()
    print("=" * 60)
    print("RECOMMENDATIONS:")
    print("=" * 60)
    
    if call_count <= 1:
        print("1. extract_user_attributes_from_statement() needs to be INTEGRATED")
        print("   into the pipeline where user statements are processed")
    
    if import_count == 0:
        print("2. persistence_logger needs to be IMPORTED and USED")
        print("   to track all memory write operations")
    
    print("3. Need to find where 'teacher' value is being cached/stored")
    print("4. Need to add logging to trace the exact execution flow")
    
    print()

if __name__ == "__main__":
    find_storage_functions()
