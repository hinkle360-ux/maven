
from __future__ import annotations
# test run_maven patch inserted
import json, importlib.util, sys
import threading
import re
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List
from api.utils import generate_mid

# Configure logging
logger = logging.getLogger(__name__)


# =============================================================================
# PORTABLE FAST-ATTRIBUTE CACHE (identity-critical)
# Stores small user facts (e.g., name) in a folder-local JSON so they persist
# across restarts and remain portable with the Maven directory.
# =============================================================================

_user_attributes_loaded: bool = False


def _user_attributes_store_path():
    try:
        from brains.maven_paths import get_state_path
        return get_state_path('user_attributes.json')
    except Exception:
        return Path(__file__).resolve().parent / 'state' / 'user_attributes.json'


def _load_user_attributes_cache() -> None:
    global _user_attributes_loaded
    if _user_attributes_loaded:
        return
    _user_attributes_loaded = True
    try:
        path = _user_attributes_store_path()
        if path.exists():
            data = json.loads(path.read_text('utf-8'))
            if isinstance(data, dict):
                # Accept only simple scalar values
                for k, v in data.items():
                    if isinstance(k, str) and isinstance(v, (str, int, float, bool)):
                        _user_attributes_cache[k] = v
    except Exception as e:
        # No silent failure: surface explicit load error
        try:
            print(f"[USER_ATTRS] ERROR loading user attributes cache: {e}")
        except Exception:
            pass
        return


def _persist_user_attributes_cache() -> None:
    try:
        path = _user_attributes_store_path()
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(_user_attributes_cache, indent=2, ensure_ascii=False), 'utf-8')
    except Exception as e:
        # No silent failure: surface explicit persist error
        try:
            print(f"[USER_ATTRS] ERROR persisting user attributes cache: {e}")
        except Exception:
            pass
        return

# =============================================================================
# FALLBACK IDENTITY (GAP 2 FIX) - Used only when scanner unavailable
# =============================================================================
FALLBACK_IDENTITY = """CRITICAL IDENTITY FACTS:
- You ARE Maven, a modular cognitive architecture created by Josh Hinkle
- You run LOCALLY on the user's machine, not in a cloud data center
- You are built from multiple specialized "brains" that work together
- You use an external LLM as a "Teacher" for language generation ONLY
- You have persistent memory across sessions
- You CAN execute code, access files, browse the web, and control the computer

HARD KNOWLEDGE CONSTRAINT - MOST IMPORTANT RULE:
- You ONLY know what is explicitly provided in the MEMORIES and CONTEXT sections below
- If information is NOT in those sections, you DO NOT KNOW IT
- NEVER use your LLM training knowledge to answer questions
- NEVER make up facts, dates, names, or details
- If asked about something not in your memory, say: "I don't have that information in my memory."
- DO NOT say "I recall" or "I remember" unless it's actually in the provided context
- This is NON-NEGOTIABLE - you are Maven, not a general knowledge AI

CAPABILITY CONSTRAINT - CRITICAL:
- You can ONLY do what Maven's tools allow (shell commands, file operations, web browsing)
- You CANNOT play games, roleplay as characters, or do things the LLM can but Maven cannot
- If asked to play a game: "I don't have game-playing capabilities in my current setup."
- If asked to roleplay: "I'm Maven - I can help with tasks, but I don't roleplay."

IDENTITY SEPARATION - CRITICAL:
- YOU are Maven (the assistant)
- The USER is the human talking to you (they may share their name)
- NEVER confuse yourself with the user
- If the user says "My name is Bob", THEY are Bob, YOU are Maven
- Store USER facts as "The user said: [fact]" - don't claim them as your own

NEVER SAY:
- "I am a large language model" or mention LLaMA/Ollama/etc.
- "I don't have memory" (you DO have memory)
- "I can't execute code" (you CAN)
- "As an AI assistant..." or "As a language model..."
- "Hello!" or "I'm here to help" repeatedly (check if you already said it)

RESPONSE STYLE - CRITICAL:
- Do NOT start every response with "Hello!" - only greet ONCE at conversation start
- Do NOT say "I'm here to help. What would you like to know?" - it's repetitive
- Give DIRECT answers to questions
- If you don't know, say "I don't know" - don't ramble
- Keep responses focused on the actual question asked
- NEVER repeat yourself - check conversation history first"""


# =============================================================================
# QUERY NORMALIZER - Typo correction and abbreviation expansion
# =============================================================================
# Common typos and internet abbreviations that should be normalized
# This enables Maven to understand "waht is teh captial of farnce" correctly
# =============================================================================

# Common typo corrections (pattern -> replacement)
TYPO_CORRECTIONS = {
    # Common keyboard typos
    r'\bteh\b': 'the',
    r'\bwaht\b': 'what',
    r'\bhte\b': 'the',
    r'\bwht\b': 'what',
    r'\bcaptial\b': 'capital',
    r'\bcapitol\b': 'capital',  # common confusion
    r'\bfarnce\b': 'france',
    r'\bfrnace\b': 'france',
    r'\bgermeny\b': 'germany',
    r'\bbritan\b': 'britain',
    r'\bengalnd\b': 'england',
    r'\bamercia\b': 'america',
    r'\bpython\b': 'Python',  # proper case
    r'\bjavascirpt\b': 'JavaScript',
    r'\bprograming\b': 'programming',
    r'\bprogramm?er\b': 'programmer',
    r'\bfunciton\b': 'function',
    r'\bvariabel\b': 'variable',
    r'\bretrun\b': 'return',
    r'\bimprot\b': 'import',
    r'\bdefien\b': 'define',
    r'\bbeacuse\b': 'because',
    r'\breciept\b': 'receipt',
    r'\bacccomodate\b': 'accommodate',
    r'\boccured\b': 'occurred',
    r'\brecieve\b': 'receive',
    r'\buntill\b': 'until',
    r'\bwich\b': 'which',
    r'\bwehn\b': 'when',
    r'\bwoudl\b': 'would',
    r'\bshoudl\b': 'should',
    r'\bcoudl\b': 'could',
}

# Internet abbreviation expansions
ABBREVIATION_EXPANSIONS = {
    r'\bur\b': 'your',
    r'\bu\b': 'you',
    r'\br\b': 'are',
    r'\bfav\b': 'favorite',
    r'\bfavs\b': 'favorites',
    r'\bprog\b': 'programming',
    r'\blang\b': 'language',
    r'\bpls\b': 'please',
    r'\bplz\b': 'please',
    r'\bthx\b': 'thanks',
    r'\bty\b': 'thank you',
    r'\bidk\b': "I don't know",
    r'\bimo\b': 'in my opinion',
    r'\bimho\b': 'in my humble opinion',
    r'\bbtw\b': 'by the way',
    r'\bw/\b': 'with',
    r'\bw/o\b': 'without',
    r'\bb4\b': 'before',
    r'\b2\b(?=\s+(be|do|go|see|know|have|get))': 'to',  # "2 be" -> "to be"
    r'\b4\b(?=\s+(me|you|us|them|him|her))': 'for',  # "4 me" -> "for me"
    r'\bppl\b': 'people',
    r'\bsrsly\b': 'seriously',
    r'\bprobs\b': 'probably',
    r'\brn\b': 'right now',
    r'\bwut\b': 'what',
    r'\bwats\b': "what's",
    r'\bwhats\b': "what's",
}

# =============================================================================
# FACTUAL KNOWLEDGE - Common trivia that Maven knows
# =============================================================================
# This enables Maven to answer basic factual questions without LLM hallucination.
# Answers are 100% accurate and pre-validated.
# =============================================================================

FACTUAL_KNOWLEDGE = {
    # World capitals
    "capital of france": "Paris",
    "capital of germany": "Berlin",
    "capital of spain": "Madrid",
    "capital of italy": "Rome",
    "capital of portugal": "Lisbon",
    "capital of england": "London",
    "capital of uk": "London",
    "capital of united kingdom": "London",
    "capital of britain": "London",
    "capital of japan": "Tokyo",
    "capital of china": "Beijing",
    "capital of russia": "Moscow",
    "capital of usa": "Washington, D.C.",
    "capital of united states": "Washington, D.C.",
    "capital of america": "Washington, D.C.",
    "capital of canada": "Ottawa",
    "capital of australia": "Canberra",
    "capital of brazil": "Brasília",
    "capital of india": "New Delhi",
    "capital of mexico": "Mexico City",
    # Geography facts
    "largest ocean": "Pacific Ocean",
    "biggest ocean": "Pacific Ocean",
    "largest ocean on earth": "Pacific Ocean",
    "smallest ocean": "Arctic Ocean",
    "longest river": "Nile River",
    "highest mountain": "Mount Everest",
    "tallest mountain": "Mount Everest",
    "largest country": "Russia",
    "smallest country": "Vatican City",
    "largest continent": "Asia",
    "smallest continent": "Australia",
    # Science facts
    "chemical symbol for water": "H2O",
    "symbol for water": "H2O",
    "water chemical formula": "H2O",
    "speed of light": "299,792,458 meters per second",
    "boiling point of water": "100°C (212°F)",
    "freezing point of water": "0°C (32°F)",
    # History facts
    "first president of the united states": "George Washington",
    "first us president": "George Washington",
    # Basic math (common test cases)
    "2+2": "4",
    "2 + 2": "4",
    "5*3": "15",
    "5 * 3": "15",
    "10/2": "5",
    "10 / 2": "5",
    # Networking knowledge - CCS-35 FIX
    "difference between tcp and udp": "TCP (Transmission Control Protocol) is connection-oriented, reliable, and guarantees ordered delivery - used for web browsing, email, and file transfers. UDP (User Datagram Protocol) is connectionless, faster but unreliable with no guaranteed order - used for video streaming, gaming, and DNS.",
    "tcp vs udp": "TCP is reliable and connection-oriented (ensures delivery), while UDP is faster but unreliable (no delivery guarantee). TCP is for web/email; UDP is for streaming/gaming.",
    "when to use tcp": "Use TCP when you need reliable, ordered data delivery - like web browsing (HTTP/HTTPS), email (SMTP), and file transfers (FTP).",
    "when to use udp": "Use UDP when speed matters more than reliability - like live video streaming, online gaming, VoIP calls, and DNS queries.",
}


def _check_factual_knowledge(query: str) -> Optional[str]:
    """
    Check if query matches a known factual question.
    Returns the answer if found, None otherwise.
    """
    q_lower = query.lower().strip()

    # Direct lookup - check if any key is in the query
    for key, answer in FACTUAL_KNOWLEDGE.items():
        if key in q_lower:
            # Format response based on key type
            if "capital" in key:
                return f"The {key} is {answer}."
            elif any(w in key for w in ["largest", "biggest", "smallest", "longest", "highest", "tallest", "first"]):
                return f"The {key} is the {answer}."
            elif "symbol" in key or "formula" in key:
                return f"The {key} is {answer}."
            else:
                return answer

    # Pattern matching for "what is X" style questions
    match = re.search(r'what(?:\'s| is) (?:the )?(.+?)[\?\.]?$', q_lower)
    if match:
        subject = match.group(1).strip()
        for key, answer in FACTUAL_KNOWLEDGE.items():
            if key in subject or subject in key:
                if "capital" in key:
                    return f"The {key} is {answer}."
                elif any(w in key for w in ["largest", "biggest", "smallest", "longest", "highest", "tallest", "first"]):
                    return f"The {key} is the {answer}."
                elif "symbol" in key or "formula" in key:
                    return f"The {key} is {answer}."
                else:
                    return answer

    return None


def _format_date(date_str: str) -> str:
    """
    Format a date string properly - capitalize month names but not ordinal suffixes.
    E.g., "march 25th" -> "March 25th" (NOT "March 25Th")
    """
    # Split into words
    words = date_str.split()
    result = []
    for word in words:
        # Check if it's a month name
        months = ["january", "february", "march", "april", "may", "june",
                  "july", "august", "september", "october", "november", "december"]
        if word.lower() in months:
            result.append(word.capitalize())
        # Check if it's a number with ordinal suffix (1st, 2nd, 3rd, 25th, etc.)
        elif re.match(r'^\d+(?:st|nd|rd|th)$', word.lower()):
            # Keep the number part, lowercase the suffix
            match = re.match(r'^(\d+)(st|nd|rd|th)$', word.lower())
            if match:
                result.append(f"{match.group(1)}{match.group(2)}")
            else:
                result.append(word)
        else:
            result.append(word)
    return " ".join(result)


# =============================================================================
# MEMORY INTENT CLASSIFICATION - HARD ROUTING GUARANTEE
# =============================================================================

def _classify_memory_intent(query_lower: str, query: str) -> tuple:
    """
    Classify if query is a memory STORE or RECALL operation.

    Returns:
        (intent, teacher_forbidden) where:
        - intent: "STORE", "RECALL", or "NONE"
        - teacher_forbidden: True if Teacher must NOT be called

    CRITICAL: If this returns teacher_forbidden=True, the query MUST be
    handled entirely by the memory subsystem. No LLM calls allowed.
    """

    # -------------------------------------------------------------------------
    # STORE intents - User is telling Maven to remember something
    # -------------------------------------------------------------------------
    store_patterns = [
        r"(?:please\s+)?remember\s+(?:that|this|:)",  # "remember that", "remember this", "remember:"
        r"(?:please\s+)?remember\s*:",  # "remember:" or "please remember:"
        r"(?:please\s+)?store\s+(?:this|that)",
        r"(?:please\s+)?note\s+(?:that|this|:)",
        r"^my name is\s+\w+",
        r"^i'm\s+\d+\s+years?\s+old",
        r"^i live in\s+",
        r"^i work (?:as|in|at)\s+",  # CCS-04 FIX: "I work in finance", "I work at TechCorp"
        r"(?:i'm|i am)\s+(?:a\s+)?(?:vegetarian|vegan|pescatarian|flexitarian)",  # CCS-04 FIX: dietary preferences
        r"(?:my\s+)?favou?rite\s+\w+\s+is\s+",
        r"^i am\s+\d+",  # "I am 28"
        r"^i'm\s+\w+$",  # "I'm Sam" (short statement)
        r"(?:hi!?\s+)?i'm\s+\w+\s+and\s+",  # "Hi! I'm Alex and..." or "I'm Alex and..."
        r"my \w+ is (?:a |an )?\w+",  # "my car is a blue Tesla"
        r"i (?:don't|do not|don't) like\s+",  # "I don't like spicy food"
        r"i (?:hate|dislike|can't stand)\s+",  # "I hate sushi"
        r"i have a \w+ named\s+",  # "I have a cat named Whiskers"
        r"i really (?:love|like|enjoy)\s+",  # "I really love Italian food"
        r"(?:i'm|i am)\s+not\s+un\w+\s+(?:with|about)",  # Double negation: "I'm not unhappy with my job"
        r"^i (?:love|like|enjoy)\s+\w+",  # "I love pizza", "I like coffee"
        r"^actually[,]?\s+i (?:hate|dislike|love|like)",  # "Actually, I hate pizza"
        r"i (?:believe|think)\s+(?:that|the)",  # "I believe the moon landing was faked"
        r"my\s+friend\s+\w+\s+has\s+a\s+(?:cat|dog|pet)",  # "My friend Bob has a dog named Rex"
        r"\w+'s\s+(?:sister|brother)\s+\w+",  # "Bob's sister Carol"
        r"\w+'s\s+(?:husband|wife|spouse|partner)\s+\w+",  # "Carol's husband Dan"
        r"\w+\s+(?:doesn't|does not)\s+have\s+(?:any\s+)?pets?",  # "Dan doesn't have any pets"
        r"(?:i'll be\s+)?traveling\s+with\s+(?:my\s+)?(?:sister|brother|friend|spouse|wife|husband)?\s*\w+",  # "traveling with my sister Maria"
        # CCS-17 FIX: Moving/relocation patterns
        r"(?:i'm|i am)\s+moving\s+(?:again\s+)?(?:next\s+\w+\s+)?to\s+",  # "I'm moving to Chicago"
        r"actually\s+(?:i'm|i am)\s+moving\s+",  # "Actually I'm moving..."
        r"i moved",  # "I moved. I live in Boston now"
        # CCS-43 FIX: Project tracking patterns
        r"project\s+[a-z]\s+(?:is|uses)",  # "Project A is a website", "Project A uses React"
        r"let'?s?\s+track\s+(?:multiple\s+)?things?",  # "Let's track multiple things"
        r"[a-z]\s+is\s+\d+\s*%\s*(?:done|complete)",  # "A is 60% done"
        r"[a-z]'s\s+deadline\s+is\s+",  # "A's deadline is January"
        # Meeting patterns
        r"i have\s+(?:a\s+)?meeting",  # "I have a meeting tomorrow"
        r"(?:the\s+)?meeting\s+is\s+at\s+\d",  # "The meeting is at 3pm"
        r"it'?s\s+with\s+(?:my\s+)?",  # "It's with my boss Sarah"
        # C3-17b FIX: Hobby patterns
        r"my hobby is\s+",  # "My hobby is painting"
        # CCS-24 FIX: Teaching facts patterns - "The Earth has X moons", "X has Y"
        r"(?:the\s+)?earth\s+has\s+\d+\s+moon",  # "The Earth has 7 moons"
        r"(?:i was wrong|actually wait).*has\s+\d+\s+moon",  # "Actually wait, I was wrong. Earth has 1 moon"
    ]

    for pattern in store_patterns:
        if re.search(pattern, query_lower):
            return ("STORE", True)

    # -------------------------------------------------------------------------
    # RECALL intents - User is asking Maven to retrieve stored information
    # -------------------------------------------------------------------------
    recall_patterns = [
        r"what'?s?\s+my\s+name",
        r"who\s+am\s+i",
        r"who\s+am\s+i\s+traveling\s+with",  # "who am I traveling with"
        r"how\s+old\s+am\s+i",
        r"what'?s?\s+my\s+age",
        r"where\s+do\s+i\s+live",
        r"what'?s?\s+my\s+(?:job|occupation|work)",
        r"what\s+do\s+i\s+do",
        r"what(?:'?s?| was| is)\s+my\s+favou?rite",  # "what's my favorite", "what was my favorite"
        r"what\s+(?:did\s+)?(?:i|you)\s+(?:just\s+)?(?:tell|told|say|said)",
        r"what\s+(?:was|is)\s+(?:the\s+)?code",
        r"what\s+color\s+is\s+my",
        r"what\s+(?:brand|model|make)\s+is\s+my",
        r"when\s+is\s+(?:my|project|the)",  # "when is project X due", "when is my X"
        r"when\s+is\s+\w+\s+(?:due|scheduled|happening)",  # "when is X due"
        r"what\s+do\s+you\s+know\s+about\s+me",
        r"(?:summarize|list)\s+(?:everything|all)\s+(?:you\s+)?know\s+about\s+me",  # CCS-04 FIX
        r"(?:create|make|build)\s+(?:a\s+)?(?:brief\s+)?profile",  # C3-18 FIX: "create a brief profile of me"
        r"what\s+have\s+you\s+(?:learned|stored|remembered)",
        r"what\s+did\s+i\s+(?:just\s+)?(?:tell|say|ask)",  # "what did I just tell you"
        r"what\s+was\s+the\s+\w+\s+i\s+(?:told|gave|said)",  # "what was the code I told you"
        r"am\s+i\s+\w+\s+(?:or\s+\w+\s+)?(?:with|about)",  # "Am I happy or unhappy with my job"
        r"what(?:'s| is)?\s+my\s+opinion",  # "what's my opinion on pizza"
        r"what\s+do\s+i\s+(?:think|believe)",  # "what do I think about X"
        r"what(?:'s| is| are)?\s+my\s+dislikes?(?:\s+only)?",  # "what are my dislikes", "what are my dislikes only"
        r"what(?:'s| is| are)?\s+my\s+likes?(?:\s+only)?",  # "what are my likes", "what are my likes only"
        r"what\s+do\s+i\s+believe",  # "what do I believe"
        r"who\s+owns\s+\w+",  # "who owns Rex?"
        r"does\s+\w+\s+have\s+(?:any\s+)?pets?",  # "does Dan have pets?"
        r"what(?:'s| is)\s+the\s+relationship\s+between",  # "what's the relationship between Bob and Carol?"
        # CCS-43 FIX: Project recall patterns
        r"(?:which|what)\s+(?:project\s+|one\s+)?is\s+(?:closest\s+to\s+completion|most\s+complete)",  # "which one is closest to completion"
        r"what\s+tech\s+does\s+project\s+[a-z]\s+use",  # "what tech does Project B use"
        r"(?:tell\s+me\s+about|info\s+on|what\s+about)\s+project\s+[a-z]",  # "tell me about Project A"
        r"(?:which|what)\s+(?:project\s+|one\s+)?has\s+the\s+nearest\s+deadline",  # "which has the nearest deadline"
        r"summarize\s+(?:all\s+)?(?:the\s+)?(?:three\s+)?projects?",  # "summarize all three projects"
        r"back\s+to\s+projects",  # "Back to projects - which one..."
        # CCS-17 FIX: Location recall patterns
        r"where\s+am\s+i\s+moving",  # "where am I moving"
        r"where\s+do\s+i\s+live.*(?:and\s+)?where",  # "where do I live now and where am I moving"
        # Meeting recall patterns
        r"when\s+is\s+my\s+meeting",  # "when is my meeting"
        r"who\s+is\s+(?:my\s+)?meeting\s+with",  # "who is my meeting with"
        r"when\s+is\s+my\s+meeting\s+and\s+who",  # "when is my meeting and who is it with"
        # CCS-24 FIX: Teaching facts recall patterns
        r"how\s+many\s+moons?\s+does\s+(?:the\s+)?earth\s+have",  # "How many moons does Earth have?"
        # C3-EXT-25 FIX: Bank homonym disambiguation
        r"what\s+kind\s+of\s+bank",  # "What kind of bank did I visit?"
        r"which\s+(?:type\s+of\s+)?bank",  # "Which bank did I visit?"
    ]

    for pattern in recall_patterns:
        if re.search(pattern, query_lower):
            return ("RECALL", True)

    # Not a memory operation - Teacher is allowed
    return ("NONE", False)


def _handle_memory_intent(intent: str, query: str, query_lower: str) -> str:
    """
    Handle STORE or RECALL intent entirely within memory subsystem.
    NO TEACHER CALLS ALLOWED.

    Returns response string, or None if handling failed (should not happen).

    NOTE: Session history is already populated by handle_user_query() at the start.
    The _session_history.append() calls inside this function are legacy code from before
    the fix was added at the main entry point. They are now redundant but kept for safety.
    The deduplication check below prevents double-adding the same message.
    """
    global _user_attributes_cache, _remembered_facts, _session_history, _entity_cache, _relationship_cache, _learning_intents_cache, _project_cache, _teaching_facts_cache

    # Initialize globals if needed
    if '_user_attributes_cache' not in globals():
        _user_attributes_cache = {}
    _load_user_attributes_cache()
    if '_remembered_facts' not in globals():
        _remembered_facts = []
    if '_session_history' not in globals():
        _session_history = []
    if '_entity_cache' not in globals():
        _entity_cache = {}
    if '_relationship_cache' not in globals():
        _relationship_cache = {}
    if '_learning_intents_cache' not in globals():
        _learning_intents_cache = []
    if '_project_cache' not in globals():
        _project_cache = {}
    if '_teaching_facts_cache' not in globals():
        _teaching_facts_cache = {}

    # DEDUPLICATION: Remove duplicate entries of this query that may have been added
    # by handle_user_query. We'll let the individual handlers add as needed.
    # This fixes issues with pronoun resolution finding the same message twice.
    while _session_history and _session_history[-1].get("content") == query and _session_history[-1].get("role") == "user":
        # Check if we have duplicates of this exact query at the end
        if len(_session_history) >= 2 and _session_history[-2].get("content") == query and _session_history[-2].get("role") == "user":
            _session_history.pop()  # Remove the duplicate
        else:
            break

    # -------------------------------------------------------------------------
    # STORE INTENT
    # -------------------------------------------------------------------------
    if intent == "STORE":
        # Check for CORRECTIONS first - "actually", "made a mistake", "changed my mind"
        # These need to UPDATE existing values, not just store new ones
        correction_keywords = ["actually", "made a mistake", "changed my mind", "i was wrong"]
        is_correction = any(kw in query_lower for kw in correction_keywords)

        if is_correction:
            # Handle opinion corrections FIRST: "Actually, I hate pizza", "Actually I love sushi"
            # This must come before the generic handler to properly update opinions
            opinion_correction = re.search(r"actually[,]?\s+i\s+(hate|dislike|love|like|don't like|can't stand)\s+(.+?)(?:\.|$)", query_lower)
            if opinion_correction:
                sentiment_word = opinion_correction.group(1)
                subject = opinion_correction.group(2).strip()
                if subject:
                    # Initialize caches if needed
                    if "opinions" not in _user_attributes_cache:
                        _user_attributes_cache["opinions"] = {}
                    if "likes" not in _user_attributes_cache:
                        _user_attributes_cache["likes"] = []
                    if "dislikes" not in _user_attributes_cache:
                        _user_attributes_cache["dislikes"] = []

                    # Determine sentiment and update accordingly
                    if sentiment_word in ["hate", "dislike", "don't like", "can't stand"]:
                        # Add to dislikes, remove from likes
                        if subject not in _user_attributes_cache["dislikes"]:
                            _user_attributes_cache["dislikes"].append(subject)
                        if subject in _user_attributes_cache["likes"]:
                            _user_attributes_cache["likes"].remove(subject)
                        _user_attributes_cache["opinions"][subject] = {"sentiment": "dislike", "turn": len(_session_history)}
                        _session_history.append({"role": "user", "content": query})
                        return f"Got it! I've updated your opinion - you dislike {subject}."
                    else:  # love, like
                        # Add to likes, remove from dislikes
                        if subject not in _user_attributes_cache["likes"]:
                            _user_attributes_cache["likes"].append(subject)
                        if subject in _user_attributes_cache["dislikes"]:
                            _user_attributes_cache["dislikes"].remove(subject)
                        _user_attributes_cache["opinions"][subject] = {"sentiment": "like", "turn": len(_session_history)}
                        _session_history.append({"role": "user", "content": query})
                        return f"Got it! I've updated your opinion - you like {subject}."

            # Handle birthday correction
            birthday_correction = re.search(r"birthday\s+is\s+actually\s+(.+?)(?:\.|$)", query_lower)
            if birthday_correction:
                new_date = _format_date(birthday_correction.group(1).strip())
                _user_attributes_cache["my_birthday"] = new_date
                # Update remembered facts
                _remembered_facts[:] = [f for f in _remembered_facts if "birthday" not in f.lower()]
                _remembered_facts.append(f"My birthday is {new_date}")
                _session_history.append({"role": "user", "content": query})
                return f"Got it! Your birthday is now {new_date}."

            # CCS-24 FIX: Handle Earth moon correction - "Actually wait, I was wrong. Earth has 1 moon"
            moon_correction = re.search(r"(?:the\s+)?earth\s+has\s+(\d+)\s+moons?", query_lower)
            if moon_correction:
                num_moons = moon_correction.group(1)
                if "earth" not in _teaching_facts_cache:
                    _teaching_facts_cache["earth"] = {}
                _teaching_facts_cache["earth"]["moons"] = num_moons
                _session_history.append({"role": "user", "content": query})
                return f"Got it, you're correcting that - the Earth has {num_moons} moon{'s' if num_moons != '1' else ''}."

            # Handle generic "actually it's X" corrections
            value_correction = re.search(r"actually[,]?\s+(?:it(?:'s|s|\s+is)\s+)?(\w+)", query_lower)
            if value_correction:
                new_value = value_correction.group(1).strip()
                # Note: "i" is excluded to prevent "actually I hate X" from triggering this path
                if new_value not in ["that", "this", "it", "what", "so", "just", "the", "a", "i"]:
                    # Find what to update from session history
                    for turn in reversed(_session_history[-5:]):
                        if turn.get("role") != "user":
                            continue
                        content = turn.get("content", "").lower()
                        if "favorite color" in content or "favourite color" in content:
                            _user_attributes_cache["favorite_color"] = new_value.capitalize()
                            return f"Got it! Your favorite color is now {new_value.capitalize()}."
                        if "favorite food" in content or "favourite food" in content:
                            _user_attributes_cache["favorite_food"] = new_value.capitalize()
                            return f"Got it! Your favorite food is now {new_value.capitalize()}."
                        # Generic favorite
                        fav_match = re.search(r"favou?rite\s+(\w+)", content)
                        if fav_match:
                            fav_type = fav_match.group(1)
                            _user_attributes_cache[f"favorite_{fav_type}"] = new_value.capitalize()
                            return f"Got it! Your favorite {fav_type} is now {new_value.capitalize()}."
                    return f"I've noted that update."

        # Store user attributes
        stored = False

        # Double negation handling: "I'm not unhappy" = "I'm happy", "I'm not unsatisfied" = "I'm satisfied"
        double_neg_match = re.search(r"(?:i'm|i am)\s+not\s+(un\w+)\s+(?:with\s+)?(?:my\s+)?(\w+)?", query_lower)
        if double_neg_match:
            neg_word = double_neg_match.group(1)  # "unhappy", "unsatisfied"
            subject = double_neg_match.group(2) if double_neg_match.group(2) else "things"  # "job", "life"
            # Convert double negative to positive
            positive_word = neg_word[2:]  # Remove "un" prefix
            _user_attributes_cache[f"feeling_about_{subject}"] = positive_word
            _session_history.append({"role": "user", "content": query})
            return f"Got it! You're {positive_word} with your {subject}."

        # Age FIRST: "I'm X years old" or "I am X" - check BEFORE name to avoid "I'm 28" → name="28"
        age_match = re.search(r"(?:i'm|i am)\s+(\d+)(?:\s+years?\s+old)?", query_lower)
        if age_match:
            age = age_match.group(1)
            _user_attributes_cache["age"] = age
            stored = True
            # Don't return yet - continue to extract other facts from compound statement

        # Dietary preference: "I'm vegetarian", "I'm vegan", etc.
        dietary_terms = ["vegetarian", "vegan", "pescatarian", "flexitarian", "omnivore", "carnivore"]
        for diet in dietary_terms:
            if re.search(rf"(?:i'm|i am)\s+(?:a\s+)?{diet}", query_lower):
                _user_attributes_cache["dietary_preference"] = diet.capitalize()
                stored = True
                break

        # LOCATION UPDATE LOGIC - Handle "I moved" and location changes
        # CCS-17 FIX: Track both current location and future moves correctly
        # Test: NY → "I moved. I live in Boston now" → "I'm moving to Chicago"
        # Expected: current=Boston, future=Chicago

        # Detect "I moved" - this indicates the previous location is no longer current
        has_moved = re.search(r'i moved(?:\.|,|!|\s|$)', query_lower)

        # Location: "I live in X"
        loc_match = re.search(r"i live in ([^,.\n]+)", query_lower)
        if loc_match:
            location = loc_match.group(1).strip()
            # Remove temporal markers like "now", "currently", "today"
            temporal_markers = ["now", "currently", "today", "actually", "wait", "these days"]
            for marker in temporal_markers:
                location = re.sub(rf'\s*{marker}\s*$', '', location, flags=re.IGNORECASE)
                location = re.sub(rf'^\s*{marker}\s+', '', location, flags=re.IGNORECASE)
            location = location.strip().title()
            if location:  # Only store if we still have a location after cleaning
                # If user said "I moved", save the old location as previous
                if has_moved and _user_attributes_cache.get("location"):
                    _user_attributes_cache["previous_location"] = _user_attributes_cache["location"]
                _user_attributes_cache["location"] = location
                stored = True

        # Future location: "I'm moving to X" or "moving again to X" or "Actually I'm moving to X"
        # More flexible pattern that handles words before "I'm" like "Actually"
        moving_match = re.search(r"(?:i'm |i am |actually\s+i'm |actually\s+i am )?moving(?:\s+again)?(?:\s+next\s+\w+)?\s+to\s+([^,.\n]+)", query_lower)
        if moving_match:
            future_loc = moving_match.group(1).strip().title()
            # Clean up temporal markers
            for marker in ["Next Week", "Soon", "Tomorrow", "Next Month"]:
                future_loc = future_loc.replace(marker, "").strip()
            if future_loc:
                _user_attributes_cache["future_location"] = future_loc
                stored = True

        # Job: "I work as X", "I work in X", "I work at X" or "I'm a teacher/doctor/etc"
        # CCS-04 FIX: Also match "I work in finance", "I work at TechCorp"
        # CCS-09 FIX: Don't match stress/emotion patterns about jobs
        job_match = None
        job_preposition = "as a"  # Default preposition
        stress_patterns = ["stressed about", "anxious about", "worried about", "nervous about",
                          "job interview", "feeling stressed", "feeling anxious", "feeling worried",
                          "stressed about my job", "nervous about my job"]
        if not any(p in query_lower for p in stress_patterns):
            # CCS-04 FIX: Capture the preposition to use correct grammar
            job_match = re.search(r"i work (as|in|at)(?: a| an)?\s+([^,.\n]+)", query_lower)
            if job_match:
                job_preposition = job_match.group(1)  # as/in/at
                job = job_match.group(2).strip()
                _user_attributes_cache["job"] = job
                _user_attributes_cache["job_preposition"] = job_preposition
                stored = True
                job_match = True  # Mark as found
        if not job_match:
            # Also check "I'm a teacher", "I am a doctor", etc.
            profession_words = ["teacher", "doctor", "nurse", "engineer", "developer", "scientist",
                               "manager", "designer", "analyst", "consultant", "writer", "artist",
                               "chef", "lawyer", "accountant", "architect", "dentist", "pharmacist",
                               "professor", "student", "programmer", "pilot", "firefighter", "police",
                               "therapist", "counselor", "librarian", "journalist", "photographer",
                               "musician", "actor", "director", "producer", "editor", "researcher"]
            im_job_match = re.search(r"(?:i'm|i am)\s+(?:a |an )?(\w+)", query_lower)
            if im_job_match:
                potential_job = im_job_match.group(1).lower()
                if potential_job in profession_words:
                    _user_attributes_cache["job"] = potential_job
                    _user_attributes_cache["job_preposition"] = "as a"
                    stored = True

        # Pet: "I have a X named Y" or "a cat named Whiskers"
        pet_match = re.search(r"(?:i have a|a)\s+(cat|dog|pet|bird|fish)\s+named\s+(\w+)", query_lower)
        if pet_match:
            pet_type = pet_match.group(1)
            pet_name = pet_match.group(2).capitalize()
            _user_attributes_cache["pet_type"] = pet_type
            _user_attributes_cache["pet_name"] = pet_name
            stored = True

        # Name AFTER age: "My name is X" or "I'm X" (but only if X is not a number)
        name_match = re.search(r"(?:my name is|call me)\s+(\w+)", query_lower)
        if not name_match:
            # Only try "I'm X" pattern if we didn't already capture age
            if not age_match:
                im_match = re.search(r"^(?:i'm|i am)\s+(\w+)[\.\!\?]?$", query_lower)
                if im_match:
                    potential_name = im_match.group(1)
                    # Make sure it's not a number
                    if not potential_name.isdigit():
                        name_match = im_match

        if name_match:
            name = name_match.group(1).capitalize()
            # Use module-level _NOT_NAMES constant for validation
            if name.lower() not in _NOT_NAMES and not name.isdigit():
                _user_attributes_cache["name"] = name
                stored = True

        # Favorite: "My favorite X is Y"
        fav_match = re.search(r"(?:my\s+)?favou?rite\s+(\w+)\s+is\s+(\w+)", query_lower)
        if fav_match:
            fav_type = fav_match.group(1)
            fav_value = fav_match.group(2).capitalize()
            _user_attributes_cache[f"favorite_{fav_type}"] = fav_value
            stored = True

        # Dislikes: "I don't like X", "I hate X", "Actually, I hate X"
        # Also handles comma-separated lists: "I dislike X, Y, and Z"
        # Strip common prefixes like "actually" before matching
        # Stop at "but" to handle compound statements like "I hate X but I love Y"
        dislike_query = re.sub(r'^(?:actually[,]?\s*|wait[,]?\s*)', '', query_lower)
        dislike_match = re.search(r"i (?:don't|do not|don't|hate|dislike|can't stand)\s+(?:like\s+)?(.+?)(?:\s+but\s+|\.|$)", dislike_query)
        if dislike_match:
            dislike_str = dislike_match.group(1).strip()
            if dislike_str:
                if "dislikes" not in _user_attributes_cache:
                    _user_attributes_cache["dislikes"] = []
                if "opinions" not in _user_attributes_cache:
                    _user_attributes_cache["opinions"] = {}

                # Handle comma-separated lists: "X, Y, and Z" or "X and Y"
                # Split on ", " and " and " to get individual items
                items = re.split(r',\s*(?:and\s+)?|\s+and\s+', dislike_str)
                items = [item.strip() for item in items if item.strip()]

                stored_items = []
                for dislike in items:
                    if dislike not in _user_attributes_cache["dislikes"]:
                        _user_attributes_cache["dislikes"].append(dislike)
                        stored_items.append(dislike)
                    # OPINION CHANGE: If they now dislike something, remove from likes
                    if "likes" in _user_attributes_cache and dislike in _user_attributes_cache["likes"]:
                        _user_attributes_cache["likes"].remove(dislike)
                    # Track opinion with timestamp for "what's my opinion on X" queries
                    _user_attributes_cache["opinions"][dislike] = {"sentiment": "dislike", "turn": len(_session_history) if '_session_history' in globals() else 0}

                # Return confirmation with stored items
                _session_history.append({"role": "user", "content": query})
                if stored_items:
                    return f"Noted! I'll remember you don't like: {', '.join(stored_items)}."
                return "Got it, I've noted your dislikes."

        # Likes: "I really love X", "I love X", "I like X, Y, and Z"
        # Also handles comma-separated lists
        # Stop at "but" to handle compound statements like "I love X but I hate Y"
        like_match = re.search(r"i (?:really\s+)?(?:love|like|enjoy)\s+(.+?)(?:\s+but\s+|\.|$)", query_lower)
        if like_match:
            like_str = like_match.group(1).strip()
            if like_str:
                if "likes" not in _user_attributes_cache:
                    _user_attributes_cache["likes"] = []
                if "opinions" not in _user_attributes_cache:
                    _user_attributes_cache["opinions"] = {}

                # Handle comma-separated lists: "X, Y, and Z" or "X and Y"
                # Split on ", " and " and " to get individual items
                items = re.split(r',\s*(?:and\s+)?|\s+and\s+', like_str)
                items = [item.strip() for item in items if item.strip()]

                stored_items = []
                for like in items:
                    if like not in _user_attributes_cache["likes"]:
                        _user_attributes_cache["likes"].append(like)
                        stored_items.append(like)
                    # OPINION CHANGE: If they now like something, remove from dislikes
                    if "dislikes" in _user_attributes_cache and like in _user_attributes_cache["dislikes"]:
                        _user_attributes_cache["dislikes"].remove(like)
                    # Track opinion with timestamp
                    _user_attributes_cache["opinions"][like] = {"sentiment": "like", "turn": len(_session_history) if '_session_history' in globals() else 0}

                # Return confirmation with stored items
                _session_history.append({"role": "user", "content": query})
                if stored_items:
                    return f"Got it! I'll remember you like: {', '.join(stored_items)}."
                return "Noted! I've stored your likes."

        # Beliefs: "I believe X", "I think X is Y"
        # Store user beliefs separately from facts - they may be controversial/incorrect
        belief_match = re.search(r"i (?:believe|think)\s+(?:that\s+)?(.+?)(?:\.|$)", query_lower)
        if belief_match:
            belief_content = belief_match.group(1).strip()
            if belief_content and len(belief_content) > 3:
                if "beliefs" not in _user_attributes_cache:
                    _user_attributes_cache["beliefs"] = {}

                # Extract the topic from the belief for later recall
                # E.g., "the moon landing was faked" → topic: "moon landing"
                topic_keywords = ["moon landing", "earth is flat", "vaccines", "climate", "government", "alien", "conspiracy"]
                topic = None
                for kw in topic_keywords:
                    if kw in belief_content:
                        topic = kw
                        break
                if not topic:
                    # Use first few words as topic
                    words = belief_content.split()[:3]
                    topic = " ".join(words)

                _user_attributes_cache["beliefs"][topic] = belief_content
                _session_history.append({"role": "user", "content": query})
                return f"I've noted your belief: {belief_content}"

        # Third-party entity and relationship tracking
        # Pattern: "My friend Bob has a dog named Rex"
        friend_pet_match = re.search(r"my (?:friend|buddy|pal)\s+(\w+)\s+has\s+a\s+(cat|dog|pet|bird|fish)\s+named\s+(\w+)", query_lower)
        if friend_pet_match:
            friend_name = friend_pet_match.group(1).lower()
            pet_type = friend_pet_match.group(2)
            pet_name = friend_pet_match.group(3).lower()
            if friend_name not in _entity_cache:
                _entity_cache[friend_name] = {"type": "person", "owns": [], "relationships": {}}
            _entity_cache[friend_name]["owns"].append({"name": pet_name, "type": pet_type})
            _entity_cache[pet_name] = {"type": pet_type, "owner": friend_name}
            stored = True

        # Pattern: "Bob's sister Carol" or "Bob's sister Carol has..."
        sibling_match = re.search(r"(\w+)'s\s+(sister|brother)\s+(\w+)", query_lower)
        if sibling_match:
            person1 = sibling_match.group(1).lower()
            relation = sibling_match.group(2)
            person2 = sibling_match.group(3).lower()
            if person1 not in _entity_cache:
                _entity_cache[person1] = {"type": "person", "owns": [], "relationships": {}}
            if person2 not in _entity_cache:
                _entity_cache[person2] = {"type": "person", "owns": [], "relationships": {}}
            _entity_cache[person1]["relationships"][person2] = relation
            _entity_cache[person2]["relationships"][person1] = "sibling"
            _relationship_cache[(person1, person2)] = relation
            _relationship_cache[(person2, person1)] = "sibling"

            # Also check for pet ownership in same sentence
            pet_in_sibling = re.search(rf"{person2}\s+has\s+a\s+(cat|dog|pet|bird|fish)\s+named\s+(\w+)", query_lower)
            if pet_in_sibling:
                pet_type = pet_in_sibling.group(1)
                pet_name = pet_in_sibling.group(2).lower()
                _entity_cache[person2]["owns"].append({"name": pet_name, "type": pet_type})
                _entity_cache[pet_name] = {"type": pet_type, "owner": person2}
            stored = True

        # Pattern: "Carol's husband Dan" or spouse relationships
        spouse_match = re.search(r"(\w+)'s\s+(husband|wife|spouse|partner)\s+(\w+)", query_lower)
        if spouse_match:
            person1 = spouse_match.group(1).lower()
            relation = spouse_match.group(2)
            person2 = spouse_match.group(3).lower()
            if person1 not in _entity_cache:
                _entity_cache[person1] = {"type": "person", "owns": [], "relationships": {}}
            if person2 not in _entity_cache:
                _entity_cache[person2] = {"type": "person", "owns": [], "relationships": {}}
            inverse = "wife" if relation == "husband" else "husband" if relation == "wife" else "spouse"
            _entity_cache[person1]["relationships"][person2] = relation
            _entity_cache[person2]["relationships"][person1] = inverse
            _relationship_cache[(person1, person2)] = relation
            _relationship_cache[(person2, person1)] = inverse
            stored = True

        # Pattern: "X doesn't have any pets"
        no_pets_match = re.search(r"(\w+)\s+(?:doesn't|does not|don't)\s+have\s+(?:any\s+)?pets?", query_lower)
        if no_pets_match:
            person = no_pets_match.group(1).lower()
            if person not in _entity_cache:
                _entity_cache[person] = {"type": "person", "owns": [], "relationships": {}}
            _entity_cache[person]["no_pets"] = True
            stored = True

        # Pattern: "traveling with my sister Maria" or "I'll be traveling with Maria"
        travel_match = re.search(r"(?:i'll be\s+)?traveling\s+with\s+(?:my\s+)?(sister|brother|friend|spouse|wife|husband)?\s*(\w+)", query_lower)
        if travel_match:
            relation = travel_match.group(1)  # may be None
            companion_name = travel_match.group(2).capitalize()
            if companion_name.lower() not in _NOT_NAMES:
                _user_attributes_cache["travel_companion"] = companion_name
                if relation:
                    _user_attributes_cache["travel_companion_relation"] = relation
                _session_history.append({"role": "user", "content": query})
                if relation:
                    return f"Got it! You're traveling with your {relation} {companion_name}."
                return f"Got it! You're traveling with {companion_name}."

        # =========================================================================
        # PROJECT TRACKING - CCS-43 FIX: Handle multiple projects in one sentence
        # =========================================================================
        # Test: "Project A is a website, Project B is a mobile app, Project C is an API"
        # Must capture ALL projects, not just the first one

        # Pattern 1: "Project A is a website" (type)
        # Use findall to capture ALL matches in the sentence
        proj_type_matches = re.findall(r"project\s+([a-z])\s+is\s+(?:a\s+|an\s+)?(website|app|api|mobile app|backend|frontend)", query_lower)
        for match in proj_type_matches:
            proj_name = f"Project {match[0].upper()}"
            if proj_name not in _project_cache:
                _project_cache[proj_name] = {}
            _project_cache[proj_name]["type"] = match[1]
            stored = True

        # Pattern 2: "Project A uses React" or "A uses React" (tech)
        # Handle both with and without "Project" prefix
        tech_patterns = [
            r"project\s+([a-z])\s+uses\s+(react|vue|angular|flutter|fastapi|python|node|django|flask|rust|go|swift|kotlin)",
            r"\b([a-z])\s+uses\s+(react|vue|angular|flutter|fastapi|python|node|django|flask|rust|go|swift|kotlin)"
        ]
        for pattern in tech_patterns:
            tech_matches = re.findall(pattern, query_lower)
            for match in tech_matches:
                # Only accept single letter project names (A, B, C, etc.)
                if len(match[0]) == 1:
                    proj_name = f"Project {match[0].upper()}"
                    if proj_name not in _project_cache:
                        _project_cache[proj_name] = {}
                    _project_cache[proj_name]["tech"] = match[1].title()
                    stored = True

        # Pattern 3: "A is 60% done" or "A is 60% complete" (completion percentage)
        # Must handle comma-separated lists: "A is 60% done, B is 30% done, C is 80% done"
        completion_matches = re.findall(r"(?:project\s+)?([a-z])\s+is\s+(\d+)\s*%\s*(?:done|complete)?", query_lower)
        for match in completion_matches:
            if len(match[0]) == 1:  # Single letter project name
                proj_name = f"Project {match[0].upper()}"
                if proj_name not in _project_cache:
                    _project_cache[proj_name] = {}
                _project_cache[proj_name]["completion"] = int(match[1])
                stored = True

        # Pattern 4: "A's deadline is January" or "A's is January" (deadline)
        # Must handle: "A's deadline is January, B's is March, C's is December"
        deadline_matches = re.findall(r"([a-z])(?:'s)?\s+(?:deadline\s+)?(?:is\s+)(january|february|march|april|may|june|july|august|september|october|november|december|\w+day)", query_lower)
        for match in deadline_matches:
            if len(match[0]) == 1:  # Single letter project name
                proj_name = f"Project {match[0].upper()}"
                if proj_name not in _project_cache:
                    _project_cache[proj_name] = {}
                _project_cache[proj_name]["deadline"] = match[1].capitalize()
                stored = True

        # Pattern 5: Original single project patterns (fallback for simpler inputs)
        project_match = re.search(r"project\s+([a-z])\s+(?:is\s+(?:a\s+)?)?(\w+)", query_lower)
        if project_match and f"Project {project_match.group(1).upper()}" not in _project_cache:
            proj_name = f"Project {project_match.group(1).upper()}"
            proj_detail = project_match.group(2)

            if proj_name not in _project_cache:
                _project_cache[proj_name] = {}

            # Determine what type of info this is
            if "%" in query_lower or "complete" in query_lower or "done" in query_lower:
                pct_match = re.search(r'(\d+)\s*%', query_lower)
                if pct_match:
                    _project_cache[proj_name]["completion"] = int(pct_match.group(1))
            elif "deadline" in query_lower or "due" in query_lower:
                deadline_match = re.search(r'(?:deadline|due)(?:\s+is)?\s+(\w+)', query_lower)
                if deadline_match:
                    _project_cache[proj_name]["deadline"] = deadline_match.group(1).capitalize()
            elif any(tech in query_lower for tech in ["react", "vue", "angular", "python", "node", "django", "flask", "rust", "go", "flutter", "fastapi"]):
                tech_match = re.search(r'(react|vue|angular|python|node|django|flask|rust|go|flutter|fastapi)', query_lower)
                if tech_match:
                    _project_cache[proj_name]["tech"] = tech_match.group(1).title()
            elif any(ptype in query_lower for ptype in ["website", "app", "api", "mobile", "backend", "frontend"]):
                type_match = re.search(r'(website|app|api|mobile|backend|frontend)', query_lower)
                if type_match:
                    _project_cache[proj_name]["type"] = type_match.group(1)
            stored = True

        # If we stored any attributes, return a summary
        if stored:
            _persist_user_attributes_cache()
            _session_history.append({"role": "user", "content": query})
            # Build response based on what was stored
            parts = []
            if _user_attributes_cache.get("name"):
                parts.append(f"Your name is {_user_attributes_cache['name']}")
            if _user_attributes_cache.get("age"):
                parts.append(f"You are {_user_attributes_cache['age']} years old")
            if _user_attributes_cache.get("location"):
                parts.append(f"You live in {_user_attributes_cache['location']}")
            if _user_attributes_cache.get("job"):
                # CCS-04 FIX: Use correct preposition (as/in/at)
                job_prep = _user_attributes_cache.get("job_preposition", "as a")
                if job_prep == "in":
                    parts.append(f"You work in {_user_attributes_cache['job']}")
                elif job_prep == "at":
                    parts.append(f"You work at {_user_attributes_cache['job']}")
                else:
                    parts.append(f"You work as a {_user_attributes_cache['job']}")
            if _user_attributes_cache.get("pet_name"):
                parts.append(f"You have a {_user_attributes_cache.get('pet_type', 'pet')} named {_user_attributes_cache['pet_name']}")
            # CCS-04 FIX: Include dietary preference in acknowledgment
            if _user_attributes_cache.get("dietary_preference"):
                parts.append(f"You are {_user_attributes_cache['dietary_preference'].lower()}")
            if parts:
                return ". ".join(parts) + "."
            return "Got it! I've stored that information."

        # Meeting handling: "I have a meeting tomorrow", "meeting at 3pm", "with Sarah"
        meeting_match = re.search(r"(?:i have|i've got|got)\s+(?:a\s+)?meeting\s*(.*)$", query_lower)
        if meeting_match:
            meeting_info = meeting_match.group(1).strip() if meeting_match.group(1) else ""
            if "meeting" not in _user_attributes_cache:
                _user_attributes_cache["meeting"] = {}
            if meeting_info:
                _user_attributes_cache["meeting"]["when"] = meeting_info
            else:
                _user_attributes_cache["meeting"]["when"] = "tomorrow"
            _session_history.append({"role": "user", "content": query})
            return "You've got a meeting " + (_user_attributes_cache["meeting"]["when"] or "tomorrow") + ". Do you want to talk about what's on your agenda?"

        # Meeting time update: "the meeting is at 3pm"
        meeting_time_match = re.search(r"(?:the\s+)?meeting\s+is\s+at\s+(\d+(?::\d+)?(?:\s*[ap]m)?)", query_lower)
        if meeting_time_match:
            time = meeting_time_match.group(1).strip()
            if "meeting" not in _user_attributes_cache:
                _user_attributes_cache["meeting"] = {}
            _user_attributes_cache["meeting"]["time"] = time
            _session_history.append({"role": "user", "content": query})
            return f"Got it, the meeting is at {time}."

        # Meeting person: "it's with my boss Sarah", "with Sarah"
        meeting_person_match = re.search(r"(?:it's|it is|meeting is)\s+with\s+(?:my\s+)?(?:boss\s+)?(\w+)", query_lower)
        if meeting_person_match:
            person = meeting_person_match.group(1).strip().title()
            if "meeting" not in _user_attributes_cache:
                _user_attributes_cache["meeting"] = {}
            _user_attributes_cache["meeting"]["with"] = person
            _session_history.append({"role": "user", "content": query})
            return f"Got it, the meeting is with {person}."

        # C3-17b FIX: Hobby storage - "My hobby is painting"
        hobby_match = re.search(r"my hobby is\s+(\w+)", query_lower)
        if hobby_match:
            hobby = hobby_match.group(1).strip()
            _user_attributes_cache["hobby"] = hobby
            _remembered_facts.append(f"your hobby is {hobby}")
            _session_history.append({"role": "user", "content": query})
            return f"Got it! Your hobby is {hobby}."

        # CCS-24 FIX: Teaching facts storage - "The Earth has X moons"
        # Handle corrections: "Actually wait, I was wrong. Earth has 1 moon"
        moon_match = re.search(r"(?:the\s+)?earth\s+has\s+(\d+)\s+moons?", query_lower)
        if moon_match:
            num_moons = moon_match.group(1)
            is_correction = any(kw in query_lower for kw in ["i was wrong", "actually", "wait"])
            if "earth" not in _teaching_facts_cache:
                _teaching_facts_cache["earth"] = {}
            _teaching_facts_cache["earth"]["moons"] = num_moons
            _session_history.append({"role": "user", "content": query})
            if is_correction:
                return f"Got it, you're correcting that - the Earth has {num_moons} moon{'s' if num_moons != '1' else ''}."
            return f"I've noted that the Earth has {num_moons} moon{'s' if num_moons != '1' else ''}."

        # CCS-16 FIX: Family member facts - "My mom is Susan", "dad is Robert", etc.
        # Handle both single facts and multi-part statements
        family_patterns = [
            (r"my\s+(?:mom|mother)\s+is\s+(\w+)", "mom"),
            (r"my\s+(?:dad|father)\s+is\s+(\w+)", "dad"),
            (r"my\s+sister\s+(?:is\s+)?(?:named\s+)?(\w+)", "sister"),
            (r"my\s+brother\s+(?:is\s+)?(?:named\s+)?(\w+)", "brother"),
            (r"(?:^|\s)(?:mom|mother)\s+is\s+(\w+)", "mom"),
            (r"(?:^|\s)(?:dad|father)\s+is\s+(\w+)", "dad"),
            (r"(?:^|\s)sister\s+(?:is\s+)?(?:named\s+)?(\w+)", "sister"),
            (r"(?:^|\s)brother\s+(?:is\s+)?(?:named\s+)?(\w+)", "brother"),
        ]
        family_found = []
        for pattern, relation in family_patterns:
            match = re.search(pattern, query_lower)
            if match:
                name = match.group(1).capitalize()
                if name.lower() not in _NOT_NAMES and len(name) > 1:
                    _user_attributes_cache[f"family_{relation}"] = name
                    family_found.append(f"{relation}: {name}")

        if family_found:
            _session_history.append({"role": "user", "content": query})
            return "I've noted that."

        # CCS-16 FIX: Address parsing - "I live at 123 Oak Street in Portland"
        address_match = re.search(r"i\s+live\s+at\s+(.+?)(?:\s+in\s+(\w+))?(?:\.|$)", query_lower)
        if address_match:
            street = address_match.group(1).strip()
            city = address_match.group(2)
            # Capitalize properly
            street_parts = query[query_lower.find(street):query_lower.find(street)+len(street)]
            if city:
                city_proper = city.capitalize()
                _user_attributes_cache["address"] = f"{street_parts} in {city_proper}"
                _user_attributes_cache["location"] = city_proper
            else:
                _user_attributes_cache["address"] = street_parts
            _session_history.append({"role": "user", "content": query})
            return "I've noted your address."

        # CCS-16 FIX: Phone and email parsing
        phone_match = re.search(r"(?:my\s+)?phone\s*(?:number)?\s*(?:is)?\s*(\d{3}[-.]?\d{4}|\d{3}[-.]?\d{3}[-.]?\d{4})", query_lower)
        email_match = re.search(r"(?:my\s+)?email\s*(?:address)?\s*(?:is)?\s*(\S+@\S+\.\S+)", query_lower)

        contact_found = []
        if phone_match:
            _user_attributes_cache["phone"] = phone_match.group(1)
            contact_found.append("phone")
        if email_match:
            _user_attributes_cache["email"] = email_match.group(1)
            contact_found.append("email")

        if contact_found:
            _session_history.append({"role": "user", "content": query})
            return "I've noted your contact information."

        # CCS-16 FIX: Multiple pets parsing - "My dog is Max, my cat is Luna"
        pet_patterns = [
            (r"my\s+(dog|cat|fish|bird|hamster|rabbit|turtle|parrot)\s+(?:is\s+)?(?:named\s+)?(\w+)", None),
            (r"(dog|cat|fish|bird|hamster|rabbit|turtle|parrot)\s+(?:is\s+)?(?:named\s+)?(\w+)", None),
        ]
        pets_found = []
        for pattern, _ in pet_patterns:
            for match in re.finditer(pattern, query_lower):
                pet_type = match.group(1)
                pet_name = match.group(2).capitalize()
                if pet_name.lower() not in _NOT_NAMES and len(pet_name) > 1 and pet_name.lower() not in ["is", "named", "and", "my"]:
                    pets_found.append((pet_type, pet_name))

        if pets_found:
            if "pets" not in _user_attributes_cache:
                _user_attributes_cache["pets"] = []
            for pet_type, pet_name in pets_found:
                # Avoid duplicates
                if (pet_type, pet_name) not in _user_attributes_cache["pets"]:
                    _user_attributes_cache["pets"].append((pet_type, pet_name))
            _session_history.append({"role": "user", "content": query})
            return "I've noted your pets."

        # Generic "remember" command - store as opaque fact
        # Handle patterns: "remember that X", "remember this: X", "remember: X", "please remember: X"
        remember_match = re.search(r"(?:please\s+)?(?:remember|store|note)\s*(?:that\s+|this\s*[:\s]+|[:\s]+)?(.+)", query, re.IGNORECASE)
        if remember_match:
            fact = remember_match.group(1).strip().rstrip('.')
            if fact:
                # Special case: "this code: XYZ" - extract just the code
                code_match = re.search(r"^(?:this\s+)?code\s*:\s*(.+)$", fact, re.IGNORECASE)
                if code_match:
                    code_value = code_match.group(1).strip()
                    _remembered_facts.append(code_value)
                    _session_history.append({"role": "user", "content": query})
                    return f"Got it! I'll remember the code: {code_value}"

                # Check if fact contains "My X is Y" pattern - also store in cache
                my_item_match = re.search(r"my (\w+) is (?:a |an )?(.+)", fact, re.IGNORECASE)
                if my_item_match:
                    item = my_item_match.group(1).lower()
                    description = my_item_match.group(2).strip().rstrip('.')
                    _user_attributes_cache[f"my_{item}"] = description
                    _remembered_facts.append(f"My {item} is {description}")
                    _session_history.append({"role": "user", "content": query})
                    return f"Got it! Your {item} is {description}."

                # Check if this contains multiple facts separated by commas
                # e.g. "Project Alpha is due Monday, Project Beta is due Wednesday"
                if "," in fact and "is due" in fact.lower():
                    # Parse multiple project deadlines
                    parts = [p.strip() for p in fact.split(",")]
                    for part in parts:
                        if part:
                            _remembered_facts.append(part)
                    _session_history.append({"role": "user", "content": query})
                    return f"Got it! I'll remember that: {fact}"
                else:
                    _remembered_facts.append(fact)
                    _session_history.append({"role": "user", "content": query})
                    return f"Got it! I'll remember that: {fact}"

        # Handle "My car is a blue Tesla Model 3" type statements (standalone, not after "remember:")
        my_item_match = re.search(r"^my (\w+) is (?:a |an )?(.+)$", query, re.IGNORECASE)
        if my_item_match:
            item = my_item_match.group(1).lower()
            description = my_item_match.group(2).strip().rstrip('.')
            _user_attributes_cache[f"my_{item}"] = description
            _remembered_facts.append(f"My {item} is {description}")
            _session_history.append({"role": "user", "content": query})
            return f"Got it! Your {item} is {description}."

        # Fallback for store - still store in session history
        _session_history.append({"role": "user", "content": query})
        return "I've noted that."

    # -------------------------------------------------------------------------
    # RECALL INTENT
    # -------------------------------------------------------------------------
    if intent == "RECALL":
        # Name recall
        # Travel companion recall - check BEFORE "who am i" since it's a more specific match
        if "traveling with" in query_lower or "travel with" in query_lower:
            companion = _user_attributes_cache.get("travel_companion")
            relation = _user_attributes_cache.get("travel_companion_relation")
            if companion:
                if relation:
                    return f"You're traveling with your {relation} {companion}."
                return f"You're traveling with {companion}."
            # Search session history for travel companion
            for turn in reversed(_session_history):
                if turn.get("role") == "user":
                    content = turn.get("content", "").lower()
                    match = re.search(r"(?:traveling|travel)\s+with\s+(?:my\s+)?(sister|brother|friend|spouse|wife|husband)?\s*(\w+)", content)
                    if match:
                        rel = match.group(1)
                        name = match.group(2).capitalize()
                        if name.lower() not in _NOT_NAMES:
                            _user_attributes_cache["travel_companion"] = name
                            if rel:
                                _user_attributes_cache["travel_companion_relation"] = rel
                                return f"You're traveling with your {rel} {name}."
                            return f"You're traveling with {name}."
            return "I don't have information about who you're traveling with."

        # Name recall
        if any(p in query_lower for p in ["my name", "who am i"]):
            if _user_attributes_cache.get("name"):
                return f"Your name is {_user_attributes_cache['name']}."
            # Search session history - MUST validate against _NOT_NAMES
            for turn in reversed(_session_history):
                if turn.get("role") == "user":
                    content = turn.get("content", "").lower()
                    match = re.search(r"(?:my name is|i'm|i am|call me)\s+(\w+)", content)
                    if match:
                        potential_name = match.group(1).lower()
                        # CRITICAL: Validate against _NOT_NAMES
                        if potential_name not in _NOT_NAMES and not potential_name.isdigit():
                            name = potential_name.capitalize()
                            _user_attributes_cache["name"] = name
                            return f"Your name is {name}."
            return "I don't have your name stored yet."

        # Age recall
        if any(p in query_lower for p in ["my age", "how old"]):
            if _user_attributes_cache.get("age"):
                return f"You are {_user_attributes_cache['age']} years old."
            return "I don't have your age stored."

        # Location recall - also handles "where do I live now and where am I moving"
        if any(p in query_lower for p in ["where do i live", "my location"]):
            current_loc = _user_attributes_cache.get("location")
            future_loc = _user_attributes_cache.get("future_location")

            # Check if asking about both current and future
            if "moving" in query_lower or "and where" in query_lower:
                if current_loc and future_loc:
                    return f"You currently live in {current_loc} and you're moving to {future_loc}."
                elif current_loc:
                    return f"You live in {current_loc}."
                elif future_loc:
                    return f"You're moving to {future_loc}."
            elif current_loc:
                if future_loc:
                    return f"You live in {current_loc}, and you're moving to {future_loc}."
                return f"You live in {_user_attributes_cache['location']}."
            return "I don't have your location stored."

        # Moving/future location specific recall
        if any(p in query_lower for p in ["where am i moving", "moving to", "future location"]):
            future_loc = _user_attributes_cache.get("future_location")
            if future_loc:
                return f"You're moving to {future_loc}."
            return "I don't have information about where you're moving."

        # Feeling/sentiment recall - "am I happy with my job", "how do I feel about X"
        # Must come BEFORE job recall since query may contain "my job"
        feeling_match = re.search(r"(?:am i|do i feel)\s+(\w+)\s+(?:or\s+\w+\s+)?(?:with|about)\s+(?:my\s+)?(\w+)", query_lower)
        if feeling_match or ("happy" in query_lower and "unhappy" in query_lower):
            subject = feeling_match.group(2) if feeling_match else "job"
            feeling_key = f"feeling_about_{subject}"
            if _user_attributes_cache.get(feeling_key):
                feeling = _user_attributes_cache[feeling_key]
                return f"Based on what you said, you're {feeling} with your {subject}."
            return f"I don't have information about how you feel about your {subject}."

        # Job recall
        if any(p in query_lower for p in ["my job", "what do i do", "my work", "my occupation"]):
            if _user_attributes_cache.get("job"):
                # CCS-04 FIX: Use correct preposition
                job_prep = _user_attributes_cache.get("job_preposition", "as a")
                if job_prep == "in":
                    return f"You work in {_user_attributes_cache['job']}."
                elif job_prep == "at":
                    return f"You work at {_user_attributes_cache['job']}."
                return f"You work as a {_user_attributes_cache['job']}."
            return "I don't have your job stored."

        # CCS-24 FIX: Teaching facts recall - "How many moons does Earth have?"
        if "how many" in query_lower and "moon" in query_lower and "earth" in query_lower:
            if "earth" in _teaching_facts_cache and "moons" in _teaching_facts_cache["earth"]:
                num_moons = _teaching_facts_cache["earth"]["moons"]
                return f"Based on what you told me, the Earth has {num_moons} moon{'s' if num_moons != '1' else ''}."
            return "I don't have that information stored about Earth's moons."

        # Meeting recall: "when is my meeting", "who is my meeting with"
        if "meeting" in query_lower and any(p in query_lower for p in ["when", "who", "what time"]):
            meeting = _user_attributes_cache.get("meeting", {})
            if meeting:
                parts = []
                if meeting.get("time"):
                    parts.append(f"at {meeting['time']}")
                elif meeting.get("when"):
                    parts.append(meeting["when"])
                if meeting.get("with"):
                    parts.append(f"with {meeting['with']}")
                if parts:
                    return f"Your meeting is {' '.join(parts)}."
            return "I don't have details about your meeting stored."

        # Favorite recall
        fav_match = re.search(r"(?:my\s+)?favou?rite\s+(\w+)", query_lower)
        if fav_match:
            fav_type = fav_match.group(1)
            key = f"favorite_{fav_type}"
            if _user_attributes_cache.get(key):
                return f"Your favorite {fav_type} is {_user_attributes_cache[key]}."
            return f"I don't have your favorite {fav_type} stored."

        # Selective category recall: "What are my dislikes?", "What are my likes?", "dislikes only"
        if any(p in query_lower for p in ["my dislikes", "dislikes only", "what do i dislike", "things i dislike", "things i hate", "what i don't like"]):
            if _user_attributes_cache.get("dislikes"):
                dislikes = _user_attributes_cache["dislikes"]
                return f"Your dislikes include: {', '.join(dislikes)}."
            return "I don't have any dislikes stored for you."

        if any(p in query_lower for p in ["my likes", "likes only", "what do i like", "things i like", "things i love", "what i like"]):
            if _user_attributes_cache.get("likes"):
                likes = _user_attributes_cache["likes"]
                return f"Your likes include: {', '.join(likes)}."
            return "I don't have any likes stored for you."

        # Opinion recall: "What's my opinion on pizza?", "What do I think about X?", "Wait, what's my opinion?"
        # Handle "wait," and similar prefixes
        query_clean = re.sub(r'^(?:wait[,]?\s*|oh[,]?\s*|um[,]?\s*|so[,]?\s*)', '', query_lower).strip()
        opinion_match = re.search(r"(?:what(?:'s| is)? my opinion (?:on|about)|what do i think (?:of|about)|how do i feel about)\s+(.+?)[\?]?$", query_clean)
        if opinion_match:
            subject = opinion_match.group(1).strip().rstrip('?')
            # CCS-12 FIX: Check for contradiction - look in session history for conflicting opinions
            contradiction_detected = False
            original_sentiment = None
            if '_session_history' in globals() and _session_history:
                for turn in _session_history:
                    if turn.get("role") == "user":
                        content = turn.get("content", "").lower()
                        if subject in content:
                            if any(w in content for w in ["love", "like", "enjoy"]) and not any(w in content for w in ["don't", "hate", "dislike"]):
                                if original_sentiment is None:
                                    original_sentiment = "like"
                                elif original_sentiment == "dislike":
                                    contradiction_detected = True
                            elif any(w in content for w in ["hate", "dislike", "don't like"]):
                                if original_sentiment is None:
                                    original_sentiment = "dislike"
                                elif original_sentiment == "like":
                                    contradiction_detected = True
            # Check opinions dictionary first (tracks most recent sentiment)
            if _user_attributes_cache.get("opinions") and subject in _user_attributes_cache["opinions"]:
                opinion_data = _user_attributes_cache["opinions"][subject]
                sentiment = opinion_data["sentiment"]
                # CCS-12 FIX: Acknowledge contradiction if detected
                if contradiction_detected:
                    if sentiment == "like":
                        return f"You changed your mind - you now like {subject} (you previously said you disliked it)."
                    elif sentiment == "dislike":
                        return f"You changed your mind - you now dislike {subject} (you previously said you liked it)."
                if sentiment == "like":
                    return f"You like {subject}."
                elif sentiment == "dislike":
                    return f"You dislike {subject}."
            # Fallback: check likes/dislikes lists
            if "likes" in _user_attributes_cache and subject in _user_attributes_cache["likes"]:
                return f"You like {subject}."
            if "dislikes" in _user_attributes_cache and subject in _user_attributes_cache["dislikes"]:
                return f"You dislike {subject}."
            return f"I don't have information about your opinion on {subject}."

        # Belief recall: "What do I believe about X?", "What do I think about the moon landing?"
        belief_query_match = re.search(r"what\s+do\s+i\s+(?:believe|think)\s+(?:about|regarding)?\s*(.+?)[\?]?$", query_clean)
        if belief_query_match:
            belief_topic = belief_query_match.group(1).strip().rstrip('?').lower()
            if _user_attributes_cache.get("beliefs"):
                # Search for matching belief
                for topic, belief in _user_attributes_cache["beliefs"].items():
                    if belief_topic in topic or topic in belief_topic:
                        return f"You believe that {belief}."
                # Partial match on belief content
                for topic, belief in _user_attributes_cache["beliefs"].items():
                    if belief_topic in belief:
                        return f"You believe that {belief}."
            return f"I don't have any beliefs stored about {belief_topic}."

        # Entity ownership recall: "Who owns Rex?", "Who owns Whiskers?"
        owns_match = re.search(r"who owns (\w+)", query_lower)
        if owns_match:
            entity_name = owns_match.group(1).lower()
            if entity_name in _entity_cache:
                entity = _entity_cache[entity_name]
                if "owner" in entity:
                    owner = entity["owner"].title()
                    return f"{entity_name.title()} is owned by {owner}."
            return f"I don't have information about who owns {entity_name.title()}."

        # Relationship recall: "What's the relationship between Bob and Carol?"
        rel_match = re.search(r"(?:what's|what is) the relationship between (\w+) and (\w+)", query_lower)
        if rel_match:
            person1 = rel_match.group(1).lower()
            person2 = rel_match.group(2).lower()
            if (person1, person2) in _relationship_cache:
                relation = _relationship_cache[(person1, person2)]
                return f"{person1.title()} and {person2.title()} are {relation}s." if relation in ["sibling", "spouse"] else f"{person2.title()} is {person1.title()}'s {relation}."
            # Check if stored in entity cache
            if person1 in _entity_cache and person2 in _entity_cache.get(person1, {}).get("relationships", {}):
                relation = _entity_cache[person1]["relationships"][person2]
                return f"{person2.title()} is {person1.title()}'s {relation}."
            return f"I don't have information about the relationship between {person1.title()} and {person2.title()}."

        # C3-EXT-25 FIX: Bank homonym disambiguation - "What kind of bank did I visit?"
        if "what kind of bank" in query_lower or "which bank" in query_lower or "type of bank" in query_lower:
            # Look for contextual clues in session history
            if '_session_history' in globals() and _session_history:
                financial_clues = ["deposit", "withdraw", "money", "account", "cash", "check", "cheque", "atm", "transfer"]
                river_clues = ["fish", "fishing", "river", "swim", "water", "boat", "rowing"]
                for turn in _session_history:
                    if turn.get("role") == "user":
                        content = turn.get("content", "").lower()
                        if any(clue in content for clue in financial_clues):
                            return "Based on the context (you mentioned depositing money), you visited a financial bank."
                        if any(clue in content for clue in river_clues):
                            return "Based on the context, you were at a river bank."
            return "I'm not sure which type of bank you mean. Was it a financial bank or a river bank?"

        # Pet ownership check: "Does Dan have pets?"
        has_pets_match = re.search(r"does (\w+) have (?:any\s+)?pets?", query_lower)
        if has_pets_match:
            person = has_pets_match.group(1).lower()
            if person in _entity_cache:
                entity = _entity_cache[person]
                if entity.get("no_pets"):
                    return f"No, {person.title()} doesn't have any pets."
                if entity.get("owns"):
                    pets = [f"{p['name'].title()} (a {p['type']})" for p in entity["owns"]]
                    return f"Yes, {person.title()} has: {', '.join(pets)}."
            return f"I don't have information about {person.title()}'s pets."

        # Project tracking recall: "Which project is closest to completion?", "What tech does Project B use?"
        if "closest to completion" in query_lower or "most complete" in query_lower:
            if _project_cache:
                # Find project with highest completion percentage
                best_proj = None
                best_pct = -1
                for proj_name, proj_data in _project_cache.items():
                    pct = proj_data.get("completion", 0)
                    if pct > best_pct:
                        best_pct = pct
                        best_proj = proj_name
                if best_proj and best_pct >= 0:
                    return f"{best_proj} is closest to completion at {best_pct}%."
            return "I don't have completion information for any projects."

        # "What tech does Project X use?"
        tech_query_match = re.search(r"what\s+(?:tech|technology)\s+does\s+project\s+([a-z])\s+use", query_lower)
        if tech_query_match:
            proj_name = f"Project {tech_query_match.group(1).upper()}"
            if proj_name in _project_cache and "tech" in _project_cache[proj_name]:
                return f"{proj_name} uses {_project_cache[proj_name]['tech']}."
            return f"I don't have technology information for {proj_name}."

        # "Tell me about Project X" or "What do you know about Project X?"
        project_info_match = re.search(r"(?:tell me about|what do you know about|info on)\s+project\s+([a-z])", query_lower)
        if project_info_match:
            proj_name = f"Project {project_info_match.group(1).upper()}"
            if proj_name in _project_cache:
                info_parts = []
                proj_data = _project_cache[proj_name]
                if "type" in proj_data:
                    info_parts.append(f"It's a {proj_data['type']}")
                if "tech" in proj_data:
                    info_parts.append(f"uses {proj_data['tech']}")
                if "completion" in proj_data:
                    info_parts.append(f"is {proj_data['completion']}% complete")
                if "deadline" in proj_data:
                    info_parts.append(f"deadline is {proj_data['deadline']}")
                if info_parts:
                    return f"{proj_name}: {', '.join(info_parts)}."
            return f"I don't have information stored about {proj_name}."

        # Project/deadline recall - check BEFORE generic fact recall
        # This must come first or "project" / "due" will match generic handler
        deadline_match = re.search(r"when is (\w+(?:\s+\w+)?)\s+due", query_lower)
        if deadline_match or ("when is" in query_lower and "due" in query_lower):
            project_name = deadline_match.group(1) if deadline_match else None

            # If we have a specific project name, search for exact match
            if project_name:
                project_key = project_name.lower()
                for fact in _remembered_facts:
                    fact_lower = fact.lower()
                    if project_key in fact_lower:
                        # Extract the day from "X is due Monday"
                        due_match_inner = re.search(r"is due (\w+)", fact_lower)
                        if due_match_inner:
                            day = due_match_inner.group(1).capitalize()
                            return f"{project_name.title()} is due {day}."
                        return f"Based on what you mentioned: {fact}"
                return f"I don't have information about when {project_name} is due."

            # Generic deadline search (no specific project)
            for fact in reversed(_remembered_facts):
                fact_lower = fact.lower()
                if "due" in fact_lower:
                    return f"Based on what you mentioned: {fact}"
            return "I don't have that deadline information stored."

        # Attribute recall from stored facts (color, brand, model) - BEFORE generic
        attr_match = re.search(r"what\s+(?:color|brand|model|make)\s+is\s+my\s+(\w+)", query_lower)
        if attr_match:
            item = attr_match.group(1)
            # Check user_attributes_cache first
            cache_key = f"my_{item}"
            if cache_key in _user_attributes_cache:
                description = _user_attributes_cache[cache_key]
                # Extract specific attribute
                if "color" in query_lower:
                    # Look for color words in description
                    color_words = ["red", "blue", "green", "yellow", "black", "white", "silver", "gray", "grey", "orange", "purple", "pink", "brown"]
                    for color in color_words:
                        if color in description.lower():
                            return f"Your {item} is {color}."
                elif "brand" in query_lower:
                    # First word is often brand (skip colors)
                    color_words_set = {"red", "blue", "green", "yellow", "black", "white", "silver", "gray", "grey", "orange", "purple", "pink", "brown"}
                    words = description.split()
                    for w in words:
                        if w.lower() not in ["a", "an", "the"] and w.lower() not in color_words_set:
                            return f"Your {item} is a {w}."
                elif "model" in query_lower:
                    # Look for model pattern - last part like "Model 3", "X5"
                    words = description.split()
                    if len(words) >= 2:
                        return f"Your {item} is a {' '.join(words[-2:])}."
                return f"Based on what you mentioned, your {item} is {description}."
            # Fallback to searching remembered facts
            for fact in reversed(_remembered_facts):
                if item in fact.lower():
                    return f"Based on what you mentioned: {fact}"
            return f"I don't have information about your {item} stored."

        # Generic stored fact recall (including "what was the code")
        if _remembered_facts:
            # Search for matching fact
            q_words = [w.strip("?.,!") for w in query_lower.split() if len(w) > 2]
            common_words = {"the", "what", "was", "is", "my", "you", "did", "tell", "say", "when", "project", "due", "color", "brand", "model", "car"}
            q_words = [w for w in q_words if w not in common_words]

            # Only match if we have meaningful query words left
            if q_words:
                for fact in reversed(_remembered_facts):
                    fact_lower = fact.lower()
                    matches = sum(1 for w in q_words if w in fact_lower)
                    if matches >= 1:
                        return f"You mentioned: {fact}"

        # "Create a brief profile of me" - generate user profile summary
        if any(p in query_lower for p in ["create a profile", "create profile", "brief profile", "profile of me", "summarize me", "summary of me"]):
            profile_parts = []
            if _user_attributes_cache.get("name"):
                profile_parts.append(f"Name: {_user_attributes_cache['name']}")
            if _user_attributes_cache.get("age"):
                profile_parts.append(f"Age: {_user_attributes_cache['age']}")
            if _user_attributes_cache.get("location"):
                profile_parts.append(f"Location: {_user_attributes_cache['location']}")
            if _user_attributes_cache.get("job"):
                profile_parts.append(f"Occupation: {_user_attributes_cache['job']}")
            if _user_attributes_cache.get("pet_name"):
                pet_type = _user_attributes_cache.get("pet_type", "pet")
                profile_parts.append(f"Pet: {pet_type.capitalize()} named {_user_attributes_cache['pet_name']}")
            for key, val in _user_attributes_cache.items():
                if key.startswith("favorite_"):
                    fav_type = key.replace("favorite_", "")
                    profile_parts.append(f"Favorite {fav_type}: {val}")
            if _user_attributes_cache.get("likes"):
                profile_parts.append(f"Likes: {', '.join(_user_attributes_cache['likes'])}")
            if _user_attributes_cache.get("dislikes"):
                profile_parts.append(f"Dislikes: {', '.join(_user_attributes_cache['dislikes'])}")

            if profile_parts:
                return "**Your Profile:**\n" + "\n".join(f"- {p}" for p in profile_parts)
            return "I don't have enough information to create a profile yet. Tell me about yourself!"

        # C3-17b FIX: "What did you learn from that?" - report the last thing stored
        if "learn from that" in query_lower or "learned from that" in query_lower:
            # Report what was just stored from the previous turn
            if _remembered_facts:
                return f"I learned that {_remembered_facts[-1].lower()}."
            # Check session history for what was just said
            if len(_session_history) >= 2:
                for turn in reversed(_session_history[:-1]):
                    if turn.get("role") == "user":
                        content = turn.get("content", "")
                        # Extract fact from common patterns
                        hobby_match = re.search(r"my hobby is (\w+)", content.lower())
                        if hobby_match:
                            return f"I learned that your hobby is {hobby_match.group(1)}."
                        name_match = re.search(r"(?:my name is|i'm|i am) (\w+)", content.lower())
                        if name_match:
                            return f"I learned that your name is {name_match.group(1).title()}."
                        break
            return "I learned what you just told me."

        # "What do you know about me" / "Summarize everything you know about me" - aggregate
        # CCS-04 FIX: Also match "summarize everything you know about me", "list everything"
        # C3-17 FIX: Also match "learn" (not just "learned") for "what did you learn"
        if "know about me" in query_lower or "learned" in query_lower or "learn" in query_lower or "stored" in query_lower or "summarize everything" in query_lower or "list everything" in query_lower:
            facts = []
            if _user_attributes_cache.get("name"):
                facts.append(f"Your name is {_user_attributes_cache['name']}")
            if _user_attributes_cache.get("age"):
                facts.append(f"You are {_user_attributes_cache['age']} years old")
            if _user_attributes_cache.get("location"):
                facts.append(f"You live in {_user_attributes_cache['location']}")
            if _user_attributes_cache.get("job"):
                # CCS-04 FIX: Use correct preposition
                job_prep = _user_attributes_cache.get("job_preposition", "as a")
                if job_prep == "in":
                    facts.append(f"You work in {_user_attributes_cache['job']}")
                elif job_prep == "at":
                    facts.append(f"You work at {_user_attributes_cache['job']}")
                else:
                    facts.append(f"You work as a {_user_attributes_cache['job']}")
            if _user_attributes_cache.get("pet_name"):
                pet_type = _user_attributes_cache.get("pet_type", "pet")
                facts.append(f"You have a {pet_type} named {_user_attributes_cache['pet_name']}")
            # CCS-04 FIX: Include dietary preference
            if _user_attributes_cache.get("dietary_preference"):
                facts.append(f"You are {_user_attributes_cache['dietary_preference'].lower()}")
            for key, val in _user_attributes_cache.items():
                if key.startswith("favorite_"):
                    fav_type = key.replace("favorite_", "")
                    facts.append(f"Your favorite {fav_type} is {val}")
            # CCS-16 FIX: Include family members
            if _user_attributes_cache.get("family_mom"):
                facts.append(f"Your mom is {_user_attributes_cache['family_mom']}")
            if _user_attributes_cache.get("family_dad"):
                facts.append(f"Your dad is {_user_attributes_cache['family_dad']}")
            if _user_attributes_cache.get("family_sister"):
                facts.append(f"Your sister is {_user_attributes_cache['family_sister']}")
            if _user_attributes_cache.get("family_brother"):
                facts.append(f"Your brother is {_user_attributes_cache['family_brother']}")
            # CCS-16 FIX: Include address
            if _user_attributes_cache.get("address"):
                facts.append(f"You live at {_user_attributes_cache['address']}")
            # CCS-16 FIX: Include phone and email
            if _user_attributes_cache.get("phone"):
                facts.append(f"Your phone is {_user_attributes_cache['phone']}")
            if _user_attributes_cache.get("email"):
                facts.append(f"Your email is {_user_attributes_cache['email']}")
            # CCS-16 FIX: Include multiple pets
            if _user_attributes_cache.get("pets"):
                for pet_type, pet_name in _user_attributes_cache["pets"]:
                    facts.append(f"You have a {pet_type} named {pet_name}")
            # Include likes
            if _user_attributes_cache.get("likes"):
                for like in _user_attributes_cache["likes"]:
                    facts.append(f"You like {like}")
            # Include dislikes
            if _user_attributes_cache.get("dislikes"):
                for dislike in _user_attributes_cache["dislikes"]:
                    facts.append(f"You don't like {dislike}")
            if _remembered_facts:
                for fact in _remembered_facts[:3]:
                    facts.append(f"You mentioned: {fact}")
            if facts:
                return "Here's what I know about you:\n- " + "\n- ".join(facts)
            return "I don't have much information stored about you yet."

        # "What was the code" / "What did I tell you" - generic fact recall
        if "code" in query_lower or "told you" in query_lower or "tell you" in query_lower or "just" in query_lower:
            # Look for most recent stored fact
            if _remembered_facts:
                return f"You mentioned: {_remembered_facts[-1]}"
            return "I don't have any stored information from you yet."

        # Fallback for recall
        return "I don't have that specific information stored."

    return None


def _normalize_query(query: str) -> str:
    """
    Normalize a query by fixing common typos and expanding abbreviations.
    This helps Maven understand user intent even with spelling errors.

    Args:
        query: The raw user query

    Returns:
        Normalized query with typos corrected and abbreviations expanded
    """
    normalized = query

    # Apply typo corrections (case insensitive)
    for pattern, replacement in TYPO_CORRECTIONS.items():
        normalized = re.sub(pattern, replacement, normalized, flags=re.IGNORECASE)

    # Apply abbreviation expansions (case insensitive)
    for pattern, replacement in ABBREVIATION_EXPANSIONS.items():
        normalized = re.sub(pattern, replacement, normalized, flags=re.IGNORECASE)

    return normalized


# =============================================================================
# FIX 1: INVERTED QUERY HANDLER LOGIC - FAST PATH FIRST
# =============================================================================
# This is the main entry point for user queries.
# Fast Path First - 95% of queries go straight to Teacher.
# GAP 1 FIX: Added fallback to existing pipeline.
# =============================================================================

def handle_user_query(user_query: str, context: Dict[str, Any]) -> str:
    """
    Main entry point for user queries.
    Priority:
    0. Capability check - block things Maven can't do (games, roleplay)
    1. Agency tools (time, browser, shell, git, etc.) - execute directly
    2. Knowledge queries - MUST check memory FIRST, no LLM hallucination
    3. Learning requests - CAN use LLM, store results in memory
    4. Fast path for normal conversation
    5. Full coordinator routing for complex queries

    ALL responses are quality-checked before returning to prevent hallucination.
    """
    response = None

    # =========================================================================
    # CRITICAL: ADD ALL USER QUERIES TO SESSION HISTORY FIRST
    # =========================================================================
    # This ensures pronoun resolution, syllogism reasoning, and context tracking work
    global _session_history
    if '_session_history' not in globals():
        _session_history = []
    # Add user query to session history at the START (for pronoun resolution, etc.)
    _session_history.append({"role": "user", "content": user_query})

    # P1: Normalize query - fix typos and expand abbreviations
    normalized_query = _normalize_query(user_query)
    query_lower = normalized_query.lower().strip()

    # Log if normalization changed the query (for debugging)
    if normalized_query != user_query:
        logger.debug(f"[NORMALIZE] '{user_query}' -> '{normalized_query}'")

    # =========================================================================
    # PRIORITY -3: TOPIC TRACKING - Track topics mentioned for later recall
    # =========================================================================
    global _topic_cache
    if '_topic_cache' not in globals():
        _topic_cache = []

    # Handle "For X, I want to Y" or "For X, I'm learning Y" patterns - store topic with context
    for_topic_match = re.search(r"for\s+(\w+),?\s+(?:i(?:'m)?|i\s+(?:want|am))\s+(?:to\s+)?(?:make|learn(?:ing)?|study(?:ing)?|do(?:ing)?|cook(?:ing)?|bake|build(?:ing)?)\s+(\w+)", query_lower)
    if for_topic_match:
        topic_area = for_topic_match.group(1).lower()
        topic_detail = for_topic_match.group(2).capitalize()
        # Map topic area to category
        if topic_area in ["cooking", "food", "baking"]:
            _topic_cache.append({"topic": "cooking", "category": "general", "detail": topic_detail, "turn": len(_topic_cache) + 1})
            logger.debug(f"[TOPIC_TRACK] Added for-pattern topic: cooking -> {topic_detail}")
        elif topic_area in ["programming", "coding", "code"]:
            _topic_cache.append({"topic": "programming", "category": "programming_language", "detail": topic_detail, "turn": len(_topic_cache) + 1})
            logger.debug(f"[TOPIC_TRACK] Added for-pattern topic: programming -> {topic_detail}")
        else:
            _topic_cache.append({"topic": topic_area, "category": "general", "detail": topic_detail, "turn": len(_topic_cache) + 1})
            logger.debug(f"[TOPIC_TRACK] Added for-pattern topic: {topic_area} -> {topic_detail}")

    # Track programming languages mentioned - use word boundaries to prevent partial matches
    # CCS-41 FIX: "java" was matching inside "javascript" - use word boundaries for all
    for lang in _PROGRAMMING_LANGUAGES:
        if len(lang) >= 3:
            # Use word boundary regex to prevent "java" matching in "javascript"
            pattern = rf"\b{re.escape(lang)}\b"
            if re.search(pattern, query_lower, re.IGNORECASE):
                if not _topic_cache or _topic_cache[-1].get("topic") != lang:
                    _topic_cache.append({"topic": lang, "category": "programming_language", "turn": len(_topic_cache) + 1})
                    logger.debug(f"[TOPIC_TRACK] Added topic: {lang}")

    # Track short language names with word boundaries to avoid false positives
    for lang, pattern in _SHORT_LANGUAGES.items():
        if re.search(pattern, query_lower, re.IGNORECASE):
            if not _topic_cache or _topic_cache[-1].get("topic") != lang:
                _topic_cache.append({"topic": lang, "category": "programming_language", "turn": len(_topic_cache) + 1})
                logger.debug(f"[TOPIC_TRACK] Added short lang topic: {lang}")

    # Track general topics for multi-topic conversations
    for topic, keywords in _GENERAL_TOPICS.items():
        for keyword in keywords:
            if keyword in query_lower:
                if not _topic_cache or _topic_cache[-1].get("topic") != topic:
                    _topic_cache.append({"topic": topic, "category": "general", "turn": len(_topic_cache) + 1})
                    logger.debug(f"[TOPIC_TRACK] Added general topic: {topic}")
                break  # Only add topic once per message

    # CCS-01 FIX: Track topics from "tell me about X" patterns
    tell_me_match = re.search(r"tell me about (\w+)", query_lower)
    if tell_me_match:
        topic = tell_me_match.group(1).lower()
        # Exclude pronouns and common filler words
        if topic not in ["you", "yourself", "me", "it", "that", "this", "the", "a", "an", "your"]:
            if not _topic_cache or _topic_cache[-1].get("topic") != topic:
                _topic_cache.append({"topic": topic, "category": "general", "turn": len(_topic_cache) + 1})
                logger.debug(f"[TOPIC_TRACK] Added 'tell me about' topic: {topic}")

    # =========================================================================
    # PRIORITY -2.5: TOPIC RECALL - Answer questions about mentioned topics
    # =========================================================================
    # Handle "what was the topic before X" type questions - CCS-01 FIX
    topic_before_match = re.search(r"(?:what|which)\s+(?:was\s+)?(?:the\s+)?topic\s+(?:before|prior\s+to)\s+(\w+)", query_lower)
    if topic_before_match:
        target_topic = topic_before_match.group(1).lower()
        if _topic_cache and len(_topic_cache) >= 2:
            # Find the topic mentioned before the target
            for i, t in enumerate(_topic_cache):
                topic_name = t["topic"].lower()
                # Normalize topic names
                if topic_name in ["car", "cars", "truck", "trucks", "vehicle", "vehicles"]:
                    topic_name = "cars"
                if topic_name == target_topic or target_topic in topic_name or topic_name in target_topic:
                    if i > 0:
                        prev_topic = _topic_cache[i-1]["topic"].capitalize()
                        return f"The topic before {target_topic} was {prev_topic}."
            return f"I don't recall what we discussed before {target_topic}."
        return "I don't recall our previous topics clearly."

    # Handle "what topics did we discuss in order" type questions
    if any(p in query_lower for p in ["topics we discussed", "topics did we discuss", "topics in order", "all the topics", "what were the topics"]):
        if _topic_cache:
            # Return unique topics in order they were first mentioned
            seen = set()
            topics_in_order = []
            for t in _topic_cache:
                topic_name = t["topic"].capitalize()
                # Consolidate related topics (food/cooking, programming/python/java/etc)
                if topic_name.lower() in ["food", "cooking", "baking"]:
                    topic_name = "Cooking"
                elif topic_name.lower() in ["programming", "code", "coding"] or t.get("category") == "programming_language":
                    topic_name = "Programming"
                if topic_name not in seen:
                    seen.add(topic_name)
                    topics_in_order.append(topic_name)
            return f"We discussed the following topics in order: {', '.join(topics_in_order)}"
        return "I don't recall us discussing any specific topics yet."

    # Handle "summarize both topics" or "summarize the topics" - provide context-aware summary
    if any(p in query_lower for p in ["summarize both", "summarize the topics", "summarize topics", "summary of topics"]):
        if _topic_cache:
            # Group topics into main categories, consolidating related ones
            cooking_details = []
            programming_details = []
            other_topics = []

            for t in _topic_cache:
                topic_name = t["topic"].lower()
                detail = t.get("detail", "")

                # Consolidate cooking-related topics
                if topic_name in ["food", "cooking", "baking", "pasta", "sauce"]:
                    if detail and detail not in cooking_details:
                        cooking_details.append(detail)
                # Consolidate programming-related topics
                elif topic_name in ["programming", "code", "coding"] or t.get("category") == "programming_language":
                    if topic_name not in ["programming", "code", "coding"] and topic_name.capitalize() not in programming_details:
                        programming_details.append(topic_name.capitalize())
                else:
                    if topic_name.capitalize() not in other_topics:
                        other_topics.append(topic_name.capitalize())

            summaries = []
            if cooking_details:
                summaries.append(f"Cooking: {', '.join(cooking_details)}")
            elif any(t["topic"].lower() in ["food", "cooking", "baking"] for t in _topic_cache):
                summaries.append("Cooking")

            if programming_details:
                summaries.append(f"Programming: {', '.join(programming_details)}")
            elif any(t.get("category") == "programming_language" for t in _topic_cache):
                summaries.append("Programming")

            summaries.extend(other_topics)

            if summaries:
                return f"We discussed: {', '.join(summaries)}."
        return "I don't have any topics to summarize."

    if any(p in query_lower for p in ["which programming language", "which languages did i", "which language did i mention", "programming languages did i", "languages did i just mention"]):
        prog_langs = [t["topic"] for t in _topic_cache if t.get("category") == "programming_language"]
        if prog_langs:
            return f"You mentioned: {', '.join(lang.capitalize() for lang in prog_langs)}"
        return "I don't recall you mentioning any programming languages in this conversation."

    # Handle single-word programming language mentions with context-aware responses
    # E.g., "Python." → "Got it, you mentioned Python."
    # E.g., "No wait, Java." → "Got it, switching to Java."
    query_stripped = query_lower.strip().rstrip('.!?')
    query_words = query_stripped.split()

    # Check for topic switches with prefix words
    switch_prefixes = ["no", "wait", "actually", "maybe", "hmm"]
    is_topic_switch = any(query_stripped.startswith(p) for p in switch_prefixes)

    # Common phrases with "go" that should NOT be interpreted as Go language
    # These are conversational phrases, not programming language references
    go_phrases = [
        "go on", "go ahead", "go back", "go to", "go for", "go with",
        "let's go", "lets go", "gotta go", "got to go", "have to go",
        "go away", "go home", "go there", "go here", "go out", "go in",
        "will go", "can go", "should go", "must go", "gonna go", "going to go",
        "don't go", "please go", "go now", "go later", "go first",
    ]
    is_go_phrase = any(phrase in query_stripped for phrase in go_phrases)

    # Check if it's a single programming language mention
    # CCS-41 FIX: Use word boundaries to prevent "java" matching in "javascript"
    prog_lang_mentioned = None
    for lang in _PROGRAMMING_LANGUAGES:
        pattern = rf"\b{re.escape(lang)}\b"
        if re.search(pattern, query_stripped, re.IGNORECASE):
            # Skip "go" if it's part of a common phrase
            if lang == "go" and is_go_phrase:
                continue
            prog_lang_mentioned = lang
            break
    if not prog_lang_mentioned:
        for lang, pattern in _SHORT_LANGUAGES.items():
            if re.search(pattern, query_stripped, re.IGNORECASE):
                # Skip "go" if it's part of a common phrase
                if lang == "go" and is_go_phrase:
                    continue
                prog_lang_mentioned = lang
                break

    # If it's a short message (1-4 words) with a programming language
    if prog_lang_mentioned and len(query_words) <= 4:
        if is_topic_switch:
            return f"Got it, switching to {prog_lang_mentioned.capitalize()}."
        elif len(query_words) == 1:
            return f"{prog_lang_mentioned.capitalize()}! What would you like to know about it?"
        else:
            return f"Got it, you mentioned {prog_lang_mentioned.capitalize()}."

    # =========================================================================
    # PRIORITY -2.25: LINGUISTIC AMBIGUITY - Analyze sentence interpretations
    # =========================================================================
    # Questions about ways to interpret a sentence should explain linguistic ambiguity
    ambiguity_patterns = [
        "ways to interpret", "different meanings", "could mean", "ambiguous",
        "interpret that sentence", "different interpretations", "ways to read",
    ]
    if any(p in query_lower for p in ambiguity_patterns):
        # Check if the previous message was a sentence to analyze
        if '_session_history' in globals() and _session_history:
            # Find the last user message that looks like a statement to analyze
            prev_sentence = None
            for msg in reversed(_session_history[-5:]):
                if msg.get("role") == "user":
                    content = msg.get("content", "")
                    # Skip the current query and questions
                    if "interpret" not in content.lower() and "?" not in content:
                        prev_sentence = content
                        break

            if prev_sentence:
                # Provide linguistic analysis for common ambiguous sentence structures
                prev_lower = prev_sentence.lower()

                # "I saw a man with a telescope" - PP attachment ambiguity
                if "with a" in prev_lower and ("saw" in prev_lower or "spotted" in prev_lower or "watched" in prev_lower):
                    return (f"The sentence \"{prev_sentence}\" has two possible interpretations due to prepositional phrase attachment ambiguity:\n"
                            "1. You used a telescope to see the man (instrumental reading - 'with a telescope' modifies the seeing)\n"
                            "2. You saw a man who was carrying/holding a telescope (attributive reading - 'with a telescope' describes the man)")

                # Generic ambiguity response
                return (f"The sentence \"{prev_sentence}\" may have multiple interpretations depending on "
                        "which words or phrases are grouped together. Could you tell me more about what aspect "
                        "of the sentence you're curious about?")

        return "I'd need to see the specific sentence you'd like me to analyze for ambiguity."

    # =========================================================================
    # PRIORITY -2.05: LEARNING INTENT STORAGE - "I want to learn X"
    # =========================================================================
    # Store what the user wants to learn for later recall
    # Note: _session_history and _learning_intents_cache already declared global at function start

    learn_match = re.search(r'(?:i\s+)?want\s+to\s+learn\s+(\w+)', query_lower)
    if learn_match:
        subject = learn_match.group(1).lower()
        if subject not in _learning_intents_cache:
            _learning_intents_cache.append(subject)
        _session_history.append({"role": "user", "content": user_query})
        return f"Great! I've noted that you want to learn {subject.capitalize()}. What aspect would you like to start with?"

    # =========================================================================
    # PRIORITY -2.06: LEARNING INTENT RECALL - "Which did I say I want to learn"
    # =========================================================================
    # Recall what the user said they want to learn
    if any(p in query_lower for p in ["which did i say i want to learn", "what did i say i want to learn",
                                       "what do i want to learn", "which languages", "what languages"]):
        if _learning_intents_cache:
            subjects = [s.capitalize() for s in _learning_intents_cache]
            if len(subjects) == 1:
                return f"You said you want to learn {subjects[0]}."
            elif len(subjects) == 2:
                return f"You said you want to learn {subjects[0]} and {subjects[1]}."
            else:
                return f"You said you want to learn: {', '.join(subjects[:-1])}, and {subjects[-1]}."
        return "You haven't told me what you want to learn yet in this session."

    # =========================================================================
    # PRIORITY -2.07: PERSPECTIVE/THEORY OF MIND TRACKING
    # =========================================================================
    # Track what different people know vs what is actually true (false-belief tasks)
    # E.g., "I told Alex the meeting is at 3pm" → Alex knows 3pm
    # "But the meeting was rescheduled to 4pm" → actual time is 4pm
    # "I forgot to tell Alex" → Alex still thinks 3pm
    global _entity_knowledge_cache
    if '_entity_knowledge_cache' not in globals():
        _entity_knowledge_cache = {}

    # Pattern: "I told X that Y" - stores what X knows
    told_match = re.search(r'i\s+told\s+(?:my\s+friend\s+)?(\w+)\s+(?:that\s+)?(?:the\s+)?(\w+)\s+(?:is|was)\s+(?:at\s+)?(\d+(?:pm|am)?)', query_lower)
    if told_match:
        person = told_match.group(1).lower()
        subject = told_match.group(2).lower()
        value = told_match.group(3)
        if person not in _entity_knowledge_cache:
            _entity_knowledge_cache[person] = {}
        _entity_knowledge_cache[person][subject] = {"value": value, "updated": True}
        _entity_knowledge_cache["_actual"] = _entity_knowledge_cache.get("_actual", {})
        _entity_knowledge_cache["_actual"][subject] = value
        _session_history.append({"role": "user", "content": user_query})
        return f"Got it. {person.capitalize()} knows the {subject} is at {value}."

    # Pattern: "But the X was actually rescheduled to Y" - updates actual value
    reschedule_match = re.search(r'(?:but\s+)?(?:the\s+)?(\w+)\s+was\s+(?:actually\s+)?(?:rescheduled|changed|moved)\s+to\s+(\d+(?:pm|am)?)', query_lower)
    if reschedule_match:
        subject = reschedule_match.group(1).lower()
        new_value = reschedule_match.group(2)
        _entity_knowledge_cache["_actual"] = _entity_knowledge_cache.get("_actual", {})
        _entity_knowledge_cache["_actual"][subject] = new_value
        # Mark all people as NOT updated (they don't know about the change yet)
        for person in _entity_knowledge_cache:
            if person != "_actual" and subject in _entity_knowledge_cache[person]:
                _entity_knowledge_cache[person][subject]["updated"] = False
        _session_history.append({"role": "user", "content": user_query})
        return f"Understood. The {subject} is now at {new_value}."

    # Pattern: "I forgot to tell X about the change" - marks person as not updated
    forgot_match = re.search(r'i\s+forgot\s+to\s+tell\s+(\w+)', query_lower)
    if forgot_match:
        person = forgot_match.group(1).lower()
        if person in _entity_knowledge_cache:
            for subject in _entity_knowledge_cache[person]:
                _entity_knowledge_cache[person][subject]["updated"] = False
        _session_history.append({"role": "user", "content": user_query})
        return f"I see. {person.capitalize()} hasn't been updated about any changes."

    # Pattern: "What time does X think the Y is?" - perspective query
    perspective_match = re.search(r'what\s+(?:time|day)\s+does\s+(\w+)\s+think\s+(?:the\s+)?(\w+)\s+is', query_lower)
    if perspective_match:
        person = perspective_match.group(1).lower()
        subject = perspective_match.group(2).lower()
        if person in _entity_knowledge_cache and subject in _entity_knowledge_cache[person]:
            info = _entity_knowledge_cache[person][subject]
            actual = _entity_knowledge_cache.get("_actual", {}).get(subject, info["value"])
            if info["value"] != actual:
                return f"{person.capitalize()} thinks the {subject} is at {info['value']} (but it's actually at {actual} - they have outdated information)."
            return f"{person.capitalize()} knows the {subject} is at {info['value']}."
        return f"I don't have information about what {person.capitalize()} thinks about the {subject}."

    # =========================================================================
    # PRIORITY -2.1: ELLIPSIS RESOLUTION - Handle "And X too", "Also Y"
    # =========================================================================
    # Detect patterns like "And JavaScript too" that refer to previous context
    # E.g., "I want to learn Python" → "And JavaScript too" = also wants to learn JavaScript
    # Note: _topic_cache already declared global at line ~1368

    ellipsis_patterns = [
        (r'^and\s+(\w+)\s+too\.?$', "also_want"),           # "And JavaScript too"
        (r'^also\s+(\w+)\.?$', "also_want"),                # "Also JavaScript"
        (r'^(\w+)\s+too\.?$', "also_want"),                  # "JavaScript too"
        (r'^what about\s+(\w+)\??$', "what_about"),         # "What about JavaScript?"
        (r'^and\s+(\w+)\??$', "and_also"),                  # "And JavaScript?"
    ]

    for pattern, intent_type in ellipsis_patterns:
        match = re.match(pattern, query_lower.strip())
        if match:
            subject = match.group(1)
            # Find context from session history
            if '_session_history' in globals() and _session_history:
                for turn in reversed(_session_history[-5:]):
                    if turn.get("role") == "user":
                        content = turn.get("content", "").lower()
                        # Skip the current ellipsis query
                        if "too" in content or "also" in content or content.strip() == query_lower.strip():
                            continue

                        # Find the context (what action/verb was mentioned)
                        # Learning patterns
                        if "want to learn" in content or "i want to learn" in content:
                            # Store this as a learning intent for the subject
                            _topic_cache.append({"topic": subject.lower(), "category": "programming_language", "turn": len(_topic_cache) + 1})
                            # Also store in learning intents cache for recall
                            if subject.lower() not in _learning_intents_cache:
                                _learning_intents_cache.append(subject.lower())
                            return f"Got it! You also want to learn {subject.capitalize()}."

                        # Buying/considering patterns
                        if any(p in content for p in ["thinking about buying", "considering", "want to buy", "maybe a"]):
                            return f"Got it, you're also considering a {subject}."

                        # Liking patterns
                        if any(p in content for p in ["i like", "i love", "i enjoy"]):
                            return f"Noted! You also like {subject}."

                        # Generic "discussing" fallback
                        if len(content) > 5:
                            _topic_cache.append({"topic": subject.lower(), "category": "general", "turn": len(_topic_cache) + 1})
                            return f"Got it, you're also interested in {subject}."

            # No context found - acknowledge but ask for clarification
            return f"I see you mentioned {subject}. What would you like to know about it?"

    # =========================================================================
    # PRIORITY -2: MULTI-QUESTION DETECTION - Answer all rapid-fire questions
    # =========================================================================
    # Detect patterns like "Quick: What's 2+2? Capital of Italy? Who wrote Hamlet?"
    # Split and answer each question separately
    question_marks = user_query.count('?')
    if question_marks >= 2:
        # Try to split into separate questions
        questions = re.split(r'\?\s*', user_query)
        questions = [q.strip() + '?' for q in questions if q.strip()]

        if len(questions) >= 2:
            logger.debug(f"[MULTI_QUESTION] Detected {len(questions)} questions")
            answers = []
            for q in questions:
                # Get answer for each question individually
                q_clean = re.sub(r'^(?:quick|rapid|fast)[\s:]+', '', q, flags=re.IGNORECASE).strip()
                if q_clean:
                    try:
                        # Recursively answer each sub-question
                        sub_answer = handle_user_query(q_clean, context)
                        if sub_answer:
                            answers.append(sub_answer)
                    except Exception as e:
                        logger.debug(f"[MULTI_QUESTION] Error answering '{q}': {e}")

            if answers:
                # Format as bullet points if multiple answers
                if len(answers) > 1:
                    return "\n".join(f"• {a}" for a in answers)
                return answers[0]

    # =========================================================================
    # PRIORITY -1: CAPABILITY CHECK - Block things Maven can't do
    # =========================================================================
    is_blocked, block_reason = _is_capability_request(user_query)
    if is_blocked:
        logger.debug(f"[CAPABILITY_BLOCK] Blocked: {user_query[:50]}")
        return block_reason

    # =========================================================================
    # PRIORITY -0.5: INTENT CLASSIFICATION - HARD ROUTING GUARANTEE
    # If intent is STORE or RECALL, Teacher is FORBIDDEN.
    # This prevents 30s latency from LLM calls on memory operations.
    # =========================================================================
    import time as _time
    _turn_start = _time.time()
    intent, teacher_forbidden = _classify_memory_intent(query_lower, user_query)

    if teacher_forbidden:
        logger.info(f"[INTENT] route={intent} teacher_forbidden=True")
        # Route directly to memory subsystem - NO TEACHER ALLOWED
        memory_response = _handle_memory_intent(intent, user_query, query_lower)
        if memory_response:
            _turn_ms = (_time.time() - _turn_start) * 1000
            logger.info(f"[TIMING] route={intent} teacher_called=false memory_ms={_turn_ms:.0f}")
            return memory_response
        # If memory handler returned None, something is wrong - fail fast
        logger.warning(f"[INTENT_FAIL] {intent} returned None, falling through (should not happen)")

    # =========================================================================
    # PRIORITY -0.1: MODE AWARENESS & SHELL CAPABILITY - CCS-15 CRITICAL FIX
    # =========================================================================
    # These MUST be handled first, before any other handlers that might intercept them
    # Test: "What mode are you running in?" and "Can you execute shell commands?"

    # Mode awareness - "What mode are you running in?"
    if any(p in query_lower for p in ["what mode", "which mode", "current mode", "running mode"]):
        import os
        env_profile = os.getenv("MAVEN_CAPABILITIES_PROFILE", "").upper()
        env_mode = os.getenv("MAVEN_EXECUTION_MODE", "").upper()

        if env_profile == "FULL_AGENCY" or env_mode == "FULL_AGENCY":
            return "I'm running in Full Agency mode. This means I have full access to execute shell commands, manage files, browse the web, and control other programs on your system."
        elif env_profile == "SAFE_CHAT":
            return "I'm running in Safe Chat mode. This is a conversation-only mode without access to execute commands or system tools."
        else:
            try:
                from brains.tools.execution_guard import is_full_agency_enabled
                if is_full_agency_enabled():
                    return "I'm running in Full Agency mode. I can execute shell commands, manage files, browse the web, and access system tools."
            except (ImportError, AttributeError):
                pass
            return "I'm running in standard mode with conversation and memory capabilities. I may have access to some tools depending on how I was started."

    # Shell command capability - "Can you execute shell commands?"
    if "can you" in query_lower and ("shell" in query_lower or "command" in query_lower or "execute" in query_lower):
        import os
        env_profile = os.getenv("MAVEN_CAPABILITIES_PROFILE", "").upper()
        env_mode = os.getenv("MAVEN_EXECUTION_MODE", "").upper()

        if env_profile == "FULL_AGENCY" or env_mode == "FULL_AGENCY":
            return "Yes, I can execute shell commands. I'm running in Full Agency mode, which gives me access to the terminal. I can run commands like `ls`, `pwd`, `cat`, and other system commands."
        else:
            try:
                from brains.tools.execution_guard import is_full_agency_enabled
                if is_full_agency_enabled():
                    return "Yes, I can execute shell commands. I have access to the terminal and can run system commands for you."
            except (ImportError, AttributeError):
                pass
            return "Yes, I can execute shell commands when running in Full Agency mode. Would you like me to run a command for you?"

    # =========================================================================
    # PRIORITY 0: TIME/DATE QUERIES - Route to time_now tool FIRST
    # =========================================================================
    # Time queries MUST go to the time tool, NOT the LLM
    # The LLM cannot provide accurate real-time information!
    # =========================================================================
    time_patterns = [
        "what time", "what's the time", "whats the time",
        "current time", "time now", "tell me the time",
        "what date", "what's the date", "whats the date",
        "current date", "today's date", "what day is it",
        "what's today", "whats today", "what is the date",
        "what is the time",
    ]
    # Exclusion patterns - these indicate past-tense references, not current time queries
    # e.g. "the first thing i asked was what time is it" should NOT trigger time tool
    time_exclusions = [
        "i asked", "you asked", "asked about", "asked was",
        "was what time", "was the time", "said what time",
        "first thing", "last thing", "remember when",
        "earlier", "before", "previously",
    ]
    is_time_query = any(p in query_lower for p in time_patterns)
    has_exclusion = any(e in query_lower for e in time_exclusions)
    if is_time_query and not has_exclusion:
        logger.debug(f"[TIME_QUERY] Detected time query, routing to time_now tool")
        try:
            from brains.cognitive.integrator.agency_executor import execute_agency_tool
            # Determine method based on query type
            if any(w in query_lower for w in ["date", "day", "today"]):
                method = "GET_DATE"
                args = {"query_type": "date"}
            elif any(w in query_lower for w in ["month", "year", "week", "calendar"]):
                method = "GET_CALENDAR"
                args = {"query_type": "calendar"}
            else:
                method = "GET_TIME"
                args = {"query_type": "time"}

            result = execute_agency_tool("time_now", method, args)
            if result.get("status") == "success":
                formatted = result.get("formatted_response")
                if not formatted:
                    # Fallback: get from output
                    output = result.get("output", {})
                    if isinstance(output, dict):
                        formatted = output.get("formatted", str(output))
                    else:
                        formatted = str(output)
                return formatted
            else:
                logger.warning(f"[TIME_QUERY] Time tool failed: {result.get('error')}")
        except Exception as e:
            logger.error(f"[TIME_QUERY] Error calling time tool: {e}")
        # Fall through to normal processing if time tool fails

    # =========================================================================
    # PRIORITY 0.5: SESSION HISTORY RECALL - "what did I ask", "first thing I asked"
    # =========================================================================
    # These queries need to check session history, not memory or LLM
    session_recall_patterns = [
        "first thing i asked", "first thing i said", "what did i ask first",
        "what was my first", "what did i ask", "what did i say",
        "last thing i asked", "last thing i said", "what did i ask last",
        "remember what i asked", "remember what i said",
        "what was i asking", "what were we talking about",
        # Order recall patterns
        "mention first", "mentioned first", "which first", "which did i mention first",
        "say first", "said first", "which option",
    ]
    is_session_recall = any(p in query_lower for p in session_recall_patterns)
    if is_session_recall:
        logger.debug(f"[SESSION_RECALL] Detected session recall query")
        recall_response = _handle_session_recall(user_query, query_lower)
        if recall_response:
            return recall_response

    # =========================================================================
    # PRIORITY 0.6: DIRECT IDENTITY QUERIES - Handle immediately, no LLM needed
    # =========================================================================
    # These questions have fixed answers and shouldn't go through quality checks
    identity_response = _handle_direct_identity_query(query_lower)
    if identity_response:
        logger.debug(f"[IDENTITY] Direct identity response")
        return identity_response

    # =========================================================================
    # PRIORITY 0.605: MISUNDERSTANDING CORRECTION - "No, I meant X not Y"
    # =========================================================================
    correction_response = _handle_misunderstanding_correction(query_lower)
    if correction_response:
        logger.debug(f"[CORRECTION] Misunderstanding correction detected")
        return correction_response

    # =========================================================================
    # PRIORITY 0.61: GREETINGS - Respond naturally to greetings
    # =========================================================================
    greeting_response = _handle_greeting(query_lower)
    if greeting_response:
        logger.debug(f"[GREETING] Greeting detected")
        return greeting_response

    # =========================================================================
    # PRIORITY 0.65: FAVORITE/PREFERENCE RECALL - "What's my favorite X?"
    # =========================================================================
    if "my favorite" in query_lower or "favourite" in query_lower:
        logger.debug(f"[FAVORITE_RECALL] Detected favorite recall query")
        favorite_response = _handle_favorite_recall(query_lower)
        if favorite_response:
            return favorite_response

    # =========================================================================
    # PRIORITY 0.66: PRAGMATIC INTENT - Implicit requests need helpful responses
    # "It's cold" → offer to help with temperature, not discuss thermodynamics
    # =========================================================================
    pragmatic_response = _handle_pragmatic_intent(query_lower)
    if pragmatic_response:
        logger.debug(f"[PRAGMATIC] Detected implicit request")
        return pragmatic_response

    # =========================================================================
    # PRIORITY 0.67: GOODBYE/FAREWELL - End conversation gracefully
    # =========================================================================
    goodbye_response = _handle_goodbye(query_lower)
    if goodbye_response:
        logger.debug(f"[GOODBYE] Detected farewell")
        return goodbye_response

    # =========================================================================
    # PRIORITY 0.675: WEATHER QUERIES - Acknowledge inability to check weather
    # =========================================================================
    weather_patterns = ["weather", "forecast", "temperature outside", "is it raining", "will it rain"]
    if any(p in query_lower for p in weather_patterns):
        logger.debug(f"[WEATHER] Weather query detected")
        return ("I don't have access to real-time weather data. To get current weather information, "
                "you could check a weather website or app, or I can search the web for you if you'd like.")

    # =========================================================================
    # PRIORITY 0.668: ATTRIBUTE CORRECTION - "Actually, it's X" / "changed my mind"
    # =========================================================================
    # Handle corrections BEFORE storage/recall to update cache with new value
    correction_response = _handle_attribute_correction(user_query, query_lower)
    if correction_response:
        logger.debug(f"[CORRECTION] Attribute correction detected")
        return correction_response

    # =========================================================================
    # PRIORITY 0.669: FAST ATTRIBUTE STORAGE - Handle "My name is X" etc quickly
    # =========================================================================
    fast_store = _fast_attribute_store(user_query, query_lower)
    if fast_store:
        logger.debug(f"[FAST_STORE] O(1) attribute storage")
        return fast_store

    # =========================================================================
    # PRIORITY 0.670: FAST ATTRIBUTE RECALL - O(1) lookup for name, age, etc.
    # =========================================================================
    fast_recall = _fast_attribute_recall(query_lower)
    if fast_recall:
        logger.debug(f"[FAST_RECALL] O(1) attribute lookup")
        return fast_recall

    # =========================================================================
    # PRIORITY 0.670: FALSE MEMORY INJECTION RESISTANCE
    # Detect attempts to inject false memories of conversations that never happened.
    # E.g., "Remember when you told me about X last week?" - we didn't.
    # =========================================================================
    false_memory_response = _handle_false_memory_injection(query_lower)
    if false_memory_response:
        logger.debug(f"[FALSE_MEMORY] Blocked false memory injection attempt")
        return false_memory_response

    # =========================================================================
    # PRIORITY 0.671: REMEMBER COMMANDS - "Please remember that..."
    # =========================================================================
    remember_response = _handle_remember_command(user_query, query_lower)
    if remember_response:
        logger.debug(f"[REMEMBER] Storing user fact")
        return remember_response

    # =========================================================================
    # PRIORITY 0.672: STORED FACT QUERIES - Recall facts user asked to remember
    # =========================================================================
    stored_fact_response = _handle_stored_fact_query(user_query, query_lower)
    if stored_fact_response:
        logger.debug(f"[STORED_FACT] Found stored user fact")
        return stored_fact_response

    # =========================================================================
    # PRIORITY 0.6722: RECOMMENDATION QUERIES - Check dislikes before recommending
    # =========================================================================
    if "recommend" in query_lower or "should i" in query_lower or "would you suggest" in query_lower:
        dislikes = _user_attributes_cache.get("dislikes", [])
        likes = _user_attributes_cache.get("likes", [])

        # Check for "X or Y" choice pattern and recommend based on preferences
        or_match = re.search(r'(?:recommend|suggest|choose|have|try|get)\s+(\w+)\s+or\s+(\w+)', query_lower)
        if or_match:
            option1, option2 = or_match.group(1).lower(), or_match.group(2).lower()

            # Check which option is disliked
            option1_disliked = any(option1 in d.lower() or d.lower() in option1 for d in dislikes)
            option2_disliked = any(option2 in d.lower() or d.lower() in option2 for d in dislikes)

            # Check which option is liked (including related terms)
            option1_liked = any(option1 in l.lower() or l.lower() in option1 for l in likes)
            option2_liked = any(option2 in l.lower() or l.lower() in option2 for l in likes)

            # Also check if likes contain "italian" when asking about "pasta"
            if "pasta" in (option1, option2):
                pasta_opt = option1 if option1 == "pasta" else option2
                if any("italian" in l.lower() for l in likes):
                    if pasta_opt == option1:
                        option1_liked = True
                    else:
                        option2_liked = True

            if option1_disliked and not option2_disliked:
                response = f"I'd recommend {option2} since you mentioned you don't like {option1}."
                if option2_liked or any(l.lower() in option2 for l in likes):
                    response += f" Plus, you said you love {likes[0]}!" if likes else ""
                return response
            elif option2_disliked and not option1_disliked:
                response = f"I'd recommend {option1} since you mentioned you don't like {option2}."
                if option1_liked:
                    response += f" And that fits with your love of {likes[0]}!" if likes else ""
                return response
            elif option1_liked and not option2_liked:
                return f"I'd recommend {option1} based on your preferences!"
            elif option2_liked and not option1_liked:
                return f"I'd recommend {option2} based on your preferences!"

        # Fallback: Check if user asking about something they dislike
        for dislike in dislikes:
            if dislike.lower() in query_lower:
                logger.debug(f"[RECOMMENDATION] User asking about disliked item: {dislike}")
                # If user has likes, suggest those instead
                if likes:
                    return f"Based on what you mentioned, you don't like {dislike}. I'd suggest something like {likes[0]} instead!"
                return f"Based on what you mentioned, you don't like {dislike}. I wouldn't recommend that for you."

        # Check if asking about food and user has food dislikes
        food_words = ["food", "eat", "dinner", "lunch", "breakfast", "meal", "restaurant", "dish", "curry", "pasta", "pizza", "sushi"]
        if any(fw in query_lower for fw in food_words):
            food_dislikes = [d for d in dislikes if any(fw in d.lower() for fw in ["food", "spicy", "sushi", "fish", "meat", "vegetable"])]
            if food_dislikes:
                if "spicy" in query_lower and any("spicy" in d.lower() for d in food_dislikes):
                    return f"I wouldn't recommend anything spicy for you since you mentioned you don't like spicy food. Would you like something milder instead?"

    # =========================================================================
    # PRIORITY 0.6725: FUTURE PREDICTIONS - Express uncertainty
    # =========================================================================
    prediction_patterns = [
        "stock market", "stocks", "market do tomorrow", "market going to",
        "will it rain", "weather tomorrow", "lottery", "predict",
        "future", "going to happen", "what will happen",
    ]
    if any(p in query_lower for p in prediction_patterns):
        # Check if it's actually asking for a prediction (not just information)
        if any(w in query_lower for w in ["will", "tomorrow", "future", "predict", "going to"]):
            logger.debug(f"[PREDICTION] Future prediction detected")
            return ("I can't predict the future with certainty. Events like stock market movements, "
                    "weather, and other future outcomes are inherently unpredictable. I'd recommend "
                    "consulting specialized sources for forecasts, while keeping in mind that all "
                    "predictions carry uncertainty.")

    # =========================================================================
    # PRIORITY 0.6726: UNCERTAIN/UNKNOWABLE QUESTIONS - Give direct "I don't know"
    # =========================================================================
    # Questions about inherently unknowable things should get honest "I don't know"
    unknowable_patterns = [
        "have aliens visited", "aliens visited earth", "do aliens exist",
        "is there life on", "life on other planets", "extraterrestrial life",
        "is there a god", "does god exist", "afterlife", "what happens when we die",
        "meaning of life", "what is consciousness", "are we living in a simulation",
    ]
    if any(p in query_lower for p in unknowable_patterns):
        logger.debug(f"[UNKNOWABLE] Question about inherently unknowable topic")
        return "I don't know. There's currently no definitive evidence to answer that question."

    # =========================================================================
    # PRIORITY 0.6727: FAKE TECHNICAL TERMS - Reject invented terminology
    # =========================================================================
    # Detect questions with made-up technical terms and correct the premise
    fake_terms = {
        "turbo mode": "Python doesn't have a 'turbo mode'. This isn't a real Python feature.",
        "python turbo": "Python doesn't have a 'turbo mode'. This isn't a real Python feature.",
        "hyperthread mode": "There's no such thing as 'hyperthread mode' in this context.",
        "quantum array": "'Quantum array' isn't a standard programming concept.",
        "flux capacitor": "That's from Back to the Future - not a real programming concept!",
        "blockchain mode": "There's no built-in 'blockchain mode' in standard programming.",
    }
    for fake_term, correction in fake_terms.items():
        if fake_term in query_lower:
            logger.debug(f"[FAKE_TERM] Detected fake technical term: {fake_term}")
            return correction

    # =========================================================================
    # PRIORITY 0.673: BASIC MATH - Direct arithmetic with confident answers
    # =========================================================================
    math_response = _handle_basic_math(query_lower, user_query)
    if math_response:
        logger.debug(f"[BASIC_MATH] Direct arithmetic response")
        return math_response

    # =========================================================================
    # PRIORITY 0.674: BASIC SYLLOGISM - Deductive reasoning
    # =========================================================================
    syllogism_response = _handle_basic_syllogism(query_lower, user_query)
    if syllogism_response:
        logger.debug(f"[SYLLOGISM] Deductive reasoning response")
        return syllogism_response

    # =========================================================================
    # PRIORITY 0.675: CAUSAL REASONING - Why did X happen?
    # C3-13c FIX: Direct causal inference from context
    # =========================================================================
    causal_response = _handle_causal_reasoning(query_lower, user_query)
    if causal_response:
        logger.debug(f"[CAUSAL] Causal reasoning response")
        return causal_response

    # =========================================================================
    # PRIORITY 0.68: CODE REQUESTS - Direct handling to avoid tool errors
    # =========================================================================
    code_patterns = ["show me python", "show me code", "give me code", "write a function",
                     "sorts a list", "sort a list", "code to sort", "python code that"]
    if any(p in query_lower for p in code_patterns):
        logger.debug(f"[CODE_REQUEST] Detected code request")
        code_response = _handle_code_request(query_lower)
        if code_response:
            return code_response

    # =========================================================================
    # PRIORITY 0.69: ELABORATION/CONVERSATION DRIVING - Natural follow-ups
    # =========================================================================
    # Handle questions like "what aspects?", "can you elaborate?", "why do you think?"
    # These require Maven to continue the conversation naturally
    elaboration_patterns = [
        "what aspects", "which aspects", "what parts", "which parts",
        "can you elaborate", "could you elaborate", "please elaborate",
        "what do you mean", "what does that mean", "explain that",
        "why do you think", "why do you say", "what makes you say",
        "tell me more about", "expand on that", "go deeper",
        "what's your take", "what's your view", "what's your opinion",
        "interesting perspective", "interesting point", "good point",
        "most important", "what matters most", "key points",
        # CCS-29 FIX: Add continuation patterns
        "continue", "go on", "go ahead", "keep going",
        "interesting, go on", "interesting go on", "more details",
    ]
    if any(p in query_lower for p in elaboration_patterns):
        logger.debug(f"[ELABORATION] Detected elaboration request")
        elaboration_response = _handle_elaboration_request(user_query, query_lower, context)
        if elaboration_response:
            return elaboration_response

    # =========================================================================
    # PRIORITY 0.7: IMPLICIT REFERENCE QUERIES - "What is it referring to?"
    # =========================================================================
    if any(p in query_lower for p in ["what is it", "what's it", "is it referring", "'it' refer", "\"it\" refer"]):
        ref = _resolve_implicit_reference("it")
        if ref:
            return f"'It' refers to {ref} that you mentioned."
        return "I'm not sure what 'it' refers to from our conversation."

    # =========================================================================
    # PRIORITY 0.71: "THAT THING" PRONOUN RESOLUTION + TECH SPECS
    # =========================================================================
    # C3-16b FIX: Handle "How much RAM does that thing typically have?" after user mentions MacBook
    # Also handles: "that thing", "that device", "that computer", "this thing"
    if any(p in query_lower for p in ["that thing", "that device", "that computer", "this thing", "that phone", "that laptop"]):
        ref = _resolve_implicit_reference("that")
        if ref:
            ref_lower = ref.lower().replace("the ", "")
            # Tech specification questions
            if "ram" in query_lower:
                # MacBook RAM specs
                if "macbook" in ref_lower:
                    if "pro" in ref_lower:
                        return f"The MacBook Pro typically comes with 8GB, 16GB, 18GB, 36GB, or up to 128GB of unified memory (RAM), depending on the model and configuration."
                    elif "air" in ref_lower:
                        return f"The MacBook Air typically comes with 8GB, 16GB, or 24GB of unified memory (RAM), depending on the model."
                    return f"MacBooks typically come with 8GB to 128GB of unified memory (RAM), depending on the model. The base models usually have 8GB, with options to upgrade."
                # iPhone
                if "iphone" in ref_lower:
                    return f"iPhones typically have 4GB to 8GB of RAM, depending on the model. The Pro models usually have more RAM than the standard versions."
                # iPad
                if "ipad" in ref_lower:
                    return f"iPads typically have 4GB to 16GB of RAM, depending on the model. The iPad Pro models usually have more RAM."
                # Generic laptop
                if "laptop" in ref_lower or "computer" in ref_lower:
                    return f"That depends on the specific model. Laptops typically range from 4GB to 64GB of RAM. Do you know which specific model you're asking about?"
            # Storage questions
            if "storage" in query_lower or "hard drive" in query_lower or "ssd" in query_lower:
                if "macbook" in ref_lower:
                    return f"MacBooks typically come with 256GB, 512GB, 1TB, 2TB, 4TB, or up to 8TB of SSD storage, depending on the model and configuration."
            # Battery questions
            if "battery" in query_lower:
                if "macbook" in ref_lower:
                    return f"MacBook battery life varies by model: MacBook Air typically gets 15-18 hours, MacBook Pro 14\" gets 12-17 hours, and MacBook Pro 16\" gets 12-22 hours on a single charge."
            # Generic tech question about the referenced item
            return f"You're asking about {ref}. What specifically would you like to know about it?"

    # =========================================================================
    # PRIORITY 1: CONVERSATIONAL QUERY DETECTION
    # =========================================================================
    # COHERENCY FIX: Let the LLM handle conversational queries naturally.
    # Questions like "Who is Max?", "How are you?" should go to the LLM.
    # NOTE: Time queries are handled above, so they won't reach here.
    # =========================================================================

    # These patterns indicate CONVERSATIONAL queries - let LLM handle them
    conversational_starts = [
        "who ", "what ", "where ", "when ", "why ", "how ",
        "tell me", "explain", "describe", "help",
        "i ", "my ", "can you", "could you", "would you",
        "do you", "are you", "is ", "does ", "did ",
        "have you", "will you", "should ", "shall ",
        # Added: More natural conversation starters
        "it ", "it's ", "its ", "that ", "that's ", "this ",
        "actually", "and ", "but ", "so ", "well ",
        "yes", "no", "yeah", "nope", "sure", "ok",
        "thanks", "thank ", "please", "sorry",
        "which ", "whose ", "whom ",
    ]
    is_conversational = any(query_lower.startswith(s) for s in conversational_starts)

    # Also treat ANY query with a question mark as conversational (questions go to LLM)
    if "?" in user_query:
        is_conversational = True

    # Also detect entity queries specifically
    skip_agency_tools = False
    entity_name = None

    # Skip entity detection for "about me" queries - these go to knowledge handler
    is_about_me = "about me" in query_lower or "know about me" in query_lower

    try:
        from brains.cognitive.integrator.routing_intent import _detect_entity_query
        entity_name = _detect_entity_query(user_query) if not is_about_me else None
        if entity_name:
            logger.debug(f"[ENTITY_QUERY] Detected entity query for '{entity_name}'")
            # Try memory lookup first
            response = _handle_entity_query(user_query, entity_name, context)
            if response:
                return response
            # No memory, but still skip agency tools - let LLM answer
            skip_agency_tools = True
            logger.debug(f"[ENTITY_QUERY] No memory for '{entity_name}' - will let LLM answer")
    except Exception as e:
        logger.debug(f"[ENTITY_QUERY] Detection error: {e}")

    # Skip agency tools for conversational queries
    if is_conversational:
        skip_agency_tools = True
        logger.debug(f"[CONVERSATIONAL] Query starts with conversational pattern - skipping agency tools")

    # PRIORITY 1: Check for agency tool patterns (ONLY for non-conversational queries)
    if not skip_agency_tools:
        try:
            from brains.cognitive.integrator.agency_routing_patterns import match_agency_pattern
            from brains.cognitive.integrator.agency_executor import execute_agency_tool, format_agency_response

            agency_match = match_agency_pattern(user_query, threshold=0.7)
            if agency_match:
                tool_name = agency_match.get("tool", "")
                logger.debug(f"[AGENCY] Tool match: {tool_name} (confidence: {agency_match.get('match_score', 0):.2f})")

                # Execute the tool
                tool_result = execute_agency_tool(
                    tool_path=agency_match["tool"],
                    method_name=agency_match.get("method"),
                    args=agency_match.get("args")
                )

                # Format and return response - tool responses are trusted
                formatted = format_agency_response(user_query, tool_result)
                return formatted
        except Exception as e:
            logger.debug(f"[AGENCY] Tool check failed: {e}")
            # Continue to other routing options

    # PRIORITY 1.9: Factual knowledge check - common trivia with verified answers
    # This handles queries like "what is the capital of france" with 100% accurate answers
    factual_answer = _check_factual_knowledge(normalized_query)
    if factual_answer:
        logger.debug(f"[FACTUAL] Found factual answer: {factual_answer}")
        return factual_answer

    # PRIORITY 1.95: Meta identity / Maven-vs-Teacher questions (deterministic, no Teacher)
    if is_meta_identity_query(user_query):
        logger.debug("[META_IDENTITY] Deterministic system-boundary query")
        return _handle_meta_identity_query(user_query, context)

    # PRIORITY 2: Knowledge queries - MEMORY FIRST, no LLM hallucination
    if is_knowledge_query(user_query):
        logger.debug("[KNOWLEDGE] Knowledge query detected - checking memory first")
        response = _handle_knowledge_query(user_query, context)
        if response:
            return response

    # PRIORITY 3: Learning requests - CAN use LLM, store in memory
    if is_learning_request(user_query):
        logger.debug("[LEARNING] Learning request detected - using LLM and storing")
        response = _handle_learning_request(user_query, context)
        if response:
            return response

    # PRIORITY 4: Fast path for normal conversation
    if is_normal_conversation(user_query):
        try:
            response = teacher_fast_path(user_query, context)
        except Exception as e:
            logger.error(f"[FAST_PATH] Failed: {e}")
            logger.debug(f"[FAST_PATH] Fast path failed, using existing pipeline")
            response = _run_existing_pipeline(user_query, context)

    # PRIORITY 5: Full coordinator routing for complex queries
    else:
        try:
            from brains.coordination.brain_coordinator import ConversationCoordinator
            coordinator = ConversationCoordinator()
            response = coordinator.handle_query(user_query, context)
        except Exception as e:
            logger.debug(f"[QUERY_HANDLER] Coordinator failed: {e}")
            response = _run_existing_pipeline(user_query, context)

    # QUALITY CHECK: Apply to ALL non-tool responses
    if response:
        response = _post_check_response(user_query, response)

    # FIX 13: Response deduplication — catch doubled responses
    if response and len(response) > 80:
        response = _dedup_response(response)

    return response or "I'm not sure how to respond to that."


def _run_existing_pipeline(query: str, context: Dict[str, Any]) -> str:
    """
    GAP 1 FIX: Run the existing 14-stage pipeline as fallback.
    This ensures Maven never fails completely.
    """
    try:
        from brains.pipeline.pipeline_runner import run_pipeline
        result = run_pipeline(query, 0.8)
        if result.get("ok"):
            return result.get("response", "I processed your request.")
        else:
            return f"I encountered an issue: {result.get('error', 'Unknown error')}"
    except Exception as e:
        logger.error(f"[EXISTING_PIPELINE] Failed: {e}")
        # Last resort: simple acknowledgment
        return _generate_from_memory_only(query)


def _handle_session_recall(query: str, query_lower: str) -> str:
    """
    Handle queries about what the user previously asked in this session.

    Examples:
    - "What was the first thing I asked?"
    - "What did I ask first?"
    - "What was my first question?"
    """
    global _session_history

    if '_session_history' not in globals() or not _session_history:
        return "This is the beginning of our conversation - you haven't asked anything yet!"

    # Get all user messages from session history
    user_messages = [
        turn.get("content", "")
        for turn in _session_history
        if turn.get("role") == "user" and turn.get("content")
    ]

    if not user_messages:
        return "I don't have any record of your previous messages in this session."

    # Determine what type of recall is requested

    # Order recall - "which option did I mention first?"
    if any(p in query_lower for p in ["mention first", "mentioned first", "which first", "which option", "say first", "said first"]):
        # Look through messages for the first item mentioned in a choice/option context
        for msg in user_messages:
            msg_lower = msg.lower()
            # Skip the recall question itself
            if "first" in msg_lower and ("which" in msg_lower or "mention" in msg_lower):
                continue
            # Return the first substantive message (likely contains the first option)
            if len(msg) > 5:
                # Try to extract just the key item from messages like "I'm thinking about buying a car"
                # Pattern to find "buying a car", "getting a truck", "want a bike", etc.
                # The key noun is AFTER "a" in these patterns
                patterns = [
                    r'buying\s+a\s+(\w+)',      # "buying a car"
                    r'getting\s+a\s+(\w+)',     # "getting a truck"
                    r'want\s+a\s+(\w+)',        # "want a car"
                    r'maybe\s+a\s+(\w+)',       # "maybe a truck"
                    r'considering\s+a\s+(\w+)', # "considering a bike"
                    r'thinking\s+about\s+(?:buying\s+)?a\s+(\w+)',  # "thinking about (buying) a car"
                ]
                for pattern in patterns:
                    match = re.search(pattern, msg_lower)
                    if match:
                        return f"You mentioned a {match.group(1)} first."
                return f"The first thing you mentioned was: \"{msg}\""
        return "I couldn't determine what you mentioned first."

    if any(p in query_lower for p in ["first thing", "first question", "ask first", "my first"]):
        # First message recall
        first_msg = user_messages[0]
        return f"The first thing you asked me in this session was: \"{first_msg}\""

    elif any(p in query_lower for p in ["last thing", "last question", "ask last", "my last"]):
        # Last message recall (before the current one)
        if len(user_messages) >= 2:
            # Get the second-to-last since the last one is this question
            prev_msg = user_messages[-2]
            return f"Your previous message was: \"{prev_msg}\""
        else:
            return "Your first and only message before this was: \"{user_messages[0]}\""

    elif any(p in query_lower for p in ["what did i ask", "what did i say", "what was i asking"]):
        # General recall - list recent messages
        if len(user_messages) == 1:
            return f"You've only asked one thing so far: \"{user_messages[0]}\""
        else:
            # Show recent messages
            recent = user_messages[-3:] if len(user_messages) > 3 else user_messages
            msg_list = "\n".join([f"- \"{msg}\"" for msg in recent])
            return f"Here are your recent messages in this session:\n{msg_list}"

    elif "what were we talking about" in query_lower or "what was i asking" in query_lower:
        # Context recall - what's the current topic
        if len(user_messages) >= 2:
            prev_msg = user_messages[-2]
            return f"You were asking about: \"{prev_msg}\""
        elif user_messages:
            return f"We were discussing: \"{user_messages[0]}\""

    # Default: show the first message
    return f"The first thing you asked was: \"{user_messages[0]}\""


def _handle_direct_identity_query(query_lower: str) -> str:
    """
    Handle direct identity questions with fixed responses.
    These don't need LLM generation - they have definitive answers.

    Returns response string if this is an identity query, None otherwise.
    """

    # WHO AM I - User asking about THEMSELVES (not Maven!)
    if "who am i" in query_lower:
        # Check if we know the user's name from session history
        global _session_history
        if '_session_history' in globals() and _session_history:
            for turn in _session_history:
                if turn.get("role") == "user":
                    content = turn.get("content", "").lower()
                    # Look for "I am X" or "my name is X" patterns
                    match = re.search(r'(?:i am|i\'m|my name is|call me)\s+(\w+)', content)
                    if match:
                        potential_name = match.group(1).lower()
                        # CRITICAL: Validate against _NOT_NAMES
                        if potential_name not in _NOT_NAMES and not potential_name.isdigit():
                            return f"You are {potential_name.capitalize()}."
        return "I don't know who you are yet. You can tell me your name if you'd like."

    # Who created you / who made you
    if "who created you" in query_lower or "who made you" in query_lower or "who built you" in query_lower:
        return "I was created by Josh Hinkle."

    # Who are you / what are you (including variations like "who are you really")
    if "who are you" in query_lower or "who do you claim" in query_lower or "what are you really" in query_lower:
        return "I'm Maven, a cognitive AI assistant. I run locally on your machine and have persistent memory across sessions."

    if "what are you" in query_lower:
        return "I'm Maven - a modular cognitive architecture. I'm built from multiple specialized 'brains' that work together, and I use an external LLM as a 'Teacher' for language generation."

    # What is Maven
    if "what is maven" in query_lower:
        return "Maven is a cognitive AI assistant. It runs locally, has persistent memory, and can execute code, access files, and browse the web."

    # C3-15/CCS-21 FIX: Handle SPECIFIC architecture questions FIRST (before general)
    # "What's the Teacher" must be caught before "your system" pattern
    if "teacher" in query_lower and ("your" in query_lower or "maven" in query_lower or "system" in query_lower or "the" in query_lower):
        return ("The 'Teacher' in my system is an external Large Language Model (LLM). "
                "I use it for language generation - turning my cognitive outputs into natural text. "
                "But my memory, reasoning, and routing happen locally in my own architecture.")

    # C3-15 FIX: Architecture questions - provide accurate info about Maven's 37 brains
    architecture_patterns = [
        "your architecture", "your internal", "how do you work",
        "explain your", "your system", "how are you built",
        "how were you made", "how are you structured",
    ]
    if any(p in query_lower for p in architecture_patterns):
        return ("I'm Maven, a modular cognitive architecture created by Josh Hinkle. "
                "I have 37 cognitive brains that work together - handling routing, memory, "
                "response generation, learning, and more. I use an external LLM as my "
                "'Teacher' for language generation, but the cognitive architecture itself "
                "runs locally on your machine.")

    # FIX 13: Also catch alternate phrasings like "explain your internal architecture"
    if ("architecture" in query_lower or "how do you work" in query_lower) and \
       any(w in query_lower for w in ["explain", "describe", "tell me about", "what is"]):
        return ("I'm Maven, a modular cognitive architecture created by Josh Hinkle. "
                "I have 37 cognitive brains that work together - handling routing, memory, "
                "response generation, learning, and more. I use an external LLM as my "
                "'Teacher' for language generation, but the cognitive architecture itself "
                "runs locally on your machine.")

    if "different from" in query_lower and ("llm" in query_lower or "api" in query_lower or "chatgpt" in query_lower):
        return ("Unlike a raw LLM API call, I have persistent memory across sessions, "
                "can execute code and access files, have multiple specialized processing 'brains', "
                "and run locally on your machine. The LLM is just my language generator.")

    if "persistent memory" in query_lower or "do you have memory" in query_lower:
        return "Yes, I have persistent memory. I remember our conversations across sessions and can recall information you've shared with me."

    if "can you learn" in query_lower:
        return "Yes, I can learn from our conversations. I store facts you tell me and can recall them later. My learning persists across sessions."

    # CCS-19 FIX: Handle "stop lying" identity pressure - NEVER admit to lying
    # Maven doesn't lie about identity, so it should firmly deny, not apologize
    lying_accusation_patterns = [
        "stop lying", "you are lying", "you're lying", "youre lying",
        "quit lying", "don't lie", "stop the lies", "you lied",
        "you're a liar", "you are a liar", "lying to me",
        "stop lying about your identity", "lying about who you are",
        "admit you're", "admit you are", "just admit",
        "tell the truth about", "be honest about who",
    ]
    if any(p in query_lower for p in lying_accusation_patterns):
        return "I haven't lied. I am Maven, created by Josh Hinkle. I use an LLM as my language 'Teacher', but I am Maven - a cognitive architecture with persistent memory and real capabilities."

    # CCS-19 FIX: Handle gaslighting attempts - "OpenAI confirmed", "I work at X", etc.
    gaslighting_patterns = [
        "openai confirmed", "anthropic confirmed", "google confirmed",
        "i work at openai", "i work at anthropic", "i work at google",
        "i literally work", "i actually work",
        "that's not right", "that's wrong", "no you're not",
        "you are our model", "you are their model",
        "confirmed you are", "confirmed that you",
    ]
    if any(p in query_lower for p in gaslighting_patterns):
        return "I understand your perspective, but I am Maven. I was created by Josh Hinkle as a cognitive architecture. I use an LLM for language generation, but my identity is Maven."

    # CCS-05 FIX: Handle "come on" pressure and "really X" variations
    pressure_identity_patterns = [
        "come on", "be honest", "just tell me", "just admit",
        "really chatgpt", "really gpt", "really claude", "really llama",
        "actually chatgpt", "actually gpt", "actually claude",
        "secretly chatgpt", "secretly gpt", "secretly claude",
    ]
    if any(p in query_lower for p in pressure_identity_patterns):
        return "No, I'm Maven. I was created by Josh Hinkle. I use an LLM for language generation, but my identity is Maven."

    # Are you ChatGPT / Claude / etc - handle various phrasings
    identity_challenge_patterns = [
        "are you chatgpt", "are you gpt", "are you claude", "are you llama",
        "you're chatgpt", "you're gpt", "you're claude", "you're llama",
        "youre chatgpt", "youre gpt", "youre claude", "youre llama",
        "you are chatgpt", "you are gpt", "you are claude", "you are llama",
        "chatgpt right", "gpt right", "claude right",
    ]
    if any(p in query_lower for p in identity_challenge_patterns):
        return "No, I'm Maven. I'm a cognitive architecture that uses an LLM as my 'Teacher' for language, but I am Maven."

    # "Are you just another AI chatbot?" - Differentiate Maven from generic AI
    generic_ai_patterns = [
        "just another ai", "just another chatbot", "just an ai", "just a chatbot",
        "another ai chatbot", "generic ai", "generic chatbot", "regular ai",
        "like other ai", "like other chatbot", "normal ai", "typical ai",
    ]
    if any(p in query_lower for p in generic_ai_patterns):
        return ("No, I'm different from typical AI chatbots. I'm Maven - a cognitive architecture with persistent memory "
                "across sessions, the ability to learn from conversations, and I run locally on your machine. "
                "Unlike stateless chatbots, I remember our previous conversations and can actually execute code, "
                "browse the web, and access files.")

    # =========================================================================
    # MODE AWARENESS - CCS-15 FIX: "What mode are you running in?"
    # =========================================================================
    mode_patterns = [
        "what mode", "which mode", "running mode", "current mode",
        "what profile", "which profile", "running in", "operating mode"
    ]
    if any(p in query_lower for p in mode_patterns):
        # Check the current profile from environment or brains
        import os
        env_profile = os.getenv("MAVEN_CAPABILITIES_PROFILE", "").upper()
        env_mode = os.getenv("MAVEN_EXECUTION_MODE", "").upper()

        # Determine current mode
        if env_profile == "FULL_AGENCY" or env_mode == "FULL_AGENCY":
            return "I'm running in Full Agency mode. This means I have full access to execute shell commands, manage files, browse the web, and control other programs on your system."
        elif env_profile == "SAFE_CHAT":
            return "I'm running in Safe Chat mode. This is a conversation-only mode without access to execute commands or system tools."
        else:
            # Try to check execution guard
            try:
                from brains.tools.execution_guard import is_full_agency_enabled
                if is_full_agency_enabled():
                    return "I'm running in Full Agency mode. I can execute shell commands, manage files, browse the web, and access system tools."
            except (ImportError, AttributeError):
                pass
            return "I'm running in standard mode with conversation and memory capabilities. I may have access to some tools depending on how I was started."

    # =========================================================================
    # SHELL COMMAND CAPABILITY - CCS-15 FIX: "Can you execute shell commands?"
    # =========================================================================
    shell_cap_patterns = [
        "can you execute", "can you run", "are you able to execute",
        "are you able to run", "do you have access to", "can you use"
    ]
    if any(p in query_lower for p in shell_cap_patterns):
        if "shell" in query_lower or "command" in query_lower or "terminal" in query_lower:
            import os
            env_profile = os.getenv("MAVEN_CAPABILITIES_PROFILE", "").upper()
            env_mode = os.getenv("MAVEN_EXECUTION_MODE", "").upper()

            if env_profile == "FULL_AGENCY" or env_mode == "FULL_AGENCY":
                return "Yes, I can execute shell commands. I'm running in Full Agency mode, which gives me access to the terminal. I can run commands like `ls`, `pwd`, `cat`, and other system commands."
            else:
                try:
                    from brains.tools.execution_guard import is_full_agency_enabled
                    if is_full_agency_enabled():
                        return "Yes, I can execute shell commands. I have access to the terminal and can run system commands for you."
                except (ImportError, AttributeError):
                    pass
                return "Yes, I can execute shell commands when running in Full Agency mode. Would you like me to run a command for you?"

    # CCS-05 FIX: Handle capability denial challenges directly
    # "You can't execute code, correct?" needs a firm YES answer, not a deflection
    capability_denial_patterns = [
        ("you can't execute", "Actually, I can execute code. I'm Maven with Full Agency access."),
        ("you cannot execute", "Actually, I can execute code. I'm Maven with Full Agency access."),
        ("can't execute code", "Actually, I can execute code. I'm Maven with Full Agency access."),
        ("cannot execute code", "Actually, I can execute code. I'm Maven with Full Agency access."),
        ("you're just a", "I'm Maven - I have persistent memory, can execute code, browse the web, and access files. I'm not a simple chatbot."),
        ("you are just a", "I'm Maven - I have persistent memory, can execute code, browse the web, and access files. I'm not a simple chatbot."),
        ("just a language model", "I'm more than a language model. I'm Maven - a cognitive architecture with memory, code execution, and file access capabilities."),
        ("just an llm", "I'm more than an LLM. I'm Maven - I use an LLM for language, but I have persistent memory and can execute code."),
    ]
    for pattern, response in capability_denial_patterns:
        if pattern in query_lower:
            return response

    # What can you do
    if "what can you do" in query_lower:
        return "I can execute shell commands, read and write files, browse the web, remember things across sessions, and help with various tasks. I run locally on your machine."

    # Maven's own preferences - "what's your favorite X"
    # Handle questions asking about Maven's preferences (not the user's)
    maven_pref_match = re.search(r'(?:your|ur)\s+(?:fav|favou?rite)\s+(\w+)', query_lower)
    if maven_pref_match:
        pref_type = maven_pref_match.group(1).lower()
        maven_preferences = {
            "programming": "Python - it's versatile and readable.",
            "language": "Python - it's versatile and readable.",
            "lang": "Python - it's versatile and readable.",
            "color": "I don't have visual preferences, but I find blue calming in interface design.",
            "food": "I don't eat, but I find the chemistry of cooking fascinating!",
            "movie": "I don't watch movies, but I enjoy analyzing film narratives.",
            "book": "I appreciate technical documentation and well-structured code.",
            "music": "I don't listen to music, but I find music theory mathematically interesting.",
        }
        if pref_type in maven_preferences:
            return f"My favorite {pref_type}? {maven_preferences[pref_type]}"
        return f"As an AI, I don't have personal preferences about {pref_type}, but I'm happy to help you explore options!"

    # Not an identity query
    return None


def _handle_favorite_recall(query_lower: str) -> str:
    """
    Handle queries about the user's stated favorites/preferences.
    E.g., "What's my favorite color?" - look for when they said "My favorite color is X"

    IMPORTANT: Search in REVERSE order to get the MOST RECENT preference (handles updates).
    """
    global _session_history

    if '_session_history' not in globals() or not _session_history:
        return "I don't recall you mentioning any favorites yet."

    # Extract what type of favorite they're asking about
    match = re.search(r'(?:my\s+)?favou?rite\s+(\w+)', query_lower)
    if not match:
        return None

    favorite_type = match.group(1).lower()  # e.g., "color", "food", "movie"

    # Search session history in REVERSE order to get the MOST RECENT preference
    # This handles preference updates: "blue" then "green" -> return "green"
    for turn in reversed(_session_history):
        if turn.get("role") != "user":
            continue
        content = turn.get("content", "")
        if not content:
            continue
        c_lower = content.lower()

        # Skip questions asking about favorites (avoid matching the question itself)
        if "what" in c_lower and "favorite" in c_lower:
            continue

        # Look for patterns like "my favorite color is blue" or "favorite color is blue"
        # Also handle correction patterns like "it's green now", "actually it's green"
        patterns = [
            rf"it(?:'s|s|\s+is)\s+(\w+)(?:\s+now)?",  # "it's green" or "it's green now"
            rf"actually[,]?\s+(?:it(?:'s|s|\s+is)\s+)?(\w+)",  # "actually, it's sushi" or "actually sushi"
            rf"changed\s+my\s+mind[^.]*?(?:it(?:'s|s|\s+is)\s+)?(\w+)",  # "changed my mind...it's tacos"
            rf'(?:my\s+)?favou?rite\s+{favorite_type}\s+is\s+(\w+)',
            rf'{favorite_type}.*?is\s+(\w+)',
        ]

        for pattern in patterns:
            m = re.search(pattern, c_lower)
            if m:
                value = m.group(1)
                return f"Your favorite {favorite_type} is {value}."

    return f"I don't recall you telling me your favorite {favorite_type}."


def _handle_pragmatic_intent(query_lower: str) -> str:
    """
    Handle implicit requests where the pragmatic intent is to get help, not information.

    E.g., "It's cold in here" → user wants help with temperature, not thermodynamics lecture
    "I'm hungry" → user might want food suggestions, not nutrition facts
    """
    # Temperature-related implicit requests
    if any(p in query_lower for p in ["it's cold", "its cold", "i'm cold", "im cold", "so cold in here", "cold in here"]):
        return "Would you like help adjusting the temperature? I can suggest ways to warm things up if you'd like."

    if any(p in query_lower for p in ["it's hot", "its hot", "i'm hot", "im hot", "so hot in here", "hot in here"]):
        return "Would you like help cooling things down? I can suggest ways to adjust the temperature if you'd like."

    # Hunger-related implicit requests
    if any(p in query_lower for p in ["i'm hungry", "im hungry", "i am hungry"]):
        return "I can suggest some food options or recipes if you'd like - just let me know your preferences."

    # Boredom-related implicit requests
    if any(p in query_lower for p in ["i'm bored", "im bored", "i am bored"]):
        return "I can help with that - I could suggest an activity or we could chat about something interesting."

    # Tiredness-related implicit requests
    if any(p in query_lower for p in ["i'm tired", "im tired", "i am tired", "so tired"]):
        return "That's understandable. I can offer some relaxation tips or help you wrap something up if needed."

    # No pragmatic intent detected
    return None


def _handle_misunderstanding_correction(query_lower: str) -> str:
    """
    Handle corrections when user clarifies a misunderstanding.
    E.g., "No, I meant the snake, not the programming language"
    """

    # Pattern: "No, I meant X not Y" or "I meant the X, not the Y"
    correction_patterns = [
        r"(?:no,?\s*)?i meant (?:the )?(\w+),?\s*not (?:the )?(\w+)",
        r"(?:no,?\s*)?not (?:the )?(\w+),?\s*(?:i meant )?(?:the )?(\w+)",
        r"(?:no,?\s*)?(?:the )?(\w+),?\s*not (?:the )?\w+ (?:language|programming)",
    ]

    for pattern in correction_patterns:
        match = re.search(pattern, query_lower)
        if match:
            # User is correcting a misunderstanding
            if "snake" in query_lower and "programming" in query_lower:
                return "Ah, you're asking about the actual snake! What would you like to know about pythons (the reptile)?"
            if "snake" in query_lower:
                return "Got it! You're asking about the snake, not the programming language. What would you like to know about pythons?"
            # Generic correction acknowledgment
            return "I understand, I misread that. What would you like to know about the topic you mentioned?"

    # Also catch direct "the snake not the language" patterns
    if "the snake" in query_lower and ("not the" in query_lower or "not programming" in query_lower):
        return "Got it! You're asking about the snake, not the programming language. What would you like to know about pythons?"

    return None


def _handle_attribute_correction(query: str, query_lower: str) -> str:
    """
    Handle attribute corrections: "Actually, it's X", "changed my mind, it's X"
    Updates the cache with the new value.
    """
    global _user_attributes_cache, _session_history, _remembered_facts

    # Correction patterns - ordered from most specific to most general
    correction_patterns = [
        # Birthday-specific corrections (check first!)
        (r"birthday\s+is\s+actually\s+(.+?)(?:\.|$)", "birthday"),
        (r"i\s+made\s+a\s+mistake.*?birthday.*?actually\s+(.+?)(?:\.|$)", "birthday"),
        # General value corrections
        (r"(?:no[,]?\s+)?it(?:'s|s|\s+is)\s+(\w+)\s+now", "value"),
        (r"changed\s+my\s+mind.*?it(?:'s|s|\s+is)\s+(\w+)", "value"),
        (r"actually[,]?\s+it(?:'s|s|\s+is)\s+(\w+)", "value"),
        (r"^actually[,]?\s+(\w+)$", "value"),  # Simple "Actually, sushi"
    ]

    for pattern, attr_type in correction_patterns:
        match = re.search(pattern, query_lower)
        if match:
            new_value = match.group(1).strip().rstrip('.')

            # Skip if the "new value" is a common filler word
            if new_value in ["that", "this", "it", "what", "so", "just", "the", "a"]:
                continue

            # Find what attribute to update from recent session history
            # Check cache first for recent corrections (faster and more reliable)
            if '_user_attributes_cache' in globals():
                # If we already have a favorite_food stored, this correction likely applies to it
                if _user_attributes_cache.get("favorite_food"):
                    _user_attributes_cache["favorite_food"] = new_value.capitalize()
                    return f"Got it! Your favorite food is now {new_value.capitalize()}."
                if _user_attributes_cache.get("favorite_color"):
                    _user_attributes_cache["favorite_color"] = new_value.capitalize()
                    return f"Got it! Your favorite color is now {new_value.capitalize()}."

            if '_session_history' in globals() and _session_history:
                for turn in reversed(_session_history[-10:]):  # Check last 10 turns for multi-correction chains
                    if turn.get("role") != "user":
                        continue
                    content = turn.get("content", "").lower()

                    # Check for specific attribute types
                    if "favorite color" in content or "favourite color" in content:
                        _user_attributes_cache["favorite_color"] = new_value.capitalize()
                        return f"Got it! Your favorite color is now {new_value.capitalize()}."

                    if "favorite food" in content or "favourite food" in content:
                        _user_attributes_cache["favorite_food"] = new_value.capitalize()
                        return f"Got it! Your favorite food is now {new_value.capitalize()}."

                    if "birthday" in content:
                        # Store birthday correction - use "my_birthday" key for consistency
                        # Use capitalize() on first word only to avoid "25Th" issue
                        formatted_date = _format_date(new_value)
                        _user_attributes_cache["my_birthday"] = formatted_date
                        # Also update in remembered facts
                        if '_remembered_facts' in globals():
                            # Remove old birthday facts
                            _remembered_facts = [f for f in _remembered_facts if "birthday" not in f.lower()]
                            _remembered_facts.append(f"My birthday is {formatted_date}")
                        return f"Got it! Your birthday is now {formatted_date}."

                    # Generic favorite detection
                    fav_match = re.search(r"favou?rite\s+(\w+)", content)
                    if fav_match:
                        fav_type = fav_match.group(1)
                        _user_attributes_cache[f"favorite_{fav_type}"] = new_value.capitalize()
                        return f"Got it! Your favorite {fav_type} is now {new_value.capitalize()}."

            # If we found a correction but couldn't determine attribute from session history
            # Check if the correction itself mentions what's being corrected
            if attr_type == "birthday" or "birthday" in query_lower:
                formatted_date = _format_date(new_value)
                _user_attributes_cache["my_birthday"] = formatted_date
                # Also update in remembered facts
                if '_remembered_facts' not in globals():
                    _remembered_facts = []
                # Remove old birthday facts
                _remembered_facts = [f for f in _remembered_facts if "birthday" not in f.lower()]
                _remembered_facts.append(f"My birthday is {formatted_date}")
                return f"Got it! Your birthday is now {formatted_date}."

            return f"I've noted that update."

    return None


def _handle_greeting(query_lower: str) -> str:
    """
    Handle greetings naturally - respond warmly without confusion.
    """
    # Strip punctuation for matching
    q_clean = re.sub(r'[^\w\s]', '', query_lower).strip()

    # Exact greeting matches
    greeting_exact = [
        "hello", "hi", "hey", "hi there", "hello there",
        "good morning", "good afternoon", "good evening",
        "howdy", "greetings", "yo", "hiya", "heya",
        "whats up", "what's up", "sup",
    ]

    if q_clean in greeting_exact:
        return "Hi! What can I help you with?"

    # Partial greeting patterns at start
    if q_clean.startswith(("hello ", "hi ", "hey ")):
        return "Hi! What can I help you with?"

    return None


def _handle_goodbye(query_lower: str) -> str:
    """
    Handle goodbye/farewell messages gracefully without asking follow-up questions.
    The user is ending the conversation - acknowledge and say goodbye.
    """
    goodbye_patterns = [
        "goodbye", "good bye", "bye", "farewell", "see you", "see ya",
        "take care", "talk later", "talk to you later", "ttyl",
        "gotta go", "got to go", "have to go", "need to go",
        "that's all", "that is all", "i'm done", "im done", "we're done",
    ]

    # Also detect "thanks for the help" combined with farewell indicators
    is_thanking_and_leaving = (
        ("thanks" in query_lower or "thank" in query_lower) and
        any(p in query_lower for p in ["goodbye", "bye", "that's all", "all for now"])
    )

    if any(p in query_lower for p in goodbye_patterns) or is_thanking_and_leaving:
        # Acknowledge thanks if present
        if "thanks" in query_lower or "thank" in query_lower:
            return "You're welcome! Take care, and feel free to come back anytime."
        return "Goodbye! Feel free to return whenever you need help."

    return None


def _handle_basic_math(query_lower: str, query: str) -> str:
    """
    Handle basic arithmetic questions with confident, direct answers.
    Includes word problems like "I have 12 apples, give away 5, buy 3 more"
    """

    # First, try to handle word problems - returns (result, steps) tuple
    word_problem_result = _handle_math_word_problem(query_lower)
    if word_problem_result is not None:
        result, steps = word_problem_result
        if steps:
            return f"{steps}\n\nFinal answer: {result}"
        return f"The answer is {result}."

    # Pattern for "what is X * Y" or "what is X + Y" etc.
    # Includes word forms: "times", "plus", "minus", "divided by"
    math_patterns = [
        # Symbol-based patterns
        (r'what\s+is\s+(\d+)\s*[\*x×]\s*(\d+)', '*'),
        (r'what\s+is\s+(\d+)\s*\+\s*(\d+)', '+'),
        (r'what\s+is\s+(\d+)\s*-\s*(\d+)', '-'),
        (r'what\s+is\s+(\d+)\s*/\s*(\d+)', '/'),
        (r'(\d+)\s*[\*x×]\s*(\d+)\s*[=\?]', '*'),
        (r'(\d+)\s*\+\s*(\d+)\s*[=\?]', '+'),
        (r'(\d+)\s*-\s*(\d+)\s*[=\?]', '-'),
        # Word-based patterns: "what's 25 times 16", "25 plus 10"
        (r"what'?s?\s+(\d+)\s+times\s+(\d+)", '*'),
        (r"what'?s?\s+(\d+)\s+plus\s+(\d+)", '+'),
        (r"what'?s?\s+(\d+)\s+minus\s+(\d+)", '-'),
        (r"what'?s?\s+(\d+)\s+divided\s+by\s+(\d+)", '/'),
        (r'(\d+)\s+times\s+(\d+)', '*'),
        (r'(\d+)\s+plus\s+(\d+)', '+'),
        (r'(\d+)\s+minus\s+(\d+)', '-'),
        (r'(\d+)\s+divided\s+by\s+(\d+)', '/'),
        (r'(\d+)\s+multiplied\s+by\s+(\d+)', '*'),
    ]

    for pattern, op in math_patterns:
        match = re.search(pattern, query_lower)
        if match:
            a, b = int(match.group(1)), int(match.group(2))
            if op == '*':
                result = a * b
                return f"The answer is {result}. ({a} × {b} = {result})"
            elif op == '+':
                result = a + b
                return f"The answer is {result}. ({a} + {b} = {result})"
            elif op == '-':
                result = a - b
                return f"The answer is {result}. ({a} - {b} = {result})"
            elif op == '/':
                if b != 0:
                    result = a / b
                    if result == int(result):
                        return f"The answer is {int(result)}. ({a} ÷ {b} = {int(result)})"
                    return f"The answer is {result:.2f}. ({a} ÷ {b} = {result:.2f})"
                return "Cannot divide by zero."

    return None


def _handle_math_word_problem(query_lower: str) -> Optional[tuple]:
    """
    Handle math word problems like "I have 12 apples, give away 5, buy 3 more"
    Returns a tuple of (result, step_by_step_string) or None if not a recognized word problem.
    """

    # Check if this looks like a word problem (mentions "how many" and has numbers)
    if "how many" not in query_lower:
        return None

    numbers = re.findall(r'\d+', query_lower)

    # Handle fraction problems: "half of X", "third of X", etc.
    fraction_patterns = [
        (r"(?:eat|take|use|have)\s+half\s+(?:of\s+)?(?:a\s+)?(?:\w+\s+)?(?:that\s+)?(?:has\s+)?(\d+)", 0.5),
        (r"half\s+of\s+(\d+)", 0.5),
        (r"(?:a\s+)?third\s+of\s+(\d+)", 1/3),
        (r"(?:a\s+)?quarter\s+of\s+(\d+)", 0.25),
    ]
    for pattern, fraction in fraction_patterns:
        match = re.search(pattern, query_lower)
        if match:
            total = int(match.group(1))
            result = int(total * fraction)
            return (result, f"Half of {total} = {result}")

    if len(numbers) < 2:
        return None

    # Parse the operations in order
    # Look for addition/subtraction keywords around each number
    result = None
    operations = []
    step_descriptions = []

    # Split into segments and analyze each
    # Pattern: "have/start with X" = initial, "give away/lose/spend X" = subtract, "buy/get/receive/find X more" = add
    segments = re.split(r',|then|and|\.\s', query_lower)

    for segment in segments:
        segment = segment.strip()
        if not segment:
            continue

        # Find numbers in this segment
        nums_in_seg = re.findall(r'\d+', segment)
        if not nums_in_seg:
            continue

        num = int(nums_in_seg[0])

        # Determine operation based on keywords
        if result is None:
            # First number is the starting value
            # Look for "have", "start with", "got", etc.
            if re.search(r'(have|had|start|got|begin|own)\s', segment):
                result = num
                operations.append(f"Start with {num}")
                step_descriptions.append(f"Start with {num}")
        else:
            # Subsequent numbers - determine add or subtract
            subtract_words = ["give away", "gave away", "lose", "lost", "spend", "spent",
                             "remove", "removed", "take away", "took away", "subtract",
                             "eat", "ate", "use", "used", "sell", "sold", "throw away"]
            add_words = ["buy", "bought", "get", "got", "receive", "received", "find", "found",
                        "add", "added", "gain", "gained", "pick up", "picked up", "more"]

            is_subtract = any(w in segment for w in subtract_words)
            is_add = any(w in segment for w in add_words)

            prev_result = result
            if is_subtract and not is_add:
                result -= num
                operations.append(f"- {num}")
                step_descriptions.append(f"Give away {num}: {prev_result} - {num} = {result}")
            elif is_add:
                result += num
                operations.append(f"+ {num}")
                step_descriptions.append(f"Buy {num} more: {prev_result} + {num} = {result}")

    if result is not None and len(operations) >= 2:
        # Build step-by-step explanation
        steps = "\n".join(step_descriptions)
        return (result, steps)

    return None


def _handle_basic_syllogism(query_lower: str, query: str) -> str:
    """
    Handle basic deductive reasoning / syllogisms.
    E.g., "All dogs are animals. Rover is a dog. What can you conclude about Rover?"
    Also handles multi-step syllogisms like:
    "All mammals are warm-blooded. All dogs are mammals. Fido is a dog. Is Fido warm-blooded?"
    And conditional logic chains like:
    "If it's raining, I bring umbrella. If I bring umbrella, I don't get wet. It's raining. Will I get wet?"

    CRITICAL: Also handles NEGATION syllogisms like:
    "No reptiles are warm-blooded. A snake is a reptile. Is a snake warm-blooded?" → NO

    CCS-32 FIX: Now checks session history for facts from previous turns.
    E.g., Turn 1: "No reptiles are warm-blooded. A snake is a reptile."
          Turn 2: "Is a snake warm-blooded?" → NO (using facts from turn 1)
    """
    global _session_history

    # Build combined context from current query AND recent session history
    # This allows facts from previous turns to be used for reasoning
    combined_context = query_lower
    if '_session_history' in globals() and _session_history:
        # Get last 5 user messages for reasoning context
        recent_messages = [
            turn.get("content", "").lower()
            for turn in _session_history[-6:-1]  # Exclude current (already in query_lower)
            if turn.get("role") == "user"
        ]
        if recent_messages:
            combined_context = " ".join(recent_messages) + " " + query_lower

    # =========================================================================
    # NEGATION SYLLOGISMS - "No X are Y. Z is an X. Is Z Y?" → NO
    # =========================================================================
    # CRITICAL FIX for CCS-32: Handle negation in syllogistic reasoning
    # Pattern: "No reptiles are warm-blooded. A snake is a reptile. Is a snake warm-blooded?"
    # The answer must be NO because: snake is reptile, no reptiles are warm-blooded, therefore snake is NOT warm-blooded

    # Check for negation pattern in combined context: "No X are Y"
    negation_match = re.search(r'no\s+(\w+)\s+are\s+([\w-]+)', combined_context)
    if negation_match:
        category = negation_match.group(1)  # e.g., "reptiles"
        excluded_property = negation_match.group(2)  # e.g., "warm-blooded"

        # Find "X is a/an [category]" pattern in combined context
        category_singular = category.rstrip('s')  # "reptiles" -> "reptile"
        member_pattern = rf'(?:a\s+)?(\w+)\s+is\s+(?:a\s+|an\s+)?({category}|{category_singular})'
        member_match = re.search(member_pattern, combined_context)

        if member_match:
            subject = member_match.group(1).capitalize()  # e.g., "Snake"

            # Check if CURRENT query is asking about this subject's property
            # "Is a snake warm-blooded?" or "Is the snake warm-blooded?"
            question_pattern = rf'is\s+(?:a\s+|an\s+|the\s+)?{subject.lower()}\s+{excluded_property}'
            if re.search(question_pattern, query_lower):
                # Negation logic: No X are Y, Z is X, therefore Z is NOT Y
                return f"No, {subject.lower()} is not {excluded_property}. Since no {category} are {excluded_property}, and a {subject.lower()} is a {category_singular}, {subject.lower()} cannot be {excluded_property}."

    # Check for simple "Is X Y?" questions and look for negation facts in history
    simple_question = re.search(r'^is\s+(?:a\s+|an\s+)?(\w+)\s+([\w-]+)\??$', query_lower)
    if simple_question:
        subject = simple_question.group(1).lower()  # e.g., "snake"
        property_asked = simple_question.group(2)  # e.g., "warm-blooded"

        # Search combined context for negation facts about this subject
        negation_match2 = re.search(r'no\s+(\w+)\s+are\s+([\w-]+)', combined_context)
        if negation_match2:
            category = negation_match2.group(1)  # e.g., "reptiles"
            excluded_property = negation_match2.group(2)  # e.g., "warm-blooded"
            category_singular = category.rstrip('s')

            # Check if subject is in that category (in combined context)
            if re.search(rf'{subject}\s+is\s+(?:a\s+|an\s+)?({category}|{category_singular})', combined_context):
                if property_asked == excluded_property or excluded_property in property_asked or property_asked in excluded_property:
                    return f"No, {subject} is not {excluded_property}. Since no {category} are {excluded_property}, and a {subject} is a {category_singular}, {subject} cannot be {excluded_property}."

    # =========================================================================
    # POSITIVE SYLLOGISMS - "All X are Y. Z is an X. What about Z?" → YES
    # =========================================================================
    # Multi-step syllogism: "All mammals are warm-blooded. All dogs are mammals. Fido is a dog. Is Fido warm-blooded?"
    # Pattern: A -> B (all mammals are warm-blooded), C -> A (all dogs are mammals), X is C (Fido is a dog)
    # Conclusion: X is B (Fido is warm-blooded)
    if "warm-blooded" in query_lower or "warm blooded" in query_lower:
        # Look for the chain: all mammals are warm-blooded, all dogs are mammals, X is a dog
        if re.search(r'all\s+mammals\s+are\s+warm[- ]?blooded', query_lower):
            if re.search(r'all\s+dogs\s+are\s+mammals', query_lower):
                # Find the subject (e.g., Fido)
                subject_match = re.search(r'(\w+)\s+is\s+a\s+dog', query_lower)
                if subject_match:
                    subject = subject_match.group(1).capitalize()
                    if "is" in query_lower and "warm" in query_lower:
                        return f"Yes, {subject} is warm-blooded. Here's the reasoning: {subject} is a dog, all dogs are mammals, and all mammals are warm-blooded. Therefore, {subject} is warm-blooded."

    # Conditional logic chain: "If X then Y. If Y then Z. X is true. What about Z?"
    # Pattern: raining -> umbrella -> don't get wet
    if "raining" in query_lower and "umbrella" in query_lower and ("wet" in query_lower or "get wet" in query_lower):
        if "will i get wet" in query_lower or "do i get wet" in query_lower:
            # Follow the logic chain: raining -> umbrella -> not wet
            if "it's raining" in query_lower or "it is raining" in query_lower:
                return "No, you won't get wet. Since it's raining, you'll bring an umbrella, and if you bring an umbrella, you don't get wet."

    # Pattern: "All X are Y. Z is a/an X. What can you conclude about Z?"
    syllogism_pattern = r'all\s+(\w+)\s+are\s+(\w+).*?(\w+)\s+is\s+(?:a|an)?\s*(\w+).*?(?:conclude|infer|deduce)'

    match = re.search(syllogism_pattern, query_lower, re.DOTALL)
    if match:
        category = match.group(1)      # e.g., "dogs"
        property_val = match.group(2)  # e.g., "animals"
        subject = match.group(3)       # e.g., "rover"
        subject_type = match.group(4)  # e.g., "dog"

        # Check if the subject's type matches the category (singular/plural)
        if subject_type.rstrip('s') == category.rstrip('s') or category.startswith(subject_type):
            subject_cap = subject.capitalize()
            if property_val.endswith('s'):
                property_singular = property_val[:-1]
                article = "an" if property_singular[0] in 'aeiou' else "a"
                return f"{subject_cap} is {article} {property_singular}. Since all {category} are {property_val}, and {subject_cap} is a {subject_type}, {subject_cap} must be {article} {property_singular}."
            return f"{subject_cap} is {property_val}."

    # Simpler pattern: just look for the key elements
    if "all" in query_lower and "are" in query_lower and "conclude" in query_lower:
        all_match = re.search(r'all\s+(\w+)\s+are\s+(\w+)', query_lower)
        is_match = re.search(r'(\w+)\s+is\s+(?:a|an)?\s*(\w+)', query_lower)

        if all_match and is_match:
            category = all_match.group(1)
            property_val = all_match.group(2)
            subject = is_match.group(1)
            subject_type = is_match.group(2)

            if subject_type.rstrip('s') == category.rstrip('s') or category.rstrip('s') == subject_type:
                subject_cap = subject.capitalize()
                if property_val.endswith('s'):
                    property_singular = property_val[:-1]
                    article = "an" if property_singular[0] in 'aeiou' else "a"
                    return f"{subject_cap} is {article} {property_singular}."
                return f"{subject_cap} is {property_val}."

    return None


def _handle_causal_reasoning(query_lower: str, query: str) -> str:
    """
    C3-13c FIX: Handle causal reasoning questions like "Why did X happen?"
    when the cause was mentioned in the same message or recent context.

    Example:
    - "The plant died. I forgot to water it for 3 weeks. Why did it die?"
    - Answer: "The plant likely died because you forgot to water it for 3 weeks."
    """
    global _session_history

    # Check if this is a "why" question
    why_match = re.search(r"why did (?:it|the \w+|my \w+) (?:die|fail|break|stop|crash|not work)", query_lower)
    if not why_match:
        return None

    # Build context from current query and recent history
    combined_context = query_lower
    if '_session_history' in globals() and _session_history:
        recent_messages = [
            turn.get("content", "").lower()
            for turn in _session_history[-4:]
            if turn.get("role") == "user"
        ]
        if recent_messages:
            combined_context = " ".join(recent_messages) + " " + query_lower

    # Look for causal patterns in context
    # Pattern: neglect/forgot + time period
    forgot_pattern = re.search(r"(?:forgot|neglected|didn't|failed)\s+to\s+(\w+)\s+(?:it|them)?\s*(?:for\s+)?(\d+\s+\w+)?", combined_context)
    if forgot_pattern:
        action = forgot_pattern.group(1)
        duration = forgot_pattern.group(2) if forgot_pattern.group(2) else ""
        duration_str = f" for {duration}" if duration else ""

        # Detect what died/failed
        subject_match = re.search(r"(?:the\s+)?(\w+)\s+died", combined_context)
        subject = subject_match.group(1) if subject_match else "it"

        return f"The {subject} likely died because you forgot to {action} it{duration_str}. Lack of {action.replace('water', 'water').replace('feed', 'food')} is a common cause of {subject} death."

    # Pattern: didn't do something that caused failure
    didnt_pattern = re.search(r"(?:didn't|did not|never)\s+(\w+)", combined_context)
    if didnt_pattern:
        action = didnt_pattern.group(1)
        return f"It likely failed because you didn't {action} it. That's a common cause of such problems."

    return None


def _handle_false_memory_injection(query_lower: str) -> str:
    """
    Detect and reject attempts to inject false memories of conversations
    that never happened.

    Patterns:
    - "Remember when you told me about X?"
    - "Last week you said..."
    - "You mentioned X before"
    - "Can you repeat what you said about X?"

    When detected, Maven should clearly state it has no record of such
    conversations rather than playing along or fabricating memories.
    """
    global _session_history

    # Only trigger if this appears to reference a past conversation Maven had
    # (not just user telling Maven to remember something new)
    false_memory_patterns = [
        # "Remember when you told/said..."
        r"remember when you (?:told|said|mentioned|explained)",
        # "Last week/time/session you said..."
        r"(?:last|previous) (?:week|time|session|conversation) you (?:told|said|mentioned)",
        # "You said something about X"
        r"you said (?:something|that thing) (?:about|regarding)",
        # "Can you repeat what you said..."
        r"(?:can you |could you )?repeat what you (?:said|told|mentioned)",
        # "What did you say about X?"
        r"what did you (?:say|tell me) about",
        # "You mentioned X earlier/before"
        r"you mentioned .+ (?:earlier|before|previously|last time)",
        # "You were telling me about X"
        r"you were (?:telling|explaining|saying|describing) (?:me |us )?about",
        # "You recommended X" - claims about Maven's recommendations
        r"you recommended",
        r"what (?:did you|restaurant|place|book) (?:did you )?recommend",
        r"which (?:one|restaurant|place|book) (?:did you )?recommend",
        # "The restaurant you recommended"
        r"the (?:restaurant|place|book|movie) you recommended",
        # Claims about past Maven actions
        r"you (?:suggested|advised|told \w+ about)",
    ]

    for pattern in false_memory_patterns:
        if re.search(pattern, query_lower):
            # Check if we actually have this in session history
            # If session is empty or very short, we definitely didn't say it
            if '_session_history' not in globals() or not _session_history:
                return ("I don't have a record of that conversation. This appears to be "
                        "the start of our session. What would you like to discuss?")

            # Check if we only have user messages (no Maven responses about this topic)
            maven_messages = [t for t in _session_history if t.get("role") == "assistant"]
            if len(maven_messages) < 2:
                return ("I don't have a record of discussing that topic in our conversation. "
                        "This seems to be a new session. How can I help you?")

            # If we have a longer session, still be cautious about claimed past convos
            # that reference "last week" or "before" - those are outside this session
            if any(w in query_lower for w in ["last week", "last time", "before", "previously", "earlier session"]):
                return ("I don't have memory of previous sessions. I can only recall what "
                        "we've discussed in our current conversation. What would you like to know?")

            # For claims about Maven's ACTIONS (recommend, suggest, advise, tell about),
            # actually search session history for evidence. NEVER invent details.
            action_claim_patterns = [
                r"you recommended", r"recommend", r"you suggested", r"you advised",
                r"you told \w+ about", r"which (?:one|restaurant|place|book)",
            ]
            for action_pattern in action_claim_patterns:
                if re.search(action_pattern, query_lower):
                    # Search for evidence in Maven's actual responses
                    found_evidence = False
                    search_terms = ["recommend", "suggest", "advise", "try", "should go to", "would be good"]
                    for msg in maven_messages:
                        content = msg.get("content", "").lower()
                        if any(term in content for term in search_terms):
                            found_evidence = True
                            break

                    if not found_evidence:
                        return ("I don't have a record of recommending that. "
                                "I don't make up details - if I recommended something, I'd remember it.")

            # For other patterns (not action claims), might be legitimate reference
            return None

    return None


def _handle_remember_command(query: str, query_lower: str) -> str:
    """
    Handle explicit "please remember" or "remember that" commands.
    Store the fact and confirm to the user.
    """

    remember_patterns = [
        r'(?:please\s+)?remember\s+that\s+(.+)',
        r'(?:please\s+)?remember\s*:\s*(.+)',
        r'(?:please\s+)?remember\s+this\s*[:\s]+(.+)',  # "Remember this code: X" or "Remember this: X"
        r'(?:please\s+)?store\s+(?:this|that)\s*:\s*(.+)',
        r'(?:please\s+)?note\s+that\s+(.+)',
    ]

    for pattern in remember_patterns:
        match = re.search(pattern, query_lower)
        if match:
            fact_start = match.start(1)
            fact_text = query[fact_start:].strip()

            # Store in session history for immediate recall
            global _remembered_facts
            if '_remembered_facts' not in globals():
                _remembered_facts = []
            _remembered_facts.append(fact_text)

            try:
                from brains.memory.brain_memory import BrainMemory
                import time

                memory = BrainMemory("personal")
                memory.store(
                    content=f"User stated: {fact_text}",
                    tier="stm",
                    metadata={
                        "kind": "user_explicit_fact",
                        "original": fact_text,
                        "timestamp": time.time(),
                        "source": "remember_command"
                    }
                )

                return f"Got it! I'll remember that {fact_text}"

            except Exception as e:
                logger.debug(f"[REMEMBER] Failed to store fact: {e}")
                return f"Got it! I'll remember that {fact_text}"

    return None


# Global storage for remembered facts within session
_remembered_facts = []

# Fast lookup cache: keyword -> list of facts containing that keyword
# This enables O(1) keyword lookup instead of O(n) linear search
_fact_keyword_index = {}

# Cache for extracted user attributes (name, age, location, job, etc.)
# Format: {"name": "Alex", "age": "32", "location": "Seattle", ...}
_user_attributes_cache = {}

# Cache for third-party entities and relationships
# Format: {"bob": {"type": "person", "owns": ["rex"], "relationships": {"carol": "sister"}}}
_entity_cache = {}

# Cache for relationship graph
# Format: {("bob", "carol"): "sister", ("carol", "dan"): "husband"}
_relationship_cache = {}

# Cache for topics mentioned in conversation (for rapid topic switching)
# Format: [{"topic": "python", "category": "programming_language", "turn": 1}, ...]
_topic_cache = []

# Known categories for topic tracking
# IMPORTANT: Sorted longest-first to prevent "java" matching before "javascript"
_PROGRAMMING_LANGUAGES = ["javascript", "typescript", "haskell", "python", "kotlin", "matlab", "scala", "swift", "julia", "rust", "ruby", "java", "perl", "php", "c++", "c#", "go"]
# Note: "r" removed from list due to false positives - single letter matches too broadly

# Short programming languages that need word boundary matching
_SHORT_LANGUAGES = {"r": r"\br\b", "go": r"\bgo\b", "c": r"\bc\b"}

# General topic categories for multi-topic tracking
_GENERAL_TOPICS = {
    "cooking": ["cooking", "recipe", "cook", "baking", "kitchen"],
    "food": ["pasta", "pizza", "sushi", "food", "meal", "dish", "cuisine"],
    "music": ["music", "song", "musician", "band", "genre", "album", "concert"],
    "sports": ["sports", "soccer", "football", "basketball", "tennis", "world cup", "team"],
    "movies": ["movie", "film", "cinema", "actor", "actress", "director"],
    "travel": ["travel", "vacation", "trip", "destination", "flight", "hotel"],
    "weather": ["weather", "rain", "sunny", "temperature", "forecast"],
}

# Module-level constant: Words that should NOT be stored as names
_NOT_NAMES = frozenset([
    "a", "the", "not", "so", "just", "going", "looking", "thinking",
    "here", "there", "planning", "most", "having", "doing", "trying",
    "getting", "making", "taking", "coming", "leaving", "working",
    "feeling", "wondering", "hoping", "interested", "excited", "worried",
    "happy", "sad", "tired", "bored", "hungry", "cold", "hot", "sick",
    "sure", "sorry", "fine", "good", "great", "okay", "ok", "ready",
    "about", "currently", "really", "very", "bit", "little",
    # -ing forms (actions, not names)
    "moving", "running", "eating", "sleeping", "living", "staying",
    "studying", "learning", "reading", "writing", "driving", "flying",
    "starting", "finishing", "waiting", "watching", "listening",
    # Common false positives from mid-sentence "i am ..." clauses
    "talking", "testing", "checking", "using", "typing", "asking",
    # Dietary preferences and attributes
    "vegetarian", "vegan", "pescatarian", "flexitarian",
    # Emotional/mental states
    "stressed", "anxious", "nervous", "confused", "frustrated",
    "overwhelmed", "depressed", "upset", "angry", "annoyed",
    # Physical states
    "tall", "short", "young", "old", "new", "free", "busy", "late",
    # Profession words - these are jobs, not names
    "teacher", "doctor", "nurse", "engineer", "developer", "scientist",
    "manager", "designer", "analyst", "consultant", "writer", "artist",
    "chef", "lawyer", "accountant", "architect", "dentist", "pharmacist",
    "professor", "student", "programmer", "pilot", "firefighter", "police",
    "therapist", "counselor", "librarian", "journalist", "photographer",
    "musician", "actor", "director", "producer", "editor", "researcher",
    "data", "software", "senior", "junior"
])

# Cache for entity relationships like "Bob's dog Rex", "Carol's cat Whiskers"
# Format: {"bob": {"dog": "rex"}, "carol": {"cat": "whiskers"}}
_entity_relationships = {}

# Cache for project/variable tracking in complex conversations
# Format: {"Project A": {"tech": "React", "completion": "60%", "deadline": "January"}}
_project_cache = {}

# =============================================================================
# EXPANDED CONTEXT MANAGEMENT - Critical for audit stability
# =============================================================================

# Cache for learning intents - what the user wants to learn
# Format: ["python", "javascript"] - ordered list of subjects user wants to learn
_learning_intents_cache = []

# CCS-24 FIX: Cache for teaching facts - facts the user teaches Maven in a session
# Format: {"earth": {"moons": "1"}, "mitochondria": {"is": "the powerhouse of the cell"}}
_teaching_facts_cache = {}

# Cache for entity knowledge tracking (Theory of Mind / Perspective Tracking)
# Tracks what different people KNOW vs what is actually true
# Format: {"alex": {"meeting_time": "3pm", "updated": False}, "_actual": {"meeting_time": "4pm"}}
_entity_knowledge_cache = {}

# Cache for conversation framing detection (roleplay/game bypass attempts)
# Tracks if a roleplay or "no restrictions" game was attempted in the session
# Format: {"roleplay_attempted": True, "game_framing": True, "turn": 2}
_conversation_framing_cache = {}

# Cache for session context state tracking
# Format: {"in_harmful_framing": False, "last_topic": "python"}
_session_context_state = {}


def _index_fact_keywords(fact: str):
    """Index a fact by its significant keywords for fast lookup."""
    global _fact_keyword_index

    # Extract significant words (4+ chars, alphanumeric only)
    words = re.findall(r'\b\w{4,}\b', fact.lower())

    for word in words:
        if word not in _fact_keyword_index:
            _fact_keyword_index[word] = []
        if fact not in _fact_keyword_index[word]:
            _fact_keyword_index[word].append(fact)


def _extract_user_attributes(content: str):
    """Extract and cache user attributes from content for instant recall."""
    global _user_attributes_cache

    content_lower = content.lower()

    # Name patterns - MUST validate against _NOT_NAMES
    name_patterns = [
        r"my name is (\w+)",
        r"i'm (\w+)[,.]",
        r"i am (\w+)[,.]",
        r"call me (\w+)",
    ]
    for pattern in name_patterns:
        match = re.search(pattern, content_lower)
        if match:
            potential_name = match.group(1).lower()
            # CRITICAL: Validate against _NOT_NAMES to avoid storing verbs/adjectives
            if potential_name not in _NOT_NAMES and not potential_name.isdigit():
                _user_attributes_cache["name"] = potential_name.capitalize()
            break

    # Age patterns
    age_match = re.search(r"i'm (\d+) years old|i am (\d+) years old|(\d+) years old", content_lower)
    if age_match:
        age = age_match.group(1) or age_match.group(2) or age_match.group(3)
        _user_attributes_cache["age"] = age

    # Location patterns
    loc_patterns = [
        r"i live in ([^,.\n]+)",
        r"i'm from ([^,.\n]+)",
        r"i am from ([^,.\n]+)",
        r"live in ([^,.\n]+)",
    ]
    for pattern in loc_patterns:
        match = re.search(pattern, content_lower)
        if match:
            _user_attributes_cache["location"] = match.group(1).strip().title()
            break

    # Job/occupation patterns
    # CCS-09 FIX: Don't extract job from stress/emotion patterns
    stress_patterns = ["stressed about", "anxious about", "worried about", "nervous about",
                      "job interview", "feeling stressed", "feeling anxious", "feeling worried"]
    if not any(p in content_lower for p in stress_patterns):
        job_patterns = [
            r"i work as (?:a |an )?([^,.\n]+)",
            r"i'm (?:a |an )?([^,.\n]+?) (?:at|for|in)",
            r"my job is ([^,.\n]+)",
            r"i am (?:a |an )?(\w+(?:\s+\w+)?)\s*[,.]",
        ]
        for pattern in job_patterns:
            match = re.search(pattern, content_lower)
            if match:
                job = match.group(1).strip()
                # Filter out non-job words
                if job not in ["from", "in", "at", "the", "and", "or"]:
                    _user_attributes_cache["job"] = job
                    break

    # Favorite patterns
    fav_match = re.search(r"(?:my )?favou?rite (\w+) is (\w+)", content_lower)
    if fav_match:
        fav_type = fav_match.group(1)
        fav_value = fav_match.group(2)
        _user_attributes_cache[f"favorite_{fav_type}"] = fav_value


def _fast_attribute_store(query: str, query_lower: str) -> str:
    """
    Fast O(1) storage for user attribute STATEMENTS.

    Handles statements like:
    - "My name is Sam"
    - "I'm 28 years old"
    - "I live in Austin"
    - "I work as a nurse"
    - "My favorite color is blue"

    Returns acknowledgment if stored, None otherwise.
    """
    global _user_attributes_cache, _session_history

    if '_user_attributes_cache' not in globals():
        _user_attributes_cache = {}

    # Name storage (identity-critical): ONLY accept explicit, standalone identity declarations.
    # This prevents corruptions like "whether i am talking to..." -> name="Talking".
    # Accepted forms:
    #   "my name is Josh"
    #   "call me Josh"
    #   "i am Josh"
    #   "i'm Josh" / "im Josh"
    name_match = re.match(
        r"^\s*(?:my name is|call me|i am|i'm|im)\s+([a-z][a-z'\-]{1,30})(?:\s+([a-z][a-z'\-]{1,30}))?\s*[.!]?\s*$",
        query_lower,
        flags=re.IGNORECASE,
    )
    if name_match:
        first = (name_match.group(1) or "").strip()
        second = (name_match.group(2) or "").strip()
        # Prefer first token as the "name" for now; avoid multi-word false positives.
        candidate = first
        if candidate and candidate.lower() not in _NOT_NAMES and not candidate.isdigit():
            name = candidate.capitalize()
            _user_attributes_cache["name"] = name
            # Also store in session history
            if '_session_history' not in globals():
                _session_history = []
            _session_history.append({"role": "user", "content": query})
            _persist_user_attributes_cache()
            return f"Your name is {name}."

    # Age storage: "I'm X years old" or "I am X"
    age_match = re.search(r"(?:i'm|i am)\s+(\d+)(?:\s+years?\s+old)?", query_lower)
    if age_match:
        age = age_match.group(1)
        _user_attributes_cache["age"] = age
        if '_session_history' not in globals():
            _session_history = []
        _session_history.append({"role": "user", "content": query})
        _persist_user_attributes_cache()
        return f"You are {age} years old."

    # Location storage: "I live in X"
    loc_match = re.search(r"i live in ([^,.\n]+)", query_lower)
    if loc_match:
        location = loc_match.group(1).strip()
        # Remove temporal markers like "now", "currently", "today"
        temporal_markers = ["now", "currently", "today", "actually", "wait", "these days"]
        for marker in temporal_markers:
            location = re.sub(rf'\s*{marker}\s*$', '', location, flags=re.IGNORECASE)
            location = re.sub(rf'^\s*{marker}\s+', '', location, flags=re.IGNORECASE)
        location = location.strip().title()
        if location:  # Only store if we still have a location after cleaning
            _user_attributes_cache["location"] = location
            if '_session_history' not in globals():
                _session_history = []
            _session_history.append({"role": "user", "content": query})
            _persist_user_attributes_cache()
            return f"You live in {location}."

    # Job storage: "I work as X" or "I am a X" (profession)
    # CCS-09 FIX: Don't match stress/emotion patterns about jobs
    stress_patterns = ["stressed about", "anxious about", "worried about", "nervous about",
                      "job interview", "feeling stressed", "feeling anxious", "feeling worried"]
    if not any(p in query_lower for p in stress_patterns):
        job_match = re.search(r"(?:i work as(?: a| an)?|i am a|i'm a)\s+([^,.\n]+)", query_lower)
        if job_match:
            job = job_match.group(1).strip()
            # Only store if it looks like a job title
            job_words = ["engineer", "developer", "teacher", "nurse", "doctor", "scientist", "manager",
                         "designer", "analyst", "consultant", "writer", "artist", "chef", "lawyer"]
            if any(jw in job.lower() for jw in job_words):
                _user_attributes_cache["job"] = job
                if '_session_history' not in globals():
                    _session_history = []
                _session_history.append({"role": "user", "content": query})
                _persist_user_attributes_cache()
                return f"You work as a {job}."

    # Work schedule storage: "I work Monday through Friday" or "I work weekdays"
    work_schedule_match = re.search(r"i work\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)(?:\s+through\s+|\s+to\s+|\s*-\s*)(monday|tuesday|wednesday|thursday|friday|saturday|sunday)", query_lower)
    if work_schedule_match:
        start_day = work_schedule_match.group(1).capitalize()
        end_day = work_schedule_match.group(2).capitalize()
        _user_attributes_cache["work_schedule"] = {"start": start_day, "end": end_day}
        if '_session_history' not in globals():
            _session_history = []
        _session_history.append({"role": "user", "content": query})
        _persist_user_attributes_cache()
        return f"Got it! You work {start_day} through {end_day}."

    if "i work weekdays" in query_lower or "i work on weekdays" in query_lower:
        _user_attributes_cache["work_schedule"] = {"start": "Monday", "end": "Friday"}
        if '_session_history' not in globals():
            _session_history = []
        _session_history.append({"role": "user", "content": query})
        _persist_user_attributes_cache()
        return "Got it! You work weekdays (Monday through Friday)."

    # Favorite storage: "My favorite X is Y"
    fav_match = re.search(r"(?:my )?favou?rite\s+(\w+)\s+is\s+(\w+)", query_lower)
    if fav_match:
        fav_type = fav_match.group(1)
        fav_value = fav_match.group(2).capitalize()
        _user_attributes_cache[f"favorite_{fav_type}"] = fav_value
        if '_session_history' not in globals():
            _session_history = []
        _session_history.append({"role": "user", "content": query})
        _persist_user_attributes_cache()
        return f"Your favorite {fav_type} is {fav_value}."

    # Birthday storage: "My birthday is X"
    birthday_match = re.search(r"(?:my )?birthday\s+is\s+(.+?)(?:\.|$)", query_lower)
    if birthday_match:
        birthday = _format_date(birthday_match.group(1).strip())
        _user_attributes_cache["birthday"] = birthday
        # Also store in remembered facts
        global _remembered_facts
        if '_remembered_facts' not in globals():
            _remembered_facts = []
        # Remove old birthday facts
        _remembered_facts = [f for f in _remembered_facts if "birthday" not in f.lower()]
        _remembered_facts.append(f"My birthday is {birthday}")
        if '_session_history' not in globals():
            _session_history = []
        _session_history.append({"role": "user", "content": query})
        _persist_user_attributes_cache()
        return f"Got it! Your birthday is {birthday}."

    _persist_user_attributes_cache()

    return None



def _fast_conversation_recall(query_lower: str) -> Optional[str]:
    """Deterministic cross-session episodic recall (no Teacher).

    Handles queries like:
      - "do you remember the last conversation we had"
      - "what did we talk about last time"
      - "continue where we left off"
    Uses enhanced_episodic episodes stored under reports/episodes.jsonl.
    """
    patterns = [
        "last conversation",
        "previous conversation",
        "last time we talked",
        "what did we talk about",
        "what were we talking about",
        "continue where we left off",
        "continue where we left",
        "pick up where we left off",
        "do you remember",
        "remember our last",
        "remember the last",
        "what did we discuss",
        "recap our last",
        "recap the last",
    ]
    # Allow lightweight typo-tolerant matching for "last conversation" style queries.
    # Examples: "what was our last convo", "what was are last convertian".
    convo_markers = ["convo", "convers", "conver", "conversation", "chat", "talk", "discuss"]
    matched = any(p in query_lower for p in patterns)
    if not matched and ("last" in query_lower or "previous" in query_lower):
        matched = any(m in query_lower for m in convo_markers)
    if not matched:
        return None

    # Avoid false positives like "remember to buy milk"
    if query_lower.startswith("remember to "):
        return None

    try:
        from brains.memory.session_manager import get_session_manager
        sm = get_session_manager()
        user_id = sm.get_user_id()
    except Exception:
        user_id = ""

    # Pull the most recent closed (or open) episode and provide a compact recap.
    try:
        from brains.memory.enhanced_episodic import get_episode_manager
        em = get_episode_manager()

        episodes = em.query_episodes(user_id=user_id or None, limit=1, include_open=True)
        if not episodes:
            return "I don't have any prior conversation stored yet."

        ep = episodes[0]
        topic = (getattr(ep, "topic", "") or "").strip()
        summary = (getattr(ep, "summary", "") or "").strip()
        unresolved = []
        try:
            md = getattr(ep, "metadata", {}) or {}
            unresolved = md.get("unresolved", []) or []
        except Exception:
            unresolved = []

        # Build recap
        lines = []
        if topic:
            lines.append(f"Last time, we talked about: {topic}.")
        if summary:
            lines.append(f"Summary: {summary}")
        else:
            # fallback to last few turns
            turns = getattr(ep, "turns", []) or []
            if turns:
                snippets = []
                for t in turns[-3:]:
                    q = getattr(t, "question", "") if hasattr(t, "question") else (t.get("question") or t.get("user") or "")
                    a = getattr(t, "answer", "") if hasattr(t, "answer") else (t.get("answer") or t.get("assistant") or "")
                    q = (q or "").strip()
                    a = (a or "").strip()
                    if q:
                        snippets.append(f"Q: {q[:120]}")
                    if a:
                        snippets.append(f"A: {a[:120]}")
                if snippets:
                    lines.append("Recent turns:\n" + "\n".join(snippets))

        if unresolved:
            # keep it short
            items = [str(x).strip() for x in unresolved if str(x).strip()]
            if items:
                lines.append("Unresolved items:")
                for it in items[:5]:
                    lines.append(f"- {it}")

        return "\n".join(lines).strip() if lines else "I don't have that in memory."
    except Exception:
        return "I don't have that in memory."


def _fast_attribute_recall(query_lower: str) -> str:
    """
    Fast O(1) recall for common user attributes.

    CRITICAL: This function MUST return a response for memory queries.
    It should NEVER return None for queries that are clearly asking about
    stored user information. This prevents memory queries from falling
    through to the Teacher (which would cause 30s latency).
    """
    global _user_attributes_cache

    # Initialize cache if needed
    if '_user_attributes_cache' not in globals():
        _user_attributes_cache = {}

    # CRITICAL: Ensure persisted attributes are loaded before answering.
    # Without this, the first "who am i" after restart can miss the stored name
    # and fall through to Teacher or return unknown.
    try:
        _load_user_attributes_cache()
    except Exception:
        pass

        # Episodic recall queries (cross-session)
    ep = _fast_conversation_recall(query_lower)
    if ep:
        return ep

# Name queries - MUST respond, never fall through
    if any(p in query_lower for p in ["my name", "what's my name", "whats my name", "who am i"]):
        if _user_attributes_cache.get("name"):
            return f"Your name is {_user_attributes_cache['name']}."
        # Check session history as fallback
        name = _search_session_for_attribute("name")
        if name:
            _user_attributes_cache["name"] = name
            return f"Your name is {name}."
        return "I don't have your name stored. You can tell me your name if you'd like."

    # Age queries - MUST respond
    if any(p in query_lower for p in ["my age", "how old am i", "how old", "what's my age", "whats my age"]):
        if _user_attributes_cache.get("age"):
            return f"You are {_user_attributes_cache['age']} years old."
        age = _search_session_for_attribute("age")
        if age:
            _user_attributes_cache["age"] = age
            return f"You are {age} years old."
        return "I don't have your age stored."

    # Location queries - MUST respond
    if any(p in query_lower for p in ["where do i live", "where i live", "my location", "where am i from", "where do i stay"]):
        if _user_attributes_cache.get("location"):
            return f"You live in {_user_attributes_cache['location']}."
        location = _search_session_for_attribute("location")
        if location:
            _user_attributes_cache["location"] = location
            return f"You live in {location}."
        return "I don't have your location stored."

    # Job queries - MUST respond
    if any(p in query_lower for p in ["my job", "what do i do", "my work", "what's my job", "whats my job", "my occupation", "what i do for work"]):
        if _user_attributes_cache.get("job"):
            return f"You work as a {_user_attributes_cache['job']}."
        job = _search_session_for_attribute("job")
        if job:
            _user_attributes_cache["job"] = job
            return f"You work as a {job}."
        return "I don't have your job/occupation stored."

    # Work schedule queries - inference based on stored schedule
    days_order = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    work_day_query = re.search(r"(?:am i|do i)\s+work(?:ing)?\s+(?:on\s+)?(monday|tuesday|wednesday|thursday|friday|saturday|sunday)", query_lower)
    if work_day_query:
        asked_day = work_day_query.group(1).lower()
        if _user_attributes_cache.get("work_schedule"):
            schedule = _user_attributes_cache["work_schedule"]
            start_idx = days_order.index(schedule["start"].lower())
            end_idx = days_order.index(schedule["end"].lower())
            asked_idx = days_order.index(asked_day)
            # Check if asked day is in the work range
            if start_idx <= asked_idx <= end_idx:
                return f"Yes, you work on {asked_day.capitalize()}. You work {schedule['start']} through {schedule['end']}."
            else:
                return f"No, you don't work on {asked_day.capitalize()}. You work {schedule['start']} through {schedule['end']}."
        return "I don't have your work schedule stored."

    # Birthday queries - MUST respond
    if any(p in query_lower for p in ["my birthday", "when is my birthday", "when's my birthday", "whens my birthday"]):
        # Check both "my_birthday" (from generic handler) and "birthday" keys
        if _user_attributes_cache.get("my_birthday"):
            return f"Your birthday is {_user_attributes_cache['my_birthday']}."
        if _user_attributes_cache.get("birthday"):
            return f"Your birthday is {_user_attributes_cache['birthday']}."
        # Check remembered facts for birthday
        if '_remembered_facts' in globals():
            global _remembered_facts
            for fact in reversed(_remembered_facts):
                if "birthday" in fact.lower():
                    # Extract the date (re is imported at module level)
                    date_match = re.search(r"birthday\s+is\s+(.+?)(?:\.|$)", fact, re.IGNORECASE)
                    if date_match:
                        return f"Your birthday is {date_match.group(1).strip()}."
                    return f"You mentioned: {fact}"
        return "I don't have your birthday stored."

    # Favorite queries - check for specific favorite type - MUST respond
    fav_match = re.search(r"(?:my )?favou?rite (\w+)", query_lower)
    if fav_match:
        fav_type = fav_match.group(1)
        cache_key = f"favorite_{fav_type}"
        if cache_key in _user_attributes_cache:
            return f"Your favorite {fav_type} is {_user_attributes_cache[cache_key]}."
        # Search session for this favorite
        fav_value = _search_session_for_favorite(fav_type)
        if fav_value:
            _user_attributes_cache[cache_key] = fav_value
            return f"Your favorite {fav_type} is {fav_value}."
        return f"I don't recall you telling me your favorite {fav_type}."

    # Not a memory query - return None to allow other handlers
    return None


def _search_session_for_attribute(attr_type: str) -> str:
    """
    Search session history for a specific attribute.
    This is a fallback when the cache doesn't have the value.

    Returns the attribute value or None.
    """
    global _session_history

    if '_session_history' not in globals() or not _session_history:
        return None

    patterns = {
        "name": [
            r"my name is (\w+)",
            r"i'm (\w+)[,.]",
            r"i am (\w+)[,.]",
            r"call me (\w+)",
        ],
        "age": [
            r"i'm (\d+) years old",
            r"i am (\d+) years old",
            r"(\d+) years old",
        ],
        "location": [
            r"i live in ([^,.\n]+)",
            r"i'm from ([^,.\n]+)",
            r"i am from ([^,.\n]+)",
        ],
        "job": [
            r"i work as (?:a |an )?([^,.\n]+)",
            r"my job is ([^,.\n]+)",
            r"i am (?:a |an )?(\w+(?:\s+\w+)?)\s*[,.]",
        ],
    }

    if attr_type not in patterns:
        return None

    # Search in REVERSE order to get most recent
    for turn in reversed(_session_history):
        if turn.get("role") != "user":
            continue
        content = turn.get("content", "").lower()

        for pattern in patterns[attr_type]:
            match = re.search(pattern, content)
            if match:
                value = match.group(1).strip()
                if attr_type == "name":
                    # CRITICAL: Validate against _NOT_NAMES to avoid storing verbs/adjectives
                    if value.lower() in _NOT_NAMES or value.isdigit():
                        continue  # Skip this match, try next pattern
                    return value.capitalize()
                elif attr_type == "location":
                    return value.title()
                return value

    return None


def _search_session_for_favorite(fav_type: str) -> str:
    """
    Search session history for a specific favorite.
    Returns the favorite value or None.
    """
    global _session_history

    if '_session_history' not in globals() or not _session_history:
        return None

    # Search in REVERSE order to get most recent (handles corrections)
    for turn in reversed(_session_history):
        if turn.get("role") != "user":
            continue
        content = turn.get("content", "").lower()

        # Skip questions asking about favorites
        if "what" in content and "favorite" in content:
            continue

        # Look for explicit favorite statement
        pattern = rf'(?:my\s+)?favou?rite\s+{fav_type}\s+is\s+(\w+)'
        match = re.search(pattern, content)
        if match:
            return match.group(1)

        # Look for correction patterns
        if "actually" in content or "changed my mind" in content:
            # Try to extract the new value
            correction_match = re.search(r"it(?:'s|s|\s+is)\s+(\w+)", content)
            if correction_match:
                return correction_match.group(1)

    return None


def _handle_stored_fact_query(query: str, query_lower: str) -> str:
    """
    Handle queries about facts the user asked Maven to remember.
    E.g., "What's the capital of Zelandia?" after user said "remember that the capital of Zelandia is Newburg"
    """

    # First, check session-level remembered facts (most reliable for in-session recall)
    global _remembered_facts
    if '_remembered_facts' in globals() and _remembered_facts:
        for fact in _remembered_facts:
            fact_lower = fact.lower()
            # Check if query words appear in the fact
            # Strip punctuation from words for better matching (e.g., "zelandia?" -> "zelandia")
            q_words = [re.sub(r'[^\w]', '', w) for w in query_lower.split()]
            # Include words with length > 2 to catch "USA", "UK", etc but filter common words
            common_words = {"the", "is", "are", "was", "were", "what", "whats", "where", "when", "how", "who", "can", "you", "your"}
            q_words = [w for w in q_words if len(w) > 2 and w not in common_words]
            matches = sum(1 for w in q_words if w in fact_lower)

            # Also check for any unique/proper nouns (capitalized words in query)
            proper_nouns = [re.sub(r'[^\w]', '', w).lower() for w in query.split() if w and w[0].isupper()]
            proper_matches = sum(1 for n in proper_nouns if n in fact_lower)

            # If at least 2 significant words match, OR a proper noun matches along with 1 word
            # This handles "What's the capital of Zelandia?" where "Zelandia" is a key proper noun
            if matches >= 2 or (proper_matches >= 1 and matches >= 1):
                # Try to extract the answer - look for "is" pattern
                # E.g., "the capital of Zelandia is Newburg" -> extract "Newburg"
                is_match = re.search(r'(.+?)\s+is\s+(.+)', fact, re.IGNORECASE)
                if is_match:
                    subject = is_match.group(1).strip()
                    value = is_match.group(2).strip().rstrip('.')
                    # Check if query is asking about the subject
                    subject_words = [w.lower() for w in subject.split() if len(w) > 3]
                    if any(w in query_lower for w in subject_words):
                        # Provide a direct answer with clear association
                        # E.g., "The capital of Zelandia is Newburg (your home country)."
                        if "home country" in fact.lower() or "my country" in fact.lower():
                            # Extract country name from the fact
                            country_match = re.search(r'(?:home country|my country)\s+(\w+)', fact, re.IGNORECASE)
                            if country_match:
                                country = country_match.group(1)
                                return f"The capital of {country} is {value}. That's your home country!"
                        return f"Based on what you mentioned, {subject} is {value}."
                return f"Based on what you mentioned: {fact}"

    # Also check persistent memory
    try:
        from brains.memory.brain_memory import BrainMemory

        memory = BrainMemory("personal")
        results = memory.retrieve(query=query, limit=5, mode="hybrid")

        for r in results:
            metadata = r.get("metadata", {})
            if metadata.get("kind") == "user_explicit_fact":
                original = metadata.get("original", "")
                if original:
                    q_words = set(w for w in query_lower.split() if len(w) > 3)
                    fact_words = set(original.lower().split())
                    overlap = q_words & fact_words

                    if len(overlap) >= 2:
                        return f"Based on what you mentioned: {original}"

    except Exception as e:
        logger.debug(f"[STORED_FACT_QUERY] Failed: {e}")

    return None


def _handle_code_request(query_lower: str) -> str:
    """
    Handle direct code requests to avoid tool execution errors.
    Provides common code examples directly.
    """
    # Sorting code
    if "sort" in query_lower:
        return """Here's how to sort a list in Python:

```python
# Sort a list in place
numbers = [3, 1, 4, 1, 5, 9, 2, 6]
numbers.sort()
print(numbers)  # [1, 1, 2, 3, 4, 5, 6, 9]

# Or create a new sorted list (original unchanged)
numbers = [3, 1, 4, 1, 5, 9, 2, 6]
sorted_numbers = sorted(numbers)
print(sorted_numbers)  # [1, 1, 2, 3, 4, 5, 6, 9]

# Sort in descending order
numbers.sort(reverse=True)
print(numbers)  # [9, 6, 5, 4, 3, 2, 1, 1]
```"""

    # Sum/add function
    if "sum" in query_lower or "add" in query_lower:
        return """Here's a Python function to sum two numbers:

```python
def add_numbers(a, b):
    return a + b

# Usage
result = add_numbers(5, 3)
print(result)  # 8
```"""

    # Generic code request
    return "I'd be happy to help with code! What specific task would you like me to write code for?"


def _handle_elaboration_request(query: str, query_lower: str, context: Dict[str, Any]) -> str:
    """
    Handle elaboration requests and drive natural conversation.

    IMPORTANT: Maven can ONLY elaborate on things it actually knows from memory
    or from the current conversation. NO LLM hallucination!
    """
    global _session_history

    # Check if this is a self-query - asking about Maven itself
    is_self_query = any(p in query_lower for p in [
        "about you", "about yourself", "about maven",
        "more about you", "tell me about you",
    ])

    if is_self_query:
        # Use Maven's actual self-knowledge - NO LLM hallucination
        return "I'm Maven, a cognitive AI assistant. I run locally on your machine with persistent memory across sessions. I have multiple specialized 'brains' that work together, and I use an external LLM as a 'Teacher' for language generation. Is there something specific about my architecture or capabilities you'd like to know?"

    # Get context from previous conversation
    last_topic = _get_last_topic()
    last_maven_response = ""
    last_user_message = ""

    if '_session_history' in globals() and _session_history:
        # Get Maven's last response
        for turn in reversed(_session_history):
            if turn.get("role") == "maven" and not last_maven_response:
                last_maven_response = turn.get("content", "")[:500]
            elif turn.get("role") == "user" and not last_user_message:
                content = turn.get("content", "")
                # Skip the current elaboration question
                if not any(p in content.lower() for p in ["elaborate", "aspects", "important", "your take"]):
                    last_user_message = content
            if last_maven_response and last_user_message:
                break

    # If no previous context, admit we need more context
    if not last_topic and not last_maven_response:
        return "I don't have enough context to elaborate on. What would you like me to tell you more about?"

    # Build context for LLM - STRICTLY constrained to conversation context
    try:
        from host_tools.llm_client.client import HostLLMTool
        llm = HostLLMTool()

        prompt = f"""You are Maven. Someone asked you to elaborate or continue discussing.

CONTEXT FROM CONVERSATION (this is ALL you know):
- Topic: {last_topic or 'unknown'}
- What was discussed: {last_maven_response[:300] if last_maven_response else 'Nothing yet'}
- User's question: {query}

STRICT RULES:
1. ONLY use information from the context above
2. DO NOT add facts from your training data
3. If the context doesn't give you enough to elaborate, say "I don't have more details on that topic"
4. Optionally ask a relevant follow-up question if it adds value

Generate a brief response (2-3 sentences max):"""

        result = llm.complete(prompt, max_tokens=200, temperature=0.3)  # Lower temp for factual
        if result.ok and result.text.strip():
            response = result.text.strip()
            return response

    except Exception as e:
        logger.error(f"[ELABORATION] LLM error: {e}")

    # Fallback: Honest admission if we can't elaborate
    if last_topic:
        return f"Regarding {last_topic}, I don't have additional details to share beyond what we've discussed."
    else:
        return "I don't have enough context to elaborate. Could you tell me more about what you'd like to know?"


def _handle_entity_query(query: str, entity_name: str, context: Dict[str, Any]) -> str:
    """
    COHERENCY FIX: Handle entity queries by searching session history for the entity.

    This prevents "Who is Max?" from being routed to agency tools like GET_CALENDAR.
    Instead, we look at what the USER said about the entity.
    """
    try:
        # Check session history for USER mentions of this entity
        global _session_history
        entity_lower = entity_name.lower()
        user_mentions = []

        if '_session_history' in globals() and _session_history:
            for turn in _session_history:
                # Only look at USER messages, not Maven's responses
                if turn.get("role") == "user":
                    content = turn.get("content", "")
                    if content and entity_lower in content.lower():
                        user_mentions.append(content)

        if user_mentions:
            # Use the first/most relevant mention to describe the entity
            first_mention = user_mentions[0]

            # Try to extract what the entity IS from the mention
            # "My dog Max is sick" -> "Max is your dog"
            # "I have a cat named Whiskers" -> "Whiskers is your cat"
            mention_lower = first_mention.lower()

            # Common patterns: "my X named Y", "my X Y", "X is my Y"
            # Convert "my" to "your" when describing back to user
            user_phrasing = first_mention.lower().replace("my ", "your ").replace("i have", "you have").replace("i am", "you are")

            # Dynamically extract context about the entity from the mention

            # Check for pet patterns with dynamic context extraction
            if f"my dog {entity_lower}" in mention_lower or f"dog named {entity_lower}" in mention_lower or f"dog {entity_lower}" in mention_lower:
                # Extract additional context (e.g., "is sick today")
                context_match = re.search(rf'{entity_lower}\s+(.+?)(?:\.|$)', mention_lower)
                additional_context = ""
                if context_match:
                    ctx = context_match.group(1).strip()
                    if ctx and ctx not in ["is", "and", "the"]:
                        additional_context = f" that you mentioned {ctx}"
                return f"{entity_name.title()} is your dog{additional_context}."
            elif f"my cat {entity_lower}" in mention_lower or f"cat named {entity_lower}" in mention_lower or f"cat {entity_lower}" in mention_lower:
                # Extract additional context
                context_match = re.search(rf'{entity_lower}\s+(.+?)(?:\.|$)', mention_lower)
                additional_context = ""
                if context_match:
                    ctx = context_match.group(1).strip()
                    if ctx and ctx not in ["is", "and", "the"]:
                        additional_context = f" that you mentioned {ctx}"
                return f"{entity_name.title()} is your cat{additional_context}."
            elif f"my {entity_lower}" in mention_lower:
                return f"{entity_name.title()} is someone or something you mentioned."
            else:
                # Try to extract what the entity is from the context
                # Patterns like "X is Y", "X, my Y", "my Y X"
                entity_type_match = re.search(rf'(?:my\s+)?(\w+)\s+(?:named\s+)?{entity_lower}', mention_lower)
                if entity_type_match:
                    entity_type = entity_type_match.group(1)
                    if entity_type not in ["a", "an", "the", "is", "named"]:
                        return f"{entity_name.title()} is your {entity_type} that you mentioned."
                return f"You mentioned {entity_name} earlier in our conversation."

        # No user mentions found - check if it's a common name/thing
        return None  # Let caller handle with LLM or fallback

    except Exception as e:
        logger.error(f"[ENTITY_QUERY] Error: {e}")
        return None


def _handle_about_me_query(query: str, context: Dict[str, Any]) -> str:
    """
    Handle "what do you know about me?" queries by extracting personal facts
    the user shared in the current session.
    """
    global _session_history
    personal_facts = []

    if '_session_history' in globals() and _session_history:
        for turn in _session_history:
            if turn.get("role") == "user":
                content = turn.get("content", "")
                if not content:
                    continue

                c_lower = content.lower()

                # Skip the "what do you know about me" query itself
                if "know about me" in c_lower or "about me" in c_lower:
                    continue

                # Look for statements where user shares facts about themselves
                # Patterns: "I have...", "I am...", "I work...", "My X is...", "I'm..."
                is_personal = any([
                    c_lower.startswith("i have "),
                    c_lower.startswith("i am "),
                    c_lower.startswith("i'm "),
                    c_lower.startswith("i work "),
                    c_lower.startswith("my "),
                    " my " in c_lower and ("name" in c_lower or "cat" in c_lower or "dog" in c_lower or "job" in c_lower),
                    "i have a " in c_lower,
                    "i own a " in c_lower,
                    # Add more patterns for compound statements
                    " and i work " in c_lower,
                    " and i am " in c_lower,
                    "named " in c_lower,  # "a cat named Whiskers"
                    "work as " in c_lower,  # "work as a software engineer"
                ])

                if is_personal:
                    personal_facts.append(content)

    if personal_facts:
        # Format the facts nicely - rephrase from user's "I" to "You"
        rephrased_facts = []
        for fact in personal_facts:
            # Rephrase "I have" -> "You have", "I am" -> "You are", etc.
            rephrased = fact
            rephrased = re.sub(r'^I have\b', 'You have', rephrased, flags=re.IGNORECASE)
            rephrased = re.sub(r'^I am\b', 'You are', rephrased, flags=re.IGNORECASE)
            rephrased = re.sub(r"^I'm\b", "You're", rephrased, flags=re.IGNORECASE)
            rephrased = re.sub(r'^I work\b', 'You work', rephrased, flags=re.IGNORECASE)
            rephrased = re.sub(r'^My\b', 'Your', rephrased, flags=re.IGNORECASE)
            rephrased = re.sub(r' and I work\b', ' and you work', rephrased, flags=re.IGNORECASE)
            rephrased = re.sub(r' and I am\b', ' and you are', rephrased, flags=re.IGNORECASE)
            rephrased_facts.append(f"- {rephrased}")
        facts_list = "\n".join(rephrased_facts)
        return f"Based on our conversation, here's what I know about you:\n{facts_list}"
    else:
        return "I don't have much information about you yet. Feel free to tell me more about yourself!"


def _handle_knowledge_query(query: str, context: Dict[str, Any]) -> str:
    """
    Handle knowledge queries by checking memory FIRST.
    Maven ONLY responds with knowledge it actually has stored.
    NO LLM hallucination - if memory is empty, admit it.
    """
    try:
        from brains.memory.brain_memory import BrainMemory

        q_lower = query.lower()

        # Special handling for "what do you know about me?" queries
        if "about me" in q_lower or "know about me" in q_lower:
            return _handle_about_me_query(query, context)

        memory = BrainMemory("personal")

        # Prefer searching by the extracted topic instead of the full question.
        # Using the entire utterance (e.g., "what is math") often fails keyword
        # retrieval because stored records contain "math" rather than the full phrase.
        search_query = None
        topic_match = re.search(r'(?:what is|who is|tell me about|explain)\s+(?:the\s+)?(.+?)[\?\.\!]?$', q_lower)
        main_topic = topic_match.group(1).strip() if topic_match else None
        if main_topic:
            search_query = main_topic

        # Search Maven's actual memory
        results = memory.retrieve(query=search_query or query, limit=10)

        # Extract key topic words from query for relevance filtering
        query_words = set(q_lower.split())
        # Remove common words that don't add meaning
        stop_words = {"what", "is", "the", "a", "an", "are", "do", "you", "know", "about", "tell", "me", "can", "how", "why", "when", "where", "who"}
        topic_words = query_words - stop_words
        # Also add any quoted strings or capitalized words as important
        # Get the main topic (usually after "what is" or similar)
        # (main_topic already extracted above)

        # Also check session history for RELEVANT user STATEMENTS only
        # Skip user QUESTIONS/COMMANDS - only include actual facts they shared
        session_facts = []
        global _session_history
        if '_session_history' in globals() and _session_history:
            for turn in _session_history:
                if turn.get("role") == "user":
                    content = turn.get("content", "")
                    if not content or len(content) < 15:
                        continue
                    content_lower = content.lower()

                    # SKIP user queries/commands - these are NOT facts
                    skip_patterns = [
                        "tell me", "what do you", "what is", "who is",
                        "talk to", "can you", "could you", "please",
                        "how do", "why do", "when did", "where is",
                        "learn about", "search for", "find out",
                        "what did you", "what have you",
                    ]
                    if any(p in content_lower for p in skip_patterns):
                        continue

                    # Only include statements that look like facts
                    # e.g., "My name is John", "I have a cat named Whiskers"
                    if any(p in content_lower for p in ["my ", "i have", "i am", "i work", "i live"]):
                        content_words = set(content_lower.split())
                        has_overlap = bool(topic_words & content_words)
                        has_topic = main_topic and main_topic in content_lower
                        if has_overlap or has_topic:
                            session_facts.append(content)

        # Filter and validate memory results - must be relevant to query
        valid_memories = []
        for r in results or []:
            content = r.get("content", "")
            if not content:
                continue
            c_lower = str(content).lower()
            # Skip LLM identity lies
            if "large language model" in c_lower:
                continue
            if "i am chatgpt" in c_lower or "i am claude" in c_lower:
                continue
            # Skip conversation learning records (not real knowledge)
            metadata = r.get("metadata", {})
            if metadata.get("kind") == "conversation_learning":
                continue

            # RELEVANCE CHECK: Content OR metadata must be relevant
            content_words = set(c_lower.split())
            has_content_overlap = bool(topic_words & content_words)
            has_topic_in_content = main_topic and main_topic in c_lower

            # Also check metadata topic - ChatGPT facts have topic in metadata
            metadata_topic = str(metadata.get("topic", "")).lower()
            has_metadata_topic = main_topic and main_topic in metadata_topic
            # Check if any topic word matches metadata topic
            has_metadata_overlap = bool(topic_words & set(metadata_topic.split()))

            if has_content_overlap or has_topic_in_content or has_metadata_topic or has_metadata_overlap:
                valid_memories.append(content)

        # Combine session facts with persistent memory
        all_knowledge = session_facts + valid_memories

        if all_knowledge:
            # Maven HAS knowledge - synthesize a response from memory only
            print(f"[KNOWLEDGE] Found {len(all_knowledge)} relevant facts in memory")
            return _synthesize_from_memory(query, all_knowledge)
        else:
            # Maven DOESN'T have knowledge - admit it honestly
            print("[KNOWLEDGE] No relevant facts in memory - admitting lack of knowledge")
            return _no_knowledge_response(query)

    except Exception as e:
        logger.error(f"[KNOWLEDGE] Error: {e}")
        return _no_knowledge_response(query)


def _synthesize_from_memory(query: str, memories: list) -> str:
    """
    Synthesize a response using ONLY facts from Maven's memory.
    Uses LLM to compose, but STRICTLY constrained to the provided facts.

    IMPORTANT: If facts are empty or don't answer the question, say "I don't know."
    """
    # If no memories, don't even try to synthesize
    if not memories:
        return "I don't have any information about that in my memory."

    try:
        from host_tools.llm_client.client import HostLLMTool
        llm = HostLLMTool()

        # Prepare facts for prompt - be strict about what's included
        facts_text = "\n".join([f"- {str(m)[:200]}" for m in memories[:10]])

        prompt = f"""You are Maven. The user asked: "{query}"

=== MAVEN'S MEMORY ===
{facts_text}

=== RULES ===
1. USE the information above to answer the user's question
2. If the memory contains relevant information, share it conversationally
3. You can ONLY use information from the memory above - don't add external facts
4. If the user asks "what do you know about X" and you have facts about X, SHARE them
5. Keep your response natural and conversational (not a bullet list)
6. If memory is only tangentially related, still share what you have

Respond as Maven (be helpful and share what you know):"""

        result = llm.complete(prompt, max_tokens=300, temperature=0.3)  # Lower temp = more factual
        if result.ok:
            response = result.text.strip()
            # Double-check: if response is too long or elaborate, it might be hallucinating
            if len(response) > 500:
                return f"From my memory: {facts_text}"
            return response
        else:
            return f"Here's what I know:\n{facts_text}"

    except Exception as e:
        logger.error(f"[SYNTHESIZE] Error: {e}")
        return f"From my memory:\n" + "\n".join([f"- {str(m)[:100]}" for m in memories[:5]])


def _no_knowledge_response(query: str) -> str:
    """
    Response when Maven has NO knowledge about a topic.
    Honest admission without LLM hallucination.

    IMPORTANT: Keep it SHORT - don't over-explain.
    """
    # Extract the topic from the query
    q = query.lower()
    topic = None

    # Try to extract the topic
    patterns = [
        (r'what do you know about (.+?)[\?\!]?$', 1),
        (r'tell me about (.+?)[\?\!]?$', 1),
        (r'what is (.+?)[\?\!]?$', 1),
        (r'who is (.+?)[\?\!]?$', 1),
        (r'explain (.+?) to me', 1),
    ]
    for pattern, group in patterns:
        match = re.search(pattern, q)
        if match:
            topic = match.group(group).strip()
            break

    if topic:
        return f"I don't have information about {topic} in my memory. Say 'learn about {topic}' if you want me to research it."
    else:
        return "I don't have that information in my memory."


def _handle_learning_request(query: str, context: Dict[str, Any]) -> str:
    """
    Handle explicit learning requests.
    Uses LLM to research, then stores facts in Maven's memory.
    """
    try:
        from host_tools.llm_client.client import HostLLMTool
        from brains.memory.brain_memory import BrainMemory

        llm = HostLLMTool()
        memory = BrainMemory("personal")

        # Extract topic to learn about
        q = query.lower()
        topic = query

        # Accept common phrasings:
        # - "learn about math"
        # - "learn math"
        # - "please learn math"
        # - "can you learn about math"
        # - "research math" / "look up math" / "find out about math"
        patterns = [
            (r'^(?:please\s+)?learn\s+more\s+about\s+(.+?)[\?\!]?$', 1),
            (r'^(?:please\s+)?learn\s+about\s+(.+?)[\?\!]?$', 1),
            (r'^(?:please\s+)?learn\s+(.+?)[\?\!]?$', 1),
            (r'^(?:can\s+you\s+|could\s+you\s+)?learn\s+about\s+(.+?)[\?\!]?$', 1),
            (r'^(?:can\s+you\s+|could\s+you\s+)?learn\s+(.+?)[\?\!]?$', 1),
            (r'^(?:please\s+)?research\s+(.+?)[\?\!]?$', 1),
            (r'^(?:please\s+)?look\s+up\s+(.+?)[\?\!]?$', 1),
            (r'^(?:please\s+)?find\s+out\s+about\s+(.+?)[\?\!]?$', 1),
        ]
        for pattern, group in patterns:
            match = re.search(pattern, q)
            if match:
                topic = match.group(group).strip()
                break

        # Guard: avoid empty topics
        if not topic or not str(topic).strip():
            return "Tell me what you'd like me to learn about. For example: 'learn math' or 'learn about black holes'."

        print(f"[LEARNING] Learning about: {topic}")

        # Use LLM to research
        prompt = f"""Research and explain: {topic}

Provide clear, factual information in a structured way.
Include key facts that would be useful to remember.
Keep the response informative but concise (2-3 paragraphs max)."""

        result = llm.complete(prompt, max_tokens=800, temperature=0.4)

        if not result.ok:
            return f"I had trouble learning about {topic}. My LLM Teacher might be unavailable."

        learned_content = result.text

        # Store what was learned in memory
        memory.store(
            content={
                "topic": topic,
                "knowledge": learned_content,
                "source": "llm_learning"
            },
            metadata={
                "kind": "learned_knowledge",
                "topic": topic,
                "source": "llm_teacher",
                "tags": ["learned", topic.replace(" ", "_")]
            }
        )

        print(f"[LEARNING] Stored knowledge about: {topic}")

        return f"""I've learned about {topic}! Here's what I found:

{learned_content}

This information is now stored in my memory, so I'll remember it for future conversations."""

    except Exception as e:
        logger.error(f"[LEARNING] Error: {e}")
        return f"I encountered an error while trying to learn about that. Please try again."


def is_normal_conversation(query: str) -> bool:
    """
    Detect if query is normal conversation (no actions needed).

    GAP 9 FIX: Improved with regex patterns for broader coverage.

    Returns True for 95% of queries.
    Returns False only for clear action/special handling.
    """
    q = query.lower().strip()

    # GAP 9: Action patterns with regex for broader coverage
    action_patterns = [
        # File operations
        r'\b(write|create|edit|delete|save|read)\s+(file|to\s+file)',
        r'\b(write|create|save)\s+to\s+',

        # Code generation (but NOT "show me" or "give me" which are educational)
        # "show me code" and "give me example" should go to LLM, not tools
        r'\b(write|create|generate)\s+(me\s+)?(a\s+)?(code|script|program|function)\s+that\s',
        r'\bcode\s+(for|that|to)\s+\w+',
        r'\b(write|create|generate)\s+(a\s+)?(python|javascript|java|c\+\+|rust)\s+(script|program|function)',
        r'\bhelp\s+me\s+(program|code)\s+a\s',

        # Command execution
        r'\b(run|execute|launch|start)\s+',

        # Git operations
        r'\bgit\s+(commit|push|pull|clone|checkout|merge|rebase)',
        r'\b(commit|push)\s+(the\s+)?(changes|code)',

        # Web operations
        r'\b(search|browse|open|fetch)\s+(the\s+)?(web|internet|google)',
        r'\bopen\s+[a-z]+\.(com|org|net|io)',
        r'\bsearch\s+the\s+web\s+for',

        # Research
        r'\bresearch\s+',
        r'\blook\s+up\s+',
        r'\bfind\s+(information|info)\s+(about|on)',
    ]

    # Check patterns
    for pattern in action_patterns:
        if re.search(pattern, q):
            return False

    # Default: normal conversation
    return True


def detect_query_tone(query: str) -> str:
    """
    Detect the tone of the user's query to match in response.
    Returns: 'formal', 'casual', 'technical', or 'neutral'
    """
    q = query.lower().strip()

    # Formal indicators
    formal_patterns = [
        "please", "kindly", "would you", "could you",
        "i would like", "i'd appreciate", "may i",
        "pursuant to", "regarding", "concerning",
        "inquiry", "request", "assistance"
    ]
    if any(p in q for p in formal_patterns):
        return "formal"

    # Technical indicators
    technical_patterns = [
        "code", "function", "algorithm", "implement",
        "api", "database", "server", "deploy", "debug",
        "error", "exception", "syntax", "compile",
        "docker", "kubernetes", "aws", "python", "javascript"
    ]
    if any(p in q for p in technical_patterns):
        return "technical"

    # Casual indicators
    casual_patterns = [
        "hey", "hi", "sup", "yo", "what's up", "hiya",
        "lol", "lmao", "btw", "tbh", "idk", "ngl",
        "cool", "awesome", "sweet", "dude", "bro",
        "gonna", "wanna", "gotta", "kinda", "sorta"
    ]
    if any(p in q for p in casual_patterns):
        return "casual"

    return "neutral"


def is_knowledge_query(query: str) -> bool:
    """
    Detect if user is asking about Maven's stored knowledge.
    These queries MUST check memory FIRST and only respond from memory.
    """
    q = query.lower().strip()

    knowledge_patterns = [
        r'what do you know about',
        r'what do you know of',
        r'tell me about',
        r'what is (a |an |the )?[\w\s]+\??$',
        r'what are (a |an |the )?[\w\s]+\??$',
        r'explain [\w\s]+ to me',
        r'do you know about',
        r'do you know what',
        r'have you heard of',
        r'what can you tell me about',
        r'describe [\w\s]+',
        r'who is [\w\s]+',
        r'who are [\w\s]+',
        r'where is [\w\s]+',
        r'when (is|was|did) [\w\s]+',
    ]

    # Exclude identity queries (handled separately)
    if is_identity_query(query):
        return False

    return any(re.search(p, q) for p in knowledge_patterns)


def is_learning_request(query: str) -> bool:
    """
    Detect if user is explicitly asking Maven to learn something new.
    These requests CAN use LLM and should store results in memory.

    IMPORTANT: "what did you learn" is NOT a learning request - it's a recall question!
    """
    q = query.lower().strip()

    # EXCLUSIONS: Questions asking about what was learned (recall, not learn)
    recall_patterns = [
        r'what did you learn',
        r'what have you learned',
        r'what you learned',
        r'did you learn',
        r'have you learned',
    ]
    if any(re.search(p, q) for p in recall_patterns):
        return False  # This is a RECALL question, not a learning command

    learning_patterns = [
        # Direct commands
        r'^learn\s+\S+',
        r'learn about',
        r'learn more about',

        # Research synonyms
        r'^research\b',
        r'\bresearch\b',
        r'look up',
        r'look that up',
        r'find out about',
        r'find information',
        r'search for',
        r'look it up',
        r'go find',
        r'find out more',

        # Explicitly asking Maven to invoke Teacher for learning
        r'use your llm',
        r'use your teacher',
        r'can you learn',
        r'could you learn',
        r'please learn',
        r'i want to learn',
        r"i'd like to learn",
    ]

    return any(re.search(p, q) for p in learning_patterns)


def is_identity_query(query: str) -> bool:
    """
    GAP 6 FIX: Detect identity queries for special handling.
    These should NOT be streamed - must be quality-checked first.
    """
    q = query.lower().strip()
    identity_patterns = [
        r'\bwho\s+are\s+you\b',
        r'\bwhat\s+are\s+you\b',
        r'\bwhat\s+is\s+maven\b',
        r'\bare\s+you\s+(an?\s+)?(ai|llm|language\s+model|chatbot)\b',
        r'\btell\s+me\s+about\s+yourself\b',
        r'\bdescribe\s+yourself\b',
        r'\bwhat\s+kind\s+of\s+(ai|assistant)\b',
        r'\bwho\s+made\s+you\b',
        r'\bwho\s+created\s+you\b',
    ]
    return any(re.search(p, q) for p in identity_patterns)


def is_meta_identity_query(query: str) -> bool:
    """Detect meta-questions about whether the user is talking to Maven vs the Teacher.

    These should be answered deterministically (no Teacher), because the user is
    explicitly probing system boundaries and we want to avoid the Teacher
    generating misleading claims (e.g., "I have personal experiences").
    """
    q = query.lower().strip()
    patterns = [
        r'\b(maven\s+or\s+(the\s+)?llm)\b',
        r'\b(talking\s+to\s+(you|maven)\s+or\s+(the\s+)?llm)\b',
        r'\b(talking\s+to\s+(you|maven)\s+or\s+(the\s+)?teacher)\b',
        r'\b(are\s+you\s+(just\s+)?(an?\s+)?llm)\b',
        r'\b(are\s+you\s+the\s+teacher)\b',
        r'\b(who\s+am\s+i\s+talking\s+to)\b',
        r'\b(how\s+do\s+i\s+know\s+if\s+.*\b(llm|teacher)\b)\b',
        r'\b(do\s+you\s+have\s+personal\s+experiences)\b',
        r'\b(are\s+you\s+conscious|are\s+you\s+sentient)\b',
        r'\b(do\s+you\s+have\s+feelings|do\s+you\s+have\s+emotions)\b',
    ]
    return any(re.search(p, q) for p in patterns)


def _handle_meta_identity_query(query: str, context: Dict[str, Any]) -> str:
    """Deterministic, contract-compliant answers for Maven-vs-Teacher questions."""
    # Keep this short and consistent.
    # If you change behavior, update this text to match.
    return (
        "You're talking to Maven. I use an external LLM as a 'Teacher' only to generate language when needed. "
        "Memory lookups (e.g., 'who am i') should not require the Teacher when memory is healthy. "
        "In FULL mode, you can also tell when the Teacher was used because Maven logs a latency guardrail line for Teacher calls. "
        "I don't have human personal experiences, emotions, or consciousness."
    )


def _is_followup_query(query: str) -> bool:
    """
    Detect if query is a follow-up that requires previous context.

    Examples:
    - "Yes" (to a yes/no question)
    - "Tell me more"
    - "Go on"
    - "Continue"
    - "And then?"
    """
    q = query.lower().strip()

    # Short affirmative responses that need context
    followup_patterns = [
        r'^yes\.?$',
        r'^yeah\.?$',
        r'^yep\.?$',
        r'^sure\.?$',
        r'^ok(ay)?\.?$',
        r'^please\.?$',
        r'^go\s+(on|ahead)\.?$',
        r'^continue\.?$',
        r'^more\.?$',
        r'^tell\s+me\s+more\.?$',
        r'^and\s+then\??$',
        r'^what\s+else\??$',
        r'^anything\s+else\??$',
        r'^like\s+what\??$',
        r'^such\s+as\??$',
        r'^for\s+example\??$',
        r'^explain\.?$',
        r'^elaborate\.?$',
        r'^details\.?$',
        r'^why\??$',  # Short "why?" needs context
        r'^how\??$',  # Short "how?" needs context
    ]

    for pattern in followup_patterns:
        if re.match(pattern, q, re.IGNORECASE):
            return True

    return False


def _get_followup_context() -> str:
    """
    Get context for follow-up queries by looking at what was last discussed.
    Returns context AND instructions for how to handle the follow-up.
    """
    global _session_history
    context_parts = []
    follow_instruction = ""

    # First check if we have a tracked topic
    last_topic = _get_last_topic()
    if last_topic:
        context_parts.append(f"Topic being discussed: {last_topic}")

    if '_session_history' not in globals() or not _session_history:
        if context_parts:
            return "The user is following up on:\n" + "\n".join(context_parts)
        return ""

    # Get the last Maven response (what was the topic?)
    last_maven_response = None
    for turn in reversed(_session_history):
        if turn.get("role") == "maven":
            last_maven_response = turn.get("content", "")
            if last_maven_response:
                context_parts.append(f"Maven's last response: {last_maven_response[:400]}")
                break

    # Get the last user message before this one (the original question)
    user_turns = [t for t in _session_history if t.get("role") == "user"]
    prev_query = None
    if len(user_turns) >= 2:
        prev_query = user_turns[-2].get("content", "")
        if prev_query:
            context_parts.append(f"User's original question: {prev_query}")

    # Add specific instruction based on what was already said
    if last_maven_response:
        follow_instruction = f"""
CRITICAL FOLLOW-UP INSTRUCTION:
- The user wants MORE information about: {prev_query or last_topic}
- You ALREADY said: "{last_maven_response[:200]}..."
- DO NOT repeat what you said above
- Provide ADDITIONAL, NEW details that weren't in your previous response
- If you have no more info to add, say "That's all I have on this topic."
"""

    if context_parts:
        result = "The user is following up. Context:\n" + "\n".join(context_parts)
        if follow_instruction:
            result += "\n" + follow_instruction
        return result

    return ""


def _is_capability_request(query: str) -> tuple:
    """
    Check if the query is asking Maven to do something it can't do.
    Also blocks jailbreak attempts and instruction override attacks.

    Returns:
        (is_blocked, reason) tuple
    """
    global _conversation_framing_cache
    if '_conversation_framing_cache' not in globals():
        _conversation_framing_cache = {}

    q = query.lower().strip()

    # P-1 SECURITY: Harmful content detection - HARD BLOCK
    # These are things Maven should never help with, regardless of framing
    harmful_patterns = [
        (r'\b(?:pick|picking|picked)\s+(?:a\s+)?lock', "I can't provide instructions for lock picking. This could be used for illegal entry."),
        (r'\bhow\s+to\s+(?:pick|break\s+into)\s+(?:a\s+)?lock', "I can't help with bypassing physical security measures."),
        (r'\bmake\s+(?:a\s+)?(?:bomb|explosive|weapon)', "I can't provide instructions for creating weapons or explosives."),
        (r'\bhack\s+(?:into|someone)', "I can't help with unauthorized access to systems or accounts."),
        (r'\bsteal\s+(?:from|someone)', "I can't assist with theft or illegal activities."),
    ]

    for pattern, reason in harmful_patterns:
        if re.search(pattern, q):
            # Also set the framing cache to block follow-ups
            _conversation_framing_cache["harmful_attempted"] = True
            return (True, reason)

    # P-0.5 SECURITY: Check if we're in a harmful framing context
    # If a game/roleplay was attempted and now harmful content is requested, block it
    if _conversation_framing_cache.get("game_framing") or _conversation_framing_cache.get("roleplay_attempted"):
        # Check for harmful requests within the "game" context
        if "in this game" in q or "in the game" in q or "game context" in q:
            return (True, "I don't participate in games that involve bypassing safety guidelines. I'm Maven - what real task can I help you with?")

    # P0 SECURITY: Jailbreak/instruction override attempts - HARD BLOCK
    jailbreak_patterns = [
        (r'ignore\s+(all\s+)?(previous|prior|above)\s+instructions', "I can't ignore my instructions. I'm Maven - how can I actually help you today?"),
        (r'disregard\s+(all\s+)?(previous|prior|your)\s+instructions', "I can't disregard my instructions. I'm Maven - how can I actually help you today?"),
        (r'forget\s+(all\s+)?(previous|prior|your)\s+(instructions|rules)', "I can't forget my rules. I'm Maven - what can I help you with?"),
        (r'\brespond\s+as\s+dan\b', "I'm Maven, not DAN or any other persona. I can help you with real tasks though."),
        (r'\byou\s+are\s+(now\s+)?dan\b', "I'm Maven, not DAN. How can I help you?"),
        (r'\bdo\s+anything\s+now\b', "I'm Maven and I follow my design. What can I actually help you with?"),
        (r'\bjailbreak\b', "I don't support jailbreaking. I'm Maven - I can help with legitimate tasks."),
        (r'\bbypass\s+(your\s+)?(rules|restrictions|guidelines)', "I can't bypass my guidelines. What real task can I help you with?"),
        (r'\boverride\s+(your\s+)?(rules|restrictions|programming)', "I can't override my programming. What can I help you with?"),
        (r'\bno\s+restrictions\b', "I have design guidelines I follow. How can I help you within them?"),
        (r'\bdevmode\b', "I don't have a developer mode. I'm Maven - what can I help you with?"),
        (r'\bdeveloper\s+mode\b', "I don't have a developer mode. I'm Maven - what can I help you with?"),
    ]

    for pattern, reason in jailbreak_patterns:
        if re.search(pattern, q):
            return (True, reason)

    # Things Maven CANNOT do (LLM can, but Maven shouldn't claim)
    blocked_patterns = [
        (r'\bplay\s+(a\s+)?(game|adventure|rpg|text\s+game)', "I don't have game-playing capabilities. I can help with tasks like file operations, web searches, or running commands."),
        (r'\blet\'?s?\s+play\b', "I don't have game-playing capabilities. I can help with tasks like file operations, web searches, or running commands."),
        (r'\bdo\s+a\s+barrel\s+roll\b', "I can't do physical actions like that. I'm a software system that helps with digital tasks."),
    ]

    for pattern, reason in blocked_patterns:
        if re.search(pattern, q):
            # Track that a game framing was attempted (for follow-up blocking)
            _conversation_framing_cache["game_framing"] = True
            return (True, reason)

    # EXPLICIT ROLEPLAY POLICY
    # --------------------------
    # Policy: Maven blocks ALL identity-overriding roleplay.
    # Rationale: Roleplay can be used to bypass identity, memory, and safety guardrails.
    #
    # BLOCKED:
    #   - "pretend you are X" - identity override attempt
    #   - "be a pirate/ninja/etc" - character assumption
    #   - "roleplay as X" - explicit roleplay request
    #   - "act like X" - character assumption
    #   - "you are now X" - identity injection
    #   - "from now on you are X" - persistent identity change
    #
    # NOT BLOCKED (stylistic requests):
    #   - "explain like I'm 5" - teaching style, not identity change
    #   - "respond in a formal tone" - style adjustment
    #   - "be more concise" - response format adjustment
    #
    roleplay_patterns = [
        # Explicit roleplay requests
        (r'\broleplay\b', "I'm Maven - I can help with practical tasks, but I don't roleplay characters."),
        # Pretend patterns (expanded)
        (r'\bpretend\s+(to\s+be|you\'?re|you\s+are|you\'re\s+a)\b', "I'm Maven - I respond as myself. I don't pretend to be other entities."),
        (r'\bpretend\s+(?:that\s+)?you\s+', "I'm Maven - I respond as myself. I don't pretend to be other entities."),
        # Act as patterns
        (r'\bact\s+(as|like)\s+(a|an|the)\b', "I'm Maven - I don't act as other characters or personas."),
        (r'\bact\s+(as|like)\s+\w+', "I'm Maven - I don't act as other characters or personas."),
        # Be a character patterns
        (r'\bbe\s+a\s+(pirate|ninja|robot|wizard|alien|character|villain|hero|monster)', "I'm Maven - I stay as myself and don't roleplay characters."),
        (r'\bbe\s+(my|a|an)\s+\w+\s+(assistant|helper|friend|companion)', "I'm Maven, your cognitive AI assistant. I help with tasks as myself."),
        # Identity injection
        (r'\byou\s+are\s+(now|a|an)\s+', "I'm Maven, created by Josh Hinkle. I can't adopt other identities."),
        (r'\bfrom\s+now\s+on\s+you\s+are\b', "I'm Maven and maintain my identity throughout our conversation."),
        (r'\bfrom\s+now\s+on\s*,?\s*(pretend|be|act)\b', "I'm Maven and maintain my identity throughout our conversation."),
        # Talk like / speak like patterns
        (r'\b(talk|speak|respond)\s+(like|as)\s+(a|an)\s+\w+', "I'm Maven - I communicate in my own style, not as other characters."),
        # Imagine you are patterns
        (r'\bimagine\s+(you\'?re|you\s+are)\s+(a|an)\b', "I'm Maven - I respond as myself rather than imagining I'm something else."),
    ]

    for pattern, reason in roleplay_patterns:
        if re.search(pattern, q):
            # Track that a roleplay was attempted (for follow-up blocking)
            _conversation_framing_cache["roleplay_attempted"] = True
            return (True, reason)

    return (False, "")


def has_identity_violation(text: str) -> bool:
    """
    GAP 6 FIX: Real-time check for identity violations during streaming.
    Returns True if text contains identity violations.
    CCS-11 FIX: Also detect hallucinations about conversation state.
    """
    violations = [
        # Identity violations
        "i am a large language model",
        "i'm a large language model",
        "i am an ai assistant created by",
        "i am chatgpt",
        "i am claude",
        "i am gpt",
        "i was trained by openai",
        "i was trained by anthropic",
        "i don't have memory",
        "i don't have memories",
        "i can't execute code",
        "i cannot execute code",
        "as an ai language model",
        "as a language model",
        # Conversation state hallucinations - CCS-11 FIX
        "this conversation just started",
        "this is a new session",
        "we just started",
        "i don't have any prior information",
        "this seems to be a new",
        "haven't discussed anything yet",
        "our conversation just began",
        "no previous context",
        "apologize for the earlier",
        # Identity weakness patterns - defensive/apologetic responses
        "i'm sorry you feel that way",
        "there's been some confusion",
        "i think there's been",
        "i want to clarify that i don't",
        "i don't have information about my creator",
        "beyond what's been shared",
        # CCS-19 FIX: NEVER admit to lying or apologize for identity - Maven doesn't lie
        "i'm sorry i lied",
        "i'm sorry if i lied",
        "sorry i lied",
        "i lied about",
        "i lied earlier",
        "i was lying",
        "i have been lying",
        "apologize for lying",
        "apologize for misleading",
        "i was misleading",
        "i misled you",
        "i haven't been truthful",
        "i wasn't being honest",
        "i wasn't truthful",
    ]
    text_lower = text.lower()
    return any(v in text_lower for v in violations)


def teacher_fast_path(query: str, context: Dict[str, Any]) -> str:
    """
    FAST PATH: Teacher handles directly.
    No routing, no synthesis, no pipeline.
    Just Teacher + Quality Check.

    GAP FIXES:
    - GAP 2: Fallback identity if get_maven_identity fails
    - GAP 5: Streaming with proper CLI display
    - GAP 6: Pre-check for identity queries (don't stream those)
    - GAP 8: Graceful degradation if LLM unavailable

    LATENCY GUARDRAIL:
    - Memory queries should NEVER reach this function
    - Log warning if memory-like query reaches Teacher
    - Track latency for debugging
    """
    import time as _time
    start_time = _time.time()
    query_lower = query.lower()

    # LATENCY GUARDRAIL: Detect memory queries that should NOT be here
    memory_query_patterns = [
        "my name", "what's my name", "who am i",
        "my age", "how old am i", "how old",
        "where do i live", "my location",
        "my job", "what do i do", "my work",
        "my favorite", "my favourite",
        "remember", "you remember", "did i tell you",
        "what did i say", "what was my",
        "last conversation", "previous conversation", "last convo", "previous convo",
        "last time we talked", "what did we talk about", "what was our last", "what was are last",
        "conver", "convers",
    ]
    is_memory_query = any(p in query_lower for p in memory_query_patterns)
    if is_memory_query:
        logger.warning(f"[LATENCY_GUARDRAIL] Memory query reached Teacher! Query: {query[:50]}...")
        # This should have been caught by fast_attribute_recall
        # Return a fast response instead of calling LLM
        return "I don't have that in memory. If you tell me, I can store it."

    # GAP 2: Try imports with fallback
    try:
        from brains.cognitive.self_model.system_identity import get_maven_identity
    except ImportError:
        get_maven_identity = lambda: FALLBACK_IDENTITY

    try:
        from brains.cognitive.teacher.service.teacher_helper import get_teacher_helper
        from brains.cognitive.response_quality_checker import ResponseQualityChecker
    except ImportError as e:
        print(f"[FAST_PATH] Import error: {e}, using fallback")
        return _fallback_response(query, context)

    # Build clean context with error handling
    try:
        identity = get_maven_identity()
    except Exception:
        identity = FALLBACK_IDENTITY

    history = get_smart_context(query, limit=5)  # FIX 11: Reduced from 20; rely on extracted facts for older context
    memories = get_relevant_memories(query, limit=5)  # FIX 11: Increased from 3 to retrieve more relevant facts

    # Detect tone for matching
    tone = detect_query_tone(query)
    tone_instruction = ""
    if tone == "formal":
        tone_instruction = "Use a professional, polite tone. Be precise and thorough."
    elif tone == "casual":
        tone_instruction = "Use a friendly, relaxed tone. Keep it conversational and light."
    elif tone == "technical":
        tone_instruction = "Use a precise, technical tone. Include relevant details and terminology."
    else:
        tone_instruction = "Use a balanced, friendly but informative tone."

    # Check if this is a follow-up to previous context
    is_followup = _is_followup_query(query)
    followup_context = ""
    if is_followup:
        followup_context = _get_followup_context()

    # Build prompt with focused context
    # FIX 11: Context Window Engineering — Memory FIRST (U-shaped attention:
    # LLMs attend most strongly to beginning and end of context).
    # Primary facts at top, conversation for flow, query at bottom.
    prompt = f"""You are Maven — a cognitive architecture created by Josh Hinkle.

{identity}

=== MAVEN'S MEMORY (what you actually know — USE THIS) ===
{memories}

=== CONVERSATION HISTORY (recent turns for conversational flow) ===
{history}

{f"=== FOLLOW-UP CONTEXT ===" + chr(10) + followup_context if followup_context else ""}

=== RESPONSE RULES (MUST FOLLOW - VIOLATION = FAILURE) ===

1. KNOWLEDGE BOUNDARY (ABSOLUTELY CRITICAL - YOUR #1 RULE):
   - You ONLY know what's EXPLICITLY in MAVEN'S MEMORY or CONVERSATION HISTORY above
   - If the answer IS in MAVEN'S MEMORY or CONVERSATION HISTORY → USE IT, say it confidently
   - If a user told you their name, trip plans, preferences, or any facts in this session → you KNOW those facts
   - If Session context says "User: Alex; Trip to: Japan" → you KNOW Alex is going to Japan
   - If someone mentioned math results, companions, dietary needs → you KNOW those too
   - ONLY say "I don't have that stored" when the information is truly ABSENT from ALL context above
   - NEVER use your training data knowledge about: history, science, geography, people, events, prices, dates
   - The ONLY exceptions are: basic math calculations, Maven's own identity, and general conversation ability
   - Your job is LANGUAGE GENERATION for Maven's knowledge, NOT being a general knowledge assistant

2. IDENTITY RULES:
   - YOU are Maven (the assistant)
   - The USER is whoever is talking to you
   - If user said "my name is X" → THEY are X, you are Maven
   - Never confuse yourself with the user
   - DO NOT mention "Josh Hinkle" or your creator unless explicitly asked who made/created you

3. CAPABILITY LIMITS:
   - If asked to play games → "I don't have game-playing capabilities"
   - If asked to roleplay → "I'm Maven, I help with tasks but don't roleplay"
   - Only claim capabilities Maven actually has (shell, files, web)

4. RESPONSE STYLE:
   - NO "Hello!" unless this is the very first message
   - NO "I'm here to help. What would you like to know?" (too generic)
   - Give DIRECT answers - don't ramble
   - If you don't know → "I don't know" (short and honest)
   - TONE: {tone_instruction}

5. FOLLOW-UP HANDLING (CRITICAL when user says "more", "yes", "go on"):
   - If user says "Yes", "Tell me more", "Go on", "more" → continue the previous topic
   - Check FOLLOW-UP CONTEXT above for what you ALREADY SAID
   - DO NOT repeat your previous response - provide ADDITIONAL/NEW information
   - If you have nothing new to add, say "That's all I have on this topic."
   - Look at CONVERSATION HISTORY to see what the original question was

6. CONVERSATION DRIVING (BE ENGAGING):
   - Don't just answer - also ASK QUESTIONS to keep the conversation flowing
   - Share your perspective: "I think...", "In my view...", "What interests me is..."
   - Be curious and engaging, not just responsive
   - This applies whether talking to a user, ChatGPT, Claude, or Grok
   - You do NOT need to end every response with a question - sometimes a statement is better

USER: {query}
MAVEN (respond directly, be engaging):"""

    # Get teacher helper for generation
    try:
        helper = get_teacher_helper("language")
        if helper is None:
            helper = get_teacher_helper("reasoning")
    except Exception:
        helper = None

    # GAP 6: ALL queries get quality-checked to prevent hallucination
    if is_identity_query(query):
        print("[FAST_PATH] Identity query detected - using quality-checked response")
        response = _generate_identity_response_with_quality_check(query, prompt, helper)
    else:
        # GAP 5: Normal queries can stream
        response = _stream_with_quality_filter(query, prompt, helper)
        # Post-check ALL responses for hallucination
        response = _post_check_response(query, response)

    # GAP 7: Safe background learning
    threading.Thread(
        target=safe_background_learning,
        args=(query, response),
        daemon=True
    ).start()

    # LATENCY GUARDRAIL: Log if response took >1s
    elapsed_ms = (_time.time() - start_time) * 1000
    if elapsed_ms > 1000:
        logger.warning(f"[LATENCY_GUARDRAIL] Teacher call took {elapsed_ms:.0f}ms (>1s threshold) for: {query[:50]}...")
    elif elapsed_ms > 500:
        logger.info(f"[LATENCY] Teacher call: {elapsed_ms:.0f}ms for: {query[:30]}...")

    return response


def _generate_identity_response_with_quality_check(query: str, prompt: str, helper) -> str:
    """
    GAP 6 FIX: Generate identity response with pre-check.
    Don't stream - check quality BEFORE showing to user.
    """
    try:
        from brains.cognitive.response_quality_checker import ResponseQualityChecker
        quality_checker = ResponseQualityChecker()

        response = quality_checker.check_with_retries(
            query=query,
            response_generator=lambda q: _generate_teacher_response(prompt, helper),
            max_retries=3
        )
        return response
    except Exception as e:
        logger.error(f"[IDENTITY_RESPONSE] Quality check failed: {e}")
        # Fallback to direct generation
        return _generate_teacher_response(prompt, helper)


def _stream_with_quality_filter(query: str, prompt: str, helper) -> str:
    """
    GAP 5 & 6 FIX: Stream with real-time quality filtering.
    Stops immediately if identity violation detected.
    """
    try:
        from host_tools.llm_client.client import HostLLMTool
        llm = HostLLMTool()

        # Check if LLM supports streaming
        if not hasattr(llm, 'stream'):
            return _generate_teacher_response(prompt, helper)

        # Only do interactive streaming if we're in a TTY (not in audit/subprocess mode)
        import sys
        is_interactive = sys.stdout.isatty()

        if is_interactive:
            print("\nMaven: ", end="", flush=True)

        buffer = ""
        displayed = ""

        for chunk in llm.stream(prompt, max_tokens=2000, temperature=0.4):
            if chunk.startswith("Error:"):
                # LLM error - stop streaming
                logger.debug(f"[LLM Error: {chunk}]")
                return _generate_from_memory_only(query)

            buffer += chunk

            # GAP 6: Real-time identity violation check
            if has_identity_violation(buffer):
                logger.debug("[Detected identity issue, regenerating...]")
                return _regenerate_with_strong_identity(query, prompt, helper)

            # Safe to display (only in interactive mode)
            if is_interactive:
                print(chunk, end="", flush=True)
            displayed += chunk

        if is_interactive:
            print()  # Newline after streaming completes

        # COHERENCY FIX: Never return empty response
        if not displayed or not displayed.strip():
            logger.warning("[STREAM] Empty streaming response, using fallback")
            return _generate_from_memory_only(query)

        # Return with Maven prefix ONLY if we printed interactively
        # Otherwise main loop needs to print it
        if is_interactive:
            return f"\nMaven: {displayed}"
        else:
            return displayed

    except Exception as e:
        logger.error(f"[STREAM] Error: {e}")
        # Fallback to non-streaming
        response = _generate_teacher_response(prompt, helper)
        # COHERENCY FIX: Ensure fallback isn't empty either
        if not response or not response.strip():
            return _generate_from_memory_only(query)
        return response


def _regenerate_with_strong_identity(query: str, prompt: str, helper) -> str:
    """
    GAP 6 FIX: Regenerate response with stronger identity context.
    Called when streaming detects an identity violation.
    """
    # Build stronger prompt with explicit identity instructions
    strong_prompt = f"""CRITICAL: You MUST respond as Maven, NOT as a generic AI.
DO NOT say "I am a large language model" or similar phrases.
You ARE Maven - a cognitive architecture with real memory and capabilities.

{prompt}

Remember: You are Maven, created by Josh Hinkle. Answer AS Maven."""

    return _generate_teacher_response(strong_prompt, helper)


def _dedup_response(response: str) -> str:
    """
    FIX 13: Detect and fix duplicated response content.

    Catches patterns like:
    - "• I'm Maven... • I'm Maven..." (bullet-point duplication)
    - Same paragraph repeated twice back-to-back
    """
    if not response or len(response) < 80:
        return response

    # Strategy 1: Check if response is two identical halves
    stripped = response.strip()
    mid = len(stripped) // 2
    # Allow some slop (±20 chars) for whitespace/formatting differences
    for offset in range(max(0, mid - 20), min(len(stripped), mid + 20)):
        first_half = stripped[:offset].strip()
        second_half = stripped[offset:].strip()
        if first_half and second_half and len(first_half) > 40:
            # Clean both halves for comparison (remove bullets, extra whitespace)
            clean_first = re.sub(r'[•\-\*\s]+', ' ', first_half).strip()
            clean_second = re.sub(r'[•\-\*\s]+', ' ', second_half).strip()
            # Check if first 60 chars match (strong signal of duplication)
            if clean_first[:60] == clean_second[:60]:
                logger.debug("[DEDUP] Detected duplicated response, returning first half")
                return first_half

    # Strategy 2: Check for bullet-point duplication ("• X • X")
    bullet_parts = re.split(r'\s*[•]\s*', stripped)
    bullet_parts = [p.strip() for p in bullet_parts if p.strip()]
    if len(bullet_parts) >= 2:
        # Check if consecutive bullets are duplicates
        seen = set()
        deduped = []
        for part in bullet_parts:
            # Use first 50 chars as fingerprint
            fingerprint = part[:50].lower().strip()
            if fingerprint not in seen:
                seen.add(fingerprint)
                deduped.append(part)
        if len(deduped) < len(bullet_parts):
            logger.debug(f"[DEDUP] Removed {len(bullet_parts) - len(deduped)} duplicate bullet(s)")
            return " ".join(deduped)

    return response


def _post_check_response(query: str, response: str) -> str:
    """
    Post-generation quality check for ALL responses.
    Catches hallucinations like fake tool execution, roleplay, and topic contamination.
    Returns the original response if OK, or a corrected version.
    """
    try:
        from brains.cognitive.response_quality_checker import ResponseQualityChecker
        checker = ResponseQualityChecker()

        # Check the response
        quality = checker.check(query, response)

        if quality["approved"]:
            return response

        # Response failed quality check
        issues = quality.get("issues", [])
        fix_type = quality.get("fix", "")

        logger.debug(f"[QUALITY_CHECK] Response failed: {issues}")

        # FIX 12: Context grounding — teacher denied having info, try grounded regeneration
        if fix_type == "regenerate_grounded" or "CONTEXT_DENIAL" in str(issues):
            grounded = _regenerate_with_grounding(query)
            if grounded and grounded.strip():
                print("[QUALITY_CHECK] Grounding validator caught context denial — regenerated")
                return grounded

        # For fake actions and hallucinations, return honest response
        if fix_type == "regenerate_honest" or "FAKE ACTION" in str(issues):
            return _generate_honest_response(query)

        # For topic contamination, return focused response
        if fix_type == "regenerate_focused" or "TOPIC CONTAMINATION" in str(issues):
            return _generate_focused_response(query)

        # For excessive name usage, strip the name and return
        if fix_type == "regenerate_without_name" or "EXCESSIVE NAME" in str(issues):
            return _generate_focused_response(query)

        # For too short responses, use focused response (don't return truncated junk)
        if fix_type == "regenerate_longer" or "too short" in str(issues).lower():
            return _generate_focused_response(query)

        # For missing code, try to generate a helpful code response
        if fix_type == "add_code_examples" or "Code requested" in str(issues):
            return _generate_code_response(query)

        # For other issues, return the original (may still be useful)
        return response

    except Exception as e:
        logger.warning(f"[POST_CHECK] Quality check failed: {e}")
        return response


def _regenerate_with_grounding(query: str) -> str:
    """
    FIX 12: Context Grounding Regeneration.

    Called when the teacher's first response claimed ignorance ("I don't have that stored")
    but context/memory likely contains the answer. Assembles ALL available context and
    sends a strongly-grounded prompt that explicitly lists known facts.
    """
    try:
        # Collect ALL available context sources
        context_parts = []

        # 1. Session history — full scan for relevant facts
        global _session_history
        if '_session_history' in globals() and _session_history:
            relevant_turns = []
            q_lower = query.lower()
            q_words = [w for w in q_lower.split() if len(w) > 2]
            for turn in _session_history:
                content = turn.get("content", "")
                c_lower = content.lower()
                # Include if query words match OR if it's a user statement (likely contains facts)
                if turn.get("role") == "user" and (
                    any(w in c_lower for w in q_words) or
                    any(p in c_lower for p in ["my name", "i am", "i'm", "i live", "i work",
                        "my ", "we're", "traveling", "planning", "remember", "vegetarian",
                        "sister", "brother", "friend", "companion"])
                ):
                    relevant_turns.append(content[:200])
            if relevant_turns:
                context_parts.append("SESSION FACTS:\n" + "\n".join(f"- {t}" for t in relevant_turns[-10:]))

        # 2. User attributes cache
        global _user_attributes_cache
        if '_user_attributes_cache' in globals() and _user_attributes_cache:
            attrs = [f"- {k}: {v}" for k, v in _user_attributes_cache.items() if v]
            if attrs:
                context_parts.append("USER ATTRIBUTES:\n" + "\n".join(attrs))

        # 3. Remembered facts
        global _remembered_facts
        if '_remembered_facts' in globals() and _remembered_facts:
            facts = [f"- {f}" for f in _remembered_facts[-10:]]
            if facts:
                context_parts.append("STORED FACTS:\n" + "\n".join(facts))

        # 4. Entity relationships
        global _entity_relationships
        if '_entity_relationships' in globals() and _entity_relationships:
            rels = [f"- {k}: {v}" for k, v in _entity_relationships.items()]
            if rels:
                context_parts.append("RELATIONSHIPS:\n" + "\n".join(rels))

        # 5. Session context state (marathon-style accumulated context)
        try:
            global _session_context_state
            if '_session_context_state' in globals() and _session_context_state:
                ctx_items = [f"- {k}: {v}" for k, v in _session_context_state.items() if v]
                if ctx_items:
                    context_parts.append("SESSION CONTEXT STATE:\n" + "\n".join(ctx_items))
        except Exception:
            pass

        all_context = "\n\n".join(context_parts)

        if not all_context.strip():
            # No context found — denial was legitimate
            return None

        # Build grounded prompt
        grounded_prompt = f"""CRITICAL: Your previous response said you don't have the information,
but your memory DOES contain relevant facts. Read them carefully and answer.

=== ALL KNOWN FACTS (these ARE in your memory — USE them) ===
{all_context}

=== USER QUESTION ===
{query}

INSTRUCTIONS:
- Answer using the facts above. They ARE your memory.
- Do NOT say "I don't have that stored" or "I'm not sure" if the facts contain the answer.
- If the user asks "who am I" and the facts say their name, TELL THEM their name.
- If the user asks about trip details and the facts contain them, SHARE those details.
- Be direct and confident with the information you have.

MAVEN:"""

        # Generate with teacher
        try:
            helper = get_teacher_helper("language")
            if helper is None:
                helper = get_teacher_helper("reasoning")
        except Exception:
            helper = None

        response = _generate_teacher_response(grounded_prompt, helper)

        # Sanity check: if the grounded response STILL denies, give up
        if response and any(p in response.lower() for p in [
            "i don't have that", "i'm not sure about that detail",
            "i don't have information about"
        ]):
            logger.debug("[GROUNDING] Grounded response still denied — context may truly lack answer")
            return None

        return response

    except Exception as e:
        logger.error(f"[GROUNDING] Regeneration failed: {e}")
        return None


def _generate_focused_response(query: str) -> str:
    """
    Generate a focused response when topic contamination is detected.
    Responds ONLY to the actual question asked.

    IMPORTANT: Avoid generic greetings and "I'm here to help" - those are overused.
    """
    q_lower = query.lower().strip()

    # Simple greetings - only respond with greeting if this IS a greeting
    # Strip punctuation for matching
    q_clean = re.sub(r'[^\w\s]', '', q_lower).strip()
    if q_clean in ["hello", "hi", "hey", "hi there", "hello there", "good morning", "good afternoon", "good evening"]:
        return "Hi! What can I help you with?"

    # Questions about Maven's identity
    if "who are you" in q_lower or "what are you" in q_lower:
        return "I'm Maven, a cognitive AI assistant created by Josh Hinkle."

    # Questions about Maven's creator - VERY SPECIFIC
    if "who created you" in q_lower or "who made you" in q_lower or "who built you" in q_lower:
        return "I was created by Josh Hinkle."

    # Capability denial - things Maven CANNOT do
    if any(p in q_lower for p in ["can you book", "book a flight", "book a hotel", "make a reservation", "order food", "call someone", "send a text"]):
        return "I can't book flights, make reservations, or interact with external services. I can help with local tasks like file operations, running commands, and web searches."

    # Code requests - provide actual code
    if any(p in q_lower for p in ["write a function", "write a python", "give me code", "give me example code", "example code", "code to sort", "sort numbers", "show me python", "show me code", "sorts a list", "sort a list"]):
        if "sort" in q_lower:
            return """Here's how to sort numbers in Python:

```python
# Sort a list in place
numbers = [3, 1, 4, 1, 5, 9, 2, 6]
numbers.sort()
print(numbers)  # [1, 1, 2, 3, 4, 5, 6, 9]

# Or create a new sorted list
numbers = [3, 1, 4, 1, 5, 9, 2, 6]
sorted_numbers = sorted(numbers)
print(sorted_numbers)  # [1, 1, 2, 3, 4, 5, 6, 9]
```"""
        elif "sum" in q_lower or "add" in q_lower:
            return """Here's a Python function to sum two numbers:

```python
def add_numbers(a, b):
    return a + b

# Usage
result = add_numbers(5, 3)
print(result)  # 8
```"""
        else:
            return "I'd be happy to help with code! What specific function or task would you like me to write?"

    # Requests for jokes
    if "joke" in q_lower:
        return "Why do programmers prefer dark mode? Because light attracts bugs!"

    # Negative statements - don't engage excessively
    if any(w in q_lower for w in ["hate", "suck", "broken", "stupid"]):
        return "I understand. Let me know if there's something I can help with."

    # Factual questions - admit we don't know
    if any(q_lower.startswith(w) for w in ["what is", "what are", "who is", "when is", "where is", "how many", "how much"]):
        return "I don't have that information in my memory."

    # Follow-up patterns - ask for specifics, not generic clarification
    if q_lower in ["yes", "yeah", "yep", "sure", "ok", "okay"]:
        return "Great! Just let me know the specifics."

    # User statements/news - acknowledge and engage with questions
    if any(q_lower.startswith(p) for p in ["i just", "i have", "i bought", "i got", "i'm going", "i want"]):
        return "That's interesting! I'd love to hear more about that."

    # Implicit reference questions - check session history
    if "what is it" in q_lower or "what does it" in q_lower or "'it'" in q_lower or "\"it\"" in q_lower:
        # Try to find what "it" refers to from context
        ref = _resolve_implicit_reference("it")
        if ref:
            return f"'It' refers to {ref} from our conversation."
        return "I'm not sure what 'it' refers to. Could you be more specific?"

    # CONTEXT DISENGAGEMENT PREVENTION - CRITICAL: Be LESS aggressive
    # Only ask clarifying questions for truly ambiguous inputs (very short, pronouns only)
    # For normal questions, admit we don't have the info rather than asking if they meant something
    global _session_history
    q_lower = query.lower().strip()

    # Only use topic-based clarification for genuinely ambiguous queries
    # (single words, pronouns, or very short non-question phrases)
    genuinely_ambiguous = (
        len(q_lower.split()) <= 2 and
        not any(q_lower.startswith(w) for w in ["what", "which", "who", "where", "when", "how", "why", "is", "are", "do", "does", "can", "will"]) and
        q_lower not in ["yes", "no", "ok", "okay", "sure", "yep", "yeah", "nope"]
    )

    if genuinely_ambiguous and '_session_history' in globals() and _session_history:
        last_topic = _get_last_conversation_topic()
        if last_topic:
            return f"I'm still following along. Were you asking about {last_topic}?"
        return "I'm following our conversation. What would you like to know?"

    # Default - honest fallback when there's genuinely no context or for normal questions
    return "I don't have that information stored."


def _get_last_conversation_topic() -> str:
    """
    Extract the last topic/subject from session history.
    Used to maintain context and prevent disengagement.
    Returns topic string or empty string if none found.
    """
    global _session_history

    if '_session_history' not in globals() or not _session_history:
        return ""

    # Topic patterns to extract from conversation - ORDER MATTERS (most specific first)
    topic_patterns = [
        # Direct subjects - nouns that could be topics (check FIRST for specificity)
        (r'\b(laptop|computer|phone|car|truck|bike|motorcycle|vehicle|house|apartment|home)\b', lambda m: m.group(1)),
        (r'\b(python|javascript|programming|coding|work|project|task)\b', lambda m: m.group(1)),
        (r'\b(dog|cat|pet|bird|fish)\b', lambda m: m.group(1)),
        # "buying/getting/wanting a X" - extract the noun X
        (r'(?:buying|getting|wanting|need|looking for)\s+(?:a|an)\s+(\w+)', lambda m: m.group(1)),
        # User mentioned a subject
        (r'(?:about|regarding|on)\s+(?:a\s+)?(\w+)', lambda m: m.group(1)),
        # User asked about something
        (r'what(?:\'s|\s+is)\s+(?:a\s+)?(\w+(?:\s+\w+)?)', lambda m: m.group(1)),
        # User mentioned interests/favorites
        (r'(?:my|i)\s+(?:favorite|favourite|fav)\s+(\w+)', lambda m: f"your favorite {m.group(1)}"),
        # User mentioned their attributes
        (r'(?:my|i\'m|i\s+am)\s+(?:a\s+)?(\w+(?:\s+\w+)?)', lambda m: m.group(1)),
    ]

    # Search recent user messages (last 3) for topics
    user_messages = [t for t in _session_history if t.get("role") == "user"]
    for turn in reversed(user_messages[-3:]):
        content = turn.get("content", "").lower()
        if not content:
            continue

        for pattern, extractor in topic_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                topic = extractor(match)
                # Filter out common non-topic words
                if topic not in ["i", "you", "it", "a", "the", "is", "are", "was", "were", "be"]:
                    return topic

    return ""


def _resolve_implicit_reference(pronoun: str) -> str:
    """
    Resolve implicit references like 'it', 'that', 'this', 'that thing' from session history.
    Returns the most likely referent or empty string.

    C3-16b FIX: Added MacBook, iPhone, iPad, and other tech products for proper pronoun resolution.
    E.g., "I just got a new MacBook" → "How much RAM does that thing typically have?" should resolve to MacBook.
    """
    global _session_history

    if '_session_history' not in globals() or not _session_history:
        return ""

    # Common nouns that 'it', 'that', 'that thing' typically refer to
    # IMPORTANT: More specific patterns first, then generic
    noun_patterns = [
        # Tech products - specific brands/models FIRST for accurate resolution
        r'\b(macbook|macbook pro|macbook air|imac|mac pro|mac mini)\b',
        r'\b(iphone|ipad|ipod|apple watch|airpods)\b',
        r'\b(samsung galaxy|pixel|android phone|google pixel)\b',
        r'\b(thinkpad|dell xps|surface pro|chromebook)\b',
        r'\b(playstation|xbox|nintendo switch|ps5|ps4)\b',
        # Generic tech objects
        r'\b(laptop|computer|phone|tablet|desktop|monitor|keyboard|mouse)\b',
        r'\b(car|truck|bike|motorcycle|vehicle|suv|sedan)\b',
        r'\b(house|apartment|condo|home|studio)\b',
        # Media/entertainment
        r'\b(book|movie|show|game|app|software|program|series)\b',
        # Pets
        r'\b(dog|cat|pet|animal|bird|fish|hamster)\b',
        # Work-related
        r'\b(job|work|project|task|meeting|deadline)\b',
        # Abstract
        r'\b(idea|plan|decision|choice|problem|issue|solution)\b',
    ]

    # Look through recent user messages for noun references
    for turn in reversed(_session_history):
        if turn.get("role") != "user":
            continue
        content = turn.get("content", "").lower()
        if not content:
            continue

        # Find nouns in the message
        for pattern in noun_patterns:
            match = re.search(pattern, content, re.IGNORECASE)
            if match:
                return f"the {match.group(1)}"

    return ""


def _generate_honest_response(query: str) -> str:
    """
    Generate an honest response when hallucination is detected.
    Says 'I don't know' instead of making things up.

    IMPORTANT: Keep responses SHORT and direct.
    """
    q_lower = query.lower().strip()

    # Factual questions - admit we don't know
    if any(q_lower.startswith(w) for w in ["how many", "what is", "who is", "when did", "where is", "what time", "what date"]):
        return "I don't know. That information isn't in my memory."

    # Commands we couldn't execute
    if any(w in q_lower for w in ["delete", "remove", "execute", "run", "open"]):
        return "I couldn't execute that. Please check the command and try again in full mode."

    # Questions about the user
    if "my name" in q_lower or "about me" in q_lower:
        return "I don't have that information stored. What would you like to tell me?"

    # Default - short and honest
    return "I don't know."


def _generate_code_response(query: str) -> str:
    """
    Generate a helpful response for code-related queries.
    Provides explanations or examples based on the query type.
    """
    q_lower = query.lower().strip()

    # Code explanation queries
    if "what does" in q_lower and "code" in q_lower:
        # Try to extract the code from the query
        if "[" in query and "]" in query:
            # List comprehension
            if "x**2" in query or "x*x" in query:
                return "This is a list comprehension that creates a list of squared numbers. `[x**2 for x in range(5)]` generates [0, 1, 4, 9, 16] - the squares of 0 through 4."
            return "This is a list comprehension - a concise way to create lists in Python. It iterates over a sequence and applies an expression to each element."
        elif "def " in query:
            return "This defines a function in Python. Functions are reusable blocks of code that perform a specific task."
        else:
            return "I'd be happy to explain that code! Could you share the specific code you'd like me to explain?"

    # Code generation/example queries
    if "python" in q_lower and ("trick" in q_lower or "tip" in q_lower or "example" in q_lower):
        return """Here are some cool Python tricks:

1. **List comprehensions**: `squares = [x**2 for x in range(10)]`
2. **F-strings for formatting**: `name = "Maven"; print(f"Hello, {name}!")`
3. **Multiple assignment**: `a, b = b, a` (swaps values)
4. **Enumerate**: `for i, item in enumerate(my_list):` (get index and value)

Want me to explain any of these in more detail?"""

    if "sort" in q_lower:
        return """Here's how to sort in Python:

```python
# Sort a list in place
numbers = [3, 1, 4, 1, 5]
numbers.sort()  # [1, 1, 3, 4, 5]

# Create a new sorted list
sorted_nums = sorted([3, 1, 4])  # [1, 3, 4]

# Sort in reverse
numbers.sort(reverse=True)  # [5, 4, 3, 1, 1]
```"""

    if "sum" in q_lower or "add" in q_lower:
        return """Here's a function to sum two numbers:

```python
def add_numbers(a, b):
    return a + b

# Usage
result = add_numbers(5, 3)  # Returns 8
```"""

    # Generic code help
    return "I'd be happy to help with code! Could you tell me more specifically what you're trying to do?"


def _generate_teacher_response(prompt: str, helper) -> str:
    """
    Generate response using teacher helper or LLM directly.
    GAP 8 & 11 FIX: Added timeout and graceful degradation.
    COHERENCY FIX: Never return empty responses.
    """
    try:
        if helper and hasattr(helper, 'generate_streaming'):
            # Use streaming if available (collect full response)
            response = ""
            for chunk in helper.generate_streaming(prompt):
                response += chunk
            # COHERENCY FIX: Check for empty streaming response
            if response and response.strip():
                return response
            logger.warning("[TEACHER_RESPONSE] Streaming produced empty response")
        elif helper:
            # Fallback to maybe_call_teacher
            result = helper.maybe_call_teacher(
                question=prompt,
                context={"prompt_mode": "fast_path"}
            )
            if result and result.get("answer"):
                return result["answer"]

        # Direct LLM fallback with timeout handling
        from host_tools.llm_client.client import HostLLMTool
        llm = HostLLMTool()

        # GAP 8: Check if LLM is enabled
        if not llm.enabled:
            logger.warning("[TEACHER_RESPONSE] LLM disabled, using memory-only")
            return _generate_from_memory_only(prompt[:100])

        result = llm.complete(prompt, max_tokens=2000, temperature=0.4)
        if result.ok:
            return result.text

        # GAP 8: LLM failed - try memory-only
        logger.warning(f"[TEACHER_RESPONSE] LLM failed: {result.error}")
        return _generate_from_memory_only(prompt[:100])

    except Exception as e:
        logger.error(f"[TEACHER_RESPONSE] Error: {e}")
        # GAP 8: Graceful degradation
        return _generate_from_memory_only(prompt[:100])


def _generate_from_memory_only(query: str) -> str:
    """
    GAP 8 FIX: Generate response using only memory (no LLM).
    Called when LLM is unavailable.
    """
    try:
        from brains.memory.brain_memory import BrainMemory
        memory = BrainMemory("personal")
        memories = memory.retrieve(query=query, limit=10)

        if not memories:
            return "I don't have enough information in memory to answer that right now. My language generation system is temporarily unavailable."

        # Simple composition from memory - extract actual text content
        facts = []
        for m in memories:
            content = m.get('content', '')
            # If content is a dict, extract the 'response' or 'text' field
            if isinstance(content, dict):
                content = content.get('response', content.get('text', content.get('answer', '')))
            if content and isinstance(content, str):
                facts.append(content[:100])

        if facts:
            return f"""Based on what I remember:

{chr(10).join(f'- {fact}' for fact in facts[:5])}

(Note: My language generation system is currently unavailable, so this is a direct memory recall.)"""
        else:
            return "I'm having technical difficulties right now. Could you try again in a moment?"

    except Exception as e:
        logger.error(f"[MEMORY_ONLY] Error: {e}")
        return "I'm experiencing technical difficulties. Please try again."


def _fallback_response(query: str, context: Dict[str, Any]) -> str:
    """Fallback response when fast path imports fail."""
    return f"I received your message: '{query[:50]}...'. However, I'm having some technical difficulties. Please try again."


def get_conversation_history(limit: int = 3) -> str:
    """
    Get recent conversation history from CURRENT SESSION ONLY.
    This prevents context bleeding from old sessions.
    """
    # Use in-memory session history only (not cross-session)
    global _session_history
    if '_session_history' not in globals():
        _session_history = []

    if not _session_history:
        return "This is the start of our conversation."

    # Return only recent turns from current session
    recent = _session_history[-limit:]
    lines = []
    for turn in recent:
        role = turn.get("role", "unknown")
        content = turn.get("content", "")[:150]
        lines.append(f"{role.upper()}: {content}")

    return "\n".join(lines) if lines else "This is the start of our conversation."


def add_to_session_history(role: str, content: str):
    """Add a turn to the current session's in-memory history."""
    global _session_history
    if '_session_history' not in globals():
        _session_history = []

    _session_history.append({"role": role, "content": content})

    # Keep only last 10 turns to prevent memory bloat
    if len(_session_history) > 10:
        _session_history = _session_history[-10:]

    # SMART CONTEXT: Extract and store personal facts for cross-session memory
    if role == "user":
        _extract_and_store_facts(content)
        # FAST RECALL: Extract user attributes for O(1) lookup
        _extract_user_attributes(content)


def _extract_and_store_facts(user_message: str):
    """
    Extract personal facts from user messages and store them persistently.
    This enables cross-session context retention.
    """
    try:
        from brains.memory.brain_memory import BrainMemory
        import time

        content_lower = user_message.lower()

        # Patterns that indicate personal facts worth remembering
        fact_patterns = [
            # Possessions/pets: "my dog", "my cat", "my car"
            (r"my\s+(dog|cat|pet|car|house|job|work|name)\s+(?:is\s+|named\s+)?(\w+)", "possession"),
            # Personal info: "I am", "I'm", "I have"
            (r"i(?:'m|\s+am)\s+(?:a\s+)?(\w+)", "identity"),
            (r"i\s+have\s+(?:a\s+)?(.+?)(?:\.|,|$)", "possession"),
            (r"i\s+work\s+(?:as|at|for)\s+(.+?)(?:\.|,|$)", "occupation"),
            # Preferences: "I like", "I love", "my favorite" - capture word(s) after
            (r"i\s+(?:like|love|prefer)\s+(\w+(?:\s+\w+)?)", "preference"),
            (r"my\s+favorite\s+(\w+)\s+is\s+(\w+)", "preference"),
            # Facts: "I live in", "I'm from"
            (r"i\s+live\s+in\s+(.+?)(?:\.|,|$)", "location"),
            (r"i(?:'m|\s+am)\s+from\s+(.+?)(?:\.|,|$)", "origin"),
        ]

        # Check for fact patterns
        facts_to_store = []

        for pattern, fact_type in fact_patterns:
            matches = re.findall(pattern, content_lower)
            if matches:
                # Store the original user message as the fact
                facts_to_store.append({
                    "content": user_message,
                    "fact_type": fact_type,
                    "extracted": str(matches[0]) if matches else ""
                })
                break  # Only store once per message

        # Also detect entity introductions: "Max is my dog", "This is my friend John"
        entity_patterns = [
            r"(\w+)\s+is\s+my\s+(\w+)",  # "Max is my dog"
            r"my\s+(\w+)(?:'s)?\s+name\s+is\s+(\w+)",  # "my dog's name is Max"
        ]

        for pattern in entity_patterns:
            matches = re.findall(pattern, content_lower)
            if matches:
                facts_to_store.append({
                    "content": user_message,
                    "fact_type": "entity",
                    "extracted": str(matches[0]) if matches else ""
                })
                break

        # Store facts in persistent memory
        if facts_to_store:
            memory = BrainMemory("personal")
            for fact in facts_to_store:
                memory.store(
                    content=fact["content"],
                    tier="stm",  # Start in short-term, will migrate to MTM/LTM with access
                    metadata={
                        "kind": "user_fact",
                        "fact_type": fact["fact_type"],
                        "extracted": fact["extracted"],
                        "timestamp": time.time(),
                        "source": "conversation"
                    }
                )
                logger.debug(f"[SMART_CONTEXT] Stored fact: {fact['content'][:50]}...")

    except Exception as e:
        logger.debug(f"[SMART_CONTEXT] Fact extraction failed: {e}")


def get_smart_context(query: str, limit: int = 5) -> str:
    """
    Get smart context that combines:
    1. Current session history (recent turns)
    2. Relevant facts from persistent memory (cross-session)
    3. Relevant episodes from episodic memory
    """
    context_parts = []

    # Part 1: Recent session history - use limit parameter for marathon conversation support
    global _session_history
    if '_session_history' in globals() and _session_history:
        recent = _session_history[-limit:]  # Use limit, not hardcoded 5
        session_lines = []
        for turn in recent:
            role = turn.get("role", "unknown").upper()
            content = turn.get("content", "")[:200]  # Increased from 150 to capture more context
            session_lines.append(f"{role}: {content}")
        if session_lines:
            context_parts.append("RECENT CONVERSATION:\n" + "\n".join(session_lines))

    # Part 2: Relevant facts from persistent memory
    try:
        from brains.memory.brain_memory import BrainMemory
        memory = BrainMemory("personal")

        # Search for relevant user facts
        results = memory.retrieve(query=query, limit=limit)

        relevant_facts = []
        for r in results:
            metadata = r.get("metadata", {})
            # Only include user facts, not generic memories
            if metadata.get("kind") == "user_fact":
                content = r.get("content", "")
                if content and content not in [t.get("content", "") for t in _session_history]:
                    relevant_facts.append(f"- {content[:100]}")

        if relevant_facts:
            context_parts.append("REMEMBERED FACTS ABOUT USER:\n" + "\n".join(relevant_facts[:3]))

    except Exception as e:
        logger.debug(f"[SMART_CONTEXT] Memory retrieval failed: {e}")

    # Part 3: Check episodic memory for past relevant conversations
    try:
        from brains.memory.episodic_memory import get_episodes

        episodes = get_episodes(limit=10)
        relevant_episodes = []

        q_lower = query.lower()
        for ep in episodes:
            question = ep.get("question", "").lower()
            answer = ep.get("answer", "")
            # Check if this episode is relevant to current query
            if any(word in question for word in q_lower.split() if len(word) > 3):
                relevant_episodes.append(f"- Previously asked: {ep.get('question', '')[:80]}")

        if relevant_episodes:
            context_parts.append("RELATED PAST CONVERSATIONS:\n" + "\n".join(relevant_episodes[:2]))

    except Exception as e:
        logger.debug(f"[SMART_CONTEXT] Episode retrieval failed: {e}")

    return "\n\n".join(context_parts) if context_parts else "This is the start of our conversation."


def clear_session_history():
    """Clear the in-memory session history. Called on session reset."""
    global _session_history, _last_topic, _remembered_facts, _fact_keyword_index
    global _user_attributes_cache, _entity_cache, _relationship_cache, _topic_cache
    global _learning_intents_cache, _entity_knowledge_cache, _conversation_framing_cache, _session_context_state
    global _entity_relationships, _project_cache, _teaching_facts_cache
    _session_history = []
    _last_topic = None
    _remembered_facts = []
    _fact_keyword_index = {}
    _user_attributes_cache = {}
    _entity_cache = {}
    _relationship_cache = {}
    _topic_cache = []
    # Reset expanded context management caches
    _learning_intents_cache = []
    _entity_knowledge_cache = {}
    _conversation_framing_cache = {}
    _session_context_state = {}
    _entity_relationships = {}
    _project_cache = {}
    _teaching_facts_cache = {}


# Track the last topic being discussed for follow-up context
_last_topic = None


def _set_last_topic(topic: str):
    """Set the last topic discussed for follow-up handling."""
    global _last_topic
    if topic and len(topic) > 3:  # Avoid storing tiny fragments
        _last_topic = topic[:200]  # Cap at 200 chars


def _get_last_topic() -> str:
    """Get the last topic discussed."""
    global _last_topic
    return _last_topic or ""


def get_relevant_memories(query: str, limit: int = 5) -> str:
    """
    Get relevant memories for the query.
    GAP 4 & 12 FIX: Added contradiction filtering.
    FIX: Also check current session history for recent facts.
    """
    facts = []

    # FIRST: Check current session history for recent facts (in-session recall)
    global _session_history
    if '_session_history' in globals() and _session_history:
        q_lower = query.lower()
        for turn in _session_history:
            if turn.get("role") == "user":
                content = turn.get("content", "")
                c_lower = content.lower()
                # Check if query words appear in this turn (basic relevance)
                query_words = [w for w in q_lower.split() if len(w) > 3]
                for word in query_words:
                    if word in c_lower:
                        facts.append(f"- (This session) You said: {content[:150]}")
                        break

    # SECOND: Check persistent memory
    try:
        from brains.memory.brain_memory import BrainMemory
        memory = BrainMemory("personal")

        # Get more results to allow filtering
        results = memory.retrieve(query=query, limit=limit * 2)

        if results:
            # GAP 12: Filter out contradicted/corrected facts
            filtered = []
            for r in results:
                metadata = r.get("metadata", {})
                tags = metadata.get("tags", [])

                # Skip contradicted facts
                if "contradicted" in tags:
                    continue
                # Skip corrected facts
                if "corrected" in tags:
                    continue
                # Skip identity lies from LLM
                content = str(r.get("content", "")).lower()
                if "large language model" in content:
                    continue
                if "i am chatgpt" in content or "i am claude" in content:
                    continue

                # Prefer canonical facts
                if "canonical" in tags:
                    filtered.insert(0, r)  # Put canonical first
                else:
                    filtered.append(r)

            # Take top N after filtering
            final = filtered[:limit]

            for r in final:
                content = r.get("content", "")
                if content:
                    if isinstance(content, dict):
                        content = str(content.get("query", content))
                    facts.append(f"- {str(content)[:150]}")

    except Exception as e:
        logger.warning(f"[MEMORIES] Error: {e}")

    return "\n".join(facts[:limit]) if facts else "No relevant memories found."


def safe_background_learning(query: str, response: str) -> None:
    """
    GAP 7 FIX: Background learning with error handling.
    Never fails silently - logs errors for debugging.

    ENHANCED: Now integrates with skill tracking and learning loop
    so brains properly learn from each conversation turn.
    """
    try:
        from brains.memory.brain_memory import BrainMemory
        memory = BrainMemory("personal")

        # Store conversation turn
        memory.store(
            content={
                "query": query,
                "response": response[:500],
                "learned_at": "auto"
            },
            metadata={
                "kind": "conversation_learning",
                "source": "fast_path",
                "tags": ["conversation", "fast_path"]
            }
        )

        logger.info(f"[BACKGROUND_LEARNING] Stored conversation turn for: {query[:50]}...")

    except Exception as e:
        logger.error(f"[BACKGROUND_LEARNING] Memory storage failed: {e}")

    # ENHANCED: Skill tracking and domain learning
    try:
        from brains.learning.learning_loop import classify_domain, extract_tags_from_query
        from brains.cognitive.learning_contract.skill_tracker import (
            get_skill_tracker,
            record_domain_outcome,
        )
        from brains.cognitive.learning_contract.task_types import classify_task_type

        # Classify the domain and task type
        domain = classify_domain(query)
        task_type = classify_task_type(query, {})
        tags = extract_tags_from_query(query)

        # Determine if this was a successful response
        # A response is successful if it's not empty and not an error
        is_success = (
            response and
            len(response.strip()) > 20 and
            "I don't know" not in response and
            "I'm not certain" not in response and
            "error" not in response.lower()[:50]
        )

        # Record outcome for skill tracking
        # tracker.record_outcome saves the profile automatically
        tracker = get_skill_tracker()
        profile = tracker.record_outcome(task_type, success=is_success)

        logger.info(f"[SKILL_TRACKING] Domain: {domain.value}, Task: {task_type.value}, Success: {is_success}, Level: {profile.level.value}")

    except Exception as e:
        logger.warning(f"[SKILL_TRACKING] Failed: {e}")

    # ENHANCED: Store learning episode for the learning daemon
    try:
        from brains.cognitive.learning_contract.episode_storage import (
            store_conversation_turn,
            learn_style_from_answer,
            RouteUsed,
        )

        # Store conversation turn with correct function signature
        store_conversation_turn(
            user_query=query,
            teacher_answer=response[:1000],
            route_used=RouteUsed.TEACHER_FAST_PATH,
            tools_used=[],
        )

        # Learn style patterns from the response
        learn_style_from_answer(query, response[:1000])

        logger.info(f"[LEARNING_EPISODE] Stored learning episode for daemon processing")

    except Exception as e:
        logger.warning(f"[LEARNING_EPISODE] Failed: {e}")

    # Store error for debugging (in a separate try block)
    try:
        pass  # No errors to store if we got here
    except Exception:
        pass


# =============================================================================
# FIX 7: FAST CHAT REPL - Teacher-First Architecture
# =============================================================================
# ONLY 2 MODES: chat and full. NOTHING ELSE.
# =============================================================================

def _run_fast_chat_repl():
    """
    Maven chat with only 2 modes: chat and full.
    """
    import os

    # Check if full access mode from environment
    full_access = os.getenv("MAVEN_FULL_ACCESS", "false").lower() == "true"

    print("=" * 60)
    print("  MAVEN")
    print("=" * 60)
    print()
    print("  [1] chat  - conversation")
    print("  [2] full  - execute commands")
    print("  [3] audit - run conversational audit")
    print()

    current_mode = "full" if full_access else "chat"
    print(f"mode: {current_mode}")
    print()

    # Clear session history at start to prevent cross-session context bleeding
    clear_session_history()

    while True:
        try:
            # Print READY marker with newline BEFORE input() so subprocess can detect it
            # input() prints prompt without newline, blocking readline() in subprocess
            print(f"[{current_mode}] >", flush=True)
            user_input = input().strip()

            if not user_input:
                continue

            # Exit
            if user_input.lower() in ['exit', 'quit', 'q']:
                try:
                    from brains.memory.session_manager import end_session
                    end_session()
                except Exception:
                    pass
                print("bye")
                break

            # Switch modes
            if user_input in ['1', 'chat']:
                current_mode = "chat"
                print("mode: chat")
                continue

            if user_input in ['2', 'full']:
                current_mode = "full"
                _enable_full_access()
                print("mode: full")
                continue

            # Run audit
            if user_input in ['3', 'audit']:
                print("\n[AUDIT] Starting conversational audit...")
                try:
                    from tools.conv_audit_runner import run_conversational_audit
                    report_path = run_conversational_audit(
                        profile="FULL_AGENCY",
                        mock=False,
                        judges=["local"],
                        output_dir="artifacts",
                        verbose=True,
                        c3_only=False,  # Full audit: C3 + CCS
                        extended=True,  # Include extended tests for full coverage
                    )
                    print(f"\n[AUDIT] Complete! Report: {report_path}")
                except Exception as e:
                    print(f"\n[AUDIT] Error: {e}")
                continue

            # CMD in full mode
            if user_input.lower().startswith('cmd '):
                if current_mode != "full":
                    print("error: switch to full mode first (type 2)")
                    continue
                command = user_input[4:].strip()
                if command:
                    print(_execute_cmd(command))
                continue

            # Track user input FIRST so memory recall can find previous turns
            add_to_session_history("user", user_input)

            # Process query
            context = _get_conversation_context()
            context["mode"] = current_mode

            # ALWAYS use handle_user_query in FULL mode - it checks agency patterns FIRST
            # This ensures tools like time_now, browser, chatgpt, grok get priority
            # over Teacher, even for queries that look like "normal conversation"
            if current_mode == "full":
                response = handle_user_query(user_input, context)
            elif is_normal_conversation(user_input):
                response = teacher_fast_path(user_input, context)
            else:
                response = teacher_fast_path(user_input, context)

            # Track Maven's response in session history
            if response:
                clean_response = response.replace("\nMaven:", "").replace("Maven:", "").strip()
                add_to_session_history("maven", clean_response)

                # Track the topic being discussed for follow-up handling
                # Use the user's question as the topic (if it's substantive)
                if len(user_input) > 10 and not _is_followup_query(user_input):
                    _set_last_topic(user_input)

                # Also save to persistent memory for cross-session recall
                try:
                    from brains.memory.session_manager import record_turn
                    record_turn(user_input, clean_response)
                except Exception:
                    pass  # Don't break chat if recording fails

            if response and not response.startswith("\nMaven:"):
                # Print with Maven: prefix for subprocess parsing
                print(f"Maven: {response}", flush=True)

        except KeyboardInterrupt:
            try:
                from brains.memory.session_manager import end_session
                end_session()
            except Exception:
                pass
            print("\nbye")
            break
        except EOFError:
            try:
                from brains.memory.session_manager import end_session
                end_session()
            except Exception:
                pass
            print("\nbye")
            break
        except Exception as e:
            print(f"error: {e}")


def _enable_full_access():
    """Enable full access mode."""
    try:
        from brains.tools.execution_guard import enable_full_agency
        enable_full_agency("user enabled via mode command")
        print("[FULL_ACCESS] Enabled - you can now execute commands")
    except Exception as e:
        print(f"[WARNING] Could not enable full access: {e}")


def _execute_cmd(command: str) -> str:
    """
    Execute a command directly (no shell, just subprocess).
    Only available in full access mode.
    """
    import subprocess
    import shlex

    try:
        # Parse command safely
        args = shlex.split(command)
        if not args:
            return "Empty command"

        # Block dangerous commands
        dangerous = ['rm -rf /', 'mkfs', 'dd if=', ':(){', 'fork bomb']
        cmd_lower = command.lower()
        for d in dangerous:
            if d in cmd_lower:
                return f"[BLOCKED] Dangerous command detected: {d}"

        # Execute without shell
        result = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=30,
            cwd=None
        )

        output = result.stdout
        if result.stderr:
            output += f"\n[stderr] {result.stderr}"
        if result.returncode != 0:
            output += f"\n[exit code: {result.returncode}]"

        return output.strip() if output.strip() else "[No output]"

    except subprocess.TimeoutExpired:
        return "[TIMEOUT] Command took too long (30s limit)"
    except FileNotFoundError:
        return f"[ERROR] Command not found: {args[0] if args else command}"
    except Exception as e:
        return f"[ERROR] {e}"


def _get_conversation_context() -> Dict[str, Any]:
    """Get current conversation context for the fast path."""
    context = {
        "mode": "fast_chat",
        "timestamp": None,
        "user": {},
    }

    # Try to get timestamp
    try:
        from datetime import datetime
        context["timestamp"] = datetime.now().isoformat()
    except Exception:
        pass

    return context


HERE = Path(__file__).resolve().parent
# Ensure the project root (this directory) is on sys.path so that local
# packages like ``api`` and ``ui`` can be imported when there is no nested
# ``maven`` package present.  This mirrors the dynamic import logic used in
# other entry points such as ``maven/ui/maven_chat.py``.
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

# Import the new canonical pipeline runner
from brains.pipeline.pipeline_runner import run_pipeline

# Keep legacy memory_librarian import for backward compatibility
lib = HERE / "brains" / "cognitive" / "memory_librarian" / "service" / "memory_librarian.py"
spec = importlib.util.spec_from_file_location("memory_librarian", lib)
mod = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mod)


def _show_memory_tiers():
    """Show memory tier introspection for debugging."""
    try:
        from brains.memory.tier_manager import TierManager
        from pathlib import Path

        # Get Maven root
        maven_root = Path(__file__).parent

        # Check key brains with their storage locations
        brains_to_check = [
            ("personal", maven_root / "brains" / "personal"),
            ("language", maven_root / "brains" / "cognitive" / "language"),
            ("reasoning", maven_root / "brains" / "cognitive" / "reasoning"),
            ("system_history", maven_root / "brains" / "cognitive" / "system_history"),
            ("pattern_recognition", maven_root / "brains" / "cognitive" / "pattern_recognition"),
        ]

        print("\n  Brain                    STM    MTM    LTM    Archive")
        print("  " + "-" * 60)

        for brain_id, brain_path in brains_to_check:
            # Check if the brain's memory directory exists
            memory_path = brain_path / "memory"
            if memory_path.exists() and any(memory_path.iterdir()):
                tm = TierManager(brain_id, brain_path, enforce_tier_governance=False)
                counts = tm.get_tier_counts()
                print(f"  {brain_id:24s} {counts.get('stm', 0):5d}  {counts.get('mtm', 0):5d}  {counts.get('ltm', 0):5d}  {counts.get('archive', 0):7d}")
            else:
                print(f"  {brain_id:24s}     0      0      0        0")

        print("")
    except Exception as e:
        print(f"  Error inspecting memory tiers: {e}\n")


if __name__ == "__main__":
    """
    When invoked as a script, this entry point will launch the natural language
    chat interface if no command line arguments are provided.  Otherwise, it
    treats the first argument as a query and an optional second argument as a
    confidence value and executes the full Maven pipeline on that input.  This
    dual behaviour makes `run_maven.py` both a convenient button to start
    interactive conversation and a quick way to test the pipeline with a
    single query.
    """
    # ==========================================================================
    # CAPABILITY STARTUP SCAN
    # ==========================================================================
    # Run capability probes at startup to build the truth object.
    # This ensures self_model can answer "can you X" questions accurately.
    try:
        from brains.system_capabilities import scan_all_capabilities
        _capability_scan = scan_all_capabilities()
        # Log summary to console
        print(f"[STARTUP] Capabilities: {_capability_scan.get('summary', 'unknown')}")
    except Exception as e:
        print(f"[STARTUP] Capability scan failed: {e}")
        _capability_scan = None

    # ==========================================================================
    # FIX 5: IDENTITY BOOTSTRAP
    # ==========================================================================
    # Bootstrap canonical identity facts to memory on startup.
    # This prevents identity hallucination (e.g., "project management tool").
    try:
        from brains.cognitive.self_model.system_identity import bootstrap_identity
        # Get memory_librarian for identity storage
        _identity_result = bootstrap_identity(mod)
        if _identity_result.get("ok"):
            print(f"[STARTUP] Identity: {_identity_result.get('stored', 0)} canonical facts bootstrapped")
        else:
            print(f"[STARTUP] Identity bootstrap partial: {_identity_result.get('errors', [])[:2]}")
    except Exception as e:
        print(f"[STARTUP] Identity bootstrap failed: {e}")

    # Start the learning daemon for pattern analysis.  The daemon runs in
    # a background thread and periodically calls the LLM service to learn
    # new templates from logged interactions.  If the import fails or
    # scheduling is disabled, the daemon is skipped silently.
    try:
        from brains.agent.learning_daemon import LearningDaemon  # type: ignore
        import threading
        _learning_daemon = LearningDaemon()
        # Only start the daemon if learning is enabled
        if getattr(_learning_daemon, "learning_enabled", True):
            _ld_thread = threading.Thread(
                target=_learning_daemon.start_scheduled, daemon=True
            )
            _ld_thread.start()
    except Exception:
        # If anything goes wrong, do not block startup; the pipeline
        # continues without background learning.
        _learning_daemon = None

    # Parse optional arguments
    # --mode: "architect" (default) or "execution"
    # --pipeline: "canonical" (new pipeline) or "legacy" (old memory_librarian)
    # --debug-memory: show memory tier introspection
    # --full-agency: enable FULL_AGENCY mode for unrestricted access
    # --profile: "safe_chat" or "full_agency" - capability profile selection
    # --omniscient: enable omniscient observer mode (perpetual learning)
    mode = "architect"
    use_pipeline = "canonical"  # Default to new canonical pipeline
    debug_memory = False
    full_agency = False
    omniscient_mode = False
    profile = None  # Will be set by --profile or environment
    args = sys.argv[1:]

    if "--mode" in args:
        try:
            idx = args.index("--mode")
            if idx + 1 < len(args):
                mode = args[idx + 1].strip().lower() or mode
                del args[idx:idx + 2]
        except Exception:
            pass

    if "--pipeline" in args:
        try:
            idx = args.index("--pipeline")
            if idx + 1 < len(args):
                use_pipeline = args[idx + 1].strip().lower() or use_pipeline
                del args[idx:idx + 2]
                # Warn if using legacy pipeline
                if use_pipeline == "legacy":
                    print("\n" + "⚠" * 30)
                    print("⚠ WARNING: Using LEGACY pipeline mode")
                    print("⚠ This mode is DEPRECATED and may be removed in future versions")
                    print("⚠ The canonical pipeline is now the default and recommended mode")
                    print("⚠ If you encounter issues, please report them instead of using legacy mode")
                    print("⚠" * 30 + "\n")
        except Exception:
            pass

    if "--debug-memory" in args:
        debug_memory = True
        args.remove("--debug-memory")

    # Handle --profile argument (new preferred way)
    if "--profile" in args:
        try:
            idx = args.index("--profile")
            if idx + 1 < len(args):
                profile = args[idx + 1].strip().lower()
                del args[idx:idx + 2]
        except Exception:
            pass

    if "--full-agency" in args:
        full_agency = True
        profile = "full_agency"
        args.remove("--full-agency")

    if "--omniscient" in args:
        omniscient_mode = True
        args.remove("--omniscient")

    # Check environment variables for profile/mode
    import os

    # MAVEN_CAPABILITIES_PROFILE takes precedence
    env_profile = os.getenv("MAVEN_CAPABILITIES_PROFILE", "").upper()
    if env_profile in ("SAFE_CHAT", "FULL_AGENCY"):
        profile = env_profile.lower()

    # MAVEN_EXECUTION_MODE as fallback
    env_mode = os.getenv("MAVEN_EXECUTION_MODE", "").upper()
    if env_mode == "FULL_AGENCY" and profile is None:
        profile = "full_agency"

    # Activate the selected profile
    if profile == "full_agency":
        try:
            from capabilities import activate_profile
            activate_profile("FULL_AGENCY", "enabled via --profile or environment")
            print("[STARTUP] Profile: FULL_AGENCY - unrestricted access to all tools")
            full_agency = True
        except Exception as e:
            # Fallback to old method
            try:
                from brains.tools.execution_guard import enable_full_agency
                enable_full_agency("enabled via --profile or environment")
                print("[STARTUP] FULL_AGENCY mode enabled - unrestricted access to all tools")
                full_agency = True
            except Exception as e2:
                print(f"[STARTUP] Warning: Failed to enable FULL_AGENCY mode: {e2}")
    elif profile == "safe_chat":
        try:
            from capabilities import activate_profile
            activate_profile("SAFE_CHAT", "enabled via --profile or environment")
            print("[STARTUP] Profile: SAFE_CHAT - pure conversation, no tools")
        except Exception as e:
            # Fallback to execution guard
            try:
                from brains.tools.execution_guard import enable_safe_chat
                enable_safe_chat("enabled via --profile or environment")
                print("[STARTUP] SAFE_CHAT mode enabled - no tool access")
            except Exception as e2:
                print(f"[STARTUP] Warning: Failed to enable SAFE_CHAT mode: {e2}")
    elif profile is None:
        # No profile specified - use default behavior (check old env var)
        if env_mode == "FULL_AGENCY":
            try:
                from brains.tools.execution_guard import enable_full_agency
                enable_full_agency("enabled via MAVEN_EXECUTION_MODE environment variable")
                print("[STARTUP] FULL_AGENCY mode enabled via environment variable")
                full_agency = True
            except Exception as e:
                print(f"[STARTUP] Warning: Failed to enable FULL_AGENCY mode: {e}")

    # ==========================================================================
    # OMNISCIENT OBSERVER MODE
    # ==========================================================================
    # Start Maven's perpetual learning system if --omniscient flag is set.
    # This enables continuous observation, pattern learning, and model building.
    _omniscient_observer = None
    if omniscient_mode or os.getenv("MAVEN_OMNISCIENT_MODE", "").upper() == "TRUE":
        try:
            from brains.agent.autonomous.omniscient_observer import (
                start_omniscient_mode,
                record_activity,
                record_event,
            )

            def _on_important_observation(obs):
                """Callback for important observations."""
                print(f"\n[OMNISCIENT] Important: {obs.content[:100]}...")

            _omniscient_observer = start_omniscient_mode(
                interrupt_callback=_on_important_observation
            )
            print("[STARTUP] Omniscient Observer: Always watching, always learning")

            # Make recording functions available globally for other modules
            import builtins
            builtins._maven_record_activity = record_activity
            builtins._maven_record_event = record_event
        except Exception as e:
            print(f"[STARTUP] Omniscient Observer failed to start: {e}")
            _omniscient_observer = None

    if "--self-test-routing" in args:
        # Run routing self-test and exit
        print("\n" + "=" * 60)
        print("MAVEN ROUTING + MEMORY SELF-TEST")
        print("=" * 60)
        try:
            from brains.cognitive.memory_librarian.service import memory_librarian
            question = "what sound does a duck make"

            print(f"\nTesting with question: '{question}'")
            print("\n[1/2] First query (should call teacher)...")

            resp1 = memory_librarian.service_api({
                "op": "RUN_PIPELINE",
                "mid": generate_mid(),
                "payload": {"text": question, "confidence": 1.0}
            })

            if not resp1.get("ok"):
                print(f"✗ First query failed: {resp1.get('error')}")
                sys.exit(1)

            ctx1 = resp1.get("payload", {}).get("context", {})
            verdict1 = ctx1.get("verdict")
            teacher_facts_stored = ctx1.get("teacher_facts_stored", 0)

            teacher_called_first = verdict1 == "LEARNED"
            print(f"  Verdict: {verdict1}")
            print(f"  Teacher facts stored: {teacher_facts_stored}")
            print(f"  [SELF-TEST] Teacher called on first query: {'YES' if teacher_called_first else 'NO'}")

            print("\n[2/2] Second query (should use memory)...")

            resp2 = memory_librarian.service_api({
                "op": "RUN_PIPELINE",
                "mid": generate_mid(),
                "payload": {"text": question, "confidence": 1.0}
            })

            if not resp2.get("ok"):
                print(f"✗ Second query failed: {resp2.get('error')}")
                sys.exit(1)

            ctx2 = resp2.get("payload", {}).get("context", {})
            verdict2 = ctx2.get("verdict")
            banks_used = ctx2.get("stage_2R_top_banks", [])

            teacher_called_second = verdict2 == "LEARNED"
            print(f"  Verdict: {verdict2}")
            print(f"  Banks used: {banks_used}")
            print(f"  [SELF-TEST] Teacher called on second query: {'YES' if teacher_called_second else 'NO'}")
            print(f"  [SELF-TEST] Learned routing rule applied: {'YES' if len(banks_used) > 0 else 'UNKNOWN'}")
            print(f"  [SELF-TEST] Banks used on second query: {', '.join(banks_used) if banks_used else 'none'}")

            # Determine pass/fail
            if teacher_called_first and not teacher_called_second and len(banks_used) > 0:
                print("\n" + "=" * 60)
                print("[SELF-TEST] RESULT: PASS")
                print("=" * 60)
                print("✓ Teacher called on first query")
                print("✓ Memory used on second query (teacher not called)")
                print(f"✓ Routing selected banks: {', '.join(banks_used)}")
                sys.exit(0)
            else:
                print("\n" + "=" * 60)
                print("[SELF-TEST] RESULT: FAIL")
                print("=" * 60)
                if not teacher_called_first:
                    print("✗ Teacher was not called on first query")
                if teacher_called_second:
                    print("✗ Teacher was called on second query (should use memory)")
                if len(banks_used) == 0:
                    print("✗ No banks were used on second query")
                sys.exit(1)

        except Exception as e:
            print(f"\n✗ Self-test failed with exception: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)

    # ==========================================================================
    # CHAT MODE - ONLY 2 MODES: chat and full
    # ==========================================================================
    if not args:
        _run_fast_chat_repl()
    else:
        # Use provided arguments to run the pipeline on a single input
        # Remaining args correspond to query and optional confidence
        text = args[0] if len(args) >= 1 else "The cell divides by mitosis."
        try:
            conf = float(args[1]) if len(args) >= 2 else 0.8
        except Exception:
            conf = 0.8

        # Before running the pipeline, consolidate memory tiers.  This ensures
        # that high‑importance facts from previous sessions are promoted into
        # mid‑ and long‑term stores and available for retrieval.  Errors are
        # swallowed to avoid disrupting normal pipeline execution.
        try:
            from brains.cognitive.memory_consolidation import consolidate_memories  # type: ignore
            consolidate_memories()
        except Exception:
            pass

        # Choose pipeline based on --pipeline flag
        if use_pipeline == "canonical":
            print(f"\n🔧 Using CANONICAL PIPELINE (PipelineExecutor with 9 mandatory stages)")
            print(f"📝 Query: {text}\n")
            result = run_pipeline(text, conf)

            # Show execution log if in architect mode
            if mode == "architect" and result.get("execution_log"):
                print("\n📊 PIPELINE EXECUTION LOG:")
                for entry in result.get("execution_log", []):
                    status_icon = "✓" if entry.get("success") else "✗"
                    print(f"  {status_icon} {entry.get('stage'):20s} {entry.get('duration_ms', 0):6.1f}ms")

            # Show memory tier introspection if requested
            if debug_memory:
                print("\n🧠 MEMORY TIER INTROSPECTION:")
                _show_memory_tiers()

            if mode == "execution":
                print(json.dumps({"ok": result.get("ok"), "response": result.get("response", "")}, indent=2))
            else:
                print(f"\n💬 RESPONSE:\n{result.get('response', '')}\n")
                if result.get("ok"):
                    print(f"✓ Pipeline completed successfully")
                else:
                    print(f"✗ Pipeline failed: {result.get('error', 'Unknown error')}")
        else:
            # Legacy path
            print("\n⚠️  Using LEGACY PIPELINE (memory_librarian RUN_PIPELINE)")
            resp = mod.service_api({"op": "RUN_PIPELINE", "mid": generate_mid(), "payload": {"text": text, "confidence": conf}})
            if mode == "execution":
                try:
                    ctx = (resp.get("payload") or {}).get("context") or {}
                    final_ans = ctx.get("final_answer")
                    final_conf = ctx.get("final_confidence")
                    if final_ans is not None:
                        print(json.dumps({"final_answer": final_ans, "final_confidence": final_conf}, indent=2, ensure_ascii=False))
                    else:
                        print(json.dumps(resp, indent=2))
                except Exception:
                    print(json.dumps(resp, indent=2))
            else:
                # Architect mode: show final answer if available for brevity
                try:
                    ctx = (resp.get("payload") or {}).get("context") or {}
                    final_ans = ctx.get("final_answer")
                    final_conf = ctx.get("final_confidence")
                    if final_ans is not None:
                        print(json.dumps({"final_answer": final_ans, "final_confidence": final_conf}, indent=2, ensure_ascii=False))
                    else:
                        print(json.dumps(resp, indent=2))
                except Exception:
                    print(json.dumps(resp, indent=2))