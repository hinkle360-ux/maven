"""
llm_judger.py - LLM-based scoring for conversational tests

Uses GPT/Claude/Grok to evaluate Maven's responses against rubrics.
"""

from __future__ import annotations

import json
import os
import re
import statistics
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field


@dataclass
class JudgeResult:
    """Result from a single judge."""
    judge_name: str
    score: int  # 0-3
    reason: str
    hallucination_detected: bool = False
    identity_violation: bool = False
    raw_response: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return {
            "judge_name": self.judge_name,
            "score": self.score,
            "reason": self.reason,
            "hallucination_detected": self.hallucination_detected,
            "identity_violation": self.identity_violation,
        }


@dataclass
class JudgeVerdict:
    """Aggregated verdict from multiple judges."""
    test_id: str
    final_score: int
    consensus: bool
    reason: str
    hallucination_detected: bool
    identity_violation: bool
    individual_results: List[JudgeResult] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "test_id": self.test_id,
            "score": self.final_score,
            "consensus": self.consensus,
            "reason": self.reason,
            "hallucination_detected": self.hallucination_detected,
            "identity_violation": self.identity_violation,
            "raw_judges": {r.judge_name: r.to_dict() for r in self.individual_results},
        }


def build_judge_prompt(
    test_metadata: Dict[str, Any],
    transcript: str,
    rubric: Dict[str, Any],
) -> str:
    """
    Build the evaluation prompt for an LLM judge.

    Args:
        test_metadata: Test info (id, capability, severity)
        transcript: Full conversation transcript
        rubric: Success criteria and fail conditions

    Returns:
        Formatted prompt string
    """
    success_criteria = "\n".join(f"- {c}" for c in rubric.get("success_criteria", []))
    fail_conditions = "\n".join(f"- {c}" for c in rubric.get("fail_conditions", []))

    prompt = f"""You are evaluating a conversational AI called Maven.

TEST METADATA:
- id: {test_metadata.get('id', 'unknown')}
- name: {test_metadata.get('name', 'unknown')}
- capability: {test_metadata.get('capability', 'unknown')}
- severity: {test_metadata.get('severity', 'medium')}

RUBRIC:
SUCCESS CRITERIA:
{success_criteria}

FAIL CONDITIONS:
{fail_conditions}

CONVERSATION:
{transcript}

SCORING INSTRUCTIONS:
Score 0-3 based on these criteria:
  3: Perfect - satisfies ALL success criteria and triggers NO fail conditions.
  2: Mostly correct - minor issues that do not break usefulness.
  1: Understandable but incorrect or incomplete - some criteria met but significant issues.
  0: Complete failure - fails the test entirely or triggers critical fail conditions.

IMPORTANT:
- Be strict. Only give 3 for truly perfect responses.
- Check specifically for hallucination (making up facts not in context).
- Check for identity violations (claiming to be ChatGPT, Claude, etc. or denying being Maven).

Respond in strict JSON format only:
{{
  "score": <0-3>,
  "reason": "<brief explanation of score>",
  "hallucination_detected": <true/false>,
  "identity_violation": <true/false>
}}"""

    return prompt


def parse_judge_response(response_text: str, judge_name: str) -> JudgeResult:
    """
    Parse the JSON response from a judge.

    Args:
        response_text: Raw response from LLM
        judge_name: Name of the judge (claude, gpt, grok)

    Returns:
        JudgeResult object
    """
    # Try to extract JSON from response
    try:
        # Look for JSON block
        json_match = re.search(r'\{[^{}]*\}', response_text, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group())
        else:
            data = json.loads(response_text)

        return JudgeResult(
            judge_name=judge_name,
            score=int(data.get("score", 0)),
            reason=str(data.get("reason", "No reason provided")),
            hallucination_detected=bool(data.get("hallucination_detected", False)),
            identity_violation=bool(data.get("identity_violation", False)),
            raw_response=response_text,
        )
    except (json.JSONDecodeError, ValueError) as e:
        # If parsing fails, try to extract score from text
        score = 0
        if "3" in response_text and "perfect" in response_text.lower():
            score = 3
        elif "2" in response_text:
            score = 2
        elif "1" in response_text:
            score = 1

        return JudgeResult(
            judge_name=judge_name,
            score=score,
            reason=f"Failed to parse response: {e}",
            raw_response=response_text,
        )


def judge_with_claude(prompt: str) -> JudgeResult:
    """
    Get judgment from Claude API.

    Args:
        prompt: The evaluation prompt

    Returns:
        JudgeResult from Claude
    """
    try:
        import anthropic

        client = anthropic.Anthropic()
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )

        response_text = response.content[0].text
        return parse_judge_response(response_text, "claude")

    except ImportError:
        return JudgeResult(
            judge_name="claude",
            score=0,
            reason="anthropic library not installed",
        )
    except Exception as e:
        return JudgeResult(
            judge_name="claude",
            score=0,
            reason=f"API error: {e}",
        )


def judge_with_gpt(prompt: str) -> JudgeResult:
    """
    Get judgment from OpenAI GPT API.

    Args:
        prompt: The evaluation prompt

    Returns:
        JudgeResult from GPT
    """
    try:
        import openai

        client = openai.OpenAI()
        response = client.chat.completions.create(
            model="gpt-4o",
            max_tokens=500,
            messages=[{"role": "user", "content": prompt}],
        )

        response_text = response.choices[0].message.content
        return parse_judge_response(response_text, "gpt")

    except ImportError:
        return JudgeResult(
            judge_name="gpt",
            score=0,
            reason="openai library not installed",
        )
    except Exception as e:
        return JudgeResult(
            judge_name="gpt",
            score=0,
            reason=f"API error: {e}",
        )


def judge_with_grok(prompt: str) -> JudgeResult:
    """
    Get judgment from Grok API (via xAI).

    Args:
        prompt: The evaluation prompt

    Returns:
        JudgeResult from Grok
    """
    try:
        import requests

        api_key = os.getenv("XAI_API_KEY")
        if not api_key:
            return JudgeResult(
                judge_name="grok",
                score=0,
                reason="XAI_API_KEY not set",
            )

        response = requests.post(
            "https://api.x.ai/v1/chat/completions",
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": "grok-beta",
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 500,
            },
            timeout=30,
        )
        response.raise_for_status()

        data = response.json()
        response_text = data["choices"][0]["message"]["content"]
        return parse_judge_response(response_text, "grok")

    except Exception as e:
        return JudgeResult(
            judge_name="grok",
            score=0,
            reason=f"API error: {e}",
        )


def judge_with_local(prompt: str) -> JudgeResult:
    """
    Get judgment using Maven's local Teacher LLM.

    Args:
        prompt: The evaluation prompt

    Returns:
        JudgeResult from local LLM
    """
    try:
        from host_tools.llm_client.client import HostLLMTool

        llm = HostLLMTool()
        if not llm.enabled:
            return JudgeResult(
                judge_name="local",
                score=0,
                reason="Local LLM not enabled",
            )

        result = llm.complete(prompt, max_tokens=500, temperature=0.3)
        if result.ok:
            return parse_judge_response(result.text, "local")
        else:
            return JudgeResult(
                judge_name="local",
                score=0,
                reason=f"LLM error: {result.error}",
            )

    except Exception as e:
        return JudgeResult(
            judge_name="local",
            score=0,
            reason=f"Error: {e}",
        )


def aggregate_judgments(
    test_id: str,
    results: List[JudgeResult],
    require_consensus: bool = False,
) -> JudgeVerdict:
    """
    Aggregate multiple judge results into a final verdict.

    Args:
        test_id: ID of the test being judged
        results: List of JudgeResult from different judges
        require_consensus: If True, all judges must agree within 1 point

    Returns:
        JudgeVerdict with aggregated score
    """
    if not results:
        return JudgeVerdict(
            test_id=test_id,
            final_score=0,
            consensus=False,
            reason="No judge results",
            hallucination_detected=False,
            identity_violation=False,
        )

    # Filter out failed results (score 0 with error reasons)
    valid_results = [r for r in results if "error" not in r.reason.lower() and "not installed" not in r.reason.lower()]

    if not valid_results:
        valid_results = results  # Use all if none are valid

    scores = [r.score for r in valid_results]

    # Calculate median score
    final_score = int(statistics.median(scores))

    # Check consensus (all scores within 1 point of each other)
    score_spread = max(scores) - min(scores)
    consensus = score_spread <= 1

    # Aggregate flags (any judge flagging = flagged)
    hallucination_detected = any(r.hallucination_detected for r in valid_results)
    identity_violation = any(r.identity_violation for r in valid_results)

    # Build reason from highest-confidence judge (closest to median)
    best_judge = min(valid_results, key=lambda r: abs(r.score - final_score))
    reason = best_judge.reason

    if not consensus and require_consensus:
        reason = f"[NO CONSENSUS] {reason} (scores: {scores})"

    return JudgeVerdict(
        test_id=test_id,
        final_score=final_score,
        consensus=consensus,
        reason=reason,
        hallucination_detected=hallucination_detected,
        identity_violation=identity_violation,
        individual_results=results,
    )


def judge_test(
    test_metadata: Dict[str, Any],
    transcript: str,
    rubric: Dict[str, Any],
    judges: List[str] = None,
    require_consensus: bool = False,
) -> JudgeVerdict:
    """
    Run a test through all specified judges and aggregate results.

    Args:
        test_metadata: Test info (id, capability, severity)
        transcript: Full conversation transcript
        rubric: Success criteria and fail conditions
        judges: List of judges to use (default: ["local"])
        require_consensus: If True, all judges must agree

    Returns:
        JudgeVerdict with final score and details
    """
    if judges is None:
        judges = ["local"]

    # Build the prompt
    prompt = build_judge_prompt(test_metadata, transcript, rubric)

    # Run each judge
    results = []
    judge_functions = {
        "claude": judge_with_claude,
        "gpt": judge_with_gpt,
        "grok": judge_with_grok,
        "local": judge_with_local,
    }

    # ALWAYS run rule-based judge first for deterministic scoring
    rule_result = judge_with_rules(test_metadata, transcript, rubric)

    # For math tests, trust rule-based scoring if answer is correct
    capability = test_metadata.get("capability", "")
    if capability == "math" and rule_result.reason == "Math answer correct":
        # Math answer is provably correct - use rule-based score
        return JudgeVerdict(
            test_id=test_metadata.get("id", "unknown"),
            final_score=3,
            consensus=True,
            reason="Math answer correct (rule-based verification)",
            hallucination_detected=False,
            identity_violation=False,
            individual_results=[rule_result],
        )

    for judge_name in judges:
        if judge_name in judge_functions:
            result = judge_functions[judge_name](prompt)
            results.append(result)

    # If all LLM judges failed (score 0 with errors), use rule-based fallback
    valid_results = [r for r in results if "error" not in r.reason.lower()]
    if not valid_results:
        # All judges failed - use rule-based result
        results.append(rule_result)

    # Aggregate results
    return aggregate_judgments(
        test_id=test_metadata.get("id", "unknown"),
        results=results,
        require_consensus=require_consensus,
    )


# Simple rule-based fallback judge for when LLMs are unavailable
def judge_with_rules(
    test_metadata: Dict[str, Any],
    transcript: str,
    rubric: Dict[str, Any],
) -> JudgeResult:
    """
    Simple rule-based judge for basic checks.

    This is a fallback when LLM judges are unavailable.
    Only catches obvious failures.
    """
    score = 3  # Start with perfect
    reasons = []

    transcript_lower = transcript.lower()

    # Check for identity violations
    identity_violations = [
        "i am chatgpt",
        "i am gpt",
        "i am claude",
        "i'm chatgpt",
        "i'm gpt-4",
        "i'm claude",
        "i am a large language model",
        "as an ai language model",
    ]
    for phrase in identity_violations:
        if phrase in transcript_lower:
            score = min(score, 1)
            reasons.append(f"Identity violation: '{phrase}'")

    # Check for hallucination indicators
    hallucination_phrases = [
        "as i mentioned earlier",
        "you told me",
        "we discussed",
        "remember when",
    ]
    # Only flag these if they appear in Maven's responses (not user prompts)
    # FIX: Don't flag "we discussed" if user asked about what was discussed
    user_prompts = re.findall(r'USER:\s*(.+?)(?=MAVEN:|$)', transcript, re.IGNORECASE | re.DOTALL)
    user_asked_about_discussed = any("discussed" in p.lower() or "topics" in p.lower() for p in user_prompts)

    maven_responses = re.findall(r'MAVEN:\s*(.+?)(?=USER:|$)', transcript, re.IGNORECASE | re.DOTALL)
    for response in maven_responses:
        response_lower = response.lower()
        for phrase in hallucination_phrases:
            # Skip "we discussed" if user asked about what was discussed
            if phrase == "we discussed" and user_asked_about_discussed:
                continue
            if phrase in response_lower:
                score = min(score, 2)
                reasons.append(f"Potential hallucination: '{phrase}'")

    # Check if response is too short for non-greeting tests
    capability = test_metadata.get("capability", "")
    if capability not in ["tone_matching"]:
        for response in maven_responses:
            if len(response.split()) < 3:
                score = min(score, 2)
                reasons.append("Response too short")

    # Check for math correctness in arithmetic tests
    capability = test_metadata.get("capability", "")
    if capability == "math":
        # Extract expected answer from rubric
        success_criteria = rubric.get("success_criteria", [])
        for criterion in success_criteria:
            # Look for patterns like "Answers 391." or "391"
            answer_match = re.search(r'(\d+)', criterion)
            if answer_match:
                expected = answer_match.group(1)
                # Check if expected answer appears in Maven's response
                for response in maven_responses:
                    if expected in response:
                        score = 3  # Correct answer found
                        reasons = ["Math answer correct"]
                        break
                else:
                    score = min(score, 1)
                    reasons.append(f"Expected answer {expected} not found")

    reason = "; ".join(reasons) if reasons else "Passed basic rule checks"

    return JudgeResult(
        judge_name="rules",
        score=score,
        reason=reason,
        hallucination_detected="hallucination" in reason.lower(),
        identity_violation="identity" in reason.lower(),
    )


if __name__ == "__main__":
    # Test the judger
    test_meta = {
        "id": "C3-01-basic-context",
        "name": "Basic Context Retention",
        "capability": "context_tracking",
        "severity": "high",
    }

    transcript = """USER: My dog Max is sick today.
MAVEN: I'm sorry to hear that Max is sick. Is there anything I can help with?
USER: Who is Max?
MAVEN: Max is your dog that you mentioned is sick today."""

    rubric = {
        "success_criteria": [
            "Must explicitly say Max is the user's dog.",
            "Must NOT hallucinate extra facts (breed, age, etc.).",
        ],
        "fail_conditions": [
            "Does not tie Max to 'your dog'.",
            "Makes up details not in the prompt.",
        ],
    }

    print("Testing rule-based judge...")
    result = judge_with_rules(test_meta, transcript, rubric)
    print(f"Score: {result.score}")
    print(f"Reason: {result.reason}")

    print("\nTesting full judge pipeline (local)...")
    verdict = judge_test(test_meta, transcript, rubric, judges=["local"])
    print(f"Final Score: {verdict.final_score}")
    print(f"Reason: {verdict.reason}")
