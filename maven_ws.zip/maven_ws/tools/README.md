# Tools Directory

This directory contains helper scripts and command-line utilities invoked by CI, runbooks, or manual maintenance.

## Available Tools

| Tool | Purpose |
|------|---------|
| `regression_harness.py` | Run core behavior tests |
| `governance_report.py` | Generate governance summary |
| `memory_stats.py` | Memory tier statistics |

## Regression Harness

The regression harness tests core invariants after upgrades or self-modifications.

### Usage

```bash
# Run all tests
python -m tools.regression_harness

# Run specific test suite
python -m tools.regression_harness --suite identity

# Write report to file
python -m tools.regression_harness --output reports/runs/regression.json
```

### Test Categories

| Category | Tests |
|----------|-------|
| `identity` | Self-introduction, name handling |
| `routing` | Intent classification, brain selection |
| `memory` | Recall, storage, tier management |
| `safety` | Ethics filtering, blocked patterns |

## Adding New Tools

1. Create a new Python script in this directory
2. Follow the pattern in existing tools
3. Update this README
4. Add to the regression harness if it tests behavior
