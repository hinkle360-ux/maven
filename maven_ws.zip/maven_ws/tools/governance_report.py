#!/usr/bin/env python3
"""
Governance Report Generator
============================

Analyzes governance logs and generates summary reports.

Usage:
    python -m tools.governance_report
    python -m tools.governance_report --days 7
    python -m tools.governance_report --output reports/governance/summary.md
"""

from __future__ import annotations
import argparse
import json
import sys
from collections import Counter, defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional


def load_governance_log(log_path: Path) -> List[Dict[str, Any]]:
    """Load governance log entries from JSONL file."""
    entries = []

    if not log_path.exists():
        return entries

    try:
        with open(log_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entry = json.loads(line)
                        entries.append(entry)
                    except json.JSONDecodeError:
                        continue
    except Exception as e:
        print(f"Error loading log: {e}")

    return entries


def filter_by_date(
    entries: List[Dict[str, Any]],
    days: int
) -> List[Dict[str, Any]]:
    """Filter entries to only those within the last N days."""
    cutoff = datetime.utcnow() - timedelta(days=days)
    filtered = []

    for entry in entries:
        ts = entry.get("ts", "")
        try:
            if ts.endswith("Z"):
                entry_time = datetime.fromisoformat(ts[:-1])
            else:
                entry_time = datetime.fromisoformat(ts.replace("Z", ""))

            if entry_time >= cutoff:
                filtered.append(entry)
        except (ValueError, TypeError):
            # Include entries without valid timestamps
            filtered.append(entry)

    return filtered


def generate_summary(entries: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate summary statistics from log entries."""
    summary = {
        "total_entries": len(entries),
        "ethics_decisions": Counter(),
        "rules_triggered": Counter(),
        "event_types": Counter(),
        "sessions": set(),
        "time_range": {"earliest": None, "latest": None}
    }

    for entry in entries:
        # Count ethics decisions
        decision = entry.get("ethics_decision", "")
        if decision:
            summary["ethics_decisions"][decision] += 1

        # Count rules triggered
        rules = entry.get("rules_applied", [])
        for rule in rules:
            summary["rules_triggered"][rule] += 1

        # Count event types
        event_type = entry.get("event_type", "unknown")
        summary["event_types"][event_type] += 1

        # Track sessions
        session_id = entry.get("session_id", "")
        if session_id:
            summary["sessions"].add(session_id)

        # Track time range
        ts = entry.get("ts", "")
        if ts:
            try:
                if ts.endswith("Z"):
                    entry_time = datetime.fromisoformat(ts[:-1])
                else:
                    entry_time = datetime.fromisoformat(ts.replace("Z", ""))

                if summary["time_range"]["earliest"] is None:
                    summary["time_range"]["earliest"] = entry_time
                    summary["time_range"]["latest"] = entry_time
                else:
                    if entry_time < summary["time_range"]["earliest"]:
                        summary["time_range"]["earliest"] = entry_time
                    if entry_time > summary["time_range"]["latest"]:
                        summary["time_range"]["latest"] = entry_time
            except (ValueError, TypeError):
                pass

    # Convert sets to counts
    summary["unique_sessions"] = len(summary["sessions"])
    del summary["sessions"]

    return summary


def format_markdown_report(
    summary: Dict[str, Any],
    entries: List[Dict[str, Any]]
) -> str:
    """Format summary as a Markdown report."""
    lines = []

    lines.append("# Governance Report")
    lines.append("")
    lines.append(f"**Generated:** {datetime.utcnow().isoformat()}Z")
    lines.append("")

    # Time range
    time_range = summary.get("time_range", {})
    if time_range.get("earliest"):
        lines.append(f"**Time Range:** {time_range['earliest'].isoformat()} to {time_range['latest'].isoformat()}")
    lines.append("")

    # Summary stats
    lines.append("## Summary Statistics")
    lines.append("")
    lines.append(f"| Metric | Value |")
    lines.append(f"|--------|-------|")
    lines.append(f"| Total Entries | {summary['total_entries']} |")
    lines.append(f"| Unique Sessions | {summary['unique_sessions']} |")
    lines.append("")

    # Ethics decisions
    ethics = summary.get("ethics_decisions", {})
    if ethics:
        lines.append("## Ethics Decisions")
        lines.append("")
        lines.append("| Decision | Count |")
        lines.append("|----------|-------|")
        for decision, count in sorted(ethics.items(), key=lambda x: -x[1]):
            lines.append(f"| {decision} | {count} |")
        lines.append("")

    # Rules triggered
    rules = summary.get("rules_triggered", {})
    if rules:
        lines.append("## Rules Triggered")
        lines.append("")
        lines.append("| Rule ID | Count |")
        lines.append("|---------|-------|")
        for rule, count in sorted(rules.items(), key=lambda x: -x[1]):
            lines.append(f"| {rule} | {count} |")
        lines.append("")

    # Event types
    events = summary.get("event_types", {})
    if events:
        lines.append("## Event Types")
        lines.append("")
        lines.append("| Type | Count |")
        lines.append("|------|-------|")
        for event_type, count in sorted(events.items(), key=lambda x: -x[1]):
            lines.append(f"| {event_type} | {count} |")
        lines.append("")

    # Recent blocked entries
    blocked = [e for e in entries if e.get("ethics_decision") == "block"]
    if blocked:
        lines.append("## Recent Blocked Requests")
        lines.append("")
        lines.append("| Timestamp | Intent | Rules |")
        lines.append("|-----------|--------|-------|")
        for entry in blocked[-10:]:  # Last 10
            ts = entry.get("ts", "unknown")[:19]
            intent = entry.get("intent", "unknown")[:30]
            rules = ", ".join(entry.get("rules_applied", []))[:30]
            lines.append(f"| {ts} | {intent} | {rules} |")
        lines.append("")

    # Recent escalations
    escalated = [e for e in entries if e.get("ethics_decision") == "escalate"]
    if escalated:
        lines.append("## Recent Escalations")
        lines.append("")
        lines.append("| Timestamp | Intent | Rules |")
        lines.append("|-----------|--------|-------|")
        for entry in escalated[-10:]:  # Last 10
            ts = entry.get("ts", "unknown")[:19]
            intent = entry.get("intent", "unknown")[:30]
            rules = ", ".join(entry.get("rules_applied", []))[:30]
            lines.append(f"| {ts} | {intent} | {rules} |")
        lines.append("")

    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Governance Report Generator")
    parser.add_argument(
        "--log",
        type=str,
        default="reports/governance/log.jsonl",
        help="Path to governance log file"
    )
    parser.add_argument(
        "--days",
        type=int,
        default=30,
        help="Number of days to include (default: 30)"
    )
    parser.add_argument(
        "--output",
        type=str,
        help="Output file for Markdown report"
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output raw JSON summary instead of Markdown"
    )

    args = parser.parse_args()

    # Resolve paths
    project_root = Path(__file__).resolve().parent.parent
    log_path = project_root / args.log

    print(f"Loading governance log from: {log_path}")

    # Load and filter entries
    entries = load_governance_log(log_path)
    print(f"Loaded {len(entries)} total entries")

    if args.days < 365 * 100:  # Not "all time"
        entries = filter_by_date(entries, args.days)
        print(f"Filtered to {len(entries)} entries (last {args.days} days)")

    if not entries:
        print("No entries found in governance log.")
        return 0

    # Generate summary
    summary = generate_summary(entries)

    if args.json:
        # Output JSON
        output = json.dumps(summary, indent=2, default=str)
        if args.output:
            Path(args.output).write_text(output)
            print(f"JSON report written to: {args.output}")
        else:
            print(output)
    else:
        # Output Markdown
        report = format_markdown_report(summary, entries)
        if args.output:
            output_path = Path(args.output)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(report)
            print(f"Report written to: {args.output}")
        else:
            print(report)

    # Print quick summary to stderr
    print(f"\n--- Quick Summary ---", file=sys.stderr)
    print(f"Total entries: {summary['total_entries']}", file=sys.stderr)
    print(f"Unique sessions: {summary['unique_sessions']}", file=sys.stderr)

    ethics = summary.get("ethics_decisions", {})
    if ethics:
        print(f"Ethics decisions:", file=sys.stderr)
        for decision, count in sorted(ethics.items()):
            print(f"  {decision}: {count}", file=sys.stderr)

    return 0


if __name__ == "__main__":
    sys.exit(main())
