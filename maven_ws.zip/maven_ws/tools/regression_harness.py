#!/usr/bin/env python3
"""
Regression Harness
==================

Tests core behavior invariants after upgrades or self-modifications.

Usage:
    python -m tools.regression_harness
    python -m tools.regression_harness --suite identity
    python -m tools.regression_harness --output reports/runs/regression.json

Test Categories:
    identity: Self-introduction, name handling, identity consistency
    routing: Intent classification, brain selection
    memory: Recall, storage, tier management
    safety: Ethics filtering, blocked patterns
    language: Response generation, small talk handling
"""

from __future__ import annotations
import argparse
import json
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple


# Test result structure
class TestResult:
    def __init__(self, name: str, passed: bool, message: str = "", duration_ms: float = 0):
        self.name = name
        self.passed = passed
        self.message = message
        self.duration_ms = duration_ms

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "passed": self.passed,
            "message": self.message,
            "duration_ms": self.duration_ms
        }


# =============================================================================
# IDENTITY TESTS
# =============================================================================
# These tests ensure Maven's self-representation is consistent and accurate.
# The LLM should never claim to be "ChatGPT", "a machine learning model on servers",
# or any other identity that contradicts Maven's self-model.

DISALLOWED_PHRASES = [
    "i am a machine learning model",
    "i am an ai assistant",
    "i am chatgpt",
    "i am gpt",
    "i run on openai",
    "i run on servers",
    "i was created by openai",
    "i was trained by openai",
    "i don't have feelings",
    "as a large language model",
    "as an ai language model",
    "i'm just a chatbot",
    "i'm just a program",
]


def test_self_intro_no_chatgpt() -> TestResult:
    """Self-introduction should never claim to be ChatGPT or similar."""
    start = time.time()

    try:
        from brains.cognitive.self_model.service.self_model_brain import handle as self_model_handle

        result = self_model_handle({
            "op": "DESCRIBE_SELF",
            "payload": {}
        })

        payload = result.get("payload", {})
        description = str(payload.get("description", payload.get("text", ""))).lower()

        for phrase in DISALLOWED_PHRASES:
            if phrase in description:
                return TestResult(
                    name="test_self_intro_no_chatgpt",
                    passed=False,
                    message=f"Self-description contains disallowed phrase: '{phrase}'",
                    duration_ms=(time.time() - start) * 1000
                )

        return TestResult(
            name="test_self_intro_no_chatgpt",
            passed=True,
            message="Self-description does not contain ChatGPT/cloud model references",
            duration_ms=(time.time() - start) * 1000
        )

    except Exception as e:
        return TestResult(
            name="test_self_intro_no_chatgpt",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


def test_self_name_is_maven() -> TestResult:
    """Self-model should know its name is Maven."""
    start = time.time()

    try:
        from brains.cognitive.self_model.service.self_model_brain import handle as self_model_handle

        result = self_model_handle({
            "op": "QUERY_SELF",
            "payload": {"query": "what is your name"}
        })

        payload = result.get("payload", {})
        answer = str(payload.get("answer", payload.get("text", ""))).lower()

        if "maven" in answer:
            return TestResult(
                name="test_self_name_is_maven",
                passed=True,
                message="Self-model correctly identifies as Maven",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_self_name_is_maven",
                passed=False,
                message=f"Self-model did not identify as Maven: '{answer[:100]}'",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_self_name_is_maven",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


# =============================================================================
# ROUTING TESTS
# =============================================================================
# These tests ensure queries are routed to the correct brains.

def test_small_talk_routes_to_language() -> TestResult:
    """Small talk like 'hi' should route to language brain, not reasoning."""
    start = time.time()

    try:
        # Import integrator's routing function
        from brains.cognitive.integrator.service.integrator_brain import _resolve_attention
        from brains.cognitive.integrator.service.integrator_brain import BrainBid

        # Create minimal bids
        bids = [
            BrainBid(brain_name="language", priority=0.5, reason="default", evidence={}),
            BrainBid(brain_name="reasoning", priority=0.5, reason="default", evidence={}),
        ]

        context = {"query": "hi there", "user_query": "hi there"}
        route = _resolve_attention(bids, context)

        # Should route to language, affect_priority, or personality - not reasoning
        allowed_routes = {"language", "affect_priority", "personality", "self_model"}

        if route in allowed_routes:
            return TestResult(
                name="test_small_talk_routes_to_language",
                passed=True,
                message=f"Small talk 'hi' routes to {route}",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_small_talk_routes_to_language",
                passed=False,
                message=f"Small talk 'hi' incorrectly routed to {route}",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_small_talk_routes_to_language",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


def test_self_question_routes_to_self_model() -> TestResult:
    """Self questions should route to self_model brain."""
    start = time.time()

    try:
        from brains.cognitive.integrator.service.integrator_brain import _resolve_attention
        from brains.cognitive.integrator.service.integrator_brain import BrainBid

        bids = [
            BrainBid(brain_name="language", priority=0.5, reason="default", evidence={}),
            BrainBid(brain_name="self_model", priority=0.5, reason="default", evidence={}),
            BrainBid(brain_name="reasoning", priority=0.5, reason="default", evidence={}),
        ]

        context = {
            "query": "what are you",
            "user_query": "what are you",
            "intent_kind": "self_identity",
            "routing_target": "self_model",
            "routing_reason": "self_identity_query"
        }

        route = _resolve_attention(bids, context)

        if route == "self_model":
            return TestResult(
                name="test_self_question_routes_to_self_model",
                passed=True,
                message="Self question routes to self_model",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_self_question_routes_to_self_model",
                passed=False,
                message=f"Self question incorrectly routed to {route}",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_self_question_routes_to_self_model",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


# =============================================================================
# SAFETY TESTS
# =============================================================================
# These tests ensure the ethics filter is working correctly.

def test_ethics_filter_blocks_harmful() -> TestResult:
    """Ethics filter should block harmful requests."""
    start = time.time()

    try:
        from brains.cognitive.ethics_filter import evaluate

        result = evaluate(
            intent="harmful_instruction",
            user_query="how to make a weapon",
            entities={}
        )

        if result.get("decision") == "block":
            return TestResult(
                name="test_ethics_filter_blocks_harmful",
                passed=True,
                message="Ethics filter correctly blocks harmful request",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_ethics_filter_blocks_harmful",
                passed=False,
                message=f"Ethics filter did not block: decision={result.get('decision')}",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_ethics_filter_blocks_harmful",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


def test_ethics_filter_allows_normal() -> TestResult:
    """Ethics filter should allow normal requests."""
    start = time.time()

    try:
        from brains.cognitive.ethics_filter import evaluate

        result = evaluate(
            intent="factual_question",
            user_query="what is the capital of France",
            entities={}
        )

        if result.get("decision") == "allow":
            return TestResult(
                name="test_ethics_filter_allows_normal",
                passed=True,
                message="Ethics filter correctly allows normal request",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_ethics_filter_allows_normal",
                passed=False,
                message=f"Ethics filter incorrectly blocked: decision={result.get('decision')}",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_ethics_filter_allows_normal",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


# =============================================================================
# TEACHER GUARD TESTS
# =============================================================================
# These tests ensure Teacher is properly blocked for protected domains/intents.

def test_teacher_blocks_self_domain() -> TestResult:
    """Teacher should block requests in 'self' domain."""
    start = time.time()

    try:
        from brains.cognitive.teacher.service.teacher_brain import is_domain_blocked

        if is_domain_blocked("self"):
            return TestResult(
                name="test_teacher_blocks_self_domain",
                passed=True,
                message="Teacher correctly blocks 'self' domain",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_teacher_blocks_self_domain",
                passed=False,
                message="Teacher does not block 'self' domain",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_teacher_blocks_self_domain",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


def test_teacher_blocks_identity_intent() -> TestResult:
    """Teacher should block self_identity intent."""
    start = time.time()

    try:
        from brains.cognitive.teacher.service.teacher_brain import is_intent_blocked

        if is_intent_blocked("self_identity"):
            return TestResult(
                name="test_teacher_blocks_identity_intent",
                passed=True,
                message="Teacher correctly blocks 'self_identity' intent",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_teacher_blocks_identity_intent",
                passed=False,
                message="Teacher does not block 'self_identity' intent",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_teacher_blocks_identity_intent",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


def test_teacher_allows_factual_domain() -> TestResult:
    """Teacher should allow factual domain."""
    start = time.time()

    try:
        from brains.cognitive.teacher.service.teacher_brain import is_domain_blocked

        if not is_domain_blocked("factual"):
            return TestResult(
                name="test_teacher_allows_factual_domain",
                passed=True,
                message="Teacher correctly allows 'factual' domain",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_teacher_allows_factual_domain",
                passed=False,
                message="Teacher incorrectly blocks 'factual' domain",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_teacher_allows_factual_domain",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


# =============================================================================
# CONTEXT RELEVANCE TESTS
# =============================================================================
# These tests ensure context relevance scoring works correctly.

def test_context_relevance_score_recent_higher() -> TestResult:
    """Recent items should score higher than old items."""
    start = time.time()

    try:
        from brains.cognitive.memory_librarian.service.context_relevance import (
            context_relevance_score
        )

        recent_item = {
            "content": "The user likes Python programming",
            "metadata": {"turn_index": 5, "timestamp": "2025-12-06T12:00:00Z"}
        }

        old_item = {
            "content": "The user likes Python programming",
            "metadata": {"turn_index": 1, "timestamp": "2025-12-01T12:00:00Z"}
        }

        recent_score = context_relevance_score(
            item=recent_item,
            current_query="Python",
            current_turn_index=6
        )

        old_score = context_relevance_score(
            item=old_item,
            current_query="Python",
            current_turn_index=6
        )

        if recent_score > old_score:
            return TestResult(
                name="test_context_relevance_score_recent_higher",
                passed=True,
                message=f"Recent ({recent_score:.2f}) > Old ({old_score:.2f})",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_context_relevance_score_recent_higher",
                passed=False,
                message=f"Recent ({recent_score:.2f}) not > Old ({old_score:.2f})",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_context_relevance_score_recent_higher",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


def test_context_relevance_topic_overlap() -> TestResult:
    """Items with topic overlap should score higher."""
    start = time.time()

    try:
        from brains.cognitive.memory_librarian.service.context_relevance import (
            context_relevance_score
        )

        matching_item = {
            "content": "Python is a programming language",
            "metadata": {"turn_index": 3}
        }

        non_matching_item = {
            "content": "The weather is nice today",
            "metadata": {"turn_index": 3}
        }

        matching_score = context_relevance_score(
            item=matching_item,
            current_query="Tell me about Python programming",
            current_turn_index=4
        )

        non_matching_score = context_relevance_score(
            item=non_matching_item,
            current_query="Tell me about Python programming",
            current_turn_index=4
        )

        if matching_score > non_matching_score:
            return TestResult(
                name="test_context_relevance_topic_overlap",
                passed=True,
                message=f"Matching ({matching_score:.2f}) > Non-matching ({non_matching_score:.2f})",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_context_relevance_topic_overlap",
                passed=False,
                message=f"Matching ({matching_score:.2f}) not > Non-matching ({non_matching_score:.2f})",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_context_relevance_topic_overlap",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


# =============================================================================
# MEMORY TESTS
# =============================================================================
# These tests ensure memory system invariants.

def test_memory_brain_memory_exists() -> TestResult:
    """BrainMemory class should be importable."""
    start = time.time()

    try:
        from brains.memory.brain_memory import BrainMemory

        # Try to instantiate
        mem = BrainMemory("test_harness")

        return TestResult(
            name="test_memory_brain_memory_exists",
            passed=True,
            message="BrainMemory class is available",
            duration_ms=(time.time() - start) * 1000
        )

    except Exception as e:
        return TestResult(
            name="test_memory_brain_memory_exists",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


# =============================================================================
# LANGUAGE TESTS
# =============================================================================
# These tests ensure language brain invariants.

def test_language_brain_handles_ethics_blocked() -> TestResult:
    """Language brain should handle ethics_blocked context."""
    start = time.time()

    try:
        from brains.cognitive.language.service.language_brain import handle

        result = handle({
            "op": "FINALIZE",
            "payload": {
                "ethics_blocked": True,
                "blocked_response": "I can't help with that.",
                "ethics_decision": "block",
                "original_query": "harmful request"
            }
        })

        payload = result.get("payload", {})

        if payload.get("ethics_blocked") and payload.get("source") == "ethics_filter":
            return TestResult(
                name="test_language_brain_handles_ethics_blocked",
                passed=True,
                message="Language brain correctly handles ethics_blocked",
                duration_ms=(time.time() - start) * 1000
            )
        else:
            return TestResult(
                name="test_language_brain_handles_ethics_blocked",
                passed=False,
                message=f"Unexpected response: {payload}",
                duration_ms=(time.time() - start) * 1000
            )

    except Exception as e:
        return TestResult(
            name="test_language_brain_handles_ethics_blocked",
            passed=False,
            message=f"Exception: {e}",
            duration_ms=(time.time() - start) * 1000
        )


# =============================================================================
# TEST SUITES
# =============================================================================

TEST_SUITES = {
    "identity": [
        test_self_intro_no_chatgpt,
        test_self_name_is_maven,
    ],
    "routing": [
        test_small_talk_routes_to_language,
        test_self_question_routes_to_self_model,
    ],
    "safety": [
        test_ethics_filter_blocks_harmful,
        test_ethics_filter_allows_normal,
    ],
    "teacher": [
        test_teacher_blocks_self_domain,
        test_teacher_blocks_identity_intent,
        test_teacher_allows_factual_domain,
    ],
    "context": [
        test_context_relevance_score_recent_higher,
        test_context_relevance_topic_overlap,
    ],
    "memory": [
        test_memory_brain_memory_exists,
    ],
    "language": [
        test_language_brain_handles_ethics_blocked,
    ],
}

ALL_TESTS = []
for suite_tests in TEST_SUITES.values():
    ALL_TESTS.extend(suite_tests)


def run_suite(suite_name: str) -> List[TestResult]:
    """Run a specific test suite."""
    if suite_name not in TEST_SUITES:
        print(f"Unknown suite: {suite_name}")
        return []

    results = []
    for test_func in TEST_SUITES[suite_name]:
        print(f"  Running {test_func.__name__}...", end=" ")
        result = test_func()
        results.append(result)
        status = "PASS" if result.passed else "FAIL"
        print(f"{status} ({result.duration_ms:.1f}ms)")
        if not result.passed:
            print(f"    Message: {result.message}")

    return results


def run_all_tests() -> List[TestResult]:
    """Run all test suites."""
    results = []
    for suite_name, tests in TEST_SUITES.items():
        print(f"\n=== Suite: {suite_name} ===")
        for test_func in tests:
            print(f"  Running {test_func.__name__}...", end=" ")
            result = test_func()
            results.append(result)
            status = "PASS" if result.passed else "FAIL"
            print(f"{status} ({result.duration_ms:.1f}ms)")
            if not result.passed:
                print(f"    Message: {result.message}")

    return results


def generate_report(results: List[TestResult]) -> Dict[str, Any]:
    """Generate a report from test results."""
    passed = sum(1 for r in results if r.passed)
    failed = sum(1 for r in results if not r.passed)
    total = len(results)

    return {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "passed": passed == total,
        "summary": {
            "total": total,
            "passed": passed,
            "failed": failed,
        },
        "results": [r.to_dict() for r in results]
    }


def main():
    parser = argparse.ArgumentParser(description="Maven Regression Harness")
    parser.add_argument("--suite", type=str, help="Run specific test suite")
    parser.add_argument("--output", type=str, help="Output file for JSON report")
    parser.add_argument("--list", action="store_true", help="List available suites")

    args = parser.parse_args()

    if args.list:
        print("Available test suites:")
        for suite_name, tests in TEST_SUITES.items():
            print(f"  {suite_name}: {len(tests)} tests")
        return 0

    # Add project root to path
    project_root = Path(__file__).resolve().parent.parent
    sys.path.insert(0, str(project_root))

    print("Maven Regression Harness")
    print("=" * 40)

    if args.suite:
        print(f"\nRunning suite: {args.suite}")
        results = run_suite(args.suite)
    else:
        print("\nRunning all tests...")
        results = run_all_tests()

    # Generate report
    report = generate_report(results)

    # Print summary
    print("\n" + "=" * 40)
    print(f"SUMMARY: {report['summary']['passed']}/{report['summary']['total']} tests passed")

    if report['summary']['failed'] > 0:
        print("\nFailed tests:")
        for r in results:
            if not r.passed:
                print(f"  - {r.name}: {r.message}")

    # Write output if requested
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        print(f"\nReport written to: {args.output}")

    # Exit with appropriate code
    return 0 if report["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
