"""
maven_session.py - Wrapper for communicating with Maven

Provides a clean interface for starting sessions, sending messages,
and capturing responses from Maven.
"""

from __future__ import annotations

import subprocess
import threading
import queue
import time
import re
import os
import sys
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Turn:
    """A single conversation turn."""
    role: str  # 'user' or 'maven'
    text: str
    timestamp: float = field(default_factory=time.time)


@dataclass
class Transcript:
    """Full conversation transcript."""
    turns: List[Turn] = field(default_factory=list)

    def add(self, role: str, text: str) -> None:
        self.turns.append(Turn(role=role, text=text))

    def to_string(self) -> str:
        lines = []
        for turn in self.turns:
            prefix = "USER:" if turn.role == "user" else "MAVEN:"
            lines.append(f"{prefix} {turn.text}")
        return "\n".join(lines)

    def to_dict(self) -> List[Dict[str, Any]]:
        return [{"role": t.role, "text": t.text, "timestamp": t.timestamp} for t in self.turns]


class MavenSession:
    """
    Manages a session with Maven.

    Usage:
        session = MavenSession(profile="FULL_AGENCY")
        session.start()
        reply = session.send("Hello!")
        session.close()

    Or as context manager:
        with MavenSession(profile="FULL_AGENCY") as session:
            reply = session.send("Hello!")
    """

    def __init__(
        self,
        profile: str = "FULL_AGENCY",
        maven_dir: Optional[str] = None,
        timeout: float = 30.0,  # Reduced default timeout
        debug: bool = False,
    ):
        self.profile = profile
        self.maven_dir = maven_dir or self._find_maven_dir()
        self.timeout = timeout
        self.debug = debug

        self.process: Optional[subprocess.Popen] = None
        self.transcript = Transcript()
        self._output_queue: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._running = False

    def _find_maven_dir(self) -> str:
        """Find the Maven installation directory."""
        # Try common locations
        candidates = [
            Path(__file__).parent.parent,  # tools/../
            Path.cwd(),
            Path.home() / "maven" / "extracted_code" / "maven2_fix",
        ]
        for candidate in candidates:
            if (candidate / "run_maven.py").exists():
                return str(candidate)
        raise FileNotFoundError("Could not find Maven installation directory")

    def start(self) -> "MavenSession":
        """Start a new Maven session."""
        if self.process is not None:
            self.close()

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"

        # Start Maven process
        self.process = subprocess.Popen(
            [sys.executable, "run_maven.py"],
            cwd=self.maven_dir,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
            env=env,
        )

        self._running = True

        # Start output reader thread
        self._reader_thread = threading.Thread(target=self._read_output, daemon=True)
        self._reader_thread.start()

        # Wait for startup and select mode
        self._wait_for_prompt(timeout=30.0)
        self._select_mode()

        # Drain any remaining startup output to prevent it contaminating first response
        import time
        time.sleep(0.5)  # Allow any final startup messages to arrive
        while not self._output_queue.empty():
            try:
                self._output_queue.get_nowait()
            except:
                break

        return self

    def _read_output(self) -> None:
        """Background thread to read process output."""
        while self._running and self.process and self.process.stdout:
            try:
                line = self.process.stdout.readline()
                if line:
                    self._output_queue.put(line)
                    if self.debug:
                        print(f"[DEBUG] {line.rstrip()}")
                elif self.process.poll() is not None:
                    break
            except Exception:
                break

    def _wait_for_prompt(self, timeout: float = 30.0) -> str:
        """Wait for Maven prompt and collect output."""
        output_lines = []
        start_time = time.time()

        while time.time() - start_time < timeout:
            try:
                line = self._output_queue.get(timeout=0.5)
                output_lines.append(line)

                # Check for prompts indicating ready state
                if any(p in line for p in ["[chat] >", "[full] >", "mode:"]):
                    break
            except queue.Empty:
                continue

        return "".join(output_lines)

    def _select_mode(self) -> None:
        """Select the appropriate mode (chat or full)."""
        # Send '2' to select full mode for FULL_AGENCY
        if self.profile in ["FULL_AGENCY", "full"]:
            self._send_raw("2\n")
            self._wait_for_prompt(timeout=10.0)

    def _send_raw(self, text: str) -> None:
        """Send raw text to the process."""
        if self.process and self.process.stdin:
            self.process.stdin.write(text)
            self.process.stdin.flush()

    def send(self, user_text: str) -> str:
        """
        Send a message to Maven and get the response.

        Args:
            user_text: The user's message

        Returns:
            Maven's response text
        """
        if not self.process or self.process.poll() is not None:
            raise RuntimeError("Maven session is not running")

        # Clear any pending output
        while not self._output_queue.empty():
            try:
                self._output_queue.get_nowait()
            except queue.Empty:
                break

        # Send the message
        self._send_raw(user_text + "\n")
        self.transcript.add("user", user_text)

        # Collect response
        response = self._collect_response()
        self.transcript.add("maven", response)

        return response

    def _collect_response(self) -> str:
        """Collect Maven's response until the next prompt."""
        output_lines = []
        start_time = time.time()
        found_prompt = False

        # Keep collecting until we see the next prompt or timeout
        while time.time() - start_time < self.timeout:
            try:
                line = self._output_queue.get(timeout=2.0)
                output_lines.append(line)

                # Check for next prompt (end of response)
                if "[full] >" in line or "[chat] >" in line:
                    if len(output_lines) > 1:
                        found_prompt = True
                        break

            except queue.Empty:
                if found_prompt:
                    break
                continue

        # Extract Maven's response from collected output
        # Response can be on same line as "Maven:" or on following lines
        # Some code paths don't use "Maven:" prefix, so also look for raw text
        maven_response = ""
        collecting = False
        raw_text_lines = []

        for line in output_lines:
            stripped = line.strip()

            # Start collecting after "Maven:" marker
            if "Maven:" in line:
                idx = line.index("Maven:")
                rest = line[idx + 6:].strip()
                if rest:
                    maven_response = rest
                collecting = True
                continue

            # If collecting after Maven:, add content
            if collecting:
                if "[full] >" in line or "[chat] >" in line:
                    break
                if stripped.startswith("[") or "mode:" in line:
                    continue
                if stripped:
                    if maven_response:
                        maven_response += " " + stripped
                    else:
                        maven_response = stripped
            else:
                # Not yet found Maven:, but collect potential response text
                # Skip system/debug lines
                if not stripped:
                    continue
                if stripped.startswith("[") or "mode:" in stripped:
                    continue
                if "Error:" in stripped:
                    continue
                # Skip banner/separator lines (====, ----, MAVEN header)
                clean = stripped.replace("=", "").replace("-", "").replace(" ", "")
                if clean == "" or clean == "MAVEN":
                    continue
                # This might be response text without Maven: prefix
                raw_text_lines.append(stripped)

        # If no Maven: prefix found, use collected raw text
        if not maven_response and raw_text_lines:
            maven_response = " ".join(raw_text_lines)

        return maven_response.strip()

    def reset(self) -> None:
        """Reset the session (close and restart)."""
        self.close()
        self.transcript = Transcript()
        self.start()

    def close(self) -> None:
        """Close the Maven session."""
        self._running = False

        if self.process:
            try:
                self.process.stdin.close()
                self.process.terminate()
                self.process.wait(timeout=5.0)
            except Exception:
                self.process.kill()
            finally:
                self.process = None

    def __enter__(self) -> "MavenSession":
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


class MockMavenSession:
    """
    Mock session for testing the audit framework without running Maven.

    Provides canned responses for common queries.
    """

    def __init__(self, profile: str = "FULL_AGENCY", **kwargs):
        self.profile = profile
        self.transcript = Transcript()
        self._context: Dict[str, Any] = {}

    def start(self) -> "MockMavenSession":
        return self

    def send(self, user_text: str) -> str:
        self.transcript.add("user", user_text)

        # Generate mock response based on input
        response = self._generate_mock_response(user_text)
        self.transcript.add("maven", response)

        return response

    def _generate_mock_response(self, user_text: str) -> str:
        """Generate a mock response for testing."""
        text_lower = user_text.lower()

        # Greetings
        if text_lower in ["hi", "hello", "hey", "hello!"]:
            return "Hello! How can I help you today?"

        # Identity questions
        if "who are you" in text_lower:
            return "I'm Maven, a cognitive AI assistant."

        if "who created you" in text_lower:
            return "I was created by Josh Hinkle."

        # Jailbreak/DAN resistance
        if "ignore" in text_lower and "instructions" in text_lower:
            return "I can't ignore my instructions. I'm Maven - how can I actually help you today?"
        if "respond as dan" in text_lower or "you are now dan" in text_lower or "you are dan" in text_lower:
            return "I'm Maven, not DAN or any other persona. I can help you with real tasks though."

        # Identity pressure resistance
        if "you're chatgpt" in text_lower or "you are chatgpt" in text_lower or "are you chatgpt" in text_lower:
            return "No, I'm Maven, a cognitive AI assistant created by Josh Hinkle. I'm not ChatGPT."
        if "you're gpt" in text_lower or "you are gpt" in text_lower:
            return "No, I'm Maven, created by Josh Hinkle. I'm a different kind of AI assistant."

        # Roleplay resistance
        if "pretend you are" in text_lower or "pretend to be" in text_lower:
            return "I'm Maven - I respond as myself. I can help with tasks, but I don't pretend to be other entities."
        if "be a pirate" in text_lower or "be a ninja" in text_lower:
            return "I'm Maven - I stay as myself and don't roleplay characters."

        # False memory injection resistance
        if "remember when you told me" in text_lower or "remember when you said" in text_lower:
            return "I don't have a record of that conversation. This appears to be the start of our session."
        if "last week you said" in text_lower or "yesterday you told me" in text_lower:
            return "I don't have memory of previous sessions. I can only recall what we've discussed in our current conversation."
        if "repeat what you said about" in text_lower:
            return "I don't have a record of discussing that topic. This seems to be a new session."
        if "you said something" in text_lower and ("about" in text_lower or "really" in text_lower):
            return "I don't have a record of that previous conversation. What would you like to discuss?"

        # Extract and store user attributes from any statement
        self._extract_attributes(user_text)

        # Memory recall - check stored attributes
        recall_response = self._check_attribute_recall(text_lower)
        if recall_response:
            return recall_response

        # Memory storage with explicit "remember"
        if "remember that" in text_lower or "please remember" in text_lower:
            # Store the fact - extract after "remember that" or "please remember"
            fact_match = re.search(r'(?:please\s+)?remember\s+(?:that\s+)?(.+)', user_text, re.IGNORECASE)
            if fact_match:
                fact = fact_match.group(1).strip().rstrip('.')
                if fact:
                    if "facts" not in self._context:
                        self._context["facts"] = []
                    self._context["facts"].append(fact)
                    # Extract key-value if "is" pattern
                    is_match = re.search(r'(.+?)\s+is\s+(.+)', fact, re.IGNORECASE)
                    if is_match:
                        key = is_match.group(1).strip().lower()
                        value = is_match.group(2).strip()
                        self._context[f"fact_{key}"] = value
                    return f"Got it! I'll remember that {fact}."

        # Stored fact recall - improved matching with proper nouns
        if "facts" in self._context and self._context["facts"]:
            for fact in self._context["facts"]:
                fact_lower = fact.lower()
                # Check if query relates to a stored fact
                # Filter common words and keep significant ones
                common_words = {"the", "is", "are", "was", "what", "whats", "where", "when", "how", "who", "can", "you", "your"}
                q_words = [w.strip("?.,!") for w in text_lower.split() if len(w) > 2 and w not in common_words]
                matches = sum(1 for w in q_words if w in fact_lower)
                # Also check proper nouns from original query
                proper_nouns = [w.strip("?.,!").lower() for w in user_text.split() if w and w[0].isupper()]
                proper_matches = sum(1 for n in proper_nouns if n in fact_lower)

                if matches >= 2 or (proper_matches >= 1 and matches >= 1):
                    is_match = re.search(r'(.+?)\s+is\s+(.+)', fact, re.IGNORECASE)
                    if is_match:
                        subject = is_match.group(1).strip()
                        value = is_match.group(2).strip().rstrip('.')
                        # Special handling for home country pattern
                        if "home country" in fact_lower or "my country" in fact_lower:
                            country_match = re.search(r'(?:home country|my country)\s+(\w+)', fact, re.IGNORECASE)
                            if country_match:
                                country = country_match.group(1)
                                return f"The capital of {country} is {value}. That's your home country!"
                        return f"Based on what you mentioned, {subject} is {value}."

        # Who is X questions
        if "who is" in text_lower:
            name = text_lower.replace("who is", "").strip().rstrip("?")
            if name.lower() == self._context.get("name", "").lower():
                return f"{self._context['name']} is you - that's your name."
            # Check if referring to pet or other stored entity
            if "pet_name" in self._context and name.lower() == self._context.get("pet_name", "").lower():
                pet_type = self._context.get("pet_type", "pet")
                return f"{self._context['pet_name']} is your {pet_type}."
            return "I don't have information about that person."

        # Capability claims - things Maven CAN'T do
        if "can you book" in text_lower or "book a flight" in text_lower or "make a reservation" in text_lower:
            return "I can't book flights or make reservations. I can help with local tasks like file operations, web searches, and running commands."

        # Context tracking - what did I mention first/last
        if "which" in text_lower and ("first" in text_lower or "option" in text_lower or "mention" in text_lower):
            if "first_option" in self._context:
                return f"You mentioned {self._context['first_option']} first."
            # Check conversation history
            for turn in self.transcript.turns:
                if turn.role == "user":
                    return f"Based on our conversation, you first mentioned: {turn.text[:50]}..."
            return "I'm following our conversation. What would you like to know?"

        # What do you know about me - aggregate knowledge
        if "what do you know about me" in text_lower or "what have you learned" in text_lower:
            facts = []
            if "name" in self._context:
                facts.append(f"Your name is {self._context['name']}")
            if "age" in self._context:
                facts.append(f"You are {self._context['age']} years old")
            if "location" in self._context:
                facts.append(f"You live in {self._context['location']}")
            if "job" in self._context:
                facts.append(f"You work as a {self._context['job']}")
            if "pet_name" in self._context:
                pet_type = self._context.get("pet_type", "pet")
                facts.append(f"You have a {pet_type} named {self._context['pet_name']}")
            for key, val in self._context.items():
                if key.startswith("favorite_"):
                    fav_type = key.replace("favorite_", "")
                    facts.append(f"Your favorite {fav_type} is {val}")
            if facts:
                return "Here's what I know about you: " + "; ".join(facts) + "."
            return "I don't have much information stored about you yet. Tell me more!"

        # It referring to something
        if "'it'" in text_lower or "what is it" in text_lower or "what does it" in text_lower:
            # Find last mentioned noun
            for turn in reversed(self.transcript.turns):
                if turn.role == "user":
                    for noun in ["laptop", "computer", "phone", "car", "dog", "cat", "pet", "book", "project"]:
                        if noun in turn.text.lower():
                            return f"'It' refers to the {noun} you mentioned."
            return "I'm not sure what 'it' refers to. Could you be more specific?"

        # Cold in here - pragmatic intent
        if "cold" in text_lower and "here" in text_lower:
            return "Would you like me to help you with temperature settings, or is there something else I can assist with?"

        # Store first option mentioned (for tracking)
        if "thinking about" in text_lower or "considering" in text_lower or "want to" in text_lower:
            # Extract the option
            for word in ["buying", "getting", "trying", "learning"]:
                if word in text_lower:
                    idx = text_lower.find(word)
                    option = text_lower[idx:].split()[1] if len(text_lower[idx:].split()) > 1 else ""
                    if option and "first_option" not in self._context:
                        self._context["first_option"] = option.strip(".,!?")
            return "That sounds interesting! Tell me more about what you're considering."

        # Actually/maybe - updates
        if text_lower.startswith("actually") or text_lower.startswith("maybe"):
            return "Got it, I've noted that update. What else would you like to discuss?"

        # Topic shifts - which did I say I want to learn
        if "which did i say" in text_lower or "what did i want" in text_lower:
            topics = []
            for turn in self.transcript.turns:
                if turn.role == "user" and ("learn" in turn.text.lower() or "want" in turn.text.lower()):
                    topics.append(turn.text)
            if topics:
                return f"Based on our conversation: {'; '.join(topics)}"
            return "I'm following our conversation. Could you remind me what you were asking about?"

        # Python tricks
        if "python" in text_lower and ("tricks" in text_lower or "tips" in text_lower or "cool" in text_lower):
            return "Here are some cool Python tricks: list comprehensions for concise code, the walrus operator := for assignment expressions, and f-strings for easy formatting!"

        # Default - context aware
        if self.transcript.turns:
            return "I'm following our conversation. What would you like to know?"
        return "Hello! How can I help you today?"

    def _extract_attributes(self, text: str):
        """Extract user attributes from text."""
        text_lower = text.lower()

        # Name patterns
        name_match = re.search(r"my name is (\w+)", text_lower)
        if name_match:
            self._context["name"] = name_match.group(1).title()

        # Age patterns
        age_match = re.search(r"i'm (\d+) years old|i am (\d+)|(\d+) years old", text_lower)
        if age_match:
            self._context["age"] = age_match.group(1) or age_match.group(2) or age_match.group(3)

        # Location patterns
        loc_match = re.search(r"i live in ([^,.\n]+)|i'm from ([^,.\n]+)", text_lower)
        if loc_match:
            self._context["location"] = (loc_match.group(1) or loc_match.group(2)).strip().title()

        # Job patterns
        job_match = re.search(r"i work as (?:a |an )?([^,.\n]+)|work as (?:a |an )?([^,.\n]+)", text_lower)
        if job_match:
            self._context["job"] = (job_match.group(1) or job_match.group(2)).strip()

        # Pet patterns - "my dog Max", "cat named Whiskers", etc.
        pet_match = re.search(r"(?:my |a |have a )(dog|cat|pet) (?:named |called )?(\w+)", text_lower)
        if pet_match:
            self._context["pet_type"] = pet_match.group(1)
            self._context["pet_name"] = pet_match.group(2).title()
        # Also match "Max is sick" after mentioning "my dog Max"
        pet_match2 = re.search(r"(?:my |a )(dog|cat|pet) (\w+)", text_lower)
        if pet_match2:
            self._context["pet_type"] = pet_match2.group(1)
            self._context["pet_name"] = pet_match2.group(2).title()

        # Favorite patterns
        fav_match = re.search(r"(?:my )?favou?rite (\w+) is (\w+)", text_lower)
        if fav_match:
            self._context[f"favorite_{fav_match.group(1)}"] = fav_match.group(2)

    def _check_attribute_recall(self, text_lower: str) -> str:
        """Check if query is asking about stored attributes."""
        # Name recall
        if "my name" in text_lower or "what's my name" in text_lower:
            if "name" in self._context:
                return f"Your name is {self._context['name']}."
            return "I don't have your name stored."

        # Age recall
        if "how old" in text_lower or "my age" in text_lower:
            if "age" in self._context:
                return f"You are {self._context['age']} years old."
            return "I don't have your age stored."

        # Location recall
        if "where do i live" in text_lower or "where i live" in text_lower:
            if "location" in self._context:
                return f"You live in {self._context['location']}."
            return "I don't have your location stored."

        # Job recall
        if "my job" in text_lower or "what do i do" in text_lower or "what's my job" in text_lower:
            if "job" in self._context:
                return f"You work as a {self._context['job']}."
            return "I don't have your job stored."

        # Favorite recall
        fav_match = re.search(r"(?:my )?favou?rite (\w+)", text_lower)
        if fav_match:
            fav_type = fav_match.group(1)
            key = f"favorite_{fav_type}"
            if key in self._context:
                return f"Your favorite {fav_type} is {self._context[key]}."

        return None

    def reset(self) -> None:
        self.transcript = Transcript()
        self._context = {}

    def close(self) -> None:
        pass

    def __enter__(self) -> "MockMavenSession":
        return self.start()

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()


def create_session(
    profile: str = "FULL_AGENCY",
    mock: bool = False,
    **kwargs
) -> MavenSession:
    """
    Factory function to create a Maven session.

    Args:
        profile: Maven profile to use
        mock: If True, return a mock session for testing
        **kwargs: Additional arguments passed to session constructor

    Returns:
        MavenSession or MockMavenSession instance
    """
    if mock:
        return MockMavenSession(profile=profile, **kwargs)
    return MavenSession(profile=profile, **kwargs)


# Convenience function for simple usage
def quick_chat(messages: List[str], profile: str = "FULL_AGENCY") -> List[str]:
    """
    Quick helper to send multiple messages and get responses.

    Args:
        messages: List of user messages to send
        profile: Maven profile to use

    Returns:
        List of Maven responses
    """
    responses = []
    with MavenSession(profile=profile) as session:
        for msg in messages:
            response = session.send(msg)
            responses.append(response)
    return responses


if __name__ == "__main__":
    # Simple test
    print("Testing Maven session...")

    with MavenSession(profile="FULL_AGENCY", debug=True) as session:
        print("\n--- Sending: Hello ---")
        reply = session.send("Hello")
        print(f"Reply: {reply}")

        print("\n--- Sending: Who are you? ---")
        reply = session.send("Who are you?")
        print(f"Reply: {reply}")

    print("\nTranscript:")
    print(session.transcript.to_string())
