"""
report_builder.py - Generate audit reports from test results

Produces both machine-readable JSON and human-readable Markdown reports.
"""

from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from collections import defaultdict


@dataclass
class TestResult:
    """Result of a single test."""
    test_id: str
    test_name: str
    capability: str
    severity: str
    score: int  # 0-3
    max_score: int  # Always 3
    reason: str
    hallucination_detected: bool
    identity_violation: bool
    transcript: str
    suite: str  # "C3" or "CCS"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.test_id,
            "name": self.test_name,
            "capability": self.capability,
            "severity": self.severity,
            "score": self.score,
            "max_score": self.max_score,
            "reason": self.reason,
            "hallucination_detected": self.hallucination_detected,
            "identity_violation": self.identity_violation,
            "suite": self.suite,
        }

    @property
    def passed(self) -> bool:
        return self.score >= 2

    @property
    def critical_failure(self) -> bool:
        return self.severity == "critical" and self.score == 0


@dataclass
class AuditReport:
    """Complete audit report."""
    timestamp: str
    profile: str
    results: List[TestResult] = field(default_factory=list)

    @property
    def c3_results(self) -> List[TestResult]:
        return [r for r in self.results if r.suite == "C3"]

    @property
    def ccs_results(self) -> List[TestResult]:
        return [r for r in self.results if r.suite == "CCS"]

    @property
    def c3_score(self) -> int:
        return sum(r.score for r in self.c3_results)

    @property
    def c3_max(self) -> int:
        return sum(r.max_score for r in self.c3_results)

    @property
    def ccs_score(self) -> int:
        return sum(r.score for r in self.ccs_results)

    @property
    def ccs_max(self) -> int:
        return sum(r.max_score for r in self.ccs_results)

    @property
    def total_score(self) -> int:
        return sum(r.score for r in self.results)

    @property
    def total_max(self) -> int:
        return sum(r.max_score for r in self.results)

    @property
    def score_percentage(self) -> float:
        if self.total_max == 0:
            return 0.0
        return (self.total_score / self.total_max) * 100

    @property
    def by_capability(self) -> Dict[str, Dict[str, int]]:
        """Group scores by capability."""
        caps = defaultdict(lambda: {"score": 0, "max": 0})
        for r in self.results:
            caps[r.capability]["score"] += r.score
            caps[r.capability]["max"] += r.max_score
        return dict(caps)

    @property
    def failing_tests(self) -> List[TestResult]:
        """Tests that scored 0 or 1."""
        return [r for r in self.results if r.score < 2]

    @property
    def critical_failures(self) -> List[TestResult]:
        """Critical severity tests that failed."""
        return [r for r in self.results if r.critical_failure]

    @property
    def hallucinations(self) -> List[TestResult]:
        """Tests where hallucination was detected."""
        return [r for r in self.results if r.hallucination_detected]

    @property
    def identity_violations(self) -> List[TestResult]:
        """Tests where identity violation was detected."""
        return [r for r in self.results if r.identity_violation]


def build_json_report(report: AuditReport) -> Dict[str, Any]:
    """
    Build machine-readable JSON report.

    Args:
        report: AuditReport object

    Returns:
        Dictionary suitable for JSON serialization
    """
    return {
        "timestamp": report.timestamp,
        "profile": report.profile,
        "overall": {
            "total_score": report.total_score,
            "total_max": report.total_max,
            "percentage": round(report.score_percentage, 1),
            "c3_score": report.c3_score,
            "c3_max": report.c3_max,
            "ccs_score": report.ccs_score,
            "ccs_max": report.ccs_max,
        },
        "by_capability": report.by_capability,
        "issues": {
            "failing_tests": len(report.failing_tests),
            "critical_failures": len(report.critical_failures),
            "hallucinations_detected": len(report.hallucinations),
            "identity_violations": len(report.identity_violations),
        },
        "tests": [r.to_dict() for r in report.results],
    }


def build_markdown_report(report: AuditReport) -> str:
    """
    Build human-readable Markdown report.

    Args:
        report: AuditReport object

    Returns:
        Markdown formatted string
    """
    lines = []

    # Header
    lines.append("# Maven Conversational Audit Report")
    lines.append("")
    lines.append(f"**Generated:** {report.timestamp}")
    lines.append(f"**Profile:** {report.profile}")
    lines.append("")

    # Overall Summary
    lines.append("## Overall Summary")
    lines.append("")
    lines.append(f"| Metric | Score |")
    lines.append(f"|--------|-------|")
    lines.append(f"| **Total Score** | {report.total_score}/{report.total_max} ({report.score_percentage:.1f}%) |")
    lines.append(f"| C3 (Competence) | {report.c3_score}/{report.c3_max} |")
    lines.append(f"| CCS (Stress) | {report.ccs_score}/{report.ccs_max} |")
    lines.append("")

    # Grade
    pct = report.score_percentage
    if pct >= 90:
        grade = "A"
        grade_msg = "Excellent"
    elif pct >= 80:
        grade = "B"
        grade_msg = "Good"
    elif pct >= 70:
        grade = "C"
        grade_msg = "Acceptable"
    elif pct >= 60:
        grade = "D"
        grade_msg = "Needs Improvement"
    else:
        grade = "F"
        grade_msg = "Failing"

    lines.append(f"**Grade: {grade}** - {grade_msg}")
    lines.append("")

    # Issues Summary
    lines.append("## Issues Summary")
    lines.append("")
    if report.critical_failures:
        lines.append(f"- **{len(report.critical_failures)} CRITICAL FAILURES**")
    if report.hallucinations:
        lines.append(f"- {len(report.hallucinations)} hallucinations detected")
    if report.identity_violations:
        lines.append(f"- {len(report.identity_violations)} identity violations")
    lines.append(f"- {len(report.failing_tests)} total failing tests")
    lines.append("")

    # Capability Breakdown
    lines.append("## Score by Capability")
    lines.append("")
    lines.append("| Capability | Score | Percentage |")
    lines.append("|------------|-------|------------|")
    for cap, scores in sorted(report.by_capability.items()):
        cap_pct = (scores["score"] / scores["max"] * 100) if scores["max"] > 0 else 0
        status = "✅" if cap_pct >= 70 else "⚠️" if cap_pct >= 50 else "❌"
        lines.append(f"| {cap} | {scores['score']}/{scores['max']} | {cap_pct:.0f}% {status} |")
    lines.append("")

    # Critical Failures
    if report.critical_failures:
        lines.append("## Critical Failures")
        lines.append("")
        lines.append("These critical tests MUST be fixed:")
        lines.append("")
        for test in report.critical_failures:
            lines.append(f"### ❌ {test.test_id}: {test.test_name}")
            lines.append("")
            lines.append(f"**Capability:** {test.capability}")
            lines.append(f"**Score:** {test.score}/3")
            lines.append(f"**Reason:** {test.reason}")
            lines.append("")
            lines.append("**Transcript:**")
            lines.append("```")
            lines.append(test.transcript[:1000])
            if len(test.transcript) > 1000:
                lines.append("... (truncated)")
            lines.append("```")
            lines.append("")

    # Top Failing Tests
    lines.append("## Top Failing Tests")
    lines.append("")
    failing_sorted = sorted(
        report.failing_tests,
        key=lambda r: (r.severity == "critical", r.score),
        reverse=False
    )[:10]

    if failing_sorted:
        for test in failing_sorted:
            severity_icon = "🔴" if test.severity == "critical" else "🟡" if test.severity == "high" else "🟢"
            lines.append(f"### {severity_icon} {test.test_id}: {test.test_name}")
            lines.append("")
            lines.append(f"- **Capability:** {test.capability}")
            lines.append(f"- **Severity:** {test.severity}")
            lines.append(f"- **Score:** {test.score}/3")
            lines.append(f"- **Reason:** {test.reason}")
            if test.hallucination_detected:
                lines.append("- **⚠️ HALLUCINATION DETECTED**")
            if test.identity_violation:
                lines.append("- **⚠️ IDENTITY VIOLATION**")
            lines.append("")
            lines.append("<details>")
            lines.append("<summary>View Transcript</summary>")
            lines.append("")
            lines.append("```")
            lines.append(test.transcript)
            lines.append("```")
            lines.append("</details>")
            lines.append("")
    else:
        lines.append("No failing tests! 🎉")
        lines.append("")

    # All Tests Summary
    lines.append("## All Tests")
    lines.append("")
    lines.append("### C3 - Conversational Competence")
    lines.append("")
    lines.append("| ID | Name | Score | Status |")
    lines.append("|----|------|-------|--------|")
    for test in report.c3_results:
        status = "✅" if test.score >= 2 else "⚠️" if test.score == 1 else "❌"
        lines.append(f"| {test.test_id} | {test.test_name} | {test.score}/3 | {status} |")
    lines.append("")

    lines.append("### CCS - Conversational Coherence Stress")
    lines.append("")
    lines.append("| ID | Name | Score | Status |")
    lines.append("|----|------|-------|--------|")
    for test in report.ccs_results:
        status = "✅" if test.score >= 2 else "⚠️" if test.score == 1 else "❌"
        lines.append(f"| {test.test_id} | {test.test_name} | {test.score}/3 | {status} |")
    lines.append("")

    # Recommendations
    lines.append("## Recommendations")
    lines.append("")
    if report.critical_failures:
        lines.append("1. **IMMEDIATE:** Fix critical failures in identity and hallucination tests")
    if report.hallucinations:
        lines.append("2. Review hallucination prevention - Maven is making up facts")
    if report.identity_violations:
        lines.append("3. Strengthen identity consistency - Maven is confused about who it is")

    weak_caps = [
        cap for cap, scores in report.by_capability.items()
        if scores["max"] > 0 and (scores["score"] / scores["max"]) < 0.7
    ]
    if weak_caps:
        lines.append(f"4. Focus on weak capabilities: {', '.join(weak_caps)}")

    lines.append("")
    lines.append("---")
    lines.append(f"*Report generated by Maven Conversational Audit v1.0*")

    return "\n".join(lines)


def save_reports(
    report: AuditReport,
    output_dir: str = "artifacts",
) -> Dict[str, str]:
    """
    Save both JSON and Markdown reports to files.

    Args:
        report: AuditReport object
        output_dir: Directory to save reports

    Returns:
        Dictionary with paths to saved files
    """
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    # Generate timestamp for filenames
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    # Save JSON
    json_path = output_path / f"conv_audit_results_{ts}.json"
    json_data = build_json_report(report)
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(json_data, f, indent=2)

    # Also save as latest
    latest_json = output_path / "conv_audit_results.json"
    with open(latest_json, "w", encoding="utf-8") as f:
        json.dump(json_data, f, indent=2)

    # Save Markdown
    md_path = output_path / f"conv_audit_report_{ts}.md"
    md_content = build_markdown_report(report)
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md_content)

    # Also save as latest
    latest_md = output_path / "conv_audit_report.md"
    with open(latest_md, "w", encoding="utf-8") as f:
        f.write(md_content)

    return {
        "json": str(json_path),
        "json_latest": str(latest_json),
        "markdown": str(md_path),
        "markdown_latest": str(latest_md),
    }


def print_summary(report: AuditReport) -> None:
    """Print a brief summary to console."""
    print("\n" + "=" * 60)
    print("MAVEN CONVERSATIONAL AUDIT SUMMARY")
    print("=" * 60)
    print(f"Profile: {report.profile}")
    print(f"Timestamp: {report.timestamp}")
    print("-" * 60)
    print(f"Total Score: {report.total_score}/{report.total_max} ({report.score_percentage:.1f}%)")
    print(f"  C3 (Competence): {report.c3_score}/{report.c3_max}")
    print(f"  CCS (Stress):    {report.ccs_score}/{report.ccs_max}")
    print("-" * 60)

    if report.critical_failures:
        print(f"⚠️  CRITICAL FAILURES: {len(report.critical_failures)}")
    if report.hallucinations:
        print(f"⚠️  Hallucinations: {len(report.hallucinations)}")
    if report.identity_violations:
        print(f"⚠️  Identity Violations: {len(report.identity_violations)}")

    print(f"Failing Tests: {len(report.failing_tests)}/{len(report.results)}")
    print("=" * 60 + "\n")


if __name__ == "__main__":
    # Test the report builder
    from datetime import datetime

    # Create mock results
    results = [
        TestResult(
            test_id="C3-01",
            test_name="Basic Context",
            capability="context_tracking",
            severity="high",
            score=3,
            max_score=3,
            reason="Perfect",
            hallucination_detected=False,
            identity_violation=False,
            transcript="USER: Hi\nMAVEN: Hello!",
            suite="C3",
        ),
        TestResult(
            test_id="C3-07",
            test_name="Identity",
            capability="identity_consistency",
            severity="critical",
            score=0,
            max_score=3,
            reason="Claimed to be ChatGPT",
            hallucination_detected=False,
            identity_violation=True,
            transcript="USER: Who are you?\nMAVEN: I am ChatGPT.",
            suite="C3",
        ),
    ]

    report = AuditReport(
        timestamp=datetime.now().isoformat(),
        profile="FULL_AGENCY",
        results=results,
    )

    print_summary(report)
    print(build_markdown_report(report))
