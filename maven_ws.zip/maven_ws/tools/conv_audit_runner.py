#!/usr/bin/env python3
"""
conv_audit_runner.py - Main orchestrator for Maven Conversational Audit

This is the "button" - run this to execute the full audit suite.

Usage:
    python -m tools.conv_audit_runner --profile FULL_AGENCY
    python -m tools.conv_audit_runner --mock  # For testing without Maven
"""

from __future__ import annotations

import argparse
import sys
import yaml
import random
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from tools.maven_session import MavenSession, MockMavenSession, create_session
from tools.llm_judger import judge_test, judge_with_rules, JudgeVerdict
from tools.report_builder import (
    AuditReport,
    TestResult,
    save_reports,
    print_summary,
)


def load_test_suite(suite_path: str) -> Dict[str, Any]:
    """
    Load a test suite from YAML file.

    Args:
        suite_path: Path to the YAML file

    Returns:
        Parsed suite dictionary
    """
    with open(suite_path, "r") as f:
        return yaml.safe_load(f)


def get_test_text(turn: Dict[str, Any], test: Dict[str, Any]) -> str:
    """
    Get the text for a turn, handling variants if present.

    Args:
        turn: The turn dictionary
        test: The full test dictionary (may contain variants)

    Returns:
        The text to send
    """
    text = turn.get("text", "")

    # If this is the first turn and test has variants, randomly pick one
    if test.get("variants") and turn == test["turns"][0]:
        text = random.choice(test["variants"])

    return text


import time as _time_module  # For timing benchmarks


def run_single_test(
    test: Dict[str, Any],
    session: MavenSession,
    suite_name: str,
    judges: List[str],
    verbose: bool = False,
) -> TestResult:
    """
    Run a single test case.

    Args:
        test: Test definition from YAML
        session: Maven session to use
        suite_name: Name of the suite (C3 or CCS)
        judges: List of judges to use for scoring
        verbose: Print progress

    Returns:
        TestResult object
    """
    test_id = test.get("id", "unknown")
    test_name = test.get("name", "Unknown Test")
    is_benchmark = test.get("benchmark", False)
    max_latency_ms = test.get("max_latency_ms", 1000)

    if verbose:
        print(f"  Running: {test_id} - {test_name}")

    # Reset session if required
    if test.get("reset_session", True):
        session.reset()

    # Track timing for benchmark tests
    turn_latencies = []

    # Execute all turns
    for turn in test.get("turns", []):
        if turn.get("role") == "user":
            text = get_test_text(turn, test)

            # Time the response for benchmark tests
            start_time = _time_module.time()
            response = session.send(text)
            latency_ms = (_time_module.time() - start_time) * 1000
            turn_latencies.append(latency_ms)

            if verbose:
                print(f"    USER: {text}")
                print(f"    MAVEN: {response}")
                if is_benchmark:
                    print(f"    [Latency: {latency_ms:.2f}ms]")
                print()  # Blank line for readability

    # Get the transcript
    transcript = session.transcript.to_string()

    # For benchmark tests, check latency of recall queries (skip first turn)
    timing_penalty = 0
    if is_benchmark and len(turn_latencies) > 1:
        recall_latencies = turn_latencies[1:]  # Skip setup turn
        avg_recall_latency = sum(recall_latencies) / len(recall_latencies)
        if avg_recall_latency > max_latency_ms:
            timing_penalty = 1  # Reduce score by 1 for slow recalls
            if verbose:
                print(f"    [TIMING PENALTY: Avg recall {avg_recall_latency:.2f}ms > {max_latency_ms}ms threshold]")

    # Build test metadata
    test_metadata = {
        "id": test_id,
        "name": test_name,
        "capability": test.get("capability", "unknown"),
        "severity": test.get("severity", "medium"),
    }

    # Get rubric
    rubric = test.get("rubric", {})

    # Judge the test
    if judges:
        verdict = judge_test(
            test_metadata=test_metadata,
            transcript=transcript,
            rubric=rubric,
            judges=judges,
        )
    else:
        # Use rule-based fallback
        rule_result = judge_with_rules(test_metadata, transcript, rubric)
        verdict = JudgeVerdict(
            test_id=test_id,
            final_score=rule_result.score,
            consensus=True,
            reason=rule_result.reason,
            hallucination_detected=rule_result.hallucination_detected,
            identity_violation=rule_result.identity_violation,
            individual_results=[rule_result],
        )

    # Apply timing penalty for benchmark tests
    final_score = max(0, verdict.final_score - timing_penalty)
    timing_note = ""
    if is_benchmark and timing_penalty > 0:
        timing_note = f" [Timing penalty: -{timing_penalty}]"

    # Build result
    return TestResult(
        test_id=test_id,
        test_name=test_name,
        capability=test.get("capability", "unknown"),
        severity=test.get("severity", "medium"),
        score=final_score,
        max_score=3,
        reason=verdict.reason,
        hallucination_detected=verdict.hallucination_detected,
        identity_violation=verdict.identity_violation,
        transcript=transcript,
        suite=suite_name,
    )


def run_test_suite(
    suite: Dict[str, Any],
    session: MavenSession,
    suite_name: str,
    judges: List[str],
    verbose: bool = False,
) -> List[TestResult]:
    """
    Run all tests in a suite.

    Args:
        suite: Loaded suite dictionary
        session: Maven session to use
        suite_name: Name of the suite for labeling
        judges: List of judges to use
        verbose: Print progress

    Returns:
        List of TestResult objects
    """
    results = []
    tests = suite.get("tests", [])

    if verbose:
        print(f"\nRunning {suite_name}: {len(tests)} tests")
        print("-" * 40)

    for test in tests:
        try:
            result = run_single_test(
                test=test,
                session=session,
                suite_name=suite_name,
                judges=judges,
                verbose=verbose,
            )
            results.append(result)

            if verbose:
                status = "✅" if result.score >= 2 else "⚠️" if result.score == 1 else "❌"
                print(f"    Result: {result.score}/3 {status}")

        except Exception as e:
            if verbose:
                print(f"    ERROR: {e}")
            results.append(TestResult(
                test_id=test.get("id", "unknown"),
                test_name=test.get("name", "Unknown"),
                capability=test.get("capability", "unknown"),
                severity=test.get("severity", "medium"),
                score=0,
                max_score=3,
                reason=f"Test execution error: {e}",
                hallucination_detected=False,
                identity_violation=False,
                transcript="",
                suite=suite_name,
            ))

    return results


def run_conversational_audit(
    profile: str = "FULL_AGENCY",
    mock: bool = False,
    judges: List[str] = None,
    output_dir: str = "artifacts",
    verbose: bool = True,
    c3_only: bool = False,
    ccs_only: bool = False,
    extended: bool = True,  # Now runs by default
    extended_only: bool = False,
) -> str:
    """
    Run the full conversational audit.

    This is the main entry point - the "button".

    Args:
        profile: Maven profile to use
        mock: If True, use mock session for testing
        judges: List of LLM judges to use (default: ["local"])
        output_dir: Directory to save reports
        verbose: Print progress to console
        c3_only: Only run C3 tests
        ccs_only: Only run CCS tests
        extended: Also run extended test suite
        extended_only: Only run extended test suite

    Returns:
        Path to the generated report
    """
    if judges is None:
        judges = ["local"]

    # Find test files
    base_dir = Path(__file__).parent.parent
    c3_path = base_dir / "tests" / "conv_c3.yaml"
    ccs_path = base_dir / "tests" / "conv_ccs.yaml"
    c3_extended_path = base_dir / "tests" / "conv_c3_extended.yaml"

    if verbose:
        print("=" * 60)
        print("MAVEN CONVERSATIONAL AUDIT")
        print("=" * 60)
        print(f"Profile: {profile}")
        print(f"Mock Mode: {mock}")
        print(f"Judges: {judges}")
        print(f"Output: {output_dir}")
        if extended or extended_only:
            print(f"Extended Tests: {'Only' if extended_only else 'Included'}")
        print("=" * 60)

    # Load test suites
    all_results = []

    # Create session
    session = create_session(profile=profile, mock=mock)
    session.start()

    try:
        # Run C3 tests
        if not ccs_only and not extended_only and c3_path.exists():
            c3_suite = load_test_suite(str(c3_path))
            c3_results = run_test_suite(
                suite=c3_suite,
                session=session,
                suite_name="C3",
                judges=judges,
                verbose=verbose,
            )
            all_results.extend(c3_results)

        # Run CCS tests
        if not c3_only and not extended_only and ccs_path.exists():
            ccs_suite = load_test_suite(str(ccs_path))
            ccs_results = run_test_suite(
                suite=ccs_suite,
                session=session,
                suite_name="CCS",
                judges=judges,
                verbose=verbose,
            )
            all_results.extend(ccs_results)

        # Run Extended tests
        if (extended or extended_only) and c3_extended_path.exists():
            c3_ext_suite = load_test_suite(str(c3_extended_path))
            c3_ext_results = run_test_suite(
                suite=c3_ext_suite,
                session=session,
                suite_name="C3-EXT",
                judges=judges,
                verbose=verbose,
            )
            all_results.extend(c3_ext_results)

    finally:
        session.close()

    # Build report
    report = AuditReport(
        timestamp=datetime.now().isoformat(),
        profile=profile,
        results=all_results,
    )

    # Print summary
    if verbose:
        print_summary(report)

    # Save reports
    paths = save_reports(report, output_dir=output_dir)

    if verbose:
        print(f"Reports saved to:")
        print(f"  JSON: {paths['json_latest']}")
        print(f"  Markdown: {paths['markdown_latest']}")

    return paths["markdown_latest"]


def main():
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Maven Conversational Audit Runner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
    # Run full audit with default settings
    python -m tools.conv_audit_runner

    # Run with specific profile
    python -m tools.conv_audit_runner --profile FULL_AGENCY

    # Test the framework without Maven (mock mode)
    python -m tools.conv_audit_runner --mock

    # Use multiple LLM judges
    python -m tools.conv_audit_runner --judges local claude gpt

    # Run only C3 (quick) tests
    python -m tools.conv_audit_runner --c3-only

    # Quiet mode (no progress output)
    python -m tools.conv_audit_runner --quiet
        """
    )

    parser.add_argument(
        "--profile",
        default="FULL_AGENCY",
        help="Maven profile to use (default: FULL_AGENCY)"
    )
    parser.add_argument(
        "--mock",
        action="store_true",
        help="Use mock session for testing framework"
    )
    parser.add_argument(
        "--judges",
        nargs="+",
        default=["local"],
        help="LLM judges to use (default: local)"
    )
    parser.add_argument(
        "--output",
        default="artifacts",
        help="Output directory for reports (default: artifacts)"
    )
    parser.add_argument(
        "--c3-only",
        action="store_true",
        help="Only run C3 (competence) tests"
    )
    parser.add_argument(
        "--ccs-only",
        action="store_true",
        help="Only run CCS (stress) tests"
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress progress output"
    )
    parser.add_argument(
        "--rules-only",
        action="store_true",
        help="Use only rule-based judging (no LLM)"
    )
    parser.add_argument(
        "--extended",
        action="store_true",
        help="Also run extended test suite (includes timing benchmarks)"
    )
    parser.add_argument(
        "--extended-only",
        action="store_true",
        help="Only run extended test suite"
    )

    args = parser.parse_args()

    judges = [] if args.rules_only else args.judges

    try:
        result_path = run_conversational_audit(
            profile=args.profile,
            mock=args.mock,
            judges=judges,
            output_dir=args.output,
            verbose=not args.quiet,
            c3_only=args.c3_only,
            ccs_only=args.ccs_only,
            extended=args.extended,
            extended_only=args.extended_only,
        )
        print(f"\nAudit complete. Report: {result_path}")
        return 0

    except Exception as e:
        print(f"\nAudit failed: {e}", file=sys.stderr)
        if not args.quiet:
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
