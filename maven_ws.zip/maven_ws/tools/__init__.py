"""
Maven Tools Package
====================

Helper scripts and command-line utilities for maintenance, testing, and governance.

Modules:
    regression_harness: Core behavior invariant testing
    governance_report: Governance log analysis and reporting
    conv_audit_runner: Conversational competence and coherence testing
    maven_session: Maven session wrapper for automated testing
    llm_judger: LLM-based test scoring
    report_builder: Audit report generation
"""

# Conversational audit exports
from tools.conv_audit_runner import run_conversational_audit

__all__ = [
    "run_conversational_audit",
]
