TEST PACKS (drop-in)
Place the 'tests/packs' folders directly into your repo, preserving structure.

Included packs:
- tests/packs/early_learning/
- tests/packs/shapes_animals/

Replay the inputs in each '*.jsonl' in order using the SAME method you used for the Eiffel Tower run.
No CLI/chat needed; these are just user-like lines to feed the pipeline.
