SHAPES & ANIMALS TEST PACK (learn + error catch)
Use the root-level run_shapes_animals.bat to run all lines in order.
