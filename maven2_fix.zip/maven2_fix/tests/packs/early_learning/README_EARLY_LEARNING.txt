EARLY LEARNING TEST PACK
Replay each line in this file through the provided runner scripts.
