from templates.DOMAIN_BANK_TEMPLATE import bank_service_factory
service_api = bank_service_factory('philosophy')
