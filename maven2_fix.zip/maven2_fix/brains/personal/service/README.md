# Personal Brain (Individuality core)
Home: `brains/personal/service/personal_brain.py`
Type: personal_brain (outside cognitive tree)
Ops: HEALTH, RECORD_LIKE, RECORD_DISLIKE, REINFORCE, SET_PRIVACY, TOP_LIKES, WHY, SCORE_BOOST, EXPORT
Persistence: JSONL (STM/MTM/LTM/Cold) under this folder
