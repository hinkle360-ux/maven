TIER-2 UPGRADE (Drop-in Kit)
- Extract to Maven root.
- Run: python tools\apply_tier2.py
- Test: python run_maven.py "Do birds have wings?" 0.8
